from pathlib import Path
import hashlib,inspect,json,pickle,sys
import numpy as np,pandas as pd,scvelo as scv
out=Path(sys.argv[1]);out.mkdir(exist_ok=False)
assert scv.__version__=='0.3.3'
calls={name:str(inspect.signature(function)) for name,function in [('simulation',scv.datasets.simulation),('recover_dynamics',scv.tl.recover_dynamics),('velocity',scv.tl.velocity),('velocity_graph',scv.tl.velocity_graph),('velocity_pseudotime',scv.tl.velocity_pseudotime),('latent_time',scv.tl.latent_time)]}
(out/'ORIGINAL-SIGNATURES.json').write_text(json.dumps(calls,indent=2)+'\n')
parameters=dict(n_obs=160,n_vars=12,noise_model='normal',alpha=8,beta=0.5,gamma=0.3,t_max=20,random_seed=882341)
adata=scv.datasets.simulation(**parameters)
assert adata.shape==(160,12)
adata.obs_names=['NA']+['cell_β_'+str(i).zfill(3) for i in range(1,160)]
adata.var_names=['NA','gene_Γ']+['gene_'+str(i).zfill(2) for i in range(2,12)]
adata.obs['state']=pd.Categorical(['state_B']*53+['state_A']*53+['state_Γ']*54,categories=['state_Γ','state_B','state_A'],ordered=False)
t=adata.obs['true_t'].to_numpy();adata.obsm['X_caller_curve']=np.column_stack([t,np.sin(t/3)])
adata.uns['fixture_provenance']='Original scVelo0.3.3 normal-noise synthetic nonnegative abundances; exact generator parameters and caller curve retained. No author data, inferred author settings, fitted UMAP or biological validation.'
adata.write_h5ad(out/'complete-original-synthetic.h5ad')
for name,values in [('X',adata.X),('spliced',adata.layers['spliced']),('unspliced',adata.layers['unspliced'])]:
    assert np.asarray(values).shape==(160,12)
    with (out/(name+'.tsv')).open('x',encoding='utf-8',newline='\n') as stream:
        stream.write('feature_id\t'+'\t'.join(adata.obs_names)+'\n')
        for gene,row in zip(adata.var_names,np.asarray(values).T):stream.write(gene+'\t'+'\t'.join(format(float(v),'.17g') for v in row)+'\n')
with (out/'cells.tsv').open('x',encoding='utf-8',newline='\n') as stream:
    stream.write('cell_id\tstate\ttrue_t\tcurve_1\tcurve_2\n')
    for cell,state,time,xy in zip(adata.obs_names,adata.obs['state'],t,adata.obsm['X_caller_curve']):stream.write('\t'.join([cell,state,format(float(time),'.17g'),format(float(xy[0]),'.17g'),format(float(xy[1]),'.17g')])+'\n')
with (out/'original-numpy-rng.pickle').open('xb') as stream:pickle.dump(np.random.get_state(),stream,protocol=5)
files={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in out.iterdir() if p.is_file()}
(out/'FIXTURE.json').write_text(json.dumps(dict(status='GENERATED_ORIGINAL_SCVELO033_SYNTHETIC_COUNTS_NOT_WRAPPER_ANALYSIS',generator_version=scv.__version__,parameters=parameters,cells=160,genes=12,first_literal_cell='NA',first_literal_gene='NA',state_levels=['state_Γ','state_B','state_A'],row_order='all12 original genes in generation order',column_order='all160 original cells in generation order',files=files,paper_reproduced=False,new_tool_credit=0),indent=2,ensure_ascii=False)+'\n')
print('GENERATED_COMPLETE_160_CELL_12_GENE_ORIGINAL033_FIXTURE',flush=True)
