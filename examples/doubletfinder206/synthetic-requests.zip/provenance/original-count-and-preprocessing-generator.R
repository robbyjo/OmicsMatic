args<-commandArgs(TRUE);lib<-args[[1]];root<-args[[2]];out<-args[[3]]
.libPaths(c(lib,.libPaths()));library(Seurat);library(DoubletFinder);source(file.path(root,'tools/literature/velociraptor120/RValues.R'))
set.seed(206281L);ngenes<-300L;ncells<-160L;groups<-rep(1:4,length.out=ncells)
counts<-matrix(rpois(ngenes*ncells,lambda=2),ngenes,ncells)
for(i in 1:4)counts[((i-1)*30+1):(i*30),groups==i]<-counts[((i-1)*30+1):(i*30),groups==i]+rpois(30*sum(groups==i),lambda=6)
rownames(counts)<-sprintf('gene%03d',seq_len(ngenes));colnames(counts)<-sprintf('cell%03d',seq_len(ncells));colnames(counts)[1]<-'NA'
seu<-CreateSeuratObject(counts=Matrix::Matrix(counts,sparse=TRUE));seu<-NormalizeData(seu,verbose=FALSE);seu<-FindVariableFeatures(seu,nfeatures=100L,verbose=FALSE);seu<-ScaleData(seu,features=VariableFeatures(seu),verbose=FALSE);seu<-RunPCA(seu,npcs=5L,verbose=FALSE)
saveRDS(seu,file.path(out,'preprocessed-input.rds'),version=3)
input.capture<-try(captureRValues(seu,file.path(out,'complete-input-values')),silent=FALSE)
set.seed(206282L);rng<-list(kind=RNGkind(),seed=.Random.seed);original.args<-list(seu=seu,PCs=1:5,pN=.25,pK=.1,nExp=16L,reuse.pANN=NULL,sct=FALSE)
saveRDS(list(operation='doubletFinder',arguments=original.args,rng=rng),file.path(out,'request.rds'),version=3)
result<-do.call(DoubletFinder::doubletFinder,original.args);saveRDS(result,file.path(out,'complete-original-return.rds'),version=3)
output.capture<-try(captureRValues(result,file.path(out,'complete-result-values')),silent=FALSE)
jsonlite::write_json(list(status='ORIGINAL_DOUBLETFINDER_FULL_OBJECT_PROBE',input_capture_complete=!inherits(input.capture,'try-error'),output_capture_complete=!inherits(output.capture,'try-error'),input_error=if(inherits(input.capture,'try-error'))as.character(input.capture)else NULL,output_error=if(inherits(output.capture,'try-error'))as.character(output.capture)else NULL,metadata_columns=colnames(result[[]]),doublets=sum(result[['DF.classifications_0.25_0.1_16']][,1]=='Doublet'),R_version=R.version.string),file.path(out,'COMPLETED.json'),pretty=TRUE,auto_unbox=TRUE,null='null')
