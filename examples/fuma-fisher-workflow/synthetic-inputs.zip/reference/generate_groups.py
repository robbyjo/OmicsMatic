"""Independent synthetic BH/classification/set oracle, followed by original R Fisher fits."""
from pathlib import Path
from collections import OrderedDict,Counter,defaultdict
import csv,hashlib,json,math,subprocess

R=Path.cwd();O=None
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(path,header,rows):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',encoding='utf-8',newline='') as stream:
        out=csv.writer(stream,delimiter='\t',lineterminator='\n');out.writerow(header);out.writerows(rows)
def bh(values):
    ordered=sorted((value,i) for i,value in enumerate(values) if value is not None);result=[None]*len(values);next_value=1
    for rank in range(len(ordered),0,-1):
        value,i=ordered[rank-1];next_value=min(next_value,value*len(ordered)/rank);result[i]=next_value
    return result
def cell(value):return 'NA' if value is None else str(value).lower() if isinstance(value,bool) else str(value)
def dump(path,header,rows):write(path,header,[[cell(v) for v in row] for row in rows])
def build_case(case,matching,absence):
    base=O/case;base.mkdir();inputs=base/'inputs';inputs.mkdir();expected=base/'expected';expected.mkdir()
    definitions=[('M1','BASELINE','synthetic-M1','M1-v1','annotation-v1','GRCh37'),('M2','BASELINE','synthetic-M2','M2-v1','annotation-v2','GRCh38'),('B','TARGET','synthetic-bulk','B-v1','annotation-v2','GRCh38'),('N','TARGET','synthetic-nucleus','N-v1','annotation-v2','GRCh38'),('U','TARGET','synthetic-unassigned','U-v1','annotation-v2','GRCh38')]
    analyses=[[source,role,model,resource,'gene-v1','trait-v1',annotation,build] for source,role,model,resource,annotation,build in definitions]
    dump(inputs/'sources.tsv',['source','role','model','resource','gene_namespace','trait_namespace','gene_annotation','genome_build'],analyses)
    observations=[]
    def add(source,trait,context,gene,value):observations.append(dict(row=len(observations)+1,source=source,role='BASELINE' if source.startswith('M') else 'TARGET',family=source,test=source+'-'+str(len(observations)+1),gene='G'+str(gene),trait=trait,context=context,value=value))
    for source in ['M1','M2']:
        for trait in ['A','B']:
            for gene in range(1,11) if source=='M1' else range(3,13):
                value=None if gene==7 else .0001 if gene in [1,3,9] and (source=='M1' or trait=='B') else .6
                add(source,trait,source,gene,value)
    for trait in ['A','B']:
        for gene in [1,2,5,7,9,10,11,14]:add('B',trait,'bulk',gene,.7 if gene==10 else .0002)
    for context in ['C1','C2']:
        for trait in ['A','B']:
            for gene in [1,2,3,4,5,7,9,10,11,12,13,14]:
                add('N',trait,context,gene,None if gene==12 else .8 if gene==10 or context=='C2' and gene==4 else .0003)
            if context=='C1' and trait=='A':add('N',trait,context,3,.0004)
    add('U','A','outside',1,.0001);add('U','B','outside',14,None)
    for source,_,_,_,_,_ in definitions:
        selected=[r for r in observations if r['source']==source];q=bh([r['value'] for r in selected])
        for r,value in zip(selected,q):r['q']=value;r['selected']=value is not None and value<=.05
    dump(inputs/'association-families.tsv',['family','source','encoding','adjustment','missing','reported_zero','duplicates','probability_definition'],[[s,s,'P_VALUE','BH','EXCLUDE','ERROR','RETAIN','synthetic raw probability;complete source family across declared traits and contexts'] for s,_,_,_,_,_ in definitions])
    domains=Counter((r['family'],r['trait'],r['context']) for r in observations)
    dump(inputs/'association-members.tsv',['family','trait','context','expected_rows'],[[*domain,n] for domain,n in domains.items()])
    dump(inputs/'tests.tsv',['family','test_id','gene','trait','context','value'],[[r[k] for k in ['family','test','gene','trait','context','value']] for r in observations])
    across=matching=='gene-across-traits'
    key=lambda r:(r['gene'],None if across else r['trait'])
    baseline=[r for r in observations if r['role']=='BASELINE'];targets=[r for r in observations if r['role']=='TARGET']
    known=defaultdict(list)
    for r in baseline:
        if r['selected']:known[key(r)].append(r['row'])
    baseline_sources={r['source'] for r in baseline}
    available={s:{key(r) for r in baseline if r['source']==s and r['value'] is not None} for s in baseline_sources}
    missing={key(r) for r in baseline if r['value'] is None}
    fully_available=set.intersection(*available.values())
    for r in targets:
        r['key']=key(r)
        if r['value'] is None:r['decision']='MISSING_TARGET_VALUE';r['hits']=None
        elif not r['selected']:r['decision']='TARGET_NOT_SELECTED';r['hits']=None
        else:
            r['hits']=len(known[r['key']]);unresolved=r['key'] in missing or absence=='require-baseline-tests' and r['key'] not in fully_available or any(not keys for keys in available.values())
            r['decision']='KNOWN' if r['hits'] else 'UNASSESSABLE_BASELINE' if unresolved else 'NOVEL_RELATIVE_TO_BASELINES'
    dump(expected/'upstream-tests.tsv',['input_row','family','source','gene','trait','context','input_value','adjusted_p','selected'],[[r[k] for k in ['row','family','source','gene','trait','context','value','q','selected']] for r in observations])
    dump(expected/'target-decisions.tsv',['target_input_row','source','family','test_id','gene','source_trait','source_context','matched_trait','matching','status','matched_known_tests'],[[r['row'],r['source'],r['family'],r['test'],r['gene'],r['trait'],r['context'],r['key'][1],matching,r['decision'],r['hits']] for r in targets])
    groups=OrderedDict([
        ('bulk',[('B',t,'bulk') for t in ['A','B']]),
        ('all',[('N',t,c) for c in ['C1','C2'] for t in ['A','B']]),
        ('class1',[('N',t,'C1') for t in ['A','B']]),
        ('class2',[('N',t,'C2') for t in ['A','B']]),
        ('trait-A',[('N','A',c) for c in ['C1','C2']]),
        ('empty',[('declared-empty','A','empty')])])
    domain_rows=lambda domain:[r for r in targets if (r['source'],r['trait'],r['context'])==domain]
    dump(inputs/'groups.tsv',['group','source','trait','context','expected_rows'],[[g,*d,len(domain_rows(d))] for g,ds in groups.items() for d in ds])
    specs=[]
    for name,group in [('all','all'),('c1','class1'),('c2','class2'),('trait-A','trait-A')]:
        for suffix,policy in [('both','RETAIN_BOTH'),('only','FINER_ONLY')]:specs.append((name+'-'+suffix,'label-only','pooled-label',group,'bulk',policy))
    specs.extend([('empty-vs-bulk','label-only','empty','empty','bulk','RETAIN_BOTH'),('bulk-vs-empty','label-only','empty','bulk','empty','RETAIN_BOTH'),('c1-c2-both','label-only','interclass','class1','class2','RETAIN_BOTH'),('c1-c2-only','label-only','interclass','class1','class2','FINER_ONLY')])
    families=[];comparisons=[]
    for correction in ['NONE','BH','BY','HOLM','BONFERRONI']:
        for encoding in ['P_VALUE','NATURAL_LOG']:
            for pseudo in [0,1]:
                family=correction+'-'+encoding+'-'+str(pseudo);families.append([family,correction,encoding,'ERROR','RETAIN_SOURCE',pseudo,.95])
                comparisons.extend([[family,*spec] for spec in specs])
    dump(inputs/'fisher-families.tsv',['family','correction','encoding','missing','empty','pseudocount','confidence'],families)
    dump(inputs/'comparisons.tsv',['family','test_id','trait','context','finer_group','comparator_group','overlap'],comparisons)
    dump(inputs/'plan.tsv',['family','test_id'],[r[:2] for r in comparisons])
    group_keys={};dispositions=[];key_rows=[];contributors=[];members=[];audits=[];used=set()
    for group,ds in groups.items():
        rows=[]
        for d in ds:
            match=domain_rows(d);members.append([group,*d,len(match),len(match)]);rows.extend(match)
        for r in rows:
            used.add(r['row']);disposition={'MISSING_TARGET_VALUE':'missing-target-excluded','TARGET_NOT_SELECTED':'not-selected','UNASSESSABLE_BASELINE':'unassessable-key-excluded'}.get(r['decision'],'selected-key-contributor')
            dispositions.append([group,r['row'],r['source'],r['trait'],r['context'],r['gene'],r['key'][1],r['decision'],disposition])
        selected=[r for r in rows if r['selected']];keys=OrderedDict()
        for r in selected:keys.setdefault(r['key'],[]).append(r)
        group_keys[group]=keys
        for k,rs in keys.items():
            status={r['decision'] for r in rs};assert len(status)==1;decision=status.pop();key_id=len(key_rows)+1
            key_rows.append([key_id,group,*k,decision,decision!='UNASSESSABLE_BASELINE',len(rs)])
            contributors.extend([[key_id,r['row']] for r in rs])
        counts=Counter(rs[0]['decision'] for rs in keys.values())
        audits.append([group,len(rows),len(rows),len(selected),counts['KNOWN'],counts['NOVEL_RELATIVE_TO_BASELINES'],counts['UNASSESSABLE_BASELINE'],sum(r['value'] is None for r in rows),sum(r['value'] is not None and not r['selected'] for r in rows)])
    dump(expected/'group-audit.tsv',['group','expected_rows','actual_rows','selected_rows','known_keys','novel_keys','unassessable_keys','missing_target_rows','unselected_rows'],audits)
    dump(expected/'group-members.tsv',['group','source','trait','context','expected_rows','actual_rows'],members)
    dump(expected/'group-keys.tsv',['group_key_row','group','gene','matched_trait','decision','counted_before_comparison_overlap','contributor_rows'],key_rows)
    dump(expected/'group-contributors.tsv',['group_key_row','known_association_input_row'],contributors)
    dump(expected/'group-dispositions.tsv',['group','known_association_input_row','source','source_trait','source_context','gene','matched_trait','decision','disposition'],dispositions)
    dump(expected/'unassigned-targets.tsv',['known_association_input_row','source','source_trait','source_context','gene','matched_trait','decision'],[[r['row'],r['source'],r['trait'],r['context'],r['gene'],r['key'][1],r['decision']] for r in targets if r['row'] not in used])
    shared=[];shared_contributors=[];counts=[]
    for family,test,trait,context,finer,comparator,policy in comparisons:
        left,right=group_keys[finer],group_keys[comparator];intersection=set(left)&set(right)
        for k in left:
            if k in intersection:
                shared_id=len(shared)+1;shared.append([shared_id,family,test,*k,policy,policy=='FINER_ONLY',len(left[k]),len(right[k])]);shared_contributors.extend([[shared_id,side,r['row']] for side,rs in [('finer',left[k]),('comparator',right[k])] for r in rs])
        eligible=lambda keys,status:{k for k,rs in keys.items() if rs[0]['decision']==status}
        finer_keys=set(left)-(set(right) if policy=='FINER_ONLY' else set())
        a=len(eligible(left,'NOVEL_RELATIVE_TO_BASELINES')&finer_keys);b=len(eligible(left,'KNOWN')&finer_keys);c=len(eligible(right,'NOVEL_RELATIVE_TO_BASELINES'));d=len(eligible(right,'KNOWN'))
        definition=next(f for f in families if f[0]==family)
        counts.append([case,family,test,trait,context,a,b,c,d,definition[5],definition[6],definition[1],definition[2]])
    dump(expected/'shared-keys.tsv',['shared_key_row','family','test_id','gene','matched_trait','overlap_policy','excluded_from_finer','finer_contributors','comparator_contributors'],shared)
    dump(expected/'shared-contributors.tsv',['shared_key_row','side','known_association_input_row'],shared_contributors)
    dump(expected/'known-association-sources.tsv',['source','role','model','resource','gene_namespace','trait_namespace','gene_annotation','genome_build'],analyses)
    record=dict(case=case,matching=matching,absence=absence,input_rows=len(observations),target_rows=len(targets),family_rows=len(families),comparison_rows=len(comparisons),group_keys=len(key_rows),group_contributors=len(contributors),group_dispositions=len(dispositions),shared_keys=len(shared),shared_contributors=len(shared_contributors),unassigned=len(targets)-len(used),expected_files={p.name:sha(p) for p in sorted(expected.iterdir())},source='Entirely synthetic, generated from explicit raw inputs. No Java output used as reference.')
    (base/'protocol.json').write_text(json.dumps(record,indent=2)+'\n');return counts,record
def main():
    global O
    import argparse
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out',required=True,type=Path);parser.add_argument('--rscript',default='Rscript');args=parser.parse_args();O=args.out.resolve()
    O.mkdir(parents=True,exist_ok=False);all_counts=[];cases=[]
    for matching in ['gene-trait','gene-across-traits']:
        for absence in ['require-baseline-tests','selected-reference']:
            case=matching+'-'+absence;counts,record=build_case(case,matching,absence);all_counts.extend(counts);cases.append(record)
    dump(O/'counts.tsv',['case','family','test_id','trait','context','a','b','c','d','pseudocount','confidence','correction','encoding'],all_counts)
    script=O/'reference.R';script.write_text('''args<-commandArgs(TRUE)
d<-read.delim(file.path(args[1],"counts.tsv"),check.names=FALSE)
d$p<-d$log_p<-d$OR<-d$lower<-d$upper<-d$adjusted<-d$log_adjusted<-NA_real_
for(i in seq_len(nrow(d))) {
 r<-d[i,];ct<-matrix(c(r$a,r$b,r$c,r$d)+r$pseudocount,2,byrow=TRUE);f<-fisher.test(ct,conf.level=r$confidence)
 m<-sum(ct[,1]);n<-sum(ct[,2]);k<-sum(ct[1,]);x<-ct[1,1];support<-max(0,k-n):min(k,m)
 ld<-dhyper(support,m,n,k,log=TRUE);weights<-exp(ld-max(ld));prob<-weights/sum(weights);take<-prob<=prob[x-min(support)+1]*(1+1e-7)
 chosen<-ld[take];lp<-if(all(take))0 else min(0,max(chosen)+log(sum(exp(chosen-max(chosen))))-max(ld)-log(sum(weights)))
 d$p[i]<-f$p.value;d$log_p[i]<-lp;d$OR[i]<-unname(f$estimate);d$lower[i]<-f$conf.int[1];d$upper[i]<-f$conf.int[2]
}
for(group in unique(paste(d$case,d$family))) {
 ix<-which(paste(d$case,d$family)==group);method<-d$correction[ix[1]];encoding<-d$encoding[ix[1]]
 if(encoding=="P_VALUE") {d$adjusted[ix]<-p.adjust(d$p[ix],method=switch(method,NONE="none",HOLM="holm",BONFERRONI="bonferroni",method));d$log_adjusted[ix]<-log(d$adjusted[ix])}
 else {
  order<-order(d$log_p[ix],seq_along(ix));v<-d$log_p[ix][order];n<-length(ix);factor<-if(method=="BY")sum(1/seq_len(n)) else 1
  adjusted<-switch(method,NONE=v,BONFERRONI=v+log(n),HOLM=cummax(v+log(n-seq_len(n)+1)),BH=rev(cummin(rev(v+log(n/seq_len(n))))),BY=rev(cummin(rev(v+log(factor*n/seq_len(n))))))
  d$log_adjusted[ix[order]]<-pmin(0,adjusted);d$adjusted[ix]<-exp(d$log_adjusted[ix])
 }
}
d$selected<-ifelse(d$encoding=="P_VALUE",d$adjusted<=.05,d$log_adjusted<=log(.05))
for(name in c("p","log_p","OR","lower","upper","adjusted","log_adjusted"))d[[name]]<-format(d[[name]],digits=17,scientific=TRUE,trim=TRUE)
d$selected<-ifelse(d$selected,"true","false")
write.table(d,file.path(args[1],"reference.tsv"),sep="\\t",quote=FALSE,row.names=FALSE)
cat(R.version.string,"\\n",as.character(packageVersion("stats")),"\\n")
''',encoding='utf-8')
    linux=lambda p:'/mnt/'+p.drive[0].lower()+p.as_posix()[2:]
    p=subprocess.run([args.rscript,'--vanilla',str(script),str(O)],cwd=R,capture_output=True,timeout=180)
    (O/'R.stdout').write_bytes(p.stdout);(O/'R.stderr').write_bytes(p.stderr);assert p.returncode==0,p.stderr.decode(errors='replace')
    with (O/'reference.tsv').open(encoding='utf-8') as stream:reference=list(csv.DictReader(stream,delimiter='\t'))
    assert len(reference)==960
    proof=dict(status='generated-independent-complete-group-and-original-R-reference',cases=cases,rows=960,R_version=p.stdout.decode(errors='replace').strip(),files={name:sha(O/name) for name in ['counts.tsv','reference.R','reference.tsv']},scope='Independent raw-input BH/classification/set definitions produce complete group/contributor/exclusion/overlap/unassigned expected ledgers;fresh original R4.2.3 supplies all fixed-margin Fisher conditional odds/CI/P and complete corrections. Finite-log correction is explicitly separate. No Java output or historical source inference.')
    (O/'observed.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({key:proof[key] for key in ['status','rows','R_version']},indent=2),flush=True)
if __name__=='__main__':main()
