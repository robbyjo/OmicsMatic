args<-commandArgs(TRUE)
d<-read.delim(file.path(args[1],"counts.tsv"),check.names=FALSE)
d$p<-d$log_p<-d$OR<-d$lower<-d$upper<-d$adjusted<-d$log_adjusted<-NA_real_
for(i in seq_len(nrow(d))) {
 r<-d[i,];ct<-matrix(c(r$a,r$b,r$c,r$d)+r$pseudocount,2,byrow=TRUE);if(all(is.na(ct)))next;f<-fisher.test(ct,conf.level=r$confidence)
 m<-sum(ct[,1]);n<-sum(ct[,2]);k<-sum(ct[1,]);x<-ct[1,1];support<-max(0,k-n):min(k,m)
 ld<-dhyper(support,m,n,k,log=TRUE);weights<-exp(ld-max(ld));prob<-weights/sum(weights);take<-if(prob[x-min(support)+1]==0)ld<=ld[x-min(support)+1]+log1p(1e-7) else prob<=prob[x-min(support)+1]*(1+1e-7)
 chosen<-ld[take];lp<-if(all(take))0 else min(0,max(chosen)+log(sum(exp(chosen-max(chosen))))-max(ld)-log(sum(weights)))
 d$p[i]<-f$p.value;d$log_p[i]<-lp;d$OR[i]<-unname(f$estimate);d$lower[i]<-f$conf.int[1];d$upper[i]<-f$conf.int[2]
}
for(group in unique(paste(d$case,d$family))) {
 ix<-which(paste(d$case,d$family)==group);method<-d$correction[ix[1]];encoding<-d$encoding[ix[1]]
 if(encoding=="P_VALUE") {d$adjusted[ix]<-p.adjust(d$p[ix],method=switch(method,NONE="none",HOLM="holm",BONFERRONI="bonferroni",method));d$log_adjusted[ix]<-log(d$adjusted[ix])}
 else {
  order<-order(d$log_p[ix],seq_along(ix));v<-d$log_p[ix][order];n<-length(ix);factor<-if(method=="BY")sum(1/seq_len(n)) else 1
  adjusted<-switch(method,NONE=v,BONFERRONI=v+log(n),HOLM=cummax(v+log(n-seq_len(n)+1)),BH=rev(cummin(rev(v+log(n/seq_len(n))))),BY=rev(cummin(rev(v+log(factor*n/seq_len(n))))))
  d$log_adjusted[ix[order]]<-pmin(0,adjusted);d$adjusted[ix]<-exp(d$log_adjusted[ix])
 }
}
d$selected<-ifelse(d$encoding=="P_VALUE",d$adjusted<=.05,d$log_adjusted<=log(.05))
for(name in c("p","log_p","OR","lower","upper","adjusted","log_adjusted"))d[[name]]<-format(d[[name]],digits=17,scientific=TRUE,trim=TRUE)
d$selected<-ifelse(d$selected,"true","false")
write.table(d,file.path(args[1],"reference.tsv"),sep="\t",quote=FALSE,row.names=FALSE)
cat(R.version.string,"\n",as.character(packageVersion("stats")),"\n")
