from pathlib import Path
import subprocess,time,json
r=Path('/mnt/d/projects/JLinAlg');o=r/'build/literature-review/monocle-runtime/doubletfinder206-native-generator-run-3'
c=['/opt/omicsmatic-doubletfinder206-r453-20261114-1/.pixi/envs/default/bin/Rscript','--vanilla',str(r/'tools/literature/doubletfinder206/GenerateNativeReferences.R'),'/opt/omicsmatic-doubletfinder206-r453-20261114-1/library',str(r),str(r/'build/literature-review/monocle-runtime/doubletfinder206-native-references-3')]
with (o/'original.stdout').open('xb') as so,(o/'original.stderr').open('xb') as se:
 p=subprocess.Popen(c,cwd=o,stdout=so,stderr=se,stdin=subprocess.DEVNULL);(o/'LIVE.json').write_text(json.dumps(dict(pid=p.pid,command=c)))
 while True:
  try:code=p.wait(timeout=20);break
  except subprocess.TimeoutExpired:print('SAME_ORIGINAL_NATIVE_FIXTURE_GENERATOR_RUNNING',p.pid,flush=True)
(o/'PROCESS.json').write_text(json.dumps(dict(command=c,exit_code=code),indent=2)+'\n');print('ORIGINAL_NATIVE_FIXTURE_GENERATOR_EXIT',code,flush=True);raise SystemExit(code)
