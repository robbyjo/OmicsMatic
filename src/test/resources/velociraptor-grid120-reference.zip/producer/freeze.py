from pathlib import Path
import hashlib,json,zipfile
ROOT=Path('D:/projects/JLinAlg');BASE=ROOT/'build/literature-review/monocle-runtime';OUT=Path(__file__).resolve().parent
REF=BASE/'velociraptor-native-grid-binary-2';ORIGINAL=BASE/'velociraptor-native-grid-reference-1';NATIVE=BASE/'velociraptor-native-grid-java-1'
TARGET=ROOT/'src/test/resources/velociraptor-grid120-reference.zip'
def identity(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
index=json.loads((REF/'INDEX.json').read_bytes());proof=json.loads((NATIVE/'COMPLETED.json').read_bytes())
assert index['case_count']==31 and proof['status']=='PASS_SCOPED_NATIVE_JAVA_VELOCIRAPTOR120_GRID_ALL31_ORIGINAL_R_CASES'
for name,wanted in json.loads((NATIVE/'SOURCE-PINS.json').read_bytes()).items():assert identity((ROOT/name).read_bytes())==wanted,name
files={}
def put(name,raw):
 assert name not in files and not name.startswith('/') and all(part not in ['.','..'] for part in name.split('/'))
 files[name]=raw
rows=['id\tdirectory\tcells\tresolution\tscale\tbins\trequires_nonfinite_review']
for case in index['cases']:
 rows.append('\t'.join(map(str,[case['id'],case['directory'],case['cells'],case['resolution'],str(case['scale']).lower(),case['fields']['start']['rows'],str(case['requires_nonfinite_review']).lower()])))
 for field in case['fields'].values():
  raw=(REF/field['path']).read_bytes();assert len(raw)==field['bytes'];put('binary/'+field['path'],raw)
put('cases.tsv',('\n'.join(rows)+'\n').encode())
put('binary/INDEX.json',(REF/'INDEX.json').read_bytes())
for name in ['COMPLETE-ORIGINAL-GRID-RESULTS.rds','COMPLETE-ORIGINAL-GRID-CONDITIONS.rds','REFERENCE.json','Reference.R','run.py','process.stdout','process.stderr','TERMINAL.json']:
 put('original-reference/'+name,(ORIGINAL/name).read_bytes())
for name in ['Export.R','run.py','OBSERVER-CORRECTION.txt','BEFORE-SERIALIZATION.bin','AFTER-SERIALIZATION.bin','COMPLETE-VALUE-PRESERVATION.rds','COMPLETED.json','BINARY-PAYLOADS.json','ORIGINAL-DIAGNOSTICS-REVIEW.json','process.stdout','process.stderr','TERMINAL.json']:
 put('binary-export/'+name,(REF/name).read_bytes())
for name in ['Export.R','run.py','process.stdout','process.stderr','TERMINAL.json','FAILURE.json']:
 put('prior-refused-export/'+name,(BASE/'velociraptor-native-grid-binary-1'/name).read_bytes())
put('producer/RValues.R',(ROOT/'tools/literature/velociraptor120/RValues.R').read_bytes())
put('producer/freeze.py',Path(__file__).read_bytes())
put('upstream/velociraptor_1.20.0.tar.gz',(BASE/'velociraptor-source-intake-5/velociraptor_1.20.0.tar.gz').read_bytes())
put('upstream/SOURCE.json',(BASE/'velociraptor-source-intake-5/SOURCE.json').read_bytes())
put('upstream/ORIGINAL_MEMBERS.json',(BASE/'velociraptor-source-intake-5/ORIGINAL_MEMBERS.json').read_bytes())
put('upstream/R4.5.3-source-census.json',(BASE/'velociraptor-system-runtime-install-2/source-audit/SOURCE-CENSUS.json').read_bytes())
put('upstream/R4.5.3-session-info.txt',(BASE/'velociraptor-system-runtime-install-2/R-session-info.txt').read_bytes())
put('upstream/R4.5.3-pixi.toml',(BASE/'velociraptor-r453-private-runtime-install-1/pixi.toml').read_bytes())
put('upstream/R4.5.3-pixi.lock',(BASE/'velociraptor-r453-private-runtime-install-1/pixi.lock').read_bytes())
put('upstream/LICENSE-velociraptor120.txt',(ROOT/'src/main/resources/META-INF/LICENSE-velociraptor120.txt').read_bytes())
readme='''# Complete original velociraptor1.20.0 grid references

These31 original R4.5.3 gridVectors controls supply complete inputs and all
arithmetic intermediates. Binary payloads are row-major, little-endian int32 or
float64 as declared by binary/INDEX.json. They preserve original numeric bits;
the human-readable original-reference/REFERENCE.json is not the numeric source
for execution or acceptance. cases.tsv contains only names, dimensions and
explicit caller settings. No native Java output is a golden value.

All original results and R warning-condition objects are retained as RDS.
The source archive is the unchanged official Bioconductor3.22 velociraptor1.20.0
release; its eight R expression trees were compared with release Git commit
67b4a9ec4afba690f124e8d25015b9a02ca79e1a. The source census checks all11 original
installed function bodies and all three declared S4 generics/seven methods.
Native arithmetic needs no R/Python installation; regeneration of original
references requires permitted exact original prerequisites and new outputs.

WARNINGS: The R reference emitted a native stack-imbalance diagnostic whose
cause is unresolved. Read original-reference/process.stderr and
binary-export/ORIGINAL-DIAGNOSTICS-REVIEW.json. The zero delivered R warning
count in REFERENCE.json describes handlers around the31 grid calls only; it is
not a universal raw-console diagnostic count. All available consoles and
conditions remain retained. No original code was patched or warning removed.

The first binary exporter wrote available fields and refused its own opaque
serialization byte-identity assumption. Its code/error/console remain retained.
The successful exporter saves before/after serialization bytes and requires
strict complete R-value equality against a fresh original RDS read, including
numeric/NA/NaN bits and attribute order. Opaque RDS byte parity is not a claim.
All341 original binary fields are present in the successful transcript.

The native method covers finite two-dimensional coordinates/vectors with
nondegenerate finite axis ranges, positive integer resolution and nonoverflowing
group sums and scaled lengths. It preserves first-matching-cell group labels,
their gaps, input row order, terminal categories and computed NaN/infinity
classes when median-length scaling encounters zero. Unsupported native domains
refuse the complete calculation; use a qualified permitted original workflow
or skip dependent work. No row/value may be omitted or repaired silently.

These are method integration controls, not an RNA-velocity implementation,
author settings, biological validation, convergence or paper reproduction.
The separate R wrapper adapter remains unqualified and missing in the catalog;
this native component grants zero family implementation credit. The complete
250-paper objective remains active. SHA-256 provides integrity, not a signature.
'''
put('README.md',readme.encode())
members={name:identity(raw) for name,raw in sorted(files.items())}
put('MEMBERS.json',(json.dumps(dict(schema_version=1,members=members),indent=2)+'\n').encode())
assert not TARGET.exists()
with zipfile.ZipFile(TARGET,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for name,raw in sorted(files.items()):
  entry=zipfile.ZipInfo(name,(2000,1,1,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED;entry.external_attr=0o100644<<16
  archive.writestr(entry,raw)
with zipfile.ZipFile(TARGET) as archive:
 assert set(archive.namelist())==set(files)
 for name,raw in files.items():assert archive.read(name)==raw,name
result=dict(status='FROZEN_COMPLETE_ORIGINAL_R_GRID_REFERENCE_FIXTURE',file=str(TARGET),identity=identity(TARGET.read_bytes()),members=len(files),cases=31,binary_fields=341,original_C_stack_diagnostic_retained=True,new_family_implementation_credit=0)
(OUT/'COMPLETED.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
