from pathlib import Path
import hashlib,json,os,subprocess,time,traceback
BASE=Path('/mnt/d/projects/JLinAlg/build/literature-review/monocle-runtime');OUT=BASE/'velociraptor-native-grid-binary-1';PRIOR=BASE/'velociraptor-native-grid-reference-1';P=Path('/opt/omicsmatic-velociraptor120-r453-20261114-1');LIB=Path('/opt/omicsmatic-velociraptor120-system-20261114-2/R-library')
def pin(path):
 raw=path.read_bytes();return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
try:
 source=PRIOR/'COMPLETE-ORIGINAL-GRID-RESULTS.rds';before=pin(source)
 command=[str(P/'.pixi/envs/default/bin/Rscript'),'--vanilla',str(OUT/'Export.R'),str(LIB),str(source),str(OUT)]
 env=dict(os.environ,R_LIBS_USER=str(LIB),PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1');start=time.time()
 with (OUT/'process.stdout').open('xb') as so,(OUT/'process.stderr').open('xb') as se:child=subprocess.run(command,env=env,stdin=subprocess.DEVNULL,stdout=so,stderr=se)
 save('TERMINAL.json',dict(command=command,exit_code=child.returncode,elapsed_seconds=time.time()-start));assert child.returncode==0 and pin(source)==before
 index=json.loads((OUT/'INDEX.json').read_bytes());assert index['status']=='COMPLETE_ORIGINAL_GRID_BINARY_TRANSCRIPT' and index['case_count']==31
 files={row['path']:pin(OUT/row['path']) for case in index['cases'] for row in case['fields'].values()}
 save('BINARY-PAYLOADS.json',files)
 stderr=(PRIOR/'process.stderr').read_text();known=[line for line in stderr.splitlines() if 'stack imbalance' in line]
 save('ORIGINAL-DIAGNOSTICS-REVIEW.json',dict(status='ORIGINAL_REFERENCE_DIAGNOSTICS_REVIEW_REQUIRED',full_raw_console=str(PRIOR/'process.stderr'),raw_console_identity=pin(PRIOR/'process.stderr'),known_stack_imbalance_lines=known,raw_console_diagnostic_counts_complete=False,delivered_R_grid_warning_count=json.loads((PRIOR/'REFERENCE.json').read_bytes())['original_warnings'],delivered_count_scope='Handlers wrap the31 original grid calls only. They do not account for native C diagnostics, namespace startup, RDS/value-tree recording or every raw console message.',warning_review_required=True,cause_of_native_stack_diagnostic_unresolved=bool(known),earlier_original_proofs_rewritten=False))
 save('COMPLETED.json',dict(status='PASS_COMPLETE_UNCHANGED_ORIGINAL_GRID_BINARY_TRANSCRIPT_NO_JAVA_QUALIFICATION',cases=31,fields=len(files),source_RDS=before,original_values_unchanged=True,all_binary_payloads_retained=True,text_JSON_not_used_as_numeric_input_or_acceptance_reference=True,warning_review_required=True,new_tool_credit=0,whole_goal_complete=False));print('COMPLETE_ORIGINAL_GRID_BINARY_CASES',31,'fields',len(files),'known raw stack diagnostics',len(known),flush=True)
except BaseException as error:
 save('FAILURE.json',dict(status='FAIL2_ORIGINAL_GRID_BINARY_TRANSCRIPT_UNADMITTED',cause=repr(error),traceback=traceback.format_exc(),new_tool_credit=0));raise
