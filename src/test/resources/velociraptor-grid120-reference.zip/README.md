# Complete original velociraptor1.20.0 grid references

These31 original R4.5.3 gridVectors controls supply complete inputs and all
arithmetic intermediates. Binary payloads are row-major, little-endian int32 or
float64 as declared by binary/INDEX.json. They preserve original numeric bits;
the human-readable original-reference/REFERENCE.json is not the numeric source
for execution or acceptance. cases.tsv contains only names, dimensions and
explicit caller settings. No native Java output is a golden value.

All original results and R warning-condition objects are retained as RDS.
The source archive is the unchanged official Bioconductor3.22 velociraptor1.20.0
release; its eight R expression trees were compared with release Git commit
67b4a9ec4afba690f124e8d25015b9a02ca79e1a. The source census checks all11 original
installed function bodies and all three declared S4 generics/seven methods.
Native arithmetic needs no R/Python installation; regeneration of original
references requires permitted exact original prerequisites and new outputs.

WARNINGS: The R reference emitted a native stack-imbalance diagnostic whose
cause is unresolved. Read original-reference/process.stderr and
binary-export/ORIGINAL-DIAGNOSTICS-REVIEW.json. The zero delivered R warning
count in REFERENCE.json describes handlers around the31 grid calls only; it is
not a universal raw-console diagnostic count. All available consoles and
conditions remain retained. No original code was patched or warning removed.

The first binary exporter wrote available fields and refused its own opaque
serialization byte-identity assumption. Its code/error/console remain retained.
The successful exporter saves before/after serialization bytes and requires
strict complete R-value equality against a fresh original RDS read, including
numeric/NA/NaN bits and attribute order. Opaque RDS byte parity is not a claim.
All341 original binary fields are present in the successful transcript.

The native method covers finite two-dimensional coordinates/vectors with
nondegenerate finite axis ranges, positive integer resolution and nonoverflowing
group sums and scaled lengths. It preserves first-matching-cell group labels,
their gaps, input row order, terminal categories and computed NaN/infinity
classes when median-length scaling encounters zero. Unsupported native domains
refuse the complete calculation; use a qualified permitted original workflow
or skip dependent work. No row/value may be omitted or repaired silently.

These are method integration controls, not an RNA-velocity implementation,
author settings, biological validation, convergence or paper reproduction.
The separate R wrapper adapter remains unqualified and missing in the catalog;
this native component grants zero family implementation credit. The complete
250-paper objective remains active. SHA-256 provides integrity, not a signature.
