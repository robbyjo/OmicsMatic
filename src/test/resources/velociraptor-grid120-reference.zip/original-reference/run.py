from pathlib import Path
import hashlib,json,os,subprocess,time,traceback
ROOT=Path('/mnt/d/projects/JLinAlg');BASE=ROOT/'build/literature-review/monocle-runtime';OUT=BASE/'velociraptor-native-grid-reference-1';P=Path('/opt/omicsmatic-velociraptor120-r453-20261114-1');LIB=Path('/opt/omicsmatic-velociraptor120-system-20261114-2/R-library')
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
try:
 assert json.loads((BASE/'velociraptor-system-runtime-install-2/COMPLETED.json').read_bytes())['original_R_source_functions_verified']==11
 helper=ROOT/'tools/literature/velociraptor120/RValues.R';raw=helper.read_bytes();save('RECORDER-SOURCE.json',dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
 command=[str(P/'.pixi/envs/default/bin/Rscript'),'--vanilla',str(OUT/'Reference.R'),str(LIB),str(OUT),str(helper)]
 env=dict(os.environ,R_LIBS_USER=str(LIB),BASILISK_USE_SYSTEM_DIR='1',BASILISK_NO_DESTROY='1',BASILISK_NO_PYENV='1',PIP_NO_INDEX='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1');start=time.time()
 with (OUT/'process.stdout').open('xb') as so,(OUT/'process.stderr').open('xb') as se:child=subprocess.run(command,env=env,stdin=subprocess.DEVNULL,stdout=so,stderr=se)
 save('TERMINAL.json',dict(command=command,exit_code=child.returncode,elapsed_seconds=time.time()-start));assert child.returncode==0
 result=json.loads((OUT/'REFERENCE.json').read_bytes());assert result['status']=='COMPLETE_ORIGINAL_VELOCIRAPTOR120_GRID_REFERENCE' and not result['python_initialized']
 assert helper.read_bytes()==raw
 save('COMPLETED.json',dict(status='PASS_COMPLETE_ORIGINAL_R_GRID_REFERENCE_NO_JAVA_QUALIFICATION_YET',cases=result['case_count'],original_warnings=result['original_warnings'],R='4.5.3',all_original_results_conditions_retained=True,recorder_source_unchanged=True,new_tool_credit=0,whole_goal_complete=False));print('ORIGINAL_R_GRID_CASES',result['case_count'],'first groups',result['cases'][0]['reference']['groups'],flush=True)
except BaseException as error:
 save('FAILURE.json',dict(status='FAIL2_ORIGINAL_R_GRID_REFERENCE_UNADMITTED',cause=repr(error),traceback=traceback.format_exc(),new_tool_credit=0));raise
