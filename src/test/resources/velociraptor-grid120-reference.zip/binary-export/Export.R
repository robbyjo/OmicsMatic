args <- commandArgs(TRUE);lib <- args[[1L]];reference <- args[[2L]];out <- args[[3L]]
.libPaths(c(lib,.libPaths()))
loadNamespace("S4Vectors")
originals <- readRDS(reference);baseline <- readRDS(reference);before <- serialize(originals,NULL,version=3)
writeBin(before,file.path(out,"BEFORE-SERIALIZATION.bin"))
cases <- list()
for (i in seq_along(originals)) {
 entry <- originals[[i]];input <- entry$input;result <- entry$result
 directory <- sprintf("case-%04d",i);dir.create(file.path(out,directory))
 fields <- list(coordinates=input$coordinates,embedded=input$embedded,start=result$start,end=result$end,vectors=result$vec,limits=result$limits,delta=result$delta,categories=as.matrix(result$categories),groups=result$grp,group_labels=as.integer(rownames(result$start)),populations=as.integer(table(result$grp)))
 metadata <- list()
 for (name in names(fields)) {
  value <- fields[[name]];kind <- if(typeof(value)=="integer")"int32"else"float64"
  stopifnot(typeof(value) %in% c("integer","double"))
  shape <- if(is.null(dim(value)))c(length(value),1L)else dim(value)
  stopifnot(length(shape)==2L)
  payload <- if(is.null(dim(value)))unname(value)else as.vector(t(value))
  relative <- file.path(directory,paste0(name,".bin"));connection <- file(file.path(out,relative),open="wb")
  writeBin(payload,connection,size=if(kind=="int32")4L else 8L,endian="little");close(connection)
  metadata[[name]] <- list(path=relative,kind=kind,rows=as.integer(shape[[1L]]),columns=as.integer(shape[[2L]]),bytes=file.info(file.path(out,relative))$size)
 }
 cases[[i]] <- list(id=input$id,directory=directory,cells=nrow(input$coordinates),resolution=input$resolution,scale=input$scale,requires_nonfinite_review=any(!is.finite(result$vec))||any(!is.finite(result$end)),fields=metadata)
}
after <- serialize(originals,NULL,version=3)
writeBin(after,file.path(out,"AFTER-SERIALIZATION.bin"))
strict <- identical(baseline,originals,num.eq=FALSE,single.NA=FALSE,attrib.as.set=FALSE,ignore.bytecode=FALSE,ignore.environment=FALSE,ignore.srcref=FALSE,extptr.as.ref=TRUE)
saveRDS(list(strict_complete_R_values_unchanged=strict,serialized_representation_identical=identical(before,after),opaque_RDS_byte_equality_required=FALSE),file.path(out,"COMPLETE-VALUE-PRESERVATION.rds"))
if (!strict) {saveRDS(originals,file.path(out,"COMPLETE-AFTER-EXPORT.rds"));saveRDS(baseline,file.path(out,"COMPLETE-BEFORE-EXPORT.rds"))}
stopifnot(strict)
jsonlite::write_json(list(status="COMPLETE_ORIGINAL_GRID_BINARY_TRANSCRIPT",schema_version=1L,byte_order="little",matrix_order="row-major",cases=cases,case_count=length(cases),original_values_unchanged=TRUE,new_tool_credit=0L),file.path(out,"INDEX.json"),pretty=TRUE,auto_unbox=TRUE,null="null",na="string",digits=17)
cat("EXPORTED_COMPLETE_ORIGINAL_GRID_BINARY_TRANSCRIPT",length(cases))
