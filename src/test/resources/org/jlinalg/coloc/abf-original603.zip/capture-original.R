
args <- commandArgs(TRUE)
input <- args[1]; output <- args[2]; lib <- args[3]; deps <- args[4]; source <- args[5]
.libPaths(c(lib,deps,.libPaths()))
stopifnot(as.character(packageVersion("coloc"))=="6.0.3")
stopifnot(nzchar(Sys.setlocale("LC_CTYPE","English_United States.utf8")))
Sys.setlocale("LC_COLLATE","C")
original <- new.env(parent=globalenv())
sys.source(file.path(source,"R/claudia.R"),envir=original,keep.source=FALSE)
sys.source(file.path(source,"R/check.R"),envir=original,keep.source=FALSE)
for(n in c("coloc.abf","process.dataset","approx.bf.estimates","approx.bf.p","combine.abf","combine_abf_weighted","check_dataset"))
 stopifnot(identical(deparse(body(get(n,envir=asNamespace("coloc")))),deparse(body(get(n,envir=original)))))
writeLines(capture.output(sessionInfo()),file.path(output,"SESSION.txt"))
read <- function(p) read.delim(p,check.names=FALSE,stringsAsFactors=FALSE,encoding="UTF-8",comment.char="",quote="\"")
tab <- function(x,p) {
 for(n in names(x)) if(is.numeric(x[[n]])) x[[n]]<-sprintf("%.17g",x[[n]])
 write.table(x,p,sep="\t",row.names=FALSE,quote=TRUE,na="NA",fileEncoding="UTF-8")
}
cases <- read(file.path(input,"cases.tsv"))
for(name in cases$name) {
 cat("CASE ",name,"\n",sep=""); dest<-file.path(output,name);dir.create(dest)
 s<-read(file.path(input,name,"settings.tsv"));settings<-setNames(as.list(s$value),s$key)
 data<-lapply(1:2,function(t) {
  d<-read(file.path(input,name,paste0("trait",t,".tsv")))
  d$snp<-enc2utf8(as.character(d$snp)); result<-as.list(d[intersect(names(d),c("snp","beta","varbeta","pvalues","MAF","position"))])
  result$type<-settings[[paste0("type",t)]]
  for(k in c("N","sdY","s")) if(!is.null(settings[[paste0(k,t)]])) result[[k]]<-as.numeric(settings[[paste0(k,t)]])
  list(d=result,w=d$prior_weight)
 })
 warnings<-character();error<-NULL
 result<-tryCatch(withCallingHandlers({
  call<-list(dataset1=data[[1]]$d,dataset2=data[[2]]$d,prior_weights1=data[[1]]$w,prior_weights2=data[[2]]$w)
  for(k in c("p1","p2","p12")) if(!is.null(settings[[k]])) call[[k]]<-as.numeric(settings[[k]])
  if(identical(settings$effect_prior_override,"True")) call$effect_priors<-c(quant=.5,cc=.6)
  do.call(coloc::coloc.abf,call)
 },warning=function(w){warnings<<-c(warnings,conditionMessage(w));invokeRestart("muffleWarning")}),error=function(e){error<<-conditionMessage(e);NULL})
 writeLines(warnings,file.path(dest,"warnings.txt"))
 if(is.null(result)) {writeLines(c("ERROR",error),file.path(dest,"STATUS.txt"));next}
 saveRDS(result,file.path(dest,"original-result.rds"),version=3)
 tab(result$results,file.path(dest,"variants.tsv"))
 tab(data.frame(field=names(result$summary),value=as.numeric(result$summary)),file.path(dest,"summary.tsv"))
 tab(data.frame(field=names(result$priors),value=as.numeric(result$priors)),file.path(dest,"priors.tsv"))
 if(!is.null(result$weights)) {
  nonnull<-result$weights[!vapply(result$weights,is.null,logical(1))]
  tab(as.data.frame(nonnull),file.path(dest,"weights.tsv"))
 }
 finite<-all(is.finite(result$summary)) && all(is.finite(result$results$SNP.PP.H4))
 writeLines(if(finite) "FINITE" else "NONFINITE_NO_RESULT_ADMITTED",file.path(dest,"STATUS.txt"))
}
