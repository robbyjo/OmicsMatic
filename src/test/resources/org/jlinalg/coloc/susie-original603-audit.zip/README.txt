Synthetic original-package source audit, not blanket native parity.
Original coloc 6.0.3 commit 27776b1bb14e19d1542798ac7477fa378fc2fc0d; GPL.
26 supplied-BF cases plus two actual original runsusie/coloc.susie fit pairs.
Selected seven installed function bodies and formals matched exact source.
CAPTURE statuses describe finite fields only. The single-variant source output
is finite but NOT a normalized hypothesis distribution; it is retained, not
repaired or admitted as a scientific oracle. Nonfinite/no-posterior cases
also remain unadmitted. Legacy-comparison results describe the old candidate.
New tests explicitly distinguish source-matching profiles, documented stable
method variants and invalid/unsupported inputs. No independent native SuSiE
fit parity, whole-tool/historical-edition or original-paper claim.
