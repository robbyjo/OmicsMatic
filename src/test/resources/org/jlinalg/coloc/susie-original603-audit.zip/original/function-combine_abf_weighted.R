function (l1, l2, p1, p2, p12, prior_weights1, prior_weights2, 
    quiet = FALSE) 
{
    stopifnot(length(l1) == length(l2))
    Q <- length(l1)
    if (is.null(prior_weights1)) {
        p1_vec <- rep(p1, Q)
    }
    else {
        prior_weights1 <- prior_weights1/sum(prior_weights1)
        p1_vec <- Q * p1 * prior_weights1
    }
    if (is.null(prior_weights2)) {
        p2_vec <- rep(p2, Q)
    }
    else {
        prior_weights2 <- prior_weights2/sum(prior_weights2)
        p2_vec <- Q * p2 * prior_weights2
    }
    stopifnot(length(p1_vec) == length(p2_vec))
    stopifnot(length(p1_vec) == length(l1))
    p12_vec <- p1_vec * p2_vec * (p12/(p1 * p2))
    lsum <- l1 + l2
    lH0_abf <- 0
    lH1_abf <- logsum(log(p1_vec) + l1)
    lH2_abf <- logsum(log(p2_vec) + l2)
    lH3_abf <- logdiff(logsum(log(p1_vec) + l1) + logsum(log(p2_vec) + 
        l2), logsum(log(p1_vec) + log(p2_vec) + lsum))
    lH4_abf <- logsum(log(p12_vec) + lsum)
    all_abf <- c(lH0_abf, lH1_abf, lH2_abf, lH3_abf, lH4_abf)
    denom_log_abf <- logsum(all_abf)
    pp_abf <- exp(all_abf - denom_log_abf)
    names(pp_abf) <- paste0("PP.H", (1:length(pp_abf)) - 1, ".abf")
    if (!quiet) {
        print(signif(pp_abf, 3))
        print(paste("PP abf for shared variant: ", signif(pp_abf["PP.H4.abf"], 
            3) * 100, "%", sep = ""))
    }
    pp_abf
}
