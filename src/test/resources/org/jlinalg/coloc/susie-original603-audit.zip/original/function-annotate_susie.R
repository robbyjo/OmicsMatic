function (res, snp, LD) 
{
    colnames(res$lbf_variable) = c(snp, "null")[1:ncol(res$lbf_variable)]
    colnames(res$alpha) = c(snp, "null")[1:ncol(res$alpha)]
    names(res$pip) = snp
    if (length(res$sets$cs)) 
        res$sets$cs = lapply(res$sets$cs, function(x) {
            names(x) = snp[x]
            x
        })
    res$sld = .susie_setld(res$sets$cs, LD)
    res$pruned = FALSE
    res
}
