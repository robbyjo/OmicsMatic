function (bf1, bf2, p1 = 1e-04, p2 = 1e-04, p12 = 5e-06, overlap.min = 0.5, 
    trim_by_posterior = TRUE, prior_weights1 = NULL, prior_weights2 = NULL) 
{
    if ((length(p1) != 1 || length(p2) != 1 || length(p12) != 
        1) && (!is.null(prior_weights1) || !is.null(prior_weights2))) {
        stop("Prior weights can only be used with single values of the prior parameters.")
    }
    if (!is.null(prior_weights1) && any(is.na(prior_weights1) | 
        (prior_weights1 <= 0))) {
        stop("prior_weights1 must contain non-NA/non-negative weights.")
    }
    if (!is.null(prior_weights2) && any(is.na(prior_weights2) | 
        (prior_weights2 <= 0))) {
        stop("prior_weights2 must contain non-NA/non-negative weights.")
    }
    if (is.vector(bf1)) 
        bf1 = matrix(bf1, nrow = 1, dimnames = list(NULL, names(bf1)))
    if (is.vector(bf2)) 
        bf2 = matrix(bf2, nrow = 1, dimnames = list(NULL, names(bf2)))
    if (!is.null(prior_weights1) && ncol(bf1) != length(prior_weights1)) {
        stop("Length of prior_weights1 must match size of dataset 1")
    }
    if (!is.null(prior_weights2) && ncol(bf2) != length(prior_weights2)) {
        stop("Length of prior_weights2 must match size of dataset 2")
    }
    todo <- as.data.table(expand.grid(i = 1:nrow(bf1), j = 1:nrow(bf2)))
    todo[, `:=`(pp4, 0)]
    isnps = setdiff(intersect(colnames(bf1), colnames(bf2)), 
        "null")
    if (!length(isnps)) 
        return(data.table(nsnps = NA))
    nulllast <- function(m) m[, c(setdiff(colnames(m), "null"), 
        "null"), drop = FALSE]
    if ("null" %in% colnames(bf1)) 
        bf1 = nulllast(bf1) - matrix(bf1[, "null"], nrow(bf1), 
            ncol(bf1))
    if ("null" %in% colnames(bf2)) 
        bf2 = nulllast(bf2) - matrix(bf2[, "null"], nrow(bf2), 
            ncol(bf2))
    pp1 = logbf_to_pp(bf1, p1, last_is_null = "null" %in% colnames(bf1))
    pp2 = logbf_to_pp(bf2, p2, last_is_null = "null" %in% colnames(bf2))
    ph0.1 = if ("null" %in% colnames(pp1)) {
        pp1[, "null"]
    }
    else {
        1 - rowSums(pp1)
    }
    ph0.2 = if ("null" %in% colnames(pp2)) {
        pp2[, "null"]
    }
    else {
        1 - rowSums(pp2)
    }
    prop1 = rowSums(pp1[, c(isnps), drop = FALSE])/rowSums(pp1[, 
        setdiff(colnames(pp1), "null"), drop = FALSE])
    prop2 = rowSums(pp2[, c(isnps), drop = FALSE])/rowSums(pp2[, 
        setdiff(colnames(pp2), "null"), drop = FALSE])
    if (trim_by_posterior == TRUE) {
        drop = sapply(1:nrow(todo), function(k) {
            prop1[todo$i[k]] < overlap.min | prop2[todo$j[k]] < 
                overlap.min
        })
        if (all(drop)) {
            warning("snp overlap too small between datasets: too few snps with high posterior in one trait represented in other")
            return(list(summary = cbind(data.table(nsnps = length(isnps), 
                hit1 = colnames(pp1)[apply(pp1, 1, which.max)][todo$i], 
                hit2 = colnames(pp2)[apply(pp2, 1, which.max)][todo$j], 
                PP.H0.abf = pmin(ph0.1[todo$i], ph0.2[todo$j]), 
                PP.H1.abf = NA, PP.H2.abf = NA, PP.H3.abf = NA, 
                PP.H4.abf = NA), todo[, .(idx1 = i, idx2 = j)])))
        }
        if (any(drop)) 
            todo = todo[!drop, , drop = FALSE]
    }
    if (length(p12) > 1) {
        if (length(isnps) != ncol(bf1) || length(isnps) != ncol(bf2)) 
            stop("p12 must have length 1 or equal length to p1 and p2, but different numbers of snps between datasets")
    }
    if (!identical(colnames(bf1), isnps)) {
        keep = match(isnps, colnames(bf1))
        prior_weights1 <- prior_weights1[keep]
        bf1 = bf1[, keep, drop = FALSE]
        if (length(p1) > 1) 
            p1 = p1[keep]
    }
    if (!identical(colnames(bf2), isnps)) {
        keep = match(isnps, colnames(bf2))
        prior_weights2 <- prior_weights2[keep]
        bf2 = bf2[, keep, drop = FALSE]
        if (length(p2) > 1) 
            p2 = p2[keep]
    }
    if (length(p12) == 1) {
        if (length(p1) > 1 || length(p2) > 1) {
            p1_at_dist = min(p1)
            p2_at_dist = min(p2)
            c12 = p12/p1_at_dist/p2_at_dist
            p12 = p1 * p2 * c12
        }
    }
    results <- PP <- vector("list", nrow(todo))
    for (k in 1:nrow(todo)) {
        df <- data.frame(snp = isnps, bf1 = bf1[todo$i[k], isnps], 
            bf2 = bf2[todo$j[k], isnps])
        df$internal.sum.lABF <- with(df, bf1 + bf2)
        my.denom.log.abf <- logsum(df$internal.sum.lABF)
        df$SNP.PP.H4 <- exp(df$internal.sum.lABF - my.denom.log.abf)
        if (!is.null(prior_weights1) || !is.null(prior_weights2)) {
            pp.abf <- combine_abf_weighted(df$bf1, df$bf2, p1, 
                p2, p12, prior_weights1, prior_weights2, quiet = TRUE)
        }
        else {
            pp.abf <- combine.abf(df$bf1, df$bf2, p1, p2, p12, 
                quiet = TRUE)
        }
        PP[[k]] = df$SNP.PP.H4
        if (all(is.na(df$SNP.PP.H4))) {
            df$SNP.PP.H4 = 0
            pp.abf[1:5] = c(1, 0, 0, 0, 0)
        }
        common.snps <- nrow(df)
        hit1 = names(which.max(bf1[todo$i[k], ]))
        if (is.null(hit1)) {
            hit1 = "-"
            pp.abf[c(1, 3)] = c(0, 1)
        }
        hit2 = names(which.max(bf2[todo$j[k], ]))
        if (is.null(hit2)) {
            hit2 = "-"
            pp.abf[c(1, 2)] = c(0, 1)
        }
        results[[k]] = do.call("data.frame", c(list(nsnps = common.snps, 
            hit1 = hit1, hit2 = hit2), as.list(pp.abf)))
    }
    results <- as.data.table(do.call("rbind", results))
    PP <- as.data.table(do.call("cbind", PP))
    if (nrow(todo) > 1) 
        colnames(PP) = paste0("SNP.PP.H4.row", 1:nrow(todo))
    else colnames(PP) = "SNP.PP.H4.abf"
    results = cbind(results, todo[, .(idx1 = i, idx2 = j)])
    PP = cbind(data.table(snp = isnps), PP)
    list(summary = results, results = PP, priors = if (length(p1) == 
        1 && length(p2) == 1 && length(p12) == 1) {
        c(p1 = p1, p2 = p2, p12 = p12)
    } else {
        list(p1 = p1, p2 = p2, p12 = p12)
    })
}
