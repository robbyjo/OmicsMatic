function (dataset1, dataset2, back_calculate_lbf = FALSE, susie.args = list(), 
    ...) 
{
    if ("susie" %in% class(dataset1)) 
        s1 = dataset1
    else s1 = do.call("runsusie", c(list(d = dataset1, suffix = 1), 
        susie.args))
    if ("susie" %in% class(dataset2)) 
        s2 = dataset2
    else s2 = do.call("runsusie", c(list(d = dataset2, suffix = 2), 
        susie.args))
    cs1 = s1$sets
    cs2 = s2$sets
    if (is.null(cs1$cs) || is.null(cs2$cs) || length(cs1$cs) == 
        0 || length(cs2$cs) == 0) {
        warning("at least one dataset has no credible sets, nothing to colocalise")
        return(data.table(nsnps = NA))
    }
    idx1 = cs1$cs_index
    idx2 = cs2$cs_index
    bf1 = s1$lbf_variable[idx1, , drop = FALSE]
    bf2 = s2$lbf_variable[idx2, , drop = FALSE]
    ret = coloc.bf_bf(bf1, bf2, ...)
    ret$summary[, `:=`(idx1, cs1$cs_index[idx1])]
    ret$summary[, `:=`(idx2, cs2$cs_index[idx2])]
    ret
}
