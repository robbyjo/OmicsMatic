function (bf, pi, last_is_null) 
{
    n = if (last_is_null) {
        ncol(bf) - 1
    }
    else {
        n = ncol(bf)
    }
    if (length(pi) == 1) {
        if (pi > 1/n) 
            pi = 1/n
        pi = if (last_is_null) {
            c(rep(pi, n), 1 - n * pi)
        }
        else {
            rep(pi, n)
        }
    }
    if (any(pi == 0)) {
        pi[pi == 0] = 1e-16
        pi = pi/sum(pi)
    }
    if (last_is_null) {
        bf = bf - bf[, ncol(bf)]
    }
    priors = matrix(log(pi), nrow(bf), ncol(bf), byrow = TRUE)
    denom = matrix(apply(bf + priors, 1, logsum), nrow(bf), ncol(bf))
    exp(bf + priors - denom)
}
