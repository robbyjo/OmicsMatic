function (l1, l2, p1, p2, p12, quiet = FALSE) 
{
    stopifnot(length(l1) == length(l2))
    lsum <- l1 + l2
    lH0.abf <- 0
    lH1.abf <- log(p1) + logsum(l1)
    lH2.abf <- log(p2) + logsum(l2)
    lH3.abf <- log(p1) + log(p2) + logdiff(logsum(l1) + logsum(l2), 
        logsum(lsum))
    lH4.abf <- log(p12) + logsum(lsum)
    all.abf <- c(lH0.abf, lH1.abf, lH2.abf, lH3.abf, lH4.abf)
    my.denom.log.abf <- logsum(all.abf)
    pp.abf <- exp(all.abf - my.denom.log.abf)
    names(pp.abf) <- paste("PP.H", (1:length(pp.abf)) - 1, ".abf", 
        sep = "")
    if (!quiet) {
        print(signif(pp.abf, 3))
        print(paste("PP abf for shared variant: ", signif(pp.abf["PP.H4.abf"], 
            3) * 100, "%", sep = ""))
    }
    return(pp.abf)
}
