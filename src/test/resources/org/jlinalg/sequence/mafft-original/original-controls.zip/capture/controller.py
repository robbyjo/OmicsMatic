from pathlib import Path
import hashlib,json,os,shutil,sys
R=Path('/mnt/d/projects/JLinAlg');B=R/'build/literature-review/mafft-runtime';O=B/'original-controls-1';O.mkdir(exist_ok=False)
ROOT=Path('/opt/omicsmatic-mafft-dev-1');WORK=ROOT/'original-controls-1';WORK.mkdir(mode=0o700,exist_ok=False)
sys.path.insert(0,str(R/'tools/literature'));from install_iqtree import owned_run,limited
pins=json.loads((B/'portable-native-setup-1/observed.json').read_bytes());records=[]
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def fasta(sequences):return ''.join('>'+name+'\n'+value+'\n' for name,value in sequences.items())
dna={'T000000001':'ACGTCAGTCCGATGCA','T000000002':'ACGTCAGTTCCGATGCA','T000000003':'ACGTCAGTCCGAGCA'}
aa={'T000000001':'ACDEFGHIKLMNPQRSTVWY','T000000002':'ACDEFGHIKLLMNPQRSTVWY','T000000003':'ACDEFGHIKLNPQRSTVWY'}
backbone={'T000000001':'ACCDEFGHI-K','T000000002':'A--DEFGHI-K'};added={'T000000003':'ACCDPQRSTEFG'}
cases=[
 ('version',[],None,None),
 ('DNA-auto',['--nuc','--auto'],dna,None),
 ('DNA-global-100',['--nuc','--globalpair','--maxiterate','100'],dna,None),
 ('AA-local-1000',['--amino','--localpair','--maxiterate','1000'],aa,None),
 ('AA-add',['--amino','--auto','--add','added.fasta'],backbone,added),
 ('AA-add-keep-map',['--amino','--auto','--add','added.fasta','--keeplength','--mapout'],backbone,added),
 ('DNA-alphabet',['--nuc','--auto'],{'T000000001':'aCgTuRYSWKMBDHVNX','T000000002':'ACGTTGCAACGTACGTA','T000000003':'ACGTTGCNACGTACGTA'},None),
 ('AA-alphabet',['--amino','--auto'],{'T000000001':'ACDEFGHIKLMNPQRSTVWYBJZXUO*','T000000002':'ACDEFGHIKLMNPQRSTVWYAAAAGGC','T000000003':'ACDEFGHIKLMNPQRSTVWYAAAAGGG'},None),
 ('AA-alphabet-any',['--amino','--anysymbol','--auto'],{'T000000001':'ACDEFGHIKLMNPQRSTVWYBJZXUO*?','T000000002':'ACDEFGHIKLMNPQRSTVWYAAAAGGCA','T000000003':'ACDEFGHIKLMNPQRSTVWYAAAAGGGT'},None),
 ('DNA-gapped',['--nuc','--auto'],{'T000000001':'--ACGTCAGT--CCGATGCA-','T000000002':'ACGTCA---GTTCCGATGCA','T000000003':'ACGTCAGTCCGAGCA'},None)]
for pin in pins:
    version=pin['version'];home=Path(pin['home']);version_dir=WORK/version;version_dir.mkdir(mode=0o700)
    for relative,wanted in pin['files'].items():assert sha((home/relative).read_bytes())==wanted['sha256']
    for name,arguments,sequences,add in cases:
        directory=version_dir/name;directory.mkdir(mode=0o700)
        if sequences is not None:(directory/'input.fasta').write_text(fasta(sequences))
        if add is not None:(directory/'added.fasta').write_text(fasta(add))
        options=['--version'] if name=='version' else ['--thread','1','--inputorder',*arguments,'input.fasta']
        command=limited(['/usr/bin/env','MAFFT_TMPDIR='+str(directory),'/bin/bash',str(home/'mafft.bat'),*options])
        error=None;receipt=None
        (O/'running.json').write_text(json.dumps(dict(status='running',controller_pid=os.getpid(),case=version+'/'+name,command=command),indent=2)+'\n')
        try:receipt=owned_run(command,directory,wall_seconds=45,maximum_bytes=16777216)
        except Exception as failure:error=repr(failure)
        process=json.loads((directory/'process.json').read_bytes());assert process['owned_live_after_cleanup']==[]
        files={p.relative_to(directory).as_posix():dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in directory.rglob('*') if p.is_file()}
        record=dict(version=version,name=name,command=command,input=sequences,added=add,exit_code=process['exit_code'],error=error,owned_live_after_cleanup=[],files=files)
        records.append(record);(O/'observed.json').write_text(json.dumps(records,indent=2)+'\n')
        print(version,name,'exit',process['exit_code'],'error',error,flush=True)
    for relative,wanted in pin['files'].items():assert sha((home/relative).read_bytes())==wanted['sha256']
shutil.copytree(WORK,O/'linux');shutil.copyfile(__file__,O/'controller.py')
(O/'running.json').write_text(json.dumps(dict(status='terminal',protocols=len(records),all_owned_groups_terminal=True),indent=2)+'\n')
print('All original control groups terminal; no user scientific analysis is admitted.',flush=True)
