#include <cstdio>
#include <cstdlib>
#include <cfenv>
#include <iostream>
#include <string>
int main(){if(std::fesetround(FE_TONEAREST)!=0)return 5;
std::string id,coverage,frag,covsum;
while(std::cin>>id>>coverage>>frag>>covsum){
double Frag_Len=std::strtod(frag.c_str(),nullptr),Cov_Sum=std::strtod(covsum.c_str(),nullptr);
int istr=0,nl=0,tlen=0,t_id=0;
float tcov=0,calc_fpkm=0,calc_tpm=0;
std::string row="1 1 1 1 "+coverage;const char* linebuf=row.c_str();
			sscanf(linebuf,"%d %d %d %d %g", &istr, &nl, &tlen, &t_id, &tcov);
			calc_fpkm=tcov*1000000000/Frag_Len;
			calc_tpm=tcov*1000000/Cov_Sum;
			/*
		 	 double eff_len=1;
		 	 if((float)tlen>AvgFrag) eff_len=tlen-AvgFrag+1;
		 	 calc_fpkm2=calc_fpkm*tlen/eff_len;
			 */
			//fprintf(stderr,"istr=%d tid=%d tlen=%d tcov=%g calc_fpkm=%g calc_tpkm=%g\n",istr,t_id,tlen,tcov,calc_fpkm,calc_tpm);
			
std::printf("%s\t%a\t%a\t%a\t%.6f\t%.6f\t%.6f\n",id.c_str(),double(tcov),double(calc_fpkm),double(calc_tpm),double(tcov),double(calc_fpkm),double(calc_tpm));
}return std::cin.eof()?0:6;}
