args<-commandArgs(TRUE);.libPaths(c(readLines(args[[1]],encoding="UTF-8"),.Library),include.site=FALSE);library(Matrix);library(chromVAR);library(jsonlite);p<-fromJSON(args[[2]])
stopifnot(as.character(packageVersion("chromVAR"))=="1.34.1",as.character(packageVersion("Matrix"))=="1.7.5")
number<-function(v){if(is.na(v))return(if(is.nan(v))"NaN" else "NA");if(is.infinite(v))return(if(v>0)"Inf" else "-Inf");trimws(formatC(v,format="g",digits=17,decimal.mark="."))}
finish<-function(v){if(inherits(v,"Matrix")){m<-as.matrix(v);return(list(dim=dim(m),rows=lapply(seq_len(nrow(m)),function(i)vapply(m[i,,drop=FALSE],number,character(1)))))};if(is.list(v))return(lapply(v,finish));v}
results<-readRDS(p$partial);stopifnot(length(results)==52L);results<-finish(results)
write_json(list(profiles=read_json(p$profiles,simplifyVector=FALSE)$records,results=results,dependencies=list(chromVAR="1.34.1",Matrix="1.7.5",historical_whole_packages_executed=FALSE,background_sampling_performed=FALSE)),p$target,digits=17,pretty=TRUE,auto_unbox=FALSE,na="string")
writeLines(capture.output(sessionInfo()),file.path(dirname(p$target),"serialization-sessionInfo.txt"),useBytes=TRUE)
