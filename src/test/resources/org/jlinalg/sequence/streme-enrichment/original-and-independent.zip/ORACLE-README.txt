Independent Python math.comb and fractions.Fraction enumeration, not the Java recurrence.
Complete small-table population grid plus seeded uneven larger tables, degenerate margins,
near-one tails and binary64 underflow. These are mathematical tables, not biological data.
Original XML retains complete source output, paths and printed precision. The historically named
streme-no-motifs case actually reports ONE motif above the stringent threshold; it is not an empty-result fixture.
The binomial and central-distance files are unsupported Fisher controls, not Fisher fits.
