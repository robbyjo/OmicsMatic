Complete original XML and independently checked literal FASTA/WEIGHTS/background inputs.
EXPECTED.json uses independent complete-word half-polynomial enumeration with integer masses,
not the Java sequential floating-point convolution. Original site/diagram probabilities agree
at printed precision, and every PWM and prior score is independently reconstructed.
Source pipeline metadata warnings remain unresolved; only their MEME subrun is audited here.
No EM fit, motif-significance derivation, complete report admission, biological validity or execution authenticity is claimed.
