args<-commandArgs(TRUE);.libPaths(c(readLines(args[[1]],encoding="UTF-8"),.Library),include.site=FALSE)
stopifnot(as.character(packageVersion("TFBSTools"))=="1.50.0");library(jsonlite)
f<-get("PFMatrix",asNamespace("TFBSTools"));writeLines(deparse(f,width.cutoff=500L),"PFMatrix-original-function.R",useBytes=TRUE)
m<-matrix(c(9,1,0,0,0,7,3,0),4,dimnames=list(c("A","C","G","T"),NULL));bg<-c(A=.1,C=.2,G=.3,T=.4)
cases<-list(integer=m,fractional=m+.25,fractional_under_one=m*0+.5,zero_column=m,maximum_integer=m,integer_overflow=m,large_count=m,negative=m,zero_matrix=m*0,reordered=m[c("T","G","C","A"),,drop=FALSE])
cases$zero_column[,2]<-0;cases$maximum_integer[1,1]<-.Machine$integer.max;cases$integer_overflow[1,1]<-2147483648;cases$large_count[1,1]<-1e12;cases$negative[1,1]<--.5
results<-lapply(names(cases),function(id){declared<-cases[[id]];w<-character();value<-tryCatch(withCallingHandlers({pf<-TFBSTools::PFMatrix(ID="M",name="factor",profileMatrix=declared,bg=bg);list(effective=unname(methods::slot(pf,"profileMatrix")),background=unname(methods::slot(pf,"bg")),storage=typeof(methods::slot(pf,"profileMatrix")),valid=methods::validObject(pf))},warning=function(x){w<<-c(w,conditionMessage(x));invokeRestart("muffleWarning")}),error=function(x)list(error=conditionMessage(x)));list(id=id,declared=unname(declared),warnings=w,value=value)})
write_json(list(TFBSTools="1.50.0",results=results),"original.json",digits=17,pretty=TRUE,auto_unbox=TRUE,na="null");writeLines(capture.output(sessionInfo()),"sessionInfo.txt",useBytes=TRUE)
