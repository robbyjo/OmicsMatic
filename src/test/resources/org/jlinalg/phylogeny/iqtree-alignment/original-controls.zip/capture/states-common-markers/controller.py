from pathlib import Path
import hashlib,json,math,os,signal,subprocess,time,shutil

ROOT=Path('/mnt/d/projects/JLinAlg');BASE=ROOT/'build/literature-review/iqtree-runtime'
OUT=BASE/'alignment-original-controls-2';OUT.mkdir(exist_ok=False)
WORK=Path('/opt/omicsmatic-iqtree-dev-1/alignment-original-controls-2');WORK.mkdir(exist_ok=False)
PROFILES=json.loads((BASE/'original-profile-inspection-1/observed.json').read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def group_members(group):
    result=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:
            text=(p/'stat').read_text();fields=text[text.rfind(')')+2:].split()
            if int(fields[2])==group and fields[0]!='Z':result.append(int(p.name))
        except (OSError,ValueError):pass
    return sorted(result)
def repeated(text,n):return (text*((n+len(text)-1)//len(text)))[:n]
dna='ACGTURYSWKMBDHVNX?-~.!acgt'
aa='ACDEFGHIKLMNPQRSTVWYBXZJ*UO?-~.!acde'
cases=[dict(name='DNA-aliases',kind='DNA',model='JC',expected=0,sequences=dict(A=dna,B=repeated('ACGT',len(dna)),C=repeated('TCGA',len(dna)),D=repeated('CCGT',len(dna)))),
       dict(name='AA-aliases',kind='AA',model='Poisson',expected=0,sequences=dict(A=aa,B=repeated('ACDEFGHIKLMNPQRSTVWY',len(aa)),C=repeated('EDCAKIHGFVYWTSRQPNML',len(aa)),D=repeated('MNPQRSTVWYACDEFGHIKL',len(aa)))),
       dict(name='CODON-ambiguities',kind='CODON',model='MG+F1X4',expected=0,sequences=dict(A='ATGGCCTTTAAACCCGGGAARNTN---NNN...!!!',B='ATGGCTTTCAAGCCCGGATTTAAAGCTNNN...!!!',C='ATAGCCTTTAAGCCAGGGTTTAAAGCCNNN...!!!',D='ATGGCTTTCAAGCCAGGATTTAAAGCANN N...!!!'.replace(' ','')))]
for name,kind,char in [('DNA-O','DNA','O'),('DNA-star','DNA','*'),('AA-digit','AA','0')]:
    values=dict(A='ACGTACGTACGT',B='ACGTACGTACGA',C='TCGTCCGTTCGT',D='TCGTCCGTACGT');values['A']=char+values['A'][1:]
    cases.append(dict(name=name,kind=kind,model='JC' if kind=='DNA' else 'Poisson',expected=2,sequences=values))
cases.append(dict(name='CODON-stop',kind='CODON',model='MG+F1X4',expected=2,sequences=dict(A='ATGTAATTTAAA',B='ATGGCTTTCAAG',C='ATAGCCTTTAAG',D='ATGGCTTTCAAG')))
tree='((A:.1,B:.2):.3,C:.4,D:.5);\n'
cases=[case for case in cases if case['expected']==0]
for case in cases:case['sequences']={name:seq.replace('!','?') for name,seq in case['sequences'].items()}
records=[]
for profile in PROFILES:
    program=Path(profile['program']);before=sha(program);assert before==profile['program_sha256']
    for case in cases:
        name=profile['version']+'-'+case['name'];directory=WORK/name;directory.mkdir()
        fasta=''.join('>'+taxon+'\n'+sequence+'\n' for taxon,sequence in case['sequences'].items())
        (directory/'alignment.fasta').write_text(fasta);(directory/'fixed.nwk').write_text(tree)
        command=['/usr/bin/prlimit','--as=4294967296','--cpu=20','--fsize=8388608','--core=0','--',str(program),'-s',str(directory/'alignment.fasta'),'-st',case['kind'],'-m',case['model'],'-te',str(directory/'fixed.nwk'),'-blfix','-wsl','-seed','1729','-nt','1','-pre',str(directory/'result')]
        start=time.monotonic();reason=None
        with (directory/'stdout').open('xb') as stdout,(directory/'stderr').open('xb') as stderr:
            child=subprocess.Popen(command,cwd=directory,env=dict(PATH='/usr/bin:/bin',HOME=str(directory),LANG='C',LC_ALL='C',OMP_NUM_THREADS='1'),stdout=stdout,stderr=stderr,start_new_session=True)
            (OUT/'running.json').write_text(json.dumps(dict(status='running',controller_pid=os.getpid(),child_pid=child.pid,case=name,command=command),indent=2)+'\n')
            try:
                while os.waitid(os.P_PID,child.pid,os.WEXITED|os.WNOHANG|os.WNOWAIT) is None:
                    if time.monotonic()-start>30:reason='wall-timeout';break
                    time.sleep(.02)
            finally:
                # waitid leaves the leader unreaped until owned-group cleanup is finished.
                live=group_members(child.pid)
                if live:
                    os.killpg(child.pid,signal.SIGKILL)
                code=child.wait(timeout=10)
            after=group_members(child.pid);assert after==[],after
        record=dict(name=name,profile=profile['version'],case=case,exit_code=code,expected_exit_code=case['expected'],timeout=reason,seconds=time.monotonic()-start,command=command,owned_live_after_cleanup=after,program_sha256=before,files={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in directory.iterdir() if p.is_file()})
        records.append(record);(OUT/'observed.json').write_text(json.dumps(records,indent=2)+'\n');print(name,code,'expected',case['expected'],flush=True)
        if code:print((directory/'stderr').read_text(errors='replace')[-450:],flush=True)
    assert sha(program)==before
shutil.copytree(WORK,OUT/'linux')
(OUT/'running.json').write_text(json.dumps(dict(status='terminal',controller_pid=os.getpid(),protocols=len(records),work=str(WORK),all_expected=all(r['exit_code']==r['expected_exit_code'] and not r['timeout'] for r in records)),indent=2)+'\n')
print('Terminal original probes:',len(records),flush=True)

