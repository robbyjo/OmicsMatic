package org.jlinalg.cli;

import java.nio.file.*;
import java.util.*;
import org.jlinalg.phylogeny.*;

/** Retained original-output inspection, not a public scientific completion gate. */
public final class IqtreeSupportProbe {
    private IqtreeSupportProbe() { }
    public static void main(String[] args)throws Exception {
        Path work=Path.of(args[0]),observations=Path.of(args[1]),destination=Path.of(args[2]);
        Object parsed=SimpleJson.parse(Files.readString(observations));if(!(parsed instanceof List<?> protocols))throw new AssertionError("Missing protocol list");
        var records=new ArrayList<Map<String,Object>>();long comparisons=0,replicates=0,mismatches=0;
        for(Object item:protocols) {
            Map<?,?> protocol=(Map<?,?>)item;String name=(String)protocol.get("name"),role=(String)protocol.get("case");
            if(((Number)protocol.get("exit_code")).intValue()!=0 || !(role.contains("UFB")||role.startsWith("DNA-standard-")))continue;
            Path directory=work.resolve(name);Map<?,?> files=(Map<?,?>)protocol.get("files");var before=new TreeMap<String,IqtreeFiles.Identity>();
            for(var entry:files.entrySet()) {
                String relative=(String)entry.getKey();Map<?,?> expected=(Map<?,?>)entry.getValue();
                Path path=directory.resolve(relative);if(!path.normalize().startsWith(directory))throw new AssertionError("Unsafe capture path");
                var identity=IqtreeFiles.identity(path,67108864,()->{});
                if(identity.bytes()!=((Number)expected.get("bytes")).longValue()||!identity.sha256().equals(expected.get("sha256")))throw new AssertionError("Capture changed: "+path);
                before.put(relative,identity);
            }
            var alignment=PhylogeneticAlignment.readFasta(directory.resolve("alignment.fasta"),PhylogeneticAlignment.Kind.DNA,PhylogeneticAlignment.HeaderPolicy.WHOLE_HEADER,PhylogeneticAlignment.Limits.defaults());
            long expected=role.equals("DNA-standard-100")?100:1000;
            String suffix=role.contains("UFB")?"ufboot":"boottrees";
            BootstrapSupport.Counts counts=BootstrapSupport.count(Files.newBufferedReader(directory.resolve("result."+suffix)),alignment.sequences().keySet(),expected,true,BootstrapSupport.Limits.defaults());
            replicates+=expected;var trees=new ArrayList<Map<String,Object>>();
            for(String kind:List.of("treefile","contree")) {
                var tree=NewickTree.parse(Files.readString(directory.resolve("result."+kind)));tree.requireMetricLengths();
                int columns=kind.equals("treefile")&&role.equals("DNA-UFB-SHaLRT-BNNI")?2:1;
                var values=BootstrapSupport.compare(tree,counts,columns,columns-1,1000000);var edges=new ArrayList<Map<String,Object>>();
                for(var value:values) {
                    comparisons++;if(!value.agreesAtPrintedPrecision())mismatches++;
                    edges.add(Map.of("child",value.childNode(),"split",new TreeSet<>(value.split()),"source_columns",value.reportedColumns(),
                        "occurrences",value.occurrences(),"replicates",value.replicates(),"percentage",value.percentage(),"agrees_at_printed_precision",value.agreesAtPrintedPrecision()));
                }
                trees.add(Map.of("source_file","result."+kind,"edges",edges));
            }
            for(var entry:before.entrySet())if(!entry.getValue().equals(IqtreeFiles.identity(directory.resolve(entry.getKey()),67108864,()->{})))throw new AssertionError("Capture changed during audit");
            records.add(Map.of("name",name,"expected_replicates",expected,"all_trees_and_taxa_read",true,"distinct_splits",counts.splits().size(),"trees",trees,"source_files",before));
            System.out.println(name+" complete trees="+expected+" support mismatches so far="+mismatches);
        }
        Files.writeString(destination,IqtreeJson.json(Map.of("status","completed-native-bootstrap-count-inspection","protocols",records,
                "replicates",replicates,"edge_comparisons",comparisons,"frequency_mismatches",mismatches,"scientific_analysis_admitted",false))+"\n",StandardOpenOption.CREATE_NEW);
        System.out.println("PROTOCOLS "+records.size()+" REPLICATES "+replicates+" EDGES "+comparisons+" MISMATCHES "+mismatches);
    }
}
