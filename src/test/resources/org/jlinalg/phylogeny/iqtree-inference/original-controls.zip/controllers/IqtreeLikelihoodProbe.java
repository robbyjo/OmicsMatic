package org.jlinalg.cli;
import java.nio.file.*;
import java.math.BigDecimal;
import java.util.*;
import java.util.regex.*;
import org.jlinalg.phylogeny.*;
public final class IqtreeLikelihoodProbe {
    private IqtreeLikelihoodProbe() { }
    public static void main(String[] args)throws Exception {
        Path root=Path.of(args[0]);List<?> protocols=(List<?>)SimpleJson.parse(Files.readString(Path.of(args[1])));
        var records=new ArrayList<Map<String,Object>>();long sites=0,nativeMismatches=0;
        for(Object item:protocols) {
            Map<?,?> p=(Map<?,?>)item;
            if(((Number)p.get("exit_code")).intValue()!=0)continue;
            Path directory=root.resolve((String)p.get("name"));String report=Files.readString(directory.resolve("result.iqtree"));
            Matcher total=Pattern.compile("(?m)^Log-likelihood of the tree: ([^ ]+) ").matcher(report);if(!total.find())throw new AssertionError("No complete final log likelihood");String printed=total.group(1);if(total.find())throw new AssertionError("Duplicate final likelihood");
            var data=List.of(Files.readString(directory.resolve("result.sitelh")).trim().split("\\s+"));
            if(!data.get(0).equals("1"))throw new AssertionError("Unexpected number of site rows");int n=Integer.parseInt(data.get(1));
            if(data.size()!=n+3||!data.get(2).equals("Site_Lh"))throw new AssertionError("Incomplete/extra site likelihood cells");
            BigDecimal sum=BigDecimal.ZERO,uncertainty=BigDecimal.ZERO;
            for(String token:data.subList(3,data.size())) {
                var decimal=new BigDecimal(token);if(Math.abs((long)decimal.scale())>18||!Double.isFinite(decimal.doubleValue()))throw new AssertionError("Invalid source site likelihood");
                sum=sum.add(decimal);uncertainty=uncertainty.add(decimal.ulp().abs().divide(BigDecimal.valueOf(2)));
            }
            var reported=new BigDecimal(printed);uncertainty=uncertainty.add(reported.ulp().abs().divide(BigDecimal.valueOf(2)));
            boolean sumAgrees=sum.subtract(reported).abs().compareTo(uncertainty)<=0;if(!sumAgrees)throw new AssertionError("Site/total printed intervals do not overlap: "+p.get("name"));
            var record=new LinkedHashMap<String,Object>();record.put("name",p.get("name"));record.put("model",p.get("model"));record.put("sites",n);record.put("source_total",printed);record.put("site_sum_decimal",sum.toPlainString());record.put("combined_printed_rounding_interval",uncertainty.toPlainString());record.put("site_total_intervals_overlap",sumAgrees);
            if(report.contains("\nModel of substitution: JC\n")) {
                var alignment=PhylogeneticAlignment.readFasta(directory.resolve("alignment.fasta"),PhylogeneticAlignment.Kind.DNA,PhylogeneticAlignment.HeaderPolicy.WHOLE_HEADER,PhylogeneticAlignment.Limits.defaults());
                var tree=NewickTree.parse(Files.readString(directory.resolve("result.treefile")));
                var nativeResult=JukesCantorLikelihood.evaluate(tree,alignment.jc69Sequences());int mismatches=0;double maxError=0;
                for(int i=0;i<n;i++) {
                    double actual=nativeResult.siteLogLikelihoods()[i];var source=new BigDecimal(data.get(i+3));
                    double difference=Math.abs(actual-source.doubleValue());maxError=Math.max(maxError,difference);
                    if(difference>source.ulp().abs().doubleValue()/2+1e-7)mismatches++;
                }
                nativeMismatches+=mismatches;record.put("native_fixed_JC69_total_on_written_tree",nativeResult.logLikelihood());record.put("native_total_minus_source_report",nativeResult.logLikelihood()-reported.doubleValue());
                record.put("site_native_mismatches_at_printed_precision_plus_1e_7",mismatches);record.put("maximum_absolute_site_difference",maxError);
                record.put("comparison_scope","Native fixed JC69 on the complete WRITTEN tree. Printed branch lengths and source duplicate removal/reinsertion can depart from the internally fitted tree; preserve differences, never replace source likelihoods.");
            }
            records.add(record);sites+=n;System.out.println(p.get("name")+" cells "+n+" total interval agrees"+(record.containsKey("site_native_mismatches_at_printed_precision_plus_1e_7")?" native cell mismatches="+record.get("site_native_mismatches_at_printed_precision_plus_1e_7"):""));
        }
        Files.writeString(Path.of(args[2]),IqtreeJson.json(Map.of("status","completed-source-site-total-and-written-tree-inspection","protocols",records,"sites",sites,"native_JC_cell_mismatches_retained",nativeMismatches,"scientific_analysis_admitted",false))+"\n",StandardOpenOption.CREATE_NEW);
        System.out.println("PROTOCOLS "+records.size()+" SITES "+sites+" NATIVE JC CELL MISMATCHES RETAINED "+nativeMismatches);
    }
}
