package org.jlinalg.cli;

import java.nio.file.*;
import java.util.*;
import org.jlinalg.phylogeny.*;

/** Same complete failed-control data, a larger declared budget and the typed execution path. */
public final class IqtreeTypedStandardProbe {
    private IqtreeTypedStandardProbe() { }
    public static void main(String[] args)throws Exception {
        Path root=Path.of(args[0]);Files.createDirectory(root);var records=new ArrayList<Map<String,Object>>();
        for(String version:List.of("1.6.12","2.3.6")) {
            Path directory=root.resolve(version);Files.createDirectory(directory);
            Path source=Path.of("/opt/omicsmatic-iqtree-setup-dev-1/inference-original-controls-1",version+"-DNA-standard-1000","alignment.fasta");
            Path alignment=directory.resolve("alignment.fasta");Files.copy(source,alignment);
            Path recipe=directory.resolve("recipe.json");
            var request=Map.of("schema_version",1,"profile","linux-x86_64-iqtree-"+version,"operation","INFER",
                "alignment",Map.of("path","alignment.fasta","format","FASTA","kind","DNA","header_policy","WHOLE_HEADER"),
                "model",Map.of("selection","FIXED","name","JC"),
                "support",Map.of("bootstrap","STANDARD","replicates",1000,"sh_alrt_replicates",0,"bnni",false,"write_branch_lengths",true),
                "parameters",Map.of("seed",61129,"threads",1,"identical_sequences","SOURCE_REMOVE_RESTORE","safe_mode",false,"outgroup",List.of()),
                "limits",Map.of("process",Map.of("wallMillis",1200000,"cpuSeconds",900,"addressSpaceBytes",4294967296L,"fileBytes",16777216,"workspaceBytes",67108864,"sampledRssBytes",2147483648L)));
            Files.writeString(recipe,IqtreeJson.json(request),StandardOpenOption.CREATE_NEW);
            var spec=IqtreeRecipe.read(recipe);var inputIdentity=IqtreeFiles.identity(alignment,spec.limits().inputBytes(),()->{});
            var admitted=PhylogeneticAlignment.readFasta(alignment,PhylogeneticAlignment.Kind.DNA,PhylogeneticAlignment.HeaderPolicy.WHOLE_HEADER,spec.limits().alignment());
            if(admitted.rows().size()!=12||admitted.columns()!=480)throw new AssertionError("Complete original data changed");
            var runtime=IqtreeRuntime.open(Path.of("/opt/omicsmatic-iqtree-setup-dev-1/formal-matrix-1/homes",version),spec.profile());
            Path process=directory.resolve("process");var taxonMap=new LinkedHashMap<String,String>();for(String taxon:admitted.taxa())taxonMap.put(taxon,taxon);
            var command=spec.arguments(alignment,null,process.resolve("result"),taxonMap);
            IqtreeProcess.Check integrity=()->{spec.verify();if(!inputIdentity.equals(IqtreeFiles.identity(alignment,spec.limits().inputBytes(),()->{})))throw new java.io.IOException("Original alignment changed");};
            System.out.println("START "+version+" standard bootstrap 1000, complete 12 taxa / 480 sites, CPU 900s / wall 1200s");
            var result=IqtreeProcess.run(runtime,1,command,process,spec.limits().process(),integrity,()->{});
            var counts=BootstrapSupport.count(Files.newBufferedReader(process.resolve("result.boottrees")),admitted.taxa(),1000,true,spec.limits().bootstrap());
            var edges=new ArrayList<Map<String,Object>>();
            for(String role:List.of("treefile","contree")) {
                var tree=NewickTree.parse(Files.readString(process.resolve("result."+role)));tree.requireMetricLengths();
                for(var value:BootstrapSupport.compare(tree,counts,1,0,1000000)) {
                    if(!value.agreesAtPrintedPrecision())throw new AssertionError("Standard bootstrap support differs from the complete replicate collection");
                    edges.add(Map.of("role",role,"child",value.childNode(),"split",new TreeSet<>(value.split()),"reported",value.reportedColumns(),"occurrences",value.occurrences(),"replicates",value.replicates()));
                }
            }
            integrity.verify();runtime.verify();
            records.add(Map.of("version",version,"recipe_identity",spec.identity(),"alignment_identity",inputIdentity,"process",result,
                "replicates",counts.replicates(),"support_edges",edges,"scientific_analysis_admitted",false));
            Files.writeString(directory.resolve("observed.json"),IqtreeJson.json(records.get(records.size()-1))+"\n",StandardOpenOption.CREATE_NEW);
            System.out.println("PASS "+version+" exact 1000 replicates; every support edge agrees; no owned live workers");
        }
        Files.writeString(root.resolve("observed.json"),IqtreeJson.json(Map.of("status","passed-typed-owned-standard-bootstrap-controls","protocols",records,"scientific_analysis_admitted",false))+"\n",StandardOpenOption.CREATE_NEW);
    }
}
