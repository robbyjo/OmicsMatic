from pathlib import Path
import hashlib,itertools,json,math,os,random,shutil,signal,stat,subprocess,time

ROOT=Path('/mnt/d/projects/JLinAlg');BASE=ROOT/'build/literature-review/iqtree-runtime'
OUT=BASE/'inference-original-controls-1';OUT.mkdir(exist_ok=False)
WORK=Path('/opt/omicsmatic-iqtree-setup-dev-1/inference-original-controls-1');WORK.mkdir(exist_ok=False)
HOMES=Path('/opt/omicsmatic-iqtree-setup-dev-1/formal-matrix-1/homes')
lock_path=ROOT/'tools/literature/iqtree-runtime-lock.json';lock=json.loads(lock_path.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(lock_path)=='2d80b924a35c9ad6dad675ca9905c4595dc1ccf8e2166116f8a001dc36a0a4f7'
shutil.copy2(__file__,OUT/'controller.py');shutil.copy2(lock_path,OUT/'runtime-lock.json')

def evolve(sequence,alphabet,length,rng):
    n=len(alphabet);keep=1/n+(1-1/n)*math.exp(-n*length/(n-1))
    return [x if rng.random()<keep else rng.choice([y for y in alphabet if y!=x]) for x in sequence]

def simulate(alphabet,sites,seed):
    # Independent explicit root/ancestral states. No upstream AliSim is used.
    rng=random.Random(seed);root=[rng.choice(alphabet) for _ in range(sites)];data={}
    for group in range(3):
        ancestor=evolve(root,alphabet,.035,rng)
        for pair in range(2):
            sister=evolve(ancestor,alphabet,.13,rng)
            for tip in range(2):
                name='T%09d'%(group*4+pair*2+tip+1)
                data[name]=''.join(evolve(sister,alphabet,.18,rng))
    return data

sense=[''.join(c) for c in itertools.product('ACGT',repeat=3) if ''.join(c) not in {'TAA','TAG','TGA'}]
datasets={'DNA':simulate(list('ACGT'),480,61129),
          'AA':simulate(list('ACDEFGHIKLMNPQRSTVWY'),320,61130),
          'CODON':simulate(sense,160,61131)}
datasets['DNA-identical']=dict(datasets['DNA']);datasets['DNA-identical']['T000000012']=datasets['DNA-identical']['T000000001']
(OUT/'synthetic-data.json').write_text(json.dumps(dict(generator='independent finite-state equal-rate ancestral simulation',
    seeds=dict(DNA=61129,AA=61130,CODON=61131),scope='Format, complete-output and source-behavior controls; no biological inference accuracy or fitted LG/MG parity claim',
    sequences=datasets),indent=2)+'\n')

def members(group):
    result=[]
    for path in Path('/proc').iterdir():
        if not path.name.isdigit():continue
        try:
            text=(path/'stat').read_text();fields=text[text.rfind(')')+2:].split()
            if int(fields[2])==group and fields[0]!='Z':result.append(int(path.name))
        except (OSError,ValueError):pass
    return sorted(result)

def census(directory):
    result={}
    for path in directory.rglob('*'):
        mode=path.lstat().st_mode
        if stat.S_ISDIR(mode):continue
        if not stat.S_ISREG(mode):raise RuntimeError('Nonregular output '+str(path))
        result[path.relative_to(directory).as_posix()]=dict(bytes=path.stat().st_size,sha256=sha(path))
    return result

records=[]
try:
    for profile_id,profile in lock['profiles'].items():
        version=profile['version'];home=HOMES/version;program=home/profile['program']
        before=sha(program);assert before==profile['files'][profile['program']]['sha256']
        for name,pin in profile['files'].items():assert sha(home/name)==pin['sha256'],(version,name)
        cases=[('DNA-JC','DNA','JC',[]),('DNA-GTR-R10','DNA','GTR+R10',[]),
               ('AA-LG-F-R10','AA','LG+F+R10',[]),('CODON-MG-F1X4','CODON','MG+F1X4',[]),
               ('DNA-ModelFinder','DNA','MFP',[]),('AA-ModelFinder','AA','MFP',[]),
               ('DNA-UFB-SHaLRT-BNNI','DNA','JC',['-bb' if version=='1.6.12' else '-B','1000','-alrt','1000','-bnni','-safe','-wbtl']),
               ('DNA-standard-100','DNA','JC',['-b','100','-wbtl']),
               ('DNA-identical-UFB','DNA-identical','JC',['-bb' if version=='1.6.12' else '-B','1000','-wbtl']),
               ('DNA-outgroup','DNA','JC',['-o','T000000011'])]
        if version in {'1.6.12','2.3.6'}:cases.append(('DNA-standard-1000','DNA','JC',['-b','1000','-wbtl']))
        for case,dataset,model,extra in cases:
            name=version+'-'+case;directory=WORK/name;directory.mkdir()
            alignment=directory/'alignment.fasta'
            alignment.write_text(''.join('>'+taxon+'\n'+sequence+'\n' for taxon,sequence in datasets[dataset].items()))
            command=['/usr/bin/prlimit','--as=4294967296','--cpu=180','--fsize=16777216','--nofile=128','--core=0','--',str(program),
                     '-s',str(alignment),'-st',dataset.split('-')[0],'-m',model,'-wsl','-seed','61129','-nt','1','-pre',str(directory/'result'),*extra]
            started=time.monotonic();reason=None;peak=0
            with (directory/'stdout').open('xb') as stdout,(directory/'stderr').open('xb') as stderr:
                child=subprocess.Popen(command,cwd=directory,env=dict(PATH='/usr/bin:/bin',HOME=str(directory),TMPDIR=str(directory),LANG='C',LC_ALL='C',OMP_NUM_THREADS='1'),
                                       stdout=stdout,stderr=stderr,start_new_session=True)
                (OUT/'running.json').write_text(json.dumps(dict(status='running',controller_pid=os.getpid(),child_pid=child.pid,case=name,command=command),indent=2)+'\n')
                try:
                    while os.waitid(os.P_PID,child.pid,os.WEXITED|os.WNOHANG|os.WNOWAIT) is None:
                        paths=list(directory.rglob('*'));size=sum(p.stat().st_size for p in paths if p.is_file());peak=max(peak,size)
                        if len(paths)>128 or size>67108864:reason='workspace-capacity';break
                        if time.monotonic()-started>240:reason='wall-capacity';break
                        time.sleep(.05)
                finally:
                    live=members(child.pid)
                    if live:os.killpg(child.pid,signal.SIGKILL)
                    code=child.wait(timeout=10)
                after=members(child.pid);assert after==[],after
            assert sha(program)==before
            record=dict(name=name,profile_id=profile_id,version=version,case=case,dataset=dataset,model=model,extra=extra,
                        exit_code=code,expected_exit_code=0,capacity_failure=reason,seconds=time.monotonic()-started,command=command,
                        owned_live_after_cleanup=after,program_sha256=before,peak_sampled_output_bytes=peak,files=census(directory))
            records.append(record);(OUT/'observed.json').write_text(json.dumps(records,indent=2)+'\n')
            print(name,'exit',code,'seconds',round(record['seconds'],2),'capacity',reason,flush=True)
            if code:print((directory/'stderr').read_text(errors='replace')[-800:],flush=True)
finally:
    shutil.copytree(WORK,OUT/'linux')
    (OUT/'running.json').write_text(json.dumps(dict(status='terminal',controller_pid=os.getpid(),protocols=len(records),work=str(WORK),
         all_expected=all(r['exit_code']==0 and not r['capacity_failure'] for r in records)),indent=2)+'\n')
print('Terminal protocols:',len(records),flush=True)
