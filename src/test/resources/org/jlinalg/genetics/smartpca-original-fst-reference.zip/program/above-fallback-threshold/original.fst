F_st              GROUP_0              GROUP_1     0.000000     0.000000
F_st              GROUP_0              GROUP_2     0.000000     0.000000
F_st              GROUP_1              GROUP_2     0.000000     0.000000

