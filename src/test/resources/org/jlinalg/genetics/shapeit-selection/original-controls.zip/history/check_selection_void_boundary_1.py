from pathlib import Path
import hashlib,json,os,subprocess

root=Path('/mnt/d/projects/JLinAlg');base=root/'build/literature-review/shapeit-runtime';work=Path('/opt/omicsmatic-shapeit-dev-1');prefix=work/'.pixi/envs/default'
capture=base/'selection-protocol-attempt-1';report=base/'selection-void-boundary-1';report.mkdir(exist_ok=False)
private=work/'selection-void-boundary-1';private.mkdir(exist_ok=False)
source=work/'source5-attempt-1/phase_common';protocol=root/'tools/literature/shapeit-reference/SelectionProtocol.cpp'
prior=json.loads((capture/'observed.json').read_bytes());assert hashlib.sha256(protocol.read_bytes()).hexdigest()==prior['source_protocol_sha256']
env=dict(os.environ,PATH=str(prefix/'bin')+':/usr/bin:/bin',LD_LIBRARY_PATH=str(prefix/'lib'),LC_ALL='C')
runs=[]
def run(name,command,expected):
    with (report/(name+'.stdout')).open('wb') as stdout,(report/(name+'.stderr')).open('wb') as stderr:
        process=subprocess.Popen([str(x) for x in command],cwd=private,env=env,stdout=stdout,stderr=stderr)
        (report/'running.json').write_text(json.dumps({'controller_linux_pid':os.getpid(),'child_linux_pid':process.pid,'phase':name},indent=2)+'\n')
        code=process.wait()
    runs.append({'name':name,'command':[str(x) for x in command],'exit_code':code});(report/'runs.json').write_text(json.dumps(runs,indent=2)+'\n')
    print(name,'EXIT',code,flush=True);assert code==expected,(name,code)
compiler=prefix/'bin/x86_64-conda-linux-gnu-g++';flags=['-std=c++20','-O2','-D_GLIBCXX_ASSERTIONS','-I'+str(prefix/'include'),'-I'+str(source/'src'),'-L'+str(prefix/'lib'),'-Wl,-rpath,'+str(prefix/'lib')]
scan=source/'src/io/genotype_reader/genotype_reader_scaning.cpp';obj=private/'scanner-checked.o'
run('compile-checked-original-scanner',[compiler,*flags,'-c',scan,'-o',obj],0)
objects=sorted(p for p in (source/'obj').glob('*.o') if p.name not in ['main.o','genotype_reader_scaning.o'])
assert len(objects)>10
program=private/'checked-selection'
run('compile-checked-protocol',[compiler,*flags,protocol,obj,*objects,'-lhts','-lboost_iostreams','-lboost_program_options','-lz','-lbz2','-lm','-lpthread','-llzma','-lcurl','-lcrypto','-ldeflate','-o',program],0)
result=report/'empty-main.oracle.tsv'
run('empty-main',[program,capture/'main0.bcf',capture/'ref50.bcf','-','20','0','default',result],-6)
stderr=(report/'empty-main.stderr').read_text();assert '__n < this->size()' in stderr and 'vector' in stderr
record={'status':'confirmed-original-void-file-gap-vector-boundary','normal_original_scanner_exit_code':-11,'checked_original_scanner_exit_code':-6,'unmodified_original_source_sha256':hashlib.sha256(scan.read_bytes()).hexdigest(),'protocol_sha256':hashlib.sha256(protocol.read_bytes()).hexdigest(),'program_sha256':hashlib.sha256(program.read_bytes()).hexdigest(),'source_boundary':'xcf_reader::addFile FILE_VOID does not append ind_names, and a later data file writes ind_names[sync_number] outside its size.','required_action':'Skip dependent phasing for an empty ordinary target file before a data-bearing reference or scaffold. Supply a nonempty valid target or separately validate an upstream header-handling fix.','public_phasing_adapter_available':False}
(report/'observed.json').write_text(json.dumps(record,indent=2)+'\n');print('ORIGINAL SOURCE BOUNDARY CONFIRMED',flush=True)
