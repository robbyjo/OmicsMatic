from pathlib import Path
import hashlib,json,os,subprocess,time

root=Path('/mnt/d/projects/JLinAlg');base=root/'build/literature-review/shapeit-runtime'
work=Path('/opt/omicsmatic-shapeit-dev-1');prefix=work/'.pixi/envs/default'
private=work/'selection-protocol-attempt-1';private.mkdir(exist_ok=False)
report=base/'selection-protocol-attempt-1';report.mkdir(exist_ok=False)
source=work/'source5-attempt-1/phase_common'
env=dict(os.environ,PATH=str(prefix/'bin')+':/usr/bin:/bin',LD_LIBRARY_PATH=str(prefix/'lib'),LC_ALL='C')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
runs=[]
def run(name,command,allowed=(0,)):
    start=time.monotonic()
    with (report/(name+'.stdout')).open('wb') as stdout,(report/(name+'.stderr')).open('wb') as stderr:
        child=subprocess.Popen([str(x) for x in command],cwd=private,env=env,stdout=stdout,stderr=stderr)
        (report/'running.json').write_text(json.dumps({'controller_linux_pid':os.getpid(),'child_linux_pid':child.pid,'phase':name},indent=2)+'\n')
        code=child.wait()
    runs.append({'name':name,'command':[str(x) for x in command],'exit_code':code,'seconds':time.monotonic()-start})
    (report/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(name,'EXIT',code,flush=True)
    if allowed is not None and code not in allowed:
        print((report/(name+'.stderr')).read_text(errors='replace')[-3000:],flush=True);raise SystemExit(code or 1)
    return code

compiler=prefix/'bin/x86_64-conda-linux-gnu-g++';protocol=root/'tools/literature/shapeit-reference/SelectionProtocol.cpp';generator=root/'tools/literature/shapeit-reference/MakeSelectionFixture.cpp'
common=['-O2','-I'+str(prefix/'include'),'-L'+str(prefix/'lib'),'-Wl,-rpath,'+str(prefix/'lib')]
run('compile-fixture',[compiler,'-std=c++17',*common,generator,'-lhts','-o',private/'make-fixture'])
objects=sorted(p for p in (source/'obj').glob('*.o') if p.name!='main.o');assert len(objects)>10
program=private/'original-selection'
run('compile-original-reader-protocol',[compiler,'-std=c++20',*common,'-I'+str(source/'src'),protocol,*objects,'-lhts','-lboost_iostreams','-lboost_program_options','-lz','-lbz2','-lm','-lpthread','-llzma','-lcurl','-lcrypto','-ldeflate','-o',program])

def row(position,name,alleles='A,C',ac='2',an='100',end='-',kind=1,contig=0):return [contig,position,name,alleles,ac,an,end,kind]
fixtures={}
def fixture(name,rows,samples=50,mode='bcf',sample_prefix='M',ac_type='Integer',an_type='Integer'):
    spec=report/(name+'.spec.tsv');spec.write_text(''.join('\t'.join(map(str,r))+'\n' for r in rows))
    output=report/(name+'.bcf')
    run('fixture-'+name,[private/'make-fixture',spec,output,samples,mode,sample_prefix,ac_type,an_type])
    run('index-'+name,[prefix/'bin/bcftools','index',output])
    fixtures[name]={'path':output.name,'samples':samples,'mode':mode,'rows':rows,'sample_prefix':sample_prefix,'ac_type':ac_type,'an_type':an_type,'sha256':sha(output)}
    return name

frequency=[]
for i,(name,alleles,ac,an,end,kind) in enumerate([
 ('one','A,C','1','1000','-',1),('complement','A,C','999','1000','-',1),('zero','A,C','0','100','-',1),
 ('no-alleles','A,C','0','0','-',1),('infinite-af','A,C','1','0','-',1),('negative-ac','A,C','-1','100','-',1),
 ('missing-ac-value','A,C','m','100','-',1),('negative-an','A,C','1','-1','-',1),('both-negative','A,C','-1','-1','-',1),
 ('half','A,C','50','100','-',1),('padded-ac','A,C','1,e,e','1000','-',1),('padded-an','A,C','1','1000,e,e','-',1),
 ('lowercase','a,c','2','100','-',1),('indel','A,AT','2','100','-',1),('mnp','AA,TT','2','100','-',1),
 ('ambiguous','N,C','2','100','-',1),('symbolic','A,<DEL>','2','100','25000',1),('star','A,*','2','100','-',1),
 ('multiallelic','A,C,G','-','-','-',1),('reference-only','A','-','-','-',1),('missing-gt','A,C','2','100','-',0),
 ('max-count','A,C','2147483647','2147483647','-',1),('missing-an-value','A,C','1','m','-',1)]):
    frequency.append(row(1000+i*100,'M-'+name,alleles,ac,an,end,kind))
fixture('frequency',frequency)
cases=[]
def case(name,main='frequency',reference=None,scaffold=None,region='20',snp=False,maf='default',error=None):
    cases.append({'name':name,'main':main,'reference':reference,'scaffold':scaffold,'region':region,'snp':snp,'maf':maf,'expected_error':error})
for maf in ['default','0','-0','-0.1','0.001','0.0010000001639127731','0.5','0.6','inf','-inf','nan','1e-80']:
    for snp in [False,True]:case('frequency-'+str(len(cases)),maf=maf,snp=snp)
case('bounded-region',region='20:1050-1250')
base_rows=[row(1000,'BASE')]
fixture('main49',base_rows,samples=49);fixture('ref1',base_rows,samples=1,sample_prefix='R')
fixture('main0',base_rows,samples=0);fixture('ref50',base_rows,samples=50,sample_prefix='R')
fixture('scaf100',base_rows,samples=100,sample_prefix='M')
case('sample49','main49',error='samples');case('sample49-scaffold-not-counted','main49',scaffold='scaf100',error='samples')
case('sample49-plus-ref1','main49','ref1');case('empty-main-plus-ref50','main0','ref50',error='no-variants')

format_rows=[row(1000+i*100,'TYPE-'+str(t),kind=t) for i,t in enumerate([0,1,2,3,4,5,6,99,-1])]
fixture('binary-main',format_rows,mode='xcf');case('binary-main-formats','binary-main')
fixture('main10',[row(r[1],'M-'+r[2]) for r in format_rows],samples=10)
fixture('binary-ref',format_rows,samples=40,mode='xcf',sample_prefix='R');case('binary-reference-formats','main10','binary-ref')
fixture('main50',[row(r[1],'M-'+r[2]) for r in format_rows])
fixture('binary-scaf',format_rows,samples=100,mode='xcf',sample_prefix='M');case('binary-scaffold-formats','main50',scaffold='binary-scaf')
case('binary-three-panels','main10','binary-ref','binary-scaf')

main=[row(1000,'M-common'),row(2000,'M-only'),row(3000,'M-indel','A,AT'),row(4000,'M-multi','A,C,G','-','-'),
      row(5000,'M-case','a,c'),row(6000,'M-del','A,<DEL>',end='6050'),row(7000,'M-dup-C-0'),row(7000,'M-dup-G','A,G'),row(7000,'M-dup-C-1'),row(8000,'M-contig21',contig=1)]
ref=[row(1000,'R-common'),row(2500,'R-only'),row(3000,'R-indel','A,AT'),row(4000,'R-bi'),row(5000,'R-case','A,C'),
     row(6000,'R-del-other','A,<DEL>',end='6060'),row(7000,'R-dup-G','A,G'),row(7000,'R-dup-C-0'),row(7000,'R-dup-C-1'),row(8000,'R-contig21',contig=1)]
scaf=[row(1000,'S-common'),row(2000,'S-main-only'),row(2600,'S-only'),row(3000,'S-indel','A,AT'),row(5000,'S-case','A,C'),
      row(6000,'S-del','A,<DEL>',end='6050'),row(7000,'S-dup-C'),row(7000,'S-dup-G','A,G')]
fixture('join-main',main,samples=10);fixture('join-ref',ref,samples=40,sample_prefix='R');fixture('join-scaf',scaf,samples=5)
case('join-main-ref','join-main','join-ref');case('join-three','join-main','join-ref','join-scaf')
case('join-three-snp','join-main','join-ref','join-scaf',snp=True);case('join-contig21','join-main','join-ref','join-scaf',region='21')
fixture('join-main50',main);case('join-main-scaffold','join-main50',scaffold='join-scaf')

for name,ac,an,ac_type,an_type in [('no-ac','-','100','Integer','Integer'),('no-an','2','-','Integer','Integer'),
 ('two-ac','1,2','100','Integer','Integer'),('empty-ac','e','100','Integer','Integer'),('two-an','2','100,101','Integer','Integer'),
 ('float-ac','2','100','Float','Integer'),('string-an','2','100','Integer','String')]:
    fixture(name,[row(1000,'BAD-'+name,ac=ac,an=an)],ac_type=ac_type,an_type=an_type)
    case('reject-'+name,name,error='AC' if name.endswith('ac') else 'AN')
fixture('missing-indel',[row(1000,'BAD-indel','A,AT',ac='-')]);case('missing-before-snp-filter','missing-indel',snp=True,error='AC')
fixture('bad-outside',[row(1000,'OK'),row(2000,'BAD',ac='-')]);case('bad-count-outside-region','bad-outside',region='20:900-1100')
fixture('ref-bad-unmatched',[row(1000,'OK'),row(2000,'BAD-ref',ac='-')],samples=50,sample_prefix='R')
fixture('one-good',base_rows);case('unmatched-reference-still-needs-counts','one-good','ref-bad-unmatched',error='AC')
fixture('scaf-bad-unmatched',[row(1000,'OK'),row(2000,'BAD-scaf',ac='-')],samples=5)
case('unmatched-scaffold-still-needs-counts','one-good',scaffold='scaf-bad-unmatched',error='AC')
case('empty-selection','one-good',maf='0.6',error='no-variants')

observed=[]
for item in cases:
    output=report/(item['name']+'.oracle.tsv')
    cmd=[program,report/fixtures[item['main']]['path'],report/fixtures[item['reference']]['path'] if item['reference'] else '-',report/fixtures[item['scaffold']]['path'] if item['scaffold'] else '-',item['region'],'1' if item['snp'] else '0',item['maf'],output]
    code=run('reader-'+item['name'],cmd,allowed=None)
    lines=output.read_text().splitlines()
    if item['expected_error']:
        assert code!=0,(item['name'],code);assert not any(line.startswith('E\t') for line in lines)
        combined=(report/('reader-'+item['name']+'.stdout')).read_text()+(report/('reader-'+item['name']+'.stderr')).read_text()
        needle={'samples':'Less than 50 samples','no-variants':'No variants to be phased!'}.get(item['expected_error'],item['expected_error']+' field is needed')
        assert needle in combined,(item['name'],combined)
    else:
        assert code==0,(item['name'],code);assert lines[-1].startswith('E\t')
        header=next(line.split('\t') for line in lines if line.startswith('H\t'))
        assert int(header[3])==sum(line.startswith('J\t') for line in lines)
        assert int(header[4])==sum(line.startswith('K\t') for line in lines)
    observed.append(dict(item,exit_code=code,result=output.name,sha256=sha(output),complete=code==0))
record={'status':'passed-original-common-stage-selection-and-joined-panel-controls','source_commit':'c34d4db3e99a2f7e23deb727671ae260901a5886','program_sha256':sha(program),'source_protocol_sha256':sha(protocol),'fixture_generator_sha256':sha(generator),'fixtures':fixtures,'cases':observed,'original_scanner_calls':len(observed),'public_phasing_adapter_available':False,'XCF_binary_payloads_are_empty_scan_only_not_genotype_fits':True}
(report/'observed.json').write_text(json.dumps(record,indent=2)+'\n');print('ALL ORIGINAL SELECTION CONTROLS RETAINED',len(observed),flush=True)
