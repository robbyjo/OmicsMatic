from pathlib import Path
import hashlib, json, os, random, subprocess, time, zipfile

root = Path('/mnt/d/projects/JLinAlg')
base = root / 'build/literature-review/shapeit-runtime'
report = base / 'map-protocol-attempt-2'; report.mkdir(exist_ok=False)
work = Path('/opt/omicsmatic-shapeit-dev-1')
private = work / 'map-protocol-attempt-2'; private.mkdir(exist_ok=False)
prefix = work / '.pixi/envs/default'
env = dict(os.environ, PATH=str(prefix/'bin')+':/usr/bin:/bin', LD_LIBRARY_PATH=str(prefix/'lib'), LC_ALL='C')
compiler = prefix/'bin/x86_64-conda-linux-gnu-g++'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
runs = []
def run(name, command, expected=None):
    start=time.monotonic()
    with (report/(name+'.stdout')).open('wb') as stdout, (report/(name+'.stderr')).open('wb') as stderr:
        child=subprocess.Popen([str(x) for x in command],cwd=private,env=env,stdout=stdout,stderr=stderr)
        (report/'running.json').write_text(json.dumps({'controller_linux_pid':os.getpid(),'child_linux_pid':child.pid,'phase':name},indent=2)+'\n')
        code=child.wait()
    runs.append({'name':name,'command':[str(x) for x in command],'exit_code':code,'seconds':time.monotonic()-start})
    (report/'runs.json').write_text(json.dumps(runs,indent=2)+'\n')
    print(name,'EXIT',code,flush=True)
    if expected is not None and code not in expected:
        print((report/(name+'.stderr')).read_text(errors='replace')[-3000:],flush=True); raise SystemExit(code or 1)
    return code

source_new = base/'upstream/source4-v4.2.2'
assert subprocess.check_output(['git','-C',source_new,'rev-parse','HEAD']).decode().strip()=='16865e593ad50689271ead985dc8f4296d2f491d'
source_manifest=[]
for record in subprocess.check_output(['git','-C',source_new,'ls-files','-s','-z']).split(b'\0'):
    if not record: continue
    head,name=record.split(b'\t',1); mode,blob,stage=head.decode().split(); name=name.decode()
    path=source_new/name
    if not path.is_file(): continue
    raw=path.read_bytes()
    assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob,name
    source_manifest.append({'path':name,'mode':mode,'git_blob_sha1':blob,'sha256':sha(path),'bytes':len(raw)})
(report/'4.2.2-selected-source.json').write_text(json.dumps({'commit':'16865e593ad50689271ead985dc8f4296d2f491d','files':source_manifest},indent=2)+'\n')

rich=[(100,-0.0),(200,0.12345678901234567),(200,0.125),(333,0.125),(1000,7.123456789012345),(4000,7.123456789012346)]
def text(points): return 'ignored header content\n'+''.join(f'{bp} ignored {cm!r}\n' for bp,cm in points)
rng=random.Random(739121); random_points=[(100,0.0)]
for i in range(150):
    random_points.append((random_points[-1][0]+rng.randrange(0,4000),random_points[-1][1]+rng.random()*0.15))
random_positions=sorted([1,100,random_points[-1][0]]+[rng.randrange(1,random_points[-1][0]+1) for _ in range(600)])
cases=[
 {'name':'mixed','mode':'map','map':text(rich),'positions':[1,99,100,100,101,150,199,200,201,332,333,334,999,1000,1001,3999,4000]},
 {'name':'global-mean','mode':'map','map':text([(100,2.0),(200,3.0),(10000,99.0)]),'positions':[20,50,100,101,150,200,500,9999,10000]},
 {'name':'flat','mode':'map','map':text([(100,5.0),(300,5.0),(300,5.0),(1000,5.0)]),'positions':[1,100,101,300,999,1000]},
 {'name':'single-exact','mode':'map','map':text([(100,0.25)]),'positions':[100,100]},
 {'name':'zero-span-exact','mode':'map','map':text([(100,0.0),(100,0.5),(100,1.0)]),'positions':[100,100]},
 {'name':'random','mode':'map','map':text(random_points),'positions':random_positions},
 {'name':'default','mode':'default','map':'unused\n','positions':[1,2,10,1000003,2000001,2147483647]},
 {'name':'coercions','mode':'map','map':'0 0 0\n0junk ignored nonsense\n100suffix anything 0.1suffix\n200 ignored 0.2\n','positions':[1,2,100,199,200]},
 {'name':'hexadecimal','mode':'map','map':'header\n0 ignored 0x1.2p-3suffix\n100 ignored 0x1.4\n200 ignored 0x1.8p1\n','positions':[1,99,100,101,200]},
 {'name':'nan-payloads','mode':'read','map':'header\n0 ignored nan(0x1234)\n1 ignored -NaN(42)\n2 ignored NaN(custom)\n3 ignored +inf\n4 ignored Infinity\n','positions':[]},
 {'name':'negative-zero','mode':'read','map':'header\n+0x ignored -0\n1 ignored +0.0\n2 ignored 1e-99999\n3 ignored 1e99999\n','positions':[]},
 {'name':'all-before','mode':'map','map':text(rich),'positions':[1,2,10,50]},
 {'name':'right-boundary','mode':'map','map':text(rich),'positions':[100,333,4000,4001]},
 {'name':'empty-variants','mode':'map','map':text(rich),'positions':[]},
 {'name':'empty-map','mode':'map','map':'header\n','positions':[100]},
 {'name':'bad-columns','mode':'read','map':'header\n100 0\n','positions':[]},
 {'name':'decreasing-bp','mode':'read','map':'header\n100 0 0\n99 0 1\n','positions':[]},
 {'name':'decreasing-cm','mode':'read','map':'header\n100 0 1\n200 0 0.9\n','positions':[]},
 {'name':'whitespace-line','mode':'read','map':'header\n \t \n','positions':[]},
]
for c in cases:
    (report/(c['name']+'.map')).write_text(c['map'])
    (report/(c['name']+'.positions')).write_text(''.join(str(x)+'\n' for x in c['positions']))
    c['inputs']={'map':c['name']+'.map','positions':c['name']+'.positions'}

protocol=root/'tools/literature/shapeit-reference/MapProtocol.cpp'
profiles=[('4.1.3',work/'source4-attempt-1','c++11'),('4.2.2',source_new,'c++11'),('5-c34d',work/'source5-attempt-1/phase_common','c++20')]
observed=[]; source_records={}
for name,source,standard in profiles:
    units=[source/'src/containers/variant_map.cpp',source/'src/objects/variant.cpp',source/'src/io/gmap_reader.cpp']
    source_records[name]={p.relative_to(source).as_posix():sha(p) for p in units}
    for arithmetic,flags in [('fused',[]),('split',['-ffp-contract=off']),('checked',['-D_GLIBCXX_ASSERTIONS'])]:
        program=private/('map-'+name+'-'+arithmetic)
        command=[compiler,'-std='+standard,'-O3','-mavx2','-mfma',*flags,'-I'+str(source/'src'),'-I'+str(prefix/'include'),'-L'+str(prefix/'lib'),'-Wl,-rpath,'+str(prefix/'lib'),protocol,*units,'-lhts','-lboost_iostreams','-lboost_program_options','-lz','-lbz2','-lm','-lpthread','-llzma','-lcurl','-lcrypto','-ldeflate','-o',program]
        run('compile-'+name+'-'+arithmetic,command,(0,))
        for c in cases:
            undefined=c['name'] in ['right-boundary','empty-variants','empty-map','whitespace-line'] or c['name']=='all-before' and name=='4.1.3'
            rejected=c['name'] in ['bad-columns','decreasing-bp','decreasing-cm']
            if (undefined or rejected) and arithmetic!='checked': continue
            result=report/(name+'-'+arithmetic+'-'+c['name']+'.tsv')
            code=run(name+'-'+arithmetic+'-'+c['name'],[program,c['mode'],report/c['inputs']['map'],report/c['inputs']['positions'],result])
            if undefined: assert code!=0,(name,c['name'],code)
            elif rejected: assert code!=0,(name,c['name'],code)
            else: assert code==0,(name,c['name'],code)
            observed.append({'profile':name,'arithmetic':arithmetic,'case':c['name'],'result':result.name,'exit_code':code,'source_undefined_boundary':undefined,'source_parser_rejected':rejected,'complete':code==0 and result.read_text().splitlines()[-1].startswith('E\t'),'program_sha256':sha(program)})
    assert source_records[name]=={p.relative_to(source).as_posix():sha(p) for p in units}

record={'status':'passed-original-map-parsing-interpolation-and-checked-boundary-controls','source_units':source_records,'protocol_sha256':sha(protocol),'compiler_sha256':sha(compiler),'profiles':[p[0] for p in profiles],'cases':cases,'observations':observed,'source4_2_2_manifest':'4.2.2-selected-source.json','public_phasing_adapter_available':False}
(report/'observed.json').write_text(json.dumps(record,indent=2)+'\n')
print('ALL MAP CONTROLS RETAINED',len(observed),flush=True)
