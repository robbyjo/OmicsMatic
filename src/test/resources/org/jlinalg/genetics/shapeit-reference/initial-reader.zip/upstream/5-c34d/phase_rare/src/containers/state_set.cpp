/*******************************************************************************
 * Copyright (C) 2022-2023 Olivier Delaneau
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 ******************************************************************************/

#include <containers/state_set.h>

using namespace std;

state_set::state_set() {
	clear();
}

state_set::~state_set() {
	clear();
}

void state_set::clear() {
	Pstates.clear();
	Pmapping.clear();
	Pstates.shrink_to_fit();
	Pmapping.shrink_to_fit();
}

void state_set::transpose() {
	tac.clock();
	for (uint64_t e = 0 ; e < Pstates.size() ; e ++) Pstates[e].swap();
	sort(Pstates.begin(), Pstates.end());
	vrb.bullet("Transpose compressed probabilities (" + stb.str(tac.rel_time()*1.0/1000, 2) + "s)");
}

void state_set::mapping(uint32_t n_scaffold_variants) {
	tac.clock();
	Pmapping = vector < int64_t > (n_scaffold_variants+1, -1);
	for (uint64_t e = 0 ; e < Pstates.size() ; e ++) {
		if (Pmapping[Pstates[e].id0] < 0) Pmapping[Pstates[e].id0] = e;
	}
	vrb.bullet("Map compressed probabilities (" + stb.str(tac.rel_time()*1.0/1000, 2) + "s)");
}
