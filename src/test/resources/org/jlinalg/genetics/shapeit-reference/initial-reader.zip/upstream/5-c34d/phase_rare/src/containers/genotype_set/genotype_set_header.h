/*******************************************************************************
 * Copyright (C) 2022-2023 Olivier Delaneau
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 ******************************************************************************/

#ifndef _GENOTYPE_SET_H
#define _GENOTYPE_SET_H

#include <utils/otools.h>

#include <containers/bitmatrix.h>
#include <objects/hmm_parameters.h>
#include <objects/rare_genotype.h>

class genotype_set {
public:

	//Counts
	uint32_t n_scaffold_variants;			//#variants rare to be phased
	uint32_t n_rare_variants;				//#variants rare to be phased
	uint32_t n_samples;						//#samples

	uint64_t nmiss_total;
	uint64_t nmiss_imputation;
	uint64_t nmiss_families;
	uint64_t nmiss_monomorphic;
	uint64_t nhets_total;
	uint64_t nhets_families;
	uint64_t nhets_imputation;
	uint64_t nhets_coalescent;

	//Sample IDs
	std::vector < std::string > names;
	std::vector < bool > haploids;

	//Trios/Duos
	std::vector < int32_t > mendel_error, mendel_ydone, mendel_ndone, mendel_imput;

	//Mapping on scaffold
	std::vector < uint32_t > MAP_R2S;

	//Genotypes at rare unphased variants
	std::vector < bool > major_alleles;
	std::vector < std::vector < rare_genotype > > GRvar_genotypes;
	std::vector < std::vector < rare_genotype > > GRind_genotypes;

	//
	genotype_set();
	~genotype_set();

	//BASIC
	void clear();
	void allocate(variant_map &, uint32_t, uint32_t , uint32_t);
	void mapUnphasedOntoScaffold(int32_t ind, std::vector < std::vector < uint32_t > > & map);
	void mapHaploidsAndResetHets(std::string fhap);

	//TRANSPOSE
	void fillup_by_transpose_V2I();
	void merge_by_transpose_I2V();
	uint64_t countHet();
	uint64_t countUnphased();

	//PUSH
	void pushRareMissing(uint32_t vr, uint32_t i, bool major);
	void pushRareUnphasedHet(uint32_t vr, uint32_t i);
	void pushRarePhasedHet(uint32_t vr, uint32_t i, bool, bool);
	void pushRareHom(uint32_t vr, uint32_t i, bool major);
	int32_t pushRare(uint32_t vr, uint32_t v);

	//IMPUTE
	void imputeMonomorphic();
	void phaseLiAndStephens(uint32_t, uint32_t, aligned_vector32 < float > &, aligned_vector32 < float > &, std::vector < uint32_t > &, float);
	void phaseCoalescentViterbi(uint32_t, std::vector < int32_t > &, std::vector < int32_t > &, hmm_parameters &, bool);
	void phasePedigrees(std::string fped);

};

inline
void genotype_set::pushRareMissing(uint32_t vr, uint32_t i, bool major) {
	GRvar_genotypes[vr].emplace_back(i, 0, 1, major, major, 0);
}

inline
void genotype_set::pushRareUnphasedHet(uint32_t vr, uint32_t i) {
	GRvar_genotypes[vr].emplace_back(i, 1, 0, 0, 1, 0);
}

inline
void genotype_set::pushRarePhasedHet(uint32_t vr, uint32_t i, bool a0, bool a1) {
	GRvar_genotypes[vr].emplace_back(i, 1, 0, a0, a1, 1);
}

inline
void genotype_set::pushRareHom(uint32_t vr, uint32_t i, bool major) {
	GRvar_genotypes[vr].emplace_back(i, 0, 0, !major, !major, 1);
}

inline
int32_t genotype_set::pushRare(uint32_t vr, uint32_t value) {
	GRvar_genotypes[vr].emplace_back(value);
	if (GRvar_genotypes[vr].back().mis) return 3;
	else if (GRvar_genotypes[vr].back().het) return 1;
	else return 2*GRvar_genotypes[vr].back().al0;
}

#endif
