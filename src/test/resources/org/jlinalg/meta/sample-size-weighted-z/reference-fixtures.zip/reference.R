args <- commandArgs(trailingOnly=TRUE)
options(digits=17)
x <- read.delim(args[1], sep="\t", check.names=FALSE, colClasses="character")
all <- data.frame(case=character(),field=character(),value=character())
for (row in seq_len(nrow(x))) {
 v <- as.double(strsplit(x$values[row], ",", fixed=TRUE)[[1]])
 w <- as.double(strsplit(x$weights[row], ",", fixed=TRUE)[[1]])
 d <- if (nchar(x$directions[row])) as.double(strsplit(x$directions[row], ",", fixed=TRUE)[[1]]) else numeric()
 z <- if(x$mode[row]=="z") v else d*qnorm((if(x$mode[row]=="p") log(v) else v)-log(2), lower.tail=FALSE,log.p=TRUE)
 total <- sum(w); a <- sqrt(w)/sqrt(total); contrib <- a*z; combined <- sum(contrib)
 lp <- log(2)+pnorm(abs(combined),lower.tail=FALSE,log.p=TRUE); p <- exp(lp)
 hc <- (z-a*combined)^2; Q <- sum(hc); df <- length(z)-1
 qlp <- if(df>0) pchisq(Q,df,lower.tail=FALSE,log.p=TRUE) else NA_real_
 qp <- if(df>0) exp(qlp) else NA_real_; i2 <- if(df>0) if(Q>df) 100*(1-df/Q) else 0 else NA_real_
 value <- c(studies=length(z),totalWeight=total,z=combined,pValue=p,logPValue=lp,pValueUnderflow=as.integer(p==0),heterogeneityQ=Q,heterogeneityDegreesOfFreedom=df,heterogeneityPValue=qp,heterogeneityLogPValue=qlp,heterogeneityPValueUnderflow=as.integer(!is.na(qp)&&qp==0),iSquaredPercent=i2)
 for (name in names(value)) all <- rbind(all,data.frame(case=x$id[row],field=name,value=if(is.na(value[name]))"NA" else sprintf("%.17g",value[name])))
 for (name in c("studyZ","squareRootFractionWeights","zContributions","heterogeneityContributions")) {
  a <- switch(name,studyZ=z,squareRootFractionWeights=sqrt(w)/sqrt(total),zContributions=contrib,heterogeneityContributions=hc)
  if(x$expected[row]=="finite") stopifnot(all(is.finite(a)))
  for (j in seq_along(a)) all <- rbind(all,data.frame(case=x$id[row],field=paste0(name,".",j-1),value=sprintf("%.17g",a[j])))
 }
}
write.table(all,args[2],sep="\t",row.names=FALSE,col.names=TRUE,quote=FALSE,na="NA")
writeLines(c(R.version.string,paste0("models=",nrow(x)),paste0("fields=",nrow(all))),args[3])
