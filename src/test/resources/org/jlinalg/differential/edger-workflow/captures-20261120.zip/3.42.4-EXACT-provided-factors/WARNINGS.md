# edgeR warnings and required actions

Status: completed-with-warnings

Read WARNINGS.md, analysis-status.json, worker/report.json, worker/warnings.txt and logs. SKIP3: dependent analysis skipped; restore the named exact permitted input/runtime/package or retain the skip. FAIL2: no complete result; preserve inputs, original model objects, partials and diagnostics, correct data/design, convergence, integrity, capacity or process failures and retry NEW output. No silent identity, count rounding, version, threshold, population, nonfinite or algorithm repair. DEVELOPMENT_SCOPE: original edgeR3.40.2/3.42.4/4.10.7 on explicit R4.6.1 profiles. Prepared count matrices, declared groups and numeric designs/contrasts; original filtering, normalization, dispersion, exact/LRT/QL tests. Current adjusted and historical legacy QL are explicit. Unchanged original model-function bodies use declared observational DGEList/matrix dispatch; original namespaces remain unchanged. No generic empirical-Bayes/native fit fallback or author-host/whole-paper claim. VERIFY audits capture integrity, deterministic intake, CPM/adjustment/effect arithmetic and exported structure without R; it does not independently refit original models, parse binary RDS model contents or authenticate coordinated replacement. REPLAY needs the exact permitted runtime.

## Original and adapter warnings

Caller-provided positive normalization factors are used literally, without geometric-mean recentering or inferred provenance.
The caller declares raw/estimated count units, biological replication and design adequacy. Numeric transport preserves literal external identities through explicit ASCII index maps.
Unchanged original glmFit/predFC/glmQLFit/glmLRT/glmQLFTest bodies run with declared observational DGEList/matrix dispatch: original full/prior-count/null/Poisson glmFit returns are retained and checked for exposed failed flags and the source hardcoded 250-iteration limit. The original namespace is not modified. This does not establish convergence of every lower-level quantity for which stock edgeR exposes no flag.
No whole paper, historical author host, generic empirical-Bayes replacement or unreported author operation is qualified by this prepared-matrix analysis.
