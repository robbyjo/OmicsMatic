# Private original mashr controls

These are synthetic development references, not a public user-analysis workflow or biological certificate. Both original algorithms and any numerical failures remain recorded.

Required action: inspect per-case status, warnings and errors before comparing or admitting results; do not discard a failed algorithm or count this foundation as a complete mashr integration.
