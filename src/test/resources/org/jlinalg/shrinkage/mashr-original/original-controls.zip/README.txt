Original mashr0.2.79 Gaussian fixed-mixture controls, 43 models / 346 complete feature rows.
Contains both original algorithms, every input/output cell, original RDS fits, commands, logs, package census and original CRAN source.
Three R calls with explicitly supplied SE1e10 fail as computationally singular; preserve those outcomes.
Both algorithms depart from the 80-digit analytic component log density in boundary-small-SE; this is explicitly NOT source equivalence.
No upstream binary, patient data, public user-analysis workflow, learned covariance certificate or whole-paper reproduction.
Required action: retain failure/warning files and respect native numerical admission; never infer missing directions or treat this as full mashr integration.
