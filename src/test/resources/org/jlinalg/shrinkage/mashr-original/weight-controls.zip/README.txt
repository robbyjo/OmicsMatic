Original mashr0.2.79 / ashr2.2-63 optimizer controls.
All inputs are complete original Gaussian likelihood matrices, with uniform or nullbiased Dirichlet priors.
Original mixEM uses SQUAREM acceleration; native plain EM is compared by concave objective and a dual-gap certificate, not iteration identity or nonidentified weights.
No covariance learning, automatic training-population selection, patient data or public user-analysis workflow.
Required action: retain source convergence values, independent dual gaps and any warnings; an iteration limit is never a convergence certificate.
