#!/bin/bash -ue
awk 'BEGIN{n=0;gc=0} !/^>/{s=toupper($0);n+=length(s);gsub(/[^GC]/,"",s);gc+=length(s)} END{printf "%s\t%d\t%d\n","c",n,gc}' "c.fa" > "c.tsv"
