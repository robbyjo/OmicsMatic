#!/bin/bash -ue
cat *.tsv | LC_ALL=C sort > counts.tsv
