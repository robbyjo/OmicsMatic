import json,pysam,sys
from pathlib import Path
root=Path(sys.argv[1]);out=Path(sys.argv[2]);case=json.load(open(root/'cases.json'))[0]
with pysam.AlignmentFile(root/case['filtered_bam'],'rb') as bam:header=bam.header;records=list(bam.fetch(until_eof=True))
records[-1].mapping_quality=0
with pysam.AlignmentFile(out/'last-filtered-mapq.bam','wb',header=header) as writer:
 for record in records:writer.write(record)
with pysam.AlignmentFile(root/case['mapped_bam'],'rb') as bam:header=bam.header;records=list(bam.fetch(until_eof=True))
eligible=[r for r in records if r.is_unmapped and not r.is_secondary and not r.is_supplementary];assert len(eligible)>1;eligible[-1].query_name=eligible[0].query_name
with pysam.AlignmentFile(out/'nonunique-mapped-query.bam','wb',header=header) as writer:
 for record in records:writer.write(record)
