# Fastp process requires complete scientific output audit

Process execution completed. Its exit code does not admit a scientific result; complete the prepared input/output audit.

Required action: preserve this directory, stdout, stderr and process ledger. Admit results only after the complete scientific output audit. Correct any failure and rerun to a new output directory.
