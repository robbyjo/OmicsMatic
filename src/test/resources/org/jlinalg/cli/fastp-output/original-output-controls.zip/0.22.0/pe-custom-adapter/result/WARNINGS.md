# fastp original processing: output audit still required

**No completed scientific result is admitted by this process stage.** Require complete FASTQ,
paired-population, original report and transformation audits before publishing any result.
Raw inputs, original headers, compression bytes, qualities, options and outputs remain retained.
Quality encoding, plus-header, alphabet and mate-identity policies are explicit. Ordinal-only
pairing is unverified. Literal noncanonical bases and ignored plus-name mismatches need review.

Source defaults depend on edition and input headers. No omitted paper options,barcode position,
patch version or biological correctness is inferred. The source Bloom deduplicator is probabilistic;
accuracy6 needs24GiB for its buffer plus overhead. Never silently lower requested accuracy.
Hard process limits and sampled RSS checks are not an OS sandbox or a whole-host-memory guarantee.

Required action: inspect all input/statistics/runtime/process records and raw outputs. Preserve
failures and partials,correct the named cause and use NEW paths. If a required install/execution
prerequisite is unavailable or forbidden,skip dependent analysis. Cell Ranger remains excluded.
