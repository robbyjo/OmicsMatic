# TwoSampleMR warnings and required actions

Status: completed-with-warnings

Read WARNINGS.md, analysis-status.json, worker/report.json, worker/warnings.txt and original logs. SKIP3: dependent analysis skipped; restore the named exact permitted input/runtime/package or retain the skip. Downloads/private installs are allowed where permitted. FAIL2: NO COMPLETE RESULT; preserve inputs, full original returns/errors, partials and diagnostics, correct data/design, convergence, integrity, capacity or process causes and retry NEW output. No silent identity, population, version, unit, threshold, nonfinite or estimator substitution. DEVELOPMENT_SCOPE: exact original TwoSampleMR0.7.14 commit c08ab8a6 on R4.6.1, prepared canonical package tables, allele harmonization, original mr aggregation and requested sensitivity methods, and multivariable harmonization. Original namespace functions are source/body/formal guarded and not rewritten. Full return/error objects and inputs remain in RDS; exported tables support offline integrity, literal-intake and selected deterministic native-statistic checks. VERIFY does not parse binary RDS, refit stochastic estimators, authenticate coordinated replacements or establish author editions. Local LD clumping, remote data access, historical editions, global registration and catalog admission remain open. Capacities are logical/monitored, not OS quotas.

## Original and adapter warnings

FAIL2: NO COMPLETE RESULT. Retain inputs, full original returns/errors, partials and logs; correct the named input/design, numerical, integrity, capacity or process cause and retry NEW output. SKIP3: restore the exact permitted named prerequisite or retain the dependent-analysis skip. Downloads/private installs remain allowed where permitted. No version, population, unit, threshold, identifier or estimator substitution.

Original multivariable member outcome_pval is NULL; it remains absent, with no imputed values
