# fastp scoped result: warnings require review

PAIRED_FAILURE_OMISSION: the original source emits neither mate when both fail. Unrepresented pairs can therefore be failed pairs or duplicate suppression;these are not identified as duplicates from absence alone. Their source counter gaps and possible failure envelopes are constrained.

CORRECTION_COUNTER_SCOPE: source counters also include corrected bases later trimmed,filtered or suppressed. Visible output changes are checked lower bounds,not a recomputed whole-source correction total.

PAIRED_DUPLICATE_RATE: source rate constrains suppressed pair count within printed precision;remaining absent pairs failed both mates. Their individual occurrence causes are not uniquely assigned.

BLOOM_SCOPE: observed suppression is not proof of exact identical-sequence duplication. The source Bloom estimate/suppression and its thread behavior remain upstream.

INSERT_SIZE_SCOPE: original histograms use thread0 and eligible paired reads;they are not a complete all-pair distribution.

AUDIT_SCOPE: complete captured populations,source filtering/disposition constraints,quality-cut/prefix/correction envelopes and full per-cycle/five-mer report statistics. Upstream adapter/overlap selection,poly-tail algorithms,Bloom simulation and biological accuracy are not independently reproduced.

PORTABLE_SCOPE: verification recomputes every declared captured population,report statistic and conservation envelope. It does not rerun fastp,readmit the recorded host,prove source-to-binary reproduction,authenticate an execution record,or certify biological accuracy. Original HTML/stdout/stderr are retained raw supplements.

RAW_STAGE_HISTORY: processing/stage.json and processing/WARNINGS.md are preserved provisional original-stage records. Only the top-level COMPLETED.json with successful fastp-tools --verify admits this scoped result.

Required action: inspect top-level WARNINGS.md,recipe-request/replay.json,processing/input-statistics.json,audit/output-audit.json,audit/read-dispositions.tsv and original reports. Require valid COMPLETED.json plus fastp-tools --verify DIRECTORY before downstream use. The admitted scope is complete populations,source report statistics and conservative transformation/conservation envelopes;upstream adapter/poly-tail/overlap/Bloom choices and biological accuracy are not independently reproduced. Missing paired reads can reflect failure of both mates or duplicate suppression. Original insert-size histograms sample thread0;0.22.0 duplicate buffers/counters are non-atomic. Exact supported Linux x86_64 runtime,completed matching setup report and permitted helpers are required for execution;portable verification uses Java and bounded scratch only. Install/download only where permitted using explicit installer flags. SKIP3 means unavailable/forbidden runtime,capability or requested duplicate-memory reservation: skip dependent analysis and resolve the named cause/use an adequate supported host. Accuracy6 needs24GiB Bloom buffer plus overhead;never silently lower requested accuracy or guess a missing edition,barcode position or paper option. FAIL2 means invalid input,integrity,process,capacity,cancellation or finalization failure:no result is admitted. Preserve raw/partial outputs and diagnostics,correct the named cause and retry to NEW output paths. Increase explicit capacities and Java heap only where resources permit;never truncate a population. Setup-only completion,exit zero and provisional stage records do not admit user results. Portable verification does not rerun upstream processing,readmit the producer host or authenticate execution history. Hashes establish integrity,not authenticity. Cell Ranger remains excluded.
