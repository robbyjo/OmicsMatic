# Original mashr workflow warnings

- SKIP3_DEPENDENCY_UNAVAILABLE: Required original package unavailable: mashr

Required action: preserve this output, inputs, original logs and fitted models. Correct the named input, numerical or convergence failure; repeat into a NEW directory. If the exact R/package dependencies cannot be installed in a permitted environment, keep the dependent analysis skipped. This original-process result is not admitted until the independent Java and bundle audits pass.
