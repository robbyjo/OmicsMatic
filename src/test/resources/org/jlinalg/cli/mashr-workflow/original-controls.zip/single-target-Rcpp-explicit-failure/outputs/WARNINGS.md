# Original mashr workflow warnings

- FAIL2_NO_RESULT_ADMITTED: SOURCE_RCPP_SINGLE_FEATURE_UNAVAILABLE: the inspected mashr0.2.79 native posterior path can abort for one feature with multiple retained components. The original R wrapper also has singleton dimension failures. Use the tested MashGaussian/MashMixtureWeights Java API while integrated native singleton execution is completed; preserve the original failures. No rows are padded or silently rerouted.

Required action: preserve this output, inputs, original logs and fitted models. Correct the named input, numerical or convergence failure; repeat into a NEW directory. If the exact R/package dependencies cannot be installed in a permitted environment, keep the dependent analysis skipped. This original-process result is not admitted until the independent Java and bundle audits pass.
