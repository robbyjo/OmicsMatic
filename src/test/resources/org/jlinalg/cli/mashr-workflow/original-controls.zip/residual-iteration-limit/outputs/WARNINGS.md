# Original mashr workflow warnings

- FAIL2_NO_RESULT_ADMITTED: RESIDUAL_EM_TERMINATION_UNPROVEN: source counter reached the declared limit; preserve the returned model and increase the limit before admission

Required action: preserve this output, inputs, original logs and fitted models. Correct the named input, numerical or convergence failure; repeat into a NEW directory. If the exact R/package dependencies cannot be installed in a permitted environment, keep the dependent analysis skipped. This original-process result is not admitted until the independent Java and bundle audits pass.
