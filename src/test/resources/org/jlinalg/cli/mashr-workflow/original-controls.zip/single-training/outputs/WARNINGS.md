# Original mashr workflow warnings

- ORIGINAL_R_WARNING: representative-training-mixture-fit Only one column of "L" has positive entries; this corresponds to the trivial solution "x" in which x[i] = 1 for one column i, and all other entries of "x" are zero. No optimization algorithm was needed.
- ORIGINAL_R_WARNING: representative-training-mixture-fit longer object length is not a multiple of shorter object length
- SOURCE_R_SINGLE_FEATURE_DIMENSION: The inspected original R wrapper has a singleton likelihood/posterior dimension failure. Input observations remain unchanged. Use the tested MashGaussian/MashMixtureWeights Java API; integrated native singleton execution is still pending. Preserve this source error and the returned training model when available.
- FAIL2_NO_RESULT_ADMITTED: dims [product 3] do not match the length of object [41]

Required action: preserve this output, inputs, original logs and fitted models. Correct the named input, numerical or convergence failure; repeat into a NEW directory. If the exact R/package dependencies cannot be installed in a permitted environment, keep the dependent analysis skipped. This original-process result is not admitted until the independent Java and bundle audits pass.
