# Original mashr workflow warnings

- FAIL2_NO_RESULT_ADMITTED: ED_TERMINATION_UNPROVEN: logged iterations reached the declared limit; preserve learned candidates and increase the permitted limit before admission

Required action: preserve this output, inputs, original logs and fitted models. Correct the named input, numerical or convergence failure; repeat into a NEW directory. If the exact R/package dependencies cannot be installed in a permitted environment, keep the dependent analysis skipped. This original-process result is not admitted until the independent Java and bundle audits pass.
