# Original mashr workflow warnings

- ED_LOCAL_OPTIMUM: Original Bovy ED is a local fit. It reports no convergence flag; finite outputs and termination before the declared iteration limit are checked, and its six-decimal logs are retained. No global optimum is certified.
- SOURCE_RESIDUAL_EM_STOP: Original ad hoc residual EM can roll back after a likelihood decrease. Its source niter/history are retained verbatim; the history can omit the last accepted likelihood. Final-model likelihood is independently recomputed. No global residual-correlation convergence certificate is asserted.
- DECLARED_POPULATIONS: Only the explicitly flagged representative training, strong covariance-learning and target rows are used. Their selection is user supplied, not inferred or certified random by this adapter.

Required action: preserve this output, inputs, original logs and fitted models. Correct the named input, numerical or convergence failure; repeat into a NEW directory. If the exact R/package dependencies cannot be installed in a permitted environment, keep the dependent analysis skipped. This original-process result is not admitted until the independent Java and bundle audits pass.
