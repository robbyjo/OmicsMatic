# Original mashr workflow warnings

- SOURCE_R_SINGLE_FEATURE_DIMENSION: The inspected original R wrapper has a singleton likelihood/posterior dimension failure. Input observations remain unchanged. Use the tested MashGaussian/MashMixtureWeights Java API; integrated native singleton execution is still pending. Preserve this source error and the returned training model when available.
- FAIL2_NO_RESULT_ADMITTED: (subscript) logical subscript too long

Required action: preserve this output, inputs, original logs and fitted models. Correct the named input, numerical or convergence failure; repeat into a NEW directory. If the exact R/package dependencies cannot be installed in a permitted environment, keep the dependent analysis skipped. This original-process result is not admitted until the independent Java and bundle audits pass.
