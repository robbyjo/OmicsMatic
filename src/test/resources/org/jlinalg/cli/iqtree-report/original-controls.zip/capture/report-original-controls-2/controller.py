from pathlib import Path
import hashlib,json,os,signal,subprocess,time,shutil,stat
ROOT=Path('/mnt/d/projects/JLinAlg');BASE=ROOT/'build/literature-review/iqtree-runtime'
OUT=BASE/'report-original-controls-2';OUT.mkdir(exist_ok=False)
WORK=Path('/opt/omicsmatic-iqtree-setup-dev-1/report-original-controls-2');WORK.mkdir(exist_ok=False)
data=json.loads((BASE/'inference-original-controls-1/synthetic-data.json').read_bytes())['sequences']
data['DNA-mini']=dict(A='AC',B='AC',C='TC',D='TC')
positions=[i for i in range(480) if len({s[i] for s in data['DNA'].values()})>1]
data['DNA-ascertainment']=dict((k,''.join(s[i] for i in positions)) for k,s in data['DNA'].items())
(OUT/'datasets.json').write_text(json.dumps(dict(sequences=data,ascertainment_selected_zero_based_columns=positions,
    scope='Complete declared control datasets; no user-data filtering. The unchanged 480-site input is separately retained and refused for ASC.'),indent=2)+'\n')
lock_path=ROOT/'tools/literature/iqtree-runtime-lock.json';lock=json.loads(lock_path.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
shutil.copy2(__file__,OUT/'controller.py');shutil.copy2(lock_path,OUT/'runtime-lock.json')
cases=[(v,d,m,[],0) for v in ["1.6.12","2.4.0"] for d,m in [("DNA","JC+I"),("DNA","JC+F"),("DNA","GTR+FQ"),("AA","Poisson+FQ"),("DNA","HKY85"),("AA","LG+G")]]
def members(group):
    values=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:
            raw=(p/'stat').read_text();f=raw[raw.rfind(')')+2:].split()
            if int(f[2])==group and f[0]!='Z':values.append(int(p.name))
        except (OSError,ValueError):pass
    return values
records=[]
try:
    for index,(version,dataset,model,extra,expected) in enumerate(cases):
        profile=lock['profiles']['linux-x86_64-iqtree-'+version];home=Path('/opt/omicsmatic-iqtree-setup-dev-1/formal-matrix-1/homes')/version
        program=home/profile['program'];before=sha(program);assert before==profile['files'][profile['program']]['sha256']
        name=str(index+1).zfill(2)+'-'+version+'-'+dataset+'-'+model;directory=WORK/name;directory.mkdir()
        (directory/'alignment.fasta').write_text(''.join('>'+k+'\n'+s+'\n' for k,s in data[dataset].items()))
        command=['/usr/bin/prlimit','--as=4294967296','--cpu=180','--fsize=16777216','--nofile=128','--core=0','--',str(program),
                 '-s',str(directory/'alignment.fasta'),'-st',dataset.split('-')[0],'-m',model,'-wsl','-seed','61129','-nt','1','-pre',str(directory/'result'),*extra]
        reason=None;start=time.monotonic()
        with (directory/'stdout').open('xb') as stdout,(directory/'stderr').open('xb') as stderr:
            child=subprocess.Popen(command,cwd=directory,env=dict(PATH='/usr/bin:/bin',HOME=str(directory),TMPDIR=str(directory),LC_ALL='C',LANG='C',OMP_NUM_THREADS='1'),
                                   stdout=stdout,stderr=stderr,start_new_session=True)
            (OUT/'running.json').write_text(json.dumps(dict(status='running',pid=child.pid,controller_pid=os.getpid(),case=name,command=command),indent=2)+'\n')
            try:
                while os.waitid(os.P_PID,child.pid,os.WEXITED|os.WNOHANG|os.WNOWAIT) is None:
                    files=list(directory.iterdir())
                    if len(files)>128 or sum(p.stat().st_size for p in files if p.is_file())>67108864:reason='workspace-capacity';break
                    if time.monotonic()-start>240:reason='wall-capacity';break
                    time.sleep(.05)
            finally:
                if members(child.pid):os.killpg(child.pid,signal.SIGKILL)
                code=child.wait(timeout=10)
        assert members(child.pid)==[] and sha(program)==before
        pins={}
        for p in directory.iterdir():
            assert stat.S_ISREG(p.lstat().st_mode)
            pins[p.name]=dict(bytes=p.stat().st_size,sha256=sha(p))
        record=dict(name=name,version=version,dataset=dataset,model=model,extra=extra,expected_exit_code=expected,exit_code=code,
                    capacity_failure=reason,seconds=time.monotonic()-start,command=command,program_sha256=before,files=pins,owned_live_after_cleanup=[])
        records.append(record);(OUT/'observed.json').write_text(json.dumps(records,indent=2)+'\n')
        print(name,'exit',code,'expected',expected,'seconds',round(record['seconds'],2),flush=True)
        if code:print((directory/'stderr').read_text(errors='replace')[-600:],flush=True)
finally:
    shutil.copytree(WORK,OUT/'linux')
    (OUT/'running.json').write_text(json.dumps(dict(status='terminal',controller_pid=os.getpid(),protocols=len(records),work=str(WORK),
         all_expected=len(records)==len(cases) and all(p['exit_code']==p['expected_exit_code'] and p['capacity_failure'] is None for p in records)),indent=2)+'\n')
print('Terminal protocols:',len(records),flush=True)
