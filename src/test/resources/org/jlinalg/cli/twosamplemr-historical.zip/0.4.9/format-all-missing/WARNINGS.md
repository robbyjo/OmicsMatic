# TwoSampleMR warnings and required actions

Status: completed-with-warnings

Read WARNINGS.md, analysis-status.json, worker/report.json, worker/warnings.txt and original logs. SKIP3: dependent analysis skipped; restore the named exact permitted input/runtime/package or retain the skip. Downloads/private installs are allowed where permitted. FAIL2: NO COMPLETE RESULT; preserve inputs, full original returns/errors, partials and diagnostics, correct data/design, convergence, integrity, capacity or process causes and retry NEW output. No silent identity, population, version, unit, threshold, nonfinite or estimator substitution. DEVELOPMENT_SCOPE: exact tagged TwoSampleMR0.4.9/0.5.6/0.5.7/0.6.8 original namespace workflows on 64-bit WindowsR4.6.1 with declared present-day dependencies. FORMAT, harmonization, MR/sensitivity/modes and multivariable preparation retain full original returns/errors/RNG and all 146/149 function body/formal guards without rewriting. Source parameter defaults differ across editions and are preserved. The private0.4.9 reference build omits only broken man documentation; all R, namespace and data bytes remain original. VERIFY checks saved integrity, literal intake, source projections and deterministic native fields, not every provider estimate or coordinated replacement authentication. This does not reproduce the paper execution commit, dependency era or historical API reference data. Local/API clumping, historical R hosts, global registration and catalog admission are separate qualifications.

## Original and adapter warnings

FAIL2: NO COMPLETE RESULT. Retain inputs, full original returns/errors, partials and logs; correct the named input/design, numerical, integrity, capacity or process cause and retry NEW output. SKIP3: restore the exact permitted named prerequisite or retain the dependent-analysis skip. Downloads/private installs remain allowed where permitted. No version, population, unit, threshold, identifier or estimator substitution.

beta column is not numeric. Coercing...
se column is not numeric. Coercing...
eaf column is not numeric. Coercing...
pval column is not numeric. Coercing...
N column is not numeric
The following SNP(s) are missing required information for the MR tests and will be excluded
miss
None of the provided SNPs can be used for MR analysis, they are missing required information.
