# TwoSampleMR warnings and required actions

Status: completed-with-warnings

Read WARNINGS.md, analysis-status.json, worker/report.json, decisions.tsv and every original PLINK/R log. A singleton may bypass reference/significance checks; a complete empty selection has no downstream MR estimate. No silent SNP/allele/population, p-value, threshold, duplicate, version or estimator repair. FAIL2: NO COMPLETE RESULT; retain inputs, full available original returns/errors, raw reports, conditions and partials, correct the named data/design, numeric, integrity, capacity or process cause and retry NEW output. SKIP3: dependent analysis skipped; supply the named exact permitted runtime/input or retain the skip. Downloads/private installation are allowed where permitted; if prohibited, explain the specific restriction and skip the affected analysis. DEVELOPMENT_SCOPE: original TwoSampleMR0.6.8 806703f0 / ieugwasr1.2.1 ce5d0c07 / official PLINK1.9.0 20260927 on WindowsR4.6.1. Literal instrument rows and complete SNP-major BED/BIM/FAM are retained. Original grouping, singleton bypasses, source defaults, duplicates, P-value formatting and parsed-index coercions are preserved. Two ieugwasr functions receive observation prefixes with exact original-statement AST inverses; original cleanup follows artifact copies and bindings are restored. VERIFY checks integrity, literal intake/reference structure and source input/report/selection projections, not an independent refit of every LD likelihood or authentication of coordinated replacement. Original PLINK thread/memory defaults are retained. Native compatible clumping remains separate. The tagged0.6.8 source is bound by all149 function hashes, not an installed RemoteSha or proven paper execution commit. Dependencies are declared present-day versions; historical dependency-era reproduction, older API clumping, global registration and catalog admission remain open.

## Source behavior and required review

REFERENCE_POPULATION_DECLARED_ONLY: the supplied BED/BIM/FAM is used intact; the ancestry declaration is not inferred or verified. Review prepared.json and reference provenance before interpreting selection.
COMPLETE_EMPTY_SELECTION: zero instruments were returned. This is a completed filtering outcome, with no downstream MR estimate. Review source logs and identifiers; retain the outcome or retry explicitly revised inputs in NEW output.

## Original and adapter warnings

FAIL2: NO COMPLETE RESULT. Retain inputs, full original returns/errors, partials and logs; correct the named input/design, numerical, integrity, capacity or process cause and retry NEW output. SKIP3: restore the exact permitted named prerequisite or retain the dependent-analysis skip. Downloads/private installs remain allowed where permitted. No version, population, unit, threshold, identifier or estimator substitution.

Unknown or uninitialised column: `rsid`.
Unknown or uninitialised column: `id`.
COMPLETE_EMPTY_SELECTION: original clumping returned zero variants; no downstream MR estimate is available. Preserve this filtering outcome; do not substitute instruments.
