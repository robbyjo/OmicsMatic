args <- commandArgs(trailingOnly=TRUE)
stopifnot(as.character(getRversion()) == "3.6.2")
root <- args[1]
ref <- new.env();eval(parse(file.path(root,"lowess.R"),keep.source=FALSE),envir=ref)
stopifnot(identical(body(ref$lowess),body(stats::lowess)),identical(formals(ref$lowess),formals(stats::lowess)))
writeLines(capture.output(sessionInfo()),file.path(root,"original-sessionInfo.txt"))
cases <- list(
 singleton=list(x=3,y=-2,f=2/3,iter=3L,delta=0),
 two_unsorted=list(x=c(2,1),y=c(1,9),f=2/3,iter=3L,delta=0),
 repeats=list(x=c(2,1,1,2,3,3,3,4),y=c(1,10,-3,4,7,8,100,5),f=0.5,iter=3L,delta=0),
 all_ties=list(x=rep(1,7),y=c(1,2,3,4,5,6,100),f=0.25,iter=3L,delta=0),
 negative_zero_ties=list(x=c(0,-0,0,1,2),y=c(1,2,3,4,5),f=0.5,iter=3L,delta=0),
 robustness_outliers=list(x=seq_len(51),y=sin(seq_len(51)/7)+seq_len(51)/20,f=0.4,iter=3L,delta=0),
 no_robustness=list(x=seq_len(51),y=sin(seq_len(51)/7)+seq_len(51)/20,f=0.4,iter=0L,delta=0),
 delta_interpolation=list(x=rev(seq(0,20,by=0.1)),y=cos(rev(seq(0,20,by=0.1))),f=0.3,iter=3L,delta=0.37),
 wide_span=list(x=seq_len(19),y=sin(seq_len(19)),f=2.5,iter=3L,delta=0),
 narrow_neighborhood=list(x=seq_len(25),y=sin(seq_len(25)),f=0.00001,iter=3L,delta=0),
 exact_line=list(x=c(1,3,4,7,11,19,25),y=2*c(1,3,4,7,11,19,25)+3,f=2/3,iter=3L,delta=0),
 constant_y=list(x=seq_len(37),y=rep(1.25,37),f=0.5,iter=3L,delta=0),
 uneven_density=list(x=c(rep(0,10),seq(0.001,0.1,length.out=101),seq(1,20,length.out=31)),y=sin(c(rep(0,10),seq(0.001,0.1,length.out=101),seq(1,20,length.out=31))),f=0.3,iter=3L,delta=0.02),
 large_offset=list(x=1e12+seq(0,100,by=0.25),y=cos(seq(0,100,by=0.25)/20),f=0.3,iter=3L,delta=0),
 tiny_y=list(x=seq_len(37),y=1e-200*(2+sin(seq_len(37))),f=0.4,iter=3L,delta=0),
 subnormal_y=list(x=seq_len(37),y=seq_len(37)*1e-320,f=0.4,iter=3L,delta=0))
cases$robustness_outliers$y[c(10,31)] <- c(50,-100)
cases$no_robustness$y[c(10,31)] <- c(50,-100)
library(DESeq2)
stopifnot(as.character(packageVersion("DESeq2")) == "1.26.0")
e <- new.env(); load(file.path(root,"original-dds-rld.RData"),envir=e)
m <- metadata(results(e$dds,contrast=c("condition","SPT5_T0","SPT5_T15")))
cases$complete_deseq126_filter_curve <- list(x=m$filterNumRej$theta,y=m$filterNumRej$numRej,f=1/5,iter=3L,delta=0.01*diff(range(m$filterNumRej$theta)))
fmt <- function(x) sprintf("%.17g",x)
for (name in names(cases)) {
 c <- cases[[name]];directory <- file.path(root,name);dir.create(directory)
 expected <- stats::lowess(c$x,c$y,f=c$f,iter=c$iter,delta=c$delta)
 if (name == "complete_deseq126_filter_curve") stopifnot(identical(expected,m$lo.fit))
 write.table(data.frame(x=fmt(c$x),y=fmt(c$y)),file.path(directory,"input.tsv"),sep="\t",quote=FALSE,row.names=FALSE)
 write.table(data.frame(x=fmt(expected$x),fitted=fmt(expected$y),source_index=order(c$x)-1L),file.path(directory,"expected.tsv"),sep="\t",quote=FALSE,row.names=FALSE)
 write.table(data.frame(span=fmt(c$f),iterations=c$iter,delta=fmt(c$delta)),file.path(directory,"options.tsv"),sep="\t",quote=FALSE,row.names=FALSE)
}
writeLines(names(cases),file.path(root,"cases.txt"))
writeLines("PASS_ORIGINAL_R362_COMPLETE_LOWESS_FIXTURES")
