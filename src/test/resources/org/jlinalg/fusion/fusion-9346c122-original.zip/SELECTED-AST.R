list(allele_function = allele.qc = function(a1, a2, ref1, ref2) {
    a1 = toupper(a1)
    a2 = toupper(a2)
    ref1 = toupper(ref1)
    ref2 = toupper(ref2)
    ref = ref1
    flip = ref
    flip[ref == "A"] = "T"
    flip[ref == "T"] = "A"
    flip[ref == "G"] = "C"
    flip[ref == "C"] = "G"
    flip1 = flip
    ref = ref2
    flip = ref
    flip[ref == "A"] = "T"
    flip[ref == "T"] = "A"
    flip[ref == "G"] = "C"
    flip[ref == "C"] = "G"
    flip2 = flip
    snp = list()
    snp[["keep"]] = !((a1 == "A" & a2 == "T") | (a1 == "T" & 
        a2 == "A") | (a1 == "C" & a2 == "G") | (a1 == "G" & a2 == 
        "C"))
    snp[["keep"]][a1 != "A" & a1 != "T" & a1 != "G" & a1 != "C"] = F
    snp[["keep"]][a2 != "A" & a2 != "T" & a2 != "G" & a2 != "C"] = F
    snp[["flip"]] = (a1 == ref2 & a2 == ref1) | (a1 == flip2 & 
        a2 == flip1)
    return(snp)
}, NA_weight_normalization = wgt.matrix[is.na(wgt.matrix)] = 0, 
    zero_weight_guard = if (sum(wgt.matrix[, mod.best] != 0) == 
        0) {
        cat("WARNING : ", unlist(wgtlist[w, ]), names(cv.performance)[mod.best], 
            "had", length(cur.Z), "overlapping SNPs, but none with non-zero expression weights, try more SNPS or a different model\n")
        cur.FAIL = TRUE
    }, top1_selection = if (substr((colnames(cv.performance))[mod.best], 
        1, 4) == "top1") wgt.matrix[-which.max(wgt.matrix[, mod.best]^2), 
        mod.best] = 0, LD = cur.LD = t(cur.genos) %*% cur.genos/(nrow(cur.genos) - 
        1), imputation_association = if (length(cur.Z) == 0) {
        cat("WARNING : ", unlist(wgtlist[w, ]), " had no overlapping SNPs\n")
        cur.FAIL = TRUE
        out.tbl$NSNP[w] = NA
    } else if (!cur.FAIL) {
        cur.LD = t(cur.genos) %*% cur.genos/(nrow(cur.genos) - 
            1)
        out.tbl$NSNP[w] = nrow(cur.LD)
        cur.miss = is.na(cur.Z)
        if (sum(cur.miss) != 0) {
            if (sum(!cur.miss) == 0) {
                cat("WARNING : ", unlist(wgtlist[w, ]), "had no overlapping GWAS Z-scores, skipping this gene\n")
                cur.FAIL = TRUE
            }
            else if (mean(cur.miss) > opt$max_impute) {
                cat("WARNING : ", unlist(wgtlist[w, ]), "had", 
                  sum(cur.miss), "/", length(cur.miss), "non-overlapping GWAS Z-scores, skipping this gene.\n")
                cur.FAIL = TRUE
            }
            else {
                cur.wgt = cur.LD[cur.miss, !cur.miss] %*% solve(cur.LD[!cur.miss, 
                  !cur.miss] + 0.1 * diag(sum(!cur.miss)))
                cur.impz = cur.wgt %*% cur.Z[!cur.miss]
                cur.r2pred = diag(cur.wgt %*% cur.LD[!cur.miss, 
                  !cur.miss] %*% t(cur.wgt))
                cur.Z[cur.miss] = cur.impz/sqrt(cur.r2pred)
                all.r2pred = rep(1, length(cur.Z))
                all.r2pred[cur.miss] = cur.r2pred
                if (sum(is.na(all.r2pred)) != 0) {
                  cat("WARNING : ", unlist(wgtlist[w, ]), "had missing GWAS Z-scores that could not be imputed, skipping this gene.\n")
                  cur.FAIL = TRUE
                }
                else if (mean(all.r2pred[wgt.matrix[, mod.best] != 
                  0]) < opt$min_r2pred) {
                  cat("WARNING : ", unlist(wgtlist[w, ]), "had mean GWAS Z-score imputation r2 of", 
                    mean(all.r2pred[wgt.matrix[, mod.best] != 
                      0]), "at expression weight SNPs, skipping this gene.\n")
                  cur.FAIL = TRUE
                }
            }
        }
        if (!cur.FAIL) {
            cur.twasz = wgt.matrix[, mod.best] %*% cur.Z
            cur.twasr2pred = wgt.matrix[, mod.best] %*% cur.LD %*% 
                wgt.matrix[, mod.best]
            if (cur.twasr2pred > 0) {
                cur.twas = cur.twasz/sqrt(cur.twasr2pred)
                if (!is.na(opt$perm) && opt$perm > 0 && cur.twas^2 > 
                  permz^2) {
                  perm.twas = rep(NA, opt$perm)
                  perm.pval = NA
                  for (i in 1:opt$perm) {
                    perm.wgt = wgt.matrix[sample(nrow(wgt.matrix)), 
                      mod.best]
                    perm.twas[i] = perm.wgt %*% cur.Z/sqrt(perm.wgt %*% 
                      cur.LD %*% perm.wgt)
                    if (sum(perm.twas[1:i]^2 > cur.twas[1]^2) > 
                      10) {
                      perm.pval = (sum(perm.twas[1:i]^2 > cur.twas[1]^2) + 
                        1)/(i + 1)
                      perm.N = i + 1
                      (break)()
                    }
                  }
                  if (is.na(perm.pval)) {
                    perm.pval = sum(perm.twas^2 > cur.twas[1]^2)/opt$perm
                    perm.N = opt$perm
                    anal.zscore = (cur.twas[1] - 0)/sd(perm.twas, 
                      na.rm = T)
                  }
                  else {
                    anal.zscore = NA
                  }
                  out.tbl$PERM.PV[w] = perm.pval
                  out.tbl$PERM.N[w] = perm.N
                  out.tbl$PERM.ANL_PV[w] = 2 * pnorm(abs(anal.zscore), 
                    lower.tail = F)
                }
            }
            else {
                cur.FAIL = T
                cat("WARNING : ", unlist(wgtlist[w, ]), " had zero predictive accuracy, try a different model.\n")
            }
        }
    }, result_output = if (!cur.FAIL) {
        out.tbl$NWGT[w] = sum(wgt.matrix[, mod.best] != 0)
        out.tbl$TWAS.Z[w] = cur.twas
        out.tbl$TWAS.P[w] = 2 * (pnorm(abs(out.tbl$TWAS.Z[w]), 
            lower.tail = F))
    } else {
        out.tbl$TWAS.Z[w] = NA
        out.tbl$TWAS.P[w] = NA
    })
