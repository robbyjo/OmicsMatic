catchSalmon <- function(paths,DGEList=FALSE,divide=FALSE,verbose=TRUE)
#	Read transcriptwise counts and bootstrap samples from Salmon output.
#	Use Gibbs or bootstrap samples to estimate overdispersion of transcriptwise counts.
#	Gordon Smyth and Pedro Baldoni
#	Created 1 April 2018. Last modified 20 Apr 2026.
{
	NSamples <- length(paths)

#	Use jsonlite and readr packages for reading
	OK <- requireNamespace("jsonlite",quietly=TRUE)
	if(!OK) stop("jsonlite package required but is not installed (or can't be loaded)")
	OK <- requireNamespace("readr",quietly=TRUE)
	if(!OK) stop("readr package required but is not installed (or can't be loaded)")

#	Initialize vector of inferential sample types
	ResampleType <- rep_len("",NSamples)

#	Accumulate counts and CV^2 of bootstrap counts for each sample
	for (j in 1L:NSamples) {
		if(verbose) cat("Reading ",paths[j],", ",sep="")

#		File locations
		MetaFile <- file.path(paths[j],"aux_info","meta_info.json")
		QuantFile <- file.path(paths[j],"quant.sf")
		BootFile <- file.path(paths[j],"aux_info","bootstrap","bootstraps.gz")
		if(!file.exists(QuantFile)) {
			QuantFile <- dir(paths[j],pattern="^quant.sf",full.names=TRUE)
			if(length(QuantFile)) QuantFile <- QuantFile[1]
			if(!file.exists(QuantFile)) {
				stop("quant.sf file not found at specified path")
			}
		}

#		Meta information
		Meta <- jsonlite::fromJSON(MetaFile)
		NTx <- Meta$num_targets
		if(is.null(NTx)) NTx <- Meta$num_valid_targets
		if(is.null(NTx)) stop("Can't find number of targets")
		NBoot <- Meta$num_bootstraps
		if(is.null(NBoot)) stop("Can't find number of bootstraps")
		Type <- Meta$samp_type
		if(is.null(ResampleType)) Type <- "bootstrap" else ResampleType[j] <- Type
		if(verbose) cat(NTx,"transcripts,",NBoot,Type,"samples\n")

#		Read counts and lengths
		if(j == 1L) {
			Counts <- Length <- matrix(0,NTx,NSamples)
			DF <- rep_len(0L,NTx)
			OverDisp <- rep_len(0,NTx)
			Quant1 <- suppressWarnings(readr::read_tsv(QuantFile,col_types="cdd_d",progress=FALSE))
			Counts[,1L] <- Quant1$NumReads	
			Length[,1L] <- Quant1$EffectiveLength
		} else {
			Quant <- suppressWarnings(readr::read_tsv(QuantFile,col_types="__d_d",progress=FALSE))
			Counts[,j] <- Quant$NumReads
			Length[,j] <- Quant$EffectiveLength
		}

#		Bootstrap samples
		if(NBoot > 0L) {
			BootFileCon <- gzcon(file(BootFile,open="rb"))
			Boot <- readBin(BootFileCon,what="double",n=NTx*NBoot)
			close(BootFileCon)
			dim(Boot) <- c(NTx,NBoot)
			M <- rowMeans(Boot)
			i <- (M > 0)
			OverDisp[i] <- OverDisp[i] + rowSums((Boot[i,]-M[i])^2) / M[i]
			DF[i] <- DF[i]+NBoot-1L
		}
	}
	
# Compute length statistics
	LTxL <- log(Length)
	AveTxLength <- exp(rowMeans(LTxL))
	MinLLen <- apply(LTxL, 1, min)
	MaxLLen <- apply(LTxL, 1, max)
	RangeTxLength <- exp(MaxLLen - MinLLen)

#	Estimate overdispersion for each transcript
	i <- (DF > 0L)
	if(sum(i) > 0L) {
		OverDisp[i] <- OverDisp[i] / DF[i]
#		Apply a limited amount of moderation
		DFMedian <- median(DF[i])
		DFPrior <- 3
		OverDispPrior <- median(OverDisp[i]) / qf(0.5,df1=DFMedian,df2=DFPrior)
		if(OverDispPrior < 1) OverDispPrior <- 1
		OverDisp[i] <- (DFPrior * OverDispPrior + DF[i]*OverDisp[i]) / (DFPrior + DF[i])
		OverDisp <- pmax(OverDisp,1)
		OverDisp[!i] <- OverDispPrior
	} else {
		OverDisp[] <- NA_real_
		OverDispPrior <- NA_real_
	}

#	Prepare output
	Quant1 <- as.data.frame(Quant1,stringsAsFactors=FALSE)
	dimnames(Counts) <- list(Quant1$Name,paths)
	row.names(Quant1) <- Quant1$Name
	Quant1$Name <- Quant1$EffectiveLength <- Quant1$NumReads <- NULL
	Quant1$AveLength <- AveTxLength
	Quant1$Max2MinLength <- RangeTxLength
	Quant1$Overdispersion <- OverDisp

#	Divided counts
	if(divide) Counts <- Counts / Quant1$Overdispersion

	if(DGEList) {
	  y  <- DGEList(count=Counts,genes=Quant1)
	  y$overdispersion.prior <- OverDispPrior
	  y$resample.type <- ResampleType
	  y$divided.counts <- divide
	} else {
	  y <- list(counts=Counts,annotation=Quant1,overdispersion.prior=OverDispPrior,resample.type=ResampleType,divided.counts=divide)
	}
	
	y
}

.imputeEffectiveLengths <- function(Length,EffLen)
#	Reset any effective length equal to actual length to 
#	minimum effective length across samples.
#	Gordon Smyth
#	7 Sep 2026.
{
	i <- which(Length - EffLen < 0.5)
	if(length(i)) {
		irow <- ((i-1L) %% length(Length)) + 1L
		icol <- ceiling(i / length(Length))
		irowu <- sort(unique(irow))
		EffLen2 <- EffLen[irowu,,drop=FALSE]
		k <- match(irow,irowu)
		i2 <- k + (icol-1L)*nrow(EffLen2)
		EffLen2[i2] <- NA
		m <- suppressWarnings(apply(EffLen2,1,min,na.rm=TRUE))
		m[!is.finite(m)] <- 1
		EffLen[i] <- m[k]
	}
	EffLen
}
