# Warnings and required actions

This bounded original-runtime profile executes exact official Sambamba
0.6.6 or0.8.2 Linux-amd64 binaries. Use Java inside a permitted Linux/WSL
environment. Requests declare every supported scientific/resource option.
Software is not installed during analysis. Supply exact permitted missing
binaries/helpers/libraries; skip dependent analysis when unavailable.

Marking retains records and changes duplicate flags. Removal additionally
executes the original removal operation on the same captured input; the
original marked companion remains retained. Native audits check all BAM
record bytes except the permitted duplicate bit, complete retained records
after removal, reference dictionaries, source header metadata and raw aux
representations. They do not independently classify duplicate molecules.
VERIFY reruns the exact original classifier and compares complete records
and headers, allowing only each checked exact command string to differ.

Original0.8.2 deliberately writes BAM header VN:1.0; preserve it alongside
the observed0.8.2 executable identity. Missing quality byte255 is not zero.
Existing secondary/supplementary duplicate flags persist; primary flags
are recomputed. This is not UMI-aware marking. Equal-score/spill behavior
remains original. No paper edition is substituted or author flags inferred.
P110 removed duplicates with0.6.6; P198 marked them with0.8.2 after donor
aggregation. Their complete parameters and binary builds remain unknown.

Generated BAI files are retained collateral, without independent index
qualification. For index-dependent downstream analysis, use a separately
qualified indexer/verification procedure. This profile admits the selected
BAM duplicate operation, not an independently qualified BAI or whole paper.

Input/output BAM audit bounds:64 MiB compressed,256 MiB decoded, one million
records,16 MiB per record,4 MiB header, fewer than16384 references. Standard
coordinate-sorted short-read BAM only; long-CIGAR CG and nonstandard aux
types are refused. Do not truncate or arbitrarily split duplicate families
to fit a bound; use a separately qualified larger-capacity workflow.

setpriv requests parent-death KILL and prlimit enforces child RLIMIT_AS.
wall_ms is per original mark/remove stage, including startup/PID recording.
Metadata probes have fixed10-second/512-MiB bounds. RSS and workspace bytes
and entry counts are sampled; work_mb/max_files are not an OS disk quota.
Java audit memory is separate; use sufficient JVM heap. No filesystem or
network isolation is claimed. All original consoles and partials remain.

SKIP3: named execution prerequisite unavailable; skip dependent analysis,
supply the permitted runtime and retry NEW output. FAIL2: invalid input,
source/runtime/request contradiction, original error, limit or recording
failure; no accepted result. Read FAILURE.txt and raw phase consoles.
Require COMPLETED.properties and successful original-runtime VERIFY; file
presence, checksums or a native transition audit alone are insufficient.
Failed runs retain provisional files, and late completion markers are
invalidated. Existing bundles are never overwritten or repaired.

Integrity/replay is not authenticity, a reproducible binary build, biological
calibration or whole-tool/paper qualification. No catalog credit is added
by this profile alone; the full250-paper goal remains open.
