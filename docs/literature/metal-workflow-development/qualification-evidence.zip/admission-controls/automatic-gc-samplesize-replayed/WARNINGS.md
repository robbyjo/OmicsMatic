# Original METAL captured workflow: warnings and required actions

SOURCE-BUILD PROFILE. This executes a caller-supplied checksum-declared
original 2020-05-05 Linux x86_64 executable. Qualification is specific to
the saved source-build runtime and controls; a release label alone is
not a checksum or producer authentication. System loader/libraries and
the Java runtime are external prerequisites, with host metadata retained.
No software is downloaded or installed during analysis.

PRIVATE RUNTIME. Original source headers restrict redistribution. The
local bundle contains the captured executable and supplied notice. Keep
it private unless separate permission covers redistribution. Public
qualification must exclude original source, archives, binaries and bundled
author examples. Independently written adapter code is separate.

The literal nine-column prepared summaries and all requested settings
are explicit. Caller must establish the same hypothesis, trait units,
effective N, genome build and allele/strand conventions. No author command,
effective N, phenotype transformation or genome coordinate is inferred.
Paired mode covers single-base DNA alleles; non-allelic mode explicitly
declares common-direction gene/other units and needs recorded acceptance
of the original missing-allele-column warning. Palindromic SNPs require a
trustworthy shared strand declaration; original allele matching does not
establish that biological fact. Original warnings remain in raw consoles.

Every declared row and marker/study contribution is checked; missingness
between studies is explicit, not invalid-row omission. Incompatible
alleles, duplicate IDs, invalid numbers and nonfinite source results fail.
warning_policy=allow-recorded never permits dropped input contributions.
Limits refuse the complete population. The metadata estimate is not a
JVM heap guarantee; stat-only process monitoring can overshoot a byte
budget between polls and is not an operating-system disk quota.

Original log probabilities are BASE 10. Ordinary output preserves literal
positive scientific notation even if conversion to double underflows;
a literal zero probability is refused, not floored. Use log10 output in
a NEW request where supported. Effect/SE output uses original 12-decimal
print settings; an unrepresentable/nonpositive printed SE fails instead
of silently changing precision. Native weighted-Z natural-log inputs
belong to a different Java API and are not original METAL log input.

Optional post-meta GC reloads the original printed primary table in a
second original process, and thus retains that printed handoff precision.
Primary heterogeneity and pooled-frequency dispersion remain in native
summary columns and raw primary results; a second single aggregate does
not invent multi-cohort heterogeneity. Original overlap Weight, adjusted N
and caller-declared total N are distinct retained quantities. No true
biological overlap estimate is independently established by this adapter.

DeclaredN is the original custom-variable sum printed with SIX significant
digits, checked against the captured input sum at that precision. It is
not an exact unrounded participant count. With overlap and frequencies
enabled, original Freq1 can lie outside original MinFreq/MaxFreq: the
source uses its adjusted Weight in this calculation. A constant input
frequency of0.3 yields original Freq1=0.2573 in the overlap control.
FreqSE is retained as an original source field, not independently certified
frequency uncertainty. No range projection or silent mean repair is made.

VERIFY checks exact directory membership, method fingerprints, runtime
identity, process records and regenerated admission/summary/warning rows.
It never launches METAL. REPLAY actually reruns the captured typed workflow
in NEW output and requires original scientific tables and native summaries
to agree byte for byte. Integrity/replay are not producer authentication,
whole-paper replication or biological validation. Keep matching old readers
for historical bundles rather than refreshing their fingerprints.

SKIP3: dependent analysis skipped. Supply the named permitted original
2020-05-05 Linux x86_64 runtime, notice and system prerequisites, or leave
analysis skipped. No installation or historical-edition substitution is
implicit. FAIL2: no complete result. Read FAILURE.txt, native/WARNINGS.tsv
and both original consoles; preserve original inputs and partials, correct
the named cause, then use a NEW output directory. Never drop failed rows,
infer directions, floor P=0 or repair NaN/Inf to force admission.
