from pathlib import Path
p=Path('D:/projects/JLinAlg/build/metal_adapter_matrix_20261118.py');code=p.read_text(encoding='utf-8').replace("adapter-matrix-1'","adapter-matrix-3'").replace('adapter-build-2/jar/','adapter-build-4/jar/')
code=code.replace(' for i,rows in enumerate(data):'," if name=='large-fractional-n':\n  data[0][0]='M1 A C .2 - 1234567.89 .1 .2 +'\n  data[1][0]='M1 C A -.3 - 456789.12 .2 .6 +'\n for i,rows in enumerate(data):")
code=code.replace("('overlap-post-gc','overlap','1.1',False,('OFF','OFF'),'forbid')]","('overlap-post-gc','overlap','1.1',False,('OFF','OFF'),'forbid'),('large-fractional-n','stderr','1.1',False,('OFF','OFF'),'forbid')]")
code=code.replace(" print('ADMITTED',name,'rows',len(summary),flush=True)"," if name=='large-fractional-n':assert next(r for r in summary if r['marker']=='M1')['declared_total_n']=='1.69136e+06'\n print('ADMITTED',name,'rows',len(summary),flush=True)")
exec(compile(code,str(p)+'-3','exec'))
