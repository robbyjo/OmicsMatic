from pathlib import Path
import subprocess,json,hashlib,csv,time,os
a=Path('D:/projects/JLinAlg/build/high-impact-stats-1');out=a/'build/metal-1/adapter-matrix-1';out.mkdir();supplied=out/'supplied';supplied.mkdir();binary=a/'build/metal-1/build-original-1/native-build/bin/metal';jar=a/'build/metal-1/adapter-build-2/jar/omicsmatic-0.4.0.jar';distro='JLinAlg-Omics-SAIGE-20261026'
def linux(p):p=Path(p).absolute();return '/mnt/'+p.drive[0].lower()+'/'+p.as_posix()[3:]
def save(p,v):p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
def pin(p):
 with Path(p).open('rb') as f:return dict(bytes=Path(p).stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
header='MARKER\tALLELE1\tALLELE2\tEFFECT\tPVALUE\tN\tSTDERR\tFREQ\tSTRAND\n';notice=(a/'build/metal-1/adapter-smoke-1/supplied/NOTICE.txt').read_bytes();records=[]
def request(name,kind='stderr',post='OFF',frequency=False,gc=('OFF','OFF'),warning='forbid',**changes):
 folder=supplied/name;folder.mkdir();(folder/'NOTICE.txt').write_bytes(notice)
 if kind=='stderr':data=[['M1 A C .2 - 100 .1 .2 +','M2 C G -.1 - 100 .2 .3 +'],['M1 C A -.3 - 200 .2 .6 +','M3 G T .1 - 200 .2 .4 +']]
 elif kind=='gene-stderr':data=[['ENSG1 - - .2 - 100 .1 - +','ENSG2 - - -.1 - 100 .2 - +'],['ENSG1 - - .3 - 200 .2 - +','ENSG3 - - .1 - 200 .2 - +']]
 elif kind=='gene':data=[['ENSG1 - - + .05 100 - - +','ENSG2 - - - .01 100 - - +'],['ENSG1 - - + .1 200 - - +','ENSG3 - - - .2 200 - - +']]
 elif kind=='sample':data=[['M1 A C + .05 100 - .2 +','M2 C G - .01 100 - .3 +'],['M1 C A - .1 200 - .6 +','M3 G T - .2 200 - .4 +']]
 elif kind=='overlap':
  source=a/'build/metal-1/adapter-source-profiles-1/overlap';data=[(source/f'study{i}.tsv').read_text().splitlines()[1:] for i in [1,2]]
 else:raise ValueError(kind)
 for i,rows in enumerate(data):
  converted=[]
  for line in rows:
   f=line.split();assert len(f)==9
   if not frequency:f[7]='-'
   converted.append('\t'.join(f))
  (folder/f'study{i}.tsv').write_bytes((header+'\n'.join(converted)+'\n').encode())
 (folder/'STUDIES.tsv').write_bytes(('study\tfile\tgenomic_control\n'+''.join(f'study{i}\tstudy{i}.tsv\t{gc[i]}\n' for i in range(2))).encode())
 c=dict(executable=linux(binary),executable_sha256=pin(binary)['sha256'],notice='NOTICE.txt',release='2020-05-05',execution='allow',studies='STUDIES.tsv',scheme='STDERR' if 'stderr' in kind else 'SAMPLESIZE',allele_mode='none' if kind.startswith('gene') else 'paired',strand='OFF' if kind.startswith('gene') else 'ON',frequency='ON' if frequency else 'OFF',overlap='ON' if kind=='overlap' else 'OFF',z_cutoff='1' if kind=='overlap' else '-',heterogeneity='ON',output_probability='log10',post_genomic_control=post,warning_policy=warning,hypothesis='Synthetic caller-declared same hypothesis, compatible effect orientation and declared effective sample sizes',max_studies='10',max_rows='100000',max_metadata_bytes='50000000',max_bytes='50000000',max_files='500',max_line_bytes='65536',wall_ms='30000');c.update(changes)
 path=folder/'REQUEST.tsv';save_request(path,c);return path
def save_request(path,c):path.write_bytes(('key\tvalue\n'+''.join(k+'\t'+v+'\n' for k,v in sorted(c.items()))).encode())
def run(name,arguments,expected=0,windows=False,empty_path=False):
 java=['C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe','-cp',str(jar)] if windows else ['wsl','-d',distro,'--exec','/usr/bin/java','-cp',linux(jar)];cmd=java+['org.jlinalg.cli.MetalWorkflowCli',*arguments];save(out/(name+'.command.json'),cmd);start=time.monotonic()
 env=dict(os.environ)
 if empty_path:env['PATH']=''
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:p=subprocess.run(cmd,cwd=a,env=env,stdout=so,stderr=se,timeout=180)
 row=dict(name=name,exit_code=p.returncode,expected=expected,seconds=time.monotonic()-start);save(out/(name+'.PROCESS.json'),row);records.append(row);print(name,p.returncode,flush=True)
 if p.returncode!=expected:print((out/(name+'.stdout')).read_text(errors='replace')[-3000:],(out/(name+'.stderr')).read_text(errors='replace')[-3000:],flush=True)
 assert p.returncode==expected,(name,p.returncode,expected)
successes=[('stderr-basic','stderr','OFF',False,('OFF','OFF'),'forbid'),('stderr-frequency','stderr','OFF',True,('OFF','OFF'),'forbid'),('stderr-numeric-gc','stderr','OFF',False,('1.2','1.1'),'forbid'),('stderr-post-gc','stderr','1.2',True,('OFF','OFF'),'forbid'),('gene-samplesize','gene','OFF',False,('OFF','OFF'),'allow-recorded'),('gene-stderr','gene-stderr','OFF',False,('OFF','OFF'),'allow-recorded'),('samplesize-basic','sample','OFF',False,('OFF','OFF'),'forbid'),('samplesize-post-gc','sample','1.1',True,('OFF','OFF'),'forbid'),('overlap','overlap','OFF',True,('OFF','OFF'),'forbid'),('overlap-post-gc','overlap','1.1',False,('OFF','OFF'),'forbid')]
for name,kind,post,freq,gc,warnings in successes:
 req=request(name,kind,post,freq,gc,warnings);bundle=out/name
 run(name+'-run',['run','--request',linux(req),'--out',linux(bundle)])
 run(name+'-verify-linux',['verify','--bundle',linux(bundle)])
 run(name+'-verify-windows-no-path',['verify','--bundle',str(bundle)],windows=True,empty_path=True)
 run(name+'-replay',['replay','--bundle',linux(bundle),'--out',linux(out/(name+'-replayed'))])
 with (bundle/'native/summary.tsv').open(newline='') as f:summary=list(csv.DictReader(f,delimiter='\t'))
 assert len(summary)==(2000 if kind=='overlap' else 3)
 if post!='OFF':assert any(r['primary_het_df']=='1' for r in summary),name
 if kind=='overlap':assert all(r['declared_total_n']=='20000' and r['primary_weight']=='23317.00' and r['primary_overlap_adjusted_n']=='18341.50' for r in summary)
 if freq:assert any(float(r['primary_freq_se'])>0 for r in summary),name
 print('ADMITTED',name,'rows',len(summary),flush=True)
failures=[('forbidden',dict(execution='forbid'),3),('historical-edition',dict(release='2011-03-25'),3),('missing-runtime',dict(executable='/definitely-missing-original-metal'),3),('wrong-runtime-hash',dict(executable_sha256='0'*64),2),('row-capacity',dict(max_rows='3'),2),('metadata-capacity',dict(max_metadata_bytes='8192'),2),('byte-capacity',dict(max_bytes='100'),2),('entry-capacity',dict(max_files='3'),2)]
for name,changes,expected in failures:
 req=request(name,**changes);bundle=out/name;run(name,['run','--request',linux(req),'--out',linux(bundle)],expected);assert not (bundle/'COMPLETED.tsv').exists()
req=request('gene-warnings-forbidden','gene');run('gene-warnings-forbidden',['run','--request',linux(req),'--out',linux(out/'gene-warnings-forbidden')],2);assert not (out/'gene-warnings-forbidden/COMPLETED.tsv').exists()
req=request('timeout','overlap',wall_ms='1');run('timeout',['run','--request',linux(req),'--out',linux(out/'timeout')],2);assert not (out/'timeout/COMPLETED.tsv').exists()
run('windows-execution-unavailable',['run','--request',str(supplied/'stderr-basic/REQUEST.tsv'),'--out',str(out/'windows-unavailable')],3,windows=True)
save(out/'COMPLETED.json',dict(status='PASS_ORIGINAL_METAL_TYPED_WORKFLOW_MATRIX',success_profiles=len(successes),actual_java_main_launches=len(records),actual_replays=len(successes),windows_readonly_verifiers_with_empty_PATH=len(successes),runs=records));print('MATRIX_COMPLETE',len(records),flush=True)
