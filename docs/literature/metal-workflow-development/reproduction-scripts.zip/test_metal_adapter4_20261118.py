from pathlib import Path
p=Path('D:/projects/JLinAlg/build/test_metal_adapter_20261118.py');code=p.read_text(encoding='utf-8').replace("adapter-tests-1'","adapter-tests-4'").replace('adapter-build-1/jar/','adapter-build-4/jar/').replace('dict(tests=15,errors=0,failures=0,skipped=0)','dict(tests=16,errors=0,failures=0,skipped=0)');exec(compile(code,str(p)+'-4','exec'))
