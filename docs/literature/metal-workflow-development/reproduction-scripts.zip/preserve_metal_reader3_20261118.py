from pathlib import Path
import shutil,json,hashlib
a=Path('D:/projects/JLinAlg/build/high-impact-stats-1');folder=a/'docs/literature/metal-workflow-development';history=folder/'historical-reader3';history.mkdir()
for name in ['VALIDATION.json','qualification-evidence.zip']:
 source=folder/name;target=history/name;raw=source.read_bytes();target.write_bytes(raw);assert target.read_bytes()==raw;assert source.resolve().is_relative_to(folder.resolve());source.unlink()
notice=dict(status='HISTORICAL_READER3_SCOPE_SUPERSEDED_BY_SIX_SIGNIFICANT_DIGIT_N_AUDIT',cause='The source uses default %g (six significant digits) for custom DeclaredN. Reader3 allowed four significant digits and its diagnostic incorrectly named that the source precision.',scientific_inputs_or_results_rewritten=False,old_source_guards_refreshed=False,old_private_closure='build/metal-1/adapter-evidence-2',old_matching_reader='build/metal-1/adapter-build-3/jar/omicsmatic-0.4.0.jar',required_action='Keep this original qualification and matching reader. Current source requires a fresh qualification with a large/fractional-N control and a stricter six-significant-digit audit. Do not use reader3 to claim the new precision guarantee.')
(history/'SUPERSESSION.json').write_bytes((json.dumps(notice,indent=2)+'\n').encode());print(json.dumps(notice,indent=2))
