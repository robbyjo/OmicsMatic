from pathlib import Path
import json
b=Path('D:/projects/JLinAlg/build/high-impact-stats-1/build/metal-1');(b/'adapter-evidence-1/FAILURE.json').write_bytes((json.dumps(dict(status='RETAINED_INCOMPLETE_CLOSURE_PACKAGING_ATTEMPT',cause='Setup helper process receipts use label.PROCESS.json; the first archive assembler expected label-PROCESS.json.',all_26_copied_bundles_verified=True,source_or_scientific_outputs_changed=False,action='Preserve the complete copied bundles/reader and this failed closure attempt; assemble into a NEW private closure root with the correct receipt filenames.'),indent=2)+'\n').encode())
p=Path('D:/projects/JLinAlg/build/close_metal_adapter_20261118.py');code=p.read_text(encoding='utf-8').replace("adapter-evidence-1'","adapter-evidence-2'")
for label in ['configure','compile','official-tests','install']:code=code.replace(label+'-PROCESS.json',label+'.PROCESS.json')
exec(compile(code,str(p)+'-2','exec'))
