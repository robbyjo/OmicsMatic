from pathlib import Path
import subprocess,json,time,hashlib
a=Path('D:/projects/JLinAlg/build/high-impact-stats-1');out=a/'build/metal-1/setup-controls-1';out.mkdir();distro='JLinAlg-Omics-SAIGE-20261026';script=a/'tools/literature/metal_workflows/setup.py';upstream=a/'build/metal-1/upstream-1';archives=[p for p in upstream.glob('*.zip') if hashlib.sha256(p.read_bytes()).hexdigest()=='090cdaa8593812ec05484a1011e623f543235e49b2d10e9467b15d27c05f74f9'];assert len(archives)==1;cmake=a/'build/metal-1/build-original-1/cmake-runtime/cmake/data/bin/cmake';ctest=cmake.with_name('ctest');records=[]
def linux(p):p=Path(p).absolute();return '/mnt/'+p.drive[0].lower()+'/'+p.as_posix()[3:]
def run(name,cmd,expected):
 (out/(name+'.command.json')).write_bytes((json.dumps(cmd,indent=2)+'\n').encode());start=time.monotonic()
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:p=subprocess.run(cmd,cwd=a,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=600)
 row=dict(name=name,exit_code=p.returncode,expected=expected,seconds=time.monotonic()-start);(out/(name+'.PROCESS.json')).write_bytes((json.dumps(row,indent=2)+'\n').encode());records.append(row);print(name,p.returncode,flush=True)
 if p.returncode!=expected:print((out/(name+'.stdout')).read_text(errors='replace')[-3000:],(out/(name+'.stderr')).read_text(errors='replace')[-3000:],flush=True)
 assert p.returncode==expected,name
base=['wsl','-d',distro,'--exec','/usr/bin/python3','-B',linux(script)]
run('missing-cmake',base+['--out',linux(out/'missing-cmake'),'--cmake','/definitely-missing-cmake'],3)
run('windows-skipped',['C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe','-X','utf8','-B',str(script),'--out',str(out/'windows-skipped')],3)
run('prepare-private-runtime',base+['--out',linux(out/'prepared'),'--archive',linux(archives[0]),'--cmake',linux(cmake),'--ctest',linux(ctest),'--jobs','4'],0)
result=json.loads((out/'prepared/COMPLETED.json').read_bytes());assert result['original_source_files_unchanged']==136 and result['scientific_analysis_executed'] is False
(out/'COMPLETED.json').write_bytes((json.dumps(dict(status='PASS_PRIVATE_RUNTIME_SETUP_AND_PREREQUISITE_SKIPS',controls=records,prepared=result),indent=2)+'\n').encode());print('SETUP_CONTROLS_COMPLETE',flush=True)
