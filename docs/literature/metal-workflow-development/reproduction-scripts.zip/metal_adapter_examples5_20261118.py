from pathlib import Path
p=Path('D:/projects/JLinAlg/build/metal_adapter_examples_20261118.py');exec(compile(p.read_text(encoding='utf-8').replace("public-examples-1'","public-examples-5'").replace('adapter-build-3/jar/','adapter-build-6/jar/'),str(p)+'-5','exec'))
