from pathlib import Path
import json,hashlib,shutil,subprocess,os,time,zipfile,datetime
root=Path('D:/projects/JLinAlg');a=root/'build/high-impact-stats-1';b=a/'build/metal-1';closed=b/'adapter-evidence-1';closed.mkdir();dest=a/'docs/literature/metal-workflow-development';dest.mkdir(exist_ok=True);matrix=b/'adapter-matrix-2';advanced=b/'adapter-admission-controls-2';jar=b/'adapter-build-3/jar/omicsmatic-0.4.0.jar'
def pin(p):
 with Path(p).open('rb') as f:return dict(bytes=Path(p).stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
def rawpin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(p,v):p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
def kv(p):return dict(line.split('\t',1) for line in p.read_text(encoding='utf-8').splitlines()[1:])
bundles={}
for folder in matrix.iterdir():
 if folder.is_dir() and (folder/'COMPLETED.tsv').exists():bundles[folder.name]=folder
for name in ['automatic-gc-stderr','automatic-gc-samplesize']:
 for suffix in ['','-replayed']:bundles[name+suffix]=advanced/(name+suffix)
for mode in ['dna','gene']:bundles['public-'+mode]=b/'public-examples-2'/(mode+' example Ω')/'result'
assert len(bundles)==26
for name,source in bundles.items():shutil.copytree(source,closed/'bundles'/name)
(closed/'readers').mkdir();shutil.copyfile(jar,closed/'readers/omicsmatic-0.4.0.jar');reader=closed/'readers/omicsmatic-0.4.0.jar';readerpin=pin(reader)
checks=[]
for name in sorted(bundles):
 cmd=['C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe','-cp',str(reader),'org.jlinalg.cli.MetalWorkflowCli','verify','--bundle',str(closed/'bundles'/name)];folder=closed/'readonly-checks';folder.mkdir(exist_ok=True);save(folder/(name+'.command.json'),cmd)
 with (folder/(name+'.stdout')).open('xb') as so,(folder/(name+'.stderr')).open('xb') as se:p=subprocess.run(cmd,cwd=a,env=dict(os.environ,PATH=''),stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=90)
 checks.append(dict(bundle=name,exit_code=p.returncode));assert p.returncode==0,(name,(folder/(name+'.stderr')).read_text());print('CLOSED_VERIFY',name,flush=True)
save(closed/'READONLY-CHECKS.json',dict(status='PASS_ALL_26_COMPLETE_COPIED_BUNDLES_WITH_MATCHING_FROZEN_READER_AND_EMPTY_PATH',checks=checks,original_runtime_executed=False))
code=[p.relative_to(a).as_posix() for p in a.glob('src/main/java/org/jlinalg/cli/MetalWorkflow*.java')]+['src/test/java/org/jlinalg/cli/MetalWorkflowCliTest.java','tools/literature/metal_workflows/setup.py','tools/literature/metal_workflows/reviews.py','examples/metal-workflow/run-example.py']
for name in code:
 p=closed/'sources'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(a/name,p)
payload={}
def add(name,path):payload[name]=Path(path).read_bytes()
def tree(prefix,path,filter_private=False):
 for p in path.rglob('*'):
  rel=p.relative_to(path)
  if not p.is_file():continue
  if filter_private and ('runtime' in rel.parts or p.name.startswith('NOTICE')):continue
  if any(part in rel.parts for part in ['windows-classes','linux-classes','native-build','source','readers','cmake-runtime']):continue
  if p.suffix in ['.class','.jar','.zip','.whl'] and p.name not in []:continue
  add(prefix+'/'+rel.as_posix(),p)
# Public views deliberately omit the restricted runtime and notice. They are NOT standalone bundles.
for name in sorted(bundles):tree('bundle-views/'+name,closed/'bundles'/name,True)
for name,prefix in [('adapter-tests-3','packaged-tests'),('adapter-matrix-2','matrix-controls'),('adapter-admission-controls-2','admission-controls'),('adapter-source-profiles-1','direct-source-controls'),('public-examples-2','public-examples')]:tree(prefix,b/name,True)
tree('source-build',b/'adapter-build-3')
for n in ['SOURCE-FILES.json','COMPLETED.json','RUNTIME.tsv','configure-PROCESS.json','compile-PROCESS.json','official-tests-PROCESS.json','install-PROCESS.json']:add('private-runtime-setup/'+n,b/'setup-controls-2/prepared'/n)
add('private-runtime-setup/CONTROLS.json',b/'setup-controls-2/COMPLETED.json');add('role-reviews/ROLE-REVIEW-PREVIEW.json',dest/'ROLE-REVIEW-PREVIEW.json');add('readonly-checks/COMPLETED.json',closed/'READONLY-CHECKS.json')
for name in code:add('current-source/'+name,a/name)
for name in ['metal_adapter_matrix_20261118.py','metal_adapter_matrix2_20261118.py','metal_adapter_adversarial_20261118.py','metal_adapter_adversarial2_20261118.py','metal_adapter_examples_20261118.py','metal_adapter_examples2_20261118.py','test_metal_setup_20261118.py','test_metal_setup2_20261118.py','test_metal_adapter_20261118.py','test_metal_adapter3_20261118.py','metal_source_profiles_20261118.py','metal_review_preview_20261118.py','metal_review_preview2_20261118.py']:add('developer-scripts/'+name,root/'build'/name)
# Retain early controls and corrections without replacing their historical readers or fingerprints.
for path,prefix in [(b/'adapter-smoke-1','historical-smoke'),(b/'adapter-tests-1','historical-tests-1'),(b/'adapter-tests-2','historical-tests-2'),(b/'adapter-admission-controls-1','historical-readonly-copy-failure')]:tree(prefix,path,True)
for n in ['FAILURE.json','configure-PROCESS.json','compile-PROCESS.json','official-tests-PROCESS.json','install-PROCESS.json']:
 p=b/'setup-controls-1/prepared'/n
 if p.exists():add('historical-setup-attempt/'+n,p)
private_roots=['adapter-matrix-2','adapter-admission-controls-2','adapter-tests-3','adapter-build-3','setup-controls-1','setup-controls-2','public-examples-1','public-examples-2']
retained=dict(status='PRIVATE_LOCAL_RETENTION_REQUIRED',admitted_complete_copies=26,frozen_reader=readerpin,private_scope='All 26 complete copied bundles and matching reader are closed below. Runtime sources/builds and failed controls also remain at the named original private paths; they are not redistributed.',other_private_roots=private_roots,public_views_are_standalone_bundles=False,public_restricted_runtime_or_original_source_redistributed=False)
save(closed/'RETENTION.json',retained);add('RETENTION.json',closed/'RETENTION.json')
members={p.relative_to(closed).as_posix():pin(p) for p in closed.rglob('*') if p.is_file()}
index=dict(status='CLOSED_PRIVATE_METAL_ADMITTED_BUNDLES_AND_FROZEN_READER',payloads=members,admitted_bundles={name:dict(path='bundles/'+name,completion=kv(closed/'bundles'/name/'COMPLETED.tsv')) for name in sorted(bundles)},reader=dict(path='readers/omicsmatic-0.4.0.jar',pin=readerpin),created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),redistribution_permitted=False)
save(closed/'INDEX.json',index)
for name,value in members.items():assert pin(closed/name)==value,name
payload['PRIVATE-CLOSURE.json']=(json.dumps(dict(index=pin(closed/'INDEX.json'),reader=readerpin,logical_payloads=len(members),admitted_bundles=26,restricted_runtime_redistributed=False,public_views_are_standalone_bundles=False),indent=2)+'\n').encode()
manifest={name:rawpin(raw) for name,raw in payload.items()};payload['ENTRY-MANIFEST.json']=(json.dumps(dict(payloads=manifest),indent=2)+'\n').encode()
archive=dest/'qualification-evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for name,raw in sorted(payload.items()):z.writestr(name,raw)
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(payload)
 for name,raw in payload.items():assert z.read(name)==raw,name
import zipfile as zz
with zz.ZipFile(jar) as current,zz.ZipFile(b/'weighted-z-build-2/jar/omicsmatic-0.4.0.jar') as prior:
 shared=set(prior.namelist());assert shared<=set(current.namelist());assert all(current.read(n)==prior.read(n) for n in shared);added=sorted(set(current.namelist())-shared);assert added and all(n.startswith('org/jlinalg/cli/MetalWorkflow') for n in added)
validation=dict(status='PASS_ORIGINAL_METAL_TYPED_WORKFLOW_QUALIFICATION',source_guards={name:pin(a/name) for name in code},reader=readerpin,private_closed_index=pin(closed/'INDEX.json'),private_closed_payloads=len(members),admitted_complete_copied_bundles=26,private_readonly_verifications=26,windows_linux_junit=dict(tests=15,errors=0,failures=0,skipped=0),matrix_java_main_launches=51,admission_control_java_main_launches=22,public_example_java_main_launches=2,private_copied_bundle_verifier_launches=26,explicit_current_java_main_launches=101,current_success_profiles=12,source_stages_in_admitted_copies=sum(len(list((closed/'bundles'/name/'stages').iterdir())) for name in bundles),public_examples=2,source_build_helper_passed=True,official_source_files_unchanged=136,original_source_functions_patched=False,archive=pin(archive),indexed_public_payloads=len(manifest),preexisting_jar_members_unchanged=len(shared),new_jar_members=added,catalog_modified=False,new_family_credit=0,role_reviews_ready=24,whole_goal_complete=False,release_created=False,literature_pages_withheld=True,private_corpus_path=closed.relative_to(a).as_posix(),public_views_are_standalone_bundles=False,restricted_source_binary_or_author_examples_redistributed=False)
save(dest/'VALIDATION.json',validation);print(json.dumps({k:v for k,v in validation.items() if k not in ['source_guards','new_jar_members']},indent=2),flush=True)
