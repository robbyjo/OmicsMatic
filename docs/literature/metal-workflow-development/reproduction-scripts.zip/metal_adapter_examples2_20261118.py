from pathlib import Path
p=Path('D:/projects/JLinAlg/build/metal_adapter_examples_20261118.py');exec(compile(p.read_text(encoding='utf-8').replace("public-examples-1'","public-examples-2'"),str(p)+'-2','exec'))
