from pathlib import Path
import subprocess,json,time
a=Path('D:/projects/JLinAlg/build/high-impact-stats-1');out=a/'build/metal-1/public-examples-1';out.mkdir();distro='JLinAlg-Omics-SAIGE-20261026';runtime=a/'build/metal-1/setup-controls-2/prepared/RUNTIME.tsv';jar=a/'build/metal-1/adapter-build-3/jar/omicsmatic-0.4.0.jar';records=[]
def linux(p):p=Path(p).absolute();return '/mnt/'+p.drive[0].lower()+'/'+p.as_posix()[3:]
for mode in ['dna','gene']:
 target=out/(mode+' example Ω');cmd=['wsl','-d',distro,'--exec','/usr/bin/python3','-B',linux(a/'examples/metal-workflow/run-example.py'),'--runtime',linux(runtime),'--jar',linux(jar),'--out',linux(target),'--java','/usr/bin/java','--mode',mode];(out/(mode+'.command.json')).write_bytes((json.dumps(cmd,indent=2)+'\n').encode());start=time.monotonic()
 with (out/(mode+'.stdout')).open('xb') as so,(out/(mode+'.stderr')).open('xb') as se:p=subprocess.run(cmd,cwd=a,stdout=so,stderr=se,timeout=180)
 row=dict(mode=mode,exit_code=p.returncode,seconds=time.monotonic()-start);records.append(row);print(mode,p.returncode,(out/(mode+'.stdout')).read_text()[-1200:],(out/(mode+'.stderr')).read_text()[-1800:],flush=True);assert p.returncode==0
(out/'COMPLETED.json').write_bytes((json.dumps(dict(status='PASS_BOTH_COPYABLE_PUBLIC_EXAMPLES_WITH_FRESH_PRIVATE_SETUP_RUNTIME',controls=records,unicode_and_space_output_paths_tested=True),indent=2)+'\n').encode())
