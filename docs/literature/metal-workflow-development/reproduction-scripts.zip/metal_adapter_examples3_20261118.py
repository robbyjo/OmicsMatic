from pathlib import Path
p=Path('D:/projects/JLinAlg/build/metal_adapter_examples_20261118.py');exec(compile(p.read_text(encoding='utf-8').replace("public-examples-1'","public-examples-3'").replace('adapter-build-3/jar/','adapter-build-4/jar/'),str(p)+'-3','exec'))
