from pathlib import Path
p=Path('D:/projects/JLinAlg/build/test_metal_adapter_20261118.py');exec(compile(p.read_text(encoding='utf-8').replace("adapter-tests-1'","adapter-tests-3'").replace('adapter-build-1/jar/','adapter-build-3/jar/'),str(p)+'-3','exec'))
