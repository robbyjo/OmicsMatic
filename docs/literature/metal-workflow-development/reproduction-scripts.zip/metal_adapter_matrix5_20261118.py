from pathlib import Path
p=Path('D:/projects/JLinAlg/build/metal_adapter_matrix3_20261118.py');code=p.read_text(encoding='utf-8').replace("adapter-matrix-3'","adapter-matrix-5'").replace('adapter-build-4/jar/','adapter-build-6/jar/');exec(compile(code,str(p)+'-5','exec'))
