from pathlib import Path
import subprocess,json,time,os,hashlib
a=Path('D:/projects/JLinAlg/build/high-impact-stats-1');out=a/'build/metal-1/adapter-build-1';out.mkdir();rel=out.relative_to(a).as_posix();init=out/'private.gradle';init.write_bytes(("gradle.projectsEvaluated { rootProject.tasks.named('executableJar') { destinationDirectory.set(rootProject.layout.projectDirectory.dir('"+rel+"/jar')) } }\n").encode())
sources={}
for p in a.glob('src/main/java/org/jlinalg/cli/MetalWorkflow*.java'):
 name=p.relative_to(a).as_posix();raw=p.read_bytes();target=out/'sources'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);sources[name]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
(out/'SOURCES.json').write_bytes((json.dumps(sources,indent=2)+'\n').encode());cmd=[str(a/'gradlew.bat'),'--no-daemon','--no-parallel','--console=plain','-I',str(init),':compileJava',':executableJar'];(out/'command.json').write_bytes((json.dumps(cmd,indent=2)+'\n').encode());start=time.monotonic()
with (out/'stdout').open('xb') as so,(out/'stderr').open('xb') as se:p=subprocess.run(cmd,cwd=a,env=dict(os.environ,JAVA_HOME='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot'),stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=900)
(out/'PROCESS.json').write_bytes((json.dumps(dict(exit_code=p.returncode,seconds=time.monotonic()-start),indent=2)+'\n').encode());print('EXIT',p.returncode);print((out/'stdout').read_text(errors='replace')[-3000:]);print((out/'stderr').read_text(errors='replace')[-6000:]);assert p.returncode==0
(out/'COMPLETED.json').write_bytes((json.dumps(dict(status='PASS_INITIAL_ADAPTER_COMPILE_AND_PACKAGE_ONLY',source_files=len(sources),runtime_qualified=False),indent=2)+'\n').encode())
