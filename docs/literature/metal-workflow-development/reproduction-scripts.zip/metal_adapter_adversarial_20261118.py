from pathlib import Path
import json,subprocess,hashlib,shutil,zipfile,time,os,csv,random,math
a=Path('D:/projects/JLinAlg/build/high-impact-stats-1');out=a/'build/metal-1/adapter-admission-controls-1';out.mkdir();matrix=a/'build/metal-1/adapter-matrix-2';jar=a/'build/metal-1/adapter-build-3/jar/omicsmatic-0.4.0.jar';oldjar=a/'build/metal-1/adapter-build-1/jar/omicsmatic-0.4.0.jar';distro='JLinAlg-Omics-SAIGE-20261026';records=[]
def linux(p):p=Path(p).absolute();return '/mnt/'+p.drive[0].lower()+'/'+p.as_posix()[3:]
def save(p,v):p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
def pin(p):
 with Path(p).open('rb') as f:return dict(bytes=Path(p).stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
def readmap(p):
 rows=p.read_text().splitlines();assert rows[0]=='key\tvalue';return dict(line.split('\t',1) for line in rows[1:])
def writemap(p,c):p.write_bytes(('key\tvalue\n'+''.join(k+'\t'+v+'\n' for k,v in sorted(c.items()))).encode())
def run(name,args,expected=0,runtime=jar,windows=True):
 java=['C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe','-cp',str(runtime)] if windows else ['wsl','-d',distro,'--exec','/usr/bin/java','-cp',linux(runtime)];cmd=java+['org.jlinalg.cli.MetalWorkflowCli',*args];save(out/(name+'.command.json'),cmd);start=time.monotonic();env=dict(os.environ)
 if windows:env['PATH']=''
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:p=subprocess.run(cmd,cwd=a,env=env,stdout=so,stderr=se,timeout=180)
 row=dict(name=name,exit_code=p.returncode,expected=expected,seconds=time.monotonic()-start);save(out/(name+'.PROCESS.json'),row);records.append(row);print(name,p.returncode,flush=True)
 if p.returncode!=expected:print((out/(name+'.stderr')).read_text(errors='replace')[-3500:],flush=True)
 assert p.returncode==expected,(name,p.returncode,expected)
 if expected==2:assert 'FAIL2_NO_COMPLETE_RESULT' in (out/(name+'.stderr')).read_text()
def reseal(folder):
 lines=['path\tbytes\tsha256']
 for p in sorted(folder.rglob('*'),key=lambda p:p.relative_to(folder).as_posix()):
  n=p.relative_to(folder).as_posix()
  if n in ['MANIFEST.tsv','COMPLETED.tsv']:continue
  if p.is_dir():lines.append(n+'/\t0\tdirectory')
  else:v=pin(p);lines.append(n+'\t'+str(v['bytes'])+'\t'+v['sha256'])
 (folder/'MANIFEST.tsv').write_bytes(('\n'.join(lines)+'\n').encode());c=readmap(folder/'COMPLETED.tsv');c['manifest_sha256']=pin(folder/'MANIFEST.tsv')['sha256'];writemap(folder/'COMPLETED.tsv',c)
parent=matrix/'stderr-basic';assert (parent/'COMPLETED.tsv').exists();before=pin(parent/'MANIFEST.tsv')
for name in ['changed-input','changed-native-summary','missing-runtime','extra-empty-directory','resealed-script','resealed-dropped-contributor','resealed-nonfinite-effect','resealed-n-total','resealed-process-exit']:
 folder=out/name;shutil.copytree(parent,folder)
 if name=='changed-input':(folder/'inputs/0000.tsv').write_bytes((folder/'inputs/0000.tsv').read_bytes()+b'\n')
 elif name=='changed-native-summary':(folder/'native/summary.tsv').write_bytes((folder/'native/summary.tsv').read_bytes()+b'\n')
 elif name=='missing-runtime':(folder/'runtime/metal').unlink()
 elif name=='extra-empty-directory':(folder/'unrecorded').mkdir()
 elif name=='resealed-script':
  p=folder/'stages/primary/analysis.metal';p.write_bytes(p.read_bytes().replace(b'GENOMICCONTROL OFF',b'GENOMICCONTROL ON'));reseal(folder)
 elif name.startswith('resealed-') and name!='resealed-process-exit':
  p=folder/'stages/primary/result1.tbl'
  with p.open(newline='') as f:rows=list(csv.reader(f,delimiter='\t'))
  row=next(r for r in rows[1:] if r[0]=='M1');column=rows[0].index({'resealed-dropped-contributor':'Direction','resealed-nonfinite-effect':'Effect','resealed-n-total':'DeclaredN'}[name]);row[column]={'resealed-dropped-contributor':'+?','resealed-nonfinite-effect':'nan','resealed-n-total':'301'}[name];p.write_bytes(('\n'.join('\t'.join(r) for r in rows)+'\n').encode());reseal(folder)
 else:
  p=folder/'stages/primary/PROCESS-FINISHED.tsv';c=readmap(p);c['exit_code']='5';writemap(p,c);reseal(folder)
 run(name,['verify','--bundle',str(folder)],2)
run('historical-reader-refuses-changed-method',['verify','--bundle',str(parent)],2,runtime=oldjar)
minimal=out/'incomplete-reader';minimal.mkdir()
with zipfile.ZipFile(jar) as z:
 for n in z.namelist():
  if n.startswith('org/jlinalg/cli/MetalWorkflow') and n.endswith('.class') and not n.endswith('MetalWorkflowFiles$InventoryVisitor.class'):
   p=minimal/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(n))
run('incomplete-reader-prominent-fail2',['verify','--bundle',str(parent)],2,runtime=minimal);assert 'complete matching source-build JAR' in (out/'incomplete-reader-prominent-fail2.stderr').read_text()
for name,mutation in [('input-zero-p','zero-p'),('input-nan','nan'),('input-duplicate','duplicate'),('input-bad-utf8','utf8'),('input-missing-direction','direction')]:
 source=matrix/'supplied'/('samplesize-basic' if mutation in ['zero-p','direction'] else 'stderr-basic');folder=out/(name+'-supplied');shutil.copytree(source,folder);p=folder/'study0.tsv';raw=p.read_bytes();rows=raw.decode().splitlines();fields=rows[1].split('\t')
 if mutation=='zero-p':fields[4]='0'
 elif mutation=='nan':fields[3]='NaN'
 elif mutation=='duplicate':rows.append(rows[1])
 elif mutation=='direction':fields[3]='0'
 if mutation!='duplicate':rows[1]='\t'.join(fields)
 p.write_bytes(('\n'.join(rows)+'\n').encode() if mutation!='utf8' else raw+b'\xc3\x28\n')
 run(name,['run','--request',linux(folder/'REQUEST.tsv'),'--out',linux(out/name)],2,windows=False);assert not (out/name/'COMPLETED.tsv').exists();assert not (out/name/'stages/primary/PROCESS-STARTED.tsv').exists()
# Actual source GC-estimation controls, with 2000 generated null-like markers per study.
for scheme in ['STDERR','SAMPLESIZE']:
 name='automatic-gc-'+scheme.lower();folder=out/(name+'-supplied');shutil.copytree(matrix/'supplied/stderr-basic',folder);c=readmap(folder/'REQUEST.tsv');c['scheme']=scheme;writemap(folder/'REQUEST.tsv',c);(folder/'STUDIES.tsv').write_bytes(b'study\tfile\tgenomic_control\nfirst\tstudy0.tsv\tON\nsecond\tstudy1.tsv\tON\n');rng=random.Random(20261119);data=[[],[]]
 for i in range(2000):
  for study in range(2):
   z=1.5*rng.gauss(0,1);effect=f'{.1*z:.17g}' if scheme=='STDERR' else ('+' if z>=0 else '-');p='-' if scheme=='STDERR' else f'{math.erfc(abs(z)/math.sqrt(2)):.17g}';se='.1' if scheme=='STDERR' else '-';data[study].append(f'G{i}\tA\tC\t{effect}\t{p}\t10000\t{se}\t-\t+')
 for i,rows in enumerate(data):(folder/f'study{i}.tsv').write_bytes(('MARKER\tALLELE1\tALLELE2\tEFFECT\tPVALUE\tN\tSTDERR\tFREQ\tSTRAND\n'+'\n'.join(rows)+'\n').encode())
 bundle=out/name;run(name,['run','--request',linux(folder/'REQUEST.tsv'),'--out',linux(bundle)],windows=False);run(name+'-verify',['verify','--bundle',str(bundle)]);run(name+'-replay',['replay','--bundle',linux(bundle),'--out',linux(out/(name+'-replayed'))],windows=False);assert 'Genomic control parameter is' in (bundle/'stages/primary/original.stdout').read_text()
assert pin(parent/'MANIFEST.tsv')==before
save(out/'COMPLETED.json',dict(status='PASS_TYPED_WORKFLOW_ADMISSION_AND_AUTOMATIC_GC_CONTROLS',actual_java_launches=len(records),runs=records,original_parent_bundle_preserved=True,resealed_semantic_mutations_refused=True));print('ADVANCED_COMPLETE',len(records),flush=True)
