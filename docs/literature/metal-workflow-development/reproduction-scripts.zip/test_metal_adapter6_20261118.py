from pathlib import Path
p=Path('D:/projects/JLinAlg/build/test_metal_adapter_20261118.py');code=p.read_text(encoding='utf-8').replace("adapter-tests-1'","adapter-tests-6'").replace('adapter-build-1/jar/','adapter-build-6/jar/').replace('dict(tests=15,errors=0,failures=0,skipped=0)','dict(tests=17,errors=0,failures=0,skipped=0)');exec(compile(code,str(p)+'-6','exec'))
