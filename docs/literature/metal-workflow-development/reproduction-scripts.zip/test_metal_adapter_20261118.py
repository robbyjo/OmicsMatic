from pathlib import Path
import subprocess,shutil,json,xml.etree.ElementTree as ET,hashlib,time
a=Path('D:/projects/JLinAlg/build/high-impact-stats-1');out=a/'build/metal-1/adapter-tests-1';out.mkdir();jar=a/'build/metal-1/adapter-build-1/jar/omicsmatic-0.4.0.jar';junit=a/'build/nfcore-atacseq121-1/linux-test-runtime-1/junit-platform-console-standalone-1.13.4.jar';source=a/'src/test/java/org/jlinalg/cli/MetalWorkflowCliTest.java';distro='JLinAlg-Omics-SAIGE-20261026';snapshot=out/'MetalWorkflowCliTest.java';shutil.copyfile(source,snapshot);empty=out/'empty';empty.mkdir()
def linux(p):p=Path(p).absolute();return '/mnt/'+p.drive[0].lower()+'/'+p.as_posix()[3:]
def run(label,cmd):
 (out/(label+'.command.json')).write_bytes((json.dumps(cmd,indent=2)+'\n').encode());start=time.monotonic()
 with (out/(label+'.stdout')).open('xb') as so,(out/(label+'.stderr')).open('xb') as se:p=subprocess.run(cmd,cwd=a,stdout=so,stderr=se,timeout=300)
 (out/(label+'.PROCESS.json')).write_bytes((json.dumps(dict(exit_code=p.returncode,seconds=time.monotonic()-start),indent=2)+'\n').encode())
 if p.returncode:print(label,(out/(label+'.stdout')).read_text(errors='replace')[-6000:],(out/(label+'.stderr')).read_text(errors='replace')[-3000:],flush=True)
 assert p.returncode==0,label
results={}
for platform in ['windows','linux']:
 fmt=str if platform=='windows' else linux;sep=';' if platform=='windows' else ':';classes=out/(platform+'-classes');classes.mkdir();jdk='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/'
 java=[jdk+'java.exe'] if platform=='windows' else ['wsl','-d',distro,'--exec','/usr/bin/java'];javac=[jdk+'javac.exe'] if platform=='windows' else ['wsl','-d',distro,'--exec','/usr/bin/javac']
 run(platform+'-compile',javac+['--release','17','--source-path',fmt(empty),'-cp',sep.join([fmt(jar),fmt(junit)]),'-d',fmt(classes),fmt(snapshot)])
 reports=out/(platform+'-reports');run(platform+'-junit',java+['-jar',fmt(junit),'execute','--class-path',sep.join([fmt(jar),fmt(classes)]),'--select-class','org.jlinalg.cli.MetalWorkflowCliTest','--reports-dir',fmt(reports),'--details','summary','--disable-banner'])
 trees=[ET.parse(p).getroot() for p in reports.glob('TEST-*.xml')];stats={k:sum(int(t.attrib.get(k,0)) for t in trees) for k in ['tests','errors','failures','skipped']};assert stats==dict(tests=15,errors=0,failures=0,skipped=0),stats;results[platform]=stats
(out/'COMPLETED.json').write_bytes((json.dumps(dict(status='PASS_PACKAGED_TYPED_ADAPTER_UNIT_AND_ADMISSION_TESTS',junit=results),indent=2)+'\n').encode());print(json.dumps(results,indent=2),flush=True)
