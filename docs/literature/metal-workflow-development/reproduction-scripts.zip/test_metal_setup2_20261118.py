from pathlib import Path
p=Path('D:/projects/JLinAlg/build/test_metal_setup_20261118.py');exec(compile(p.read_text(encoding='utf-8').replace("setup-controls-1'","setup-controls-2'"),str(p)+'-2','exec'))
