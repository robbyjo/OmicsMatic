from pathlib import Path
p=Path('D:/projects/JLinAlg/build/metal_adapter_matrix_20261118.py');code=p.read_text(encoding='utf-8').replace("adapter-matrix-1'","adapter-matrix-2'").replace('adapter-build-2/jar/','adapter-build-3/jar/');exec(compile(code,str(p)+'-2','exec'))
