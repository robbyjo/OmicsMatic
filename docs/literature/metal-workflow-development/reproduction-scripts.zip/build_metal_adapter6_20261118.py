from pathlib import Path
p=Path('D:/projects/JLinAlg/build/build_metal_adapter_20261118.py');exec(compile(p.read_text(encoding='utf-8').replace("adapter-build-1'","adapter-build-6'"),str(p)+'-6','exec'))
