from pathlib import Path
p=Path('D:/projects/JLinAlg/build/close_metal_adapter_20261118.py');code=p.read_text(encoding='utf-8').replace("adapter-evidence-1'","adapter-evidence-3'").replace('adapter-matrix-2','adapter-matrix-4').replace('adapter-admission-controls-2','adapter-admission-controls-4').replace('adapter-build-3','adapter-build-5').replace('adapter-tests-3','adapter-tests-5').replace('public-examples-2','public-examples-4')
for label in ['configure','compile','official-tests','install']:code=code.replace(label+'-PROCESS.json',label+'.PROCESS.json')
code=code.replace('==26','==28').replace('=26','=28').replace('ALL_26','ALL_28').replace('tests=15','tests=16').replace('matrix_java_main_launches=51','matrix_java_main_launches=55').replace('explicit_current_java_main_launches=101','explicit_current_java_main_launches=107').replace('current_success_profiles=12','current_success_profiles=13')
# Add the supersession and exact large-N scope; never rewrite reader3 evidence.
code=code.replace("manifest={name:rawpin(raw) for name,raw in payload.items()}","add('historical-reader3/SUPERSESSION.json',dest/'historical-reader3/SUPERSESSION.json')\nmanifest={name:rawpin(raw) for name,raw in payload.items()}")
exec(compile(code,str(p)+'-3','exec'))
