from pathlib import Path
import json,hashlib,importlib.util
root=Path('D:/projects/JLinAlg');a=root/'build/high-impact-stats-1';out=a/'build/metal-1/role-review-1';out.mkdir();dest=a/'docs/literature/metal-workflow-development';dest.mkdir(exist_ok=True);intake=json.loads((a/'build/metal-1/PRIMARY-ROLES.private.json').read_bytes())
p=a/'tools/literature/metal_workflows/reviews.py';spec=importlib.util.spec_from_file_location('reviews',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);reviews=m.REVIEWS;assert len(reviews)==24;assert set(reviews)=={r['paper_id'] for r in intake['existing_roles']}=={r['paper_id'] for r in intake['all_named_hits']}
cache=root/'build/literature-review/xml';paths={p.stem:p for p in cache.glob('*.xml')};checked=0
for row in intake['primary_identities']:
 path=paths.get(row['pmcid']) or paths.get(row['paper_id']);assert path is not None,(row['paper_id'],list(paths)[:4]);assert hashlib.sha256(path.read_bytes()).hexdigest()==row['xml_sha256'],row['paper_id'];checked+=1
rows=[]
for old in intake['existing_roles']:
 id=old['paper_id'];indices,edition,kind,summary,caution=reviews[id];paragraphs={p['paragraph_index']:p for p in old['source_paragraphs']};assert set(indices)<=set(paragraphs),(id,indices,list(paragraphs));selected=[dict(paragraph_index=i,section=paragraphs[i]['section'],paragraph_sha256=paragraphs[i]['paragraph_sha256']) for i in indices]
 rows.append(dict(paper_id=id,doi=old['doi'],pmcid=old['pmcid'],source_xml_sha256=old['xml_sha256'],source_url=old['fulltext_url'],selected_primary_evidence=selected,positive_use=True,role=kind,use_summary=summary,edition_literal=edition,required_caution=caution,review_status='individually-reviewed-positive-use',exact_paper_reproduction_claimed=False,canonical_catalog_applied=False))
report=dict(status='PASS_24_PRIMARY_METAL_ROLE_REVIEWS_PREVIEW_ONLY',primary_xml_hashes_checked=checked,existing_observations=24,all_named_hit_papers=24,named_paragraphs=sum(len(r['paragraphs']) for r in intake['all_named_hits']),positive_roles_reviewed=len(rows),negative_context_observations_removed=0,canonical_catalog_modified=False,new_family_credit=0,adapter_qualification_pending=True,whole_goal_complete=False,reviews=rows)
raw=(json.dumps(report,indent=2)+'\n').encode();(dest/'ROLE-REVIEW-PREVIEW.json').write_bytes(raw);(dest/'.gitattributes').write_bytes(b'*.json -text\n*.zip -text\n');(out/'COMPLETED.json').write_bytes(raw);print(json.dumps({k:v for k,v in report.items() if k!='reviews'},indent=2),flush=True)
