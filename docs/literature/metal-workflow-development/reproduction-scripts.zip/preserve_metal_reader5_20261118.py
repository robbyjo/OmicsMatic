from pathlib import Path
import json
a=Path('D:/projects/JLinAlg/build/high-impact-stats-1');d=a/'docs/literature/metal-workflow-development';h=d/'historical-reader5';h.mkdir()
for n in ['VALIDATION.json','qualification-evidence.zip','reproduction-scripts.zip','AUDITOR-CONTROLS.json']:
 p=d/n;raw=p.read_bytes();(h/n).write_bytes(raw);assert (h/n).read_bytes()==raw;assert p.resolve().is_relative_to(d.resolve());p.unlink()
(h/'SUPERSESSION.json').write_bytes((json.dumps(dict(status='HISTORICAL_READER5_RETAINED_BEFORE_ORIGINAL_MANIFEST_CAPTURE_EXTENSION',scientific_results_rewritten=False,old_fingerprints_refreshed=False,old_matching_reader='build/metal-1/adapter-build-5/jar/omicsmatic-0.4.0.jar',old_closed_corpus='build/metal-1/adapter-evidence-3',change='Current source additionally captures the exact original study-list bytes, rejects a request/list changed between parse and capture, and verifies original/canonical declarations. Fresh qualification is required; keep this historical reader and corpus.'),indent=2)+'\n').encode())
