from pathlib import Path
import subprocess,math,random,json,hashlib,time
a=Path('D:/projects/JLinAlg/build/high-impact-stats-1');out=a/'build/metal-1/adapter-source-profiles-1';out.mkdir();binary=a/'build/metal-1/build-original-1/native-build/bin/metal';distro='JLinAlg-Omics-SAIGE-20261026'
def linux(p):p=Path(p).absolute();return '/mnt/'+p.drive[0].lower()+'/'+p.as_posix()[3:]
def run(name,script,files):
 folder=out/name;folder.mkdir()
 for n,raw in files.items():(folder/n).write_bytes(raw.encode())
 (folder/'analysis.metal').write_bytes(script.encode());cmd=['wsl','-d',distro,'--cd',linux(folder),'--exec',linux(binary),'analysis.metal'];start=time.monotonic()
 with (folder/'original.stdout').open('xb') as so,(folder/'original.stderr').open('xb') as se:p=subprocess.run(cmd,cwd=a,stdout=so,stderr=se,timeout=120)
 (folder/'PROCESS.json').write_bytes((json.dumps(dict(command=cmd,exit_code=p.returncode,seconds=time.monotonic()-start),indent=2)+'\n').encode());assert p.returncode==0,name
 for p in folder.glob('result*.tbl'):print(name,p.name,p.read_text()[:2200],flush=True)
 print(name,'CONSOLE',(folder/'original.stdout').read_text()[-1800:],flush=True)
 return folder
header='MARKER ALLELE1 ALLELE2 EFFECT PVALUE N STDERR FREQ STRAND\n'
files={'study1.tsv':header+'M1 A C 0.2 - 100 0.1 0.2 +\nM2 C G -0.1 - 100 0.2 0.3 +\n','study2.tsv':header+'M1 C A -0.3 - 200 0.2 0.6 +\nM2 C G 0.2 - 200 0.3 0.4 +\n'}
base='SCHEME STDERR\nMINWEIGHT 0\nGENOMICCONTROL OFF\nOVERLAP OFF\nEFFECT_PRINT_PRECISION 12\nSTDERR_PRINT_PRECISION 12\nCUSTOMVARIABLE DeclaredN\nLABEL DeclaredN AS N\nAVERAGEFREQ ON\nMINMAXFREQ ON\nFREQLABEL FREQ\nUSESTRAND ON\nSTRANDLABEL STRAND\n'
paired=run('stderr-frequencies',base+'PROCESSFILE study1.tsv\nPROCESSFILE study2.tsv\nOUTFILE result .tbl\nANALYZE HETEROGENEITY\nQUIT\n',files)
run('post-gc', 'SCHEME STDERR\nMINWEIGHT 0\nGENOMICCONTROL 1.2\nMARKERLABEL MarkerName\nALLELELABELS Allele1 Allele2\nEFFECTLABEL Effect\nSTDERRLABEL StdErr\nWEIGHTLABEL DeclaredN\nCUSTOMVARIABLE DeclaredN\nLABEL DeclaredN AS DeclaredN\nAVERAGEFREQ ON\nMINMAXFREQ ON\nFREQLABEL Freq1\nLOGPVALUE ON\nEFFECT_PRINT_PRECISION 12\nSTDERR_PRINT_PRECISION 12\nPROCESSFILE combined.tsv\nOUTFILE result .tbl\nANALYZE\nQUIT\n',{'combined.tsv':(paired/'result1.tbl').read_text()})
run('gene-samplesize','SCHEME SAMPLESIZE\nMINWEIGHT 0\nALLELELABELS UNUSED1 UNUSED2\nGENOMICCONTROL OFF\nLOGPVALUE ON\nPROCESSFILE study1.tsv\nPROCESSFILE study2.tsv\nOUTFILE result .tbl\nANALYZE HETEROGENEITY\nQUIT\n',{'study1.tsv':header+'ENSG1 - - 1 .05 100 - - +\nENSG2 - - -1 .01 100 - - +\n','study2.tsv':header+'ENSG1 - - 1 .1 200 - - +\nENSG3 - - -1 .2 200 - - +\n'})
rng=random.Random(20261118);one=header;two=header
for i in range(2000):
 z1=rng.gauss(0,1);z2=.3*z1+math.sqrt(1-.3**2)*rng.gauss(0,1)
 one+=f'S{i} A C {1 if z1>=0 else -1} {math.erfc(abs(z1)/math.sqrt(2)):.17g} 10000 - .3 +\n';two+=f'S{i} A C {1 if z2>=0 else -1} {math.erfc(abs(z2)/math.sqrt(2)):.17g} 10000 - .3 +\n'
run('overlap','SCHEME SAMPLESIZE\nMINWEIGHT 0\nGENOMICCONTROL OFF\nOVERLAP ON\nZCUTOFF 1\nLOGPVALUE ON\nPROCESSFILE study1.tsv\nPROCESSFILE study2.tsv\nOUTFILE result .tbl\nANALYZE HETEROGENEITY\nQUIT\n',{'study1.tsv':one,'study2.tsv':two})
