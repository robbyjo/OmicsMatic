from pathlib import Path
import hashlib,json,os,shutil,stat,sys,zipfile
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[3];BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools/literature'))
from cell2location_catalog.model import META,PROOF,COVERAGE,EVIDENCE,WORKFLOW,GUIDE,CURATION,encoded,pin
from cell2location_catalog.finalize import DESCRIPTOR,check
out=BASE/'cell2location-catalog-freeze-1';out.mkdir(exist_ok=False)
data=ROOT/EVIDENCE
first=BASE/'cell2location-catalog-preflight-1'
observation=first/'OBSERVED_FAILURE.json'
with observation.open('xb') as stream:stream.write(encoded(dict(status='FAIL2_PRE_ADMISSION_BROWSER_CARD_EDITION_WARNING_MISSING',cause='Original browser-ui.log: cell2location (6 papers): 0.7a0',live_catalog_changed=False,scientific_sources_changed=False,corrected_before_admission=True,original_attempt_and_sources_retained=True)))
raw=BASE/'cell2location-catalog-rescan-2/COMPLETED.json';gate=json.loads(raw.read_bytes())
assert gate['status']=='PASS_ORIGINAL_CELL2LOCATION013_WORKFLOW_AND_SIX_PRIMARY_SOURCE_ROLES' and gate['primary_sources_rescanned'] and gate['reviewed_uses']==1162
ui=json.loads((BASE/'cell2location-catalog-validation-1/COMPLETED.json').read_bytes());assert ui['boundary_tests']==17
assert all(p['exit_code']==0 for p in json.loads((BASE/'cell2location-catalog-validation-1/PROCESSES.json').read_bytes()))
inverse=check(ROOT)
groups=['cell2location-catalog-preview-1','cell2location-catalog-preflight-1','cell2location-catalog-preflight-2','cell2location-catalog-apply-1','cell2location-catalog-admission-guard-1','cell2location-pre-admission-cumulative-1','cell2location-catalog-rescan-1','cell2location-catalog-rescan-2','cell2location-catalog-validation-1','cell2location-catalog-finalize-1','cell2location-catalog-finalize-check-1']
items={}
for group in groups:
 folder=BASE/group;assert folder.is_dir()
 for p in sorted(folder.rglob('*')):
  if p.is_file():
   assert not p.is_symlink();items[p.relative_to(BASE).as_posix()]=p
for name in ['cell2location-catalog-checks.py','cell2location-catalog-package.py']:
 items['validation-scripts/'+name]=BASE/name
for n in ['README.md','SOURCE_AUDIT.json','qualified-source-reviews.json','qualified-intake.json']:
 items['admission-public-snapshot/'+n]=data/n
members={}
with zipfile.ZipFile(data/'validation-attempts.zip','x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(items.items()):
  raw=p.read_bytes();info=zipfile.ZipInfo(name,(2026,11,14,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,raw)
  members[name]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
(data/'VALIDATION_MEMBERS.json').write_bytes(encoded(members))
with zipfile.ZipFile(data/'validation-attempts.zip') as z:
 assert set(z.namelist())==set(members)
 for n,w in members.items():
  raw=z.read(n);assert dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())==w
saved=json.loads((ROOT/'build/git-merge/20261114-branch-sync-1/BEFORE.json').read_bytes());checked={}
for name,w in saved['files'].items():
 if name=='tools/literature/cell2location_catalog/model.py':continue
 path=ROOT/name;current=dict(exists=path.exists(),size=path.stat().st_size if path.exists() else None,sha256=hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None)
 assert current==w,('Concurrent/unrelated file changed',name)
 checked[name]=current
(out/'PRESERVATION.json').write_bytes(encoded(dict(status='PASS_ALL_UNRELATED_AND_FROZEN_LOCAL_FILES_UNCHANGED',files=checked,canonical_jar_unchanged=True)))
for folder in [ROOT/WORKFLOW,data]:
 checksum=folder/'SHA256SUMS';assert not checksum.exists()
 checksum.write_text(''.join(pin(p)['sha256']+'  '+p.relative_to(folder).as_posix()+'\n' for p in sorted(folder.rglob('*')) if p.is_file() and p!=checksum),encoding='ascii',newline='\n')
sources=[p.relative_to(ROOT).as_posix() for d in ['tools/literature/cell2location013','tools/literature/cell2location_catalog'] for p in sorted((ROOT/d).rglob('*')) if p.is_file() and '__pycache__' not in p.parts]
sources += [GUIDE,CURATION,'docs/literature/CELL2LOCATION013_DEVELOPMENT.md',PROOF,COVERAGE,DESCRIPTOR,'tools/literature/wire_signac_catalog.py','tools/literature/catalog_source_integrity.py']
evidence=[p.relative_to(ROOT).as_posix() for d in [EVIDENCE,WORKFLOW] for p in sorted((ROOT/d).rglob('*')) if p.is_file() and p.name!='VALIDATION.json']
evidence += [WORKFLOW+'/VALIDATION.json']
result=dict(status='PASS_ORIGINAL_CELL2LOCATION013_CATALOG_COMPLETE_COMPONENT_PRIOR_GATES_SOURCE_CENSUS_AND_UI',scope=dict(new_upstream_family_credit=1,new_native_family_credit=0,individual_reviews_added=6,papers=250,observations=2671,reviewed_uses=1162,unreviewed_uses=1509,new_scoped_integrations=110,including_existing_adapters=113,missing_families=263,whole_goal_complete=False),cumulative_gate=gate,validation=ui,exact_review_inverse=inverse,all_failed_catalog_attempts_retained=True,validation_archive_members=len(members),validation_archive=pin(data/'validation-attempts.zip'),validation_members=pin(data/'VALIDATION_MEMBERS.json'),source_pins={n:pin(ROOT/n) for n in sources},metadata_pins={n:pin(ROOT/n) for n in META},evidence_pins={n:pin(ROOT/n) for n in evidence},unrelated_and_canonical_jar_preserved=True,original_statistical_sources_changed=False,older_verifier_sources_changed=False,public_site_deployed=False)
(data/'VALIDATION.json').write_bytes(encoded(result));(out/'COMPLETED.json').write_bytes(encoded(dict(status=result['status'],validation=pin(data/'VALIDATION.json'),members=len(members))))
print(json.dumps(dict(status=result['status'],members=len(members),archive=pin(data/'validation-attempts.zip'),validation=pin(data/'VALIDATION.json'))),flush=True)
