from pathlib import Path
import argparse,ast,hashlib,http.server,importlib.util,json,os,shutil,subprocess,sys,threading,time,traceback,unittest
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'tools/literature'))
from cell2location_catalog.model import META,transition,check_transition
p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--preview',action='store_true');a=p.parse_args()
out=a.out.resolve();out.mkdir(exist_ok=False);records=[]
def write(n,v): (out/n).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def run(label,command,cwd=ROOT,env=None):
 start=time.monotonic()
 with (out/(label+'.log')).open('w',encoding='utf-8') as log:
  process=subprocess.run(command,cwd=cwd,stdout=log,stderr=subprocess.STDOUT,env=env)
 record=dict(label=label,command=[str(v) for v in command],exit_code=process.returncode,elapsed_seconds=time.monotonic()-start)
 records.append(record);write('PROCESSES.json',records)
 if process.returncode:raise RuntimeError(label+' failed; inspect '+label+'.log')
 return record
try:
 for path in (ROOT/'tools/literature/cell2location_catalog').glob('*'):
  if path.is_file():
   dest=out/'source-snapshot'/path.name;dest.parent.mkdir(exist_ok=True);shutil.copyfile(path,dest)
   if path.suffix=='.py':ast.parse(path.read_bytes(),filename=str(path))
 if a.preview:
  before={n:(ROOT/n).read_bytes() for n in META};after=transition(ROOT,before);check_transition(ROOT,before,after)
  for n,raw in after.items():dest=out/'preview'/n;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
  spec=importlib.util.spec_from_file_location('cell2location_pre_admission_boundaries',ROOT/'tools/literature/cell2location_catalog/test_catalog.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);module.load_before=lambda r:before
  with (out/'boundary-tests.log').open('w',encoding='utf-8') as log:
   result=unittest.TextTestRunner(stream=log,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(module))
  if not result.wasSuccessful():raise RuntimeError('Read boundary-tests.log')
  boundary_count=result.testsRun
 else:
  run('boundary-tests',[sys.executable,'-X','utf8',str(ROOT/'tools/literature/cell2location_catalog/test_catalog.py'),'-v'])
  boundary_count=17
 print('PASS_BOUNDARIES',boundary_count,flush=True)
 old=json.loads((ROOT/'build/literature-review/monocle-runtime/ggpubr-catalog-validation-1/PROCESSES.json').read_bytes())
 node=next(r['command'][0] for r in old if r['label']=='browser-ui')
 class Handler(http.server.SimpleHTTPRequestHandler):
  def __init__(self,*args,**kwargs):super().__init__(*args,directory=str(ROOT/'site'),**kwargs)
  def log_message(self,*args):pass
  def translate_path(self,path):
   clean=path.split('?',1)[0]
   if a.preview and clean in ['/literature-review.html','/literature-warnings.html']:return str(out/'preview/site'/clean.lstrip('/'))
   return super().translate_path(path)
 server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler)
 thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
 try:run('browser-ui',[node,str(ROOT/'tools/literature/cell2location_catalog/check_ui.cjs'),'C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules','C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',str(out/'ui'),'http://127.0.0.1:'+str(server.server_port)])
 finally:server.shutdown();server.server_close()
 if not a.preview:
  checkout=ROOT/'build/literature-review/monocle-runtime/palette-allelic-validation-1/checkout'
  status=subprocess.run(['git','diff','--name-only'],cwd=checkout,check=True,stdout=subprocess.PIPE).stdout.decode().splitlines()
  assert set(status)<=set(['site/literature-review.html','site/literature-warnings.html']),status
  for name in ['site/literature-review.html','site/literature-warnings.html']:
   shutil.copyfile(ROOT/name,checkout/name)
   assert (ROOT/name).read_bytes()==(checkout/name).read_bytes()
  env=os.environ.copy();env['JAVA_HOME']='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot';env['PATH']=env['JAVA_HOME']+'/bin;'+env['PATH']
  run('website',['cmd.exe','/d','/c',str(checkout/'gradlew.bat'),'checkWebsite','--no-daemon','--no-parallel','--no-configuration-cache','--max-workers=2','--console=plain'],cwd=checkout,env=env)
 write('COMPLETED.json',dict(status='PASS_PRE_ADMISSION_EXACT_PREVIEW_BOUNDARIES_UI' if a.preview else 'PASS_ADMITTED_CATALOG_BOUNDARIES_UI_AND_ISOLATED_WEBSITE',boundary_tests=boundary_count,preview_only=a.preview,public_site_deployed=False))
 print('PASS_CATALOG_CHECKS',flush=True)
except BaseException as error:
 write('FAILURE.json',dict(status='FAIL2_VALIDATION_INCOMPLETE',cause=repr(error),traceback=traceback.format_exc(),all_attempts_retained=True))
 print(traceback.format_exc(),flush=True);raise SystemExit(2)
