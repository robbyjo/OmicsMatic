from pathlib import Path
import scanpy as sc,anndata as ad,numpy as np,json,sys
a=ad.read_h5ad(sys.argv[1]);sc.settings.preset='scanpy-v1';sc.settings.n_jobs=1
mask=~((a.obs['group']=='group-0')&(a.obs['total_counts']<1e9));a=a[mask.to_numpy(),:].copy();a.layers['provided_scaled']=a.X.copy()
sc.tl.embedding_density(a,basis='umap',groupby='group',out=False)
sc.tl.score_genes(a,gene_list=[f'gene-{i:03d}' for i in range(5)],use_raw=True,ctrl_as_ref=False,ctrl_size=4,n_bins=4,rng=8,score_name='score_supplied',out=False)
b=ad.read_h5ad(sys.argv[2]);assert a.n_obs==b.n_obs==40 and a.n_vars==b.n_vars==80
assert list(a.obs_names)==list(b.obs_names) and list(a.var_names)==list(b.var_names)
arrays={}
for name,x,y in [('X',a.X,b.X),('provided_scaled',a.layers['provided_scaled'],b.layers['provided_scaled']),('density',a.obs['umap_density_group'].to_numpy(),b.obs['umap_density_group'].to_numpy()),('score',a.obs['score_supplied'].to_numpy(),b.obs['score_supplied'].to_numpy()),('supplied_UMAP',a.obsm['X_umap'],b.obsm['X_umap']),('raw.X',a.raw.X.toarray(),b.raw.X.toarray())]:
 np.testing.assert_allclose(x,y,rtol=2e-11,atol=1e-12,err_msg=name);arrays[name]=dict(shape=list(x.shape),maximum_absolute_difference=float(np.max(np.abs(x-y))))
Path(sys.argv[3]).write_text(json.dumps(dict(status='PASS_ORIGINAL_FOUR_STEP_PROVIDED_OBJECT_COMPARISON',cells=40,genes=80,arrays=arrays,graph_or_embedding_refitted=False,source_patched=False),indent=2)+'\n')
print('PASS ORIGINAL PROVIDED H5AD',len(arrays),'arrays, 40 retained cells')
