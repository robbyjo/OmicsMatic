from pathlib import Path
import scanpy as sc,anndata as ad,numpy as np,pandas as pd,scipy.sparse as sp,json,sys
source=Path(sys.argv[1]);out=Path(sys.argv[2]);a=ad.read_h5ad(sys.argv[3])
b=ad.read_h5ad(source/'worker/outputs/result.h5ad');comparisons=[]
def compare(name,x,y):
 if sp.issparse(x):x=x.toarray()
 if sp.issparse(y):y=y.toarray()
 x=np.asarray(x);y=np.asarray(y);assert x.shape==y.shape,(name,x.shape,y.shape)
 if x.dtype.kind in 'biuf' and y.dtype.kind in 'biuf':
  assert np.isfinite(x).all() and np.isfinite(y).all(),name
  np.testing.assert_allclose(x,y,rtol=2e-11,atol=1e-12,err_msg=name)
  delta=float(np.max(np.abs(x.astype(float)-y.astype(float)))) if x.size else 0.
 else:
  assert x.tolist()==y.tolist(),name;delta=0.
 comparisons.append(dict(name=name,shape=list(x.shape),maximum_absolute_difference=delta))
compare('X',a.X,b.X);compare('raw.X',a.raw.X,b.raw.X)
compare('obs_names',a.obs_names,b.obs_names);compare('var_names',a.var_names,b.var_names)
for slot in ['layers','obsm','varm','obsp','varp']:
 left=getattr(a,slot);right=getattr(b,slot);assert set(left)==set(right),(slot,list(left),list(right))
 for key in left:compare(slot+'/'+str(key),left[key],right[key])
for slot in ['obs','var']:
 left=getattr(a,slot);right=getattr(b,slot);assert set(left)==set(right),slot
 for key in left:compare(slot+'/'+str(key),left[key].to_numpy(),right[key].to_numpy())
for name in ['variance','variance_ratio']:compare('pca/'+name,a.uns['pca'][name],b.uns['pca'][name])
for name in ['scores','pvals','pvals_adj','logfoldchanges','names']:
 left=a.uns['rank_genes_groups'][name];right=b.uns['rank_genes_groups'][name];assert left.dtype.names==right.dtype.names
 for group in left.dtype.names:compare('markers/'+name+'/'+group,left[group],right[group])
for name in ['pts','pts_rest']:compare('markers/'+name,a.uns['rank_genes_groups'][name].to_numpy(),b.uns['rank_genes_groups'][name].to_numpy())
report=dict(status='PASS_SEPARATELY_WRITTEN_ORIGINAL_SCANPY_13_STEP_COMPARISON',comparisons=comparisons,source_patched=False,worker_imported=False,whole_tool_qualified=False)
(out/'COMPARISONS.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(status=report['status'],compared_arrays=len(comparisons),max_abs=max(c['maximum_absolute_difference'] for c in comparisons))))
