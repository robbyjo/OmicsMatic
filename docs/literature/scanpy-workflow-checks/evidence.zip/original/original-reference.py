from pathlib import Path
import scanpy as sc,anndata as ad,numpy as np,pandas as pd,scipy.sparse as sp,json,sys
from scipy.io import mmread
source=Path(sys.argv[1]);out=Path(sys.argv[2]);sc.settings.preset='scanpy-v1';sc.settings.n_jobs=1
obs=pd.read_csv(source/'inputs/cells',sep='\t',dtype=str,index_col=0);obs['group']=pd.Categorical(obs['group'],categories=['group-0','group-1','group-2'],ordered=False)
var=pd.read_csv(source/'inputs/features',sep='\t',dtype=str,index_col=0)
a=ad.AnnData(mmread(source/'inputs/matrix.mtx').T.tocsr(),obs=obs,var=var)
a.layers['counts']=a.X.copy()
sc.pp.calculate_qc_metrics(a,percent_top=[5,10],log1p=True,qc_vars=[],out=False)
sc.pp.normalize_total(a,target_sum=10000,key_added='normalization_factor',out=False)
sc.pp.log1p(a,out=False)
a.raw=a.copy()
sc.pp.highly_variable_genes(a,flavor='seurat',n_top_genes=40,n_bins=10,subset=False,out=False)
sc.pp.scale(a,zero_center=True,max_value=10,out=False)
sc.pp.pca(a,n_comps=10,svd_solver='arpack',rng=7,dtype='float64',mask_var='highly_variable',out=False)
sc.pp.neighbors(a,n_neighbors=10,n_pcs=10,use_rep='X_pca',transformer='sklearn',metric='euclidean',rng=7,out=False)
sc.tl.leiden(a,resolution=.6,flavor='leidenalg',directed=True,rng=7,n_iterations=5,out=False)
sc.tl.umap(a,min_dist=.3,maxiter=30,rng=7,init_pos='random',compatibility_layout=True,out=False)
sc.tl.score_genes(a,gene_list=[f'gene-{i:03d}' for i in range(5)],use_raw=True,ctrl_as_ref=False,ctrl_size=4,n_bins=4,rng=7,out=False)
sc.tl.rank_genes_groups(a,groupby='group',use_raw=True,method='wilcoxon',tie_correct=True,corr_method='benjamini-hochberg',n_genes=None,mean_in_log_space=True,pts=True,out=False)
a.write_h5ad(out/'original.h5ad',compression='gzip')
b=ad.read_h5ad(source/'worker/outputs/result.h5ad');comparisons=[]
def compare(name,x,y):
 if sp.issparse(x):x=x.toarray()
 if sp.issparse(y):y=y.toarray()
 x=np.asarray(x);y=np.asarray(y);assert x.shape==y.shape,(name,x.shape,y.shape)
 if x.dtype.kind in 'biuf' and y.dtype.kind in 'biuf':
  assert np.isfinite(x).all() and np.isfinite(y).all(),name
  np.testing.assert_allclose(x,y,rtol=2e-11,atol=1e-12,err_msg=name)
  delta=float(np.max(np.abs(x.astype(float)-y.astype(float)))) if x.size else 0.
 else:
  assert x.tolist()==y.tolist(),name;delta=0.
 comparisons.append(dict(name=name,shape=list(x.shape),maximum_absolute_difference=delta))
compare('X',a.X,b.X);compare('raw.X',a.raw.X,b.raw.X)
compare('obs_names',a.obs_names,b.obs_names);compare('var_names',a.var_names,b.var_names)
for slot in ['layers','obsm','varm','obsp','varp']:
 left=getattr(a,slot);right=getattr(b,slot);assert list(left)==list(right),(slot,list(left),list(right))
 for key in left:compare(slot+'/'+str(key),left[key],right[key])
for slot in ['obs','var']:
 left=getattr(a,slot);right=getattr(b,slot);assert list(left)==list(right),slot
 for key in left:compare(slot+'/'+str(key),left[key].to_numpy(),right[key].to_numpy())
for name in ['variance','variance_ratio']:compare('pca/'+name,a.uns['pca'][name],b.uns['pca'][name])
for name in ['scores','pvals','pvals_adj','logfoldchanges','names']:
 left=a.uns['rank_genes_groups'][name];right=b.uns['rank_genes_groups'][name];assert left.dtype.names==right.dtype.names
 for group in left.dtype.names:compare('markers/'+name+'/'+group,left[group],right[group])
for name in ['pts','pts_rest']:compare('markers/'+name,a.uns['rank_genes_groups'][name].to_numpy(),b.uns['rank_genes_groups'][name].to_numpy())
report=dict(status='PASS_SEPARATELY_WRITTEN_ORIGINAL_SCANPY_13_STEP_COMPARISON',comparisons=comparisons,source_patched=False,worker_imported=False,whole_tool_qualified=False)
(out/'COMPARISONS.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(status=report['status'],compared_arrays=len(comparisons),max_abs=max(c['maximum_absolute_difference'] for c in comparisons))))
