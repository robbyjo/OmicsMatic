# Original AllelicSeries batch conditions

Every requested entry is retained in input order. A failed/nonfinite/scalar-zero entry prevents complete-batch admission. Read each recorded reason, preserve all outputs, correct the named cause and retry NEW paths.
Identifiers below use R quoted display; complete typed identifiers and values remain in RDS.

## Entry 000000007
    Identifier: "../escape"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000011
    Identifier: "line\nbreak"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000013
    Identifier: " NA "
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000014
    Identifier: "ENSG000001.7"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000021
    Identifier: "gene-000021"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000022
    Identifier: "gene-000022"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000026
    Identifier: "gene-000026"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000028
    Identifier: "gene-000028"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000033
    Identifier: "gene-000033"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000035
    Identifier: "gene-000035"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000039
    Identifier: "gene-000039"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000042
    Identifier: "gene-000042"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000044
    Identifier: "gene-000044"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000049
    Identifier: "gene-000049"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000052
    Identifier: "gene-000052"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000055
    Identifier: "gene-000055"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000056
    Identifier: "gene-000056"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000063
    Identifier: "gene-000063"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000065
    Identifier: "gene-000065"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000066
    Identifier: "gene-000066"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000070
    Identifier: "gene-000070"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000077
    Identifier: "gene-000077"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000078
    Identifier: "gene-000078"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000084
    Identifier: "gene-000084"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000088
    Identifier: "gene-000088"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000091
    Identifier: "gene-000091"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.
    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000098
    Identifier: "gene-000098"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000099
    Identifier: "gene-000099"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000104
    Identifier: "gene-000104"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000105
    Identifier: "gene-000105"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000110
    Identifier: "gene-000110"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000112
    Identifier: "gene-000112"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000117
    Identifier: "gene-000117"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000119
    Identifier: "gene-000119"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000121
    Identifier: "gene-000121"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000126
    Identifier: "gene-000126"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000130
    Identifier: "gene-000130"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000132
    Identifier: "gene-000132"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000133
    Identifier: "gene-000133"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000140
    Identifier: "gene-000140"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000143
    Identifier: "gene-000143"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.
    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000147
    Identifier: "gene-000147"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000154
    Identifier: "gene-000154"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000156
    Identifier: "gene-000156"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000161
    Identifier: "gene-000161"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000165
    Identifier: "gene-000165"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000168
    Identifier: "gene-000168"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000169
    Identifier: "gene-000169"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000175
    Identifier: "gene-000175"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000176
    Identifier: "gene-000176"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000182
    Identifier: "gene-000182"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.
    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000187
    Identifier: "gene-000187"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000189
    Identifier: "gene-000189"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000195
    Identifier: "gene-000195"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000196
    Identifier: "gene-000196"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000198
    Identifier: "gene-000198"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000203
    Identifier: "gene-000203"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000208
    Identifier: "gene-000208"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000209
    Identifier: "gene-000209"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000210
    Identifier: "gene-000210"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000217
    Identifier: "gene-000217"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000220
    Identifier: "gene-000220"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000221
    Identifier: "gene-000221"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000224
    Identifier: "gene-000224"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000231
    Identifier: "gene-000231"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000234
    Identifier: "gene-000234"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000238
    Identifier: "gene-000238"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000242
    Identifier: "gene-000242"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000245
    Identifier: "gene-000245"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000247
    Identifier: "gene-000247"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000252
    Identifier: "gene-000252"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000253
    Identifier: "gene-000253"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000259
    Identifier: "gene-000259"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000260
    Identifier: "gene-000260"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000264
    Identifier: "gene-000264"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000266
    Identifier: "gene-000266"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000273
    Identifier: "gene-000273"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.
    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000275
    Identifier: "gene-000275"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000280
    Identifier: "gene-000280"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000286
    Identifier: "gene-000286"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.
    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000287
    Identifier: "gene-000287"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000294
    Identifier: "gene-000294"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000297
    Identifier: "gene-000297"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000299
    Identifier: "gene-000299"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000301
    Identifier: "gene-000301"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000308
    Identifier: "gene-000308"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000312
    Identifier: "gene-000312"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000315
    Identifier: "gene-000315"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000319
    Identifier: "gene-000319"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000322
    Identifier: "gene-000322"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000325
    Identifier: "gene-000325"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000329
    Identifier: "gene-000329"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000330
    Identifier: "gene-000330"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000336
    Identifier: "gene-000336"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000338
    Identifier: "gene-000338"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000341
    Identifier: "gene-000341"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000343
    Identifier: "gene-000343"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000350
    Identifier: "gene-000350"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000351
    Identifier: "gene-000351"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000352
    Identifier: "gene-000352"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000357
    Identifier: "gene-000357"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000363
    Identifier: "gene-000363"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000364
    Identifier: "gene-000364"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.
    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000371
    Identifier: "gene-000371"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000374
    Identifier: "gene-000374"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000377
    Identifier: "gene-000377"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000378
    Identifier: "gene-000378"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000385
    Identifier: "gene-000385"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000390
    Identifier: "gene-000390"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000392
    Identifier: "gene-000392"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000396
    Identifier: "gene-000396"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000399
    Identifier: "gene-000399"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000403
    Identifier: "gene-000403"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000406
    Identifier: "gene-000406"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000407
    Identifier: "gene-000407"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000413
    Identifier: "gene-000413"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000416
    Identifier: "gene-000416"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000418
    Identifier: "gene-000418"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000420
    Identifier: "gene-000420"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000427
    Identifier: "gene-000427"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000429
    Identifier: "gene-000429"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.
    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000434
    Identifier: "gene-000434"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000440
    Identifier: "gene-000440"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000441
    Identifier: "gene-000441"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000442
    Identifier: "gene-000442"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000448
    Identifier: "gene-000448"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000451
    Identifier: "gene-000451"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000455
    Identifier: "gene-000455"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.
    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000462
    Identifier: "gene-000462"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000468
    Identifier: "gene-000468"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000469
    Identifier: "gene-000469"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000473
    Identifier: "gene-000473"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000476
    Identifier: "gene-000476"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000481
    Identifier: "gene-000481"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000483
    Identifier: "gene-000483"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000484
    Identifier: "gene-000484"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000490
    Identifier: "gene-000490"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000494
    Identifier: "gene-000494"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000495
    Identifier: "gene-000495"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000497
    Identifier: "gene-000497"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000504
    Identifier: "gene-000504"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000506
    Identifier: "gene-000506"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000507
    Identifier: "gene-000507"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000511
    Identifier: "gene-000511"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000517
    Identifier: "gene-000517"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000518
    Identifier: "gene-000518"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000520
    Identifier: "gene-000520"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000525
    Identifier: "gene-000525"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000528
    Identifier: "gene-000528"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000532
    Identifier: "gene-000532"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000533
    Identifier: "gene-000533"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000539
    Identifier: "gene-000539"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000546
    Identifier: "gene-000546"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.
    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000550
    Identifier: "gene-000550"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000553
    Identifier: "gene-000553"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000559
    Identifier: "gene-000559"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000560
    Identifier: "gene-000560"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000561
    Identifier: "gene-000561"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000567
    Identifier: "gene-000567"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000572
    Identifier: "gene-000572"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.
    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000574
    Identifier: "gene-000574"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000581
    Identifier: "gene-000581"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000583
    Identifier: "gene-000583"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000585
    Identifier: "gene-000585"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000588
    Identifier: "gene-000588"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000594
    Identifier: "gene-000594"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000595
    Identifier: "gene-000595"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000598
    Identifier: "gene-000598"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000602
    Identifier: "gene-000602"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000605
    Identifier: "gene-000605"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000609
    Identifier: "gene-000609"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000611
    Identifier: "gene-000611"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000616
    Identifier: "gene-000616"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000623
    Identifier: "gene-000623"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000624
    Identifier: "gene-000624"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000627
    Identifier: "gene-000627"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000630
    Identifier: "gene-000630"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000637
    Identifier: "gene-000637"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.
    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000638
    Identifier: "gene-000638"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000644
    Identifier: "gene-000644"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000649
    Identifier: "gene-000649"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000650
    Identifier: "gene-000650"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000651
    Identifier: "gene-000651"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000658
    Identifier: "gene-000658"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000660
    Identifier: "gene-000660"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000663
    Identifier: "gene-000663"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000665
    Identifier: "gene-000665"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000671
    Identifier: "gene-000671"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000672
    Identifier: "gene-000672"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000676
    Identifier: "gene-000676"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000679
    Identifier: "gene-000679"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000682
    Identifier: "gene-000682"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000686
    Identifier: "gene-000686"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000689
    Identifier: "gene-000689"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000693
    Identifier: "gene-000693"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000700
    Identifier: "gene-000700"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000702
    Identifier: "gene-000702"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000704
    Identifier: "gene-000704"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000707
    Identifier: "gene-000707"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000714
    Identifier: "gene-000714"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000715
    Identifier: "gene-000715"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.
    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000721
    Identifier: "gene-000721"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000726
    Identifier: "gene-000726"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000728
    Identifier: "gene-000728"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.
    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000735
    Identifier: "gene-000735"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000737
    Identifier: "gene-000737"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000741
    Identifier: "gene-000741"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000742
    Identifier: "gene-000742"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000748
    Identifier: "gene-000748"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000749
    Identifier: "gene-000749"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000754
    Identifier: "gene-000754"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000756
    Identifier: "gene-000756"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000759
    Identifier: "gene-000759"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000763
    Identifier: "gene-000763"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000767
    Identifier: "gene-000767"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000770
    Identifier: "gene-000770"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000777
    Identifier: "gene-000777"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000780
    Identifier: "gene-000780"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000781
    Identifier: "gene-000781"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000784
    Identifier: "gene-000784"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000791
    Identifier: "gene-000791"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000792
    Identifier: "gene-000792"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000793
    Identifier: "gene-000793"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000798
    Identifier: "gene-000798"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000803
    Identifier: "gene-000803"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000805
    Identifier: "gene-000805"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000806
    Identifier: "gene-000806"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000812
    Identifier: "gene-000812"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000814
    Identifier: "gene-000814"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000819
    Identifier: "gene-000819"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.
    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000825
    Identifier: "gene-000825"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000826
    Identifier: "gene-000826"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000832
    Identifier: "gene-000832"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000833
    Identifier: "gene-000833"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000836
    Identifier: "gene-000836"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000840
    Identifier: "gene-000840"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000845
    Identifier: "gene-000845"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000847
    Identifier: "gene-000847"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000854
    Identifier: "gene-000854"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000858
    Identifier: "gene-000858"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.
    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000861
    Identifier: "gene-000861"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000868
    Identifier: "gene-000868"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000869
    Identifier: "gene-000869"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000871
    Identifier: "gene-000871"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000875
    Identifier: "gene-000875"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000880
    Identifier: "gene-000880"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000882
    Identifier: "gene-000882"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000884
    Identifier: "gene-000884"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000889
    Identifier: "gene-000889"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000891
    Identifier: "gene-000891"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000896
    Identifier: "gene-000896"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000897
    Identifier: "gene-000897"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000902
    Identifier: "gene-000902"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000903
    Identifier: "gene-000903"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000910
    Identifier: "gene-000910"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.
    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000913
    Identifier: "gene-000913"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000917
    Identifier: "gene-000917"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000923
    Identifier: "gene-000923"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000924
    Identifier: "gene-000924"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000931
    Identifier: "gene-000931"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000935
    Identifier: "gene-000935"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000936
    Identifier: "gene-000936"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000938
    Identifier: "gene-000938"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000945
    Identifier: "gene-000945"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000946
    Identifier: "gene-000946"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000949
    Identifier: "gene-000949"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000952
    Identifier: "gene-000952"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000957
    Identifier: "gene-000957"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000959
    Identifier: "gene-000959"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000962
    Identifier: "gene-000962"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000966
    Identifier: "gene-000966"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000968
    Identifier: "gene-000968"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000973
    Identifier: "gene-000973"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000975
    Identifier: "gene-000975"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000979
    Identifier: "gene-000979"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000980
    Identifier: "gene-000980"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000987
    Identifier: "gene-000987"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

## Entry 000000988
    Identifier: "gene-000988"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: The inflation factor labmda should be >= 1. Values < 1 will be reset to 1.

## Entry 000000990
    Identifier: "gene-000990"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: LD has very small or negative eigenvalues. Epsilon will be added to the diagonal.

## Entry 000000994
    Identifier: "gene-000994"
    Status: ORIGINAL_RETURN_CAPTURED

    Original warning: If LD is not provided, an identity matrix is assumed. This may not be accurate in cases where the LD is appreciable.

