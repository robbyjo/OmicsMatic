options(warn=2)
.libPaths(c("D:/projects/JLinAlg/build/high-impact-stats-1/build/dunnett-high-impact-1/reference-runtime-2/library",.libPaths()))
install.packages("D:/projects/JLinAlg/build/high-impact-stats-1/build/dunnett-high-impact-1/reference-runtime-2/source/multcomp_1.4-29.tar.gz",repos=NULL,type="source",lib="D:/projects/JLinAlg/build/high-impact-stats-1/build/dunnett-high-impact-1/reference-runtime-2/library")
stopifnot(as.character(packageVersion("multcomp",lib.loc="D:/projects/JLinAlg/build/high-impact-stats-1/build/dunnett-high-impact-1/reference-runtime-2/library"))=="1.4-29")
