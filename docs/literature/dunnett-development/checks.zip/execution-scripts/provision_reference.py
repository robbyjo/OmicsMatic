import gzip,hashlib,json,os,subprocess,tarfile,time,traceback,urllib.request,zipfile
from pathlib import Path,PurePosixPath
b=Path(__file__).resolve().parent;out=b/'reference-runtime-1';out.mkdir();library=out/'library';library.mkdir();rscript=Path('C:/Program Files/R/R-4.6.1/bin/Rscript.exe');retrievals=[]
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def fetch(url,name,maximum=67108864):
 with urllib.request.urlopen(url,timeout=120) as response:raw=response.read(maximum+1);assert len(raw)<=maximum
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(raw);retrievals.append(dict(file=name,url=url,**pin(p)));save(out/'RETRIEVALS.json',retrievals);return p
def process(name,code,timeout=180):
 worker=out/(name+'.R');worker.write_text(code,encoding='utf8',newline='\n');cmd=[str(rscript),'--vanilla',str(worker)];save(out/(name+'.command.json'),cmd);env={k:v for k,v in os.environ.items() if not k.startswith('LC_')};env.update(LANG='C',LANGUAGE='C',LC_ALL='C');began=time.monotonic()
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:p=subprocess.run(cmd,env=env,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=timeout)
 save(out/(name+'.PROCESS.json'),dict(exit_code=p.returncode,seconds=time.monotonic()-began));assert p.returncode==0,name;print('PASS',name,flush=True)
def quote(p):return json.dumps(str(p).replace('\\','/'))
try:
 archive=fetch('https://cran.r-project.org/src/contrib/Archive/multcomp/multcomp_1.4-29.tar.gz','source/multcomp_1.4-29.tar.gz')
 index=fetch('https://cran.r-project.org/bin/windows/contrib/4.6/PACKAGES.gz','windows-PACKAGES.gz');text=gzip.decompress(index.read_bytes()).decode();records={}
 for block in text.strip().split('\n\n'):
  fields={};last=None
  for line in block.splitlines():
   if line.startswith((' ','\t')) and last:fields[last]+=' '+line.strip()
   elif ': ' in line:last,value=line.split(': ',1);fields[last]=value
  if 'Package' in fields:records[fields['Package']]=fields
 downloads=[]
 for package in ['mvtnorm','sandwich','zoo','TH.data']:
  entry=records[package];name=package+'_'+entry['Version']+'.zip';p=fetch('https://cran.r-project.org/bin/windows/contrib/4.6/'+name,'binary/'+name)
  assert hashlib.md5(p.read_bytes()).hexdigest()==entry['MD5sum'];downloads.append(p)
  fetch('https://cran.r-project.org/src/contrib/'+package+'_'+entry['Version']+'.tar.gz','source/'+package+'_'+entry['Version']+'.tar.gz')
  # Windows package archives are extracted unchanged into this new private library.
  with zipfile.ZipFile(p) as z:
   for item in z.infolist():
    path=PurePosixPath(item.filename);assert not path.is_absolute() and '..' not in path.parts;target=library.joinpath(*path.parts);assert target.resolve().is_relative_to(library.resolve())
    if item.is_dir():target.mkdir(parents=True,exist_ok=True)
    else:target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists();target.write_bytes(z.read(item))
 process('install-original-multcomp','options(warn=2)\n.libPaths(c('+quote(library)+',.libPaths()))\ninstall.packages('+quote(archive)+',repos=NULL,type="source",lib='+quote(library)+')\nstopifnot(as.character(packageVersion("multcomp",lib.loc='+quote(library)+'))=="1.4-29")\n')
 process('fit-original-dunnett','options(warn=2)\n.libPaths(c('+quote(library)+',.libPaths()))\nlibrary(multcomp)\nset.seed(19870624)\nx<-list(Control=c(2.9,3.0,2.5,2.6,3.2),A=c(3.8,2.7,4.0,2.4),B=c(2.8,3.4,3.7,2.2,2.0))\nd<-data.frame(value=unlist(x),group=factor(rep(names(x),lengths(x)),levels=names(x)))\nm<-lm(value~group,data=d)\ng<-glht(m,linfct=mcp(group="Dunnett"),alternative="two.sided")\ns<-summary(g,test=adjusted("single-step",maxpts=1000000,abseps=1e-6))\nc<-confint(g)\nsaveRDS(list(input=x,model=m,contrasts=g,summary=s,intervals=c,session=sessionInfo()),'+quote(out/'original-dunnett-fit.rds')+')\nwrite.table(data.frame(comparison=names(s$test$tstat),estimate=s$test$coefficients,se=s$test$sigma,t=s$test$tstat,adjusted_p=unname(s$test$pvalues),lower=c$confint[,"lwr"],upper=c$confint[,"upr"]),'+quote(out/'original-dunnett.tsv')+',sep="\\t",row.names=FALSE,quote=TRUE)\nwriteLines(capture.output(sessionInfo()),'+quote(out/'SESSION.txt')+')\nprint(s);print(c)\n')
 installed={p.relative_to(library).as_posix():pin(p) for p in library.rglob('*') if p.is_file()};save(out/'INSTALLED-FILES.json',installed)
 save(out/'COMPLETED.json',dict(status='PASS_WORKSPACE_ORIGINAL_MULTCOMP1429_PROVISION_AND_FIRST_DUNNETT_REFERENCE_FIT',rscript=pin(rscript),retrievals=retrievals,private_library=str(library),global_libraries_modified=False,first_fit=dict(cases=1,comparisons=2,original_rds=pin(out/'original-dunnett-fit.rds'),original_table=pin(out/'original-dunnett.tsv')),java_adapter_implemented=False,native_dunnett_inference_implemented=False,new_catalog_integrations=0,whole_goal_complete=False));print('PASS original1.4-29 reference fit; no adapter admission yet',flush=True)
except Exception as e:
 code=3 if isinstance(e,(FileNotFoundError,PermissionError,urllib.error.URLError)) else 2
 save(out/'FAILURE.json',dict(status='SKIP3_REFERENCE_ANALYSIS_SKIPPED' if code==3 else 'FAIL2_NO_REFERENCE_RESULT_ADMITTED',error=repr(e),traceback=traceback.format_exc(),completed_retrievals=retrievals,required_action='Retain all partial downloads/install/fit logs. Supply a permitted R4.6.1 installation and exact private original multcomp1.4-29 dependencies, then retry NEW output. Do not substitute editions or accept partial fits. No project adapter or whole-package qualification is established.'));print('SKIP3 reference analysis skipped' if code==3 else 'FAIL2 no reference result admitted',repr(e),flush=True);raise
