from pathlib import Path
b=Path(__file__).resolve().parent
s=(b/'build_implementation.py').read_text()
s=s.replace("out=b/'build-1'","out=b/'build-2'")
s=s.replace("'src/test/java/org/jlinalg/cli/DunnettCliTest.java']","'src/test/java/org/jlinalg/cli/DunnettCliTest.java','src/test/java/org/jlinalg/stats/DunnettReferenceTest.java']+[p.relative_to(r).as_posix() for p in (r/'src/test/resources/org/jlinalg/stats/dunnett-fit').iterdir() if p.is_file()]")
s=s.replace("'org.jlinalg.stats.DunnettModelTest','--tests'","'org.jlinalg.stats.DunnettModelTest','--tests','org.jlinalg.stats.DunnettReferenceTest','--tests'")
(b/'build_implementation2.py').write_text(s,encoding='utf8')
s=(b/'run_implementation.py').read_text().replace("out=b/'execution-1'","out=b/'execution-1'").replace("build-1/","build-2/")
(b/'run_implementation2.py').write_text(s,encoding='utf8')
