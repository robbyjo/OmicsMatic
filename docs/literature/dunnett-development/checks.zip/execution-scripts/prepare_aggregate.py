import json
from pathlib import Path
b=Path(__file__).resolve().parent
s=(b/'verify_executions.py').read_text().replace("assert (b/'execution-2/COMPLETED.json').is_file();", "assert (b/'execution-4/COMPLETED.json').is_file();")
s=s.replace("for case in sorted((b/'execution-2').iterdir()):", "selected=[b/'execution-3'/n for n in ['original-example','middle-control','one-residual-df','equal-means']]+[p for p in (b/'execution-4').iterdir() if p.is_dir()]\n for case in sorted(selected):")
s=s.replace("source=b/'execution-2/original-example/result'", "source=b/'execution-3/original-example/result'")
(b/'verify_executions3.py').write_text(s,encoding='utf8')
