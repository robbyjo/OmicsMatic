import csv,hashlib,json,math,os,subprocess,time,traceback
from pathlib import Path
b=Path(__file__).resolve().parent;out=b/'reference-fit-1';out.mkdir();provider=b/'reference-runtime-2';library=provider/'library';rscript=Path('C:/Program Files/R/R-4.6.1/bin/Rscript.exe')
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def quote(p):return json.dumps(str(p).replace('\\','/'))
try:
 original_log=(provider/'install-original-multcomp.stderr').read_text();assert '* DONE (multcomp)' in original_log
 # The previous post-install check compared R's normalized package_version string
 # (1.4.29) to the literal DESCRIPTION spelling (1.4-29). Check both explicitly.
 code='''options(warn=2)
.libPaths(c(LIBRARY,.libPaths()))
stopifnot(packageDescription("multcomp")$Version=="1.4-29",as.character(packageVersion("multcomp"))=="1.4.29")
startup_warnings<-character()
withCallingHandlers(library(multcomp),warning=function(w){
  message(conditionMessage(w))
  if(grepl("was built under R version 4.6.2",conditionMessage(w),fixed=TRUE)){
    startup_warnings<<-c(startup_warnings,conditionMessage(w));invokeRestart("muffleWarning")
  }else stop(w)
})
writeLines(startup_warnings,WARNINGS)
set.seed(19870624)
x<-list(Control=c(2.9,3.0,2.5,2.6,3.2),A=c(3.8,2.7,4.0,2.4),B=c(2.8,3.4,3.7,2.2,2.0))
d<-data.frame(value=unlist(x),group=factor(rep(names(x),lengths(x)),levels=names(x)))
m<-lm(value~group,data=d)
g<-glht(m,linfct=mcp(group="Dunnett"),alternative="two.sided")
s<-summary(g,test=adjusted("single-step",maxpts=1000000,abseps=1e-6))
c<-confint(g)
saveRDS(list(input=x,model=m,contrasts=g,summary=s,intervals=c,session=sessionInfo(),startup_warnings=startup_warnings),MODEL)
write.table(data.frame(comparison=names(s$test$tstat),estimate=s$test$coefficients,se=s$test$sigma,t=s$test$tstat,adjusted_p=unname(s$test$pvalues),lower=c$confint[,"lwr"],upper=c$confint[,"upr"]),TABLE,sep="\\t",row.names=FALSE,quote=TRUE)
writeLines(capture.output(sessionInfo()),SESSION)
writeLines(c(paste("pvalue_error",attr(s$test$pvalues,"error")),paste("r4_6_2_build_warnings",length(startup_warnings))),DIAGNOSTICS)
print(s);print(c)
'''
 for token,path in [('LIBRARY',library),('WARNINGS',out/'STARTUP-BUILD-WARNINGS.txt'),('MODEL',out/'original-dunnett-fit.rds'),('TABLE',out/'original-dunnett.tsv'),('SESSION',out/'SESSION.txt'),('DIAGNOSTICS',out/'DIAGNOSTICS.txt')]:code=code.replace(token,quote(path))
 worker=out/'fit.R';worker.write_text(code,encoding='utf8',newline='\n');command=[str(rscript),'--vanilla',str(worker)];save(out/'command.json',command);environment={k:v for k,v in os.environ.items() if not k.startswith('LC_')};environment.update(LANG='C',LANGUAGE='C',LC_ALL='C');began=time.monotonic()
 with (out/'stdout').open('xb') as so,(out/'stderr').open('xb') as se:p=subprocess.run(command,env=environment,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=180)
 save(out/'PROCESS.json',dict(exit_code=p.returncode,seconds=time.monotonic()-began));assert p.returncode==0
 with (out/'original-dunnett.tsv').open(newline='') as f:rows=list(csv.DictReader(f,delimiter='\t'))
 assert len(rows)==2
 for row,t,pvalue in zip(rows,[.90874545,-.05007117],[.58325114,.99819341]):assert math.isclose(float(row['t']),t,abs_tol=1e-8) and math.isclose(float(row['adjusted_p']),pvalue,abs_tol=1e-4)
 installed={p.relative_to(library).as_posix():pin(p) for p in library.rglob('*') if p.is_file()};save(out/'INSTALLED-FILES.json',installed)
 save(out/'COMPLETED.json',dict(status='PASS_FIRST_ORIGINAL_MULTCOMP1429_DUNNETT_REFERENCE_FIT',comparisons=2,official_scipy_example_agrees_at_documented_display_precision=True,pvalue_display_tolerance=1e-4,original_rds=pin(out/'original-dunnett-fit.rds'),startup_warnings=pin(out/'STARTUP-BUILD-WARNINGS.txt'),diagnostics=pin(out/'DIAGNOSTICS.txt'),package_declaration='1.4-29',R_normalized_package_version='1.4.29',private_library=str(library),global_libraries_modified=False,installation_completed_in_previous_attempt=True,previous_attempt_post_install_version_check_failed=True,java_adapter_implemented=False,native_dunnett_inference_implemented=False,new_catalog_integrations=0,whole_goal_complete=False));print('PASS original multcomp1.4-29 first Dunnett fit;2 comparisons; startup build warnings retained; adapter still pending',flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc(),required_action='Preserve the complete original source/install/fit records and resolve the named prerequisite or numerical issue. No project Dunnett adapter or scientific result is admitted by a partial fit.'));print(repr(e),flush=True);raise
