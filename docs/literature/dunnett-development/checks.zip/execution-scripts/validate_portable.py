import hashlib,json,shutil,subprocess,time,traceback,xml.etree.ElementTree as ET
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];out=b/'portable-1';out.mkdir()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 return dict(bytes=p.stat().st_size,sha256=h.hexdigest())
def linux(p):return '/mnt/d/'+p.resolve().as_posix().split(':/',1)[1]
try:
 assert (b/'build-3/COMPLETED.json').is_file();classes=['org.jlinalg.stats.DunnettModelTest','org.jlinalg.stats.DunnettReferenceTest','org.jlinalg.cli.DunnettCliTest','org.jlinalg.cli.DunnComparisonsCliTest','org.jlinalg.cli.TukeyKramerCliTest'];copied=[]
 for name in classes:
  folder,simple=name.rsplit('.',1);source=r/'build/classes/java/test'/folder.replace('.','/')
  for p in source.glob(simple+'*.class'):
   target=out/'test-classes'/folder.replace('.','/')/p.name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target);copied.append(target)
 shutil.copytree(r/'src/test/resources/org/jlinalg/stats/dunnett-fit',out/'test-resources/org/jlinalg/stats/dunnett-fit')
 console=r/'build/nfcore-atacseq121-1/linux-test-runtime-1/junit-platform-console-standalone-1.13.4.jar';save(out/'TEST-RUNTIME.json',dict(console=pin(console),classes={p.relative_to(out).as_posix():pin(p) for p in copied}))
 cmd=['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--exec','/usr/bin/java','-Xmx2048m','-jar',linux(console),'execute','--class-path',':'.join(linux(p) for p in [b/'build-3/jar/omicsmatic-0.4.0.jar',out/'test-classes',out/'test-resources'])]
 for name in classes:cmd.extend(['--select-class',name])
 cmd.extend(['--reports-dir',linux(out/'linux-junit-reports'),'--disable-ansi-colors']);save(out/'command.json',cmd);start=time.monotonic()
 with (out/'stdout').open('xb') as so,(out/'stderr').open('xb') as se:p=subprocess.run(cmd,cwd=r,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=180)
 save(out/'PROCESS.json',dict(exit_code=p.returncode,seconds=time.monotonic()-start));assert p.returncode==0
 trees=[ET.parse(p).getroot() for p in (out/'linux-junit-reports').glob('TEST-*.xml')];counts={k:sum(int(t.attrib.get(k,0)) for t in trees) for k in ['tests','errors','failures','skipped']};assert counts==dict(tests=30,errors=0,failures=0,skipped=0),counts
 save(out/'COMPLETED.json',dict(status='PASS30_LINUX_JAVA_AND_INPUT_REFUSAL_TESTS',junit=counts,scope='Java fits and CLI input/runtime-unavailable controls only; original R inference qualified on Windows, not executed on Linux',artifact=pin(b/'build-3/jar/omicsmatic-0.4.0.jar')));print('PASS',counts,flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc()));print(repr(e),flush=True);raise
