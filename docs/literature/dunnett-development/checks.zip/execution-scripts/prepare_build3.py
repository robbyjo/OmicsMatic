from pathlib import Path
b=Path(__file__).resolve().parent
s=(b/'build_implementation2.py').read_text().replace("out=b/'build-2'","out=b/'build-3'")
(b/'build_implementation3.py').write_text(s,encoding='utf8')
s=(b/'run_implementation2.py').read_text().replace("out=b/'execution-1'","out=b/'execution-2'").replace('build-2/','build-3/')
s=s.replace("save(case/'request.json',request);cmd=", "\n  if name=='unbalanced-five':request.update(maxpts=10000000,absolute_tolerance=1e-5)\n  save(case/'request.json',request);cmd=")
(b/'run_implementation3.py').write_text(s,encoding='utf8')
