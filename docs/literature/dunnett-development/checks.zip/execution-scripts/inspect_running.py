import datetime,json
from pathlib import Path
b=Path(__file__).resolve().parent;p=b/'execution-2/unbalanced-five/request.json'
print('current_utc',datetime.datetime.now(datetime.timezone.utc).isoformat())
print('case_request_age_seconds',datetime.datetime.now().timestamp()-p.stat().st_mtime)
print('worker_files',[x.name for x in (p.parent/'result/worker').iterdir()])
print('process_complete',(p.parent/'PROCESS.json').exists())
