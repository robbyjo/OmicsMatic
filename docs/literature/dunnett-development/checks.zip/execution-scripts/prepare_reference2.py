from pathlib import Path
b=Path(__file__).resolve().parent;text=(b/'provision_reference.py').read_text();text=text.replace("out=b/'reference-runtime-1'","out=b/'reference-runtime-2'")
old=" with urllib.request.urlopen(url,timeout=120) as response:raw=response.read(maximum+1);assert len(raw)<=maximum";assert text.count(old)==1
new=""" previous=b/'reference-runtime-1'/name
 prior=[row for row in json.loads((b/'reference-runtime-1/RETRIEVALS.json').read_bytes()) if row['file']==name and row['url']==url]
 if previous.exists() and len(prior)==1:
  assert pin(previous)=={k:prior[0][k] for k in ['bytes','sha256']};raw=previous.read_bytes()
 else:
  with urllib.request.urlopen(url,timeout=120) as response:raw=response.read(maximum+1)
 assert len(raw)<=maximum"""
text=text.replace(old,new)
old="  assert hashlib.md5(p.read_bytes()).hexdigest()==entry['MD5sum'];downloads.append(p)";assert text.count(old)==1
text=text.replace(old,"  if 'MD5sum' in entry:assert hashlib.md5(p.read_bytes()).hexdigest()==entry['MD5sum']\n  save(out/(package+'-INDEX-RECORD.json'),entry);downloads.append(p)")
old=" process('fit-original-dunnett','options(warn=2)\\n.libPaths(c('";assert text.count(old)==1
new=" process('fit-original-dunnett','options(warn=2)\\n.libPaths(c('"
# Use a narrowly classified, recorded startup condition; numerical/model warnings remain fatal.
old="\\nlibrary(multcomp)\\nset.seed(19870624)";assert text.count(old)==1
new="\\nstartup_warnings<-character()\\nwithCallingHandlers(library(multcomp),warning=function(w){message(conditionMessage(w));if(grepl(\"was built under R version\",conditionMessage(w),fixed=TRUE)){startup_warnings<<-c(startup_warnings,conditionMessage(w));invokeRestart(\"muffleWarning\")}else stop(w)})\\nwriteLines(startup_warnings,'+quote(out/'STARTUP-BUILD-WARNINGS.txt')+')\\nset.seed(19870624)"
text=text.replace(old,new)
old="global_libraries_modified=False,first_fit=";assert text.count(old)==1
text=text.replace(old,"global_libraries_modified=False,dependency_build_warning_policy='Record original package-build-version warnings for the tested R4.6.1 plus declared original Windows dependency builds; all numerical/model warnings remain fatal. No author-runtime equivalence.',startup_warning_record=pin(out/'STARTUP-BUILD-WARNINGS.txt'),first_fit=")
p=b/'provision_reference2.py';assert not p.exists();p.write_text(text,newline='\n')
