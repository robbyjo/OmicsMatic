import hashlib,json,shutil,subprocess,traceback,zipfile
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];out=b/'closure-1';out.mkdir();public=r/'docs/literature/dunnett-development'
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def pin(p):
 h=hashlib.sha256();size=0
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):size+=len(block);h.update(block)
 return dict(bytes=size,sha256=h.hexdigest())
try:
 win=json.loads((b/'build-3/COMPLETED.json').read_text());lin=json.loads((b/'portable-1/COMPLETED.json').read_text());verification=json.loads((b/'verification-1/COMPLETED.json').read_text())
 assert win['junit']==lin['junit']==dict(tests=30,errors=0,failures=0,skipped=0)
 assert len(verification['cases'])==9 and sum('report' in row for row in verification['cases'])==6
 assert verification['tampered_copies_refused']==3 and verification['linux_read_only_verifier_exit']==0
 jar=b/'build-3/jar/omicsmatic-0.4.0.jar';assert pin(jar)==win['artifact']==lin['artifact']
 build_guards=json.loads((b/'build-3/SOURCES.json').read_text());assert all(pin(r/n)==v for n,v in build_guards.items())
 cancelled=[]
 for name in ['execution-2','execution-3']:
  p=b/name/'unbalanced-five/result';process=json.loads((p/'worker/process.json').read_text());assert (p/'CANCEL').is_file() and not (p/'COMPLETED.json').exists()
  assert not json.loads((p/'analysis.json').read_text())['result_admitted']
  assert all(not x['same_owned_process_alive'] for x in process['owned_process_cleanup'])
  cancelled.append(dict(attempt=name,cause=json.loads((p/'analysis.json').read_text())['cause'],owned_process_cleanup=process['owned_process_cleanup']))
 # Existing catalog stays byte-for-byte at the predecessor; this is a component qualification.
 p=subprocess.run(['git','diff','--exit-code','HEAD','--','docs/literature/omics-2023-2026','tools/literature/reviewed-uses.json'],cwd=r,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False);assert p.returncode==0
 names=list(build_guards)+['tools/literature/common_statistics/dunnett_sources.py','tools/literature/common_statistics/verify_dunnett_evidence.py','src/main/java/org/jlinalg/cli/NextflowFiles.java','src/main/java/org/jlinalg/cli/NextflowJson.java','src/main/java/org/jlinalg/cli/NextflowParameters.java','src/main/java/org/jlinalg/cli/SimpleJson.java','src/main/java/org/jlinalg/stats/StatisticsSupport.java','docs/vignettes/dunnett-control-comparisons.md','docs/vignettes/posthoc-comparisons.md','docs/literature/IMPLEMENTATION_PRIORITY.md','docs/literature/dunnett-development/README.md']
 guards={name:pin(r/name) for name in sorted(set(names))};save(out/'SOURCE_GUARDS.json',guards)
 payloads={}
 def add(name,path):
  assert name not in payloads and path.is_file() and not path.is_symlink();payloads[name]=path
 for name in guards:add('current-source/'+name,r/name)
 for path in b.glob('*.py'):add('execution-scripts/'+path.name,path)
 dirs=['runtime-probe-1','reference-runtime-1','reference-runtime-2','reference-fit-1','native-fit-reference-1','build-1','build-2','build-3','execution-1','execution-2','execution-3','execution-4','source-review-1','portable-1','verification-1']
 excluded=[]
 for folder in dirs:
  for path in sorted((b/folder).rglob('*')):
   if not path.is_file():continue
   rel=path.relative_to(b);parts=rel.parts
   skip=any(s in parts for s in ['library','jar','test-classes','test-report','__pycache__']) or path.suffix in ['.class','.pyc'] or path.name.endswith(('.tar.gz','.zip'))
   if 'tamper-controls' in parts and len(parts)>parts.index('tamper-controls')+2:skip=True
   if skip:
    # Runtime/class providers are covered by their complete saved manifests.
    if 'library' not in parts and 'jar' not in parts and 'test-classes' not in parts:excluded.append(dict(path=rel.as_posix(),pin=pin(path),reason='retained private provider/download or reproducible tamper-copy payload'))
    continue
   add(rel.as_posix(),path)
 original=b/'reference-runtime-2/source/multcomp_1.4-29.tar.gz';assert original.is_file();add('upstream/multcomp_1.4-29.tar.gz',original)
 save(out/'EXCLUDED_PRIVATE_PAYLOADS.json',excluded);save(out/'CANCELLED_ATTEMPTS.json',cancelled)
 add('closure/SOURCE_GUARDS.json',out/'SOURCE_GUARDS.json');add('closure/EXCLUDED_PRIVATE_PAYLOADS.json',out/'EXCLUDED_PRIVATE_PAYLOADS.json');add('closure/CANCELLED_ATTEMPTS.json',out/'CANCELLED_ATTEMPTS.json')
 index={name:pin(path) for name,path in sorted(payloads.items())};save(out/'PAYLOADS.json',index)
 sums=''.join(v['sha256']+'  '+name+'\n' for name,v in index.items());(out/'SHA256SUMS').write_text(sums,encoding='utf8',newline='\n')
 archive=public/'checks.zip';assert not archive.exists()
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for name,path in sorted(payloads.items()):z.write(path,name)
  z.write(out/'SHA256SUMS','SHA256SUMS')
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None and len(z.namelist())==len(index)+1
  assert z.read('SHA256SUMS').decode('utf8')==sums
  for name,expected in index.items():
   raw=z.read(name);assert dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())==expected,name
 assert all(pin(r/n)==v for n,v in guards.items())
 shutil.copyfile(b/'source-review-1/SOURCE_REVIEW.json',public/'SOURCE_REVIEW.json')
 (public/'WARNINGS.md').write_text('''# Warnings and required actions

SKIP3 means dependent analysis skipped: supply a permitted accessible R runtime,
multcomp 1.4-29/dependencies or a separately qualified required model, then retry
NEW output. FAIL2 means no complete family admitted: preserve partial files,
read FAILURE.txt and original worker logs, correct the named input/model,
numerical, integration-budget or integrity issue and retry NEW output.

The actual reference R 4.6.1 provider loads two binaries built under R 4.6.2.
Original warnings are retained under the explicit RECORD_BUILD_WARNINGS policy;
the FAIL policy refuses them. Install matching permitted builds and select FAIL
to avoid the mismatch. Other original model/numerical warnings remain fatal.

The default five-group precision request fails. Two tighter interval attempts
were cancelled with owned-process cleanup verified. A separate case passes at
maxpts=1000000, absolute_tolerance=0.0001 and interval_probability_tolerance=0.001.
Those wider probability tolerances do not establish the precision requested by
the failed/cancelled attempts. All records remain retained and labeled.

Small original adjusted probabilities, including numeric zeros, may have
unresolved relative precision. Read NUMERIC-WARNING.txt; retain original values,
error estimates and native unadjusted log tails. Never fabricate a floor or
interpret a numeric zero as exact mathematical zero probability.

Six admitted synthetic packaged cases and three expected failure/skip cases
qualify the bounded ordinary method. Java/input controls pass on Windows and
Linux; actual original R inference is qualified on Windows only. Provider bytes
are fingerprinted, not bundled; replay requires the same permitted provider.
Hash checks establish recorded integrity, not publisher authenticity or an
independent multivariate calculation. Repeated/paired, mixed, nested,
covariate-adjusted, unequal-variance and unresolved source contexts remain out of
scope. No whole Prism/multcomp, paper, deployment or full-goal badge is claimed.
''',encoding='utf8',newline='\n')
 fixture=r/'src/test/resources/org/jlinalg/stats/dunnett-fit';contrasts=sum(1 for _ in (fixture/'expected.tsv').open())-1;corr=sum(1 for _ in (fixture/'correlation.tsv').open())-1
 results=[]
 selected=[b/'execution-3'/n for n in ['original-example','middle-control','one-residual-df','equal-means']]+[p for p in (b/'execution-4').iterdir() if p.is_dir()]
 for path in sorted(selected):
  process=json.loads((path/'PROCESS.json').read_text());assert process['exit_code']==process['expected'];analysis=json.loads((path/'result/analysis.json').read_text())
  results.append(dict(case=path.name,evidence_path=path.relative_to(b).as_posix(),exit_code=process['exit_code'],result_admitted=analysis['result_admitted'],request=json.loads((path/'request.json').read_text()),native_audit=analysis.get('native_audit'),cause=analysis.get('cause')))
 validation=dict(status='PASS_SCOPED_DUNNETT_ORDINARY_COMPONENT',profile='dunnett-multcomp1429-oneway-v1',windows_tests=win['junit'],linux_same_tests=lin['junit'],independent_base_R_models=64,independent_base_R_contrasts=contrasts,independent_base_R_correlation_entries=corr,packaged_original_R_cases=results,recorded_result_verification=verification,cancelled_attempts=cancelled,artifact=pin(jar),controls_archive=pin(archive),indexed_payloads=len(index),all_archive_payloads_read_back=True,source_guards=guards,source_review=pin(public/'SOURCE_REVIEW.json'),warnings=pin(public/'WARNINGS.md'),existing_jar_members_preserved_except_explicit_posthoc_router=True,provider_bytes_bundled=False,original_R_inference_platform='Windows R4.6.1; no Linux R inference qualification',multivariate_inference='Original multcomp1.4-29/mvtnorm; Java independently audits the ordinary model and probability/interval bounds, not the multivariate integral',new_catalog_integrations=0,admitted_catalog_integrations_unchanged=127,whole_vendor_tool_qualified=False,whole_paper_reproduced=False,whole_goal_complete=False)
 save(public/'VALIDATION.json',validation);save(out/'COMPLETED.json',dict(status='PASS_SCOPED_DUNNETT_EVIDENCE_CLOSED',validation=pin(public/'VALIDATION.json'),archive=pin(archive),indexed_payloads=len(index),reference_contrasts=contrasts,reference_correlations=corr));print('PASS closed',len(index),'payloads',pin(archive),flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc()));print(repr(e),flush=True);raise
