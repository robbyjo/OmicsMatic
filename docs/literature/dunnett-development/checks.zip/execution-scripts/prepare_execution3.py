from pathlib import Path
b=Path(__file__).resolve().parent
s=(b/'run_implementation4.py').read_text().replace("out=b/'execution-2'","out=b/'execution-3'")
s=s.replace("request.update(maxpts=10000000,absolute_tolerance=1e-5)","request.update(maxpts=10000000,absolute_tolerance=1e-5,interval_probability_tolerance=1e-4)")
(b/'run_implementation5.py').write_text(s,encoding='utf8')
s=(b/'verify_executions.py').read_text().replace("execution-2/","execution-3/").replace("b/'execution-2'","b/'execution-3'")
(b/'verify_executions2.py').write_text(s,encoding='utf8')
