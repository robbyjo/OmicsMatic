import tarfile
from pathlib import Path
b=Path(__file__).resolve().parent/'reference-runtime-2'
for p in b.rglob('mvtnorm_*.tar.gz'):
 with tarfile.open(p) as t:
  for m in t.getmembers():
   if m.name.endswith('.R'):
    s=t.extractfile(m).read().decode()
    a=s.find('qmvt <- function')
    if a>=0:print(s[a:a+13500])
