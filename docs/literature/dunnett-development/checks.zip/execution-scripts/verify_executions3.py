import importlib.util,json,shutil,subprocess,sys,tempfile,traceback,zipfile,hashlib
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];out=b/'verification-1';out.mkdir()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
try:
 assert (b/'execution-4/COMPLETED.json').is_file();module=r/'tools/literature/common_statistics/verify_dunnett_evidence.py';spec=importlib.util.spec_from_file_location('verify_dunnett',module);v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
 cases=[]
 selected=[b/'execution-3'/n for n in ['original-example','middle-control','one-residual-df','equal-means']]+[p for p in (b/'execution-4').iterdir() if p.is_dir()]
 for case in sorted(selected):
  if not case.is_dir():continue
  expected=json.loads((case/'PROCESS.json').read_text())['expected'];result=case/'result'
  if expected==0:
   report=v.verify(result);cases.append(dict(case=case.name,report=report))
  else:
   try:v.verify(result);raise AssertionError('Failed/skipped result accepted')
   except (ValueError,OSError):pass
   cases.append(dict(case=case.name,failed_or_skipped_result_refused=True))
 # Tamper checks use newly created copies, never the original scientific result.
 source=b/'execution-3/original-example/result';tamper=out/'tamper-controls';tamper.mkdir()
 for kind in ['changed-input','unlisted-file','missing-manifest-member']:
  target=tamper/kind;shutil.copytree(source,target)
  if kind=='changed-input':
   with (target/'source-input.tsv').open('ab') as f:f.write(b'X\t7\n')
  elif kind=='unlisted-file':(target/'unexpected.txt').write_text('not in original result\n')
  else:(target/'worker/original-correlation.tsv').unlink()
  try:v.verify(target);raise AssertionError('Tampered copy accepted')
  except (ValueError,OSError) as error:save(tamper/(kind+'.json'),dict(status='PASS_TAMPERED_COPY_REFUSED',cause=str(error)))
 # Every preexisting executable member must be unchanged except the posthoc router.
 old=r/'build/common-stats-1/build-3/jar/omicsmatic-0.4.0.jar';new=b/'build-3/jar/omicsmatic-0.4.0.jar'
 with zipfile.ZipFile(old) as a,zipfile.ZipFile(new) as c:
  aa=set(a.namelist());cc=set(c.namelist());removed=sorted(aa-cc);changed=[n for n in sorted(aa&cc) if hashlib.sha256(a.read(n)).digest()!=hashlib.sha256(c.read(n)).digest()];added=sorted(cc-aa)
 assert not removed and changed==['org/jlinalg/cli/PosthocToolsCli.class'],(removed,changed)
 assert all(n.startswith(('org/jlinalg/stats/Dunnett','org/jlinalg/cli/Dunnett')) or n=='org/jlinalg/stats/dunnett-worker.R' for n in added),added
 save(out/'JAR_MEMBER_COMPATIBILITY.json',dict(status='PASS_ALL_PREEXISTING_MEMBERS_EXCEPT_EXPLICIT_POSTHOC_ROUTER_IDENTICAL',changed=changed,added=added,removed=removed))
 # Run the same read-only verifier in Linux against the unchanged Windows result.
 cmd=['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--exec','/usr/bin/python3','-B','/mnt/d/'+module.as_posix().split(':/',1)[1],'--result','/mnt/d/'+source.as_posix().split(':/',1)[1]];save(out/'linux-verifier-command.json',cmd)
 with (out/'linux-verifier-stdout').open('xb') as so,(out/'linux-verifier-stderr').open('xb') as se:p=subprocess.run(cmd,cwd=r,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=120)
 assert p.returncode==0
 save(out/'COMPLETED.json',dict(status='PASS_RECORDED_RESULT_INTEGRITY_AND_PRESERVATION_CONTROLS',cases=cases,tampered_copies_refused=3,linux_read_only_verifier_exit=p.returncode));print('PASS result checks,3 tampered-copy refusals,Linux read-only check and old JAR-member preservation',flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc()));print(repr(e),flush=True);raise
