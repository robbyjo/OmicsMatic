from pathlib import Path
b=Path(__file__).resolve().parent
s=(b/'run_implementation5.py').read_text().replace("out=b/'execution-3'","out=b/'execution-4'")
s=s.replace('outcomes=[]',"cases=[case for case in cases if case[0] in {'unbalanced-five','fail-build-warning','default-budget-failure','small-probability','missing-package'}]\n outcomes=[]")
s=s.replace('request.update(maxpts=10000000,absolute_tolerance=1e-5,interval_probability_tolerance=1e-4)','request.update(maxpts=1000000,absolute_tolerance=1e-4,interval_probability_tolerance=1e-3)')
(b/'run_implementation6.py').write_text(s,encoding='utf8')
