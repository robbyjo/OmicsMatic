import hashlib,json,shutil
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];s=b/'native-fit-reference-1';d=r/'src/test/resources/org/jlinalg/stats/dunnett-fit';d.mkdir(parents=True)
assert json.loads((s/'PROCESS.json').read_text())['exit_code']==0
pins={}
for name in ['reference.R','inputs.tsv','expected.tsv','correlation.tsv','SESSION.txt']:
 p=s/name;shutil.copyfile(p,d/name);pins[name]=dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
(d/'PROVENANCE.json').write_text(json.dumps(dict(scope='64 synthetic independent common-variance one-way models; base R 4.6.1 lm, vcov, sigma, df.residual, pt; no multivariate Dunnett inference',models=64,source_command=json.loads((s/'command.json').read_text()),source_exit_code=0,files=pins),indent=2)+'\n',encoding='utf8')
print('installed 64 independent base-R fit reference models')
