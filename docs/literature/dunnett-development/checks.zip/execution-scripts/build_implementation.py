import hashlib,json,os,shutil,subprocess,time,traceback,xml.etree.ElementTree as ET
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];out=b/'build-1';out.mkdir()
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 return dict(bytes=p.stat().st_size,sha256=h.hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
try:
 names=['src/main/java/org/jlinalg/stats/DunnettModel.java','src/main/java/org/jlinalg/cli/DunnettCli.java','src/main/java/org/jlinalg/cli/DunnettProcess.java','src/main/java/org/jlinalg/cli/PosthocToolsCli.java','src/main/java/org/jlinalg/cli/JLinAlgCli.java','src/main/resources/org/jlinalg/stats/dunnett-worker.R','src/test/java/org/jlinalg/stats/DunnettModelTest.java','src/test/java/org/jlinalg/cli/DunnettCliTest.java']
 guards={n:pin(r/n) for n in names};save(out/'SOURCES.json',guards)
 for name in guards:
  p=out/'sources'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/name,p)
 rel=out.relative_to(r).as_posix();init=out/'private.gradle';init.write_text("gradle.projectsEvaluated {\n rootProject.tasks.named('executableJar') { destinationDirectory.set(rootProject.layout.projectDirectory.dir('"+rel+"/jar')) }\n rootProject.tasks.named('test') { reports.junitXml.outputLocation.set(rootProject.layout.projectDirectory.dir('"+rel+"/test-results')); reports.html.outputLocation.set(rootProject.layout.projectDirectory.dir('"+rel+"/test-report')) }\n}\n",newline='\n')
 cmd=[str(r/'gradlew.bat'),'--no-daemon','--console=plain','-I',str(init),':test','--tests','org.jlinalg.stats.DunnettModelTest','--tests','org.jlinalg.cli.DunnettCliTest','--tests','org.jlinalg.cli.DunnComparisonsCliTest','--tests','org.jlinalg.cli.TukeyKramerCliTest',':executableJar'];save(out/'command.json',cmd);env=dict(os.environ,JAVA_HOME='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot');began=time.monotonic()
 with (out/'stdout').open('xb') as so,(out/'stderr').open('xb') as se:p=subprocess.run(cmd,cwd=r,env=env,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=900)
 save(out/'PROCESS.json',dict(exit_code=p.returncode,seconds=time.monotonic()-began));assert p.returncode==0
 trees=[ET.parse(p).getroot() for p in (out/'test-results').glob('TEST-*.xml')];counts={k:sum(int(t.attrib.get(k,0)) for t in trees) for k in ['tests','errors','failures','skipped']};assert counts['failures']==counts['errors']==0 and counts['tests']>=13,counts
 assert all(pin(r/n)==v for n,v in guards.items());save(out/'COMPLETED.json',dict(status='PASS_FOCUSED_DUNNETT_BUILD',junit=counts,artifact=pin(out/'jar/omicsmatic-0.4.0.jar'),new_catalog_integrations=0));print('PASS',counts,flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc()));print(repr(e),flush=True);raise
