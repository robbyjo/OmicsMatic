import tarfile
from pathlib import Path
b=Path(__file__).resolve().parent
for p in (b/'reference-runtime-2').rglob('multcomp_1.4-29.tar.gz'):
 print('ARCHIVE',p)
 with tarfile.open(p) as t:
  for m in t.getmembers():
   if m.name.endswith('.R'):
    s=t.extractfile(m).read().decode()
    if 'adjusted_calpha <-' in s or 'pqglht <-' in s:
     print(m.name);print(s)
