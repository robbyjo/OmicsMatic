from pathlib import Path
b=Path(__file__).resolve().parent
s=(b/'run_implementation3.py').read_text()
old="('fail-build-warning',[('Control',[0,2]),('T',[3,4])],'Control',2)"
new=old+",('default-budget-failure',[('A',[0,1,4]),('B',[2,6,9,10]),('Control',[1,2]),('D',[3]),('E',[-2,-1,0,5,8])],'Control',2),('small-probability',[('Control',[-1,0,1]),('A',[99,100,101]),('B',[49,50,51])],'Control',0),('missing-package',[('Control',[0,2]),('T',[3,4])],'Control',3)"
assert old in s;s=s.replace(old,new)
s=s.replace("save(case/'request.json',request);cmd=", "\n  if name=='missing-package':\n   (case/'empty-library').mkdir();request['library']=str(case/'empty-library')\n  save(case/'request.json',request);cmd=")
s=s.replace("outcomes.append(status)","\n  if name=='default-budget-failure':assert (result/'worker/partial-original-fit.rds').is_file() and 'Completion with error > abseps' in (result/'worker/original-error.txt').read_text()\n  if name=='small-probability':assert (result/'NUMERIC-WARNING.txt').is_file()\n  outcomes.append(status)")
(b/'run_implementation4.py').write_text(s,encoding='utf8')
