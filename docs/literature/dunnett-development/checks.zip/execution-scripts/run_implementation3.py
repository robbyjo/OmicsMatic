import hashlib,json,os,subprocess,time,traceback
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];out=b/'execution-2';out.mkdir()
def save(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 return dict(bytes=p.stat().st_size,sha256=h.hexdigest())
try:
 jar=b/'build-3/jar/omicsmatic-0.4.0.jar';assert (b/'build-3/COMPLETED.json').is_file()
 java='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe'
 library=b/'reference-runtime-2/library';rhome=Path('C:/Program Files/R/R-4.6.1')
 cases=[('original-example',[('Control',[2.9,3,2.5,2.6,3.2]),('A',[3.8,2.7,4,2.4]),('B',[2.8,3.4,3.7,2.2,2])],'Control',0),('middle-control',[('Z',[8]),('対照',[1,2,3]),('A',[4,6])],'対照',0),('one-residual-df',[('Control',[0,2]),('Treatment',[3])],'Control',0),('equal-means',[('Control',[1,2,3]),('B',[0,2,4]),('A',[2])],'Control',0),('unbalanced-five',[('A',[0,1,4]),('B',[2,6,9,10]),('Control',[1,2]),('D',[3]),('E',[-2,-1,0,5,8])],'Control',0),('fail-build-warning',[('Control',[0,2]),('T',[3,4])],'Control',2)]
 outcomes=[]
 for name,groups,control,expected in cases:
  case=out/name;case.mkdir();data='group\tvalue\n'+''.join(f'{label}\t{v}\n' for label,values in groups for v in values);(case/'input.tsv').write_text(data,encoding='utf8',newline='\n')
  request=dict(schema_version=1,input='input.tsv',out='result',control=control,design='independent-common-variance',confidence_level=.95,data_provenance='Synthetic integration validation; no biological data',assumptions_declaration='Independent Gaussian common-variance model explicitly selected for this numerical control',r_home=str(rhome),rscript=str(rhome/'bin/Rscript.exe'),library=str(library),startup_warning_policy='FAIL' if name=='fail-build-warning' else 'RECORD_BUILD_WARNINGS')
  
  if name=='unbalanced-five':request.update(maxpts=10000000,absolute_tolerance=1e-5)
  save(case/'request.json',request);cmd=[java,'-jar',str(jar),'posthoc-tools','dunnett','--request',str(case/'request.json')];save(case/'command.json',cmd);start=time.monotonic()
  with (case/'stdout').open('xb') as so,(case/'stderr').open('xb') as se:p=subprocess.run(cmd,cwd=r,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=720)
  status=dict(case=name,exit_code=p.returncode,expected=expected,seconds=time.monotonic()-start);save(case/'PROCESS.json',status);print(status,flush=True);assert p.returncode==expected,status
  result=case/'result';assert (result/'COMPLETED.json').is_file()==(expected==0);a=json.loads((result/'analysis.json').read_text());assert a['result_admitted']==(expected==0)
  if expected==0:
   manifest=json.loads((result/'manifest.json').read_text());assert all(pin(result/name)==v for name,v in manifest.items());assert json.loads((result/'provider-before.json').read_text())==json.loads((result/'provider-after.json').read_text());assert (result/'worker/original-fit.rds').is_file()
  outcomes.append(status)
 save(out/'COMPLETED.json',dict(status='PASS_ORIGINAL_R_DUNNETT_ADAPTER_CONTROLS',cases=outcomes,jar=pin(jar),new_catalog_integrations=0,whole_goal_complete=False));print('PASS complete actual original-R controls',flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc()));print(repr(e),flush=True);raise
