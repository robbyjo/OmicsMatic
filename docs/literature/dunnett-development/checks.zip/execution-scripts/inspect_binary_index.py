import gzip
from pathlib import Path
b=Path(__file__).resolve().parent;p=b/'reference-runtime-1/windows-PACKAGES.gz';text=gzip.decompress(p.read_bytes()).decode()
for block in text.split('\n\n'):
 if block.startswith('Package: mvtnorm\n') or block.startswith('Package: sandwich\n'):print(block)
