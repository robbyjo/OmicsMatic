from pathlib import Path
import json,stat,os,concurrent.futures,sys,traceback
base=Path('/mnt/d/projects/JLinAlg/build/literature-review/monocle-runtime');out=base/'evidence-scvelo-pack-recovery-1';index=json.loads((base/'scvelo-evidence-pack-2/INDEX.json').read_bytes())
def source(name):
 if name.startswith('native-originals/'):
  relative=name[len('native-originals/'):];return Path('/tmp')/relative
 return base/name
entries=[(kind,name,row) for kind in ['files','links','directories','special_nodes'] for name,row in index[kind].items()]
def check(entry):
 kind,name,row=entry;p=source(name);s=p.lstat();mode=stat.S_IMODE(s.st_mode)
 expected={'files':stat.S_ISREG,'links':stat.S_ISLNK,'directories':stat.S_ISDIR}.get(kind)
 if (expected is not None and not expected(s.st_mode)) or mode!=row['mode']:raise ValueError('Original file type/mode changed: '+name)
 if kind=='links' and os.readlink(p)!=row['target']:raise ValueError('Original link target changed: '+name)
 if kind=='special_nodes' and (stat.S_IFMT(s.st_mode)!=row['file_type'] or s.st_rdev!=row['device']):raise ValueError('Original special node identity changed: '+name)
 return kind
with concurrent.futures.ThreadPoolExecutor(max_workers=12) as pool:result=list(pool.map(check,entries))
proof=dict(status='PASS_COMPLETE_ORIGINAL_FILE_TYPES_MODES_LINKS_AND_DIRECTORY_IDENTITIES',entries=len(entries),counts={k:result.count(k) for k in ['files','links','directories','special_nodes']},links_followed=False)
(out/'MODES.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof),flush=True)
