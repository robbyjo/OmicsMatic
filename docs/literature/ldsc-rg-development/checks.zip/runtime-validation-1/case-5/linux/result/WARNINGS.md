# Scope, warnings and required actions

Native Java unpartitioned observed-scale LDSC RG/Gencov using complete genome-ordered common rows, same-effect-allele signed Z, supplied per-trait N and reference M. Two trait-specific Hsq fits precede covariance weights. Two-step uses each trait's own strict chi-square cutoff and a joint covariance mask, then pairs the three delete fits by source block ordinal even if mapped row boundaries differ. Full-data raw rg is the reported point estimate; the bias-corrected ratio is separate. No allele harmonization, row joining, QC, ancestry/reference matching, missing-row removal, sample-overlap intercept or liability scale is inferred. Selected unchanged original reference: CBIIT/ldsc3.0.2 numerical core commit6c673952cee74bd5c57aef1555a03b1c015399a0; no Python runtime is required.

Require exit0, COMPLETED.json and analysis.json result_admitted=true. SKIP3 skips unavailable/forbidden input: supply permitted accessible prepared files and retry NEW output. FAIL2 admits no requested correlation: retain model.json, all component tables, inputs and partial output; read FAILURE.txt/WARNINGS.md. Correct the named complete-input, block, numeric, reference/QC or model issue and retry NEW output with a scientifically justified population. Do not drop failed variants/blocks, flip signs, clamp estimates, replace NaN/NA or force positive heritability. out_of_range_policy=retain-raw reproduces the source's explicit unbounded presentation choice only; it does not repair nonpositive heritability or nonfinite uncertainty. Original zero/Inf conventions and numeric resolution limits need their retained diagnostics.

This command requires an already harmonized common SNP population. A declared alignment/reference is not independently established by this prepared input. Original model-specific weighting floors/clamps are retained; final estimates are not clamped. Negative individual delete heritabilities are retained, and their product determines the original ratio denominator. Invalid correlation inference is retained as unreportable, never admitted.

## Observed warnings

Two-step mapped row boundaries differ among trait/covariance fits. Source RG pairs deletes by ordinal; no common-boundary replacement was made. Read block-boundaries.tsv.

Final heritability estimates outside[0,1] remain unchanged; only weighting estimates are bounded.

Source feedback bounds affect one or more weighting estimates only; final estimates were not clamped. Read weight-updates.tsv.

Source weights floor LD/weight-LD below1; original signed regressors and all rows remain unchanged.
