import hashlib,json,shutil,subprocess,traceback,xml.etree.ElementTree as ET
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];out=b/'native-probe-2';out.mkdir()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
try:
 names=['src/main/java/org/jlinalg/xwas/LdscHeritability.java','src/main/java/org/jlinalg/xwas/LdscGeneticCorrelation.java','src/test/java/org/jlinalg/xwas/LdscHeritabilityTest.java','src/test/java/org/jlinalg/xwas/LdscGeneticCorrelationTest.java'];copied=[]
 for name in names:
  target=out/'sources'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/name,target);copied.append(target)
 for folder in ['ldsc-hsq','ldsc-rg']:shutil.copytree(r/'src/test/resources/org/jlinalg/xwas'/folder,out/'resources/org/jlinalg/xwas'/folder)
 classes=out/'classes';classes.mkdir();jdk=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin');parent=r/'build/ldsc-high-impact-1/build-3/jar/omicsmatic-0.4.0.jar';junit=r/'build/nfcore-atacseq121-1/linux-test-runtime-1/junit-platform-console-standalone-1.13.4.jar'
 cp=str(parent)+';'+str(junit);cmd=[str(jdk/'javac.exe'),'--release','17','-encoding','UTF-8','-cp',cp,'-d',str(classes),*map(str,copied)];save(out/'compile-command.json',cmd)
 with (out/'compile-stdout').open('xb') as so,(out/'compile-stderr').open('xb') as se:p=subprocess.run(cmd,cwd=r,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=90)
 assert p.returncode==0
 cmd=[str(jdk/'java.exe'),'-jar',str(junit),'execute','--class-path',';'.join(map(str,[classes,parent,out/'resources'])),'--select-class','org.jlinalg.xwas.LdscHeritabilityTest','--select-class','org.jlinalg.xwas.LdscGeneticCorrelationTest','--reports-dir',str(out/'reports'),'--disable-ansi-colors'];save(out/'test-command.json',cmd)
 with (out/'test-stdout').open('xb') as so,(out/'test-stderr').open('xb') as se:p=subprocess.run(cmd,cwd=r,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=90)
 assert p.returncode==0
 save(out/'COMPLETED.json',dict(status='PASS_SIX_NATIVE_API_TESTS_AND_BOTH_ORIGINAL_REFERENCE_POPULATIONS',source_snapshots={p.relative_to(out).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in copied}));print('PASS six API tests',flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc()));print(repr(e),flush=True);raise
