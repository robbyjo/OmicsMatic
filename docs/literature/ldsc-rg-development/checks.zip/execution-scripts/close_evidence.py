import hashlib,json,shutil,subprocess,traceback,zipfile
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];previous=r/'build/ldsc-high-impact-1';out=b/'closure-1';out.mkdir();public=r/'docs/literature/ldsc-rg-development'
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def pin(p):
 h=hashlib.sha256();size=0
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):size+=len(block);h.update(block)
 return dict(bytes=size,sha256=h.hexdigest())
try:
 win=json.loads((b/'build-2/COMPLETED.json').read_text());runtime=json.loads((b/'runtime-validation-1/COMPLETED.json').read_text());reference=json.loads((b/'reference-1/result/reference.json').read_text())
 assert win['junit']==runtime['windows_junit']==runtime['linux_same_junit']==dict(tests=21,errors=0,failures=0,skipped=0)
 assert len(reference['cases'])==72 and not reference['errors'];assert len(runtime['processes'])==43 and runtime['numeric_fields_checked']==10964 and runtime['byte_identical_rg_payloads']==133 and runtime['byte_identical_prior_hsq_files']==96
 assert all(pin(previous/'upstream-1/cbiit'/name)==v for name,v in reference['source_guards'].items())
 installed=json.loads((previous/'reference-runtime-1/INSTALLED-FILES.json').read_text());provider=previous/'reference-runtime-1/python';assert {p.relative_to(provider).as_posix() for p in provider.rglob('*') if p.is_file()}==set(installed);assert all(pin(provider/name)==v for name,v in installed.items())
 build_guards=json.loads((b/'build-2/SOURCES.json').read_text());assert all(pin(r/name)==v for name,v in build_guards.items());jar=b/'build-2/jar/omicsmatic-0.4.0.jar';assert pin(jar)==win['artifact']==runtime['artifact']
 p=subprocess.run(['git','diff','--exit-code','HEAD','--','docs/literature/omics-2023-2026','tools/literature/reviewed-uses.json'],cwd=r,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert p.returncode==0
 names=list(build_guards)+['.gitattributes','docs/vignettes/ldsc-genetic-correlation.md','docs/vignettes/ldsc-heritability.md','docs/literature/IMPLEMENTATION_PRIORITY.md','docs/literature/ldsc-rg-development/README.md']+[p.relative_to(r).as_posix() for p in (r/'examples/ldsc-rg').iterdir() if p.is_file()]
 guards={n:pin(r/n) for n in sorted(set(names))};save(out/'SOURCE_GUARDS.json',guards);payloads={}
 def add(name,path):assert name not in payloads and path.is_file() and not path.is_symlink();payloads[name]=path
 for name in guards:add('current-source/'+name,r/name)
 for path in b.glob('*.py'):add('execution-scripts/'+path.name,path)
 for folder in ['reference-1','native-probe-1','native-probe-2','fixture-transport-fix-1','build-1','build-2','runtime-validation-1']:
  for path in sorted((b/folder).rglob('*')):
   if not path.is_file():continue
   relative=path.relative_to(b)
   if any(x in relative.parts for x in ['jar','classes','test-report','test-classes','__pycache__']) or path.suffix in ['.class','.pyc']:continue
   add(relative.as_posix(),path)
 for name in reference['source_guards']:add('original-core/'+name,previous/'upstream-1/cbiit'/name)
 for name in ['INTAKE.json','cbiit-commit.json']:add('original-core-intake/'+name,previous/'upstream-1'/name)
 for name in ['COMPLETED.json','INSTALLED-FILES.json','PYTHON-INTAKE.json','probe-stdout','download-command.json','python310._pth.original']:add('reference-provider/'+name,previous/'reference-runtime-1'/name)
 # Bind the unchanged prior Hsq evidence and the actual comparison inputs/outputs.
 add('prior-hsq/VALIDATION.json',r/'docs/literature/ldsc-hsq-development/VALIDATION.json');add('prior-hsq/SOURCE_CENSUS.json',r/'docs/literature/ldsc-hsq-development/SOURCE_CENSUS.json')
 prior=r/'build/ldsc-high-impact-1/runtime-validation-1'
 for index in range(6):
  for platform in ['windows','linux']:
   for name in ['estimates.tsv','delete-values.tsv','covariance.tsv','row-audit.tsv','block-boundaries.tsv','weight-updates.tsv','analysis.json','WARNINGS.md']:
    add('prior-hsq/case-'+str(index)+'/'+platform+'/'+name,prior/('case-'+str(index))/platform/name)
 for name in ['one-step','two-step','nonpositive-heritability','nonfinite-delete-uncertainty']:
  folder=r/'build'/('ldsc-rg-example-'+name)
  for path in folder.rglob('*'):
   if path.is_file():add('copyable-example-results/'+name+'/'+path.relative_to(folder).as_posix(),path)
 save(out/'PROVIDER_RECHECK.json',dict(status='PASS_COMPLETE_UNCHANGED_SELECTED_REFERENCE_PROVIDER',files=len(installed),bytes=sum(v['bytes'] for v in installed.values()),package_initializer_executed=False,original_functions_replaced=False,provider_bytes_bundled=False));add('closure/PROVIDER_RECHECK.json',out/'PROVIDER_RECHECK.json');add('closure/SOURCE_GUARDS.json',out/'SOURCE_GUARDS.json')
 index={name:pin(path) for name,path in sorted(payloads.items())};save(out/'PAYLOADS.json',index);sums=''.join(v['sha256']+'  '+name+'\n' for name,v in index.items());(out/'SHA256SUMS').write_text(sums,encoding='utf8',newline='\n')
 archive=public/'checks.zip';assert not archive.exists()
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for name,path in sorted(payloads.items()):z.write(path,name)
  z.write(out/'SHA256SUMS','SHA256SUMS')
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None and len(z.namelist())==len(index)+1 and z.read('SHA256SUMS').decode()==sums
  for name,value in index.items():
   raw=z.read(name);assert dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())==value
 assert all(pin(r/name)==v for name,v in guards.items())
 warnings='''# Warnings and required actions

Require exit0, COMPLETED.json and analysis.json result_admitted=true. SKIP3 skips
unavailable/forbidden input: supply permitted accessible prepared files. FAIL2
admits no requested correlation. Preserve model.json, component tables, original
inputs and FAILURE.txt/WARNINGS.md; correct the named population, block,
numerical or model issue and retry NEW output. A retained covariance fit is not
an admitted correlation. Never drop SNPs/blocks, flip signs, force h2 positive,
clamp final estimates or replace NA/NaN to obtain a successful status.

Nonpositive full h2 retains original correlation NA. Negative delete h2 products
retain finite raw rg with NaN uncertainty and no correlation admission. Two
negative individual delete h2 values have a positive product under the source
rule and remain warned about. Source-summary suppresses finite abs(rg)>1.2;
explicit retain-raw changes presentation only and cannot repair invalid
uncertainty or model adequacy. Numeric-zero probabilities and the source +Inf-Z
zero-SE convention retain resolution diagnostics and do not establish certainty.

The command needs complete already-harmonized signed Z, matching reference/QC
population, per-trait N, M and genomic ordering. The declarations do not prove
allele or ancestry/reference matching. Two-step masks and mapped boundaries can
differ; original RG pairs delete estimates by block ordinal. Read every boundary,
weight, delete and observed-warning record before interpretation.

Native Java analysis needs no Python installation. The selected original-core
reference runs unchanged CBIIT3.0.2 numerical modules only; the unrelated web
initializer/full CLI and historical editions are not runtime-qualified. Original
providers are fingerprinted, not bundled as an end-user deployment. Integrity
hashes do not authenticate execution or prove biology.

Prior Hsq evidence retains its own unchanged source hashes and artifact. Current
compatibility is established by complete original references and 96 identical
output-file comparisons, not by refreshing historical fingerprints. P092/P151
canonical source corrections and broader LDSC roles remain pending. No new
catalog family badge, full-paper reproduction or full-goal completion is claimed.
'''
 (public/'WARNINGS.md').write_text(warnings,encoding='utf8',newline='\n');fields=sum(1 for _ in (r/'src/test/resources/org/jlinalg/xwas/ldsc-rg/expected.tsv').open())-1;assert fields==54202
 status_counts={'finite_raw_inference':sum(isinstance(c['expected']['rg']['rg_se'],(float,int)) for c in reference['cases']),'nonpositive_hsq_NA':sum(c['expected']['rg']['rg_ratio']=='NA' for c in reference['cases']),'nonfinite_uncertainty_NaN':sum(c['expected']['rg']['rg_se']=='NaN' for c in reference['cases'])};assert status_counts==dict(finite_raw_inference=56,nonpositive_hsq_NA=8,nonfinite_uncertainty_NaN=8)
 validation=dict(status='PASS_SCOPED_NATIVE_LDSC_RG_GENCOV_COMPONENT',profile='native-ldsc-rg-cbiit302-v1',original_core_repository='CBIIT/ldsc',original_core_commit='6c673952cee74bd5c57aef1555a03b1c015399a0',original_core_models=72,original_core_reference_fields=fields,source_status_counts=status_counts,earlier_distinct_hsq_models_rechecked=72,windows_junit=win['junit'],linux_same_junit=runtime['linux_same_junit'],packaged_validation=runtime,source_guards=guards,artifact=pin(jar),controls_archive=pin(archive),indexed_payloads=len(index),all_archive_payloads_read_back=True,warnings=pin(public/'WARNINGS.md'),provider_recheck=json.loads((out/'PROVIDER_RECHECK.json').read_text()),prior_hsq_evidence_unchanged=True,canonical_source_correction_pending=True,new_catalog_integrations=0,admitted_catalog_integrations_unchanged=127,whole_tool_qualified=False,whole_paper_reproduced=False,whole_goal_complete=False)
 save(public/'VALIDATION.json',validation);save(out/'COMPLETED.json',dict(status='PASS_NATIVE_LDSC_RG_EVIDENCE_CLOSED',validation=pin(public/'VALIDATION.json'),archive=pin(archive),indexed_payloads=len(index)));print('PASS closed',len(index),'payloads',pin(archive),flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc()));print(repr(e),flush=True);raise
