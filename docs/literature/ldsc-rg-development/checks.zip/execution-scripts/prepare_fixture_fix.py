import hashlib,json,zipfile
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];out=b/'fixture-transport-fix-1';out.mkdir();d=r/'src/test/resources/org/jlinalg/xwas/ldsc-rg'
with zipfile.ZipFile(out/'previous-derived-fixtures.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
 for p in d.iterdir():
  if p.is_file():z.write(p,p.name)
s=(b/'install_fixtures.py').read_text().replace('d.mkdir(parents=True)','d.mkdir(parents=True,exist_ok=True)')
s=s.replace("def add(field,component,first,second,value):expected.append", "def scalar(value):\n  while isinstance(value,list) and len(value)==1:value=value[0]\n  return value\n def add(field,component,first,second,value):value=scalar(value);expected.append")
s=s.replace("if p.is_file()}","if p.is_file() and p.name!='PROVENANCE.json'}")
(b/'install_fixtures2.py').write_text(s,encoding='utf8')
s=(b/'probe_native.py').read_text().replace("out=b/'native-probe-1'","out=b/'native-probe-2'");(b/'probe_native2.py').write_text(s,encoding='utf8')
(out/'RECEIPT.json').write_text(json.dumps(dict(cause='Original Gencov p/z and weight-intercept returns include length-one arrays. Failed TSV exporter used their list representation in scalar cells.',action='Flatten only length-one scalar transport containers; retain every numeric value, original JSON and old fixture bytes; do not change original functions or native arithmetic.'),indent=2)+'\n')
