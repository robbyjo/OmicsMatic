import json,subprocess,time
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];previous=r/'build/ldsc-high-impact-1';out=b/'reference-1';out.mkdir()
cmd=[str(previous/'reference-runtime-1/python/python.exe'),'-B',str(b/'generate_reference.py'),'--source',str(previous/'upstream-1/cbiit'),'--out',str(out/'result')]
(out/'command.json').write_text(json.dumps(cmd,indent=2)+'\n');start=time.monotonic()
with (out/'stdout').open('xb') as so,(out/'stderr').open('xb') as se:p=subprocess.run(cmd,cwd=b,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=180)
(out/'PROCESS.json').write_text(json.dumps(dict(exit_code=p.returncode,seconds=time.monotonic()-start))+'\n');assert p.returncode==0
print('PASS original selected RG/Gencov/Hsq reference',flush=True)
