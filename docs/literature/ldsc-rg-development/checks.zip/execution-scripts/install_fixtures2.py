import hashlib,json,shutil
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];data=json.loads((b/'reference-1/result/reference.json').read_text());assert len(data['cases'])==72 and not data['errors'];d=r/'src/test/resources/org/jlinalg/xwas/ldsc-rg';d.mkdir(parents=True,exist_ok=True)
models=['id\tM\tblocks\tintercept_hsq1\tintercept_hsq2\tintercept_gencov\ttwo_step\n'];inputs=['id\trow\tz1\tz2\tld\twld\tn1\tn2\n'];expected=['id\tfield\tcomponent\tfirst\tsecond\tvalue\n']
for c in data['cases']:
 name=c['id'];models.append(name+'\t'+'\t'.join(str(c[k]) for k in ['reference_variants','blocks','intercept_hsq1','intercept_hsq2','intercept_gencov','two_step'])+'\n')
 for index,row in enumerate(zip(c['z1'],c['z2'],c['ld'],c['weight_ld'],c['n1'],c['n2'])):inputs.append(name+'\t'+str(index)+'\t'+'\t'.join(map(str,row))+'\n')
 def scalar(value):
  while isinstance(value,list) and len(value)==1:value=value[0]
  return value
 def add(field,component,first,second,value):value=scalar(value);expected.append(f'{name}\t{field}\t{component}\t{first}\t{second}\t{value}\n')
 stage_count=2 if c['two_step'] is not None else 1
 for component,key in enumerate(['hsq1','hsq2','gencov']):
  e=c['expected'][key]
  for field,original in [('total','tot'),('se','tot_se'),('intercept','intercept'),('intercept_se','intercept_se'),('mean_chi','mean_chisq'),('lambda_gc','lambda_gc'),('mean_product','mean_z1z2'),('p','p'),('z','z')]:
   if component==2 or field not in ['mean_product','p','z']:add(field,component,0,0,e[original])
  add('coefficient',component,0,0,e['coef'][0]);add('coefficient_se',component,0,0,e['coef_se'][0])
  for i,value in enumerate(e['tot_delete_values']):
   add('delete',component,i,0,value[0]);add('delete',component,i,1,e['intercept_delete_values'][i] if e['intercept_delete_values'] is not None else c[['intercept_hsq1','intercept_hsq2','intercept_gencov'][component]])
  stage=c['stages'][(component+1)*stage_count-1]
  for i,value in enumerate(stage['weights']):add('weight',component,i,0,value)
  for i,value in enumerate(stage['separators']):add('boundary',component,i,0,value)
  if c['two_step'] is not None:
   for i,value in enumerate(c['stages'][component*stage_count]['separators']):add('step1_boundary',component,i,0,value)
 for field,value in c['expected']['rg'].items():add('rg_'+field,3,0,0,value)
 for i,call in enumerate([x for x in c['weight_calls'] if x['kind']=='Gencov']):add('gcov_weight_estimate',2,i,0,call['estimate']);add('gcov_weight_intercept',2,i,0,0 if call['intercept'] is None else call['intercept'])
for name,lines in [('models.tsv',models),('inputs.tsv',inputs),('expected.tsv',expected)]:(d/name).write_text(''.join(lines),encoding='utf8',newline='\n')
shutil.copyfile(b/'generate_reference.py',d/'generate_reference.py');pins={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in d.iterdir() if p.is_file() and p.name!='PROVENANCE.json'}
(d/'PROVENANCE.json').write_text(json.dumps(dict(status=data['status'],models=72,upstream_repository='CBIIT/ldsc',commit='6c673952cee74bd5c57aef1555a03b1c015399a0',python=data['python'],numpy=data['numpy'],scipy=data['scipy'],pandas=data['pandas'],source_guards=data['source_guards'],files=pins,package_initializer_executed=False,original_function_replaced=False),indent=2)+'\n',encoding='utf8')
print('installed72 original RG models;',len(expected)-1,'fields',flush=True)
