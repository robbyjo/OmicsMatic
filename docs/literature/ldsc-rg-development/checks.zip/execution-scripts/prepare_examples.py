import collections,json,math
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];data=json.loads((b/'reference-1/result/reference.json').read_text());d=r/'examples/ldsc-rg';d.mkdir(parents=True,exist_ok=True)
def finite(c):return isinstance(c['expected']['rg']['rg_se'],(int,float)) and isinstance(c['expected']['rg']['rg_ratio'],(int,float))
selected=[('one-step',next(c for c in data['cases'] if c['mode']==0 and finite(c) and abs(c['expected']['rg']['rg_ratio'])<=1.2)),('two-step',next(c for c in data['cases'] if c['mode']==4 and finite(c) and abs(c['expected']['rg']['rg_ratio'])<=1.2)),('nonpositive-heritability',data['cases'][6]),('nonfinite-delete-uncertainty',data['cases'][7])]
for name,c in selected:
 input=d/(name+'.tsv');request=d/(name+'.json');assert not input.exists() and not request.exists()
 input.write_text('variant\tz1\tz2\tld_score\tweight_ld_score\tn1\tn2\n'+''.join('synthetic_'+str(i)+'\t'+'\t'.join(map(str,row))+'\n' for i,row in enumerate(zip(c['z1'],c['z2'],c['ld'],c['weight_ld'],c['n1'],c['n2']))),encoding='utf8',newline='\n')
 m=dict(schema_version=1,input=name+'.tsv',out='../../build/ldsc-rg-example-'+name,reference_variants=c['reference_variants'],n_blocks=c['blocks'],trait1='Synthetic trait A',trait2='Synthetic trait B',heritability_intercepts=['free' if c[k] is None else c[k] for k in ['intercept_hsq1','intercept_hsq2']],covariance_intercept='free' if c['intercept_gencov'] is None else c['intercept_gencov'],two_step=c['two_step'],out_of_range_policy='source-summary',data_provenance='Synthetic original-core reference '+c['id']+'; no biological data',row_order_declaration='Fixed original synthetic common row order; no real genomic/reference-matching claim',allele_alignment_declaration='Both signed synthetic Z columns use the same declared synthetic effect allele')
 request.write_text(json.dumps(m,indent=2)+'\n',encoding='utf8',newline='\n')
print('examples',[(name,c['id'],c['expected']['rg']['rg_ratio'],c['expected']['rg']['rg_se']) for name,c in selected])
print('source range candidate',next((c['id'],c['expected']['rg']['rg_ratio']) for c in data['cases'] if finite(c) and abs(c['expected']['rg']['rg_ratio'])>1.2))
print('status counts',collections.Counter('NA' if c['expected']['rg']['rg_ratio']=='NA' else 'NaN uncertainty' if c['expected']['rg']['rg_se']=='NaN' else 'finite' for c in data['cases']))
