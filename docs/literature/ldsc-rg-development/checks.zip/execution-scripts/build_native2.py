import hashlib,json,os,shutil,subprocess,time,traceback,xml.etree.ElementTree as ET
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];out=b/'build-2';out.mkdir()
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
try:
 names=['src/main/java/org/jlinalg/xwas/LdscHeritability.java','src/main/java/org/jlinalg/xwas/LdscGeneticCorrelation.java','src/main/java/org/jlinalg/cli/LdscToolsCli.java','src/main/java/org/jlinalg/cli/LdscRgCli.java','src/test/java/org/jlinalg/xwas/LdscHeritabilityTest.java','src/test/java/org/jlinalg/xwas/LdscGeneticCorrelationTest.java','src/test/java/org/jlinalg/cli/LdscToolsCliTest.java','src/test/java/org/jlinalg/cli/LdscRgCliTest.java']+[p.relative_to(r).as_posix() for folder in ['ldsc-hsq','ldsc-rg'] for p in (r/'src/test/resources/org/jlinalg/xwas'/folder).iterdir() if p.is_file()]
 guards={n:pin(r/n) for n in names};save(out/'SOURCES.json',guards)
 for name in guards:
  target=out/'sources'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/name,target)
 rel=out.relative_to(r).as_posix();init=out/'private.gradle';init.write_text("gradle.projectsEvaluated {\n rootProject.tasks.named('executableJar') { destinationDirectory.set(rootProject.layout.projectDirectory.dir('"+rel+"/jar')) }\n rootProject.tasks.named('test') { reports.junitXml.outputLocation.set(rootProject.layout.projectDirectory.dir('"+rel+"/test-results')); reports.html.outputLocation.set(rootProject.layout.projectDirectory.dir('"+rel+"/test-report')) }\n}\n",newline='\n')
 cmd=[str(r/'gradlew.bat'),'--no-daemon','--console=plain','-I',str(init),':test']
 for name in ['org.jlinalg.xwas.LdscHeritabilityTest','org.jlinalg.xwas.LdscGeneticCorrelationTest','org.jlinalg.cli.LdscToolsCliTest','org.jlinalg.cli.LdscRgCliTest']:cmd.extend(['--tests',name])
 cmd.append(':executableJar');save(out/'command.json',cmd);env=dict(os.environ,JAVA_HOME='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot');start=time.monotonic()
 with (out/'stdout').open('xb') as so,(out/'stderr').open('xb') as se:p=subprocess.run(cmd,cwd=r,env=env,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=900)
 save(out/'PROCESS.json',dict(exit_code=p.returncode,seconds=time.monotonic()-start));assert p.returncode==0
 trees=[ET.parse(p).getroot() for p in (out/'test-results').glob('TEST-*.xml')];counts={k:sum(int(t.attrib.get(k,0)) for t in trees) for k in ['tests','errors','failures','skipped']};assert counts==dict(tests=21,errors=0,failures=0,skipped=0),counts
 assert all(pin(r/n)==v for n,v in guards.items());save(out/'COMPLETED.json',dict(status='PASS_FOCUSED_NATIVE_LDSC_RG_AND_HSQ_BUILD',junit=counts,artifact=pin(out/'jar/omicsmatic-0.4.0.jar'),new_catalog_integrations=0));print('PASS',counts,flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc()));print(repr(e),flush=True);raise
