import csv,hashlib,json,math,shutil,subprocess,time,traceback,xml.etree.ElementTree as ET,zipfile
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];out=b/'runtime-validation-1';out.mkdir();records=[];checked=0;maximum_scaled_error=0
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def linux(p):return '/mnt/d/'+p.resolve().as_posix().split(':/',1)[1]
def run(label,cmd,expected):
 save(out/(label+'.command.json'),cmd);start=time.monotonic()
 with (out/(label+'.stdout')).open('xb') as so,(out/(label+'.stderr')).open('xb') as se:p=subprocess.run(cmd,cwd=r,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=180)
 receipt=dict(label=label,exit_code=p.returncode,expected=expected,seconds=time.monotonic()-start);save(out/(label+'.PROCESS.json'),receipt);records.append(receipt);assert p.returncode==expected,receipt
def scalar(x):
 while isinstance(x,list) and len(x)==1:x=x[0]
 return x
def close(actual,expected):
 global checked,maximum_scaled_error
 expected=scalar(expected)
 if expected is None or expected=='NA':assert actual is None or actual=='NA';return
 if expected in ['NaN','Inf','-Inf']:assert actual==expected;return
 a=float(actual);e=float(expected);scale=max(abs(a),abs(e));error=abs(a-e);assert error<=3e-9*scale+3e-13,(a,e)
 if scale:maximum_scaled_error=max(maximum_scaled_error,error/scale)
 checked+=1
def table(p):
 with p.open(encoding='utf8',newline='') as f:return list(csv.DictReader(f,delimiter='\t'))
try:
 win=json.loads((b/'build-2/COMPLETED.json').read_text());assert win['junit']==dict(tests=21,errors=0,failures=0,skipped=0);jar=b/'build-2/jar/omicsmatic-0.4.0.jar';assert pin(jar)==win['artifact'];java='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe'
 classes=['org.jlinalg.xwas.LdscHeritabilityTest','org.jlinalg.xwas.LdscGeneticCorrelationTest','org.jlinalg.cli.LdscToolsCliTest','org.jlinalg.cli.LdscRgCliTest']
 for name in classes:
  folder,simple=name.rsplit('.',1)
  for p in (r/'build/classes/java/test'/folder.replace('.','/')).glob(simple+'*.class'):
   target=out/'test-classes'/folder.replace('.','/')/p.name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
 for folder in ['ldsc-hsq','ldsc-rg']:shutil.copytree(r/'src/test/resources/org/jlinalg/xwas'/folder,out/'test-resources/org/jlinalg/xwas'/folder)
 console=r/'build/nfcore-atacseq121-1/linux-test-runtime-1/junit-platform-console-standalone-1.13.4.jar';save(out/'TEST-RUNTIME.json',dict(console=pin(console),classes={p.relative_to(out).as_posix():pin(p) for p in (out/'test-classes').rglob('*.class')}))
 cmd=['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--exec','/usr/bin/java','-Xmx2048m','-jar',linux(console),'execute','--class-path',':'.join(linux(p) for p in [jar,out/'test-classes',out/'test-resources'])]
 for name in classes:cmd.extend(['--select-class',name])
 cmd.extend(['--reports-dir',linux(out/'linux-junit-reports'),'--disable-ansi-colors']);run('linux-tests',cmd,0)
 trees=[ET.parse(p).getroot() for p in (out/'linux-junit-reports').glob('TEST-*.xml')];counts={k:sum(int(t.attrib.get(k,0)) for t in trees) for k in ['tests','errors','failures','skipped']};assert counts==win['junit']
 def cli(platform,request,mode='rg'):return [java,'-jar',str(jar),'ldsc-tools',mode,'--request',str(request)] if platform=='windows' else ['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--exec','/usr/bin/java','-jar',linux(jar),'ldsc-tools',mode,'--request',linux(request)]
 reference=json.loads((b/'reference-1/result/reference.json').read_text());identical_rg_files=0;states=[]
 def request(c):return dict(schema_version=1,input='input.tsv',out='result',reference_variants=c['reference_variants'],n_blocks=c['blocks'],trait1='Trait A',trait2='Trait B',heritability_intercepts=['free' if c[k] is None else c[k] for k in ['intercept_hsq1','intercept_hsq2']],covariance_intercept='free' if c['intercept_gencov'] is None else c['intercept_gencov'],two_step=c['two_step'],out_of_range_policy='retain-raw',data_provenance='Original selected-core synthetic RG model '+c['id'],row_order_declaration='Fixed synthetic common row order',allele_alignment_declaration='Both signed Z columns use the same declared synthetic effect allele')
 def data(c):return 'variant\tz1\tz2\tld_score\tweight_ld_score\tn1\tn2\n'+''.join('rs'+str(i)+'\t'+'\t'.join(map(str,row))+'\n' for i,row in enumerate(zip(c['z1'],c['z2'],c['ld'],c['weight_ld'],c['n1'],c['n2'])))
 for index in range(9):
  c=reference['cases'][index];expected=2 if index in [6,7] else 0;states.append(dict(id=c['id'],expected_exit=expected));case=out/('case-'+str(index));case.mkdir()
  for platform in ['windows','linux']:
   p=case/platform;p.mkdir();(p/'input.tsv').write_text(data(c),encoding='utf8',newline='\n');save(p/'request.json',request(c));run(platform+'-rg-'+str(index),cli(platform,p/'request.json'),expected);result=p/'result';assert (result/'COMPLETED.json').is_file()==(expected==0);assert json.loads((result/'analysis.json').read_text())['result_admitted']==(expected==0)
   if expected==0:assert all(pin(result/name)==value for name,value in json.loads((result/'manifest.json').read_text()).items())
   for component,row in enumerate(table(result/'heritability.tsv')):
    e=c['expected']['hsq'+str(component+1)]
    for actual,original in [('h2','tot'),('se','tot_se'),('coefficient','coef'),('coefficient_se','coef_se'),('intercept','intercept'),('intercept_se','intercept_se'),('mean_chi_square','mean_chisq'),('lambda_gc','lambda_gc')]:close(row[actual],e[original])
   row=table(result/'genetic-covariance.tsv')[0];e=c['expected']['gencov']
   for actual,original in [('covariance','tot'),('se','tot_se'),('coefficient','coef'),('coefficient_se','coef_se'),('intercept','intercept'),('intercept_se','intercept_se'),('mean_z1z2','mean_z1z2'),('z','z'),('p','p')]:close(row[actual],e[original])
   row=table(result/'correlation.tsv')[0];e=c['expected']['rg']
   for actual,original in [('raw_rg','rg_ratio'),('se','rg_se'),('bias_corrected_rg','rg_jknife'),('z','z'),('p','p')]:close(row[actual],e[original])
   stage_count=2 if c['two_step'] is not None else 1
   for i,row in enumerate(table(result/'row-audit.tsv')):
    for component,name in enumerate(['h1_weight','h2_weight','gcov_weight']):close(row[name],c['stages'][(component+1)*stage_count-1]['weights'][i])
   for i,row in enumerate(table(result/'delete-values.tsv')):
    for name,key in [('h1','hsq1'),('h2','hsq2'),('genetic_covariance','gencov')]:close(row[name],c['expected'][key]['tot_delete_values'][i])
  left=case/'windows/result';right=case/'linux/result';names={p.relative_to(left).as_posix() for p in left.rglob('*') if p.is_file()};assert names=={p.relative_to(right).as_posix() for p in right.rglob('*') if p.is_file()}
  assert all((left/name).read_bytes()==(right/name).read_bytes() for name in names);identical_rg_files+=len(names)
 # The source presentation bound changes admission, never the fitted numeric tables.
 for platform in ['windows','linux']:
  p=out/(platform+'-source-summary');p.mkdir();c=reference['cases'][1];(p/'input.tsv').write_text(data(c),encoding='utf8',newline='\n');m=request(c);m['out_of_range_policy']='source-summary';save(p/'request.json',m);run(platform+'-source-summary',cli(platform,p/'request.json'),2)
  for name in ['heritability.tsv','genetic-covariance.tsv','delete-values.tsv','parameter-covariances.tsv','block-boundaries.tsv','row-audit.tsv','weight-updates.tsv']:assert (p/'result'/name).read_bytes()==(out/'case-1'/platform/'result'/name).read_bytes()
  for kind,code in [('missing-input',3),('duplicate-id',2),('missing-alignment',2)]:
   p=out/(platform+'-'+kind);p.mkdir();c=reference['cases'][0];m=request(c)
   if kind!='missing-input':(p/'input.tsv').write_text(data(c)+(data(c).splitlines()[1]+'\n' if kind=='duplicate-id' else ''),encoding='utf8',newline='\n')
   if kind=='missing-alignment':m['allele_alignment_declaration']=''
   save(p/'request.json',m);run(platform+'-'+kind,cli(platform,p/'request.json'),code);assert not (p/'result/COMPLETED.json').exists()
 # Shared helper extraction must preserve all previously qualified Hsq scientific outputs.
 hsq_identical=0
 for index in range(6):
  old=r/'build/ldsc-high-impact-1/runtime-validation-1'/('case-'+str(index))
  for platform in ['windows','linux']:
   p=out/('hsq-'+str(index)+'-'+platform);p.mkdir();shutil.copyfile(old/'input.tsv',p/'input.tsv');m=json.loads((old/(platform+'.json')).read_text());m['out']='result';save(p/'request.json',m);run(platform+'-hsq-compat-'+str(index),cli(platform,p/'request.json','h2'),0)
   for name in ['estimates.tsv','delete-values.tsv','covariance.tsv','row-audit.tsv','block-boundaries.tsv','weight-updates.tsv','analysis.json','WARNINGS.md']:assert (p/'result'/name).read_bytes()==(old/platform/name).read_bytes();hsq_identical+=1
 for name,code in [('one-step',0),('two-step',0),('nonpositive-heritability',2),('nonfinite-delete-uncertainty',2)]:
  p=r/'examples/ldsc-rg'/(name+'.json');m=json.loads(p.read_text());result=(p.parent/m['out']).resolve();assert not result.exists();run('example-'+name,cli('windows',p),code);assert (result/'COMPLETED.json').exists()==(code==0)
 oldjar=r/'build/ldsc-high-impact-1/build-3/jar/omicsmatic-0.4.0.jar'
 with zipfile.ZipFile(oldjar) as a,zipfile.ZipFile(jar) as c:
  aa=set(a.namelist());cc=set(c.namelist());removed=sorted(aa-cc);changed=[name for name in sorted(aa&cc) if a.read(name)!=c.read(name)];added=sorted(cc-aa)
 assert not removed and all(name in ['org/jlinalg/cli/LdscToolsCli.class','org/jlinalg/xwas/LdscHeritability.class','org/jlinalg/xwas/LdscHeritability$Fit.class','org/jlinalg/xwas/LdscHeritability$Moments.class','org/jlinalg/xwas/LdscHeritability$Sum.class'] for name in changed),changed
 assert all(name.startswith(('org/jlinalg/cli/LdscRgCli','org/jlinalg/xwas/LdscGeneticCorrelation')) for name in added),added
 save(out/'JAR-MEMBER-COMPATIBILITY.json',dict(status='PASS_ONLY_EXPLICIT_LDSC_SHARED_HELPERS_AND_ROUTER_CHANGED',changed=changed,added=added,removed=removed))
 save(out/'COMPLETED.json',dict(status='PASS_NATIVE_LDSC_RG_PACKAGED_AND_SHARED_HSQ_VALIDATION',windows_junit=win['junit'],linux_same_junit=counts,original_rg_models=states,numeric_fields_checked=checked,maximum_relative_error_without_absolute_floor=maximum_scaled_error,byte_identical_rg_payloads=identical_rg_files,byte_identical_prior_hsq_files=hsq_identical,source_presentation_policy_does_not_change_fit=True,processes=records,artifact=pin(jar),new_catalog_integrations=0,whole_goal_complete=False));print('PASS',len(records),'processes;',checked,'original fields;',identical_rg_files,'RG payloads;',hsq_identical,'old Hsq files identical',flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc(),processes=records));print(repr(e),flush=True);raise
