from pathlib import Path
b=Path(__file__).resolve().parent;s=(b/'build_native.py').read_text().replace("out=b/'build-1'","out=b/'build-2'");(b/'build_native2.py').write_text(s,encoding='utf8')
