import ast,hashlib,json
from pathlib import Path
r=Path(__file__).resolve().parents[2];p=r/'build/ldsc-high-impact-1/upstream-1/cbiit/ldscore/regressions.py';s=p.read_text();lines=s.splitlines();print('source_sha256',hashlib.sha256(p.read_bytes()).hexdigest())
for node in ast.parse(s).body:
 if isinstance(node,ast.ClassDef) and node.name in ['Gencov','RG']:print('\n'.join(lines[node.lineno-1:node.end_lineno]))
