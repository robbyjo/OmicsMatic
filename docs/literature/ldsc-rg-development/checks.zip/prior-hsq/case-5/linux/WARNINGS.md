# Scope, warnings and required actions

Native Java unpartitioned observed-scale LDSC Hsq: explicit free/fixed intercept or two-step intercept estimation, two IRWLS updates and block jackknife with frozen final stage weights. All declared rows contribute to the final slope. The cutoff selects only the two-step intercept population. Weight-feedback h2 is clamped to [0,1]; final estimates are retained unchanged, including negative/out-of-range estimates. Prepared rows must already be QC-filtered, aligned to their LD reference and genome-ordered. No allele harmonization, sample-size inference, LD-score computation, munging, ancestry matching, outlier removal, liability conversion, genetic correlation or partitioned model is inferred. Selected reference: unchanged CBIIT/ldsc3.0.2 numerical core commit6c673952cee74bd5c57aef1555a03b1c015399a0; historical edition and whole-paper parity remain separate. No Python runtime needed.

Require exit0, COMPLETED.json and analysis.json result_admitted=true. SKIP3 means dependent analysis skipped for unavailable/forbidden input or an unsupported requested analysis. Supply permitted accessible prepared inputs or a separately qualified method and retry NEW output. FAIL2 means no result admitted: retain inputs and partial output, read FAILURE.txt/WARNINGS.md, correct the named complete-input, design, block-population or numeric-capacity issue and retry NEW output. Never remove failed blocks, replace nonfinite values, truncate rows or clamp final estimates to force success. For deployment or paper attribution, establish the exact author inputs, QC/reference population, settings and software edition separately.

Block jackknife uses consecutive rows: input order and the declared reference/QC population determine inference. A valid numerical fit does not establish ancestry matching, biological adequacy or independent loci. Standard errors use the selected original fixed-stage-weight jackknife; IRWLS is not rerun for each delete. Undefined original diagnostics remain NA.

## Observed warnings

Original weight feedback clamped one or more h2 estimates to[0,1]; final estimates were not clamped. Read weight-updates.tsv.

Original weighting floors LD/weight-LD below1. Complete original signed regressor values remain unchanged. Raw rows below1: LD=1,weight-LD=5; first-stage two-step updates use the source N-scaled LD column.
