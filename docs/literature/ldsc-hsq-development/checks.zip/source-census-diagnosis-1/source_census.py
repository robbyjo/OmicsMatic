#!/usr/bin/env python3
# Copyright (C) 2026 JLinAlg contributors; SPDX-License-Identifier: GPL-3.0-or-later
"""Verify the frozen 250 primary identities and enumerate exact LDSC source pointers.

This is a source census, not individual role admission or paper reproduction.
"""
import argparse,gzip,hashlib,json,re,sys,unicodedata,xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'tools/literature'))
from collect_omics_review import paragraphs
from catalog_fixed_cohort import verify_fixed_cohort

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--xml-cache',required=True,type=Path);p.add_argument('--out',required=True,type=Path);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False)
 catalog=ROOT/'docs/literature/omics-2023-2026';papers=json.loads((catalog/'papers.json').read_bytes());verify_fixed_cohort(ROOT,catalog,papers)
 row=next(x for x in json.loads((catalog/'tool-inventory.json').read_bytes()) if x['id']=='ldsc');pattern=re.compile(row['pattern'],re.I)
 sources=[];uses=[]
 for paper in papers:
  raw=gzip.decompress((a.xml_cache/(paper['pmcid']+'.xml.gz')).read_bytes());assert hashlib.sha256(raw).hexdigest()==paper['xml_sha256'];sources.append(dict(paper_id=paper['paper_id'],pmcid=paper['pmcid'],xml_sha256=paper['xml_sha256']))
  pointers=[]
  for paragraph in paragraphs(ET.fromstring(raw)):
   if pattern.search(unicodedata.normalize('NFKC',paragraph['text'])):pointers.append(dict(paragraph_index=paragraph['paragraph_index'],paragraph_sha256=hashlib.sha256(paragraph['text'].encode()).hexdigest(),section=paragraph['section']))
  if pointers:uses.append(dict(paper_id=paper['paper_id'],pmcid=paper['pmcid'],doi=paper['doi'],xml_sha256=paper['xml_sha256'],source_pointers=pointers,individual_role_review_complete=False,univariate_hsq_paper_reproduced=False))
 assert len(uses)==41 and {x['paper_id'] for x in uses}==set(row['papers'])
 report=dict(status='PASS250_PRIMARY_IDENTITIES_AND41_LDSC_PAPER_POINTERS',primary_sources=sources,ldsc_papers=uses,scope='Native prepared unpartitioned Hsq numerical component. Census does not establish that every mention uses Hsq or resolve genetic correlation, stratification, LD-score generation, historical editions or whole author pipelines.',new_catalog_integrations=0,whole_goal_complete=False)
 (a.out/'SOURCE_CENSUS.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8');print('PASS250 primary hashes;41 LDSC paper identities with exact paragraph pointers;no role/badge inflation')

if __name__=='__main__':main()
