import numpy,scipy,pandas,sys
print(sys.version)
print(numpy.__version__,scipy.__version__,pandas.__version__)
