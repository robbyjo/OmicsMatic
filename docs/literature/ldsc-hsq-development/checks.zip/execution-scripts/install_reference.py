import hashlib,io,json,os,subprocess,sys,time,traceback,urllib.request,zipfile
from pathlib import Path
b=Path(__file__).resolve().parent;out=b/'reference-runtime-1';out.mkdir()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def extract(archive,destination):
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None
  for entry in z.infolist():
   if entry.is_dir():continue
   name=entry.filename;assert not name.startswith('/') and '\\' not in name and all(x not in ['..','.',''] for x in name.split('/'))
   p=destination/name;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(z.read(entry))
try:
 url='https://www.python.org/ftp/python/3.10.11/python-3.10.11-embed-amd64.zip'
 with urllib.request.urlopen(url,timeout=90) as f:raw=f.read()
 archive=out/'python-3.10.11-embed-amd64.zip';archive.write_bytes(raw);save(out/'PYTHON-INTAKE.json',dict(url=url,pin=pin(archive)))
 runtime=out/'python';runtime.mkdir();extract(archive,runtime)
 # The only runtime configuration change enables the private wheel directory.
 pth=runtime/'python310._pth';original=pth.read_bytes();(out/'python310._pth.original').write_bytes(original);pth.write_text('python310.zip\n.\nsite-packages\n',encoding='utf8',newline='\n')
 wheels=out/'wheels';wheels.mkdir();requirements=['numpy==1.23.3','scipy==1.9.2','pandas==1.5.0','python-dateutil==2.8.2','pytz==2022.4','six==1.16.0']
 cmd=[sys.executable,'-m','pip','--isolated','--disable-pip-version-check','download','--index-url','https://pypi.org/simple','--only-binary=:all:','--python-version','310','--platform','win_amd64','--implementation','cp','--abi','cp310','--dest',str(wheels),*requirements];save(out/'download-command.json',cmd);began=time.monotonic()
 with (out/'download-stdout').open('xb') as so,(out/'download-stderr').open('xb') as se:p=subprocess.run(cmd,cwd=out,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=600)
 save(out/'download-process.json',dict(exit_code=p.returncode,seconds=time.monotonic()-began));assert p.returncode==0
 site=runtime/'site-packages';site.mkdir()
 for wheel in sorted(wheels.glob('*.whl')):extract(wheel,site)
 probe=out/'probe.py';probe.write_text('import numpy,scipy,pandas,sys\nprint(sys.version)\nprint(numpy.__version__,scipy.__version__,pandas.__version__)\n',encoding='utf8')
 cmd=[str(runtime/'python.exe'),'-B',str(probe)];save(out/'probe-command.json',cmd)
 with (out/'probe-stdout').open('xb') as so,(out/'probe-stderr').open('xb') as se:p=subprocess.run(cmd,cwd=out,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=60)
 assert p.returncode==0
 save(out/'INSTALLED-FILES.json',{p.relative_to(runtime).as_posix():pin(p) for p in sorted(runtime.rglob('*')) if p.is_file()})
 save(out/'COMPLETED.json',dict(status='PASS_PRIVATE_SELECTED_CORE_REFERENCE_RUNTIME',python='3.10.11 embedded Windows amd64',requirements=requirements,wheels={p.name:pin(p) for p in sorted(wheels.glob('*.whl'))},package_initializer_executed=False,scope='Unchanged original CBIIT Hsq core reference only. Its web wrapper/CLI and unrelated pybedtools/pysam/bitarray dependencies are not invoked; not a full package installation.'))
 print('PASS private Python3.10.11 NumPy1.23.3/SciPy1.9.2/pandas1.5.0 reference',flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc()));print(repr(e),flush=True);raise
