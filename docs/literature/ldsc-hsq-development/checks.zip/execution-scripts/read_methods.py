import ast
from pathlib import Path
b=Path(__file__).resolve().parent
p=b/'upstream-1/cbiit/ldscore/regressions.py';text=p.read_text();tree=ast.parse(text);lines=text.splitlines()
for node in tree.body:
 if isinstance(node,ast.ClassDef) and node.name=='Hsq':print('\n'.join(lines[node.lineno-1:node.end_lineno]))
 if isinstance(node,ast.ClassDef) and node.name=='LD_Score_Regression':
  for method in node.body:
   if isinstance(method,ast.FunctionDef) and method.name=='_combine_twostep_jknives':print('\n'.join(lines[method.lineno-1:method.end_lineno]))
print('MODULE INIT',(b/'upstream-1/cbiit/ldscore/__init__.py').read_text())
