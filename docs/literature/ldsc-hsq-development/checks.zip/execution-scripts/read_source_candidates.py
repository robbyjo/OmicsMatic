import gzip,json,re,sys,xml.etree.ElementTree as ET
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];sys.path.insert(0,str(r/'tools/literature'));from collect_omics_review import paragraphs
papers=json.loads((r/'docs/literature/omics-2023-2026/papers.json').read_bytes());pattern=re.compile(r'LD[- ]?score regression|LDSC',re.I)
for paper in papers:
 if paper['paper_id'] not in ['P072','P151','P092','P177']:continue
 print('\nPAPER',paper['paper_id'],paper['pmcid'],paper['doi'])
 raw=gzip.decompress((Path('D:/projects/JLinAlg/build/literature-review/xml')/(paper['pmcid']+'.xml.gz')).read_bytes());uses=[u for u in paper['tools'] if u['tool_id']=='ldsc'];indices={u['evidence_paragraph_index'] for u in uses}
 for row in paragraphs(ET.fromstring(raw)):
  if row['paragraph_index'] in indices or pattern.search(row['text']):print('PARAGRAPH',row['paragraph_index'],row['section'],row['text'])
