from pathlib import Path
b=Path(__file__).resolve().parent
s=(b/'build_native2.py').read_text().replace("out=b/'build-2'","out=b/'build-3'").replace('tests=10,errors=0','tests=11,errors=0')
(b/'build_native3.py').write_text(s,encoding='utf8')
