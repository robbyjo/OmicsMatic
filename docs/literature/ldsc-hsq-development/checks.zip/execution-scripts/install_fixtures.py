import hashlib,json,shutil
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];data=json.loads((b/'reference-1/result/reference.json').read_text());assert len(data['cases'])==72 and not data['original_errors']
d=r/'src/test/resources/org/jlinalg/xwas/ldsc-hsq';d.mkdir(parents=True)
models=['id\treference_variants\tblocks\tintercept\ttwo_step\n'];inputs=['id\trow\tchi_square\tld_score\tweight_ld_score\tn\n'];expected=['id\tfield\tfirst\tsecond\tvalue\n']
for c in data['cases']:
 name=c['id'];models.append(f"{name}\t{c['reference_variants']}\t{c['blocks']}\t{c['fixed_intercept']}\t{c['two_step']}\n")
 for i,row in enumerate(zip(c['chi_square'],c['ld'],c['weight_ld'],c['n'])):inputs.append(name+'\t'+str(i)+'\t'+'\t'.join(map(str,row))+'\n')
 def add(field,first,second,value):expected.append(f'{name}\t{field}\t{first}\t{second}\t{value}\n')
 e=c['expected'];nbar=sum(c['n'])/len(c['n']);scale=c['reference_variants']/nbar
 for field,key in [('h2','tot'),('h2_se','tot_se'),('intercept','intercept'),('intercept_se','intercept_se'),('mean_chi','mean_chisq'),('lambda_gc','lambda_gc'),('ratio','ratio'),('ratio_se','ratio_se')]:add(field,0,0,e[key])
 add('coefficient',0,0,e['coef'][0]);add('coefficient_se',0,0,e['coef_se'][0])
 for i,value in enumerate(e['tot_delete_values']):
  add('delete',i,0,value[0]);add('delete',i,1,e['intercept_delete_values'][i] if c['fixed_intercept'] is None else c['fixed_intercept'])
 cov=e['jknife_cov'];add('covariance',0,0,cov[0][0]*scale*scale);add('covariance',1,1,cov[1][1] if len(cov)>1 else 0);add('covariance',0,1,cov[0][1]*scale if len(cov)>1 else 0)
 for i,value in enumerate(c['stages'][-1]['weights']):add('weight',i,0,value)
 for i,value in enumerate(c['stages'][-1]['separators']):add('separator',i,0,value)
 if c['two_step'] is not None:
  for i,value in enumerate(c['stages'][0]['separators']):add('step1_separator',i,0,value)
 for i,call in enumerate(c['weight_calls']):add('weight_h2',i,0,call['h2']);add('weight_intercept',i,0,call['intercept'])
for name,lines in [('models.tsv',models),('inputs.tsv',inputs),('expected.tsv',expected)]:
 (d/name).write_text(''.join(lines),encoding='utf8',newline='\n')
shutil.copyfile(b/'generate_reference.py',d/'generate_reference.py')
pins={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(d.iterdir()) if p.is_file()}
(d/'PROVENANCE.json').write_text(json.dumps(dict(status=data['status'],models=72,python=data['python'],numpy=data['numpy'],scipy=data['scipy'],pandas=data['pandas'],upstream_repository='CBIIT/ldsc',commit='6c673952cee74bd5c57aef1555a03b1c015399a0',source_guards=data['source_guards'],files=pins,scope=data['scope'],package_initializer_executed=False,original_source_modified=False),indent=2)+'\n',encoding='utf8')
print('installed72 original Hsq core models',len(expected)-1,'expected fields',flush=True)
