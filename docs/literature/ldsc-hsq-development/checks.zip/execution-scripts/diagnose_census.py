import gzip,hashlib,json,re,shutil,sys,unicodedata,xml.etree.ElementTree as ET
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];out=b/'source-census-diagnosis-1';out.mkdir();shutil.copyfile(r/'tools/literature/ldsc_hsq/source_census.py',out/'source_census.py')
sys.path.insert(0,str(r/'tools/literature'));from collect_omics_review import paragraphs
data=r/'docs/literature/omics-2023-2026';papers=json.loads((data/'papers.json').read_text());item=next(x for x in json.loads((data/'tool-inventory.json').read_text()) if x['id']=='ldsc');pattern=re.compile(item['pattern'],re.I);found=set();canonical=[]
for paper in papers:
 raw=gzip.decompress((Path('D:/projects/JLinAlg/build/literature-review/xml')/(paper['pmcid']+'.xml.gz')).read_bytes());rows=paragraphs(ET.fromstring(raw));match=[p for p in rows if pattern.search(unicodedata.normalize('NFKC',p['text']))]
 if match:found.add(paper['paper_id'])
 for use in paper['tools']:
  if use['tool_id']=='ldsc':canonical.append(dict(paper_id=paper['paper_id'],use=use))
report=dict(status='RETAINED_FAILED_FIRST_REGEX_EQUALITY_CENSUS_ASSUMPTION',found=len(found),canonical=len(canonical),extra=sorted(found-set(item['papers'])),missing=sorted(set(item['papers'])-found),canonical_rows=canonical)
(out/'DIAGNOSIS.json').write_text(json.dumps(report,indent=2)+'\n');print({k:v for k,v in report.items() if k!='canonical_rows'});print('canonical_example',json.dumps(canonical[0],indent=2)[:3000])
