import json
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];data=json.loads((b/'reference-1/result/reference.json').read_text());d=r/'examples/ldsc-hsq';d.mkdir(parents=True)
for name,index in [('one-step',0),('two-step',4)]:
 case=data['cases'][index];lines=['variant\tchi_square\tld_score\tweight_ld_score\tn\n']
 for i,values in enumerate(zip(case['chi_square'],case['ld'],case['weight_ld'],case['n'])):lines.append('synthetic_'+str(i)+'\t'+'\t'.join(map(str,values))+'\n')
 (d/(name+'.tsv')).write_text(''.join(lines),encoding='utf8',newline='\n')
 request=dict(schema_version=1,input=name+'.tsv',out='../../build/ldsc-hsq-example-'+name,reference_variants=case['reference_variants'],n_blocks=case['blocks'],intercept='free',two_step=case['two_step'],data_provenance='Synthetic original-core numerical fixture '+case['id']+'; no biological data',row_order_declaration='Fixed synthetic reference row order for consecutive block-deletion validation; no real genomic matching claim')
 (d/(name+'.json')).write_text(json.dumps(request,indent=2)+'\n',encoding='utf8',newline='\n')
print('prepared two complete source-reference examples',flush=True)
