import json,subprocess,time
from pathlib import Path
b=Path(__file__).resolve().parent;out=b/'reference-1';out.mkdir()
cmd=[str(b/'reference-runtime-1/python/python.exe'),'-B',str(b/'generate_reference.py'),'--source',str(b/'upstream-1/cbiit'),'--out',str(out/'result')]
(out/'command.json').write_text(json.dumps(cmd,indent=2)+'\n',encoding='utf8');start=time.monotonic()
with (out/'stdout').open('xb') as so,(out/'stderr').open('xb') as se:p=subprocess.run(cmd,cwd=b,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=180)
(out/'PROCESS.json').write_text(json.dumps(dict(exit_code=p.returncode,seconds=time.monotonic()-start))+'\n',encoding='utf8');assert p.returncode==0
print('PASS unchanged selected original Hsq core references',flush=True)
