import hashlib,json,shutil,subprocess,traceback,zipfile
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];out=b/'closure-1';out.mkdir();public=r/'docs/literature/ldsc-hsq-development'
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def pin(p):
 h=hashlib.sha256();size=0
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):size+=len(block);h.update(block)
 return dict(bytes=size,sha256=h.hexdigest())
try:
 win=json.loads((b/'build-3/COMPLETED.json').read_text());runtime=json.loads((b/'runtime-validation-1/COMPLETED.json').read_text());reference=json.loads((b/'reference-1/result/reference.json').read_text());source=json.loads((b/'source-census-3/SOURCE_CENSUS.json').read_text())
 assert win['junit']==runtime['windows_junit']==runtime['linux_same_junit']==dict(tests=11,errors=0,failures=0,skipped=0)
 assert len(reference['cases'])==72 and not reference['original_errors'];assert runtime['numeric_fields_checked']==1218 and runtime['byte_identical_scientific_files']==48 and len(runtime['processes'])==23
 assert len(source['primary_sources'])==250 and len(source['ldsc_papers'])==41 and len(source['targeted_semantic_reviews'])==4
 assert all(pin(b/'upstream-1/cbiit'/name)==v for name,v in reference['source_guards'].items())
 installed=json.loads((b/'reference-runtime-1/INSTALLED-FILES.json').read_text());provider=b/'reference-runtime-1/python';assert {p.relative_to(provider).as_posix() for p in provider.rglob('*') if p.is_file()}==set(installed)
 assert all(pin(provider/name)==v for name,v in installed.items())
 build_guards=json.loads((b/'build-3/SOURCES.json').read_text());assert all(pin(r/name)==v for name,v in build_guards.items())
 jar=b/'build-3/jar/omicsmatic-0.4.0.jar';assert pin(jar)==win['artifact']==runtime['artifact']
 p=subprocess.run(['git','diff','--exit-code','HEAD','--','docs/literature/omics-2023-2026','tools/literature/reviewed-uses.json'],cwd=r,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert p.returncode==0
 names=list(build_guards)+['.gitattributes','tools/literature/ldsc_hsq/source_census.py','docs/vignettes/ldsc-heritability.md','docs/literature/IMPLEMENTATION_PRIORITY.md','docs/literature/ldsc-hsq-development/README.md']+[p.relative_to(r).as_posix() for p in (r/'examples/ldsc-hsq').iterdir() if p.is_file()]
 guards={n:pin(r/n) for n in sorted(set(names))};save(out/'SOURCE_GUARDS.json',guards)
 payloads={}
 def add(name,path):assert name not in payloads and path.is_file() and not path.is_symlink();payloads[name]=path
 for name in guards:add('current-source/'+name,r/name)
 for path in b.glob('*.py'):add('execution-scripts/'+path.name,path)
 for folder in ['build-1','build-2','build-3','reference-1','runtime-validation-1','source-census-diagnosis-1','source-census-2','source-census-3']:
  for path in sorted((b/folder).rglob('*')):
   if not path.is_file():continue
   relative=path.relative_to(b)
   if any(x in relative.parts for x in ['jar','test-report','test-classes','__pycache__']) or path.suffix in ['.class','.pyc']:continue
   add(relative.as_posix(),path)
 for path in sorted((b/'upstream-1').iterdir()):
  if path.is_file():add('upstream-1/'+path.name,path)
 for label in ['bulik','cbiit']:
  for name in ['LICENSE','README.md','setup.py','requirements.txt','ldscore/__init__.py','ldscore/regressions.py','ldscore/irwls.py','ldscore/jackknife.py']:
   path=b/'upstream-1'/label/name
   if path.is_file():add('upstream-1/'+label+'/'+name,path)
 for path in (b/'reference-runtime-1').iterdir():
  if path.is_file() and path.suffix not in ['.zip','.whl']:add('reference-runtime-1/'+path.name,path)
 # Actual original example outputs are retained alongside the requests they executed.
 for name in ['one-step','two-step']:
  folder=r/'build'/('ldsc-hsq-example-'+name)
  for path in folder.rglob('*'):
   if path.is_file():add('copyable-example-results/'+name+'/'+path.relative_to(folder).as_posix(),path)
 save(out/'PROVIDER_RECHECK.json',dict(status='PASS_COMPLETE_UNCHANGED_PRIVATE_CORE_REFERENCE_PROVIDER',files=len(installed),bytes=sum(v['bytes'] for v in installed.values()),runtime_configuration_change='Only private python310._pth enables private wheel directory; original saved',provider_bytes_bundled=False,original_source_files_unchanged=True))
 add('closure/PROVIDER_RECHECK.json',out/'PROVIDER_RECHECK.json');add('closure/SOURCE_GUARDS.json',out/'SOURCE_GUARDS.json')
 index={name:pin(path) for name,path in sorted(payloads.items())};save(out/'PAYLOADS.json',index);sums=''.join(value['sha256']+'  '+name+'\n' for name,value in index.items());(out/'SHA256SUMS').write_text(sums,encoding='utf8',newline='\n')
 archive=public/'checks.zip';assert not archive.exists()
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for name,path in sorted(payloads.items()):z.write(path,name)
  z.write(out/'SHA256SUMS','SHA256SUMS')
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None and len(z.namelist())==len(index)+1 and z.read('SHA256SUMS').decode()==sums
  for name,value in index.items():
   raw=z.read(name);assert dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())==value
 assert all(pin(r/name)==value for name,value in guards.items())
 shutil.copyfile(b/'source-census-3/SOURCE_CENSUS.json',public/'SOURCE_CENSUS.json')
 warnings='''# Warnings and required actions

Native Java analysis requires no Python/LDSC installation. SKIP3 skips an
unavailable/forbidden input or unsupported requested analysis: supply permitted
prepared inputs or a separately qualified method. FAIL2 admits no result:
preserve partial output, read FAILURE.txt/WARNINGS.md, correct the named complete
population, block, input or numeric-capacity issue and retry NEW output.

Require exit0, COMPLETED.json and analysis.json result_admitted=true. Final h2
can be negative or above1 and remains unchanged. Only weight feedback bounds h2;
LD/weight-LD floors affect weights, not the supplied signed regressors. Read the
complete weight-update and row-audit tables. Undefined diagnostics remain NA;
rank-deficient/zero-diagnostic/nonfinite cases refuse completion. Never drop a
failed block or replace nonfinite values to force success.

The numerical core is unpartitioned observed-scale Hsq, with complete explicitly
prepared/genome-ordered rows and declared M/N/blocks/intercept/cutoff. It does not
infer QC, ancestry/reference compatibility, harmonization, region selection,
liability conversion, genetic correlation, stratification or whole-paper scope.
The private original reference executes only unchanged CBIIT3.0.2 numerical
modules under a controlled package namespace; its web/package initializer and
full CLI are not executed. Legacy bulik source is captured, not runtime-qualified.

The current 41 cataloged mentions are not 41 verified Hsq applications. P092 has
an actual stratified role missing from the current catalog; P151 is comparison
only, and P177 is discussion of an alternative. Canonical correction remains
pending. Exact pointers/paraphrases are saved; no family badge is granted.

Integrity hashes do not authenticate execution or prove biological validity.
Independent original-core reference comparison and bounded packaged controls are
the scientific evidence. All earlier failed/prototype attempts remain retained.
'''
 (public/'WARNINGS.md').write_text(warnings,encoding='utf8',newline='\n')
 fields=sum(1 for _ in (r/'src/test/resources/org/jlinalg/xwas/ldsc-hsq/expected.tsv').open())-1;assert fields==12034
 validation=dict(status='PASS_SCOPED_NATIVE_LDSC_HSQ_COMPONENT',profile='native-ldsc-hsq-cbiit302-v1',original_core_repository='CBIIT/ldsc',original_core_commit='6c673952cee74bd5c57aef1555a03b1c015399a0',original_source_unchanged=True,original_package_initializer_executed=False,original_full_CLI_executed=False,independent_original_core_models=72,original_core_fields=fields,windows_junit=win['junit'],linux_same_junit=runtime['linux_same_junit'],packaged_validation=runtime,source_guards=guards,artifact=pin(jar),controls_archive=pin(archive),indexed_payloads=len(index),all_archive_payloads_read_back=True,source_census=pin(public/'SOURCE_CENSUS.json'),warnings=pin(public/'WARNINGS.md'),provider_recheck=json.loads((out/'PROVIDER_RECHECK.json').read_text()),canonical_source_correction_pending=True,new_catalog_integrations=0,admitted_catalog_integrations_unchanged=127,whole_tool_qualified=False,whole_paper_reproduced=False,whole_goal_complete=False)
 save(public/'VALIDATION.json',validation);save(out/'COMPLETED.json',dict(status='PASS_NATIVE_LDSC_HSQ_EVIDENCE_CLOSED',validation=pin(public/'VALIDATION.json'),archive=pin(archive),indexed_payloads=len(index)));print('PASS closed',len(index),'payloads',pin(archive),flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc()));print(repr(e),flush=True);raise
