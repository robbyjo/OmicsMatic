import datetime,hashlib,json,traceback,urllib.request,zipfile,io
from pathlib import Path
b=Path(__file__).resolve().parent;out=b/'upstream-1';out.mkdir()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def get(url):
 req=urllib.request.Request(url,headers={'User-Agent':'OmicsMatic-scientific-source-validation'})
 with urllib.request.urlopen(req,timeout=90) as f:return f.read(),f.geturl()
records=[]
try:
 for label,repo,branch in [('bulik','bulik/ldsc','master'),('cbiit','CBIIT/ldsc','ldsc39')]:
  raw,url=get('https://api.github.com/repos/'+repo+'/commits/'+branch);data=json.loads(raw);sha=data['sha'];save(out/(label+'-commit.json'),data)
  raw,url=get('https://codeload.github.com/'+repo+'/zip/'+sha);archive=out/(label+'-'+sha+'.zip');archive.write_bytes(raw)
  with zipfile.ZipFile(io.BytesIO(raw)) as z:
   assert z.testzip() is None
   prefix=z.namelist()[0].split('/')[0]+'/'
   for member in z.infolist():
    name=member.filename.removeprefix(prefix)
    if member.is_dir() or not name:continue
    assert not name.startswith('/') and all(x not in ['..','.',''] for x in name.split('/')) and '\\' not in name
    target=out/label/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(member))
  records.append(dict(label=label,repository=repo,branch=branch,commit=sha,archive_url=url,archive_bytes=len(raw),archive_sha256=hashlib.sha256(raw).hexdigest(),retrieved_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
  print(label,sha,flush=True)
  for name in ['requirements.txt','setup.py','environment3.yml']:
   p=out/label/name
   if p.exists():print(name,p.read_text(encoding='utf8')[:5000],flush=True)
 save(out/'INTAKE.json',records)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc(),completed=records));raise
