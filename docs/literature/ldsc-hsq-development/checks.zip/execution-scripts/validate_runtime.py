import csv,hashlib,json,math,shutil,subprocess,time,traceback,xml.etree.ElementTree as ET,zipfile
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];out=b/'runtime-validation-1';out.mkdir()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def linux(p):return '/mnt/d/'+p.resolve().as_posix().split(':/',1)[1]
records=[];checked=0;maximum_scaled_error=0
def run(label,cmd,expected):
 save(out/(label+'.command.json'),cmd);start=time.monotonic()
 with (out/(label+'.stdout')).open('xb') as so,(out/(label+'.stderr')).open('xb') as se:p=subprocess.run(cmd,cwd=r,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=180)
 receipt=dict(label=label,exit_code=p.returncode,expected=expected,seconds=time.monotonic()-start);save(out/(label+'.PROCESS.json'),receipt);records.append(receipt);assert p.returncode==expected,receipt
def close(actual,expected):
 global checked,maximum_scaled_error
 if expected is None or expected=='NA':assert actual is None or actual=='NA';return
 a=float(actual);e=float(expected);scale=max(abs(a),abs(e));error=abs(a-e);assert error<=2e-9*scale+2e-13,(a,e)
 if scale:maximum_scaled_error=max(maximum_scaled_error,error/scale)
 checked+=1
def table(p):
 with p.open(encoding='utf8',newline='') as f:return list(csv.DictReader(f,delimiter='\t'))
try:
 win=json.loads((b/'build-3/COMPLETED.json').read_text());assert win['junit']==dict(tests=11,errors=0,failures=0,skipped=0);jar=b/'build-3/jar/omicsmatic-0.4.0.jar';assert pin(jar)==win['artifact']
 classes=['org.jlinalg.xwas.LdscHeritabilityTest','org.jlinalg.cli.LdscToolsCliTest']
 for name in classes:
  folder,simple=name.rsplit('.',1)
  for p in (r/'build/classes/java/test'/folder.replace('.','/')).glob(simple+'*.class'):
   target=out/'test-classes'/folder.replace('.','/')/p.name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
 shutil.copytree(r/'src/test/resources/org/jlinalg/xwas/ldsc-hsq',out/'test-resources/org/jlinalg/xwas/ldsc-hsq')
 console=r/'build/nfcore-atacseq121-1/linux-test-runtime-1/junit-platform-console-standalone-1.13.4.jar';save(out/'TEST-RUNTIME.json',dict(console=pin(console),classes={p.relative_to(out).as_posix():pin(p) for p in (out/'test-classes').rglob('*.class')}))
 cmd=['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--exec','/usr/bin/java','-Xmx2048m','-jar',linux(console),'execute','--class-path',':'.join(linux(p) for p in [jar,out/'test-classes',out/'test-resources'])]
 for name in classes:cmd.extend(['--select-class',name])
 cmd.extend(['--reports-dir',linux(out/'linux-junit-reports'),'--disable-ansi-colors']);run('linux-tests',cmd,0)
 trees=[ET.parse(p).getroot() for p in (out/'linux-junit-reports').glob('TEST-*.xml')];counts={k:sum(int(t.attrib.get(k,0)) for t in trees) for k in ['tests','errors','failures','skipped']};assert counts==win['junit']
 reference=json.loads((b/'reference-1/result/reference.json').read_text());java='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe'
 def cli(platform,request):return [java,'-jar',str(jar),'ldsc-tools','h2','--request',str(request)] if platform=='windows' else ['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--exec','/usr/bin/java','-jar',linux(jar),'ldsc-tools','h2','--request',linux(request)]
 exact_files=['estimates.tsv','delete-values.tsv','covariance.tsv','row-audit.tsv','block-boundaries.tsv','weight-updates.tsv','analysis.json','WARNINGS.md']
 for index in range(6):
  c=reference['cases'][index];case=out/('case-'+str(index));case.mkdir();(case/'input.tsv').write_text('variant\tchi_square\tld_score\tweight_ld_score\tn\n'+''.join('rs'+str(i)+'\t'+'\t'.join(map(str,row))+'\n' for i,row in enumerate(zip(c['chi_square'],c['ld'],c['weight_ld'],c['n']))),encoding='utf8',newline='\n')
  for platform in ['windows','linux']:
   request=dict(schema_version=1,input='input.tsv',out=platform,reference_variants=c['reference_variants'],n_blocks=c['blocks'],intercept='free' if c['fixed_intercept'] is None else c['fixed_intercept'],two_step=c['two_step'],data_provenance='Original selected-core synthetic numerical model '+c['id'],row_order_declaration='Fixed original synthetic row order; no biological/genomic matching claim');save(case/(platform+'.json'),request);run(platform+'-case-'+str(index),cli(platform,case/(platform+'.json')),0)
   result=case/platform;assert (result/'COMPLETED.json').is_file();manifest=json.loads((result/'manifest.json').read_text());assert all(pin(result/name)==value for name,value in manifest.items());report=json.loads((result/'analysis.json').read_text());assert report['result_admitted']
   e=c['expected'];mapping={'h2':'tot','h2_se':'tot_se','intercept':'intercept','intercept_se':'intercept_se','mean_chi_square':'mean_chisq','lambda_gc':'lambda_gc','ratio':'ratio','ratio_se':'ratio_se'}
   for key,value in mapping.items():close(report['diagnostics'][key],e[value])
   for i,row in enumerate(table(result/'delete-values.tsv')):close(row['h2_delete'],e['tot_delete_values'][i][0]);close(row['intercept_delete'],e['intercept_delete_values'][i] if c['fixed_intercept'] is None else c['fixed_intercept'])
   for i,row in enumerate(table(result/'row-audit.tsv')):close(row['final_precision_weight'],c['stages'][-1]['weights'][i]);assert row['step1_selected']==str(c['two_step'] is None or c['chi_square'][i]<c['two_step']).lower()
   for i,row in enumerate(table(result/'block-boundaries.tsv')):assert int(row['full_row_position'])==c['stages'][-1]['separators'][i]
  assert all((case/'windows'/name).read_bytes()==(case/'linux'/name).read_bytes() for name in exact_files)
 # Negative CLI processes use fresh output directories; successful bundles stay unchanged.
 for platform in ['windows','linux']:
  for kind,expected in [('missing-input',3),('duplicate-id',2),('blank-row',2),('too-few-step1',2)]:
   case=out/(platform+'-'+kind);case.mkdir();base=json.loads((out/'case-0'/('windows.json')).read_text());base.update(out='result');
   if kind=='too-few-step1':base['two_step']=.01
   if kind!='missing-input':
    original=(out/'case-0/input.tsv').read_text();lines=original.splitlines();content=original
    if kind=='duplicate-id':content=original+lines[1]+'\n'
    if kind=='blank-row':content=original+'\n'
    (case/'input.tsv').write_text(content,encoding='utf8',newline='\n')
   save(case/'request.json',base);run(platform+'-'+kind,cli(platform,case/'request.json'),expected);assert not (case/'result/COMPLETED.json').exists()
 # Execute the actual copyable example requests, including their original output paths.
 for name in ['one-step','two-step']:
  request=r/'examples/ldsc-hsq'/(name+'.json');config=json.loads(request.read_text());result=(request.parent/config['out']).resolve();assert not result.exists();run('example-'+name,[java,'-jar',str(jar),'ldsc-tools','h2','--request',str(request)],0);assert (result/'COMPLETED.json').is_file()
 # Preserve all prior scientific implementations at executable-member level.
 old=r/'build/dunnett-high-impact-1/build-3/jar/omicsmatic-0.4.0.jar'
 with zipfile.ZipFile(old) as a,zipfile.ZipFile(jar) as c:
  aa=set(a.namelist());cc=set(c.namelist());changed=[n for n in sorted(aa&cc) if a.read(n)!=c.read(n)];added=sorted(cc-aa);removed=sorted(aa-cc)
 assert not removed and changed==['org/jlinalg/cli/JLinAlgCli.class'],(removed,changed)
 assert all(name.startswith(('org/jlinalg/xwas/LdscHeritability','org/jlinalg/cli/LdscToolsCli')) for name in added),added
 save(out/'JAR-MEMBER-COMPATIBILITY.json',dict(status='PASS_OLD_MEMBERS_IDENTICAL_EXCEPT_EXPLICIT_ROOT_DISPATCHER',changed=changed,added=added,removed=removed))
 save(out/'COMPLETED.json',dict(status='PASS_NATIVE_LDSC_PACKAGED_AND_LINUX_VALIDATION',windows_junit=win['junit'],linux_same_junit=counts,packaged_positive_models=6,platforms=['Windows','Linux'],numeric_fields_checked=checked,maximum_relative_error_without_absolute_floor=maximum_scaled_error,byte_identical_scientific_files=len(exact_files)*6,processes=records,artifact=pin(jar),new_catalog_integrations=0,whole_goal_complete=False));print('PASS',len(records),'processes;',checked,'original fields;',len(exact_files)*6,'cross-platform identical files',flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc(),processes=records));print(repr(e),flush=True);raise
