from pathlib import Path
b=Path(__file__).resolve().parent;s=(b/'prepare_examples.py').read_text().replace('d.mkdir(parents=True)','d.mkdir(parents=True,exist_ok=True)')
s=s.replace("(d/(name+'.tsv')).write_text", "assert not (d/(name+'.tsv')).exists() and not (d/(name+'.json')).exists()\n (d/(name+'.tsv')).write_text")
(b/'prepare_examples_fixed.py').write_text(s,encoding='utf8')
