# Original nf-core declared workflow result

Required action: read the latest attempt's WARNINGS.md, engine log/trace, process ledgers and complete source-component reports. Require a COMPLETED result and successful --verify before downstream use. SKIP3 means a missing/forbidden exact prerequisite or unsupported requested profile/capability: affected analysis skipped; install/download only where permitted through separate setup, or provide the admitted local runtime/source/image. FAIL2 means invalid/inconsistent input, changed integrity, process/cleanup/capacity failure or unassessable source output: no adapter result is admitted. Preserve originals, every failed attempt and all source missing/nonfinite values; resolve the named cause and use NEW paths for changed requests/inputs/capacities. --resume uses the immutable captured request/input/cache, with no fallback across indeterminate runs. This source-specific adapter executes original programs and checks complete selected output contracts; source feature classifications, optical clustering, Preseq extrapolation and negative-binomial fitting remain upstream methods. Biological accuracy, independent model reimplementation, whole-paper reproduction and unreported author settings are not certified. Hashes establish integrity, not authenticity. Other nf-core families/versions remain pending. Cell Ranger remains excluded.

# Nextflow declared workflow result

Required action: inspect the latest attempt's WARNINGS.md, FAILURE.json when present, original nextflow.log, trace.tsv and process logs. Require COMPLETED.json and successful --verify before downstream use. SKIP3 means the exact runtime, permitted dependency or requested task capability is unavailable: skip dependent analysis and complete permitted setup first. Export setup separately with --export-runtime-setup; downloads/installations require explicit installer flags and are never attempted during analysis. FAIL2 means invalid input, changed evidence, process, capacity, cancellation or finalization failure: no result is admitted. Preserve every attempt, correct the named cause and use NEW paths if the immutable request/capacities must change. --resume uses the same captured recipe, inputs, working files and original Nextflow cache; editing originals is not a request to change the captured analysis. The guard tracks owned local Linux processes, not remote scheduler/service lifecycles. Portable verification checks complete captured bytes, declared input/output contracts, exact command/parameters and original completion/trace consistency; it does not rerun biology, readmit the producer host or authenticate execution history. Hashes establish integrity, not authenticity. A complete declared workflow result does not certify biological accuracy or reproduce unresolved paper settings. Cell Ranger remains excluded.

WARNING: Effective filesystem permission modes differ from requested archive modes for 130 runtime members. Bytes and link targets remain exact; required executable access was checked. Use a permitted filesystem and fresh setup paths if exact POSIX modes are needed.



## reads-and-alignments

# Native ChIP-seq component audit only



Required action: this is a native component audit, with no nf-core tool or biological admission. Require the complete original pipeline/runtime/scientific contracts before downstream claims. Preserve original outputs, IDs, flags, failures and source numeric tokens. FAIL2 means the named contract is incomplete or inconsistent; no component result admitted. Correct the named cause and use a new audit path. Hashes establish integrity, not authenticity. Cell Ranger remains excluded.


## consensus

# Original consensus component only

WARNING: Original ChIP-seq1.2.1 writes BED's zero-based Start directly to SAF. The native audit preserves this source convention and does not increment Start. Standard one-based SAF interpretation therefore differs by one base. Do not relabel or silently repair it; a coordinate conversion requires a separate declared analysis with original outputs retained.

Required action: this is a source-specific consensus component audit, with zero nf-core tool credit and no whole-pipeline scientific or biological admission. Preserve all original peaks, tokens, failures and coordinate conventions. FAIL2 means no consensus component result is admitted: correct the named cause and use a new audit path. Complete the original runtime/image and remaining scientific contracts before downstream claims. Hashes establish integrity, not execution authenticity. Cell Ranger remains excluded.


## complexity

# Library-complexity component only

WARNING: Optical duplicate counts remain original-engine classifications. The native audit verifies their count bounds and use in the source library-size formula; it does not independently infer optical read clusters.

WARNING: Preseq estimates and confidence intervals remain original-engine outputs. Complete finite/grid/order/bound consistency is checked; passing this component does not independently validate the extrapolation model or biological library complexity.

Required action: this is a source-specific library-complexity component, with no nf-core tool, whole-pipeline or biological admission. It counts the full original marked BAM and checks Picard 2.23.1 derived formulas and complete published histograms. It does not independently mark duplicates, identify optical duplicates or recompute Preseq extrapolation/CI. Retain all raw counts, original absent/nonfinite estimates, coordinate conventions, failed attempts and warnings. FAIL2 means no component result: inspect the named count, integrity, output or capacity discrepancy, correct its cause and retry a NEW directory. No producer work paths or substitute tools are used. Hashes establish integrity, not execution authenticity.


## annotation-QC

# Original annotation and QC consistency component

Original HOMER feature labels and metadata remain upstream results; native checks cover complete identities/geometry, compatible nearest gene-TSS assignments and all published aggregate counts/statistics. Feature-priority classification and PDF rendering are not independently recomputed.

38 rows have multiple compatible nearest gene-TSS assignments. The original choice is retained; no unique assignment is invented.

Required action: this is an original annotation/QC consistency component, with no biological or independent feature-classification admission. Gene-ID mode retains raw transcript TSS rows and uses the original last-row-per-contig/gene lookup; transcripts are not merged into gene spans. Raw missing annotations remain unchanged. The original plotting script's separate NA-distance -> Unassigned copy and absent-category NA cells are retained. FAIL2 admits no component result: inspect the named source, identity, geometry, TSS or QC discrepancy, preserve all originals/failures and retry a NEW output path after resolving its cause. No identifier, coordinate, missing value or threshold is repaired.


## differential

# Postfit component only: no scientific result admitted

WARNING: Original ChIP-seq1.2.1 copies BED zero-based Start unchanged into SAF; featureCounts treats SAF positions inclusively. This audit preserves that convention and Length=End-Start+1. Any coordinate conversion requires a separate declared analysis with originals retained.

SPT5: ORIGINAL_DISPERSION_FIT: local; retained from the fitted object, without refitting or substituting a parametric curve.

SPT5: original runtime reports warnings in antibody-000001/process/process.stderr; review the retained complete stderr and sessionInfo.txt.
Loading required package: S4Vectors
Loading required package: stats4
Loading required package: BiocGenerics
Loading required package: parallel

Attaching package: ‘BiocGenerics’

The following objects are masked from ‘package:parallel’:

    clusterApply, clusterApplyLB, clusterCall, clusterEvalQ,
    clusterExport, clusterMap, parApply, parCapply, parLapply,
    parLapplyLB, parRapply, parSapply, parSapplyLB

The following objects are masked from ‘package:stats’:

    IQR, mad, sd, var, xtabs

The following objects are masked from ‘package:base’:

    anyDuplicated, append, as.data.frame, basename, cbind, colnames,
    dirname, do.call, duplicated, eval, evalq, Filter, Find, get, grep,
    grepl, intersect, is.unsorted, lapply, Map, mapply, match, mget,
    order, paste, pmax, pmax.int, pmin, pmin.int, Position, rank,
    rbind, Reduce, rownames, sapply, setdiff, sort, table, tapply,
    union, unique, unsplit, which, which.max, which.min


Attaching package: ‘S4Vectors’

The following object is masked from ‘package:base’:

    expand.grid

Loading required package: IRanges
Loading required package: GenomicRanges
Loading required package: GenomeInfoDb
Loading required package: SummarizedExperiment
Loading required package: Biobase
Welcome to Bioconductor

    Vignettes contain introductory material; view with
    'browseVignettes()'. To cite Bioconductor, see
    'citation("Biobase")', and for packages 'citation("pkgname")'.

Loading required package: DelayedArray
Loading required package: matrixStats

Attaching package: ‘matrixStats’

The following objects are masked from ‘package:Biobase’:

    anyMissing, rowMedians

Loading required package: BiocParallel

Attaching package: ‘DelayedArray’

The following objects are masked from ‘package:matrixStats’:

    colMaxs, colMins, colRanges, rowMaxs, rowMins, rowRanges

The following objects are masked from ‘package:base’:

    aperm, apply, rowsum

Warning message:
package ‘matrixStats’ was built under R version 3.6.3 


Required action: inspect WARNINGS.md, audit.json, every process/process.stderr and the original warning/session files. This is a DESeq2 postfit component audit: no negative-binomial refit, independent rlog/vst recomputation, whole-pipeline, biological or paper admission; zero nf-core tool credit. Preserve originals and failed attempts. SKIP3 means a missing/forbidden prerequisite: install the exact permitted runtime/image separately, or use an allowed Linux environment, then retry a NEW output path. FAIL2 means no component result: inspect the named integrity, input, process, capacity or numeric discrepancy; correct its cause and retry a NEW path. Hashes establish integrity, not execution authenticity.
