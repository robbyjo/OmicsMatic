# Nextflow process FAIL2 failed

java.io.IOException: Cannot run program "/usr/bin/setsid" (in directory "/var/tmp/omicsmatic-nfcore-chipseq121-adapter-2"): Failed to exec spawn helper: pid: 77444, exit code: 1, error: 0 (none) 
Possible reasons:
  - Spawn helper ran into JDK version mismatch
  - Spawn helper ran into unexpected internal error
  - Spawn helper was terminated by another process
Possible solutions:
  - Restart JVM, especially after in-place JDK updates
  - Check system logs for JDK-related errors
  - Re-install JDK to fix permission/versioning problems
  - Switch to legacy launch mechanism with -Djdk.lang.Process.launchMechanism=VFORK


Required action: preserve this directory, stdout, stderr and process ledger. Admit results only after the complete scientific output audit. Correct any failure and rerun to a new output directory.
