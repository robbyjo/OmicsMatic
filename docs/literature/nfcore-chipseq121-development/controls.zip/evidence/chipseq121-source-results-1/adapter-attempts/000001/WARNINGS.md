# FAIL2_NO_RESULT

java.io.IOException: Cannot run program "/usr/bin/setsid" (in directory "/var/tmp/omicsmatic-nfcore-chipseq121-adapter-2"): Failed to exec spawn helper: pid: 77444, exit code: 1, error: 0 (none) 
Possible reasons:
  - Spawn helper ran into JDK version mismatch
  - Spawn helper ran into unexpected internal error
  - Spawn helper was terminated by another process
Possible solutions:
  - Restart JVM, especially after in-place JDK updates
  - Check system logs for JDK-related errors
  - Re-install JDK to fix permission/versioning problems
  - Switch to legacy launch mechanism with -Djdk.lang.Process.launchMechanism=VFORK


Required action: read the latest attempt's WARNINGS.md, engine log/trace, process ledgers and complete source-component reports. Require a COMPLETED result and successful --verify before downstream use. SKIP3 means a missing/forbidden exact prerequisite or unsupported requested profile/capability: affected analysis skipped; install/download only where permitted through separate setup, or provide the admitted local runtime/source/image. FAIL2 means invalid/inconsistent input, changed integrity, process/cleanup/capacity failure or unassessable source output: no adapter result is admitted. Preserve originals, every failed attempt and all source missing/nonfinite values; resolve the named cause and use NEW paths for changed requests/inputs/capacities. --resume uses the immutable captured request/input/cache, with no fallback across indeterminate runs. This source-specific adapter executes original programs and checks complete selected output contracts; source feature classifications, optical clustering, Preseq extrapolation and negative-binomial fitting remain upstream methods. Biological accuracy, independent model reimplementation, whole-paper reproduction and unreported author settings are not certified. Hashes establish integrity, not authenticity. Other nf-core families/versions remain pending. Cell Ranger remains excluded.
