# Original annotation and QC consistency component

Original HOMER feature labels and metadata remain upstream results; native checks cover complete identities/geometry, compatible nearest gene-TSS assignments and all published aggregate counts/statistics. Feature-priority classification and PDF rendering are not independently recomputed.

38 rows have multiple compatible nearest gene-TSS assignments. The original choice is retained; no unique assignment is invented.

Required action: this is an original annotation/QC consistency component, with no biological or independent feature-classification admission. Gene-ID mode retains raw transcript TSS rows and uses the original last-row-per-contig/gene lookup; transcripts are not merged into gene spans. Raw missing annotations remain unchanged. The original plotting script's separate NA-distance -> Unassigned copy and absent-category NA cells are retained. FAIL2 admits no component result: inspect the named source, identity, geometry, TSS or QC discrepancy, preserve all originals/failures and retry a NEW output path after resolving its cause. No identifier, coordinate, missing value or threshold is repaired.
