/* Copyright (C) 2026 JLinAlg contributors; SPDX-License-Identifier: GPL-3.0-or-later */
package org.jlinalg.cli;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import static org.jlinalg.cli.NextflowFiles.*;

/** Explicit source/runtime selection over the existing fully typed captured-engine recipe. */
final class NfcoreChipseqRequest {
    private NfcoreChipseqRequest() { }
    static final String PROFILE = "nfcore-chipseq-1.2.1";
    static final String ENGINE = "linux-x86_64-nextflow-21.04.1";
    static final String EXTERNAL = "// No institutional overrides selected; original scientific defaults remain in force.\n";
    record Request(Path recipe, Path containerHome, Path image, String peakType, String readMode,
                   int minimumReplicates, int executorCpus, long executorMemoryBytes, Map<?, ?> raw) { }
    static Request read(Path file) throws IOException {
        Map<?, ?> raw = object(NextflowParameters.parse(utf8(bytes(file, 4194304)), 4194304, 100000));
        keys(raw, "schema_version", "pipeline_profile", "engine_recipe", "container_home", "image", "peak_type", "read_mode", "minimum_replicates", "executor_cpus", "executor_memory_bytes"); integer(raw.get("schema_version"), 1, 1);
        if (!PROFILE.equals(text(raw.get("pipeline_profile")))) throw new NextflowProcess.Unavailable("Requested nf-core family/version is not admitted by this adapter profile. No pipeline/engine version is inferred or substituted; dependent analysis skipped.");
        String peak = text(raw.get("peak_type")), mode = text(raw.get("read_mode")); if (!Set.of("broadPeak", "narrowPeak").contains(peak) || !Set.of("paired", "single").contains(mode)) throw new IOException("Declare exact source peak_type and read_mode");
        return new Request(absolute(raw.get("engine_recipe")), absolute(raw.get("container_home")), absolute(raw.get("image")), peak, mode, (int) integer(raw.get("minimum_replicates"), 1, 1000000), (int) integer(raw.get("executor_cpus"), 1, 1024), integer(raw.get("executor_memory_bytes"), 16777216, 1099511627776L), raw);
    }
    private static Path absolute(Object value) throws IOException { Path path = Path.of(text(value)); if (!path.isAbsolute() || !path.normalize().equals(path)) throw new IOException("Require literal normalized absolute source/runtime paths"); return path; }
    static String overlay(Request request, Path engine) throws IOException {
        for (Path path : List.of(engine, request.image())) if (path.toString().indexOf(',') >= 0 || path.toString().chars().anyMatch(c -> c < 32 || c == 127)) throw new NextflowProcess.Unavailable("Original config/bind syntax cannot represent the requested path. Use NEW supported run/runtime paths; analysis skipped.");
        return "process.executor = 'local'\nprocess.container = " + quote(request.image().toString()) + "\nexecutor.cpus = " + request.executorCpus() + "\nexecutor.memory = '" + request.executorMemoryBytes() + " B'\nsingularity.cacheDir = " + quote(engine.resolve("workspace/execution/container-cache").toString()) + "\nsingularity.autoMounts = true\nsingularity.runOptions = '--userns --no-home --pid'\n";
    }
    private static String quote(String value) { return "'" + value.replace("\\", "\\\\").replace("'", "\\'") + "'"; }
    static NextflowRecipe.Request validate(Request request, Path engine) throws IOException {
        NextflowRecipe.Request recipe = NextflowRecipe.read(request.recipe());
        if (!recipe.profile().equals(ENGINE)) throw new NextflowProcess.Unavailable("ChIP-seq1.2.1 admission selects exact Nextflow21.04.1. The author engine can remain unreported; requested unsupported engine is not silently replaced. Analysis skipped.");
        if (!recipe.workflow().entrypoint().equals("main.nf") || !recipe.workflow().configs().equals(List.of("nextflow.config", "runtime/host.config")) || !recipe.workflow().profiles().equals(List.of("singularity")) || !recipe.requireTasks()) throw new IOException("Require the original entrypoint, complete primary-config order, singularity profile and observed tasks");
        Path bundle = recipe.sources().get("bundle"); if (bundle == null || !recipe.workflow().source().startsWith(bundle)) throw new IOException("Declare one complete common bundle containing workflow, bound design, reads and references");
        for (Path source : recipe.sources().values()) if (!source.startsWith(bundle)) throw new IOException("Every declared input alias must remain in the complete captured common bundle");
        if (recipe.tools().size() != 1 || !recipe.tools().get(0).name().equals("singularity") || !recipe.tools().get(0).executable().equals(request.containerHome().resolve("bin/singularity"))) throw new IOException("Declare only the exact admitted private singularity launcher; no host scientific executable substitute is accepted");
        Map<?, ?> parameters = object(recipe.parameters());
        for (var pair : Map.of("input", "design", "fasta", "fasta", "gtf", "gtf", "custom_config_base", "external_configs").entrySet()) {
            if (!object(parameters.get(pair.getKey())).equals(Map.of("$input", pair.getValue())) || !recipe.sources().containsKey(pair.getValue())) throw new IOException("Require complete declared captured input binding: " + pair.getKey());
        }
        if (!object(parameters.get("outdir")).equals(Map.of("$output", "")) || !object(parameters.get("tracedir")).equals(Map.of("$output", "pipeline_info"))) throw new IOException("Original output/trace paths must bind to the owned published tree");
        if (!parameters.containsKey("macs_gsize")) throw new IOException("Declare the actual source MACS genome-size setting explicitly");
        for (var entry : parameters.entrySet()) if (text(entry.getKey()).startsWith("skip_") && Boolean.TRUE.equals(entry.getValue())) throw new NextflowProcess.Unavailable("This profile requires the complete selected original workflow branches; requested skip flag is outside this admission: " + entry.getKey() + ". Use the separately scoped source tool where appropriate; analysis skipped.");
        requireFlag(parameters, "single_end", request.readMode().equals("single")); requireFlag(parameters, "narrow_peak", request.peakType().equals("narrowPeak"));
        if (parameters.containsKey("min_reps_consensus") && integer(parameters.get("min_reps_consensus"), 1, 1000000) != request.minimumReplicates()) throw new IOException("Declared consensus minimum differs from exact source parameter");
        if (!parameters.containsKey("min_reps_consensus") && request.minimumReplicates() != 1) throw new IOException("Non-default source replicate minimum must be explicit in parameters");
        if (parameters.containsKey("max_cpus") && integer(parameters.get("max_cpus"), 1, 1024) > request.executorCpus()) throw new IOException("Requested source task CPU maximum exceeds declared executor capacity");
        Path external = recipe.sources().get("external_configs"); if (!Files.isDirectory(external) || !utf8(bytes(external.resolve("nfcore_custom.config"), 1048576)).equals(EXTERNAL)) throw new IOException("Require the separately declared no-institutional-override runtime binding; no unreported institutional configuration is inferred");
        try (var files = Files.list(external)) { if (!files.map(p -> p.getFileName().toString()).collect(java.util.stream.Collectors.toSet()).equals(Set.of("nfcore_custom.config"))) throw new IOException("Unexpected external configuration members"); }
        if (!utf8(bytes(recipe.workflow().source().resolve("runtime/host.config"), 1048576)).equals(overlay(request, engine))) throw new IOException("Runtime-only overlay differs from the typed local executor, image and namespace binding");
        originalSource(recipe.workflow().source());
        Set<String> required = Set.of("pipeline_info", "fastqc", "trim_galore", "bwa", "genome", "multiqc", "igv"); var directories = new HashSet<String>();
        for (var output : recipe.outputs()) if (output.kind().equals("directory") && !output.allowEmpty()) directories.add(output.path());
        if (!directories.containsAll(required)) throw new IOException("Declare every required nonempty source output family; complete publication capture is mandatory");
        return recipe;
    }
    private static void requireFlag(Map<?, ?> parameters, String name, boolean expected) throws IOException { Object value = parameters.get(name); if (parameters.containsKey(name) ? !Boolean.valueOf(expected).equals(value) : expected) throw new IOException("Exact original " + name + " selection must agree with declared mode"); }
    static void originalSource(Path workflow) throws IOException {
        byte[] raw;
        try (var input = NfcoreChipseqRequest.class.getResourceAsStream("/org/jlinalg/omics/nfcore/nfcore-source-lock.json")) { if (input == null) throw new IOException("Missing original source lock"); raw = input.readNBytes(134642); }
        if (raw.length != 134641 || !sha(raw).equals("f5ef123c1d212061c202a1b5ef2d9fef62aa3f7cc764834d40c0c94799bf8646")) throw new IOException("Original source-lock bytes differ");
        Map<?, ?> profile = object(object(object(SimpleJson.parse(utf8(raw))).get("pipelines")).get("chipseq-1.2.1")); Map<?, ?> files = object(profile.get("files")); var expected = new HashSet<String>();
        for (var entry : files.entrySet()) { String name = member(text(entry.getKey())); if (!pin(workflow.resolve(name), 1000000000L, () -> { }).equals(fingerprint(entry.getValue(), 1000000000L))) throw new IOException("Original ChIP-seq1.2.1 source differs: " + name); expected.add(name); }
        expected.add("runtime/host.config"); var actual = tree(workflow, 10000, 1000000000L, 1000000000L, () -> { });
        if (!actual.keySet().equals(expected) || actual.values().stream().anyMatch(value -> !value.kind().equals("file"))) throw new IOException("Original source directory has missing/extra code or links beyond the explicit runtime overlay");
    }
}
