"""Preserve complete small result/attempt metadata; large immutable source objects remain local."""
from pathlib import Path
import json,subprocess,sys,shutil,collections,hashlib
if sys.platform!='linux':raise SystemExit(subprocess.call(['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--exec','/usr/bin/python3','/mnt/d/projects/JLinAlg/build/literature-review/nfcore-runtime/snapshot_typed_chipseq121_results1.py']))
base=Path('/mnt/d/projects/JLinAlg/build/literature-review/nfcore-runtime');run=Path('/var/tmp/omicsmatic-nfcore-chipseq121-adapter-2');assert json.loads((run/'latest.json').read_text())==dict(attempt='000003',status='COMPLETED');out=base/'chipseq121-source-results-1';out.mkdir();excluded={'objects','named-inputs','work','resources','execution','container-cache','container-tmp'}
def copy_metadata(src,dest):
 for p in sorted(src.rglob('*')):
  relative=p.relative_to(src)
  if any(x in excluded for x in relative.parts) or not p.is_file():continue
  assert not p.is_symlink() and p.stat().st_size<=67108864,(p,p.stat().st_size);q=dest/relative;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q);assert p.read_bytes()==q.read_bytes()
traces={}
for i in [1,2,3]:
 id=f'{i:06d}';copy_metadata(run/'engine/attempts'/id,out/'engine'/id);copy_metadata(run/'attempts'/id,out/'adapter-attempts'/id);p=run/'engine/attempts'/id/'trace.tsv';rows=p.read_text().splitlines();header=rows[0].split('\t');pos=header.index('status');traces[id]=dict(collections.Counter(line.split('\t')[pos] for line in rows[1:]));assert sum(traces[id].values())==97
for id,compiler in [('000002','21'),('000003','25')]:
 src=run/'results'/id;assert (src/'COMPLETED.json').exists();copy_metadata(src,out/('compiler'+compiler));assert json.loads((src/'workflow.json').read_text())['complete_published_files']>0
copy_metadata(Path('/var/tmp/omicsmatic-nfcore-chipseq121-adapter-1'),out/'earlier-missing-entrypoint')
for name in ['missing_container_home','workspace_capacity']:
 src=Path('/var/tmp/omicsmatic-nfcore-chipseq121-fault-'+name+'-1');copy_metadata(src,out/'faults'/name);src=Path('/var/tmp/omicsmatic-nfcore-chipseq121-fault-prepared-'+name+'-1');dest=out/'fault-preparation'/name;dest.mkdir(parents=True);shutil.copyfile(src/'COMPLETED.json',dest/'COMPLETED.json');shutil.copyfile(src/'request.json',dest/'request.json');shutil.copyfile(src/'engine-recipe.json',dest/'engine-recipe.json')
dpkg=Path('/var/log/dpkg.log');lines=dpkg.read_text().splitlines();(out/'host-java-update-evidence.txt').write_text('\n'.join(s for s in lines if s.startswith('2026-11-11 ') and any(x in s for x in ['openjdk-21','ca-certificates-java']))+'\n');(out/'COMPLETED.json').write_text(json.dumps(dict(status='PASS_TWO_TYPED_SOURCE_PROFILE_EXECUTIONS_AND_RETAINED_FAILURES',traces=traces,full_input_streams_retained=True,original_tasks_first_run=97,large_original_objects_remain_local=True,biological_accuracy_certified=False,new_tool_credit=0),indent=2)+'\n');print('Saved complete small source result metadata',traces,flush=True)
