from pathlib import Path
import json,hashlib,shutil
b=Path('build/literature-review/nfcore-runtime');out=b/'annotation-native-fixture-1';out.mkdir();a=b/'scientific-cross-platform-2/original-complete-attempt';members=json.loads((a/'outputs.json').read_bytes())['members'];cap=json.loads((a/'capture.json').read_bytes());rows={}
def copy(name,dest):
 identity=members[name]['pin'];source=a/'objects'/identity['sha256'];assert source.stat().st_size==identity['bytes'] and hashlib.sha256(source.read_bytes()).hexdigest()==identity['sha256'];target=out/dest;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target);rows[dest]=identity
prefix='bwa/mergedLibrary/macs/broadPeak/'
for sample in ['SPT5_T0_R1','SPT5_T0_R2','SPT5_T15_R1','SPT5_T15_R2']:
 for suffix in ['_peaks.broadPeak','_peaks.annotatePeaks.txt']:copy(prefix+sample+suffix,sample+suffix)
for suffix in ['.bed','.boolean.txt','.annotatePeaks.txt','.boolean.annotatePeaks.txt']:copy(prefix+'consensus/SPT5/SPT5.consensus_peaks'+suffix,'consensus'+suffix)
for name in ['macs_peak.summary.txt','macs_annotatePeaks.summary.txt','macs_annotatePeaks.summary_mqc.tsv']:
 copy(prefix+'qc/'+name,name);p=out/name;print('TABLE',name);print('\n'.join(p.read_text().splitlines()[:5]))
for basename in ['genome.fa','genes.gtf']:
 entry=next(v for n,v in cap['roots'][0]['items'].items() if n.endswith('reference/'+basename) and v['kind']=='file');shutil.copyfile(a/'objects'/entry['original']['pin']['sha256'],out/basename);rows[basename]=entry['original']['pin']
(out/'SOURCE.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf8');print('Staged complete annotation inputs/results and source QC tables')
