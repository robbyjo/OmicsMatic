"""Second compiler build executing the unchanged captured source request/cache."""
from pathlib import Path
import json,subprocess,sys,time,hashlib
if sys.platform!='linux':raise SystemExit(subprocess.call(['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--exec','/usr/bin/python3','/mnt/d/projects/JLinAlg/build/literature-review/nfcore-runtime/resume_typed_chipseq121_control4.py']))
root=Path('/mnt/d/projects/JLinAlg');base=root/'build/literature-review/nfcore-runtime';out=base/'chipseq121-runner-control-4';out.mkdir();run=Path('/var/tmp/omicsmatic-nfcore-chipseq121-adapter-2');assert json.loads((run/'latest.json').read_text())==dict(attempt='000002',status='COMPLETED')
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
jar=base/'chipseq-runner-build25-3/nfcore-chipseq-development.jar';guard={str(p):pin(p) for p in [jar,run/'request.json',run/'engine-recipe.json']};command=['/usr/bin/java','-Xmx2048m','-XX:ActiveProcessorCount=4','-jar',str(jar),'--resume',str(run),'--home',str(root/'build/literature-review/nextflow-runtime/managed-setup-development-1/home-21-v2'),'--setup-report',str(base/'engine-host-recheck-1/report-21-v2')];save(out/'STARTED.json',dict(command=command,guards=guard,compiler=25,runtime='Linux Java21',scientific_parameters_changed=False,jvm_version=subprocess.run(['/usr/bin/java','-version'],capture_output=True,text=True).stderr));started=time.monotonic()
with (out/'stdout').open('xb') as so,(out/'stderr').open('xb') as se:r=subprocess.run(command,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=14400)
save(out/'process.json',dict(command=command,exit_code=r.returncode,elapsed_seconds=time.monotonic()-started));assert all(pin(Path(n))==v for n,v in guard.items());print('Compiler25 typed cache resume exit',r.returncode,flush=True);print((out/'stderr').read_text()[-3000:]);raise SystemExit(r.returncode)
