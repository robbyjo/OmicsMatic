from pathlib import Path
import json,hashlib,zipfile
b=Path('build/literature-review/nfcore-runtime');target=Path('src/test/resources/org/jlinalg/cli/nfcore-annotation411');target.mkdir(parents=True)
roots={'captured':b/'annotation-native-fixture-1','sparse':b/'annotation-sparse-original-1/fixture','unicode_versioned':b/'annotation-sparse-original-2/fixture'};payload={}
for case,root in roots.items():
 for path in sorted(root.iterdir()):
  if path.is_file() and path.suffix not in ['.pdf'] and path.name not in ['SOURCE.json']:
   payload[case+'/'+path.name]=path.read_bytes()
metadata=dict(profile='nf-core/chipseq1.2.1 HOMER4.11 R3.6.2',source_image=dict(bytes=1131143168,sha256='50bd3f475b82608dd305138dff30b4789973d930994a5f710a7e5dd8acbb1e38'),complete_captured_annotation_rows=4829,complete_captured_peaks=3357,complete_captured_consensus=1472,synthetic_cases=['sparse','unicode_versioned'],synthetic_annotation_rows_each=9,raw_transcripts_each=7,effective_gene_TSS_rows_each=6,overwritten_transcript_rows_each=1,original_source_rule='parseGTF emits sorted transcript IDs with gene-ID labels; original lookup keeps the last row per exact contig/gene ID. Raw rows stay retained; no gene-span merge.',source_absent_feature_categories='NA',source_plot_missing_distance='Unassigned in plotting copy only; raw annotation NA unchanged',scientific_result_admitted=False,files={n:dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()) for n,raw in payload.items()})
payload['SOURCE.json']=(json.dumps(metadata,indent=2,ensure_ascii=False)+'\n').encode();payload['ORIGINAL-nfcore-LICENSE']=(b/'deseq126-synthetic-original-1/ORIGINAL-LICENSE').read_bytes()
with zipfile.ZipFile(target/'reference.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,raw in sorted(payload.items()):
  info=zipfile.ZipInfo(name,(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,raw)
(target/'SOURCE.json').write_bytes(payload['SOURCE.json']);(target/'.gitattributes').write_bytes(b'* -text\n');print('Packaged complete original annotation/QC references',len(payload),(target/'reference.zip').stat().st_size)
