"""Fresh complete original source control through the typed Java workflow adapter; all prior attempts retained."""
from pathlib import Path
import json,subprocess,sys,time,hashlib,os
if sys.platform!='linux':raise SystemExit(subprocess.call(['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--exec','/usr/bin/python3','/mnt/d/projects/JLinAlg/build/literature-review/nfcore-runtime/run_typed_chipseq121_control2.py']))
root=Path('/mnt/d/projects/JLinAlg');base=root/'build/literature-review/nfcore-runtime';out=base/'chipseq121-runner-control-2';out.mkdir();prepared=Path('/var/tmp/omicsmatic-nfcore-chipseq121-prepared-2');runroot=Path('/var/tmp/omicsmatic-nfcore-chipseq121-adapter-2');assert not prepared.exists() and not runroot.exists()
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf8',newline='\n')
def pin(path):
 h=hashlib.sha256();n=0
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b);n+=len(b)
 return dict(bytes=n,sha256=h.hexdigest())
source=Path('/var/tmp/omicsmatic-nfcore-sources-1/chipseq-1.2.1');data=Path('/var/tmp/omicsmatic-nfcore-chipseq121-pcr-controls-1');reference=Path('/var/tmp/omicsmatic-nfcore-chipseq121-controls-1/reference');home=root/'build/literature-review/nextflow-runtime/managed-setup-development-1/home-21-v2';report=base/'engine-host-recheck-1/report-21-v2';jar=base/'chipseq-runner-build21-3/nfcore-chipseq-development.jar';before=pin(jar)
prep=['/usr/bin/python3',str(root/'tools/literature/prepare_nfcore_chipseq121.py'),'--workflow',str(source),'--data-root','/var/tmp','--design',str(data/'local-design.csv'),'--fasta',str(reference/'genome.fa'),'--gtf',str(reference/'genes.gtf'),'--macs-genome-size','1.2e7','--container-home','/var/tmp/omicsmatic-nfcore-apptainer-1','--image','/var/tmp/omicsmatic-nfcore-images-1/nfcore-chipseq-1.2.1.sif','--out',str(prepared),'--run-root',str(runroot),'--max-cpus','4','--executor-memory-bytes','25769803776','--max-memory','8.GB','--max-time','2.h']
with (out/'prepare.stdout').open('xb') as so,(out/'prepare.stderr').open('xb') as se:r=subprocess.run(prep,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=300)
save(out/'prepare.process.json',dict(command=prep,exit_code=r.returncode));assert r.returncode==0,(out/'prepare.stderr').read_text()[-2000:]
command=['/usr/bin/java','-Xmx2048m','-XX:ActiveProcessorCount=4','-jar',str(jar),'--request',str(prepared/'request.json'),'--home',str(home),'--setup-report',str(report),'--out',str(runroot)]
save(out/'STARTED.json',dict(command=command,artifact=before,prepared_root=str(prepared),run_root=str(runroot),full_input_reads_retained=True,additional_simulated_PCR_pairs_per_sample=16195,scientific_analysis_scope='Complete original source workflow control; no whole-paper or independent biological validation.'))
started=time.monotonic()
with (out/'stdout').open('xb') as so,(out/'stderr').open('xb') as se:r=subprocess.run(command,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=14400)
assert pin(jar)==before;save(out/'process.json',dict(command=command,exit_code=r.returncode,elapsed_seconds=time.monotonic()-started,artifact=before));print('Typed complete source adapter exit',r.returncode,flush=True);print((out/'stderr').read_text()[-2500:])
if r.returncode==0:
 verify=['/usr/bin/java','-Xmx2048m','-jar',str(jar),'--verify',str(runroot)]
 with (out/'verify.stdout').open('xb') as so,(out/'verify.stderr').open('xb') as se:check=subprocess.run(verify,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=1800)
 save(out/'verify.process.json',dict(command=verify,exit_code=check.returncode));assert check.returncode==0,(out/'verify.stderr').read_text()[-2000:];print('PASS complete source adapter and saved result verification',flush=True)
raise SystemExit(r.returncode)

