from pathlib import Path
import json,shutil,hashlib
b=Path('build/literature-review/nfcore-runtime');out=b/'annotation-qc-source-intake-1';out.mkdir();a=b/'scientific-cross-platform-2/original-complete-attempt';capture=json.loads((a/'capture.json').read_bytes());items=capture['roots'][0]['items'];rows={}
for name in ['plot_homer_annotatepeaks.r','plot_macs_qc.r']:
 identity=items['workflow/bin/'+name]['original']['pin'];source=a/'objects'/identity['sha256'];assert source.stat().st_size==identity['bytes'] and hashlib.sha256(source.read_bytes()).hexdigest()==identity['sha256'];shutil.copyfile(source,out/name);rows[name]=identity
 print('SOURCE',name)
 lines=source.read_text().splitlines()
 for i,line in enumerate(lines):
  if any(word in line for word in ['write.table','summary','Annotation','gsub(','grepl(','nrow(','width','quantile(','median(','mean(','min(','max(']):print(i+1,line.strip()[:240])
(out/'SOURCE.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf8')
