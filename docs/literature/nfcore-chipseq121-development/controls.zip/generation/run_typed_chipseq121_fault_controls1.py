"""Real missing-prerequisite and capacity controls; full source inputs retained, no admitted analysis."""
from pathlib import Path
import json,subprocess,sys,time,hashlib
if sys.platform!='linux':raise SystemExit(subprocess.call(['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--exec','/usr/bin/python3','/mnt/d/projects/JLinAlg/build/literature-review/nfcore-runtime/run_typed_chipseq121_fault_controls1.py']))
root=Path('/mnt/d/projects/JLinAlg');base=root/'build/literature-review/nfcore-runtime';out=base/'chipseq121-runtime-fault-controls-1';out.mkdir();original=json.loads((base/'chipseq121-runner-control-2/prepare.process.json').read_text())['command'];checks=[]
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
for name,expected in [('missing_container_home',3),('workspace_capacity',2)]:
 case=out/name;case.mkdir();prepared=Path('/var/tmp/omicsmatic-nfcore-chipseq121-fault-prepared-'+name+'-1');run=Path('/var/tmp/omicsmatic-nfcore-chipseq121-fault-'+name+'-1');assert not prepared.exists() and not run.exists();cmd=list(original)
 for flag,value in [('--out',str(prepared)),('--run-root',str(run))]:cmd[cmd.index(flag)+1]=value
 if expected==3:cmd[cmd.index('--container-home')+1]='/var/tmp/omicsmatic-deliberately-absent-container-home-1';assert not Path(cmd[cmd.index('--container-home')+1]).exists()
 else:
  limit=case/'limits.json';save(limit,dict(workspace_bytes=16384));cmd+=['--limits',str(limit)]
 with (case/'prepare.stdout').open('xb') as so,(case/'prepare.stderr').open('xb') as se:r=subprocess.run(cmd,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=300)
 save(case/'prepare.process.json',dict(command=cmd,exit_code=r.returncode));assert r.returncode==0,(case/'prepare.stderr').read_text()
 jar=base/'chipseq-runner-build21-5/nfcore-chipseq-development.jar';cmd=['/usr/bin/java','-Xmx2048m','-XX:ActiveProcessorCount=4','-jar',str(jar),'--request',str(prepared/'request.json'),'--home',str(root/'build/literature-review/nextflow-runtime/managed-setup-development-1/home-21-v2'),'--setup-report',str(base/'engine-host-recheck-1/report-21-v2'),'--out',str(run)]
 with (case/'stdout').open('xb') as so,(case/'stderr').open('xb') as se:r=subprocess.run(cmd,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=600)
 save(case/'process.json',dict(command=cmd,exit_code=r.returncode));assert r.returncode==expected,(name,r.returncode,(case/'stderr').read_text());latest=json.loads((run/'latest.json').read_text());assert latest==dict(attempt='000001',status='SKIP3' if expected==3 else 'FAIL2');assert not any((run/'results').iterdir());failure=json.loads((run/'attempts/000001/FAILURE.json').read_text());assert 'Required action' in failure['required_action'];save(case/'FAILURE.json',failure);save(case/'latest.json',latest)
 checks.append(dict(case=name,exit_code=expected,passed=True,run_root=str(run),no_adapter_result=True,dependency_install_attempted=False));print(name,'PASS expected',expected,flush=True)
save(out/'COMPLETED.json',dict(status='PASS_TYPED_RUNTIME_FAULT_CONTROLS_ONLY',checks=checks,new_tool_credit=0,biological_accuracy_certified=False))
