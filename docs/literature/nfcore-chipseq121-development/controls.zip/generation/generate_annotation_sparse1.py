from pathlib import Path
import json,subprocess,sys,shutil
sys.path.insert(0,str(Path('tools/literature').resolve()))
from setup_deseq2_reference import ROOT,pin,save
from validate_nfcore_engine import BASE,DISTRO,linux
out=BASE/'annotation-sparse-original-1';out.mkdir();fixture=out/'fixture';fixture.mkdir();(fixture/'case.properties').write_text('include-consensus=false\n',encoding='utf8')
(fixture/'genome.fa').write_text(''.join('>'+c+'\n'+'A'*30000+'\n' for c in ['chr1','chr2','chr3']),encoding='ascii')
genes=[('chr1',100,200,'+','GeneA','TxA1'),('chr1',10000,10200,'+','GeneA','TxA2'),('chr1',5000,5200,'-','GeneB','TxB'),('chr1',1000,1100,'+','GeneE','TxE'),('chr1',1900,2000,'-','GeneF','TxF'),('chr1',20000,25000,'+','GeneR','TxR'),('chr2',500,600,'.','GeneD','TxD')]
(fixture/'genes.gtf').write_text('\n'.join('\t'.join(map(str,[c,'synthetic','exon',s,e,'.',strand,'.',f'gene_id "{g}"; transcript_id "{t}"; gene_name "{g}"; gene_type "protein_coding";'])) for c,s,e,strand,g,t in genes)+'\n',encoding='utf8',newline='\n')
samples=['SPT5_T0_R1','SPT5_T0_R2','SPT5_T15_R1','SPT5_T15_R2'];positions=[ [('chr1',9990,10030),('chr1',1490,1509),('chr3',100,200)],[('chr1',95,115),('chr2',490,510)],[('chr1',5170,5190),('chr1',23000,23030)],[('chr3',2000,2050),('chr3',5000,5050)]]
for sample,peaks in zip(samples,positions):
 (fixture/(sample+'_peaks.broadPeak')).write_text('\n'.join('\t'.join(map(str,[c,s,e,sample+'_peak_'+str(i+1),100+i,'.',1.1+i*.1,2.3+i*.2,1.2+i*.3])) for i,(c,s,e) in enumerate(peaks))+'\n',encoding='utf8',newline='\n')
source=BASE/'annotation-qc-source-intake-1';shutil.copyfile(source/'plot_homer_annotatepeaks.r',out/'plot_homer_annotatepeaks.r');shutil.copyfile(source/'plot_macs_qc.r',out/'plot_macs_qc.r')
base=['wsl.exe','-d',DISTRO,'--exec','/var/tmp/omicsmatic-nfcore-apptainer-1/bin/apptainer','exec','--userns','--no-home','--pid','-B',linux(ROOT)+':'+linux(ROOT),'/var/tmp/omicsmatic-nfcore-images-1/nfcore-chipseq-1.2.1.sif']
def run(label,cmd,target=None):
 with (target or out/(label+'.stdout')).open('xb') as so,(out/(label+'.stderr')).open('xb') as se:r=subprocess.run(cmd,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=180)
 save(out/(label+'.process.json'),dict(command=cmd,exit_code=r.returncode));assert r.returncode==0,(out/(label+'.stderr')).read_bytes()[-1500:]
for sample in samples:run(sample,base+['annotatePeaks.pl',linux(fixture/(sample+'_peaks.broadPeak')),linux(fixture/'genome.fa'),'-gid','-gtf',linux(fixture/'genes.gtf'),'-cpu','2'],fixture/(sample+'_peaks.annotatePeaks.txt'))
run('features',base+['Rscript','--vanilla',linux(out/'plot_homer_annotatepeaks.r'),'-i',','.join(linux(fixture/(s+'_peaks.annotatePeaks.txt')) for s in samples),'-s',','.join(samples),'-o',linux(fixture),'-p','macs_annotatePeaks'])
run('peaks',base+['Rscript','--vanilla',linux(out/'plot_macs_qc.r'),'-i',','.join(linux(fixture/(s+'_peaks.broadPeak')) for s in samples),'-s',','.join(samples),'-o',linux(fixture),'-p','macs_peak'])
save(out/'COMPLETED.json',dict(status='PASS_COMPLETE_ORIGINAL_HOMER411_SPARSE_TRANSCRIPT_GENE_QC_CONTROL_ONLY',explicitly_synthetic=True,peaks=9,source_gene_transcripts=7,gene_ID_mode=True,multiple_transcript_TSSs_preserved=True,missing_GTF_contig_present=True,tied_gene_candidates_present=True,original_dot_strand_present=True,scientific_result_admitted=False,files={p.relative_to(out).as_posix():pin(p) for p in fixture.iterdir() if p.is_file()}));print('PASS original sparse annotation and QC control');print((fixture/'macs_annotatePeaks.summary.txt').read_text())
