from pathlib import Path
b=Path('build/literature-review/nfcore-runtime');source=b/'generate_annotation_sparse1.py';text=source.read_text().replace('annotation-sparse-original-1','annotation-sparse-original-2')
needle="(fixture/'genes.gtf').write_text("
insert="""# Explicit NEW synthetic version/Unicode/order control; preserve the first original control.
genes=[(c,s,e,d,g+'.2',('TxA_\\ue000.1' if t=='TxA1' else 'TxA_\\U0001f600.1' if t=='TxA2' else t+'.3')) for c,s,e,d,g,t in reversed(genes)]
"""
assert needle in text;text=text.replace(needle,insert+needle);target=b/'generate_annotation_sparse2.py';assert not target.exists();target.write_text(text,encoding='utf8',newline='\n');print('Prepared separate versioned/Unicode/reversed-input original control')
