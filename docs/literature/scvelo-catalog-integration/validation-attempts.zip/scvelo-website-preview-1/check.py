from pathlib import Path
import sys,json,subprocess,shutil,zipfile,os,time,hashlib
ROOT=Path('D:/projects/JLinAlg');BASE=ROOT/'build/literature-review/monocle-runtime';OUT=Path(__file__).resolve().parent;CHECKOUT=BASE/'palette-allelic-validation-1/checkout';sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'tools/literature'));from scvelo_catalog.model import *
before={name:(ROOT/name).read_bytes() for name in META};after=transition(ROOT,before)
paths=list(META)+[GUIDE,'docs/literature/SCVELO024025_DEVELOPMENT.md']
with zipfile.ZipFile(OUT/'rolling-checkout-before.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
 for name in paths:
  if (CHECKOUT/name).is_file():z.writestr(name,(CHECKOUT/name).read_bytes())
for name in paths:
 target=CHECKOUT/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(after[name] if name in after else (ROOT/name).read_bytes())
for source in (ROOT/WORKFLOW).rglob('*'):
 relative=source.relative_to(ROOT);target=CHECKOUT/relative
 if source.is_file():
  target.parent.mkdir(parents=True,exist_ok=True)
  if target.exists():
   if pin(target)!=pin(source):raise ValueError('Existing rolling-checkout evidence differs; preserve and reconcile')
  else:shutil.copyfile(source,target)
env=dict(os.environ,JAVA_HOME='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot');cmd=[str(CHECKOUT/'gradlew.bat'),'checkWebsite','--no-daemon','--no-parallel','--no-configuration-cache','--max-workers=2','--console=plain'];start=time.time()
with (OUT/'website.log').open('xb') as f:p=subprocess.run(cmd,cwd=CHECKOUT,env=env,stdout=f,stderr=subprocess.STDOUT)
proof=dict(status='PASS_ISOLATED_EXACT_SCVELO_PREVIEW_WEBSITE_CHECK' if p.returncode==0 else 'FAIL2_ISOLATED_WEBSITE_PREVIEW_UNADMITTED',command=cmd,exit_code=p.returncode,elapsed_seconds=time.time()-start,checkout=str(CHECKOUT),after_files={n:rawpin(v) for n,v in after.items()},main_worktree_Gradle_run=False,new_tool_credit=0)
(OUT/('COMPLETED.json' if p.returncode==0 else 'FAILURE.json')).write_bytes(encoded(proof));print((OUT/'website.log').read_text(encoding='utf8',errors='replace')[-1300:]);raise SystemExit(p.returncode)
