from pathlib import Path
import http.server,threading,urllib.parse,subprocess,sys,json,concurrent.futures,time,hashlib
ROOT=Path('D:/projects/JLinAlg');BASE=ROOT/'build/literature-review/monocle-runtime';OUT=Path(__file__).resolve().parent;PREVIEW=BASE/'scvelo-catalog-preview-1';old=json.loads((BASE/'ggpubr-catalog-validation-1/PROCESSES.json').read_bytes());node=next(x['command'][0] for x in old if x['label']=='browser-ui')
processes=[]
def run(label,command):
 start=time.time()
 with (OUT/(label+'.stdout')).open('xb') as so,(OUT/(label+'.stderr')).open('xb') as se:child=subprocess.run(list(map(str,command)),cwd=ROOT,stdout=so,stderr=se)
 result=dict(label=label,command=list(map(str,command)),exit_code=child.returncode,elapsed_seconds=time.time()-start);processes.append(result);(OUT/(label+'-PROCESS.json')).write_text(json.dumps(result,indent=2),encoding='utf8');return result
class Handler(http.server.SimpleHTTPRequestHandler):
 def __init__(self,*args,**kwargs):super().__init__(*args,directory=str(ROOT/'site'),**kwargs)
 def translate_path(self,path):
  name=urllib.parse.urlsplit(path).path
  if name in ['/literature-review.html','/literature-warnings.html']:return str(PREVIEW/name.lstrip('/'))
  return super().translate_path(path)
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();url='http://127.0.0.1:'+str(server.server_port)
try:
 commands=[('boundary-tests',[sys.executable,'-B',ROOT/'tools/literature/scvelo_catalog/test_catalog.py']),('browser-ui',[node,ROOT/'tools/literature/scvelo_catalog/check_ui.cjs','C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules','C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',OUT/'ui',url])]
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(lambda x:run(*x),commands))
 (OUT/'PROCESSES.json').write_text(json.dumps(processes,indent=2),encoding='utf8')
 summary=dict(status='PASS_PRE_ADMISSION_BOUNDARIES_AND_EXACT_RENDERED_PREVIEW' if all(x['exit_code']==0 for x in results) else 'FAIL2_PRE_ADMISSION_PREVIEW_UNADMITTED',processes=results,preview={n:{'bytes':len((PREVIEW/n).read_bytes()),'sha256':hashlib.sha256((PREVIEW/n).read_bytes()).hexdigest()} for n in ['literature-review.html','literature-warnings.html']},current_catalog_changed=False,new_tool_credit=0,whole_goal_complete=False)
 (OUT/('COMPLETED.json' if summary['status'].startswith('PASS') else 'FAILURE.json')).write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary),flush=True);raise SystemExit(0 if summary['status'].startswith('PASS') else 2)
finally:server.shutdown();server.server_close();thread.join(timeout=5)
