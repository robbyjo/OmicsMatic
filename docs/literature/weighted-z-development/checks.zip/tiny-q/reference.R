options(digits=17)
args<-commandArgs(TRUE)
cases<-read.delim(args[1],stringsAsFactors=FALSE)
out<-file(args[2],"wt");writeLines("case\tfield\tvalue",out)
for(i in seq_len(nrow(cases))){
 z<-as.numeric(strsplit(cases$values[i],",",fixed=TRUE)[[1]])
 n<-as.numeric(strsplit(cases$weights[i],",",fixed=TRUE)[[1]])
 coefficient<-sqrt(n)/sqrt(sum(n)); combined<-sum(coefficient*z)
 q<-sum((z-coefficient*combined)^2);df<-length(z)-1
 values<-c(z=combined,heterogeneityQ=q,heterogeneityDegreesOfFreedom=df,
 heterogeneityPValue=pchisq(q,df,lower.tail=FALSE),
 heterogeneityLogPValue=pchisq(q,df,lower.tail=FALSE,log.p=TRUE))
 for(name in names(values))writeLines(paste(cases$id[i],name,format(values[[name]],digits=17,scientific=TRUE),sep="\t"),out)
}
close(out)
