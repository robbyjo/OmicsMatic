from pathlib import Path
import json,hashlib
a=Path('D:/projects/JLinAlg/build/high-impact-stats-1');rows={}
for n in ['src/main/java/org/jlinalg/meta/SampleSizeWeightedMetaAnalysis.java','src/test/java/org/jlinalg/meta/SampleSizeWeightedMetaAnalysisTest.java','src/test/resources/org/jlinalg/meta/sample-size-weighted-z/.gitattributes']:
 p=a/n;old=p.read_bytes();new=old.replace(b'\r\n',b'\n');p.write_bytes(new);rows[n]=dict(before=dict(bytes=len(old),sha256=hashlib.sha256(old).hexdigest()),after=dict(bytes=len(new),sha256=hashlib.sha256(new).hexdigest()),change='Git-declared LF line endings only; no scientific source/token change.')
(a/'build/metal-1/LINE-ENDINGS.json').write_bytes((json.dumps(rows,indent=2)+'\n').encode())
p=Path('D:/projects/JLinAlg/build/weighted_z_portable_20261118.py');code=p.read_text(encoding='utf-8').replace("out=a/'build/metal-1/weighted-z-portable-1'","out=a/'build/metal-1/weighted-z-portable-2'");exec(compile(code,str(p)+'-LF','exec'))
