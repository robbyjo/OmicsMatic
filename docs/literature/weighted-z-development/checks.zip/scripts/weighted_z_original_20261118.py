from pathlib import Path
import json,csv,math,subprocess,hashlib,time
a=Path('D:/projects/JLinAlg/build/high-impact-stats-1');out=a/'build/metal-1/weighted-z-original-1';out.mkdir();binary=a/'build/metal-1/build-original-1/native-build/bin/metal';distro='JLinAlg-Omics-SAIGE-20261026'
def save(p,v):p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
def pin(p):
 with Path(p).open('rb') as f:return dict(bytes=Path(p).stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
def linux(p):p=Path(p).absolute();return '/mnt/'+p.drive[0].lower()+'/'+p.as_posix()[3:]
def run(name,folder,script):
 (folder/'analysis.metal').write_bytes(script.encode('ascii'));cmd=['wsl','-d',distro,'--cd',linux(folder),'--exec',linux(binary),'analysis.metal'];save(out/(name+'.command.json'),cmd);start=time.monotonic()
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:p=subprocess.run(cmd,cwd=a,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=120)
 save(out/(name+'.PROCESS.json'),dict(exit_code=p.returncode,seconds=time.monotonic()-start));assert p.returncode==0,(name,p.returncode)
 print(name,(out/(name+'.stdout')).read_text(errors='replace')[-2200:],flush=True)
with (a/'build/metal-1/weighted-z-reference-2/cases.tsv').open(newline='') as f:cases=list(csv.DictReader(f,delimiter='\t'))
selected=[];omitted=[];inputs=[]
for c in cases:
 reason=None
 if c['expected']!='finite':reason='Native complete-model refusal is not an original-runtime finite-result comparator.'
 elif c['mode']=='logp':reason='Native finite natural-log-P input; this original METAL version has no corresponding log-P input declaration.'
 elif c['id'] in ['underflow','P001','unequal']:reason={'underflow':'Individual two-sided P underflows before original METAL input; distinct input-capability boundary.','P001':'Smallest-subnormal P is tested separately at the original-runtime boundary.','unequal':'Extreme sub-unit weights and round-to-one P require a separate source-behavior control.'}[c['id']]
 if reason:omitted.append(dict(id=c['id'],reason=reason));continue
 values=[float(v) for v in c['values'].split(',')];weights=[float(v) for v in c['weights'].split(',')];signs=[float(v) for v in c['directions'].split(',')] if c['mode']=='p' else [1 if v>=0 else -1 for v in values]
 ps=values if c['mode']=='p' else [math.erfc(abs(v)/math.sqrt(2)) for v in values];assert all(0<p<=1 for p in ps)
 selected.append(c['id']);inputs.append(dict(id=c['id'],p=ps,sign=signs,weights=weights,source_input_conversion='literal input P' if c['mode']=='p' else 'Python math.erfc(abs(signed_Z)/sqrt(2)); original API result compared with declared rounding tolerance'))
assert len(selected)==62,(len(selected),omitted)
for log in [False,True]:
 name='ordinary-log-output' if log else 'ordinary-p-output';folder=out/name;folder.mkdir()
 for i in range(9):
  lines=['MARKER ALLELE1 ALLELE2 EFFECT PVALUE N']
  for c in inputs:
   if i<len(c['p']):lines.append(f"{c['id']} A C {int(c['sign'][i])} {c['p'][i]:.17g} {c['weights'][i]:.17g}")
  (folder/f'study{i+1}.tsv').write_bytes(('\n'.join(lines)+'\n').encode())
 script='SCHEME SAMPLESIZE\nSEPARATOR WHITESPACE\nCOLUMNCOUNTING STRICT\nMARKERLABEL MARKER\nALLELELABELS ALLELE1 ALLELE2\nEFFECTLABEL EFFECT\nPVALUELABEL PVALUE\nWEIGHTLABEL N\nGENOMICCONTROL OFF\nOVERLAP OFF\nMINWEIGHT 0\nLOGPVALUE '+('ON' if log else 'OFF')+'\n'+''.join(f'PROCESSFILE study{i+1}.tsv\n' for i in range(9))+'OUTFILE result .tbl\nANALYZE HETEROGENEITY\nQUIT\n'
 run(name,folder,script)
edge=out/'boundary';edge.mkdir()
rows=[('P_ZERO','0','1','100'),('P_SUBNORMAL','4.9406564584124654e-324','1','100'),('P_TINY','1e-300','1','100'),('P_ONE','1','1','100'),('EFFECT_ZERO','.05','0','100'),('N_TINY','.05','1','1e-200'),('P_NEGATIVE','-.5','1','100'),('P_NAN','NaN','1','100')]
(edge/'study1.tsv').write_bytes(('MARKER ALLELE1 ALLELE2 EFFECT PVALUE N\n'+'\n'.join(f'{m} A C {effect} {p} {w}' for m,p,effect,w in rows)+'\n').encode())
run('boundary',edge,'SCHEME SAMPLESIZE\nMINWEIGHT 0\nLOGPVALUE ON\nPROCESSFILE study1.tsv\nOUTFILE result .tbl\nANALYZE HETEROGENEITY\nQUIT\n')
save(out/'CONTROL-INTAKE.json',dict(status='ORIGINAL_RUNTIME_CONTROLS_EXECUTED_PENDING_NUMERICAL_COMPARISON',release='2020-05-05',commit='e2253cc3901df8403a331bd725d4d9fe1edfb19f',binary=pin(binary),source_modified=False,ordinary_models=selected,ordinary_model_inputs=inputs,nonordinary_or_not_applicable_cases=omitted,all_native_fixture_models_accounted_for=len(selected)+len(omitted),original_source_binary_or_examples_redistributed=False))
for folder in [out/'ordinary-p-output',out/'ordinary-log-output',edge]:
 for p in folder.glob('result*.tbl'):print('TABLE',p.name,p.read_text()[:2500],flush=True)
