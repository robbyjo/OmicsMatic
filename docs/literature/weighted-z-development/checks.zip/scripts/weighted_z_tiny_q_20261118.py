from pathlib import Path
import subprocess,json,math,csv,hashlib,time
a=Path('D:/projects/JLinAlg/build/high-impact-stats-1');out=a/'build/metal-1/weighted-z-tiny-q-1';out.mkdir();distro='JLinAlg-Omics-SAIGE-20261026';jar=a/'build/metal-1/weighted-z-build-2/jar/omicsmatic-0.4.0.jar';binary=a/'build/metal-1/build-original-1/native-build/bin/metal';R=Path('C:/Program Files/R/R-4.6.1/bin/Rscript.exe')
def save(p,v):p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
def linux(p):p=Path(p).absolute();return '/mnt/'+p.drive[0].lower()+'/'+p.as_posix()[3:]
def run(label,cmd):
 save(out/(label+'.command.json'),cmd);start=time.monotonic()
 with (out/(label+'.stdout')).open('xb') as so,(out/(label+'.stderr')).open('xb') as se:p=subprocess.run(cmd,cwd=a,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=120)
 save(out/(label+'.PROCESS.json'),dict(exit_code=p.returncode,seconds=time.monotonic()-start));assert p.returncode==0,label
cases=[('SMALL_Q',1.0002),('ABOVE_Q',1.002)]
(out/'cases.tsv').write_bytes(('id\tmode\tvalues\tdirections\tweights\texpected\n'+''.join(f'{name}\tz\t1,{other:.17g}\t\t100,100\tfinite\n' for name,other in cases)).encode())
script='''options(digits=17)
args<-commandArgs(TRUE)
cases<-read.delim(args[1],stringsAsFactors=FALSE)
out<-file(args[2],"wt");writeLines("case\\tfield\\tvalue",out)
for(i in seq_len(nrow(cases))){
 z<-as.numeric(strsplit(cases$values[i],",",fixed=TRUE)[[1]])
 n<-as.numeric(strsplit(cases$weights[i],",",fixed=TRUE)[[1]])
 coefficient<-sqrt(n)/sqrt(sum(n)); combined<-sum(coefficient*z)
 q<-sum((z-coefficient*combined)^2);df<-length(z)-1
 values<-c(z=combined,heterogeneityQ=q,heterogeneityDegreesOfFreedom=df,
 heterogeneityPValue=pchisq(q,df,lower.tail=FALSE),
 heterogeneityLogPValue=pchisq(q,df,lower.tail=FALSE,log.p=TRUE))
 for(name in names(values))writeLines(paste(cases$id[i],name,format(values[[name]],digits=17,scientific=TRUE),sep="\\t"),out)
}
close(out)
'''
(out/'reference.R').write_bytes(script.encode());run('R-reference',[str(R),'--vanilla',str(out/'reference.R'),str(out/'cases.tsv'),str(out/'expected.tsv')])
for platform in ['windows','linux']:
 classes=a/f'build/metal-1/weighted-z-portable-1/{platform}-classes'
 java=['C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe'] if platform=='windows' else ['wsl','-d',distro,'--exec','/usr/bin/java'];fmt=str if platform=='windows' else linux;sep=';' if platform=='windows' else ':'
 run(platform+'-probe',java+['-cp',sep.join([fmt(jar),fmt(classes)]),'org.jlinalg.meta.Probe',fmt(out/'cases.tsv'),fmt(out/(platform+'-models'))])
for name in ['SMALL_Q.tsv','ABOVE_Q.tsv','COMPLETED.properties']:assert (out/'windows-models'/name).read_bytes()==(out/'linux-models'/name).read_bytes()
with (out/'expected.tsv').open(newline='') as f:expected=list(csv.DictReader(f,delimiter='\t'))
for e in expected:
 with (out/'windows-models'/(e['case']+'.tsv')).open(newline='') as f:actual={r['field']:r['value'] for r in csv.DictReader(f,delimiter='\t')}
 assert math.isclose(float(actual[e['field']]),float(e['value']),rel_tol=5e-11,abs_tol=1e-18),(e,actual[e['field']])
for i in range(2):
 rows=['MARKER ALLELE1 ALLELE2 EFFECT PVALUE N']
 for name,other in cases:
  z=1 if i==0 else other;rows.append(f'{name} A C 1 {math.erfc(z/math.sqrt(2)):.17g} 100')
 (out/f'study{i+1}.tsv').write_bytes(('\n'.join(rows)+'\n').encode())
(out/'analysis.metal').write_bytes(b'SCHEME SAMPLESIZE\nMINWEIGHT 0\nGENOMICCONTROL OFF\nOVERLAP OFF\nPROCESSFILE study1.tsv\nPROCESSFILE study2.tsv\nOUTFILE result .tbl\nANALYZE HETEROGENEITY\nQUIT\n')
run('original',['wsl','-d',distro,'--cd',linux(out),'--exec',linux(binary),'analysis.metal'])
with (out/'result1.tbl').open(newline='') as f:rows={r['MarkerName']:r for r in csv.DictReader(f,delimiter='\t')}
assert rows['SMALL_Q']['HetPVal']=='1';assert float(rows['ABOVE_Q']['HetPVal'])<1
with (out/'windows-models/SMALL_Q.tsv').open(newline='') as f:native={r['field']:r['value'] for r in csv.DictReader(f,delimiter='\t')}
assert float(native['heterogeneityPValue'])<.9999
summary=dict(status='PASS_RETAINED_TINY_Q_SOURCE_CONVENTION_DIFFERENCE',R_reference_models=2,R_reference_fields=len(expected),windows_linux_identical_payloads=3,source_rows=2,small_q_native_probability=native['heterogeneityPValue'],small_q_original_probability=rows['SMALL_Q']['HetPVal'],source_threshold='Original source sets heterogeneity P=1 below Q=1e-7; independent native method retains the ordinary chi-square tail.',whole_METAL_parity_claimed=False)
save(out/'COMPLETED.json',summary);print(json.dumps(summary,indent=2),flush=True)
