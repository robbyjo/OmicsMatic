from pathlib import Path
p=Path('D:/projects/JLinAlg/build/build_weighted_z_20261118.py')
code=p.read_text(encoding='utf-8').replace("weighted-z-build-1'","weighted-z-build-2'")
exec(compile(code,str(p)+'-qualification','exec'))
