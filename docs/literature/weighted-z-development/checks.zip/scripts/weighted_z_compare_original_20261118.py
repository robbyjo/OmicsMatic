from pathlib import Path
import json,csv,math
a=Path('D:/projects/JLinAlg/build/high-impact-stats-1');out=a/'build/metal-1/weighted-z-original-1';portable=a/'build/metal-1/weighted-z-portable-1/windows-models';intake=json.loads((out/'CONTROL-INTAKE.json').read_bytes());comparisons=[];differences=[]
def load(path):
 with path.open(newline='') as f:return list(csv.DictReader(f,delimiter='\t'))
def native(case):return {r['field']:r['value'] for r in load(portable/(case+'.tsv'))}
def check(case,mode,field,observed,expected,tolerance):
 assert math.isfinite(float(observed)) and math.isfinite(float(expected)),(case,field,observed,expected)
 delta=abs(float(observed)-float(expected));ok=delta<=tolerance
 comparisons.append(dict(case=case,mode=mode,field=field,observed=observed,expected=expected,tolerance=tolerance,absolute_error=delta,passed=ok));assert ok,(case,mode,field,observed,expected,tolerance,delta)
def four_sig(value):return .5*10**(math.floor(math.log10(abs(value)))-3) if value else 1e-14
for mode in ['ordinary-p-output','ordinary-log-output']:
 rows=load(out/mode/'result1.tbl');assert {r['MarkerName'] for r in rows}==set(intake['ordinary_models']) and len(rows)==62
 for r in rows:
  case=r['MarkerName'];n=native(case);source=next(c for c in intake['ordinary_model_inputs'] if c['id']==case);assert (r['Allele1'],r['Allele2'])==('a','c')
  direction=''.join('0' if p==1 else '+' if s>0 else '-' for p,s in zip(source['p'],source['sign']))+'?'*(9-len(source['p']));assert r['Direction']==direction,(case,r['Direction'],direction)
  for field,key,tol in [('Weight','totalWeight',.005000001),('Zscore','z',.000500001),('HetChiSq','heterogeneityQ',.000500001),('HetDf','heterogeneityDegreesOfFreedom',0)]:check(case,mode,field,r[field],float(n[key]),tol)
  df=int(n['heterogeneityDegreesOfFreedom']);check(case,mode,'HetISq',r['HetISq'],float(n['iSquaredPercent']) if df else 0,.050000001)
  if mode=='ordinary-p-output':
   expected=float(n['pValue']);check(case,mode,'P-value',r['P-value'],expected,four_sig(expected)+1e-12*abs(expected))
   if df:
    expected=float(n['heterogeneityPValue']);check(case,mode,'HetPVal',r['HetPVal'],expected,four_sig(expected)+1e-11*abs(expected))
   else:assert r['HetPVal']=='1';differences.append(dict(case=case,mode=mode,field='HetPVal',native='undefined/null',original='1',reason='Single-cohort source convention retained, not native inference.'))
  else:
   check(case,mode,'log(P)',r['log(P)'],float(n['logPValue'])/math.log(10),.005000001)
   if df:
    expected=float(n['heterogeneityLogPValue'])/math.log(10);check(case,mode,'logHetP',r['logHetP'],expected,four_sig(expected)+1e-10)
   else:assert r['logHetP']=='0';differences.append(dict(case=case,mode=mode,field='logHetP',native='undefined/null',original='0',reason='Single-cohort source convention retained, not native inference.'))
(out/'NUMERICAL-COMPARISONS.json').write_bytes((json.dumps(dict(status='PASS_62_ORIGINAL_MODELS_AT_BOTH_PRINTED_OUTPUT_BOUNDARIES',comparisons=comparisons,source_convention_differences=differences,changed_source_functions=False,original_output_rounding_explicit=True,source_rows_each_output=62,all_native_fixture_cases_accounted_for=intake['all_native_fixture_models_accounted_for']),indent=2)+'\n').encode())
boundary=load(out/'boundary/result1.tbl');assert len(boundary)==6;byid={r['MarkerName']:r for r in boundary};assert 'P_ZERO' not in byid and 'P_NEGATIVE' not in byid
assert any(not math.isfinite(float(byid['P_NAN'][f])) for f in ['Zscore','log(P)','HetChiSq'])
assert byid['EFFECT_ZERO']['Direction']=='+' and byid['P_SUBNORMAL']['Zscore']=='38.485'
(out/'BOUNDARY-ADMISSION.json').write_bytes((json.dumps(dict(status='FAIL2_ORIGINAL_BOUNDARY_RUN_NO_COMPLETE_RESULT',original_exit_code=0,original_result_rows=6,invalid_p_rows_omitted=['P_ZERO','P_NEGATIVE'],nonfinite_source_row='P_NAN',zero_effect_source_direction='positive',tiny_positive_weight_printed='0.00',native_policy='No omitted invalid cohort, nonfinite model or inferred direction is admitted. Finite log-P preserves underflow explicitly.',required_action='Retain these raw source outputs as failure evidence. Correct invalid inputs explicitly and retry a new analysis; never infer completion from exit zero. Future captured adapter must enforce this admission.'),indent=2)+'\n').encode())
print(json.dumps(dict(status='PASS_COMPARISON_WITH_RETAINED_ORIGINAL_FAILURE',ordinary_models=62,original_output_modes=2,numeric_fields=len(comparisons),single_cohort_source_convention_records=len(differences),boundary_status='FAIL2_NO_COMPLETE_RESULT'),indent=2))
