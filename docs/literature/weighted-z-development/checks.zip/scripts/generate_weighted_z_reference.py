from pathlib import Path
import random,json,subprocess,hashlib,zipfile,time
r=Path(__file__).resolve().parents[2];b=Path(__file__).resolve().parent;out=b/'weighted-z-reference-1';out.mkdir();rng=random.Random(20261118);cases=[]
for i in range(55):
 n=[1,2,3,5,9][i%5];z=[rng.uniform(-12,12) for _ in range(n)];w=[rng.choice([13.5,100,317,1000,10000,1000000])*rng.uniform(.5,1.5) for _ in range(n)];cases.append(dict(id='Z'+str(i).zfill(3),mode='z',values=z,directions=[],weights=w))
for name,z,w in [('zero',[0,0,0],[1,100,1e6]),('cancel',[2,-2],[25,25]),('homogeneous',[1,2,3],[100,400,900]),('underflow',[40,40],[100,100]),('tiny-weight',[1e308,0],[5e-324,1e308]),('unequal',[1e-100,-1e-100,1],[1e-200,1e-100,1])]:cases.append(dict(id=name,mode='z',values=z,directions=[],weights=w))
for i,values in enumerate([[1,.5,.01],[1e-100,1e-300,5e-324],[.3,.9],[1],[.05,.05,.05]]):cases.append(dict(id='P'+str(i).zfill(3),mode='p',values=values,directions=[1 if j%2==0 else -1 for j in range(len(values))],weights=[100*(j+1) for j in range(len(values))]))
for i,values in enumerate([[0,-1,-1000],[-10000,-20000],[-744.4400719213812],[-1e-30,-.1,-1]]):cases.append(dict(id='L'+str(i).zfill(3),mode='logp',values=values,directions=[-1 if j%2==0 else 1 for j in range(len(values))],weights=[100*(j+1) for j in range(len(values))]))
lines=['id\tmode\tvalues\tdirections\tweights']
for c in cases:lines.append('\t'.join([c['id'],c['mode'],','.join(map(repr,c['values'])),','.join(map(str,c['directions'])),','.join(map(repr,c['weights']))]))
(out/'cases.tsv').write_bytes(('\n'.join(lines)+'\n').encode());(out/'CASES.json').write_bytes((json.dumps(cases,indent=2)+'\n').encode())
script=out/'reference.R';script.write_bytes(b'''args <- commandArgs(trailingOnly=TRUE)
options(digits=17)
x <- read.delim(args[1], sep="\\t", check.names=FALSE, colClasses="character")
all <- data.frame(case=character(),field=character(),value=character())
for (row in seq_len(nrow(x))) {
 v <- as.double(strsplit(x$values[row], ",", fixed=TRUE)[[1]])
 w <- as.double(strsplit(x$weights[row], ",", fixed=TRUE)[[1]])
 d <- if (nchar(x$directions[row])) as.double(strsplit(x$directions[row], ",", fixed=TRUE)[[1]]) else numeric()
 z <- if(x$mode[row]=="z") v else d*qnorm((if(x$mode[row]=="p") log(v) else v)-log(2), lower.tail=FALSE,log.p=TRUE)
 total <- sum(w); a <- sqrt(w)/sqrt(total); contrib <- a*z; combined <- sum(contrib)
 lp <- log(2)+pnorm(abs(combined),lower.tail=FALSE,log.p=TRUE); p <- exp(lp)
 hc <- (z-a*combined)^2; Q <- sum(hc); df <- length(z)-1
 qlp <- if(df>0) pchisq(Q,df,lower.tail=FALSE,log.p=TRUE) else NA_real_
 qp <- if(df>0) exp(qlp) else NA_real_; i2 <- if(df>0) if(Q>df) 100*(1-df/Q) else 0 else NA_real_
 value <- c(studies=length(z),totalWeight=total,z=combined,pValue=p,logPValue=lp,pValueUnderflow=as.integer(p==0),heterogeneityQ=Q,heterogeneityDegreesOfFreedom=df,heterogeneityPValue=qp,heterogeneityLogPValue=qlp,heterogeneityPValueUnderflow=as.integer(!is.na(qp)&&qp==0),iSquaredPercent=i2)
 for (name in names(value)) all <- rbind(all,data.frame(case=x$id[row],field=name,value=if(is.na(value[name]))"NA" else sprintf("%.17g",value[name])))
 for (name in c("studyZ","squareRootFractionWeights","zContributions","heterogeneityContributions")) {
  a <- switch(name,studyZ=z,squareRootFractionWeights=sqrt(w)/sqrt(total),zContributions=contrib,heterogeneityContributions=hc)
  stopifnot(all(is.finite(a)))
  for (j in seq_along(a)) all <- rbind(all,data.frame(case=x$id[row],field=paste0(name,".",j-1),value=sprintf("%.17g",a[j])))
 }
}
write.table(all,args[2],sep="\\t",row.names=FALSE,col.names=TRUE,quote=FALSE,na="NA")
writeLines(c(R.version.string,paste0("models=",nrow(x)),paste0("fields=",nrow(all))),args[3])
''')
rexec=Path('C:/Program Files/R/R-4.6.1/bin/Rscript.exe');cmd=[str(rexec),'--vanilla',str(script),str(out/'cases.tsv'),str(out/'expected.tsv'),str(out/'versions.txt')];(out/'command.json').write_bytes((json.dumps(cmd,indent=2)+'\n').encode());start=time.monotonic()
with (out/'stdout').open('xb') as so,(out/'stderr').open('xb') as se:p=subprocess.run(cmd,cwd=r,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=300)
(out/'PROCESS.json').write_bytes((json.dumps(dict(exit_code=p.returncode,seconds=time.monotonic()-start),indent=2)+'\n').encode());assert p.returncode==0,(out/'stderr').read_text()
raw=(out/'expected.tsv').read_bytes();fields=len(raw.splitlines())-1;provenance=dict(status='PASS_INDEPENDENT_BASE_R_WEIGHTED_Z_REFERENCE',models=len(cases),fields=fields,R_version=(out/'versions.txt').read_text().splitlines()[0],Rscript=dict(bytes=rexec.stat().st_size,sha256=hashlib.sha256(rexec.read_bytes()).hexdigest()),script=dict(bytes=script.stat().st_size,sha256=hashlib.sha256(script.read_bytes()).hexdigest()),METAL_source_or_functions_used=False,seed=20261118);(out/'PROVENANCE.json').write_bytes((json.dumps(provenance,indent=2)+'\n').encode());dest=r/'src/test/resources/org/jlinalg/meta/sample-size-weighted-z';dest.mkdir(parents=True)
with zipfile.ZipFile(dest/'reference-fixtures.zip','x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name in ['cases.tsv','expected.tsv','versions.txt','reference.R','PROVENANCE.json']:z.writestr(name,(out/name).read_bytes())
(dest/'.gitattributes').write_bytes(b'*.zip -text\n');print(json.dumps(provenance,indent=2),flush=True)
