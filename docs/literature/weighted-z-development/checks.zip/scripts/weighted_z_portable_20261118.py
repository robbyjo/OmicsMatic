from pathlib import Path
import subprocess,json,hashlib,zipfile,os,time,shutil,xml.etree.ElementTree as ET
a=Path('D:/projects/JLinAlg/build/high-impact-stats-1');out=a/'build/metal-1/weighted-z-portable-1';out.mkdir();jar=a/'build/metal-1/weighted-z-build-2/jar/omicsmatic-0.4.0.jar';baseline=a/'build/ldsc-reference-cli-1/build-2/jar/omicsmatic-0.4.0.jar';junit=a/'build/nfcore-atacseq121-1/linux-test-runtime-1/junit-platform-console-standalone-1.13.4.jar';jdk=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin');distro='JLinAlg-Omics-SAIGE-20261026'
def save(p,v):p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
def pin(p):
 with Path(p).open('rb') as f:return dict(bytes=Path(p).stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
def linux(p):
 p=Path(p).absolute();return '/mnt/'+p.drive[0].lower()+'/'+p.as_posix()[3:]
def run(label,cmd):
 save(out/(label+'.command.json'),cmd);start=time.monotonic()
 with (out/(label+'.stdout')).open('xb') as so,(out/(label+'.stderr')).open('xb') as se:p=subprocess.run(cmd,cwd=a,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=300)
 save(out/(label+'.PROCESS.json'),dict(exit_code=p.returncode,seconds=time.monotonic()-start))
 if p.returncode:print(label,(out/(label+'.stderr')).read_text(encoding='utf-8',errors='replace')[-3500:],flush=True)
 assert p.returncode==0,label
sources=['src/main/java/org/jlinalg/meta/SampleSizeWeightedMetaAnalysis.java','src/test/java/org/jlinalg/meta/SampleSizeWeightedMetaAnalysisTest.java','src/test/resources/org/jlinalg/meta/sample-size-weighted-z/reference-fixtures.zip','tools/literature/weighted_z/Probe.java','examples/meta/SampleSizeWeightedMetaExample.java'];sourcepins={}
for n in sources:
 p=out/'sources'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(a/n,p);sourcepins[n]=pin(p)
save(out/'SOURCES.json',sourcepins)
save(out/'RUNTIMES.json',dict(jar=pin(jar),baseline=pin(baseline),junit=pin(junit)))
with zipfile.ZipFile(jar) as z,zipfile.ZipFile(baseline) as old:
 names=set(z.namelist());prior=set(old.namelist());removed=sorted(prior-names);added=sorted(names-prior);changed=[n for n in sorted(names&prior) if z.read(n)!=old.read(n)];assert not removed and not changed,(removed,changed)
 assert added and all(n.startswith('org/jlinalg/meta/SampleSizeWeightedMetaAnalysis') for n in added),added
 save(out/'JAR-BASELINE-COMPATIBILITY.json',dict(status='PASS_EVERY_PREEXISTING_JAR_MEMBER_UNCHANGED',shared_members=len(names&prior),added_members=added,changed_members=changed,removed_members=removed))
empty=out/'empty-sourcepath';empty.mkdir();cases=out/'cases.tsv';shutil.copyfile(a/'build/metal-1/weighted-z-reference-2/cases.tsv',cases)
compile_sources=[out/'sources'/n for n in [sources[1],sources[3],sources[4]]]
counts={}
for platform in ['windows','linux']:
 classes=out/(platform+'-classes');classes.mkdir();resource=classes/'org/jlinalg/meta/sample-size-weighted-z/reference-fixtures.zip';resource.parent.mkdir(parents=True);shutil.copyfile(a/sources[2],resource)
 if platform=='windows':
  java=[str(jdk/'java.exe')];javac=[str(jdk/'javac.exe')];fmt=str;sep=';'
 else:java=['wsl','-d',distro,'--exec','/usr/bin/java'];javac=['wsl','-d',distro,'--exec','/usr/bin/javac'];fmt=linux;sep=':'
 run(platform+'-java-version',java+['-version']);run(platform+'-javac-version',javac+['-version'])
 run(platform+'-compile',javac+['--release','17','--source-path',fmt(empty),'-cp',sep.join([fmt(jar),fmt(junit)]),'-d',fmt(classes),*[fmt(p) for p in compile_sources]])
 reports=out/(platform+'-junit-reports')
 run(platform+'-junit',java+['-jar',fmt(junit),'execute','--class-path',sep.join([fmt(jar),fmt(classes)]),'--select-class','org.jlinalg.meta.SampleSizeWeightedMetaAnalysisTest','--reports-dir',fmt(reports),'--disable-banner','--details','summary'])
 t=[ET.parse(p).getroot() for p in reports.glob('TEST-*.xml')];stats={k:sum(int(p.attrib.get(k,0)) for p in t) for k in ['tests','errors','failures','skipped']};assert stats==dict(tests=7,errors=0,failures=0,skipped=0),stats;counts[platform]=stats
 run(platform+'-probe',java+['-cp',sep.join([fmt(jar),fmt(classes)]),'org.jlinalg.meta.Probe',fmt(cases),fmt(out/(platform+'-models'))])
 run(platform+'-example',java+['-cp',sep.join([fmt(jar),fmt(classes)]),'SampleSizeWeightedMetaExample'])
models=out/'windows-models';other=out/'linux-models';files=sorted(p.name for p in models.iterdir());assert files==sorted(p.name for p in other.iterdir());assert len(files)==71
for n in files:assert (models/n).read_bytes()==(other/n).read_bytes(),n
win=(out/'windows-example.stdout').read_bytes();lin=(out/'linux-example.stdout').read_bytes();assert win.replace(b'\r\n',b'\n')==lin.replace(b'\r\n',b'\n')
result=dict(status='PASS_NATIVE_WEIGHTED_Z_PACKAGED_WINDOWS_LINUX',junit=counts,finite_models_each_platform=69,expected_unrepresentable_each_platform=1,byte_identical_complete_payloads=71,example_identical_after_console_line_endings=True,source_pins=sourcepins,jar=pin(jar),whole_METAL_tool_implemented=False,new_family_credit=0)
save(out/'COMPLETED.json',result);print(json.dumps({k:v for k,v in result.items() if k!='source_pins'},indent=2),flush=True)
