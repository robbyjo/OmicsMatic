
nextflow.enable.dsl=2
params.inputs=null
params.outdir=null
params.fail=false
params.ignore=false
params.empty=false

process COUNTS {
    tag { sample }
    input:
    tuple val(sample),path(sequence)
    output:
    tuple val(sample),path("${sample}.tsv")
    script:
    """
    awk 'BEGIN{n=0;gc=0} !/^>/{s=toupper(\$0);n+=length(s);gsub(/[^GC]/,"",s);gc+=length(s)} END{printf "%s\\t%d\\t%d\\n","$sample",n,gc}' "$sequence" > "${sample}.tsv"
    """
}

process GATHER {
    publishDir params.outdir,mode:'copy'
    errorStrategy 'retry'
    maxRetries 1
    input:
    path(tables)
    output:
    path 'counts.tsv'
    script:
    if(true) 'exit 7'
    else 'cat *.tsv | LC_ALL=C sort > counts.tsv'
}

workflow {
    if(!params.empty){
        samples=Channel.of(tuple('a',file(params.inputs+'/a.fa',checkIfExists:true)),tuple('b',file(params.inputs+'/b.fa',checkIfExists:true)),tuple('c',file(params.inputs+'/c.fa',checkIfExists:true)))
        COUNTS(samples)
        GATHER(COUNTS.out.map{sample,table -> table}.collect())
    }
}
