#!/bin/bash -ue
printf '%s\n' 'TTAA' > 'b.txt'
