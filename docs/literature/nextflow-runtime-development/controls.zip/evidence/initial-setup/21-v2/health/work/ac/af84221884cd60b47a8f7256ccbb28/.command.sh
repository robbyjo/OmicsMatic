#!/bin/bash -ue
cat *.txt | LC_ALL=C sort > result.txt
