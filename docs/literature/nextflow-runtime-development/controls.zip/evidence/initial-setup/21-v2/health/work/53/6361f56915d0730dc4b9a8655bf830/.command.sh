#!/bin/bash -ue
printf '%s\n' 'ACGT' > 'a.txt'
