from pathlib import Path
import hashlib,json,os,stat,subprocess,zipfile
B=Path('/mnt/d/projects/JLinAlg/build/literature-review/pal2nal-runtime/workflow-development-1');O=B/'public-cli-2'
jar=B/'package-4/omicsmatic-0.3.7-pal2nal-development.jar';request=O/'request-141.json'
parent=Path('/opt/omicsmatic-pal2nal-workflow-development-1');assert parent.parent.resolve()==Path('/opt')
if not parent.exists():parent.mkdir(mode=0o700)
assert parent.resolve()==parent and parent.is_dir()
root=parent/'linux-case-1';assert not root.exists()
runs=[]
for name,args in [('persistent-linux-analysis',['--recipe',str(request),'--out',str(root)]),('persistent-linux-verify',['--verify',str(root)])]:
 command=['/usr/bin/java','-Xmx128m','-jar',str(jar),'pal2nal-tools',*args]
 with (O/(name+'.stdout')).open('xb') as out,(O/(name+'.stderr')).open('xb') as err:p=subprocess.run(command,stdout=out,stderr=err,timeout=180)
 runs.append(dict(name=name,command=command,exit_code=p.returncode));assert p.returncode==0,name
assert root.is_dir() and (root/'COMPLETED.json').is_file()
target=O/'linux-result-persistent.zip';assert not target.exists();files=[]
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as archive:
 for path in sorted(root.rglob('*')):
  assert path.resolve()==path and not path.is_symlink()
  if path.is_file():
   attrs=path.stat();assert stat.S_ISREG(attrs.st_mode) and attrs.st_nlink==1 and attrs.st_size<=16777216
   archive.write(path,path.relative_to(root).as_posix());files.append(path.relative_to(root).as_posix())
assert len(files)>=20 and {'COMPLETED.json','manifest.json','cells.tsv','triplets.tsv','alignment.phy','rows.ndjson'}<=set(files)
record=dict(status='passed-persistent-Linux-workflow-and-complete-immediate-capture',runs=runs,persistent_root=str(root),files=len(files),archive_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),
 previous_tmp_capture='Historical /tmp result was absent at capture time; the cause is not inferred. Its empty ZIP is retained as failed evidence, not a complete result. This is a fresh explicitly labelled run.')
(O/'persistent-linux-summary.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
