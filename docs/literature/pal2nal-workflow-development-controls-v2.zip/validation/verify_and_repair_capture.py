from pathlib import Path,PurePosixPath
import hashlib,json,shutil,stat,subprocess,zipfile
R=Path('D:/projects/JLinAlg');O=R/'build/literature-review/pal2nal-runtime/workflow-development-1';P=O/'public-cli-2';D=R/'docs/literature'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
source=P/'linux-result-persistent.zip';raw=source.read_bytes();target=P/'linux-result-rehydrated';target.mkdir()
with zipfile.ZipFile(source) as archive:
 names=archive.namelist();assert len(names)==len(set(names))
 manifest=json.loads(archive.read('manifest.json'));assert set(names)==set(manifest['files'])|{'manifest.json','COMPLETED.json'}
 marker=json.loads(archive.read('COMPLETED.json'));assert marker['manifest_sha256']==sha(archive.read('manifest.json'))
 for info in archive.infolist():
  name=PurePosixPath(info.filename);assert not name.is_absolute() and '..' not in name.parts and '\\' not in info.filename and not info.is_dir()
  assert stat.S_IFMT(info.external_attr>>16) in {0,stat.S_IFREG}
  body=archive.read(info);path=(target/info.filename).resolve();assert path.is_relative_to(target.resolve());path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(body)
  if info.filename in manifest['files']:
   pin=manifest['files'][info.filename];assert pin['bytes']==len(body) and pin['sha256']==sha(body)
jar=O/'package-4/omicsmatic-0.3.7-pal2nal-development.jar'
cmd=['C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe','-Xmx128m','-jar',str(jar),'pal2nal-tools','--verify',str(target)]
with (P/'persistent-windows-verify.stdout').open('xb') as out,(P/'persistent-windows-verify.stderr').open('xb') as err:process=subprocess.run(cmd,cwd=R,stdout=out,stderr=err,timeout=180)
assert process.returncode==0,(P/'persistent-windows-verify.stderr').read_text(errors='replace')
recovery=dict(status='passed-exact-manifest-census-and-Windows-verification-of-persistent-Linux-case',files=len(names),manifest_files=len(manifest['files']),archive_sha256=sha(raw),Windows_verification_command=cmd,Windows_exit_code=process.returncode,
 persistent_root='/opt/omicsmatic-pal2nal-workflow-development-1/linux-case-1',
 retained_issues=[dict(case='/tmp/omicsmatic-pal2nal-public-workflow-2',issue='Original execution and verification receipts are retained, but the raw result directory was absent at the later capture attempt. Its cause is not inferred. The first capture incorrectly accepted an absent root and produced an empty ZIP; that ZIP is retained only as failed evidence.'),
  dict(case='persistent Linux capture',issue='The complete19-file archive was written, but a mistaken minimum20-file harness assertion failed. Exact manifest census validation shows17 declared members plus the manifest and completion marker, with no missing/extra files. No scientific rerun or data change was needed to validate this archive.')])
(P/'persistent-capture-recovery.json').write_text(json.dumps(recovery,indent=2)+'\n')

guide=D/'PAL2NAL_WORKFLOW.md';before=guide.read_bytes();backup=O/'guide-before-retention-note.md';assert not backup.exists();backup.write_bytes(before)
anchor='The output parent must exist and be canonical, and the result directory must be\nnew.'
text=before.decode();assert text.count(anchor)==1
text=text.replace(anchor,anchor+' Use persistent storage when evidence must be retained. Copy the whole bundle\nand verify the copy before treating archival capture as complete; volatile temporary\nlocations may be removed after a successful run.')
guide.write_text(text,encoding='utf-8',newline='\n')

report=D/'PAL2NAL_WORKFLOW_DEVELOPMENT_VALIDATION.json';before_report=report.read_bytes();backup=O/'report-before-capture-recovery.json';assert not backup.exists();backup.write_bytes(before_report)
record=json.loads(before_report);old=D/record['artifact']['path'];new=D/'pal2nal-workflow-development-controls-v2.zip';assert not new.exists()
with zipfile.ZipFile(old) as prior,zipfile.ZipFile(new,'w',zipfile.ZIP_DEFLATED) as archive:
 for info in prior.infolist():
  name=info.filename;body=prior.read(info)
  if name in {'public-cli-2/linux-result.zip','public-cli-2/linux-result.json'}:name='historical/failed-empty-capture/'+name.rsplit('/',1)[-1]
  if name=='source/docs/literature/PAL2NAL_WORKFLOW.md':body=guide.read_bytes()
  archive.writestr(name,body)
 for name in ['linux-result-persistent.zip','persistent-linux-analysis.stdout','persistent-linux-analysis.stderr','persistent-linux-verify.stdout','persistent-linux-verify.stderr','persistent-windows-verify.stdout','persistent-windows-verify.stderr','persistent-capture-recovery.json']:
  archive.write(P/name,'public-cli-2/'+name)
 archive.write(O/'capture_persistent_linux.py','validation/capture_persistent_linux.py')
 archive.write(Path(__file__),'validation/verify_and_repair_capture.py')
record['source_pins']['docs/literature/PAL2NAL_WORKFLOW.md']=dict(bytes=guide.stat().st_size,sha256=sha(guide.read_bytes()))
record['artifact']=dict(path=new.name,bytes=new.stat().st_size,sha256=sha(new.read_bytes()))
record['superseded_artifact']=dict(path=old.name,sha256=sha(old.read_bytes()),reason='Retains the empty historical /tmp capture; superseded by exact-census-checked persistent Linux capture.')
record['retention_warning']='Historical temporary Linux raw files were unavailable at later capture. Their command receipts and the failed empty capture remain retained. A fresh persistent Linux case is fully captured and independently verified on Windows. Do not label the fresh case as the original temporary run.'
record['capture_recovery']=recovery
record['direct_public_protocols'].pop('complete_Windows_and_Linux_result_bundles_retained',None)
record['direct_public_protocols']['complete_current_Windows_and_persistent_Linux_result_bundles_retained']=True
record['direct_public_protocols']['additional_persistent_Linux_analysis_and_verification']=2
record['direct_public_protocols']['additional_Windows_verification_of_rehydrated_Linux_case']=1
record['recorded_utc']=__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat()
for name,pin in record['source_pins'].items():assert sha((R/name).read_bytes())==pin['sha256'],name
report.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
closure=O/'workflow-closure.json';shutil.copy2(closure,O/'workflow-closure-before-capture-recovery.json');closure.write_text(json.dumps(record,indent=2)+'\n')
checkpoint=R/'build/literature-review/pal2nal-runtime/current-checkpoint.json';current=json.loads(checkpoint.read_bytes());current['capture_recovery']='passed-exact-manifest-census-and-cross-OS-native-recomputation';current['retention_warning']=record['retention_warning'];checkpoint.write_text(json.dumps(current,indent=2)+'\n')
print(json.dumps(dict(status=recovery['status'],files=len(names),source_pins=len(record['source_pins']),current_artifact=new.name,Windows_exit_code=0,retention_warning_retained=True)))
