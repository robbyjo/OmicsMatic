from pathlib import Path
import hashlib,json,os,shutil,subprocess,time,zipfile,xml.etree.ElementTree as ET

OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2]
def pin(path):return dict(bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
def save(name,value):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
def sources():
    selected=[]
    for pattern in ['src/main/java/org/jlinalg/cli/Pops*.java','src/main/java/org/jlinalg/genetics/Pops*.java','src/main/java/org/jlinalg/cli/JLinAlgCli.java','src/main/resources/org/jlinalg/omics/pops-original-v1/*','src/test/java/org/jlinalg/cli/PopsOriginal*.java','tools/literature/pops_original/*']:
        selected.extend(p for p in ROOT.glob(pattern) if p.is_file())
    return {p.relative_to(ROOT).as_posix():pin(p) for p in sorted(set(selected))}
before=sources();save('SOURCE-BEFORE.json',before)
with zipfile.ZipFile(OUT/'as-run-sources.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
    for name in before:z.writestr(name,(ROOT/name).read_bytes())
env=os.environ.copy();env['JAVA_HOME']='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot';env['PATH']=env['JAVA_HOME']+'/bin;'+env['PATH']
command=[str(ROOT/'gradlew.bat'),':test','--tests','org.jlinalg.cli.PopsOriginalContractTest','--tests','org.jlinalg.genetics.Pops*','--tests','org.jlinalg.cli.PopsWorkflow*','--tests','org.jlinalg.cli.JLinAlgCliTest','checkWebsite','executableJar','--no-daemon','--max-workers=2','--console=plain'];start=time.monotonic()
with (OUT/'stdout').open('xb') as so,(OUT/'stderr').open('xb') as se:p=subprocess.run(command,cwd=ROOT,env=env,stdout=so,stderr=se,timeout=900)
same=sources()==before;save('PROCESS.json',dict(command=command,exit_code=p.returncode,seconds=round(time.monotonic()-start,3),sources_unchanged=same))
assert p.returncode==0 and same,'Inspect retained build/test records'
counts=dict(tests=0,failures=0,errors=0,skipped=0);(OUT/'test-results').mkdir()
for path in sorted((ROOT/'build/test-results/test').glob('TEST-*.xml')):
    tree=ET.parse(path).getroot()
    for key in counts:counts[key]+=int(tree.attrib.get(key,0))
    shutil.copyfile(path,OUT/'test-results'/path.name)
assert counts['tests']>=269 and not counts['failures'] and not counts['errors'] and not counts['skipped'],counts
shutil.copyfile(ROOT/'build/cli/omicsmatic-0.4.0.jar',OUT/'candidate.jar')
with zipfile.ZipFile(OUT/'candidate.jar') as a,zipfile.ZipFile(ROOT/'build/pops-original/compile-2/candidate.jar') as b:
    assert a.namelist()==b.namelist();changed=[name for name in a.namelist() if a.read(name)!=b.read(name)]
    assert set(changed)=={'org/jlinalg/cli/PopsOriginalCli.class','org/jlinalg/cli/PopsOriginalRuntime.class'},changed
save('COMPLETED.json',dict(status='PASS_NEW_CONTRACT_CONTROLS_NATIVE_REGRESSIONS_AND_FROZEN_CANDIDATE',candidate=pin(OUT/'candidate.jar'),tests=counts,changed_existing_packaged_classes=changed,existing_scientific_implementations_unchanged=True,original_adapter_fully_qualified=False,whole_goal_complete=False))
print(json.dumps(dict(status='PASS_COMPILE_3',candidate=pin(OUT/'candidate.jar'),tests=counts,changed_classes=changed)),flush=True)
