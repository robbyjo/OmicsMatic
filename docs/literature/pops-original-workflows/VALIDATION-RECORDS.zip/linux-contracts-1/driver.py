from pathlib import Path
import hashlib,json,subprocess,time,zipfile

OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2]
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(name,value):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
old=json.loads((ROOT/'build/pops-workflow/linux-driver-2/PROCESS.json').read_bytes())['command'];cp=old[old.index('-cp')+1]
cp=cp.replace('/build/pops-workflow/java-workflow-2/candidate.jar','/build/pops-original/compile-3/candidate.jar')
source=ROOT/'tools/literature/pops_original/PopsOriginalJUnitReplay.java';before={source.relative_to(ROOT).as_posix():pin(source)}
classes=list((ROOT/'build/classes/java/test/org/jlinalg/cli').glob('PopsOriginalContractTest*.class'));assert classes
before.update({p.relative_to(ROOT).as_posix():pin(p) for p in classes});save('SOURCE-AND-CLASSES-BEFORE.json',before)
with zipfile.ZipFile(OUT/'as-run-test-classes.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
    for p in classes:z.writestr(p.relative_to(ROOT/'build/classes/java/test').as_posix(),p.read_bytes())
(OUT/'as-run-PopsOriginalJUnitReplay.java').write_bytes(source.read_bytes())
linux='/mnt/d/projects/JLinAlg/build/git-publish/20261115-all-main-4/checkout';command=['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--exec','/usr/bin/java','-Xmx512m','-cp',cp,linux+'/tools/literature/pops_original/PopsOriginalJUnitReplay.java',linux+'/build/pops-original/linux-contracts-1/results'];start=time.monotonic()
with (OUT/'stdout').open('xb') as so,(OUT/'stderr').open('xb') as se:p=subprocess.run(command,cwd=ROOT,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=120)
same=all(pin(ROOT/n)==value for n,value in before.items());save('PROCESS.json',dict(command=command,exit_code=p.returncode,seconds=round(time.monotonic()-start,3),sources_unchanged=same))
assert p.returncode==0 and same and (OUT/'results/COMPLETED.properties').is_file()
print(json.dumps(dict(status='PASS_LINUX_ORIGINAL_CONTRACTS',tests=32,failures=0,skipped=0)),flush=True)
