from pathlib import Path
from types import SimpleNamespace
import importlib.util,json,traceback,zipfile

ROOT=Path(__file__).resolve().parents[3]
spec=importlib.util.spec_from_file_location('original_adapter_qualification',ROOT/'tools/literature/pops_original/qualify_adapter.py');q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)
a=SimpleNamespace(suite='guide-example',jar=ROOT/'build/pops-original/compile-3/candidate.jar',runtime=ROOT/'build/pops-original/adopted-runtime-2',reference=ROOT/'build/pops-original/reference-1',out=Path(__file__).resolve().parent/'run')
s=q.Suite(a)
try:
    (s.out/'as-run-guide-example-driver.py').write_bytes(Path(__file__).read_bytes());inputs=s.out/'example-inputs';inputs.mkdir()
    with zipfile.ZipFile(ROOT/'examples/pops-workflow/synthetic-inputs.zip') as z:
        assert set(z.namelist())=={'NOTICE.txt','annotation.tsv','features.cols.0.txt','features.mat.0.npy','features.rows.txt','request.properties','scores.tsv'}
        for name in z.namelist():(inputs/name).write_bytes(z.read(name))
    fields=dict(edition='0.2',task='fit',gene_annotation=str(inputs/'annotation.tsv'),feature_prefix=str(inputs/'features'),feature_chunks='1',target_type='custom',scores=str(inputs/'scores.tsv'),method='ridge',genome_build='synthetic-no-biological-build',feature_set_id='synthetic-original-pops-control',target_source_id='synthetic-ridge-plain',java_heap_mb='512',python_address_space_mb='8192',wall_ms='900000',max_input_bytes='10000000',max_work_bytes='100000000',max_files='500')
    bundle=s.request('guide-example',fields);s.replay('guide-example-replay',bundle);report=json.loads((bundle/'audit/summary.json').read_bytes());s.complete(dict(example_archive='examples/pops-workflow/synthetic-inputs.zip',target_genes=report['target_genes'],prediction_genes=report['models'][0]['prediction_genes'],input_features=report['all_feature_count'],model_features=report['feature_selection_count'],genuine_replay=True,original_source_profile=True))
except Exception as error:
    q.save(s.out/'FAILURE.json',dict(reason=repr(error),traceback=traceback.format_exc(),processes=s.records));raise
