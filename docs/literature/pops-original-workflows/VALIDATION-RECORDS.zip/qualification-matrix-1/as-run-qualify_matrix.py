#!/usr/bin/env python3
# Copyright (C) 2026 JLinAlg contributors; SPDX-License-Identifier: GPL-3.0-or-later
"""Run all saved original ridge/OLS, selection and covariance-format controls."""
from pathlib import Path
import argparse,concurrent.futures,importlib.util,json,traceback

spec=importlib.util.spec_from_file_location('original_adapter_qualification',Path(__file__).with_name('qualify_adapter.py'))
q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--jar',type=Path,required=True);p.add_argument('--runtime',type=Path,required=True);p.add_argument('--reference',type=Path,required=True);p.add_argument('--prepared',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--workers',type=int,default=3);a=p.parse_args();s=None
    try:
        assert 1<=a.workers<=3;a.suite='original-profile-matrix';s=q.Suite(a);own_sha=q.sha(__file__);(s.out/'as-run-qualify_matrix.py').write_bytes(Path(__file__).read_bytes())
        prepared=a.prepared.resolve();names=json.loads((prepared/'CASES.json').read_bytes());assert len(names)==19 and len(names)==len(set(names))
        before={str(p):q.sha(p) for name in names for p in (prepared/name).iterdir() if p.is_file()};q.save(s.out/'INPUTS-AND-DIRECT-REFERENCES-BEFORE.json',before)
        def case(name):
            r=prepared/name;params=q.properties(r/'params.properties');cfg=dict(edition='0.2',task='fit',gene_annotation=str(r/'annotation.tsv'),feature_prefix=str(r/'features'),feature_chunks='1',method=params['method'],p_cutoff=params['cutoff'],max_selected_by_p=params['maximum'],forward_steps=params['forward'])
            if params['magma']=='true':cfg.update(target_type='magma',magma_prefix=str(r/'magma'))
            else:
                cfg.update(target_type='custom',scores=str(r/'scores.tsv'))
                if (r/'score-covariates.tsv').is_file():cfg['score_covariates']=str(r/'score-covariates.tsv')
                covariances=[p for p in [r/'error-covariance.npz',r/'error-covariance.npy'] if p.is_file()];assert len(covariances)<=1
                if covariances:cfg['error_covariance']=str(covariances[0])
            for key,filename in [('subset_features','subset.txt'),('control_features','controls.txt')]:
                if (r/filename).is_file():cfg[key]=str(r/filename)
            failure=params['expect_failure']=='true';bundle=s.request(name,cfg,2 if failure else 0)
            if failure:return dict(name=name,expected_source_failure=True,no_completion_marker=True)
            reports={}
            for suffix,dest in [('coefs','coefficients.tsv'),('preds','predictions.tsv'),('marginals','marginals.tsv')]:
                actual=bundle/'results'/dest;original=r/('original.'+suffix);identical=actual.read_bytes()==original.read_bytes()
                reports[dest]=dict(adapter_sha256=q.sha(actual),original_sha256=q.sha(original),byte_identical=identical)
                assert identical,(name,dest,'Source discrepancy retained; do not repair values or loosen checks silently')
            replay=name in ['ols-fss-gls','ridge-controls-subset','ridge-custom-gls']
            if replay:s.replay(name+'-replay',bundle)
            result=dict(name=name,expected_source_failure=False,direct_reports=reports,genuine_replay=replay);q.save(s.out/name/'DIRECT-COMPARISON.json',result);return result
        results=[]
        with concurrent.futures.ThreadPoolExecutor(max_workers=a.workers) as pool:
            futures={pool.submit(case,name):name for name in names}
            for future in concurrent.futures.as_completed(futures):results.append(future.result())
        assert q.sha(__file__)==own_sha and all(q.sha(path)==value for path,value in before.items())
        assert sum(r['expected_source_failure'] for r in results)==2
        s.records.sort(key=lambda r:r['name']);s.complete(dict(cases=sorted(results,key=lambda r:r['name']),successful_original_cases=17,expected_original_failures=2,source_reports_per_success=3,genuine_replays=3,whole_original_profile_matrix=True,subsampled=False));return 0
    except Exception as error:
        if s is not None:q.save(s.out/'FAILURE.json',dict(status='FAIL_ORIGINAL_PROFILE_MATRIX_QUALIFICATION',reason=repr(error),traceback=traceback.format_exc(),processes=s.records))
        traceback.print_exc();return 2

if __name__=='__main__':raise SystemExit(main())
