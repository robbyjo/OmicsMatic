from pathlib import Path
import sys,json,hashlib,warnings,math,importlib.metadata as md
import numpy as np,scanpy as sc,anndata as ad,scipy.sparse as sp
O=Path(sys.argv[1]);version=sys.argv[2];source=Path(sys.argv[3]);intake=json.loads(Path(sys.argv[4]).read_bytes());O.mkdir(exist_ok=False)
assert md.version('scanpy')==version
module=Path(sc.__file__).parent/'experimental/pp/_normalization.py';expected=intake['sources'][version]['source'];assert dict(bytes=module.stat().st_size,sha256=hashlib.sha256(module.read_bytes()).hexdigest())==expected
def number(value):
 value=float(value)
 return 'NaN' if math.isnan(value) else 'Infinity' if value==math.inf else '-Infinity' if value==-math.inf else value.hex()
def encoded(array):return [number(x) for x in np.asarray(array).ravel(order='C')]
def real(value):return float(value) if value is not None else None
fixture=json.loads(source.read_bytes());cases=[]
for matrix in fixture['matrices']:
 x=np.asarray(matrix['values'],dtype=np.float64);nc,nf=x.shape
 for storage in fixture['storages']:
  if storage=='dense':data=x.copy()
  elif storage=='csr':data=sp.csr_matrix(x)
  else:data=sp.csr_matrix((x.ravel().copy(),np.tile(np.arange(nf,dtype=np.int32),nc),np.arange(0,nc*nf+1,nf,dtype=np.int32)),shape=x.shape)
  if sp.issparse(data):g=np.asarray(np.sum(data,axis=0)).ravel();c=np.asarray(np.sum(data,axis=1)).ravel()
  else:g=np.sum(data,axis=0);c=np.sum(data,axis=1)
  with np.errstate(all='ignore'):total=np.sum(g)
  for i,options in enumerate(fixture['options']):
   theta=real(options['theta']);clip=real(options['clip']);a=ad.AnnData(data.copy());record=dict(id=matrix['id']+'/'+storage+'/'+str(i),input_id=matrix['id'],storage=storage,option_index=i,options=options)
   with warnings.catch_warnings(record=True) as caught:
    warnings.simplefilter('always')
    try:
     kwargs=dict(theta=theta,clip=clip,check_values=options['check_values'])
     result=sc.experimental.pp.normalize_pearson_residuals(a,**kwargs,**({'inplace':False} if version=='1.10.4' else {'out':True}))
     values=np.asarray(result['X'] if version=='1.10.4' else result)
     with np.errstate(all='ignore'):
      mu=np.outer(c,g)/(1 if version=='1.13.0' and total==0 else total);variance=mu+mu**2/theta
      raw=np.divide(x-mu,np.sqrt(variance),out=np.zeros_like(x),where=mu!=0) if version=='1.13.0' else (x-mu)/np.sqrt(variance)
      lost=(mu==0)&(c[:,None]>0)&(g[None,:]>0)
     usable=all(np.isfinite(z).all() for z in [g,c,np.asarray(total),mu,variance,raw,values]) and not lost.any()
     record.update(status='original-returned',shape=list(values.shape),values=encoded(values),feature_totals=encoded(g),cell_totals=encoded(c),grand_total=number(total),mu=encoded(mu),variance=encoded(variance),project_arithmetic_admissible=bool(usable),nonfinite_values=int((~np.isfinite(values)).sum()),zero_values=int((values==0).sum()),input_unchanged=bool(np.array_equal(a.X.toarray() if sp.issparse(a.X) else a.X,x)))
    except Exception as error:record.update(status='original-error',error_type=type(error).__name__,error=str(error))
   record['warnings']=[dict(category=w.category.__name__,message=str(w.message)) for w in caught];cases.append(record)
record=dict(status='PASS_CAPTURED_ORIGINAL_SCANPY_PEARSON_CASES',scanpy_version=version,source=expected,versions={n:md.version(n) for n in ['scanpy','numpy','scipy','anndata','pandas']},cases=cases,source_patched=False,fixture_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),whole_tool_qualified=False)
(O/'CASES.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
print(version,'cases',len(cases),'errors',sum(c['status']=='original-error' for c in cases),'source_nonfinite_cases',sum(c.get('nonfinite_values',0)>0 for c in cases),'project_unadmitted',sum(c.get('project_arithmetic_admissible') is False for c in cases))
