import bitarray,json,numpy,scipy,pandas
from pathlib import Path
r=bitarray.test()
assert r.wasSuccessful() and r.testsRun>=400
Path(__file__).with_name('SMOKE.json').write_text(json.dumps(dict(bitarray=bitarray.__version__,numpy=numpy.__version__,scipy=scipy.__version__,pandas=pandas.__version__,tests=r.testsRun,failures=len(r.failures),errors=len(r.errors),skipped=len(r.skipped)),indent=2)+'\n')
