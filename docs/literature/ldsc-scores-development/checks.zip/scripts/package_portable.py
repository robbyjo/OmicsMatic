import hashlib,json,os,shutil,subprocess,time,traceback,xml.etree.ElementTree as ET,zipfile
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];out=b/'portable-1';out.mkdir();jdk=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin');junit=r/'build/nfcore-atacseq121-1/linux-test-runtime-1/junit-platform-console-standalone-1.13.4.jar'
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
def linux(p):p=Path(p).resolve();return '/mnt/'+p.drive[0].lower()+'/'+p.as_posix()[3:]
def run(tag,cmd,env=None):
 save(out/(tag+'-command.json'),cmd);start=time.monotonic()
 with (out/(tag+'.stdout')).open('xb') as so,(out/(tag+'.stderr')).open('xb') as se:p=subprocess.run(cmd,cwd=r,env=env,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=900)
 save(out/(tag+'-PROCESS.json'),dict(exit_code=p.returncode,seconds=time.monotonic()-start));assert p.returncode==0,(tag,p.returncode)
try:
 native=json.loads((b/'native-test-1/COMPLETED.json').read_bytes());assert native['junit']==dict(tests=9,errors=0,failures=0,skipped=0)
 guards=json.loads((b/'native-test-1/SOURCES.json').read_bytes());assert all(pin(r/n)==v for n,v in guards.items());save(out/'SOURCES.json',guards)
 rel=out.relative_to(r).as_posix();init=out/'private.gradle';init.write_text("gradle.projectsEvaluated { rootProject.tasks.named('executableJar') { destinationDirectory.set(rootProject.layout.projectDirectory.dir('"+rel+"/jar')) } }\n",newline='\n');run('package',[str(r/'gradlew.bat'),'--no-daemon','--console=plain','-I',str(init),':executableJar'],dict(os.environ,JAVA_HOME=str(jdk.parent)))
 jar=out/'jar/omicsmatic-0.4.0.jar';before=r/'build/ldsc-stratified-cli-1/build-3/jar/omicsmatic-0.4.0.jar'
 with zipfile.ZipFile(before) as old,zipfile.ZipFile(jar) as current:
  assert set(old.namelist())<=set(current.namelist())
  for n in old.namelist():assert old.read(n)==current.read(n),'Changed prior JAR member: '+n
  new=sorted(set(current.namelist())-set(old.namelist()));assert all(n.startswith('org/jlinalg/genetics/LdscLdScores') for n in new),new
 save(out/'PRIOR-JAR-MEMBERS.json',dict(status='PASS_ALL_PRIOR_WORKFLOW_JAR_MEMBERS_UNCHANGED',new_members=new,baseline=pin(before),artifact=pin(jar)))
 classes=out/'test-classes';classes.mkdir();test=r/'src/test/java/org/jlinalg/genetics/LdscLdScoresTest.java';run('compile-tests',[str(jdk/'javac.exe'),'--release','17','-cp',os.pathsep.join(map(str,[jar,junit])),'-d',str(classes),str(test)])
 for platform in ['windows','linux']:
  report=out/(platform+'-junit');report.mkdir();paths=[jar,classes,r/'src/test/resources'];cp=os.pathsep.join(map(str,paths)) if platform=='windows' else ':'.join(linux(p) for p in paths);args=['execute','--class-path',cp,'--select-class','org.jlinalg.genetics.LdscLdScoresTest','--reports-dir',str(report) if platform=='windows' else linux(report),'--details','summary','--disable-ansi-colors'];cmd=[str(jdk/'java.exe'),'-jar',str(junit),*args] if platform=='windows' else ['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','java','-jar',linux(junit),*args];run(platform+'-tests',cmd)
  trees=[ET.parse(p).getroot() for p in report.glob('TEST-*.xml')];counts={k:sum(int(t.attrib.get(k,0)) for t in trees) for k in ['tests','errors','failures','skipped']};assert counts==dict(tests=9,errors=0,failures=0,skipped=0),counts;save(out/(platform+'-COUNTS.json'),counts)
 probe=out/'LdScoreProbe.java';probe.write_text('''package org.jlinalg.genetics;
import java.nio.file.*;import java.util.*;import java.nio.charset.StandardCharsets;
public final class LdScoreProbe {
 public static void main(String[] args)throws Exception {
  var test=new LdscLdScoresTest();test.temp=Path.of(args[0]);Files.createDirectory(test.temp);Path dest=Path.of(args[1]);Files.createDirectory(dest);
  for(var model:test.models(LdscLdScoresTest.fixtures())){var result=model.compute();var flat=new TreeMap<String,Object>();LdscLdScoresTest.flatten("",result,flat);var rows=new StringBuilder("field\\tvalue\\n");for(var e:flat.entrySet())rows.append(e.getKey()).append('\\t').append(e.getValue()==null?"NA":e.getValue()).append('\\n');Files.writeString(dest.resolve(model.id()+".tsv"),rows.toString(),StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW);}
 }
}
''',encoding='utf8',newline='\n');run('compile-probe',[str(jdk/'javac.exe'),'--release','17','-cp',os.pathsep.join(map(str,[jar,junit,classes,r/'src/test/resources'])),'-d',str(classes),str(probe)])
 for platform in ['windows','linux']:
  paths=[jar,junit,classes,r/'src/test/resources'];cp=os.pathsep.join(map(str,paths)) if platform=='windows' else ':'.join(linux(p) for p in paths);args=['-cp',cp,'org.jlinalg.genetics.LdScoreProbe',str(out/(platform+'-inputs')) if platform=='windows' else linux(out/(platform+'-inputs')),str(out/(platform+'-payloads')) if platform=='windows' else linux(out/(platform+'-payloads'))];cmd=[str(jdk/'java.exe'),*args] if platform=='windows' else ['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','java',*args];run(platform+'-probe',cmd)
 win=out/'windows-payloads';other=out/'linux-payloads';assert {p.name for p in win.iterdir()}=={p.name for p in other.iterdir()} and len(list(win.iterdir()))==37
 for p in win.iterdir():assert p.read_bytes()==(other/p.name).read_bytes(),p.name
 assert all(pin(r/n)==v for n,v in guards.items());save(out/'COMPLETED.json',dict(status='PASS_PACKAGED_NATIVE_LDSCORES_WINDOWS_LINUX',windows_tests=9,linux_same_tests=9,original_models=37,reference_fields=native['reference_fields'],byte_identical_complete_model_payloads=37,all_prior_jar_members_unchanged=True,new_jar_members=new,artifact=pin(jar),source_guards=guards));print('PASS packaged9 tests on both platforms;37 identical complete model payloads',flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),detail=traceback.format_exc()));print(traceback.format_exc(),flush=True);raise
