import hashlib,json,shutil,subprocess,sys,time,traceback,urllib.request,zipfile
from pathlib import Path,PurePosixPath
b=Path(__file__).resolve().parent;r=b.parents[1];out=b/'reference-runtime-1';out.mkdir();old=r/'build/ldsc-high-impact-1/reference-runtime-1';source=old/'python'
def pin(p):
 with p.open('rb') as f:d=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(bytes=p.stat().st_size,sha256=d)
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
def get(url):
 req=urllib.request.Request(url,headers={'User-Agent':'OmicsMatic-authorized-scientific-reference-setup'})
 with urllib.request.urlopen(req,timeout=45) as response:return response.read()
try:
 expected=json.loads((old/'INSTALLED-FILES.json').read_bytes());assert {p.relative_to(source).as_posix() for p in source.rglob('*') if p.is_file()}==set(expected);assert all(pin(source/n)==v for n,v in expected.items());save(out/'PREVIOUS-RUNTIME-INTAKE.json',dict(files=len(expected),manifest=pin(old/'INSTALLED-FILES.json')))
 metadata=get('https://pypi.org/pypi/bitarray/2.6.0/json');(out/'bitarray-pypi.json').write_bytes(metadata);package=json.loads(metadata);assert package['info']['version']=='2.6.0'
 wheels=[x for x in package['urls'] if x['filename']=='bitarray-2.6.0-cp310-cp310-win_amd64.whl'];assert len(wheels)==1;wheel=wheels[0];data=get(wheel['url']);assert len(data)==wheel['size'] and hashlib.sha256(data).hexdigest()==wheel['digests']['sha256'];path=out/wheel['filename'];path.write_bytes(data)
 runtime=out/'python';shutil.copytree(source,runtime)
 with zipfile.ZipFile(path) as z:
  for name in z.namelist():
   p=PurePosixPath(name);assert not p.is_absolute() and '..' not in p.parts and not (runtime/'site-packages'/name).exists()
  for entry in z.infolist():
   if not entry.is_dir():
    dest=runtime/'site-packages'/entry.filename;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z.read(entry))
 # Original runtime is unchanged. New dependency installation stays private.
 assert all(pin(source/n)==v for n,v in expected.items());script=out/'smoke.py';script.write_text("import bitarray,json,numpy,scipy,pandas\nfrom pathlib import Path\nr=bitarray.test()\nassert r.wasSuccessful() and r.testsRun>=400\nPath(__file__).with_name('SMOKE.json').write_text(json.dumps(dict(bitarray=bitarray.__version__,numpy=numpy.__version__,scipy=scipy.__version__,pandas=pandas.__version__,tests=r.testsRun,failures=len(r.failures),errors=len(r.errors),skipped=len(r.skipped)),indent=2)+'\\n')\n",encoding='utf8',newline='\n')
 cmd=[str(runtime/'python.exe'),'-B',str(script)];save(out/'command.json',cmd);start=time.monotonic()
 with (out/'stdout').open('xb') as so,(out/'stderr').open('xb') as se:p=subprocess.run(cmd,cwd=b,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=180)
 save(out/'PROCESS.json',dict(exit_code=p.returncode,seconds=time.monotonic()-start));assert p.returncode==0
 installed={p.relative_to(runtime).as_posix():pin(p) for p in runtime.rglob('*') if p.is_file()};save(out/'INSTALLED-FILES.json',installed);save(out/'COMPLETED.json',dict(status='PASS_PRIVATE_ORIGINAL_LDSCORE_REFERENCE_RUNTIME',original_runtime_files_unchanged=len(expected),installed_files=len(installed),wheel=wheel,smoke=json.loads((out/'SMOKE.json').read_bytes())));print('PASS private bitarray2.6 runtime',len(installed),'files; original runtime unchanged',flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),detail=traceback.format_exc()));print(traceback.format_exc(),flush=True);raise
