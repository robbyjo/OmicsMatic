import hashlib,json,re,subprocess,sys,time,traceback,zipfile
from pathlib import Path,PurePosixPath
b=Path(__file__).resolve().parent;r=b.parents[1];out=b/'closure-1';out.mkdir();evidence=r/'docs/literature/ldsc-scores-development'
def rawpin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def pin(p):
 with p.open('rb') as f:d=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(bytes=p.stat().st_size,sha256=d)
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
def run(tag,cmd):
 save(out/(tag+'-command.json'),cmd);start=time.monotonic()
 with (out/(tag+'.stdout')).open('xb') as so,(out/(tag+'.stderr')).open('xb') as se:p=subprocess.run(cmd,cwd=r,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=300)
 save(out/(tag+'-PROCESS.json'),dict(exit_code=p.returncode,seconds=time.monotonic()-start));assert p.returncode==0,(tag,p.returncode)
try:
 portable=json.loads((b/'portable-1/COMPLETED.json').read_bytes());assert portable['status']=='PASS_PACKAGED_NATIVE_LDSCORES_WINDOWS_LINUX' and portable['original_models']==37 and portable['reference_fields']==75226 and portable['byte_identical_complete_model_payloads']==37
 for n,v in portable['source_guards'].items():assert pin(r/n)==v,n
 comparison=json.loads((b/'example-validation-1/COMPLETED.json').read_bytes());assert comparison['status']=='PASS_DOCUMENTED_NATIVE_EXAMPLE_AND_UNCHANGED_ORIGINAL_CLI_COMPARISON' and comparison['rows']==42
 upstream=r/'build/ldsc-high-impact-1/upstream-1';info=next(x for x in json.loads((upstream/'INTAKE.json').read_bytes()) if x['label']=='cbiit');archive=upstream/('cbiit-'+info['commit']+'.zip');assert pin(archive)==dict(bytes=info['archive_bytes'],sha256=info['archive_sha256']);source=upstream/'cbiit';source_pins={}
 with zipfile.ZipFile(archive) as z:
  for member in z.infolist():
   if member.is_dir():continue
   path=PurePosixPath(member.filename);relative=PurePosixPath(*path.parts[1:]).as_posix();raw=z.read(member);assert (source/relative).read_bytes()==raw,relative;source_pins[relative]=rawpin(raw)
 assert {p.relative_to(source).as_posix() for p in source.rglob('*') if p.is_file()}==set(source_pins)
 save(out/'UPSTREAM-SOURCE-TREE.json',dict(status='PASS_COMPLETE_EXTRACTION_MATCHES_SAVED_COMMIT_ARCHIVE',commit=info['commit'],archive=pin(archive),files=source_pins))
 for folder,manifest in [(b/'reference-runtime-1/python',b/'reference-runtime-1/INSTALLED-FILES.json'),(r/'build/ldsc-high-impact-1/reference-runtime-1/python',r/'build/ldsc-high-impact-1/reference-runtime-1/INSTALLED-FILES.json')]:
  installed=json.loads(manifest.read_bytes());assert {p.relative_to(folder).as_posix() for p in folder.rglob('*') if p.is_file()}==set(installed);assert all(pin(folder/n)==v for n,v in installed.items())
 origins=dict(original_scores_population_indices_and_observed_graph=0,observed_retained_frequency_and_normalization=0,summaries_from_original_filtered_population=0,independent_raw_genotype_audit=0)
 with zipfile.ZipFile(r/'src/test/resources/org/jlinalg/genetics/ldsc-scores/reference-fixtures.zip') as z:
  for ident in [line.split('\t')[0] for line in z.read('cases.tsv').decode().splitlines()[1:]]:
   fields=dict(line.split('\t',1) for line in z.read(ident+'/expected.tsv').decode().splitlines()[1:])
   for key,value in fields.items():
    if key.startswith(('retainedInputIndices.','nominalWindowLefts.','ldScores.','chunks.')):group='original_scores_population_indices_and_observed_graph'
    elif key.startswith('variantAudit.'):
     row=key.split('.')[1];retained=fields['variantAudit.'+row+'.retained']=='true'
     group='observed_retained_frequency_and_normalization' if retained and key.rsplit('.',1)[1] in ['allele2Frequency','maf','imputedMean','populationStandardDeviation'] else 'independent_raw_genotype_audit'
    else:group='summaries_from_original_filtered_population'
    origins[group]+=1
 assert sum(origins.values())==75226;save(evidence/'REFERENCE-ORIGINS.json',origins)
 for name in ['docs/vignettes/ldsc-ld-scores.md','docs/literature/ldsc-scores-development/README.md','examples/ldsc-scores/README.md']:
  for target in re.findall(r'\]\(([^)]+)\)',(r/name).read_text(encoding='utf8')):
   if not target.startswith(('https://','http://','#')):assert ((r/name).parent/target.split('#')[0]).exists(),(name,target)
 run('catalog',[sys.executable,'-X','utf8','-B',str(r/'tools/literature/ldsc_hsq/catalog.py'),'--verify','--primary-cache','D:/projects/JLinAlg/build/literature-review/xml','--out',str(out/'catalog-current')]);run('prior-workflow',[sys.executable,'-X','utf8','-B',str(r/'tools/literature/ldsc_stratified/workflow_verify.py'),'--out',str(out/'prior-workflow-current')])
 catalog=json.loads((out/'catalog-current/COMPLETED.json').read_bytes());assert catalog['new_scoped_integrations']==128 and catalog['current_manifest']['entries']==794
 names=['src/main/java/org/jlinalg/genetics/LdscLdScores.java','src/main/java/org/jlinalg/genetics/PlinkBedDataset.java','src/test/java/org/jlinalg/genetics/LdscLdScoresTest.java','docs/vignettes/ldsc-ld-scores.md','tools/literature/ldsc_scores/verify.py','build.gradle']
 for folder in ['examples/ldsc-scores','src/test/resources/org/jlinalg/genetics/ldsc-scores','docs/literature/ldsc-scores-development']:names.extend(p.relative_to(r).as_posix() for p in (r/folder).rglob('*') if p.is_file())
 guards={n:pin(r/n) for n in sorted(set(names))};payload={}
 for folder in ['reference-1','native-test-1','portable-1','original-cli-1','example-validation-1']:
  for p in (b/folder).rglob('*'):
   if p.is_file() and 'jar' not in p.relative_to(b/folder).parts:payload['attempts/'+p.relative_to(b).as_posix()]=p.read_bytes()
 for p in (b/'reference-runtime-1').iterdir():
  if p.is_file():payload['reference-runtime/'+p.name]=p.read_bytes()
 for p in b.glob('*.py'):payload['scripts/'+p.name]=p.read_bytes()
 for n in guards:payload['snapshot/'+n]=(r/n).read_bytes()
 for p in source.rglob('*'):
  if p.is_file() and (p.suffix=='.py' or p.name in ['LICENSE','README.md']):payload['original-cbiit/'+p.relative_to(source).as_posix()]=p.read_bytes()
 payload['original-cbiit/ARCHIVE-INTAKE.json']=(json.dumps(info,indent=2)+'\n').encode()
 for p in out.rglob('*'):
  if p.is_file():payload['closure/'+p.relative_to(out).as_posix()]=p.read_bytes()
 payload['closure/EXAMPLE-SETUP-HISTORY.json']=(json.dumps(dict(status='INITIAL_SETUP_GUARD_REFUSAL_RETAINED',observed_error='FileExistsError: examples/ldsc-scores already existed after Java/README files were added; no input was overwritten.',initial_script='scripts/prepare_example.py',corrected_exclusive_script='scripts/prepare_example2.py',scientific_results_changed=False),indent=2)+'\n').encode()
 index={n:rawpin(raw) for n,raw in sorted(payload.items())};payload['ENTRY-MANIFEST.json']=(json.dumps(dict(payloads=index),indent=2)+'\n').encode();controls=evidence/'checks.zip'
 with zipfile.ZipFile(controls,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for n,raw in sorted(payload.items()):z.writestr(n,raw)
 with zipfile.ZipFile(controls) as z:
  assert len(z.namelist())==len(set(z.namelist()))==len(index)+1 and set(z.namelist())==set(index)|{'ENTRY-MANIFEST.json'} and z.testzip() is None
  for n,v in index.items():assert rawpin(z.read(n))==v,n
 expected=dict(tests=9,errors=0,failures=0,skipped=0);result=dict(status='PASS_NATIVE_REFERENCE_LD_SCORE_API',profile='native-reference-ldscore-cbiit302-source-chunked-v1',original_models=37,reference_fields=75226,reference_origins=origins,windows_junit=expected,linux_same_junit=expected,byte_identical_complete_model_payloads=37,all_prior_jar_members_unchanged=True,large_control=dict(input_variants=4099,samples=512,peak_cached_genotype_cells=51200,correlations=286465,beyond_nominal_window_pairs=261930),original_cli_comparison=comparison,complete_original_source_tree_checked=True,original_commit=info['commit'],original_source_archive=pin(archive),original_source_files=len(source_pins),private_reference_runtime_files=4441,earlier_4424_file_runtime_unchanged=True,reference_dependency_self_tests=dict(tests=435,errors=0,failures=0,skipped=0),source_guards=guards,artifact=portable['artifact'],indexed_payloads=len(index),all_archive_payloads_read_back=True,archive=pin(controls),prior_stratified_workflow_preserved=True,current_catalog=catalog,new_family_credit=0,whole_tool_qualified=False,whole_goal_complete=False,historical_fingerprints_refreshed=False,public_runtime_dependency='Java17+',workflow_command_available=False,website_deployed=False,released=False,pushed=False)
 save(evidence/'VALIDATION.json',result);run('retained-verifier',[sys.executable,'-X','utf8','-B',str(r/'tools/literature/ldsc_scores/verify.py'),'--out',str(out/'retained-recheck')]);save(out/'COMPLETED.json',result);print(json.dumps({k:result[k] for k in ['status','reference_origins','indexed_payloads','archive']}),flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),detail=traceback.format_exc()));print(traceback.format_exc(),flush=True);raise
