import csv,gzip,hashlib,json,os,subprocess,time,traceback
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];out=b/'example-validation-1';out.mkdir()
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
try:
 assert (b/'portable-1/COMPLETED.json').exists() and (b/'original-cli-1/COMPLETED.json').exists();jar=b/'portable-1/jar/omicsmatic-0.4.0.jar';cmd=['C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe','-cp',str(jar),str(r/'examples/ldsc-scores/LdscLdScoresExample.java')];save(out/'command.json',cmd);start=time.monotonic()
 with (out/'stdout').open('xb') as so,(out/'stderr').open('xb') as se:p=subprocess.run(cmd,cwd=r,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=180)
 save(out/'PROCESS.json',dict(exit_code=p.returncode,seconds=time.monotonic()-start));assert p.returncode==0
 with (out/'stdout').open() as f:native=list(csv.DictReader(f,delimiter='\t'))
 with gzip.open(b/'original-cli-1/ldscore.l2.ldscore.gz','rt') as f:original=list(csv.DictReader(f,delimiter='\t'))
 assert len(native)==len(original)>0;maximum=0
 for a,z in zip(native,original):
  assert a['variant']==z['SNP'];difference=abs(float(a['L2'])-float(z['L2']));maximum=max(maximum,difference);assert difference<=.0005000001
 expected=next(c['expected'] for c in json.loads((b/'reference-1/result/reference.json').read_bytes())['cases'] if c['id']=='L018');assert len(native)==len(expected['retainedInputIndices'])
 for row,value in zip(native,expected['ldScores']):assert abs(float(row['L2'])-value[0])<=2e-11+2e-9*abs(value[0])
 full=float((b/'original-cli-1/ldscore.l2.M').read_text().strip());common=float((b/'original-cli-1/ldscore.l2.M_5_50').read_text().strip());assert full==expected['annotationCounts'][0] and common==expected['commonAnnotationCounts'][0]
 warnings=(out/'stderr').read_text();assert 'M='+str([full]) in warnings and 'M_5_50='+str([common]) in warnings and 'SYNTHETIC' in warnings
 save(out/'COMPLETED.json',dict(status='PASS_DOCUMENTED_NATIVE_EXAMPLE_AND_UNCHANGED_ORIGINAL_CLI_COMPARISON',rows=len(native),reference_case='L018',native_values_match_full_precision_core=True,upstream_cli_decimal_places=3,maximum_absolute_printing_difference=maximum,full_annotation_count=full,common_annotation_count=common));print('PASS public native example vs full original L2 CLI',len(native),'rows',flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),detail=traceback.format_exc()));print(traceback.format_exc(),flush=True);raise
