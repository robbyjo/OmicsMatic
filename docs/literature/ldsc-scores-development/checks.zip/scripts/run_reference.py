import hashlib,json,os,subprocess,time,traceback
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];out=b/'reference-1';out.mkdir();runtime=b/'reference-runtime-1/python'
def pin(p):
 with p.open('rb') as f:d=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(bytes=p.stat().st_size,sha256=d)
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
try:
 expected=json.loads((b/'reference-runtime-1/INSTALLED-FILES.json').read_bytes());assert {p.relative_to(runtime).as_posix() for p in runtime.rglob('*') if p.is_file()}==set(expected);assert all(pin(runtime/n)==v for n,v in expected.items())
 cmd=[str(runtime/'python.exe'),'-B',str(b/'generate_reference.py'),'--source',str(r/'build/ldsc-high-impact-1/upstream-1/cbiit'),'--out',str(out/'result')];save(out/'command.json',cmd);start=time.monotonic()
 with (out/'stdout').open('xb') as so,(out/'stderr').open('xb') as se:p=subprocess.run(cmd,cwd=b,env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'),stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=300)
 save(out/'PROCESS.json',dict(exit_code=p.returncode,seconds=time.monotonic()-start));assert p.returncode==0
 assert all(pin(runtime/n)==v for n,v in expected.items());save(out/'COMPLETED.json',dict(status='PASS_ORIGINAL_LDSCORE_REFERENCE_AND_PRIVATE_RUNTIME_UNCHANGED',runtime_files=len(expected),reference=pin(out/'result/reference.json')));print('PASS original source LD-score reference',flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),detail=traceback.format_exc()));print(traceback.format_exc(),flush=True);raise
