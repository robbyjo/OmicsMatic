import shutil
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];dest=r/'examples/ldsc-scores';source=b/'reference-1/result/L018'
assert dest.resolve().is_relative_to(r/'examples') and {p.name for p in dest.iterdir()}=={'LdscLdScoresExample.java','README.md'}
for ext in ['.bed','.bim','.fam']:
 with (dest/('reference'+ext)).open('xb') as f:f.write((source/('reference'+ext)).read_bytes())
rows=[]
for line in (source/'reference.bim').read_text().splitlines():
 fields=line.split();rows.append(fields[1]+'\t'+fields[2])
with (dest/'coordinates.tsv').open('x',encoding='utf8',newline='\n') as f:f.write('variant\tcoordinate\n'+'\n'.join(rows)+'\n')
with (dest/'variant-ids.txt').open('x',encoding='utf8',newline='\n') as f:f.write('\n'.join(line.split('\t')[0] for line in rows)+'\n')
for folder in [dest,r/'src/test/resources/org/jlinalg/genetics/ldsc-scores']:
 with (folder/'.gitattributes').open('x',encoding='utf8',newline='\n') as f:f.write('* -text whitespace=cr-at-eol\n')
print('PASS exclusive creation of complete original L018 BED example.')
