from pathlib import Path
r=Path(__file__).resolve().parents[2]
for path,spans in [('build/ldsc-high-impact-1/upstream-1/cbiit/ldscore/ldscore.py',[(1,246),(246,410)]),('build/ldsc-high-impact-1/upstream-1/cbiit/ldsc.py',[(215,375)]),('src/main/java/org/jlinalg/genetics/PlinkBedDataset.java',[(1,210)]),('build/ldsc-high-impact-1/upstream-1/cbiit/setup.py',[(1,120)])]:
 print('\nFILE',path);lines=(r/path).read_text(encoding='utf8').splitlines()
 for a,b in spans:
  for i in range(a-1,min(b,len(lines))):print(str(i+1)+': '+lines[i])
