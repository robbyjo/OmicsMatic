import hashlib,json,os,subprocess,time,traceback
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];out=b/'original-cli-1';out.mkdir();source=r/'build/ldsc-high-impact-1/upstream-1/cbiit';runtime=b/'reference-runtime-1/python'
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
try:
 expected=json.loads((b/'reference-runtime-1/INSTALLED-FILES.json').read_bytes());assert all(pin(runtime/n)==v for n,v in expected.items());guards=json.loads((b/'reference-1/result/reference.json').read_bytes())['source_guards'];assert all(pin(source/n)==v for n,v in guards.items())
 case=next(x for x in json.loads((b/'reference-1/result/reference.json').read_bytes())['cases'] if x['id']=='L018');assert case['selected_samples']==list(range(case['raw_samples'])) and case['selected_variants']==list(range(case['raw_variants']))
 bootstrap=out/'launch.py';bootstrap.write_text("import runpy,sys,types\nfrom pathlib import Path\np=Path(sys.argv[1]);args=sys.argv[2:];package=types.ModuleType('ldscore');package.__path__=[str(p/'ldscore')];sys.modules['ldscore']=package;sys.argv=[str(p/'ldsc.py'),*args];runpy.run_path(str(p/'ldsc.py'),run_name='__main__')\n",encoding='utf8',newline='\n');prefix=b/'reference-1/result/L018/reference';cmd=[str(runtime/'python.exe'),'-B',str(bootstrap),str(source),'--l2','--bfile',str(prefix),'--ld-wind-cm',str(case['window']),'--chunk-size',str(case['chunk']),'--maf',str(case['maf']),'--out',str(out/'ldscore')];save(out/'command.json',cmd);env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1');gzip=Path('C:/Program Files/Git/usr/bin/gzip.exe')
 if gzip.exists():env['PATH']=str(gzip.parent)+os.pathsep+env.get('PATH','');save(out/'GZIP.json',dict(path=str(gzip),pin=pin(gzip)))
 start=time.monotonic()
 with (out/'stdout').open('xb') as so,(out/'stderr').open('xb') as se:p=subprocess.run(cmd,cwd=b,env=env,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=300)
 save(out/'PROCESS.json',dict(exit_code=p.returncode,seconds=time.monotonic()-start));assert p.returncode==0
 assert (out/'ldscore.l2.ldscore.gz').exists() and (out/'ldscore.l2.M').exists() and (out/'ldscore.l2.M_5_50').exists();assert all(pin(source/n)==v for n,v in guards.items());assert all(pin(runtime/n)==v for n,v in expected.items());save(out/'COMPLETED.json',dict(status='PASS_UNCHANGED_ORIGINAL_L2_CLI',reference_case='L018',original_functions_replaced=False,source_initializer_bypassed=True,source_guards=guards,runtime_unchanged=True,outputs={p.name:pin(p) for p in out.glob('ldscore*') if p.is_file()}));print('PASS original full L2 CLI',flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),detail=traceback.format_exc()));print(traceback.format_exc(),flush=True);raise
