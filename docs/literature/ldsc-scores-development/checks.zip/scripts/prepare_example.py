import json,shutil
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];dest=r/'examples/ldsc-scores';dest.mkdir();source=b/'reference-1/result/L018'
for ext in ['.bed','.bim','.fam']:shutil.copyfile(source/('reference'+ext),dest/('reference'+ext))
rows=[]
for line in (source/'reference.bim').read_text().splitlines():
 fields=line.split();rows.append(fields[1]+'\t'+fields[2])
(dest/'coordinates.tsv').write_text('variant\tcoordinate\n'+'\n'.join(rows)+'\n',encoding='utf8',newline='\n')
(dest/'variant-ids.txt').write_text('\n'.join(line.split('\t')[0] for line in rows)+'\n',encoding='utf8',newline='\n')
for folder in [dest,r/'src/test/resources/org/jlinalg/genetics/ldsc-scores']:(folder/'.gitattributes').write_text('* -text whitespace=cr-at-eol\n',encoding='utf8',newline='\n')
print('Prepared complete synthetic original L018 BED example.')
