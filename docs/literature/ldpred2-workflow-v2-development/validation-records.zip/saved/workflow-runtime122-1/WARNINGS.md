# Warnings and required actions

Use a permitted Linux x86-64 R runtime, all original dependencies, and the exact selected 1.12.2 CRAN or 1.12.4 official development archive. Install only where allowed; otherwise skip dependent analysis. Fix the named cause and retry NEW paths. Never replace an existing runtime fingerprint to suppress refusal. This adoption runs no model and establishes no author-binary authenticity.
