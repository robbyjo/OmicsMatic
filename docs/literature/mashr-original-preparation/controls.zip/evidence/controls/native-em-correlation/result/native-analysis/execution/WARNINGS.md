# Native mash development execution

DEVELOPMENT ONLY: native plain EM and explicit fully expanded models. PCA/extreme-deconvolution learning, public runtime/bundle admission and whole-paper reproduction are not provided by this executor.

- STRONG_POPULATION_RECORDED: strong rows are recorded, but this native execution uses only canonical or explicitly supplied covariance bases. It does not learn PCA/ED covariances.

- training-likelihood row 0: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 0: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 1: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 1: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 2: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 2: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 3: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 3: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 4: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 4: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 5: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 5: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 6: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 6: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 7: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 7: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 8: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 8: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 9: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 9: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 10: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 10: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 11: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 11: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 12: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 12: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 13: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 13: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 14: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 14: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 15: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 15: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 16: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 16: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 17: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 17: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 18: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 18: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 19: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 19: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 20: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 20: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 21: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 21: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 22: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 22: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 23: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 23: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 24: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 24: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 25: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 25: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 26: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 26: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 27: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 27: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 28: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 28: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 29: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 29: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 30: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 30: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 31: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 31: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 32: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 32: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 33: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 33: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 34: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 34: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 35: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 35: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 36: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 36: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 37: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 37: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 38: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 38: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 39: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 39: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 40: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 40: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 41: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 41: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 42: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 42: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 43: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 43: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 44: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 44: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 45: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 45: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 46: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 46: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 47: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 47: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 48: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 48: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 49: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 49: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 50: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 50: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 51: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 51: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 52: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 52: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 53: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 53: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 54: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 54: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 55: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 55: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 56: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 56: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 57: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 57: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 58: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 58: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 59: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 59: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 60: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 60: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 61: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 61: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 62: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 62: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 63: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 63: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 64: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 64: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 65: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 65: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 66: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 66: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 67: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 67: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 68: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 68: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 69: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 69: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 70: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 70: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 71: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 71: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 72: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 72: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 73: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 73: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 74: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 74: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 75: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 75: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 76: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 76: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 77: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 77: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 78: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 78: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 79: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 79: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 80: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 80: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 81: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 81: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 82: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 82: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 83: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 83: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 84: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 84: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 85: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 85: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 86: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 86: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 87: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 87: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 88: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 88: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 89: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 89: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 90: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 90: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 91: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 91: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 92: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 92: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 93: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 93: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 94: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 94: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 95: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 95: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 96: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 96: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 97: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 97: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 98: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 98: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 99: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 99: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 0: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 0: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 1: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 1: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 2: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 2: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 3: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 3: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 4: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 4: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 5: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 5: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 6: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 6: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 7: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 7: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 8: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 8: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 9: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 9: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 10: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 10: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 11: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 11: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 12: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 12: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 13: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 13: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 14: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 14: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 15: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 15: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 16: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 16: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 17: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 17: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 18: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 18: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 19: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 19: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 20: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 20: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 21: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 21: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 22: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 22: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 23: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 23: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 24: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 24: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 25: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 25: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 26: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 26: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 27: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 27: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 28: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 28: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 29: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 29: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 30: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 30: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 31: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 31: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 32: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 32: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 33: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 33: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 34: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 34: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 35: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 35: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 36: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 36: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 37: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 37: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 38: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 38: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 39: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 39: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 40: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 40: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 41: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 41: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 42: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 42: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 43: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 43: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 44: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 44: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 45: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 45: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 46: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 46: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 47: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 47: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 48: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 48: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 49: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 49: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 50: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 50: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 51: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 51: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 52: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 52: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 53: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 53: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 54: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 54: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 55: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 55: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 56: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 56: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 57: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 57: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 58: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 58: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 59: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 59: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 60: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 60: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 61: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 61: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 62: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 62: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 63: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 63: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 64: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 64: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 65: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 65: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 66: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 66: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 67: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 67: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 68: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 68: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 69: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 69: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 70: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 70: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 71: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 71: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 72: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 72: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 73: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 73: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 74: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 74: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 75: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 75: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 76: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 76: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 77: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 77: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 78: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 78: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 79: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 79: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 80: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 80: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 81: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 81: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 82: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 82: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 83: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 83: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 84: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 84: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 85: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 85: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 86: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 86: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 87: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 87: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 88: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 88: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 89: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 89: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 90: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 90: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 91: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 91: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 92: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 92: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 93: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 93: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 94: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 94: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 95: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 95: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 96: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 96: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 97: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 97: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 98: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 98: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 99: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 99: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- Weight fit 1: OBJECTIVE_ROUNDOFF: an EM objective decrease occurred within the explicit floating-point accumulation tolerance;the dual-gap convergence gate remains required.

- weight-fit row -1: OBJECTIVE_ROUNDOFF: an EM objective decrease occurred within the explicit floating-point accumulation tolerance;the dual-gap convergence gate remains required.

- training-likelihood row 0: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 0: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 1: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 1: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 2: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 2: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 3: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 3: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 4: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 4: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 5: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 5: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 6: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 6: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 7: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 7: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 8: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 8: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 9: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 9: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 10: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 10: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 11: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 11: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 12: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 12: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 13: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 13: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 14: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 14: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 15: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 15: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 16: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 16: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 17: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 17: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 18: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 18: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 19: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 19: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 20: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 20: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 21: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 21: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 22: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 22: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 23: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 23: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 24: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 24: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 25: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 25: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 26: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 26: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 27: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 27: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 28: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 28: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 29: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 29: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 30: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 30: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 31: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 31: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 32: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 32: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 33: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 33: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 34: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 34: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 35: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 35: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 36: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 36: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 37: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 37: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 38: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 38: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 39: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 39: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 40: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 40: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 41: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 41: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 42: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 42: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 43: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 43: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 44: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 44: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 45: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 45: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 46: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 46: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 47: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 47: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 48: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 48: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 49: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 49: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 50: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 50: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 51: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 51: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 52: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 52: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 53: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 53: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 54: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 54: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 55: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 55: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 56: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 56: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 57: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 57: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 58: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 58: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 59: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 59: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 60: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 60: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 61: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 61: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 62: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 62: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 63: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 63: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 64: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 64: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 65: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 65: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 66: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 66: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 67: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 67: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 68: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 68: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 69: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 69: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 70: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 70: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 71: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 71: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 72: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 72: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 73: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 73: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 74: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 74: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 75: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 75: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 76: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 76: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 77: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 77: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 78: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 78: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 79: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 79: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 80: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 80: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 81: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 81: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 82: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 82: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 83: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 83: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 84: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 84: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 85: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 85: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 86: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 86: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 87: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 87: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 88: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 88: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 89: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 89: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 90: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 90: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 91: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 91: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 92: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 92: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 93: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 93: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 94: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 94: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 95: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 95: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 96: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 96: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 97: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 97: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 98: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 98: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 99: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 99: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- Weight fit 2: OBJECTIVE_ROUNDOFF: an EM objective decrease occurred within the explicit floating-point accumulation tolerance;the dual-gap convergence gate remains required.

- weight-fit row -1: OBJECTIVE_ROUNDOFF: an EM objective decrease occurred within the explicit floating-point accumulation tolerance;the dual-gap convergence gate remains required.

- training-likelihood row 0: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 0: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 1: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 1: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 2: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 2: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 3: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 3: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 4: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 4: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 5: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 5: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 6: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 6: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 7: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 7: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 8: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 8: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 9: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 9: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 10: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 10: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 11: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 11: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 12: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 12: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 13: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 13: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 14: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 14: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 15: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 15: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 16: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 16: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 17: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 17: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 18: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 18: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 19: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 19: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 20: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 20: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 21: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 21: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 22: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 22: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 23: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 23: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 24: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 24: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 25: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 25: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 26: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 26: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 27: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 27: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 28: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 28: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 29: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 29: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 30: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 30: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 31: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 31: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 32: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 32: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 33: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 33: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 34: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 34: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 35: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 35: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 36: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 36: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 37: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 37: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 38: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 38: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 39: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 39: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 40: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 40: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 41: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 41: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 42: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 42: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 43: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 43: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 44: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 44: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 45: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 45: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 46: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 46: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 47: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 47: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 48: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 48: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 49: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 49: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 50: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 50: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 51: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 51: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 52: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 52: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 53: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 53: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 54: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 54: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 55: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 55: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 56: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 56: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 57: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 57: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 58: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 58: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 59: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 59: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 60: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 60: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 61: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 61: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 62: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 62: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 63: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 63: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 64: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 64: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 65: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 65: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 66: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 66: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 67: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 67: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 68: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 68: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 69: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 69: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 70: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 70: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 71: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 71: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 72: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 72: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 73: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 73: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 74: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 74: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 75: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 75: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 76: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 76: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 77: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 77: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 78: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 78: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 79: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 79: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 80: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 80: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 81: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 81: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 82: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 82: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 83: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 83: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 84: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 84: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 85: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 85: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 86: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 86: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 87: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 87: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 88: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 88: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 89: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 89: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 90: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 90: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 91: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 91: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 92: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 92: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 93: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 93: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 94: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 94: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 95: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 95: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 96: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 96: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 97: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 97: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 98: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 98: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- training-likelihood row 99: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 99: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- OBJECTIVE_ROUNDOFF: an EM objective decrease occurred within the explicit floating-point accumulation tolerance;the dual-gap convergence gate remains required.
