# Native mash scoped analysis

Scope: explicit representative populations, supplied/canonical covariance bases,
native plain-EM weights, fixed/simple/ad-hoc residual estimation and full target
posteriors. Only the top-level COMPLETED.json plus successful mashr-tools --verify
admits this scoped result. execution/result.tsv is a retained development-stage
record; its public_bundle_admitted=false describes that stage alone.

Read execution/WARNINGS.md in full for every numerical, prior-pruning and residual
warning. Read execution/fit for every weight history and accepted/rejected residual
proposal. RESIDUAL_ROLLBACK returns the preceding accepted model under the ad-hoc
likelihood rule; it does not prove a global residual optimum.

PCA/extreme-deconvolution learning, automatic RDS conversion, effect/P-value/SE
derivation, inferred missingness, sharing/composite hypotheses and whole-paper
reproduction are outside this native contract. Imported models must already be
explicitly fully expanded. Strong rows are recorded but do not learn covariances.

Verification replays every captured input and output, including fit histories,
model, posterior covariance and warnings. Numeric outputs use fixed absolute
1e-10 plus relative 1e-9 tolerance; identities, discrete states and choices are exact.
Each complete production or replay obeys limits.execution; creation performs two
complete executions and each verify performs one. Byte/census limits apply per
evidence tree. Limits are admission checks, not an operating-system sandbox.

Native execution needs Java only. SKIP3 means a requested unavailable capability:
skip dependent analysis and use a supported, separately validated workflow. No
fallback, population truncation, silent jitter or parameter guessing is performed.
FAIL2 means invalid input, integrity, numerical, convergence, capacity, cancellation
or finalization failure; no result is admitted. Required action: retain all inputs,
partial outputs and diagnostics, correct the named cause or increase only permitted
limits/heap, then retry into NEW output paths. Failed portable replay names retained
scratch and leaves the source bundle unchanged. SHA-256 establishes integrity,
not authenticity. Biological accuracy is not certified.

Fit status: RESIDUAL_TOLERANCE
