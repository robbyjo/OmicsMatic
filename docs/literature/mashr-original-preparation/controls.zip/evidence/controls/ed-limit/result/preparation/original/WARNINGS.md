# Original mashr preparation stage only
Status: 2
Phase: original-Bovy-extreme-deconvolution
Required action: preserve all source inputs, outputs, logs and candidate covariances. SKIP3 skips unavailable exact dependencies. FAIL2 admits no result for invalid input, numerical, convergence or capacity failures. Correct the named cause and retry into a NEW output directory. No population truncation, jitter fallback or synthetic padding. This preparation stage alone does not admit an analysis; the parent workflow and native child require separate verification.
