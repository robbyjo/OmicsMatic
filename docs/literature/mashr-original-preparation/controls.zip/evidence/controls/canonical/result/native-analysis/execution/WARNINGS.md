# Native mash development execution

DEVELOPMENT ONLY: native plain EM and explicit fully expanded models. PCA/extreme-deconvolution learning, public runtime/bundle admission and whole-paper reproduction are not provided by this executor.

- STRONG_POPULATION_RECORDED: strong rows are recorded, but this native execution uses only canonical or explicitly supplied covariance bases. It does not learn PCA/ED covariances.

- training-likelihood row 0: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 1: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 2: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 3: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 4: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 5: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 6: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 7: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 8: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 9: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 10: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 11: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 12: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 13: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 14: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 15: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 16: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 17: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 18: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 19: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 20: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 21: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 22: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 23: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 24: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 25: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 26: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 27: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 28: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 29: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 30: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 31: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 32: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 33: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 34: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 35: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 36: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 37: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 38: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 39: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 40: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 41: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 42: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 43: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 44: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 45: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 46: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 47: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 48: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 49: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 50: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 51: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 52: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 53: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 54: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 55: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 56: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 57: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 58: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 59: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 60: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 61: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 62: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 63: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 64: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 65: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 66: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 67: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 68: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 69: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 70: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 71: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 72: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 73: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 74: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 75: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 76: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 77: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 78: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 79: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 80: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 81: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 82: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 83: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 84: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 85: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 86: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 87: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 88: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 89: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 90: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 91: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 92: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 93: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 94: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 95: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 96: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 97: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 98: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 99: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.

- PROPORTION_ROUNDOFF: supplied sum=1.0000000000000004 was normalized within the admitted1e-10 simplex tolerance.
