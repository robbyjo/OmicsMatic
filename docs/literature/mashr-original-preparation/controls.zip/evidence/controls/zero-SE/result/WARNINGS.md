
# FAIL2: no result admitted

Original covariance preparation failed: FAIL2	typed-population-and-method-admission	Complete ordered effect/SE identities differ or SE are nonpositive Loading required package: ashr
FAIL2 ORIGINAL PREPARATION: Complete ordered effect/SE identities differ or SE are nonpositive 
 Required action: preserve all source inputs, outputs, logs and candidate covariances. SKIP3 skips unavailable exact dependencies. FAIL2 admits no result for invalid input, numerical, convergence or capacity failures. Correct the named cause and retry into a NEW output directory. No population truncation, jitter fallback or synthetic padding. This preparation stage alone does not admit an analysis; the parent workflow and native child require separate verification.; preserve full D:\projects\JLinAlg\build\literature-review\mashr-runtime\original-preparation-development-1\controls-3\zero-SE\result\preparation\original.stderr

Required action: preserve all inputs, partial downloads, installed files and logs. Missing/forbidden exact dependencies or monitoring capability are SKIP3: skip dependent analysis until permitted setup succeeds. Invalid input, integrity, process, convergence, capacity or cancellation errors are FAIL2: no result admitted. Correct the named cause and retry into NEW home/report/output paths. No edition substitution, user-library fallback or population truncation. Setup completion alone does not admit an analysis. Fingerprints establish integrity, not authenticity or source-to-binary reproduction.
