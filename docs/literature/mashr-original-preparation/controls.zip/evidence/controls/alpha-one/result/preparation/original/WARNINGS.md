# Original mashr preparation stage only
Status: 0
Phase: original-preparation-complete-awaiting-parent-and-native-verification
ORIGINAL_ED_EPSILON: cov_ed applies its own identity/sqrt(Nstrong) covariance addition (mashr issue91); retained as source method, not a generic numerical repair.
Required action: preserve all source inputs, outputs, logs and candidate covariances. SKIP3 skips unavailable exact dependencies. FAIL2 admits no result for invalid input, numerical, convergence or capacity failures. Correct the named cause and retry into a NEW output directory. No population truncation, jitter fallback or synthetic padding. This preparation stage alone does not admit an analysis; the parent workflow and native child require separate verification.
