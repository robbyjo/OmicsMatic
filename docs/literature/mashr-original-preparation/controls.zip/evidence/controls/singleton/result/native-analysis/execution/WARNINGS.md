# Native mash development execution

DEVELOPMENT ONLY: native plain EM and explicit fully expanded models. PCA/extreme-deconvolution learning, public runtime/bundle admission and whole-paper reproduction are not provided by this executor.

- STRONG_POPULATION_RECORDED: strong rows are recorded, but this native execution uses only canonical or explicitly supplied covariance bases. It does not learn PCA/ED covariances.

- training-likelihood row 0: PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- training-likelihood row 0: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.

- PROPORTION_ROUNDOFF: supplied sum=1.000000000000001 was normalized within the admitted1e-10 simplex tolerance.

- PRIOR_PRUNING: posterior summaries use only proportions strictly greater than0.0;full-mixture likelihoods retain all components.
