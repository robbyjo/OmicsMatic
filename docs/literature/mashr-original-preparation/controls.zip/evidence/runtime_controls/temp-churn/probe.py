import pathlib,time
p=pathlib.Path("churn");p.mkdir()
stop=time.monotonic()+2
while time.monotonic()<stop:
 f=p/"transient";f.write_bytes(b"x");f.unlink()
print("complete")
