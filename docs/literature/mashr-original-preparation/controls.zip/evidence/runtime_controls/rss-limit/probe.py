import subprocess,sys,time
p=subprocess.Popen([sys.executable,"-I","-B","-c","import time;time.sleep(30)"])
print(p.pid,flush=True)
time.sleep(30)
