# mashr SKIP3_DEPENDENCY_UNAVAILABLE

Require permitted Windows AMD64, CPython3.11+ and exact R4.6.1; this profile does not silently select another host or edition

Required action: preserve all inputs, partial downloads, installed files and logs. Missing/forbidden exact dependencies or monitoring capability are SKIP3: skip dependent analysis until permitted setup succeeds. Invalid input, integrity, process, convergence, capacity or cancellation errors are FAIL2: no result admitted. Correct the named cause and retry into NEW home/report/output paths. No edition substitution, user-library fallback or population truncation. Setup completion alone does not admit an analysis. Fingerprints establish integrity, not authenticity or source-to-binary reproduction.
