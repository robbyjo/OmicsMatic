# mashr FAIL2_NO_RUNTIME_ADMITTED

Existing exact cache file is corrupt; preserve it and select a NEW cache: D:\projects\JLinAlg\build\literature-review\mashr-runtime\original-preparation-development-1\runtime-controls-3\corrupt-cache\cache\Rcpp_1.1.2.zip

Required action: preserve all inputs, partial downloads, installed files and logs. Missing/forbidden exact dependencies or monitoring capability are SKIP3: skip dependent analysis until permitted setup succeeds. Invalid input, integrity, process, convergence, capacity or cancellation errors are FAIL2: no result admitted. Correct the named cause and retry into NEW home/report/output paths. No edition substitution, user-library fallback or population truncation. Setup completion alone does not admit an analysis. Fingerprints establish integrity, not authenticity or source-to-binary reproduction.
