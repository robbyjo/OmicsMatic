
# FAIL2: no result admitted

Noncanonical runtime/evidence path: D:\projects\JLinAlg\build\literature-review\mashr-runtime\original-preparation-development-1\controls-1\simple-null\result\native-scratch\omicsmatic-mash-verify-14888249865864452914\execution\model\component-36.tsv

Required action: preserve all inputs, partial downloads, installed files and logs. Missing/forbidden exact dependencies or monitoring capability are SKIP3: skip dependent analysis until permitted setup succeeds. Invalid input, integrity, process, convergence, capacity or cancellation errors are FAIL2: no result admitted. Correct the named cause and retry into NEW home/report/output paths. No edition substitution, user-library fallback or population truncation. Setup completion alone does not admit an analysis. Fingerprints establish integrity, not authenticity or source-to-binary reproduction.
