# Original mashr covariance preparation and native fitting

Only top-level COMPLETED.json plus successful parent --verify admits this declared
mixed workflow. Preparation uses original mashr0.2.79 canonical/uncentered PCA/Bovy
ED covariance functions with the explicit strong population. PCA initializes ED;
fitting receives canonical+ED bases. Original identity/sqrt(Nstrong) addition is
retained as a source method. No global ED optimum is certified; inspect ED logs.

The native child fits representative training rows by plain EM, with its own
dual-gap and ad-hoc residual rules. It is not upstream mixSQP/SQUAREM identity.
Read native-analysis/WARNINGS.md and native-analysis/execution/WARNINGS.md in full.
Read preparation/original/WARNINGS.md and METHOD-NOTES.txt for actual source
warnings, transformed-data scope and source residual initialization.
Strong rows recorded in that child were already used by original preparation;
the child does not relearn covariances. True singleton fitting is native; no rows
are padded or silently rerouted through broken original posterior wrappers.

Parent verify requires the exact permitted original Windows R profile and reruns
original covariance preparation plus the child's complete native verification.
The child can separately verify portably with Java. Runtime unavailability is
SKIP3, not evidence that an existing producer bundle is invalid. Producer paths
are recorded history; verification reads captured inputs and current explicit
runtime only. Native child completion alone admits its conditional supplied-basis
scope, not this parent preparation claim. Stage-only status records remain raw.

Numeric source tables compare with fixed absolute1e-9 plus relative1e-8 tolerance;
IDs, methods, RNG states, source code and file graphs are exact. Raw RDS, session
metadata, human logs and stdout/stderr are retained supplements, not interpreted
as executable analysis inputs or authenticated process history. ED numeric
likelihood history, all source covariance matrices, transformed strong data,
prepared native inputs and full native child analysis are checked. Hashes provide
integrity, not authenticity or source-to-binary reproduction. No whole-paper or
biological-accuracy certification. Sampling limits are not an OS sandbox.

Required action: preserve all inputs, partial downloads, installed files and logs. Missing/forbidden exact dependencies or monitoring capability are SKIP3: skip dependent analysis until permitted setup succeeds. Invalid input, integrity, process, convergence, capacity or cancellation errors are FAIL2: no result admitted. Correct the named cause and retry into NEW home/report/output paths. No edition substitution, user-library fallback or population truncation. Setup completion alone does not admit an analysis. Fingerprints establish integrity, not authenticity or source-to-binary reproduction.

Actual source covariance mode: canonical_pca_ed

# FAIL2: no result admitted

Parent verification failed; preserve scratch D:\projects\JLinAlg\build\literature-review\mashr-runtime\original-preparation-development-1\controls-1\omicsmatic-mashr-parent-verify-bl1w929c; source_unchanged=True; Noncanonical runtime/evidence path: D:\projects\JLinAlg\build\literature-review\mashr-runtime\original-preparation-development-1\controls-1\omicsmatic-mashr-parent-verify-bl1w929c\native-scratch\omicsmatic-mash-verify-6961764241632360481\execution\inputs\residual.tsv

Required action: preserve all inputs, partial downloads, installed files and logs. Missing/forbidden exact dependencies or monitoring capability are SKIP3: skip dependent analysis until permitted setup succeeds. Invalid input, integrity, process, convergence, capacity or cancellation errors are FAIL2: no result admitted. Correct the named cause and retry into NEW home/report/output paths. No edition substitution, user-library fallback or population truncation. Setup completion alone does not admit an analysis. Fingerprints establish integrity, not authenticity or source-to-binary reproduction.
