# FAIL2: original/native bridge validation incomplete

('canonical', 2)

Required action: preserve this attempt, inspect all original and native logs, correct the named failure and retry into a NEW directory. No partial validation passed.
