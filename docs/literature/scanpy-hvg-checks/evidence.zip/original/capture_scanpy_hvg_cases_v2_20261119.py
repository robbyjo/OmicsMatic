from pathlib import Path
import hashlib,importlib.metadata as md,json,math,sys,warnings

O=Path(sys.argv[1]);version=sys.argv[2];source=Path(sys.argv[3]);intake=json.loads(Path(sys.argv[4]).read_bytes());O.mkdir(exist_ok=False)
assert md.version('scanpy')==version
module=Path(md.distribution('scanpy').locate_file('scanpy/preprocessing/_highly_variable_genes.py'))
expected=intake['files'][version+'/scanpy/preprocessing/_highly_variable_genes.py']
assert dict(bytes=module.stat().st_size,sha256=hashlib.sha256(module.read_bytes()).hexdigest())==expected
import numpy as np,pandas as pd,scipy.sparse as sp,anndata as ad,scanpy as sc
if version=='1.13.0':sc.settings.preset='scanpy-v1'
sc.settings.n_jobs=1;sc.settings.verbosity=0
def number(x):
    x=float(x);return 'NaN' if math.isnan(x) else 'Infinity' if x==math.inf else '-Infinity' if x==-math.inf else x.hex()
def values(a):return [number(x) for x in np.asarray(a).ravel()]
def scalar(v):return float(v)
fixture=json.loads(source.read_bytes());matrices={m['id']:m for m in fixture['matrices']};options={m['id']:m for m in fixture['options']};cases=[]
for i,spec in enumerate(fixture['cases']):
    m=matrices[spec['matrix']];o=options[spec['option']];x=np.asarray(m['values'],dtype=np.float64);nc,nf=x.shape
    if spec['storage']=='dense':data=x.copy()
    elif spec['storage']=='csr':data=sp.csr_matrix(x)
    else:data=sp.csr_matrix((x.ravel().copy(),np.tile(np.arange(nf,dtype=np.int32),nc),np.arange(0,nc*nf+1,nf,dtype=np.int32)),shape=x.shape)
    record=dict(id=spec['id'],matrix=spec['matrix'])
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        try:
            a=ad.AnnData(data.copy(),**({'dtype':np.float64} if version=='1.9.3' else {}));a.obs_names=m['cells'];a.var_names=m['features']
            assert a.X.dtype==np.float64
            if m['log_base'] is not None:a.uns['log1p']={'base':m['log_base']}
            kwargs=dict(flavor=o['flavor'],n_top_genes=o['top'],n_bins=o['bins'],subset=False,
                min_mean=scalar(o.get('min_mean',.0125)),max_mean=scalar(o.get('max_mean',3)),
                min_disp=scalar(o.get('min_disp',.5)),max_disp=scalar(o.get('max_disp','Infinity')))
            if spec['batch']:
                categories=['Z','A','B'];a.obs['batch']=pd.Categorical([categories[c%3] for c in range(nc)],categories=categories)
                kwargs['batch' if version=='1.13.0' else 'batch_key']='obs.batch' if version=='1.13.0' else 'batch'
            if spec['filter'] is not None:kwargs['filter_unexpressed_genes']=spec['filter']
            kwargs['out' if version=='1.13.0' else 'inplace']=spec['export']=='dataframe' if version=='1.13.0' else spec['export']=='anndata'
            returned=sc.pp.highly_variable_genes(a,**kwargs)
            table=returned if spec['export']=='dataframe' else a.var
            record.update(status='original-returned',means=values(table['means']),dispersions=values(table['dispersions']),
                normalized=values(table['dispersions_norm']),selected=[bool(x) for x in table['highly_variable']],
                normalized_dtype=str(table['dispersions_norm'].dtype),feature_order=list(a.var_names),
                input_unchanged=bool(np.array_equal(a.X.toarray() if sp.issparse(a.X) else a.X,x)))
            if spec['batch']:record.update(batch_counts=[int(x) for x in table['highly_variable_nbatches']],intersection=[bool(x) for x in table['highly_variable_intersection']])
        except Exception as error:record.update(status='original-error',error_type=type(error).__name__,error=str(error))
    record['warnings']=[dict(category=w.category.__name__,message=str(w.message)) for w in caught];cases.append(record)
    if (i+1)%200==0:print(version,'completed',i+1,flush=True)
result=dict(status='PASS_CAPTURED_ORIGINAL_SCANPY_DISPERSION_HVG_CASES',scanpy_version=version,source=expected,
    versions={n:md.version(n) for n in ['scanpy','numpy','scipy','pandas','statsmodels','anndata']},
    fixture_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),cases=cases,source_patched=False,source_batch_accessor='obs.batch' if version=='1.13.0' else 'batch',whole_tool_qualified=False)
(O/'CASES.json').write_text(json.dumps(result,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
print(version,'cases',len(cases),'original returns',sum(c['status']=='original-returned' for c in cases),'errors',sum(c['status']=='original-error' for c in cases),flush=True)
