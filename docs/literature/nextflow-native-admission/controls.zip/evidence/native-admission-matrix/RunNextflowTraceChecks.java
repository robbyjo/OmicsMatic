import java.io.File;
import java.io.PrintWriter;
import org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder;
import org.junit.platform.launcher.core.LauncherFactory;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;
public final class RunNextflowTraceChecks {
 private RunNextflowTraceChecks() { }
 public static void main(String[] args)throws Exception {
  System.out.println("java.version="+System.getProperty("java.version"));System.out.println("os.name="+System.getProperty("os.name"));
  if(!System.getProperty("java.specification.version").equals(args[1]))throw new AssertionError("Wrong JVM");
  if(!Class.forName("org.jlinalg.cli.NextflowProcess").getProtectionDomain().getCodeSource().getLocation().toURI().equals(new File(args[0]).toURI()))throw new AssertionError("Wrong actual artifact");
  var listener=new SummaryGeneratingListener();LauncherFactory.create().execute(LauncherDiscoveryRequestBuilder.request().selectors(selectClass("org.jlinalg.workflow.NextflowTraceAuditTest"),selectClass("org.jlinalg.cli.NextflowProcessTest"),selectClass("org.jlinalg.cli.NextflowOriginalProcessTest"),selectClass("org.jlinalg.cli.NextflowRuntimeTest"),selectClass("org.jlinalg.cli.NextflowFilesTest"),selectClass("org.jlinalg.cli.NextflowParametersTest"),selectClass("org.jlinalg.cli.NextflowSetupTest")).build(),listener);var s=listener.getSummary();s.printTo(new PrintWriter(System.out));s.printFailuresTo(new PrintWriter(System.out));
  if(s.getTestsFoundCount()!=85||s.getTestsSucceededCount()!=85||s.getTestsSkippedCount()!=0||s.getTestsAbortedCount()!=0||s.getTestsFailedCount()!=0||s.getContainersFailedCount()!=0)throw new AssertionError("Incomplete native trace verification");
 }
}
