from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
BASE=Path('/mnt/d/projects/JLinAlg/build/literature-review/monocle-runtime');intake=BASE/'tpmcalculator-source-intake-1';out=Path('/opt/omicsmatic-tpmcalculator-original-20261115-2');out.mkdir(exist_ok=False)
for n in ['runtime','home','tmp','pixi-home','source-original','build-original']:(out/n).mkdir()
manifest='''[workspace]
name = "omicsmatic-tpmcalculator004-original-comparison"
channels = ["conda-forge", "bioconda"]
platforms = ["linux-64"]
[dependencies]
bamtools = "==2.5.2"
samtools = "==1.21"
gxx_linux-64 = "==7.5.0"
make = "*"
'''
(out/'runtime/pixi.toml').write_text(manifest)
profile=json.loads((intake/'SOURCE.json').read_bytes());original=out/'source-original/TPMCalculator';shutil.copytree(intake/'source-original',original)
for n,v in profile['regular_members'].items():
 raw=(original/n).read_bytes();assert len(raw)==v['bytes'] and hashlib.sha256(raw).hexdigest()==v['sha256'],n
manager='/mnt/d/projects/JLinAlg/build/literature-review/saige-runtime/pixi-bootstrap-1/pixi'
env=dict(HOME=str(out/'home'),TMPDIR=str(out/'tmp'),PATH='/usr/bin:/bin',PIXI_HOME=str(out/'pixi-home'),PIXI_CACHE_DIR='/root/.cache/rattler/cache',PIXI_NO_PROGRESS='true',PIXI_NO_PATH_UPDATE='1')
calls=[]
def run(name,command,cwd):
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:
  child=subprocess.Popen(list(map(str,command)),env=env,cwd=cwd,stdin=subprocess.DEVNULL,stdout=so,stderr=se)
  (out/(name+'-LIVE.json')).write_text(json.dumps(dict(pid=child.pid,command=list(map(str,command)))))
  while True:
   try:code=child.wait(timeout=15);break
   except subprocess.TimeoutExpired:print('SAME_ORIGINAL_TPMCALCULATOR_BUILD_CHILD_RUNNING',name,child.pid,flush=True)
 record=dict(command=list(map(str,command)),exit_code=code);calls.append(record);(out/(name+'-PROCESS.json')).write_text(json.dumps(record,indent=2)+'\n')
 if code:raise RuntimeError('Original step failed without changing source: '+name)
run('locked-dependencies',[manager,'install','--manifest-path',out/'runtime/pixi.toml'],out)
prefix=out/'runtime/.pixi/envs/default';env.update(PATH=str(prefix/'bin')+':/usr/bin:/bin',LD_LIBRARY_PATH=str(prefix/'lib'))
build=out/'build-original/TPMCalculator';shutil.copytree(original,build)
# Preserve the original make recipe, all translation units, optimization and C++14.
# Supply explicit compiler/include/library locations through documented make variables.
compiler=next(p for p in (prefix/'bin').glob('*-linux-gnu-g++'))
run('original-source-build',['make','-f','nbproject/Makefile-Release.mk','bin/TPMCalculator','-j2',
 'CCC='+str(compiler),'CXX='+str(compiler),'CXXFLAGS=-g -I'+str(prefix/'include/bamtools'),
 'LDLIBSOPTIONS=-L'+str(prefix/'lib')+' -Wl,-rpath,'+str(prefix/'lib')],build)
run('original-version',[build/'bin/TPMCalculator','-version'],out)
for n,v in profile['regular_members'].items():
 raw=(original/n).read_bytes();assert len(raw)==v['bytes'] and hashlib.sha256(raw).hexdigest()==v['sha256'],n
record=dict(status='PASS_SOURCE_BUILT_ORIGINAL_TPMCALCULATOR_TAG004_NOT_NATIVE_OR_PAPER_QUALIFICATION',commit=profile['commit'],tag='0.0.4',printed_version=(out/'original-version.stdout').read_text(),source_algorithms_patched=False,comparison_bamtools='2.5.2',runtime=str(out),binary=str(build/'bin/TPMCalculator'),calls=calls,new_integration_credit=0,whole_goal_complete=False)
(out/'COMPLETED.json').write_text(json.dumps(record,indent=2)+'\n');print(record['status'],record['printed_version'].strip(),flush=True)
