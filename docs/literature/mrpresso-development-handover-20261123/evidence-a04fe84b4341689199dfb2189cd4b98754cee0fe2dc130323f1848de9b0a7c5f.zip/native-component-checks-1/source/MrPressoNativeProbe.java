package org.jlinalg.mrpresso;
public final class MrPressoNativeProbe {
 public static void main(String[] args)throws Exception {
  var random=new MrPressoRandomTest();random.matchesOriginalR461UniformNormalsSamplingAndEveryContinuationState();random.explicitProfileAndStateAreRequiredAndDefensivelyCopied();
  new MrPressoOriginalTest().comparesWholeFiniteNativeAnalysisAndRngAgainstTwentyOriginalPublicApiReturns();
  System.out.println("PASS three component tests; twelve original R stream cases and25 original MR-PRESSO calls; Java="+System.getProperty("java.version")+"; OS="+System.getProperty("os.name"));
 }
}
