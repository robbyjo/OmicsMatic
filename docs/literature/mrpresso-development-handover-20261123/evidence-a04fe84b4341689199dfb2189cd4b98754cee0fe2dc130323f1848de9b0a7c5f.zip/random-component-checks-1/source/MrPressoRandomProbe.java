package org.jlinalg.mrpresso;
public final class MrPressoRandomProbe {
 public static void main(String[] args)throws Exception {
  var test=new MrPressoRandomTest();test.matchesOriginalR461UniformNormalsSamplingAndEveryContinuationState();test.explicitProfileAndStateAreRequiredAndDefensivelyCopied();
  System.out.println("PASS two component tests; twelve original R stream cases; Java="+System.getProperty("java.version")+"; OS="+System.getProperty("os.name"));
 }
}
