from pathlib import Path
import json,sys
ROOT=Path('D:/projects/JLinAlg');D=ROOT/'build/sa-1/build/skat-acat-1/source-discovery-1'
if len(sys.argv)==1:
    for row in json.loads((D/'CENSUS.json').read_bytes())['records']:
        print(row['identity']['paper_id'],[(u['tool_id'],u['paragraph_index']) for u in row['existing_tools']],[(p['paragraph_index'],p['matching_names']) for p in row['paragraphs']])
else:
    for arg in sys.argv[1:]:
        pid,_,indices=arg.partition(':');row=json.loads((D/'private-context'/(pid+'.json')).read_bytes());wanted=None if not indices else set(map(int,indices.split(',')))
        print('\nPAPER',pid,row['title'],row['identity']['doi'])
        for block in row['paragraphs']:
            if wanted is None or block['paragraph_index'] in wanted:print('PARAGRAPH',block['paragraph_index'],block['section'],'\n'+block['text'])
