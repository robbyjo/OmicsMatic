from pathlib import Path
import ast,json,re,subprocess,sys
from prepare_acat_skat_catalog_20261122_109 import R,T,O,BASE
from prepare_handover_qtltools_20261121_105 import pin,save,git,inventory
sys.path.insert(0,str(T/'tools/literature'))
from acat_skat_catalog import primary as p,model as m,evidence as e
from qtltools_catalog.catalog import read_before,zipped
from seurat_catalog.catalog import clean_manifest
B=T/'build/acat-skat-catalog-1';Q=T/e.FOLDER
def load(path):return json.loads(path.read_bytes())
if __name__=='__main__':
    for label in ['plan-2','inspect-2','apply-2','verify-2','verify-linux-1','preview-ui-2','installed-ui-2']:assert load(B/label/'PROCESS.json')['exit_code']==0,label
    for label in ['preview-ui-2','installed-ui-2']:
        assert load(B/label/'SERVER-CLOSED.json')['owned_helper_stopped'];result=load(B/label/'browser/COMPLETED.json');assert (result['integrations'],result['reviewed'],result['pending'])==(147,1661,1062) and len(result['paper_roles_checked'])==22
        log=(B/label/'server.log').read_text();assert '"GET /assets/styles.css HTTP/1.1" 200' in log and '"GET /assets/app.js HTTP/1.1" 200' in log,label
        start=load(B/label/'STARTED.json');assert start['source']==pin((T/'tools/literature/check_acat_skat_catalog_ui.cjs').read_bytes())
        for name,wanted in start['html'].items():assert pin((T/'site'/name).read_bytes())==wanted,(label,name)
    win=load(B/'verify-2/result/COMPLETED.json');lin=load(B/'verify-linux-1/result/COMPLETED.json');assert win['result']==lin['result'] and win['current_manifest']==lin['current_manifest'] and win['actual_owners_rechecked'] and not lin['actual_owners_rechecked'] and win['fresh_primary_audit'] and lin['fresh_primary_audit']
    proof=load(T/e.PROOF);before=read_before(Q/'metadata-before.zip');after={n:(T/n).read_bytes() for n in m.META};qualified=load(Q/'QUALIFICATION.json');result=m.check(before,after,p.frozen(),qualified['component']['result']);assert result==proof['result']==win['result'] and e.control_evidence()==qualified['controls']
    raw=before[m.META[5]];newline=b'\r\n' if b'\r\n' in raw else b'\n';closing=raw.rfind(newline+b'  ]');assert closing>0 and after[m.META[5]].startswith(raw[:closing]);lineage=dict(status='PASS_ALL1639_PREVIOUS_LEDGER_RECORD_BYTES_PRESERVED_AS_PREFIX',unchanged_prefix_bytes=closing,before=pin(raw),after=pin(after[m.META[5]]),reviews_appended=22)
    save(O/'LEDGER-LINEAGE.json',lineage);manifest=clean_manifest();assert manifest['entries']==847
    assert not git(T,'diff',BASE,'--','src/main','src/test','build.gradle','settings.gradle','gradle.properties','.github/workflows','site/assets')
    assert 'ignore_patterns("literature-review.html", "literature-warnings.html")' in (T/'.github/workflows/pages.yml').read_text()
    current=(T/'docs/literature/HANDOVER_CURRENT.md').read_bytes();old=git(T,'show',BASE+':docs/literature/HANDOVER_CURRENT.md');heading=b'# Current toolbox handover\n\n';assert current.startswith(heading) and current.endswith(old[len(heading):]) and pin(current)==load(O/'HANDOVER-PREPEND.json')['current']
    native=(T/'docs/literature/ACAT091_NATIVE.md').read_bytes();old=git(T,'show',BASE+':docs/literature/ACAT091_NATIVE.md');heading=b'# Native ACAT 0.91 matrix combination\n\n';assert native.startswith(heading) and native.endswith(old[len(heading):])
    links=[]
    for name in [m.GUIDE,'docs/literature/ACAT_SKAT_CATALOG_CHECKPOINT_2026-11-22.md','tools/literature/acat_skat_catalog/ADMISSION.md','docs/literature/ACAT091_NATIVE.md']:
        path=T/name
        for target in re.findall(r'\]\(([^)\s]+)\)',path.read_text(encoding='utf-8')):
            if target.startswith(('https:','http:','#')):continue
            assert (path.parent/target.split('#')[0]).resolve().is_file(),(name,target);links.append(dict(source=name,target=target))
    for path in (T/'tools/literature/acat_skat_catalog').glob('*.py'):ast.parse(path.read_text(encoding='utf-8'),filename=str(path))
    process=subprocess.run(['git','diff','--check'],cwd=T,capture_output=True);assert process.returncode==0,process.stdout+process.stderr
    inv=inventory();states=load(O/'WORKTREES-BEFORE.json');assert len(states)==65
    for i,state in enumerate(states,1):
        assert inv.snapshot(Path(state['root']))==state,state['root']
        if i%20==0:print('Prior owners exact',i,'/65',flush=True)
    save(O/'PRESERVATION-FINAL.json',dict(status='PASS_ALL65_PRIOR_OWNERS_EXACT',owners=65,current_owner=66,qualified_native_source_and_JAR_unchanged=True,current_manifest=manifest))
    receipts={}
    for label in ['plan-1','inspect-1','plan-2','inspect-2','apply-2','verify-2','verify-linux-1','preview-ui-1','preview-ui-2','installed-ui-2']:
        names=['STARTED.json','PROCESS.json','stdout','stderr']
        if 'ui-' in label:names+=['SERVER-CLOSED.json','server.log','browser/COMPLETED.json','browser/desktop.png','browser/mobile.png']
        if label in ['inspect-1','inspect-2','apply-2','verify-2','verify-linux-1']:names+=['result/COMPLETED.json']
        for name in names:receipts[label+'/'+name]=(B/label/name).read_bytes()
    for host in ['windows','linux']:
        for attempt in [1,2]:
            folder=B/('fresh-source-'+host+'-'+str(attempt))
            for name in ['STARTED.json','PROCESS.json','stdout','stderr','result/RESULT.json']:receipts['historical/'+folder.name+'/'+name]=(folder/name).read_bytes()
    for name in ['source-refusal-inputs/INPUT-PINS.json','supplement-inspection-2/RESULT.json','source-freeze-2/RESULT.json']:receipts[name]=(B/name).read_bytes()
    for name in ['LEDGER-LINEAGE.json','PRESERVATION-FINAL.json','HANDOVER-PREPEND.json']:receipts['publication/'+name]=(O/name).read_bytes()
    for path in (R/'build').iterdir():
        if path.is_file() and path.name.endswith(('_20261122_109.py','_20261122_109.R')):receipts['orchestration/'+path.name]=path.read_bytes()
    (Q/'validation.zip').write_bytes(zipped(receipts))
    checks=dict(status='PASS_ACAT_SKAT_CATALOG_INSTALLED_READBACK_AND_PUBLIC_HANDOVER',baseline=BASE,result=result,model_transaction_tests_each_host=32,actual_source_refusals_each_host=4,full_manifest=manifest,Windows_installed_verify=win,Linux_installed_verify=lin,styled_preview_and_installed_UI=True,unchanged_site_assets_served=True,first_spacing_preview_historical=True,private_primary_XML_PDF_text_renders_dependencies_and_binaries_excluded=True,private_transfer_completed=False,all65_prior_owners_preserved=True,current_owner=66,ledger_lineage=lineage,qualified_scientific_source_changed=False,original_models_refit_in_admission=False,relative_doc_links=links,validation_archive=pin((Q/'validation.zip').read_bytes()),validation_members={n:pin(v) for n,v in receipts.items()},whole_goal_complete=False)
    save(Q/'VALIDATION.json',checks);save(O/'VALIDATION.json',checks)
    fields=git(T,'status','--porcelain=v1','-z','--untracked-files=all').split(b'\0');files={}
    allowed=set(m.META)|{m.DATA+'/SHA256SUMS',e.PROOF,e.COMPAT,m.COVERAGE,m.GUIDE,'docs/literature/ACAT_SKAT_CATALOG_CHECKPOINT_2026-11-22.md','docs/literature/ACAT091_NATIVE.md','docs/literature/HANDOVER_CURRENT.md','tools/literature/audit_acat_skat_source_roles.py','tools/literature/close_acat_skat_catalog.py','tools/literature/check_acat_skat_catalog_ui.cjs'}
    prefixes=['tools/literature/acat_skat_catalog/',p.FOLDER+'/',e.FOLDER+'/',e.CONTROLS+'/','docs/literature/acat-skat-catalog-controls/']
    for field in fields:
        if not field:continue
        assert field[:2] in [b' M',b'??'],field
        name=field[3:].decode();assert name in allowed or any(name.startswith(prefix) for prefix in prefixes),name
        assert not name.endswith(('.pdf','.bam','.vcf','.xml','.whl','.exe','.jar','.class','.pyc')) and '__pycache__' not in name,name
        files[name]=pin((T/name).read_bytes())
    assert not any(name.startswith(('src/','.github/','build/')) for name in files)
    save(O/'PUBLICATION-FILES.json',dict(sorted(files.items())));(O/'PUBLICATION-PATHS.nul').write_bytes(b'\0'.join(n.encode() for n in sorted(files))+b'\0')
    print('PASS publication ready:',len(files),'bounded files;all65 prior owners preserved;147 families/1661 reviewed/1062 pending;goal unfinished',flush=True)
