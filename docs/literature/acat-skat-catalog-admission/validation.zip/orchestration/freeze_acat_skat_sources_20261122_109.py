import argparse,json,sys,traceback
from prepare_acat_skat_catalog_20261122_109 import R,T,O,BASE
from prepare_handover_qtltools_20261121_105 import pin,save
sys.path.insert(0,str(T/'tools/literature'))
from acat_skat_catalog import primary as p
B=T/'build/acat-skat-catalog-1';F=T/p.FOLDER
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--label',required=True);args=parser.parse_args();out=B/args.label;out.mkdir(parents=True)
    sources=['tools/literature/acat_skat_catalog/'+n for n in ['__init__.py','decisions.py','primary.py']]
    save(out/'STARTED.json',dict(source_inputs={n:pin((T/n).read_bytes()) for n in sources},manual_visual_pages=[31,32,36],canonical_modified=False))
    for name in sources:
        path=out/'source'/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes((T/name).read_bytes())
    F.mkdir(exist_ok=True);inspected=json.loads((B/'supplement-inspection-2/RESULT.json').read_bytes())
    aux=dict(pdf=inspected['pdf'],url=p.PDF_URL,pages_total=55,extractor_version='6.21.4',manual_visual_pages=[31,32,36],pages={n:{'text':r['text'],'image':r['image']} for n,r in inspected['pages'].items()},source_scope='Complete relevant pages read and rendered;no full text/images published. Uniform-weight choice and simulation context are established;ACAT edition is not.')
    if (F/'AUXILIARY.json').exists():assert json.loads((F/'AUXILIARY.json').read_bytes())==aux
    else:save(F/'AUXILIARY.json',aux)
    try:
        result=p.audit(R/'build/literature-review/xml',R/'build/qt-4/build/qtltools-catalog-1/auxiliary-intake-1/P190-mmc1.pdf')
        save(F/'CENSUS.json',result);save(F/'CENSUS-PIN.json',dict(census=pin((F/'CENSUS.json').read_bytes())))
        save(out/'RESULT.json',dict(status='PASS_FROZEN_ACAT_SKAT_SOURCE_ROLES',census=pin((F/'CENSUS.json').read_bytes()),roles=len(result['roles']),existing_uses_to_review=21,recovered_observations=1,new_family_credit=0,whole_goal_complete=False));print('PASS fresh250;19 candidates/95 paragraphs/one table;22 roles with one recovered SKATO;3PDF pages;no canonical mutation',flush=True)
    except Exception as error:
        save(out/'FAILURE.json',dict(error=repr(error),traceback=traceback.format_exc(),canonical_modified=False));raise
