import gzip,re,sys,xml.etree.ElementTree as ET
from prepare_acat_skat_catalog_20261122_109 import R,T
sys.path.insert(0,str(T/'tools/literature'))
from acat_skat_catalog.decisions import ROLES,PATTERNS
from gsea_catalog.primary import identities
from collect_omics_review import paragraphs
for spec in ROLES:
    identity=next(r for r in identities() if r['paper_id']==spec['paper_id']);blocks={b['paragraph_index']:b for b in paragraphs(ET.fromstring(gzip.decompress((R/'build/literature-review/xml'/(identity['pmcid']+'.xml.gz')).read_bytes())))}
    for n in spec['paragraphs'][1:]:
        b=blocks[n]
        if n not in spec['linked_details'] and not re.search(PATTERNS[spec['tool_id']],b.get('match_text',b['text']),re.I):print('UNNAMED',spec['paper_id'],spec['tool_id'],n,b['text'])
