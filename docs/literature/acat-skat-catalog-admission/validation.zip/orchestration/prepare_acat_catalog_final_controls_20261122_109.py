import sys
from prepare_acat_skat_catalog_20261122_109 import T
from prepare_handover_qtltools_20261121_105 import save
sys.path.insert(0,str(T/'tools/literature'))
from acat_skat_catalog import evidence as e
B=T/'build/acat-skat-catalog-1';save(B/'CONTROL-SOURCE-3.json',e.sources())
old=T/'docs/literature/acat-skat-catalog-controls';(old/'HISTORICAL.md').write_text('Historical passing controls before notice-spacing changes. Retain all original bytes. The current admission uses acat-skat-catalog-controls-v2 and fresh source/test attempts3. No scientific behavior changed.\n',encoding='utf-8')
