import subprocess
from prepare_acat_skat_catalog_20261122_109 import R,T,O,BASE
from prepare_handover_qtltools_20261121_105 import save,pin
B=T/'build/acat-skat-catalog-1';D=B/'verify-linux-1';D.mkdir();bridge=B/'metadata-git-bridge';DEP=R/'build/qt-4/build/qtltools-catalog-1/pdf-reader-dependency-1/python'
def mount(path):return '/mnt/d/'+path.relative_to(R.anchor).as_posix()
command=['wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','-u','root','--','env','PATH='+mount(bridge)+':/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin','PYTHONPATH='+mount(DEP),'python3','-B',mount(T/'tools/literature/close_acat_skat_catalog.py'),'--verify','--primary-cache',mount(R/'build/literature-review/xml'),'--supplement-pdf',mount(R/'build/qt-4/build/qtltools-catalog-1/auxiliary-intake-1/P190-mmc1.pdf'),'--out',mount(D/'result')]
save(D/'STARTED.json',dict(command=command,git_bridge=pin((bridge/'git').read_bytes()),scope='Linux Python installed readback and fresh source audit;Windows Git reads Windows-owned worktree metadata only. Original-host immutable owner checks are separately repeated on Windows. No scientific model refit.'))
with (D/'stdout').open('xb') as stdout,(D/'stderr').open('xb') as stderr:p=subprocess.run(command,cwd=T,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=300)
save(D/'PROCESS.json',dict(exit_code=p.returncode));print('Linux installed verify',p.returncode);print((D/'stdout').read_text() if p.returncode==0 else (D/'stderr').read_text()[-5000:]);raise SystemExit(p.returncode)
