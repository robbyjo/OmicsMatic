import importlib.util,json
from prepare_acat_skat_catalog_20261122_109 import R,T,O,BASE
from prepare_handover_qtltools_20261121_105 import pin,save
B=T/'build/acat-skat-catalog-1';D=B/'supplement-inspection-1';P=R/'build/qt-4/build/qtltools-catalog-1/auxiliary-intake-1/P190-mmc1.pdf'
if __name__=='__main__':
    D.mkdir(parents=True);raw=P.read_bytes();assert pin(raw)==dict(bytes=3125933,sha256='468d4018f261f438654d873b539952dd157417910844d68de34be68e5d3678f0')
    import pypdf,fitz
    assert pypdf.__version__=='6.21.4';reader=pypdf.PdfReader(P);doc=fitz.open(P);assert len(reader.pages)==len(doc)==55
    result={}
    for n in [31,32,36]:
        text=reader.pages[n-1].extract_text();(D/f'page{n}.txt').write_bytes(text.encode());doc[n-1].get_pixmap(matrix=fitz.Matrix(1.3,1.3)).save(D/f'page{n}.png');result[str(n)]=dict(text=pin(text.encode()),image=pin((D/f'page{n}.png').read_bytes()))
        print('PDF PAGE',n,'\n'+text)
    save(D/'RESULT.json',dict(status='PINNED_COMPLETE_PAGES_EXTRACTED_AND_RENDERED_FOR_PRIVATE_INSPECTION',pdf=pin(raw),extractor=pypdf.__version__,renderer=fitz.VersionBind,pages=result,full_text_published=False))
