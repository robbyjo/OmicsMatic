import json,sys
from prepare_acat_skat_catalog_20261122_109 import R,T
from prepare_handover_qtltools_20261121_105 import save
sys.path.insert(0,str(T/'tools/literature'))
from acat_skat_catalog import evidence as e
B=T/'build/acat-skat-catalog-1';D=B/'failed-control-sources-1';D.mkdir()
for name in e.OWN:
    path=D/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes((T/name).read_bytes())
(D/'run_checks_original.py').write_bytes((R/'build/run_acat_catalog_checks_20261122_109.py').read_bytes())
save(D/'RETAINED.json',dict(source_code=e.sources(),windows='32 tests;one test error because an unrelated historical observation legitimately lacks extraction_score. Canonical data unchanged.',linux='Six transaction tests passed;model setup failed because native Linux Git cannot read the Windows-owned worktree pointer. Canonical data unchanged.',source_audits='Both first fresh XML/PDF audits passed before these test/infrastructure corrections;retain their source scope as historical.',whole_goal_complete=False))
