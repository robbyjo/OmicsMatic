import gzip,json,sys
from prepare_acat_skat_catalog_20261122_109 import R,T,O,BASE
from prepare_handover_qtltools_20261121_105 import pin,save
sys.path.insert(0,str(T/'tools/literature'))
from acat_skat_catalog import primary as p,evidence as e
B=T/'build/acat-skat-catalog-1'
if __name__=='__main__':
    bad=B/'source-refusal-inputs';bad.mkdir();changed=bad/'changed-cache';changed.mkdir();first=p.identities()[0];raw=gzip.compress(b'<article>deliberately changed synthetic refusal fixture</article>',mtime=0);(changed/(first['pmcid']+'.xml.gz')).write_bytes(raw);(bad/'wrong.pdf').write_bytes(b'deliberately changed private PDF refusal fixture')
    save(bad/'INPUT-PINS.json',dict(changed_xml=pin(raw),changed_pdf=pin((bad/'wrong.pdf').read_bytes()),target_identity=first,scientific_model_inputs=False))
    save(B/'CONTROL-SOURCE.json',e.sources());print('PASS control source pinned;refusals target first frozen XML and exact P190 PDF guards')
