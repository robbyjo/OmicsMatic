import gzip,importlib.util,json,sys,xml.etree.ElementTree as ET
from prepare_acat_skat_catalog_20261122_109 import R,T,O,BASE
from prepare_handover_qtltools_20261121_105 import pin,save
sys.path.insert(0,str(T/'tools/literature'))
from gsea_catalog.primary import identities
from collect_omics_review import paragraphs
B=T/'build/acat-skat-catalog-1'
if __name__=='__main__':
    for arg in sys.argv[1:]:
        pid,_,indices=arg.partition(':');identity=next(r for r in identities() if r['paper_id']==pid);raw=gzip.decompress((R/'build/literature-review/xml'/(identity['pmcid']+'.xml.gz')).read_bytes());assert pin(raw)['sha256']==identity['xml_sha256']
        blocks={b['paragraph_index']:b for b in paragraphs(ET.fromstring(raw))};print('\nPAPER',pid)
        for n in map(int,indices.split(',')):
            b=blocks[n];print('PARAGRAPH',n,b['section'],'SHA256',pin(b['text'].encode())['sha256'],'\n'+b['text'])
