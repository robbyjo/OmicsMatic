import json,sys
from prepare_acat_skat_catalog_20261122_109 import T
sys.path.insert(0,str(T/'tools/literature'))
from qtltools_catalog.model import registry
if __name__=='__main__':
    for row in registry():
        if row['id'] in ['skat','skato','acat']:print(json.dumps(row,indent=2))
    inv=json.loads((T/'docs/literature/omics-2023-2026/tool-inventory.json').read_bytes())
    for row in inv:
        if row['id'] in ['skat','skato','acat']:print(json.dumps({k:v for k,v in row.items() if k not in ['paper_role_qualification']},indent=2))
