import hashlib,json,shutil,subprocess
from prepare_acat_skat_catalog_20261122_109 import R,T,O,BASE
from prepare_handover_qtltools_20261121_105 import pin,save
B=T/'build/acat-skat-catalog-1';D=B/'supplement-inspection-2';P=R/'build/qt-4/build/qtltools-catalog-1/auxiliary-intake-1/P190-mmc1.pdf'
if __name__=='__main__':
    D.mkdir(parents=True);raw=P.read_bytes();assert pin(raw)==dict(bytes=3125933,sha256='468d4018f261f438654d873b539952dd157417910844d68de34be68e5d3678f0')
    import pypdf
    assert pypdf.__version__=='6.21.4';reader=pypdf.PdfReader(P);assert len(reader.pages)==55;renderer=shutil.which('pdftoppm');assert renderer
    result={}
    for n in [31,32,36]:
        text=reader.pages[n-1].extract_text();(D/f'page{n}.txt').write_bytes(text.encode());command=[renderer,'-f',str(n),'-l',str(n),'-singlefile','-r','105','-png',str(P),str(D/f'page{n}')]
        with (D/f'page{n}.stdout').open('xb') as stdout,(D/f'page{n}.stderr').open('xb') as stderr:p=subprocess.run(command,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=120)
        assert p.returncode==0;result[str(n)]=dict(text=pin(text.encode()),image=pin((D/f'page{n}.png').read_bytes()),render_command=command,render_exit_code=p.returncode)
    save(D/'RESULT.json',dict(status='PINNED_COMPLETE_PAGES_EXTRACTED_AND_RENDERED_FOR_PRIVATE_INSPECTION',pdf=pin(raw),extractor=pypdf.__version__,renderer=renderer,pages=result,full_text_published=False))
    print('PASS complete P190 pages31,32,36 extracted and rendered privately;exact input PDF/source retained',flush=True)
