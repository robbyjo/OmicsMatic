import sys
from prepare_acat_skat_catalog_20261122_109 import T
from prepare_handover_qtltools_20261121_105 import save
sys.path.insert(0,str(T/'tools/literature'))
from acat_skat_catalog import evidence as e
B=T/'build/acat-skat-catalog-1';D=B/'controls2-source-snapshot';D.mkdir()
for name in e.OWN:
    path=D/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes((T/name).read_bytes())
save(D/'HISTORICAL.json',dict(source_code=e.sources(),scope='Passing32+4 controls per host,source audits,plan/inspect and semantic UI checks before notice spacing was improved. Scientific and source interpretations are unchanged. Preserve exact prior packet/source;current qualification uses the later source and NEW attempts.'))
