import argparse,json,subprocess
from prepare_acat_skat_catalog_20261122_109 import R,T,O,BASE
from prepare_handover_qtltools_20261121_105 import save
B=T/'build/acat-skat-catalog-1';PY='C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('phase',choices=['plan','inspect','apply','verify']);parser.add_argument('--attempt',type=int,default=1);args=parser.parse_args();D=B/(args.phase+'-'+str(args.attempt));D.mkdir()
    command=[PY,'-X','utf8','-B',str(T/'tools/literature/close_acat_skat_catalog.py'),'--'+args.phase,'--out',str(D/'result'),'--primary-cache',str(R/'build/literature-review/xml'),'--supplement-pdf',str(R/'build/qt-4/build/qtltools-catalog-1/auxiliary-intake-1/P190-mmc1.pdf'),'--checks-root',str(B)]
    if args.phase in ['inspect','apply']:command+=['--plan-dir',str(B/('plan-'+str(args.attempt))/'result')]
    save(D/'STARTED.json',dict(command=command))
    with (D/'stdout').open('xb') as stdout,(D/'stderr').open('xb') as stderr:p=subprocess.run(command,cwd=T,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=300)
    save(D/'PROCESS.json',dict(exit_code=p.returncode));print(args.phase,p.returncode,flush=True);print((D/'stdout').read_text() if p.returncode==0 else (D/'stderr').read_text()[-5000:]);raise SystemExit(p.returncode)
