import json,sys
from prepare_acat_skat_catalog_20261122_109 import R,T,O,BASE
from prepare_handover_qtltools_20261121_105 import pin,save
sys.path.insert(0,str(T/'tools/literature'))
from acat_skat_catalog import evidence as e
from qtltools_catalog.catalog import zipped
B=T/'build/acat-skat-catalog-1';Q=T/e.CONTROLS
if __name__=='__main__':
    assert json.loads((B/'CONTROL-SOURCE-3.json').read_bytes())==e.sources();Q.mkdir();files={}
    for host in ['windows','linux']:
        folder=B/('catalog-controls-'+host+'-3');result=json.loads((folder/'RESULT.json').read_bytes());assert result['model_transaction_tests']==32 and result['all_source_refusals_passed']
        for path in folder.rglob('*'):
            assert not path.is_symlink()
            if path.is_file():files[host+'/'+path.relative_to(folder).as_posix()]=path.read_bytes()
        failed=B/('catalog-controls-'+host+'-1')
        for path in failed.rglob('*'):
            if path.is_file():files['historical/'+host+'-1/'+path.relative_to(failed).as_posix()]=path.read_bytes()
    for folder,label in [(B/'failed-control-sources-1','historical/source-1'),(B/'source-freeze-1/source','historical/first-source-freeze'),(B/'controls2-source-snapshot','historical/passing-source-2')]:
        for path in folder.rglob('*'):
            if path.is_file():files[label+'/'+path.relative_to(folder).as_posix()]=path.read_bytes()
    files['historical/source-freeze-1-FAILURE.json']=(B/'source-freeze-1/FAILURE.json').read_bytes()
    files['metadata-git-bridge/git']=(B/'metadata-git-bridge/git').read_bytes();files['metadata-git-bridge/SCOPE.json']=(B/'metadata-git-bridge/SCOPE.json').read_bytes()
    (Q/'.gitattributes').write_bytes(b'* -text whitespace=cr-at-eol\n');(Q/'checks.zip').write_bytes(zipped(files))
    save(Q/'CONTROL-CHECKS.json',dict(status='PASS_ACAT_SKAT_CATALOG_MODEL_TRANSACTION_AND_SOURCE_REFUSALS',tests_each_host=32,source_refusals_each_host=4,source_code=e.sources(),members={n:pin(raw) for n,raw in files.items()},historical_failures_retained=True,scientific_models_executed=False))
    (Q/'README.md').write_text('''# ACAT/SKAT catalog controls

Each current host passed32 model/transaction tests and four actual source
refusals. Missing XML/PDF yields SKIP3; changed source bytes yield FAIL2 for the
intended identity. Complete process logs and source are retained in checks.zip.
Linux Python uses Windows Git interop solely for this Windows-owned worktree's
metadata; source extraction and scientific behavior are unchanged.

The first Windows32-test run had one test error because some unrelated older
observations legitimately omit extraction_score. The corrected check preserves
both absence and value, rather than inventing that field. The first Linux model
setup used native Git against a Windows worktree pointer and failed; its six
transaction tests passed. Both failures and full source remain historical and
unadmitted. The initial source freeze also refused a SKAT-O-only supporting
paragraph for the separate SKAT package role; that unsupported link was removed.
No canonical metadata changed in these failed attempts.
''',encoding='utf-8',newline='\n')
    assert e.control_evidence()['tests_each_host']==32;print('PASS complete32+4 controls each host sealed;failed attempts and exact source retained',flush=True)
