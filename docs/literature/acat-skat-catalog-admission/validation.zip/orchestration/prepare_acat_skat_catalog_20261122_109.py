from pathlib import Path
import json,subprocess
from prepare_handover_qtltools_20261121_105 import R,pin,save,git,inventory
T=R/'build/sa-2';O=R/'build/git-publish/20261122-acat-skat-catalog-109';BASE='f66c8e5e082d9a0f4fbc4c8bc22df705f325867a'
if __name__=='__main__':
    O.mkdir(parents=True)
    inv=inventory();states=[inv.snapshot(Path(block.splitlines()[0][9:])) for block in git(R,'worktree','list','--porcelain').decode().strip().split('\n\n')]
    assert len(states)==65;save(O/'WORKTREES-BEFORE.json',states);lookup={s['root']:s for s in states}
    for s in json.loads((O.parent/'20261122-skat-acat-108/WORKTREES-BEFORE.json').read_bytes()):assert lookup[s['root']]==s,s['root']
    assert lookup[str(R/'build/sa-1')]['head']==BASE and not lookup[str(R/'build/sa-1')]['files']
    assert git(R,'ls-remote','origin','refs/heads/main').decode().split()[0]==BASE
    command=['git','worktree','add','-b','codex/acat-skat-catalog-20261122',str(T),BASE];save(O/'WORKTREE-STARTED.json',dict(command=command))
    with (O/'worktree.stdout').open('xb') as stdout,(O/'worktree.stderr').open('xb') as stderr:p=subprocess.run(command,cwd=R,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=240)
    save(O/'WORKTREE-PROCESS.json',dict(exit_code=p.returncode));assert p.returncode==0
    print('PASS:new owner66;all65 preceding owners preserved',flush=True)
