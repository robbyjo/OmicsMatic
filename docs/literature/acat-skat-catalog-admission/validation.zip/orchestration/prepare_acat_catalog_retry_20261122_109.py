import sys
from prepare_acat_skat_catalog_20261122_109 import R,T
from prepare_handover_qtltools_20261121_105 import save,pin
sys.path.insert(0,str(T/'tools/literature'))
from acat_skat_catalog import evidence as e
B=T/'build/acat-skat-catalog-1';bridge=B/'metadata-git-bridge';bridge.mkdir();wrapper=bridge/'git';wrapper.write_bytes(b'#!/bin/sh\nexec "/mnt/c/Program Files/Git/cmd/git.exe" "$@"\n');wrapper.chmod(0o755)
save(B/'CONTROL-SOURCE-2.json',e.sources());save(bridge/'SCOPE.json',dict(wrapper=pin(wrapper.read_bytes()),scope='Windows Git interop solely reads metadata for this Windows-owned worktree;Linux Python model/source checks unchanged;no scientific engine replacement.'))
