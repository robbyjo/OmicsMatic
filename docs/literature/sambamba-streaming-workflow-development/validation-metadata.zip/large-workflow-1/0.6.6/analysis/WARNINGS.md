# Warnings and required actions

Streaming original Sambamba Linux x86-64 profile v2. Supply the exact
permitted0.6.6 or0.8.2 executable and all20 request fields. No software is
installed during analysis. Missing runtime/helper/library: SKIP3, skip
dependent analysis, supply the named permitted prerequisite and retry NEW
output. A wrong build or edition is FAIL2; no substitution is admitted.

Marking and optional removal execute original software on the same
captured input. Native Java checks all BGZF/BAM framing, raw records,
headers and retained removal records with bounded streaming memory.
It records transitions and source-defined metrics, not an independent
duplicate classification. VERIFY genuinely reruns the original classifier
and compares complete records and all header values except each checked
exact command string. A checksum or saved native audit alone is insufficient.

All six audit capacities are explicit: compressed/decoded bytes, records,
per-record/header/dictionary bytes. Counts are64-bit. Memory depends on
record/header/dictionary bounds and JVM needs, not total record count.
Decision rows stream to disk; partial ledgers are provisional until full
success. Never truncate data or split duplicate families to fit a limit.
Standard coordinate-sorted short-read BAM only; long-CIGAR CG and
nonstandard auxiliary types remain unsupported and are refused.

All files retain raw values/representations. Original0.8.2 writes VN:1.0;
preserve that value with its actual binary identity. Missing quality255
is not zero. Existing secondary/supplementary duplicate flags persist;
primary flags are recomputed. This is not UMI-aware marking. Original
tie/spill behavior remains original. P110/P198 author flags/builds remain
incompletely reported. No paper-specific parameters are inferred.

Generated BAI files are collateral without independent qualification.
Use a separately qualified indexer before index-dependent analysis.
Integrity/replay is not authenticity, a reproducible source build,
biological calibration or whole-tool/paper qualification. This profile
alone adds no catalog credit; the full250-paper objective remains open.

wall_ms applies per original mark/remove, including startup/PID recording.
Metadata probes have fixed10-second/512-MiB bounds. prlimit enforces
child RLIMIT_AS; setpriv requests parent-death KILL. Work bytes/entries
and RSS are sampled, not an OS disk quota or total JVM memory limit.
No network/filesystem isolation is claimed. Cancel the recorded Linux
JVM; Windows WSL-relay cancellation is not qualified by this notice.

Require COMPLETED.properties and successful genuine-runtime VERIFY.
FAIL2 admits no result: read FAILURE.txt, WARNINGS.md and phase consoles;
retain raw outputs/errors and correct the named cause before retrying NEW
output. Late completion markers are invalidated. Existing bundles are
never overwritten or repaired. Use the original v1 CLI/build for v1
bundles; profiles are distinct and their identities are not refreshed.
