from pathlib import Path
import concurrent.futures,hashlib,json,os,re,subprocess
R=Path('D:/projects/JLinAlg');B=R/'build/literature-review/fastp-runtime/workflow-development-1';O=B/'packaged-tests-2';O.mkdir()
jar=B/'package-3/omicsmatic-0.3.7-fastp-development.jar';assert jar.is_file();libs=sorted((R/'build/literature-review/shapeit-runtime/owned-common-native-matrix-4/lib').glob('*.jar'));assert len(libs)==9
runner=O/'RunFastpChecks.java';runner.write_text('''import java.io.PrintWriter;
import org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder;
import org.junit.platform.launcher.core.LauncherFactory;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;
public final class RunFastpChecks {
 private RunFastpChecks() { }
 public static void main(String[] args) {
  var request=LauncherDiscoveryRequestBuilder.request().selectors(selectClass("org.jlinalg.sequence.FastpReadFilterTest"),selectClass("org.jlinalg.cli.FastpFastqTest"),selectClass("org.jlinalg.cli.FastpRuntimeTest"),selectClass("org.jlinalg.cli.FastpParametersTest"),selectClass("org.jlinalg.cli.FastpProcessTest")).build();
  var listener=new SummaryGeneratingListener();LauncherFactory.create().execute(request,listener);
  listener.getSummary().printTo(new PrintWriter(System.out));listener.getSummary().printFailuresTo(new PrintWriter(System.out));
  if(listener.getSummary().getTestsFailedCount()>0||listener.getSummary().getTestsFoundCount()!=192)System.exit(1);
 }
}
''')
classes=O/'classes';classes.mkdir();j='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin';cp=os.pathsep.join(map(str,[jar,*libs]));sources=[runner,*sorted((R/'src/test/java/org/jlinalg/cli').glob('Fastp*Test.java')),R/'src/test/java/org/jlinalg/sequence/FastpReadFilterTest.java']
subprocess.run([j+'/javac.exe','--release','17','-Xlint:all','-Werror','-cp',cp,'-d',str(classes),*map(str,sources)],cwd=R,check=True)
linux=lambda p:'/mnt/d/'+p.relative_to(Path('D:/')).as_posix();entries=[classes,jar,R/'src/test/resources',*libs]
runs=[('windows-java21',[j+'/java.exe','-Xmx128m','-XX:ActiveProcessorCount=2','-cp',os.pathsep.join(map(str,entries)),'RunFastpChecks'],175,17),('windows-java25',['C:/Program Files/Common Files/Oracle/Java/javapath/java.exe','-Xmx128m','-XX:ActiveProcessorCount=2','-cp',os.pathsep.join(map(str,entries)),'RunFastpChecks'],175,17),('linux-java21',['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','env','JLINALG_FASTP_MANAGED_ROOT=/opt/omicsmatic-fastp-managed-1','JLINALG_FASTP_EVIDENCE_ROOT=/opt/omicsmatic-fastp-owned-stage-controls-1','/usr/bin/java','-Xmx128m','-XX:ActiveProcessorCount=2','-cp',':'.join(map(linux,entries)),'RunFastpChecks'],192,0)]
def execute(row):
 name,cmd,passed,aborted=row
 with (O/(name+'.stdout')).open('xb') as out,(O/(name+'.stderr')).open('xb') as err:p=subprocess.run(cmd,cwd=R,stdout=out,stderr=err,timeout=1800)
 record=dict(name=name,command=cmd,exit_code=p.returncode,tests_found=192,expected_passed=passed,expected_aborted_platform_controls=aborted);(O/(name+'.observed.json')).write_text(json.dumps(record,indent=2)+'\n')
 text=(O/(name+'.stdout')).read_text(errors='replace');print(name,p.returncode,text[-12000:] if p.returncode else text[-650:],flush=True)
 assert p.returncode==0
 for count,label in [(192,'tests found'),(passed,'tests successful'),(0,'tests failed'),(aborted,'tests aborted')]:assert re.search(r'\[\s*'+str(count)+' '+label+r'\s*\]',text),(name,label)
 return record
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:observed=list(pool.map(execute,runs))
record=dict(status='passed-actual-JAR-native-and-original-processing-stage-matrix',tests_found_per_JVM=192,runs=observed,artifact=jar.relative_to(R).as_posix(),artifact_sha256=hashlib.sha256(jar.read_bytes()).hexdigest(),heap_mib=128,strict_Java_release=17,linux_actual_original_stage_protocols=0,original_stage_evidence_retained_separately=True,all_owned_processes_terminal=True)
(O/'summary.json').write_text(json.dumps(record,indent=2)+'\n');print(record['status'])
