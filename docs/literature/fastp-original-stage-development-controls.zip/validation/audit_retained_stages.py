from pathlib import Path
from collections import Counter
import gzip,hashlib,json,zipfile
R=Path('/mnt/d/projects/JLinAlg');O=R/'build/literature-review/fastp-runtime/workflow-development-1';C=Path('/opt/omicsmatic-fastp-owned-stage-controls-1');G=R/'src/test/resources/org/jlinalg/sequence/fastp-original/native-controls.zip';sha=lambda raw:hashlib.sha256(raw).hexdigest();load=lambda p:json.loads(p.read_bytes())
def fq(raw):
 lines=raw.decode('ascii').splitlines();assert len(lines)%4==0;rows=[]
 for i in range(0,len(lines),4):assert lines[i].startswith('@') and lines[i+2]=='+' and len(lines[i+1])==len(lines[i+3]);rows.append((lines[i],lines[i+1],lines[i+3]))
 return rows
def stats(rows,offset):return dict(total_reads=len(rows),total_bases=sum(len(x[1]) for x in rows),q20_bases=sum(ord(q)-offset>=20 for x in rows for q in x[2]),q30_bases=sum(ord(q)-offset>=30 for x in rows for q in x[2]))
def expected_options(raw):
 lines=raw.decode().splitlines();c=dict(zip(lines[0].split('\t'),lines[1].split('\t')));n=lambda k:int(c[k]);b=lambda k:c[k]=='true';cut=lambda mode:dict(enabled=b(mode+'_on'),window=n(mode+'_window'),meanPhred=n(mode+'_quality'))
 return dict(threads=1,adapters=dict(enabled=False,detectPaired=False,read1='',read2=''),global_=dict(front1=n('front'),tail1=n('tail'),front2=0,tail2=0,maximum1=n('max_length'),maximum2=0),cutting=dict(front=cut('front'),right=cut('right'),tail=cut('tail')),filters=dict(qualityEnabled=b('quality_on'),qualifiedPhred=n('qualified'),unqualifiedPercent=n('unqualified_percent'),minimumAveragePhred=n('average'),maximumNs=n('maximum_n'),lengthEnabled=b('length_on'),minimumLength=n('minimum_length'),maximumLength=n('filter_max_length'),complexityEnabled=b('complexity_on'),minimumComplexityPercent=n('complexity_percent')),polyG='DISABLE',polyGMinimum=10,polyX=False,polyXMinimum=10,correction=False,duplication=dict(evaluate=False,deduplicate=False,accuracy=0),overlap=dict(minimumLength=30,maximumDifferences=5,maximumDifferencePercent=20),storeUnpaired=False)
def normalized_options(o):
 o=dict(o);o['global_']=o.pop('global');return o
def rc(seq):return seq.translate(str.maketrans('ACGT','TGCA'))[::-1]
counter=Counter();versions=Counter();seen=set();input_records=output_records=0;report_fields=0;manifest={};roots=sorted(C.iterdir());assert len(roots)==133
with zipfile.ZipFile(G) as gold:
 controls=json.loads(gold.read('summary.json'));mapping={}
 for case in controls['protocols']:
  prefix=case['version']+'/'+case['case']+'/';key=(case['version'],json.dumps(expected_options(gold.read(prefix+'options.tsv')),sort_keys=True));assert key not in mapping;mapping[key]=prefix
 for root in roots:
  result=root/'result';request=load(result/'request.json');version=request['profile'].removeprefix('linux-x86_64-fastp-');assert version in ['0.22.0','0.23.2','0.25.0','1.0.1']
  if root.name.startswith('memory-'):
   failure=load(result/'FAILURE.json');assert failure['status']=='SKIP3_PREREQUISITE_OR_CAPACITY_UNAVAILABLE' and not (result/'original').exists();assert request['options']['duplication']['accuracy']==6;counter['expected_prelaunch_accuracy6_skip']+=1;continue
  stage=load(result/'stage.json');assert stage['scientific_output_admitted'] is False and stage['status']=='ORIGINAL_PROCESSING_FINISHED_OUTPUT_AUDIT_PENDING';assert not (result/'COMPLETED.json').exists()
  p=result/'original';process=load(p/'process.json');assert process['status']=='completed-process-only' and process['exit_code']==0 and process['owned_live_after_cleanup']==[]
  captured=load(result/'input-captures.json');inspected=load(result/'input-statistics.json');runtime=load(result/'runtime-binding.json');assert runtime['profile']==request['profile'];before=[];offset=64 if request['encoding']=='PHRED64' else 33
  for index,entry in enumerate(captured):
   original=Path(entry['originalPath']).read_bytes();snapshot=(result/entry['snapshot']).read_bytes();assert original==snapshot;assert len(snapshot)==entry['identity']['pin']['bytes'] and sha(snapshot)==entry['identity']['pin']['sha256'];raw=gzip.decompress(snapshot) if snapshot.startswith(b'\x1f\x8b') else snapshot;rows=fq(raw);before+=rows
   values=stats(rows,offset);metadata=inspected['read'+str(index+1)];assert metadata['reads']==values['total_reads'] and metadata['bases']==values['total_bases'] and metadata['q20Bases']==values['q20_bases'] and metadata['q30Bases']==values['q30_bases']
  after=fq((p/'read1.fastq').read_bytes());after+=fq((p/'read2.fastq').read_bytes()) if len(captured)==2 else []
  reported=load(p/'fastp.json')['summary']
  for name,rows,encoding in [('before_filtering',before,offset),('after_filtering',after,33)]:
   for key,value in stats(rows,encoding).items():assert reported[name][key]==value,(root.name,name,key);report_fields+=1
  if root.name.startswith('case-'):
   key=(version,json.dumps(normalized_options(request['options']),sort_keys=True));prefix=mapping[key];assert prefix not in seen;seen.add(prefix)
   assert (p/'read1.fastq').read_bytes()==gold.read(prefix+'output.fq') and (p/'failed.fastq').read_bytes()==gold.read(prefix+'failed.fq');assert (result/captured[0]['snapshot']).read_bytes()==gold.read(prefix+'input.fq');counter['golden_filter_cutting_protocols']+=1
  elif root.name.startswith('paired-'):
   a=fq(Path(captured[0]['originalPath']).read_bytes());b=fq(Path(captured[1]['originalPath']).read_bytes());one=fq((p/'read1.fastq').read_bytes());two=fq((p/'read2.fastq').read_bytes());assert len(a)==len(b)==len(one)==len(two)==12
   for r1,r2,out1,out2 in zip(a,b,one,two):
    assert r1[0]==out1[0] and r2[0]==out2[0];assert r2[1].endswith('AGATCGGAAGAGCGTCGTGTAG');fragment=r2[1][:-len('AGATCGGAAGAGCGTCGTGTAG')];assert out1[1]==rc(fragment) and out2[1]==fragment;assert out1[2]==out2[2]=='I'*len(fragment)
   assert (p/'failed.fastq').read_bytes()==b'';counter['paired_adapter_and_correction_protocols']+=1
  elif root.name.startswith('encoded-'):
   assert len(before)==len(after)==1;assert before[0][:2]==after[0][:2];assert after[0][2]==''.join(chr(ord(x)-31) for x in before[0][2]);assert captured[0]['snapshot'].endswith('.gz');counter['gzip_phred64_protocols']+=1
  else:raise AssertionError(root.name)
  versions[version]+=1;input_records+=len(before);output_records+=len(after)
assert counter=={'golden_filter_cutting_protocols':124,'paired_adapter_and_correction_protocols':4,'gzip_phred64_protocols':4,'expected_prelaunch_accuracy6_skip':1};assert len(seen)==124 and versions=={'0.22.0':33,'0.23.2':33,'0.25.0':33,'1.0.1':33}
for path in sorted(C.rglob('*')):
 assert not path.is_symlink()
 if path.is_file():raw=path.read_bytes();manifest[path.relative_to(C).as_posix()]=dict(bytes=len(raw),sha256=sha(raw))
record=dict(status='passed-independent-full-retained-original-stage-audit',protocols=dict(counter),completed_original_stages=132,versions=dict(versions),input_read_records=input_records,output_read_records=output_records,independent_report_fields=report_fields,all_snapshots_match_original_bytes=True,all_owned_processes_terminal=True,scientific_completion_markers=0,whole_pipeline_output_admission_pending=True,files=len(manifest))
target=O/'owned-stage-controls-1.zip';assert not target.exists()
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
 for name in manifest:z.write(C/name,name)
 z.writestr('CAPTURE-MANIFEST.json',json.dumps(manifest,indent=2)+'\n');z.writestr('CAPTURE-SUMMARY.json',json.dumps(record,indent=2)+'\n')
record['artifact']=dict(path=target.name,bytes=target.stat().st_size,sha256=sha(target.read_bytes()));(O/'retained-stage-audit.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
