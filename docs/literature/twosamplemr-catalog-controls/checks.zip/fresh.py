import sys
from pathlib import Path
sys.path.insert(0,sys.argv[1])
from twosamplemr_catalog import primary as p
x=p.audit(Path(sys.argv[2]),Path(sys.argv[3]));assert x==p.frozen()
print('PASS fresh all250 source identities and9 pinned author files plus archived MR script; no author code executed')
