from pathlib import Path
import argparse,json,subprocess
R=Path('D:/projects/JLinAlg');T=R/'build/mo-7';O=R/'build/git-publish/20261121-monocle-response-99';B=T/'build/monocle-response-1'
def save(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('host',choices=['windows','linux']);args=p.parse_args();host=args.host;out=B/('saved-'+host+'-1')
    if host=='windows':command=['C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe','-X','utf8','-B',str(T/'tools/literature/monocle_responses/qualification/verify.py'),'--out',str(out),'--restore']
    else:command=['wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','-u','root','--','python3','-B','/mnt/d/projects/JLinAlg/build/mo-7/tools/literature/monocle_responses/qualification/verify.py','--out','/mnt/d/projects/JLinAlg/build/mo-7/build/monocle-response-1/saved-linux-1']
    save(O/('reader-'+host+'-STARTED.json'),dict(command=command))
    with (O/('reader-'+host+'.stdout')).open('xb') as stdout,(O/('reader-'+host+'.stderr')).open('xb') as stderr:proc=subprocess.run(command,cwd=T,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=300)
    save(O/('reader-'+host+'-PROCESS.json'),dict(exit_code=proc.returncode));print(host,'reader exit',proc.returncode,flush=True);print((out/'RESULT.json').read_text() if (out/'RESULT.json').exists() else (O/('reader-'+host+'.stderr')).read_text());raise SystemExit(proc.returncode)
