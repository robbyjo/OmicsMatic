from pathlib import Path
import hashlib,importlib.util,json,re,subprocess,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/mo-7';B=T/'build/monocle-response-1';O=R/'build/git-publish/20261121-monocle-response-99';Q=T/'docs/literature/monocle-response-checkpoint';BASE='1aeba2a01361746004818928b25d43701faa6fe9'
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
if __name__=='__main__':
    a=json.loads((B/'saved-windows-1/RESULT.json').read_bytes());b=json.loads((B/'saved-linux-1/RESULT.json').read_bytes());assert a.pop('restored') is True and b.pop('restored') is False and a==b
    inventory=json.loads((Q/'INVENTORY.json').read_bytes());assert len(inventory)==1820
    for name,wanted in inventory.items():assert pin((B/'saved-windows-1/restored'/name).read_bytes())==wanted,name
    controls=json.loads((O/'NEGATIVE-CONTROLS.json').read_bytes());assert len(controls['controls'])==3 and all(row['refused'] and row['exit_code']==2 for row in controls['controls'].values())
    profile=json.loads((Q/'PROFILE.json').read_bytes())
    for name,wanted in {**profile['source_inputs'],**profile['canonical_unchanged'],**profile['preceding_public_inputs']}.items():assert pin((T/name).read_bytes())==wanted,name
    for name,wanted in profile['packet_files'].items():assert pin((Q/name).read_bytes())==wanted,name
    old=subprocess.check_output(['git','show',BASE+':docs/literature/HANDOVER_CURRENT.md'],cwd=T);new=(T/'docs/literature/HANDOVER_CURRENT.md').read_bytes();heading=b'# Current toolbox handover\n\n';assert old.startswith(heading) and new.endswith(old[len(heading):])
    documents=[T/'docs/literature/MONOCLE_RESPONSES.md',T/'docs/literature/MONOCLE_RESPONSES_CHECKPOINT_2026-11-21.md',T/'tools/literature/monocle_responses/README.md',T/'examples/monocle-responses/README.md',Q/'README.md'];links=0
    for path in documents:
        for name in re.findall(r'\]\(([^)]+)\)',path.read_text(encoding='utf-8')):
            if ':' in name or name.startswith('#'):continue
            assert (path.parent/name.split('#',1)[0]).resolve().exists(),(str(path),name);links+=1
    spec=importlib.util.spec_from_file_location('inventory',O.parent/'20261115-all-main-3/inventory.py');inv=importlib.util.module_from_spec(spec);spec.loader.exec_module(inv);originals=json.loads((O/'WORKTREES-BEFORE.json').read_bytes())
    for state in originals:assert inv.snapshot(Path(state['root']))==state,state['root']
    files={}
    for name in ['run_monocle_response_reader_20261121_99.py','control_monocle_response_checkpoint_20261121_99.py','finalize_monocle_response_20261121_99.py']:files['orchestration/'+name]=R/'build'/name
    for host in ['windows','linux']:
        for suffix in ['-STARTED.json','-PROCESS.json','.stdout','.stderr']:files['reader-'+host+'/'+suffix.lstrip('-.')]=O/('reader-'+host+suffix)
        files['reader-'+host+'/RESULT.json']=B/('saved-'+host+'-1')/'RESULT.json'
    for label in controls['controls']:
        for name in ['STARTED.json','PROCESS.json','stdout','stderr','result/FAILURE.txt']:files['controls/'+label+'/'+name]=B/'checkpoint-controls-1'/label/name
    files['controls/RESULT.json']=O/'NEGATIVE-CONTROLS.json';members={}
    with zipfile.ZipFile(Q/'validation.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,path in sorted(files.items()):
            raw=path.read_bytes();info=zipfile.ZipInfo(name,(2026,11,21,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,raw);members[name]=pin(raw)
    result=dict(status='PASS_CURRENT_NATIVE_MONOCLE_RESPONSE_CHECKPOINT_POSTCHECKS',profile=pin((Q/'PROFILE.json').read_bytes()),saved_reader_hosts=['windows','linux'],evidence_members_restored_exact=1820,negative_controls=controls['controls'],original_worktrees_preserved=55,canonical_files_unchanged=30,prior_handover_content_retained_exact=True,relative_document_links_checked=links,normal_JAR=profile['normal_producer'],tests_per_packaged_JVM=889,packaged_JVMs=['windows21','windows25','linux21'],response_values_compared=984,admitted_original_gene_tests=54,original_fields_compared=378,retained_degenerate_family_refusals=3,original_source_gene_tests_retained=66,actual_global_stages=['GRAPH-1.0.0','NEIGHBORS-1.0.0','WEIGHTS-1.0.0','RESPONSES-1.0.0'],validation_archive=pin((Q/'validation.zip').read_bytes()),validation_members=members,whole_goal_complete=False,new_catalog_credit=0,website_published=False,release_published=False)
    save(Q/'VALIDATION.json',result);save(O/'VALIDATION.json',result);print('PASS1820 restored evidence members;3 scope refusals;55 original owners/30 canonical files preserved',flush=True)
