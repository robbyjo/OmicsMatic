from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/mo-7';O=R/'build/git-publish/20261121-monocle-response-99';B=T/'build/monocle-response-1/checkpoint-controls-1';Q='docs/literature/monocle-response-checkpoint';PY='C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def put(path,value):path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
def rebuild(root,logical,edit):
    folder=root/Q;inventory=json.loads((folder/'INVENTORY.json').read_bytes())
    with zipfile.ZipFile(folder/'checks.zip') as z:blobs={name:z.read(name) for name in z.namelist()}
    value=json.loads(blobs['blobs/'+inventory[logical]['sha256']]);edit(value);raw=(json.dumps(value,indent=2)+'\n').encode();wanted=pin(raw);inventory[logical]=wanted;blobs['blobs/'+wanted['sha256']]=raw
    needed={'blobs/'+row['sha256'] for row in inventory.values()}
    with zipfile.ZipFile(folder/'checks.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
        for name in sorted(needed):z.writestr(name,blobs[name])
    put(folder/'INVENTORY.json',inventory);profile=json.loads((folder/'PROFILE.json').read_bytes())
    for name in ['checks.zip','INVENTORY.json']:profile['packet_files'][name]=pin((folder/name).read_bytes())
    put(folder/'PROFILE.json',profile)
if __name__=='__main__':
    B.mkdir(parents=True,exist_ok=False);profile=json.loads((T/Q/'PROFILE.json').read_bytes());sources=set(profile['source_inputs'])|set(profile['canonical_unchanged'])|set(profile['preceding_public_inputs'])|{Q+'/'+name for name in profile['packet_files']}|{Q+'/PROFILE.json'};results={}
    for label,expected in [('source-tamper','Changed source/catalog/predecessor bytes'),('false66-matched-tests','Incomplete actual complete-response comparisons'),('degenerate-family-admitted','Degenerate family admitted')]:
        root=B/label/'checkout';root.mkdir(parents=True)
        for name in sources:
            target=root/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(T/name,target)
        if label=='source-tamper':
            path=root/'src/main/java/org/jlinalg/singlecell/MonocleResponsePreparation.java';path.write_bytes(path.read_bytes()+b'\n// owned changed source\n')
        elif label=='false66-matched-tests':rebuild(root,'current/live-2/RESULT.json',lambda row:row.update(admitted_original_gene_tests_compared=66))
        else:rebuild(root,'current/live-2/asis-plain/work/moran-greater/analysis.json',lambda row:row.update(result_admitted=True))
        command=[PY,'-X','utf8','-B',str(root/'tools/literature/monocle_responses/qualification/verify.py'),'--out',str(B/label/'result')];put(B/label/'STARTED.json',dict(command=command,expected_exit=2,expected_message=expected,owned_resealed_negative_control=True))
        with (B/label/'stdout').open('xb') as stdout,(B/label/'stderr').open('xb') as stderr:p=subprocess.run(command,cwd=root,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=120)
        put(B/label/'PROCESS.json',dict(exit_code=p.returncode));error=(B/label/'stderr').read_text(encoding='utf-8');assert p.returncode==2 and expected in error,(label,p.returncode,error);results[label]=dict(exit_code=2,expected_exit=2,expected_message=expected,refused=True);print('PASS refusal',label,flush=True)
    result=dict(status='PASS3_OWNED_RESPONSE_CHECKPOINT_TAMPER_AND_FALSE_ADMISSION_REFUSALS',controls=results,production_or_original_packet_modified=False,scientific_models_run=0);put(B/'RESULT.json',result);put(O/'NEGATIVE-CONTROLS.json',result)
