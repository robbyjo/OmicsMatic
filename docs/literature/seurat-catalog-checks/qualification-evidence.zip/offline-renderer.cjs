// Render two isolated public HTML copies over an inherited debugging pipe.
// No HTTP server, listening debugging port, downloads, or network-enabled context.
const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const {pathToFileURL} = require('node:url');
const A = 'D:/projects/JLinAlg/build/high-impact-stats-1';
const {chromium} = require(A + '/build/seurat-catalog-1/offline-browser-deps-1/playwright-core');
const out = path.join(A, 'build/seurat-catalog-1/offline-layout-3');
const fixture = path.join(A, 'build/seurat-catalog-1/offline-layout-2/public-only-inputs');
const names = ['literature-review.html', 'literature-warnings.html'];
async function pin(name) { const raw = await fs.readFile(name); return {bytes:raw.length,sha256:crypto.createHash('sha256').update(raw).digest('hex')}; }
(async()=>{
  await fs.mkdir(out);
  const browser = await chromium.launch({
    executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
    headless:true, chromiumSandbox:true, args:['--disable-background-networking','--disable-component-update','--disable-sync']
  });
  const allowed = new Set(names.map(n=>pathToFileURL(path.join(fixture,n)).href));
  const results = {};
  try {
    for (const [label,width,height] of [['desktop',1440,1000],['mobile',390,1800]]) {
      const context = await browser.newContext({viewport:{width,height},offline:true,acceptDownloads:false,serviceWorkers:'block'});
      await context.route('**/*',route=>allowed.has(route.request().url()) ? route.continue() : route.abort('blockedbyclient'));
      for (const name of names) {
        const page = await context.newPage();
        await page.goto(pathToFileURL(path.join(fixture,name)).href,{waitUntil:'load'});
        const metrics = await page.evaluate(()=>{
          const n = document.getElementById('seurat-catalog-notice');
          const r = n.getBoundingClientRect();
          return {viewport_width:innerWidth,viewport_height:innerHeight,first_body_element:document.body.firstElementChild.id,
            notice:{x:r.x,y:r.y,right:r.right,width:r.width,height:r.height,scroll_width:n.scrollWidth,client_width:n.clientWidth},
            text:n.innerText};
        });
        const r=metrics.notice;
        if (metrics.viewport_width!==width || metrics.first_body_element!=='seurat-catalog-notice' ||
            r.x<0 || r.right>width || r.scroll_width>r.client_width+1 ||
            !metrics.text.includes('Warnings and required actions:') || !metrics.text.includes('1,339') || !metrics.text.includes('131 new scoped')) {
          throw new Error('Notice layout/content failure: '+name+' '+label+' '+JSON.stringify(metrics));
        }
        delete metrics.text;
        const key=name.replace('.html','')+'-'+label;
        const png=path.join(out,key+'.png');
        await page.locator('#seurat-catalog-notice').screenshot({path:png});
        results[key]={metrics,screenshot:await pin(png)};
        process.stdout.write(key+': PASS exact '+width+'px viewport\n');
        await page.close();
      }
      await context.close();
    }
  } finally { await browser.close(); }
  const source_files={};
  for (const name of names) source_files['site/'+name]=await pin(path.join(A,'site',name));
  const report={status:'PASS_NEW_SEURAT_NOTICES_OFFLINE_DESKTOP_AND_MOBILE',source_files,results,
    scope:'New first-body Seurat notices only; full historical page layout/interactivity remain unqualified.',
    server_started:false,network_requests_allowed:false,private_worktree_served:false,debugging_transport:'inherited pipe; no listening port'};
  await fs.writeFile(path.join(out,'COMPLETED.json'),JSON.stringify(report,null,2)+'\n');
})().catch(async error=>{await fs.writeFile(path.join(out,'FAILURE.json'),JSON.stringify({error:String(error),stack:error.stack},null,2)+'\n');process.stderr.write(String(error)+'\n');process.exitCode=2;});
