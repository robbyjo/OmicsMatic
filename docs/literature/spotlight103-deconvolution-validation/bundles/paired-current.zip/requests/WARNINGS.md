Synthetic project-selected cells, spots and markers; not biological validation or author reproduction.
