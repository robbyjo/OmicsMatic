# Copyright (C) 2026 JLinAlg contributors; SPDX-License-Identifier: GPL-3.0-or-later
# Compare complete original returns, conditions/calls and RNG without numeric tolerances.
local({
 a<-commandArgs(TRUE);stopifnot(length(a)==5L);.libPaths(c(a[[1L]],.libPaths()))
 d<-a[[2L]];w<-a[[3L]];out<-a[[4L]];name<-a[[5L]]
 direct<-readRDS(file.path(d,'status.rds'));worker<-jsonlite::read_json(file.path(w,'R-status.json'),simplifyVector=TRUE)
 conditions<-readRDS(file.path(w,'complete-original-conditions.rds'))
 events<-Filter(function(x)x$phase=='ORIGINAL_ANALYSIS',conditions$conditions)
 checks<-list(returned=identical(direct$returned,worker$original_function_returned),
  error=identical(direct$error,conditions$error),complete_original_conditions=identical(direct$events,events),
  RNG_before=identical(readRDS(file.path(d,'rng-before.rds')),readRDS(file.path(w,'complete-original-rng-before.rds'))))
 if(direct$returned){
  checks$complete_return<-identical(readRDS(file.path(d,'return.rds')),readRDS(file.path(w,'complete-original-return.rds')))
  checks$complete_RNG<-identical(readRDS(file.path(d,'rng.rds')),readRDS(file.path(w,'complete-original-rng.rds')))
  if(name=='train.deconvolve')checks$complete_training_return<-identical(readRDS(file.path(d,'training-return.rds')),readRDS(file.path(w,'complete-original-training-return.rds')))
 }else checks$complete_failed_RNG<-identical(readRDS(file.path(d,'failed-rng.rds')),readRDS(file.path(w,'failed-original-rng.rds')))
 result<-list(status=if(all(unlist(checks)))'PASS_COMPLETE_ORIGINAL_SPOTLIGHT103_COMPARISON'else'FAIL2_ORIGINAL_SPOTLIGHT103_DIFFERENCE',case=name,returned=direct$returned,checks=checks,
  original_warnings=unname(vapply(Filter(function(x)x$kind=='warning',direct$events),function(x)x$message,character(1))),
  original_error=if(is.null(direct$error))NULL else conditionMessage(direct$error),whole_tool_qualified=FALSE,biological_accuracy_established=FALSE)
 jsonlite::write_json(result,out,pretty=TRUE,auto_unbox=TRUE,null='null',digits=17)
 if(!all(unlist(checks)))quit(save='no',status=2L,runLast=FALSE)
})
