from pathlib import Path
import csv,hashlib,json,math,os,subprocess
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');B=A/'build/coloc-high-impact-1';R=B/'original-reference-4';O=B/'native-reference-3';O.mkdir(exist_ok=False);classes=O/'probe-classes';classes.mkdir()
jar=B/'native-build-1/omicsmatic-0.4.0.jar';javac='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/javac.exe';java='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe';probe=A/'src/test/java/org/jlinalg/coloc/ColocAbfReferenceProbe.java'
command=[javac,'--release','17','-encoding','UTF-8','-cp',str(jar),'-d',str(classes),str(probe)];r=subprocess.run(command,cwd=A,capture_output=True,timeout=60);(O/'javac.stdout').write_bytes(r.stdout);(O/'javac.stderr').write_bytes(r.stderr);assert r.returncode==0,r.stderr
command=[java,'-Xmx512m','-cp',os.pathsep.join(map(str,[classes,jar])),'org.jlinalg.coloc.ColocAbfReferenceProbe',str(R/'inputs'),str(O/'native')];r=subprocess.run(command,cwd=A,capture_output=True,timeout=120);(O/'java.stdout').write_bytes(r.stdout);(O/'java.stderr').write_bytes(r.stderr);assert r.returncode==0,r.stderr
def table(p):
 with p.open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f,delimiter='\t'))
records=[];differences=[];compared=0;maxerr=0
for case in table(R/'inputs/cases.tsv'):
 name=case['name'];native=O/'native'/name;original=R/'original'/name;status=int((native/'STATUS.txt').read_text());expected=int(case['expected_native']);assert status==expected,(name,status,(native/'ERROR.txt').read_text() if (native/'ERROR.txt').exists() else '')
 row=dict(case=name,native_exit=status,original_status=(original/'STATUS.txt').read_text().strip())
 if status==0:
  for kind in ['summary','priors','variants']:
   source=table(original/(kind+'.tsv'));actual=table(native/(kind+'.tsv'));assert len(source)==len(actual),(name,kind)
   if kind=='variants':assert [r['snp'] for r in source]==[r['snp'] for r in actual],('source-order-or-identity',name,[r['snp'] for r in source],[r['snp'] for r in actual])
   for x,y in zip(source,actual,strict=True):
    for key in y:
     if key in ['snp','field']:assert x[key]==y[key];continue
     a,b=float(x[key]),float(y[key]);err=abs(a-b);tolerance=2e-12*max(1,abs(a))
     if not (a==b or math.isfinite(err) and err<=tolerance):differences.append(dict(case=name,kind=kind,key=key,original=a,native=b,error=err,tolerance=tolerance))
     if math.isfinite(err):maxerr=max(maxerr,err)
     compared+=1
 records.append(row)
result=dict(status='PASS_NATIVE_ABF_ORIGINAL_REFERENCE_CAMPAIGN' if not differences else 'FAILED_NATIVE_ABF_DIFFERENCES_RETAINED',cases=len(records),successful_cases=sum(r['native_exit']==0 for r in records),expected_refusals=sum(r['native_exit']==2 for r in records),compared_numeric_fields=compared,maximum_absolute_error=maxerr,differences=differences,records=records,new_family_credit=0,whole_goal_complete=False)
(O/'COMPLETED.json').write_bytes((json.dumps(result,indent=2,allow_nan=True)+'\n').encode());print(json.dumps(result),flush=True)
