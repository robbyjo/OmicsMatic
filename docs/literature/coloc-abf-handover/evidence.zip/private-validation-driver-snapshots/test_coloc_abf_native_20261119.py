from pathlib import Path
import json,os,subprocess,xml.etree.ElementTree as ET
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');B=A/'build/coloc-high-impact-1';O=B/'junit-qualification-2';O.mkdir(exist_ok=False);classes=O/'test-classes';classes.mkdir()
jar=B/'native-build-2/omicsmatic-0.4.0.jar';jdk=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin');junit=A/'build/nfcore-atacseq121-1/linux-test-runtime-1/junit-platform-console-standalone-1.13.4.jar'
sources=[A/'src/test/java/org/jlinalg/coloc/ColocAbfReferenceProbe.java',A/'src/test/java/org/jlinalg/coloc/ColocAbfTest.java',A/'examples/coloc-abf/NativeAbfExample.java']
cmd=[str(jdk/'javac.exe'),'--release','17','-encoding','UTF-8','-cp',os.pathsep.join(map(str,[jar,junit])),'-d',str(classes),*map(str,sources)]
r=subprocess.run(cmd,cwd=A,capture_output=True,timeout=120);(O/'javac.stdout').write_bytes(r.stdout);(O/'javac.stderr').write_bytes(r.stderr);assert r.returncode==0,r.stderr
jdk25=Path('C:/Program Files/Java/jdk-25/bin/java.exe');assert jdk25.exists()
def linux(p):return '/mnt/d/'+str(p).replace('\\','/').split(':/',1)[1]
basecp=[classes,jar,A/'src/test/resources']
hosts=[('windows21',[str(jdk/'java.exe'),'-Xmx512m','-jar',str(junit)],os.pathsep.join(map(str,basecp)),str(O/'windows21-reports')),
 ('windows25',[str(jdk25),'-Xmx512m','-jar',str(junit)],os.pathsep.join(map(str,basecp)),str(O/'windows25-reports')),
 ('linux21',['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/java','-Xmx512m','-jar',linux(junit)],':'.join(linux(p) for p in basecp),linux(O/'linux21-reports'))]
rows=[]
for name,prefix,cp,reports in hosts:
 cmd=prefix+['execute','--class-path',cp,'--select-class','org.jlinalg.coloc.ColocAbfTest','--reports-dir',reports,'--details','summary','--fail-if-no-tests']
 with (O/(name+'.stdout')).open('xb') as so,(O/(name+'.stderr')).open('xb') as se:r=subprocess.run(cmd,cwd=A,stdout=so,stderr=se,timeout=180)
 print(name,r.returncode,flush=True)
 report=O/(name+'-reports/TEST-junit-jupiter.xml');counts=dict(ET.parse(report).getroot().attrib) if report.exists() else {}
 rows.append(dict(host=name,exit_code=r.returncode,counts=counts))
 if r.returncode:print((O/(name+'.stdout')).read_text(errors='replace')[-4500:],flush=True);print((O/(name+'.stderr')).read_text(errors='replace')[-2000:],flush=True)
 cmd=([str(jdk/'java.exe'),'-cp',os.pathsep.join(map(str,[classes,jar])),'NativeAbfExample'] if name=='windows21' else None)
 if cmd:
  e=subprocess.run(cmd,cwd=A,capture_output=True,timeout=60);(O/'external-example.stdout').write_bytes(e.stdout);(O/'external-example.stderr').write_bytes(e.stderr);assert e.returncode==0
result=dict(status='PASS_NATIVE_ABF_JVM_REFERENCE_AND_BOUNDARY_TESTS' if all(r['exit_code']==0 for r in rows) else 'FAILED_RETAINED',records=rows,original_R_reexecuted=False,new_family_credit=0,whole_goal_complete=False)
(O/'COMPLETED.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(result),flush=True)
