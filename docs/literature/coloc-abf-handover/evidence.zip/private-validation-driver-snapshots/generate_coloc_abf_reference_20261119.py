from pathlib import Path
import copy,csv,json,os,subprocess,random
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');B=A/'build/coloc-high-impact-1';O=B/'original-reference-4';O.mkdir(exist_ok=False);inputs=O/'inputs';inputs.mkdir();out=O/'original';out.mkdir()
def est(ids=('b','a','c'),kind='quant',sdY=1):
 return dict(snp=list(ids),beta=[.1,.5,-.15][:len(ids)],varbeta=[.01,.01,.02][:len(ids)],type=kind,**({'sdY':sdY} if kind=='quant' and sdY is not None else {}))
def pv(kind='quant',ids=('b','a','c')):
 return dict(snp=list(ids),pvalues=[.01,1e-9,.9][:len(ids)],MAF=[.1,.2,.8][:len(ids)],N=1200,type=kind,**({'s':.25} if kind=='cc' else {}))
cases=[]
def case(name,first=None,second=None,expect=0,**options):
 cases.append(dict(name=name,first=copy.deepcopy(first if first is not None else est()),second=copy.deepcopy(second if second is not None else est()),expected_native=expect,options=options))
case('quant-known-sdy');case('case-control-estimates',est(kind='cc'),est(kind='cc'));case('quant-sdy-two',est(sdY=2),est(sdY=.5));case('mixed-estimates',est(),est(kind='cc'))
case('p-quant',pv(),pv());case('p-case-control',pv('cc'),pv('cc'));case('mixed-p-and-estimates',pv(),est(kind='cc'))
d=est(sdY=None);d.update(MAF=[.1,.2,.4],N=2000);case('estimated-sdy',d,est())
first=dict(snp=['d','a','b','c'],beta=[.1,.5,-.1,.3],varbeta=[.01,.02,.03,.04],MAF=[.1,.2,.3,.4],N=1000,type='quant')
second=dict(snp=['a','c','e','f','g'],beta=[.5,.3,0,0,.1],varbeta=[.02]*5,type='quant',sdY=1)
case('asymmetric-prior-adjustment',first,second,p1=.3,p2=.25,p12=.6)
first=est();second=est();first['position']=[2,1,3];second['position']=[2,9,3];case('position-mismatch',first,second)
second.pop('position');case('position-one-sided',first,second)
first=est();first['prior_weight']=[0,2,8];case('one-weight-vector',first,est())
second=est();second['prior_weight']=[3,1,4];case('both-weight-vectors',first,second)
first['prior_weight']=[0,0,0];case('all-zero-weights',first,est(),expect=2)
first['prior_weight']=[1,0,0];second['prior_weight']=[0,1,0];case('disjoint-weight-support',first,second,expect=2)
first=est();first['beta']=[0,8,0];first['varbeta']=[.0001]*3;case('strong-identical-signal',first,first)
first=pv();first['pvalues'][0]=5e-324;case('p-half-underflow',first,pv(),expect=2)
first=est(ids=('a',));case('single-variant',first,first)
first=est();first['beta']=[0,0,0];case('weak-association-warning',first,first)
case('shared-prior-above-marginal',est(),est(),p1=.0001,p2=.0002,p12=.003)
first=est();first['pvalues']=[1,1,1];case('estimates-take-precedence',first,est())
first=est();first['varbeta'][0]=0;case('zero-variance',first,est(),expect=2)
first=pv();first['pvalues'][0]=1.5;case('native-refuses-invalid-probability',first,pv(),expect=2)
first=est();second=est();first['position']=[1,2,3];second['position']=[4,5,6];case('no-common-position-key',first,second,expect=2)
first=dict(snp=['家族','😀','é','\ue000','a'],beta=[.1,.2,.3,.4,.5],varbeta=[.01]*5,type='quant',sdY=1);second=copy.deepcopy(first);second['snp']=list(reversed(first['snp']));second['beta']=list(reversed(first['beta']));case('unicode-identifiers-C-collation',first,second)
first=est();first['snp']=['a','a','c'];case('duplicate-id',first,est(),expect=2)
case('missing-quantitative-scale',est(sdY=None),est(),expect=2)
case('ignored-upstream-effect-priors',est(),est(),effect_prior_override=True)
first=est();first['prior_weight']=[1,100,2];second=est(ids=('c','b'));second['prior_weight']=[4,3];case('weights-normalize-after-intersection',first,second)
rng=random.Random(812739)
def scale(start,n):
 ids=['s'+str(i).zfill(5) for i in range(start,start+n)];rng.shuffle(ids)
 return dict(snp=ids,beta=[.6 if x=='s07500' else rng.gauss(0,.02) for x in ids],varbeta=[.01]*n,type='quant',sdY=1)
case('regional-scale-12000-10000',scale(0,12000),scale(4000,10000))
for item in cases:
 folder=inputs/item['name'];folder.mkdir()
 settings={**{k:str(v) for k,v in item['options'].items() if k!='effect_prior_override'},'effect_prior_override':str(item['options'].get('effect_prior_override',False))}
 for t,key in [(1,'first'),(2,'second')]:
  d=item[key];vectors={k:v for k,v in d.items() if isinstance(v,list)}
  for k,v in d.items():
   if not isinstance(v,list):settings[k+str(t)]=str(v)
  with (folder/('trait'+str(t)+'.tsv')).open('w',encoding='utf-8',newline='') as f:
   writer=csv.writer(f,delimiter='\t',lineterminator='\n');writer.writerow(vectors);writer.writerows(zip(*vectors.values(),strict=True))
 with (folder/'settings.tsv').open('w',encoding='utf-8',newline='') as f:
  writer=csv.writer(f,delimiter='\t',lineterminator='\n');writer.writerow(['key','value']);writer.writerows(settings.items())
with (inputs/'cases.tsv').open('w',encoding='utf-8',newline='') as f:
 writer=csv.writer(f,delimiter='\t',lineterminator='\n');writer.writerow(['name','expected_native']);writer.writerows((c['name'],c['expected_native']) for c in cases)
(O/'DESIGN.json').write_bytes((json.dumps(cases,indent=2,ensure_ascii=False)+'\n').encode())
script=r'''
args <- commandArgs(TRUE)
input <- args[1]; output <- args[2]; lib <- args[3]; deps <- args[4]; source <- args[5]
.libPaths(c(lib,deps,.libPaths()))
stopifnot(as.character(packageVersion("coloc"))=="6.0.3")
stopifnot(nzchar(Sys.setlocale("LC_CTYPE","English_United States.utf8")))
Sys.setlocale("LC_COLLATE","C")
original <- new.env(parent=globalenv())
sys.source(file.path(source,"R/claudia.R"),envir=original,keep.source=FALSE)
sys.source(file.path(source,"R/check.R"),envir=original,keep.source=FALSE)
for(n in c("coloc.abf","process.dataset","approx.bf.estimates","approx.bf.p","combine.abf","combine_abf_weighted","check_dataset"))
 stopifnot(identical(deparse(body(get(n,envir=asNamespace("coloc")))),deparse(body(get(n,envir=original)))))
writeLines(capture.output(sessionInfo()),file.path(output,"SESSION.txt"))
read <- function(p) read.delim(p,check.names=FALSE,stringsAsFactors=FALSE,encoding="UTF-8",comment.char="",quote="\"")
tab <- function(x,p) {
 for(n in names(x)) if(is.numeric(x[[n]])) x[[n]]<-sprintf("%.17g",x[[n]])
 write.table(x,p,sep="\t",row.names=FALSE,quote=TRUE,na="NA",fileEncoding="UTF-8")
}
cases <- read(file.path(input,"cases.tsv"))
for(name in cases$name) {
 cat("CASE ",name,"\n",sep=""); dest<-file.path(output,name);dir.create(dest)
 s<-read(file.path(input,name,"settings.tsv"));settings<-setNames(as.list(s$value),s$key)
 data<-lapply(1:2,function(t) {
  d<-read(file.path(input,name,paste0("trait",t,".tsv")))
  d$snp<-enc2utf8(as.character(d$snp)); result<-as.list(d[intersect(names(d),c("snp","beta","varbeta","pvalues","MAF","position"))])
  result$type<-settings[[paste0("type",t)]]
  for(k in c("N","sdY","s")) if(!is.null(settings[[paste0(k,t)]])) result[[k]]<-as.numeric(settings[[paste0(k,t)]])
  list(d=result,w=d$prior_weight)
 })
 warnings<-character();error<-NULL
 result<-tryCatch(withCallingHandlers({
  call<-list(dataset1=data[[1]]$d,dataset2=data[[2]]$d,prior_weights1=data[[1]]$w,prior_weights2=data[[2]]$w)
  for(k in c("p1","p2","p12")) if(!is.null(settings[[k]])) call[[k]]<-as.numeric(settings[[k]])
  if(identical(settings$effect_prior_override,"True")) call$effect_priors<-c(quant=.5,cc=.6)
  do.call(coloc::coloc.abf,call)
 },warning=function(w){warnings<<-c(warnings,conditionMessage(w));invokeRestart("muffleWarning")}),error=function(e){error<<-conditionMessage(e);NULL})
 writeLines(warnings,file.path(dest,"warnings.txt"))
 if(is.null(result)) {writeLines(c("ERROR",error),file.path(dest,"STATUS.txt"));next}
 saveRDS(result,file.path(dest,"original-result.rds"),version=3)
 tab(result$results,file.path(dest,"variants.tsv"))
 tab(data.frame(field=names(result$summary),value=as.numeric(result$summary)),file.path(dest,"summary.tsv"))
 tab(data.frame(field=names(result$priors),value=as.numeric(result$priors)),file.path(dest,"priors.tsv"))
 if(!is.null(result$weights)) {
  nonnull<-result$weights[!vapply(result$weights,is.null,logical(1))]
  tab(as.data.frame(nonnull),file.path(dest,"weights.tsv"))
 }
 finite<-all(is.finite(result$summary)) && all(is.finite(result$results$SNP.PP.H4))
 writeLines(if(finite) "FINITE" else "NONFINITE_NO_RESULT_ADMITTED",file.path(dest,"STATUS.txt"))
}
'''
rfile=O/'capture-original.R';rfile.write_bytes(script.encode())
source=B/'runtime-coloc603-1/source/coloc-27776b1bb14e19d1542798ac7477fa378fc2fc0d'
command=['C:/Program Files/R/R-4.6.1/bin/Rscript.exe','--vanilla',str(rfile),str(inputs),str(out),str(B/'runtime-coloc603-2/library'),str(B/'runtime-coloc603-1/library'),str(source)]
env=dict(os.environ,LC_ALL='C',LANG='C',LANGUAGE='en')
with (O/'R.stdout').open('xb') as so,(O/'R.stderr').open('xb') as se:r=subprocess.run(command,cwd=O,env=env,stdout=so,stderr=se,timeout=180)
print('ORIGINAL_R',r.returncode,flush=True)
if r.returncode:print((O/'R.stderr').read_text(errors='replace')[-4000:],flush=True)
statuses={c['name']:(out/c['name']/'STATUS.txt').read_text().strip() for c in cases if (out/c['name']/'STATUS.txt').exists()}
(O/'COMPLETED.json').write_bytes((json.dumps(dict(status='CAPTURED_PINNED_INSTALLED_COLOC603_ORIGINAL_FUNCTIONS' if r.returncode==0 and len(statuses)==len(cases) else 'FAILED_RETAINED',cases=len(cases),records=statuses,original_package_executed=True,selected_namespace_function_bodies_matched_source=True if r.returncode==0 else False,project_method_qualified=False,whole_goal_complete=False),indent=2)+'\n').encode())
print(json.dumps(statuses),flush=True)
