from pathlib import Path
import json,subprocess,time,hashlib
OUT=Path(__file__).resolve().parent
def linux(p):
 s=p.resolve().as_posix();return '/mnt/'+s[0].lower()+s[2:]
pixi=Path(r'D:/projects/JLinAlg/build/literature-review/saige-runtime/pixi-bootstrap-1/pixi')
command=['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/env','PIXI_CACHE_DIR='+linux(OUT/'private-cache'),linux(pixi),'install','--manifest-path',linux(OUT/'pixi.toml')]
started=time.monotonic()
with (OUT/'install.stdout').open('xb') as so,(OUT/'install.stderr').open('xb') as se:p=subprocess.run(command,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=3600)
a={'command':command,'exit_code':p.returncode,'seconds':round(time.monotonic()-started,3),'pixi_sha256':hashlib.sha256(pixi.read_bytes()).hexdigest()}
(OUT/'PROCESS.json').write_text(json.dumps(a,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(a));print((OUT/'install.stdout').read_text(errors='replace')[-2500:]);print((OUT/'install.stderr').read_text(errors='replace')[-3500:]);raise SystemExit(p.returncode)
