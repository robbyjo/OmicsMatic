# Warnings and required actions

Build current source and use ldpred2-tools. Missing permitted prerequisites require SKIP3 and skipping dependent analysis; forbidden installation stays skipped. FAIL2 admits no complete result. Retain raw inputs, original objects, source failures and historical evidence; retry NEW paths after correcting causes. Finite chains are not convergence; do not pool automatically. LDpred1, unresolved author parameters and full-paper reproduction remain unqualified. Full250-paper goal remains active.
