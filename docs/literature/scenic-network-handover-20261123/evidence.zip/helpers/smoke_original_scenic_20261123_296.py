"""Linux source-specific synthetic original SCENIC pipeline probe; no project admission."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.feather as feather
T=Path('/mnt/d/projects/JLinAlg/build/fu-1');D=T/'build/scenic-2/original-smoke-2';D.mkdir()
python=Path('/var/tmp/omicsmatic-scenic-runtime-20261123-274/environment/bin/python');site=python.parent.parent/'lib/python3.10/site-packages';intake=T/'build/scenic-1/source-intake-1'
def pin(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return dict(bytes=path.stat().st_size,sha256=h.hexdigest())
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
sources={}
for name in ['pyscenic/cli/arboreto_with_multiprocessing.py','pyscenic/cli/pyscenic.py','pyscenic/utils.py','pyscenic/prune.py','pyscenic/transform.py','pyscenic/aucell.py','ctxcore/recovery.py','ctxcore/genesig.py','ctxcore/ctdb.py','ctxcore/rnkdb.py']:
 package=name.split('/')[0];original=intake/package/'original-source/src'/name;actual=site/name;assert actual.read_bytes()==original.read_bytes(),name;sources[str(actual)]=pin(actual)
save(D/'SOURCE-BEFORE.json',sources)
rng=np.random.RandomState(719);genes=['TF'+str(i) for i in range(4)]+['G'+str(i).zfill(3) for i in range(100)];cells=['cell-'+str(i).zfill(3) for i in range(96)];latent=rng.uniform(.2,6,size=(96,4));matrix=np.empty((96,len(genes)));matrix[:,:4]=latent
for target in range(100):matrix[:,4+target]=(.5+(target%7)/10)*latent[:,target//25]+rng.normal(0,.03,size=96)+.2
expression=pd.DataFrame(matrix,index=cells,columns=genes);expression.to_csv(D/'expression.csv');(D/'tfs.txt').write_text('\n'.join(genes[:4])+'\n')
rankings=np.empty((64,len(genes)),dtype=np.int32)
for motif in range(64):
 order=list(rng.permutation(len(genes)))
 if motif<4:
  targets=[4+j for j in range(100) if j//25==motif]+[motif];order=targets+[i for i in order if i not in targets]
 for rank,idx in enumerate(order):rankings[motif,idx]=rank
table={gene:pa.array(rankings[:,idx],type=pa.int32()) for idx,gene in enumerate(genes)};table['motifs']=pa.array(['M'+str(i).zfill(3) for i in range(64)])
database=D/'synthetic.genes_vs_motifs.rankings.feather';feather.write_feather(pa.table(table),database,version=2,compression='uncompressed')
annotations=D/'motifs.tbl';annotations.write_text('#motif_id\tgene_name\tmotif_similarity_qvalue\torthologous_identity\tdescription\n'+''.join('M'+str(i).zfill(3)+'\tTF'+str(i)+'\t0\t1\tgene is directly annotated\n' for i in range(4)))
save(D/'FIXTURE.json',dict(artificial_data=True,fixture_seed=719,cells=96,genes=104,TFs=4,motifs=64,selected_GRN_seed=17,CTX_rank_threshold=80,CTX_auc_fraction=.2,CTX_nes_threshold=2.5,CTX_min_genes=10,biological_reproduction=False))
environment=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',NUMBA_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',NUMBA_CACHE_DIR=str(D/'numba-cache'),MPLCONFIGDIR=str(D/'matplotlib-cache'),PYTHONHASHSEED='0')
commands=[('grn',[str(python),'-m','pyscenic.cli.arboreto_with_multiprocessing',str(D/'expression.csv'),str(D/'tfs.txt'),'--method','grnboost2','--seed','17','--num_workers','2','--output',str(D/'adjacencies.tsv')]),
 ('ctx',[str(python),'-m','pyscenic.cli.pyscenic','ctx',str(D/'adjacencies.tsv'),str(database),'--annotations_fname',str(annotations),'--expression_mtx_fname',str(D/'expression.csv'),'--output',str(D/'regulons.csv'),'--mode','custom_multiprocessing','--num_workers','2','--chunk_size','2','--rank_threshold','80','--auc_threshold','.2','--nes_threshold','2.5','--min_genes','10']),
 ('aucell',[str(python),'-m','pyscenic.cli.pyscenic','aucell',str(D/'expression.csv'),str(D/'regulons.csv'),'--output',str(D/'activity.csv'),'--num_workers','1','--seed','17'])]
records=[]
for label,args in commands:
 start=time.time()
 with (D/(label+'.stdout')).open('xb') as out,(D/(label+'.stderr')).open('xb') as err:
  p=subprocess.Popen(args,cwd=D,env=environment,stdin=subprocess.DEVNULL,stdout=out,stderr=err);save(D/(label+'.STARTED.json'),dict(pid=p.pid,arguments=args,linux_start_ticks=Path('/proc/'+str(p.pid)+'/stat').read_text().rsplit(')',1)[1].split()[19],started_unix=start));code=p.wait()
 row=dict(step=label,exit_code=code,seconds=time.time()-start);records.append(row);save(D/'PROGRESS.json',records);print(json.dumps(row),flush=True)
 if code:
  save(D/'FAILURE.json',dict(status='ORIGINAL_PIPELINE_PROBE_FAILED',step=label,exit_code=code,partial_evidence_retained=True,analysis_admitted=False));print((D/(label+'.stderr')).read_text(errors='replace')[-2400:],flush=True);raise SystemExit(code)
assert all(pin(Path(n))==wanted for n,wanted in sources.items())
save(D/'SOURCE-AFTER.json',{n:pin(Path(n)) for n in sources})
save(D/'COMPLETED.json',dict(status='ORIGINAL_SYNTHETIC_SCENIC_CLI_PIPELINE_PROBE_RETURNED',steps=records,source_files_unchanged=len(sources),adjacency_rows=len(pd.read_csv(D/'adjacencies.tsv',sep='\t')),activity_shape=list(pd.read_csv(D/'activity.csv',index_col=0).shape),whole_tool_qualified=False,new_family_credit=0,new_reviews=0,whole_goal_complete=False))
print((D/'COMPLETED.json').read_text())
