from pathlib import Path
from handover_inventory_20261122_111 import snapshot,save,pin,git
R=Path('D:/projects/JLinAlg');T=R/'build/fu-1';O=R/'build/git-publish/20261123-scenic-network-294';B=T/'build/scenic-2'
assert git('rev-parse','HEAD',cwd=T).decode().strip()=='bcb579d823c2a65c03d7e8d147addede25434586' and not git('status','--porcelain=v1',cwd=T)
O.mkdir();B.mkdir();owners=snapshot();save(O/'WORKTREES-BEFORE.json',owners);indexes={}
for row in owners:
 path=Path(git('rev-parse','--path-format=absolute','--git-path','index',cwd=Path(row['worktree'])).decode().strip());indexes[row['worktree']]=dict(path=str(path),identity=pin(path))
save(O/'INDEXES-BEFORE.json',indexes);git('switch','-c','codex/scenic-network-20261123',cwd=T)
save(O/'START.json',dict(previous_goal_turn='progress',base='bcb579d823c2a65c03d7e8d147addede25434586',scoped_families=154,reviewed_uses=1697,pending_uses=1025,new_family_credit=0,new_reviews=0,whole_goal_complete=False))
print('Started isolated source-bound SCENIC network workflow stage;19 worktree owners preserved.')
