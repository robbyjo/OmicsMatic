# Original PoPS warnings and required actions

DEVELOPMENT: selected original GPL PoPS source, not an author binary or
paper environment. Edition is mandatory. PoPS 0.1 uses the original
lower Cholesky of inverse covariance, marginal statsmodels OLS and
chromosome-held-out RidgeCV with Pearson scoring. PoPS 0.2 has its own
covariance transformation, feature selection and ridge/OLS/LassoCV.
No edition or method is silently substituted. Native ridge/OLS is a
separate explicit pops-tools profile, never an automatic fallback.

Original execution requires a separately installed and adopted Linux
x86-64 Python runtime. Run Java inside Linux/WSL. No installation or
download occurs during analysis. Missing/forbidden prerequisites:
SKIP3, dependent analysis skipped. Supply the named permitted setup or
leave it skipped. Other failures: FAIL2, no accepted complete result.

Source warnings and failures are retained. Explicit ConvergenceWarning
means FAIL2 even when source coefficients are finite. No iteration limit,
random seed, identifier, NaN, infinity or covariance is silently repaired.
A missing-value policy is required explicitly for original feature munging.
Preparation/selection completion does not establish a fitted model.
Empty 0.1 selection can still yield a control-only model. The selected
original 0.1 source fails with a single selected feature; that failure
is preserved. Its selected CV alpha/score are not exported by the source.

Genome build, target-source and feature-set labels are caller declarations.
They are not verified biological provenance. Whole-paper reproduction,
biological validation and new catalog credit are not established here.
Build current source; released v0.4.0 lacks this command.

java_heap_mb bounds the owned worker heap. python_address_space_mb is a
separate per-Python-process Linux address-space limit. wall_ms monitors
the worker, including runtime checking and source execution. Work bytes
and entries are monitored, not OS disk quotas. This is not a filesystem
or network sandbox or an executable-authenticity claim. Increase permitted
capacities without thinning genes/features or splitting dependencies.

Only root COMPLETED.properties admits the complete requested task.
WORKER_DONE alone does not. --verify checks complete bundle membership
and bytes, then actually reruns the original source and compares the full
scientific result and binding families in NEW output. Use the original
matching artifact/profile and adopted runtime. Do not refresh fingerprints
to force a pass. Hashes provide integrity, not authenticity/signature.
Retain all raw outputs, runtime-logs, worker consoles and FAILURE.txt.
Correct the named cause and retry NEW output; unresolved source numerical
failures must remain unadmitted. Cancel normally so owned children stop.
Hard-killing a Windows parent has no process-job guarantee.
