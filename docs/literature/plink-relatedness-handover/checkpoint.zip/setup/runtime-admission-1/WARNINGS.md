# ORIGINAL PLINK ANALYSIS SKIPPED

[WinError 5] Access is denied: 'D:\\projects\\JLinAlg\\build\\high-impact-stats-1\\build\\plink-relatedness-development-1\\tmpghhcqfnf' -> 'D:\\projects\\JLinAlg\\build\\high-impact-stats-1\\build\\plink-relatedness-development-1\\runtime-1'

Required action: Where permitted run python tools/literature/install_plink.py --home NEW_PRIVATE_HOME --archives ARCHIVE_DIRECTORY --allow-install; add --allow-download only when missing official downloads are allowed. Supply that exact sealed home to plink-tools --home or JLINALG_PLINK_HOME. If installation or the host is unavailable, skip the dependent original analysis (exit 3). Preserve changed/incomplete homes and diagnostics; never re-seal changed binaries or overwrite an existing home. Version/admission probes alone do not validate scientific workflows.

Private original binaries and unchanged GPL text only. All official archive members are authenticated; unused bonus utilities/toy data are not installed. No OS/global installation, persistent PATH change or program patch. Windows system DLLs remain a host boundary. Analysis commands do not install software.
