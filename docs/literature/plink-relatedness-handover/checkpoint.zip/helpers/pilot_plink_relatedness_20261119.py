from pathlib import Path
import hashlib,json,random,subprocess,sys,time
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');B=A/'build/plink-relatedness-development-1'
O=B/'pilot-1';O.mkdir(exist_ok=False)
jar=B/'build-1/omicsmatic-0.4.0.jar';java=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe')
old=Path('D:/projects/JLinAlg/build/literature-review/plink-relatedness-runtime/reference-controls-3/inputs/variants-129/cohort')
clean=O/'clean';clean.mkdir();prefix=clean/'cohort';rng=random.Random(20261119)
samples=[]
for i in range(17):
 fid=['zeta','alpha','group','other','group'][i] if i<5 else 'family'+str(i%4)
 iid='sample_alpha_\u03b1' if i==0 else 'same' if i in [2,3] else 's'+str(i)
 samples.append(dict(fid=fid,iid=iid,father='same' if i==4 else '0',mother='0',sex=i%3,phenotype=1+i%2))
prefix.with_suffix('.fam').write_text(''.join(f'{s["fid"]}\t{s["iid"]}\t{s["father"]}\t{s["mother"]}\t{s["sex"]}\t{s["phenotype"]}\n' for s in samples),encoding='utf-8',newline='\n')
prefix.with_suffix('.bim').write_text(''.join(f'{1+j//65}\tv{j}\t0\t{100+j*41}\tA\tC\n' for j in range(129)),encoding='utf-8',newline='\n')
calls=[];bed=bytearray([0x6c,0x1b,1])
for j in range(129):
 p=.1+(j%15)*.05
 row=[int(rng.random()<p)+int(rng.random()<p) for s in samples]
 for i in range(len(row)):
  if rng.random()<.01:row[i]=-1
 row[1]=row[0]
 if j==0:row=[0]*len(samples)
 if j==1:row=[2]*len(samples)
 if j==2:row=[1]*len(samples)
 if j==128:row=[-1]*len(samples)
 calls.append(row);packed=bytearray((len(samples)+3)//4)
 for i,value in enumerate(row):packed[i//4]|={2:0,-1:1,1:2,0:3}[value]<<(2*(i%4))
 bed.extend(packed)
prefix.with_suffix('.bed').write_bytes(bed)
(clean/'SYNTHETIC.json').write_bytes((json.dumps(dict(seed=20261119,samples=samples,calls=calls,paper_data=False),indent=2)+'\n').encode())
limits=dict(input_bytes=50000000,metadata_bytes=5000000,working_bytes=268435456,disk_bytes=100000000,output_bytes=50000000,files=100,samples=100000,variants=2000000,pair_variant_operations=1000000000,pair_batch_size=7,line_bytes=16384,wall_seconds=120)
genome=dict(rel_check=False,unbounded=False,nudge=False,ppc_gap_kb=500,min_pi_hat=None,max_pi_hat=None,frequency_mode='COHORT_FOUNDERS')
cases=[
 ('table-counts-old','KING_TABLE',old,dict(counts=True,rel_check=False,kinship_filter=None),0),
 ('table-proportions-clean','KING_TABLE',prefix,dict(counts=False,rel_check=False,kinship_filter=None),0),
 ('table-filter-clean','KING_TABLE',prefix,dict(counts=True,rel_check=False,kinship_filter=.177),0),
 ('table-relcheck-old','KING_TABLE',old,dict(counts=True,rel_check=True,kinship_filter=None),0),
 ('matrix64-clean','KING_MATRIX',prefix,dict(precision='FLOAT64'),0),
 ('matrix32-clean','KING_MATRIX',prefix,dict(precision='FLOAT32'),0),
 ('matrix-nonfinite-old','KING_MATRIX',old,dict(precision='FLOAT64'),2),
 ('cutoff-partition-old','KING_CUTOFF',old,dict(threshold=.177,audit_retained_pairs=False),0),
 ('cutoff-unsafe-old','KING_CUTOFF',old,dict(threshold=.177,audit_retained_pairs=True),2),
 ('cutoff-clean','KING_CUTOFF',prefix,dict(threshold=.177,audit_retained_pairs=True),0),
 ('cutoff-invalid-original','KING_CUTOFF',prefix,dict(threshold=.5,audit_retained_pairs=False),2),
 ('genome-bounded-old','GENOME',old,genome,0),
 ('genome-unbounded-old','GENOME',old,dict(genome,unbounded=True),0),
 ('genome-nudge-clean','GENOME',prefix,dict(genome,nudge=True),0),
 ('genome-filter-old','GENOME',old,dict(genome,min_pi_hat=.2,max_pi_hat=.8),0),
 ('genome-relcheck-clean','GENOME',prefix,dict(genome,rel_check=True,ppc_gap_kb=0),0),
]
reports={}
for name,operation,bfile,settings,expected in cases:
 request=dict(schema_version=1,mode='RUN',operation=operation,bfile=str(bfile),runtime_home=str(B/'runtime-2'),out=str(O/name),threads=2,memory_mib=640,seed=20261119,settings=settings,limits=limits)
 path=O/(name+'.json');path.write_bytes((json.dumps(request,indent=2,ensure_ascii=False)+'\n').encode())
 command=[str(java),'-Xmx1g','-cp',str(jar),'org.jlinalg.cli.PlinkRelatednessCli','--request',str(path)]
 start=time.monotonic()
 with (O/(name+'.stdout')).open('xb') as so,(O/(name+'.stderr')).open('xb') as se:
  proc=subprocess.run(command,cwd=A,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=180)
 state=json.loads((O/name/'analysis-status.json').read_bytes()) if (O/name/'analysis-status.json').is_file() else {}
 reports[name]=dict(exit_code=proc.returncode,expected=expected,seconds=time.monotonic()-start,status=state.get('status'),error=state.get('error'),summary=state.get('summary'))
 if proc.returncode==0:
  verify=[str(java),'-Xmx1g','-cp',str(jar),'org.jlinalg.cli.PlinkRelatednessCli','--request',str(O/name/'verify-request.json')]
  with (O/(name+'-verify.stdout')).open('xb') as so,(O/(name+'-verify.stderr')).open('xb') as se:v=subprocess.run(verify,cwd=A,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=180)
  reports[name]['verify_exit_code']=v.returncode
 print(json.dumps(dict(case=name,exit=proc.returncode,expected=expected,error=state.get('error'),verify=reports[name].get('verify_exit_code'))),flush=True)
 (O/'PROGRESS.json').write_bytes((json.dumps(reports,indent=2)+'\n').encode())
result=dict(status='PASS_ALL_ORIGINAL_PILOT_CASES' if all(r['exit_code']==r['expected'] and r.get('verify_exit_code',0)==0 for r in reports.values()) else 'FAIL2_PILOT_HAS_UNQUALIFIED_DIFFERENCES',cases=reports,full_tool_qualified=False,catalog_credit=0,whole_goal_complete=False)
(O/'COMPLETED.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
print(result['status'],flush=True)
