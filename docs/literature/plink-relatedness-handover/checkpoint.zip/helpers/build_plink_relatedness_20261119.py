from pathlib import Path
import hashlib,json,shutil,subprocess,sys,zipfile
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1')
attempt=sys.argv[1];assert attempt.replace('-','').isalnum()
O=A/'build/plink-relatedness-development-1'/attempt;O.mkdir(exist_ok=False)
parent=A/'build/seurat-workflow-1/qualification-1/omicsmatic-0.4.0.jar'
sources=sorted((A/'src/main/java/org/jlinalg/cli').glob('PlinkRelatedness*.java'));assert len(sources)==6
resource=A/'src/main/resources/org/jlinalg/omics/plink-relatedness-setup'
inputs={p.relative_to(A).as_posix():p for p in [*sources,*resource.iterdir()] if p.is_file()}
def pin(p):
 with p.open('rb') as f:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
for name,p in inputs.items():
 target=O/'source'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
classes=O/'classes';classes.mkdir()
jdk=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin')
command=[str(jdk/'javac.exe'),'--release','17','-g','-Xlint:all','-cp',str(parent),'-d',str(classes),*[str(O/'source'/p.relative_to(A)) for p in sources]]
(O/'COMMAND.json').write_bytes((json.dumps(command,indent=2)+'\n').encode())
with (O/'javac.stdout').open('xb') as so,(O/'javac.stderr').open('xb') as se:proc=subprocess.run(command,cwd=A,stdin=subprocess.DEVNULL,stdout=so,stderr=se)
(O/'PROCESS.json').write_bytes((json.dumps(dict(exit_code=proc.returncode,source_pins={n:pin(p) for n,p in inputs.items()}),indent=2)+'\n').encode())
if proc.returncode:
 print((O/'javac.stderr').read_text(errors='replace')[-12000:],flush=True);raise SystemExit(proc.returncode)
candidate=O/'omicsmatic-0.4.0.jar';shutil.copyfile(parent,candidate)
added={p.relative_to(classes).as_posix():p for p in classes.rglob('*.class')}
for p in resource.iterdir():
 if p.is_file():added['org/jlinalg/omics/plink-relatedness-setup/'+p.name]=p
with zipfile.ZipFile(parent) as old:
 assert not set(added).intersection(old.namelist())
with zipfile.ZipFile(candidate,'a',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(added.items()):z.write(p,name)
with zipfile.ZipFile(parent) as old,zipfile.ZipFile(candidate) as new:
 assert len(new.namelist())==len(set(new.namelist())) and set(new.namelist())==set(old.namelist())|set(added)
 for name in old.namelist():assert old.read(name)==new.read(name),name
 members=len(old.namelist())
report=dict(status='PASS_ISOLATED_PLINK_RELATEDNESS_BUILD_ONLY',parent=pin(parent),candidate=pin(candidate),
 old_payloads_unchanged=members,added_payloads={n:pin(p) for n,p in added.items()},source_pins={n:pin(p) for n,p in inputs.items()},analysis_qualified=False,catalog_credit=0,whole_goal_complete=False)
(O/'COMPLETED.json').write_bytes((json.dumps(report,indent=2)+'\n').encode())
print(json.dumps(dict(status=report['status'],parent_payloads=members,added_payloads=len(added),candidate=str(candidate))),flush=True)
