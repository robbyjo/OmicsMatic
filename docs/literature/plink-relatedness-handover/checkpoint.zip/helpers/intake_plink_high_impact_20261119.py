"""Private, source-bound next-family intake; regex hints are not semantic reviews."""
from pathlib import Path
from collections import Counter
import gzip,hashlib,json,re,sys,xml.etree.ElementTree as ET
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1')
O=A/'build/plink-high-impact-1/primary-intake-1';O.mkdir(parents=True,exist_ok=False)
sys.dont_write_bytecode=True;sys.path.insert(0,str(A/'tools/literature'))
from collect_omics_review import paragraphs
from catalog_fixed_cohort import verify_fixed_cohort
data=A/'docs/literature/omics-2023-2026'
papers=json.loads((data/'papers.json').read_bytes());verify_fixed_cohort(A,data,papers)
inventory={r['id']:r for r in json.loads((data/'tool-inventory.json').read_bytes())}
reviews=json.loads((A/'tools/literature/reviewed-uses.json').read_bytes())['reviews']
prior={(r['pmcid'],r['tool_id']):r for r in reviews}
patterns={name:re.compile(inventory[name]['pattern'],re.I) for name in ['plink','plink2','king']}
hints={name:re.compile(pattern,re.I) for name,pattern in {
 'relatedness':r'kinship|KING|relatedness|unrelated|related individuals',
 'ibd':r'\bIBD\b|pi[_ -]?hat|identity.by.descent|--genome|\bZ[012]\b',
 'ld':r'\bLD\b|clump|prun|indep.pairwise|linkage disequilibrium',
 'qc':r'\bQC\b|quality control|\bHWE\b|Hardy|missing|\bMAF\b|sex check',
 'pca':r'\bPCA\b|principal components?|\bPCs\b',
 'association':r'\bGWAS\b|regression|--glm|--linear|--logistic|firth|association',
 'score':r'--score|polygenic|\bPRS\b|\bPGS\b|risk score',
 'conversion':r'convert|recode|--make|format|\bVCF\b|\bPGEN\b|dosage',
 'nonhuman':r'wheat|cucumber|plant|tetraploid|polyploid|accession|--chr-set|extra.chr'}.items()}
records=[];identities=[];mentions=[]
for paper in papers:
 raw=gzip.decompress((Path('D:/projects/JLinAlg/build/literature-review/xml')/(paper['pmcid']+'.xml.gz')).read_bytes())
 assert hashlib.sha256(raw).hexdigest()==paper['xml_sha256']
 xml=ET.fromstring(raw)
 assert next(n.text for n in xml.findall('front/article-meta/article-id') if n.get('pub-id-type')=='doi').lower()==paper['doi'].lower()
 identities.append({k:paper[k] for k in ['paper_id','pmcid','doi','xml_sha256']})
 ps=paragraphs(xml);by_index={p['paragraph_index']:p for p in ps}
 for p in ps:p['paragraph_sha256']=hashlib.sha256(p['text'].encode()).hexdigest()
 for name,pattern in patterns.items():
  found=[p for p in ps if pattern.search(p.get('match_text',p['text']))]
  observation=next((t for t in paper['tools'] if t['tool_id']==name),None)
  if found:mentions.append(dict(paper_id=paper['paper_id'],tool_id=name,existing_observation=observation is not None,paragraph_indices=[p['paragraph_index'] for p in found]))
  if observation is None:continue
  anchor=by_index[observation['evidence_paragraph_index']];assert anchor['paragraph_sha256']==observation['evidence_paragraph_sha256']
  selected={p['paragraph_index']:p for p in found};selected[anchor['paragraph_index']]=anchor
  old=prior.get((paper['pmcid'],name))
  if old:
   for pointer in old.get('supporting_evidence',[]):
    p=by_index[pointer['paragraph_index']];assert p['paragraph_sha256']==pointer['paragraph_sha256'];selected[p['paragraph_index']]=p
  selected=[selected[k] for k in sorted(selected)];text='\n'.join(p['text'] for p in selected)
  records.append(dict(paper_id=paper['paper_id'],pmcid=paper['pmcid'],doi=paper['doi'],tool_id=name,source_xml_sha256=paper['xml_sha256'],existing_observation=observation,prior_review=old,
   operation_hints=[k for k,pattern in hints.items() if pattern.search(text)],
   paragraphs=[{k:p[k] for k in ['paragraph_index','section','paragraph_sha256','text']} for p in selected]))
counts=dict(Counter(r['tool_id'] for r in records));assert counts=={'plink':52,'plink2':25,'king':15},counts
def save(n,v):(O/n).write_bytes((json.dumps(v,indent=2,ensure_ascii=False)+'\n').encode())
save('SOURCE-ROLES.private.json',records);save('NAMED-CONTEXTS.private.json',mentions)
result=dict(status='PASS_250_PRIMARY_IDENTITIES_AND92_CURRENT_PLINK_KING_OBSERVATIONS_INTAKE_ONLY',
 papers_scanned=250,observations=92,tool_counts=counts,previously_reviewed=sum(r['prior_review'] is not None for r in records),
 operation_hint_counts=dict(Counter(h for r in records for h in r['operation_hints'])),
 existing_current_source_review_retained=True,regex_hints_are_semantic_reviews=False,
 analyses_executed=False,canonical_metadata_modified=False,new_family_credit=0,whole_goal_complete=False,
 next_action='Review the specific missing high-impact PLINK/PLINK2/KING analysis scope against existing GLM/QC/prune/PCA/scoring/LD components; do not duplicate qualified work or infer IBD from KING coefficients.')
save('COMPLETED.json',result);save('IDENTITIES.json',identities)
print(json.dumps(result),flush=True)
