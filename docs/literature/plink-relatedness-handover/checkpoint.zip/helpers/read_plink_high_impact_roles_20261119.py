from pathlib import Path
import json,sys
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1')
rows=json.loads((A/'build/plink-high-impact-1/primary-intake-1/SOURCE-ROLES.private.json').read_bytes())
inventory=json.loads((A/'docs/literature/omics-2023-2026/tool-inventory.json').read_bytes())
for name in ['plink','plink2','king','coloc']:
 row=next(r for r in inventory if r['id']==name)
 print('CURRENT DEFINITION',name,json.dumps({k:row[k] for k in ['implementation_status','implementation_source','implementation_scope','coverage_note','paper_count'] if k in row}),flush=True)
selected=[r for r in rows if r['tool_id'] in ['plink','plink2'] and any(k in r['operation_hints'] for k in ['relatedness','ibd'])]
print('RELATEDNESS CANDIDATES',len(selected),[(r['paper_id'],r['tool_id'],r['prior_review'] is not None) for r in selected],flush=True)
start=int(sys.argv[1]) if len(sys.argv)>1 else 0
for row in selected[start:start+8]:
 print('\nROLE',row['paper_id'],row['tool_id'],'PRIOR REVIEW',row['prior_review'],flush=True)
 for p in row['paragraphs']:
  if any(x in p['text'].lower() for x in ['kinship','relatedness','pi_hat','--genome','identity-by-descent','king','unrelated']):
   print('PARAGRAPH',p['paragraph_index'],p['section'],'\n'+p['text'][:4500],flush=True)
