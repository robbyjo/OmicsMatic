from pathlib import Path
p=Path('D:/projects/JLinAlg/build/pilot_plink_relatedness_20261119.py')
code=p.read_text(encoding='utf-8')
for old,new in [("O=B/'pilot-1'","O=B/'pilot-handover-2'"),("jar=B/'build-1/omicsmatic-0.4.0.jar'","jar=B/'build-4/omicsmatic-0.4.0.jar'")]:
 assert old in code; code=code.replace(old,new)
exec(compile(code,str(p)+'-HANDOVER-BUILD-4','exec'))
