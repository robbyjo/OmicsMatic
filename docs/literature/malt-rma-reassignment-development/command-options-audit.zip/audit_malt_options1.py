from pathlib import Path
import hashlib,json,subprocess,urllib.request
R=Path('D:/projects/JLinAlg');B=R/'build/literature-review/nfcore-runtime';O=B/'malt-command-options-audit-1';assert not O.exists();O.mkdir();commit='5984e0672000604e8ef0b5ebb2a41f0ad00fb67d';sources={}
for name in ['MaltRun.java','MaltOptions.java']:
 url='https://raw.githubusercontent.com/husonlab/malt/'+commit+'/src/malt/'+name
 with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'OmicsMatic-source-audit'}),timeout=60) as response:
  raw=response.read(1048577);assert response.status==200 and len(raw)<=1048576
 (O/name).write_bytes(raw);sources[name]=dict(url=url,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
command=['C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/javap.exe','-c','-private','-cp',str(B/'malt-rma-public-install-1/MALT.jar'),'malt.MaltRun','malt.MaltOptions'];p=subprocess.run(command,stdin=subprocess.DEVNULL,capture_output=True,timeout=60);(O/'original-bytecode.stdout').write_bytes(p.stdout);(O/'original-bytecode.stderr').write_bytes(p.stderr);assert p.returncode==0
for marker in [b'float 0.001f',b'float 10.0f',b'(--minSupportPercent: overridden, set to 0)']:assert marker in p.stdout,marker
(O/'COMPLETED.json').write_text(json.dumps(dict(status='PASS_ORIGINAL_MALT_COMMAND_OPTION_SOURCE_AND_BYTECODE_AUDIT_ONLY',source_context_commit=commit,sources=sources,command=command,exit_code=p.returncode,original_standalone_defaults=dict(top_percent=10.0,support_percent=0.001),current_qualified_eager_control_profile=dict(top_percent=1.0,support_percent=0.01),positive_minimum_support_disables_percentage=True,whole_goal_complete=False),indent=2)+'\n');print('Verified original CLI precedence and recorded standalone versus qualified eager-profile defaults')
