import hashlib,json,re,subprocess,sys,traceback,zipfile
from pathlib import Path
from html.parser import HTMLParser
b=Path(__file__).resolve().parent;r=b.parents[1];out=b/'closure-1';out.mkdir()
sys.dont_write_bytecode=True;sys.path.insert(0,str(r/'tools/literature'))
from ldsc_hsq import catalog as m
from catalog_source_integrity import reverse_delta,verify_source
def save(p,v):p.write_bytes(m.encoded(v))
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
try:
 admission=b/'admission-1';assert (admission/'COMPLETED.json').exists()
 result=json.loads((admission/'verified/COMPLETED.json').read_bytes());assert result['new_scoped_integrations']==128 and result['current_manifest']['entries']==794
 assert all(json.loads((admission/f'PROCESS-{i}.json').read_bytes())['exit_code']==0 for i in range(4))
 tests=(admission/'0.stderr').read_text();assert 'Ran 10 tests' in tests and tests.rstrip().endswith('OK')
 before=m.baseline();after={n:(r/n).read_bytes() for n in m.META};census=json.loads((r/m.COVERAGE).read_bytes());counts=m.check(before,after,census)
 journal=json.loads((r/m.COMPATIBILITY).read_bytes());name='tools/literature/reviewed-uses.json';assert len(journal['paths'])==1 and reverse_delta(after[name],journal['paths'][0])==before[name];verify_source(r,r/m.DATA,name,pin(before[name])['sha256'])
 old=m.git('show',m.BASE+':'+m.DATA+'/SHA256SUMS');assert old==(r/m.EVIDENCE/'PREVIOUS-SHA256SUMS').read_bytes();assert len([x for x in old.decode().splitlines() if '  ../' in x])==9
 olddefs=__import__('common_statistics.prism_catalog',fromlist=['registry']).registry();newdefs=m.registry();assert [x for x in olddefs if x['id']!='ldsc']==[x for x in newdefs if x['id']!='ldsc']
 for name in ['site/literature-review.html','site/literature-warnings.html']:
  text=after[name].decode();parser=HTMLParser();parser.feed(text);parser.close();assert text.count('id="ldsc-catalog-notice"')==1 and text.index('id="ldsc-catalog-notice"')<text.index('id="prism-source-catalog-notice"')
  assert m.CURRENT in text and m.ACTION in text and '<strong>Required actions:</strong>' in text
 oldpage=before['site/literature-review.html'].decode();newpage=after['site/literature-review.html'].decode()
 scripts=lambda page:[x for x in re.findall(r'<script([^>]*)>(.*?)</script>',page,re.S) if 'id="review-data"' not in x[0]]
 assert scripts(oldpage)==scripts(newpage)
 links=[]
 for name in [m.GUIDE,'docs/literature/IMPLEMENTATION_PRIORITY.md','docs/literature/ldsc-catalog/README.md']:
  text=(r/name).read_text(encoding='utf-8')
  for target in re.findall(r'\]\(([^)]+)\)',text):
   if not target.startswith(('https://','http://','#')):assert ((r/name).parent/target.split('#')[0]).exists(),(name,target);links.append([name,target])
 guide=(r/m.GUIDE).read_text(encoding='utf-8');assert 'ldsc-tools h2 --request REQUEST.json' in guide and 'ldsc-tools rg --request REQUEST.json' in guide and ' run REQUEST' not in guide
 # Only the intended current catalog/guide and review-file edits may be tracked.
 changed=set(subprocess.check_output(['git','diff','--name-only'],cwd=r).decode().splitlines());allowed=set(m.META)|{m.DATA+'/SHA256SUMS','docs/literature/IMPLEMENTATION_PRIORITY.md'};assert changed<=allowed,changed-allowed
 evidence=r/m.EVIDENCE;payload={}
 for folder in [admission/'plan',admission/'applied',admission/'verified']:
  for p in folder.rglob('*'):
   if p.is_file():payload['admission/'+p.relative_to(admission).as_posix()]=p.read_bytes()
 for p in admission.iterdir():
  if p.is_file() and p.name!='reviewed-source.zip':payload['admission/'+p.name]=p.read_bytes()
 selected=[*m.OWN,m.GUIDE,'docs/literature/IMPLEMENTATION_PRIORITY.md',*m.META,m.DATA+'/SHA256SUMS',m.COVERAGE,m.PROOF,m.COMPATIBILITY,'docs/literature/ldsc-rg-development/VALIDATION.json']
 for p in evidence.iterdir():
  if p.is_file():selected.append(p.relative_to(r).as_posix())
 for name in selected:payload['snapshot/'+name]=(r/name).read_bytes()
 payload['closure/close.py']=Path(__file__).read_bytes();payload['closure/compatibility.json']=m.encoded(dict(status='PASS_REVIEW_ONLY_INVERSE_AND_GENERIC_HISTORICAL_SOURCE_RECONSTRUCTION',before=pin(before['tools/literature/reviewed-uses.json']),after=pin(after['tools/literature/reviewed-uses.json']),previous_manifest_verbatim=True,parent_entries_preserved=9,other_registry_definitions_preserved=484,scientific_source_mutations=0,script_bodies_unchanged=True,local_documentation_links_checked=len(links)))
 index={name:pin(raw) for name,raw in sorted(payload.items())};payload['ENTRY-MANIFEST.json']=m.encoded(dict(schema_version=1,payloads=index))
 archive=evidence/'checks.zip'
 with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name,raw in sorted(payload.items()):z.writestr(name,raw)
 with zipfile.ZipFile(archive) as z:
  assert len(z.namelist())==len(payload) and len(set(z.namelist()))==len(payload) and z.testzip() is None
  assert set(z.namelist())==set(index)|{'ENTRY-MANIFEST.json'}
  for name,expected in index.items():assert pin(z.read(name))==expected
  assert json.loads(z.read('ENTRY-MANIFEST.json'))['payloads']==index
 guardnames=set(selected)|{m.EVIDENCE+'/checks.zip'}
 proof=dict(status='PASS_LDSC_CATALOG_SOURCE_ADMISSION_AND_EVIDENCE_CLOSURE',**counts,base_commit=m.BASE,tests=dict(tests=10,failures=0,errors=0,skipped=0),primary_xml_hashes_rechecked=250,current_manifest=m.manifest_audit(),archive=m.pin(archive),indexed_payloads=len(index),all_archive_payloads_read_back=True,scientific_runtime_reexecuted=False,scientific_engines_changed=False,historical_fingerprints_refreshed=False,legacy_manifest_preserved=True,review_inverse_reconstructed_actual_git=True,other_registry_definitions_preserved=484,website_deployed=False,source_guards={n:m.pin(r/n) for n in sorted(guardnames)},warnings=m.EVIDENCE+'/WARNINGS.md',guide=m.GUIDE)
 assert proof['current_manifest']['entries']==794 and not any(proof['current_manifest'][k] for k in ['mismatches','missing_entries','extra_entries'])
 save(evidence/'VALIDATION.json',proof);save(out/'COMPLETED.json',proof);print(json.dumps({k:proof[k] for k in ['status','new_scoped_integrations','native_integrations','upstream_integrations','indexed_payloads','archive']}),flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc()));print(traceback.format_exc(),flush=True);raise
