# FAIL2: NO RESULT ADMITTED

java.io.IOException: Empty/duplicate/implicitly trimmed/control identifier

REQUIRED ACTION: Require exit 0, result_admitted=true in COMPLETED.json and successful --verify before using projected.tsv. Read WARNINGS.md. On FAIL2, admit no result: preserve the complete attempt, correct the named input/capacity/numerical cause and retry a NEW output directory. This native projection installs nothing. It neither selects a PPI nor infers a paper's raw.use setting; upstream inference must explicitly consume projected expression. Limits are logical capacities, not hard RAM/time quotas.
