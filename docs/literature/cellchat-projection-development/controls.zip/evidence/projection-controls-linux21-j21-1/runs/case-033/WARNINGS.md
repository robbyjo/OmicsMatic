# PROJECTION WARNINGS AND REQUIRED ACTIONS

Projection alone does not change CellChat inference. Select raw.use=FALSE explicitly in an upstream workflow to consume projected expression; no paper setting is inferred.

No expression genes overlap the PPI: every original expression row is unchanged.

Alpha is close to one. A small backward residual does not establish small forward error; compare with the original solver for sensitive downstream decisions.

Require exit 0, result_admitted=true in COMPLETED.json and successful --verify before using projected.tsv. Read WARNINGS.md. On FAIL2, admit no result: preserve the complete attempt, correct the named input/capacity/numerical cause and retry a NEW output directory. This native projection installs nothing. It neither selects a PPI nor infers a paper's raw.use setting; upstream inference must explicitly consume projected expression. Limits are logical capacities, not hard RAM/time quotas.
