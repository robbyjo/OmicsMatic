# INSTALLED_ORIGINAL_CELLCHAT_EDITION_ONLY



Required action: If an exact original edition/dependency/compiler is unavailable or installation is forbidden, SKIP dependent CellChat analysis. Read WARNINGS.md and installer stdout/stderr. Supply the named permitted prerequisite in NEW private paths and retry NEW output paths. Preserve all earlier attempts/libraries and original source. Do not patch upstream functions, use another CellChat edition or silently replace historical algorithms. Setup/constructor/DLL health alone admits no analysis.
