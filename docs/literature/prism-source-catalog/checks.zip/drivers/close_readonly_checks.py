import hashlib,json,subprocess,time,traceback,zipfile
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];out=b/'closure-1';out.mkdir();public=r/'docs/literature/prism-source-catalog';py='C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,value):p.write_text(json.dumps(value,indent=2)+'\n',encoding='utf8')
try:
 for folder in ['apply-2','verify-2']:
  value=json.loads((b/folder/'COMPLETED.json').read_bytes());assert value['status']=='PASS_P215_PRISM_SOURCE_CATALOG_CORRECTION' and value['observations']==2694 and value['reviewed_uses']==1219
 source=json.loads((b/'current-method-source-review-2/SOURCE_REVIEW.json').read_bytes());assert source['catalog_source_gap']['status']=='CORRECTED_ONE_PAPER_TOOL_RECORD_WITH_FOUR_SUPPORTING_POINTERS' and source['admitted_catalog_prism_papers']==47
 command=[py,'-X','utf8','-B',str(r/'tools/literature/common_statistics/prism_catalog.py'),'--verify','--primary-cache','D:/projects/JLinAlg/build/literature-review/xml','--out',str(b/'verify-3')];save(out/'command.json',command);began=time.monotonic()
 with (out/'stdout').open('xb') as so,(out/'stderr').open('xb') as se:p=subprocess.run(command,cwd=r,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=180)
 save(out/'PROCESS.json',dict(exit_code=p.returncode,seconds=time.monotonic()-began));assert p.returncode==0
 proof=json.loads((r/'docs/literature/omics-2023-2026/prism-source-catalog-validation.json').read_bytes());assert proof['source_code']=={name:pin(r/name) for name in proof['source_code']};assert len(proof['predecessor_current_manifest']['missing_entries'])==71 and len(proof['predecessor_current_manifest']['mismatches'])==5
 changed=subprocess.check_output(['git','diff','--name-only','-z'],cwd=r).split(b'\0');assert not any(x.startswith(b'src/') for x in changed if x)
 stage=out/'payload';stage.mkdir();files={}
 def add(path,name):
  target=stage/name;target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists();raw=path.read_bytes();target.write_bytes(raw);files[name]=pin(target)
 for folder in ['plan-1','plan-2','admission-1','admission-2','apply-1','apply-2','verify-2','verify-3','current-method-source-review-2']:
  for path in (b/folder).rglob('*'):
   if path.is_file():add(path,folder+'/'+path.relative_to(b/folder).as_posix())
 for path in b.glob('*.py'):add(path,'drivers/'+path.name)
 for name in ['command.json','stdout','stderr','PROCESS.json']:add(out/name,'final-check/'+name)
 for name in proof['source_code']:add(r/name,'current-source/'+name)
 for path in public.iterdir():
  if path.is_file():add(path,'source-evidence/'+path.name)
 for name in proof['after']:add(r/name,'current-metadata/'+name)
 for name in ['docs/literature/omics-2023-2026/prism-source-catalog-validation.json','docs/literature/omics-2023-2026/prism-source-reviews-shared-source-compatibility.json','docs/literature/omics-2023-2026/SHA256SUMS','docs/literature/PRISM_SOURCE_CATALOG.md','docs/literature/IMPLEMENTATION_PRIORITY.md']:add(r/name,'current-records/'+name)
 save(stage/'INDEX.json',dict(schema_version=1,payload_files=files));target=public/'checks.zip';assert not target.exists()
 with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for path in sorted(stage.rglob('*')):
   if path.is_file():z.write(path,path.relative_to(stage).as_posix())
 with zipfile.ZipFile(target) as z:
  assert len(z.namelist())==len(set(z.namelist()))==len(files)+1
  for name,identity in files.items():
   raw=z.read(name);assert dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())==identity,name
 record=dict(status='PASS_PRISM_SOURCE_CORRECTION_READONLY_CLOSURE',catalog_proof=pin(r/'docs/literature/omics-2023-2026/prism-source-catalog-validation.json'),current_counts=json.loads((b/'verify-3/COMPLETED.json').read_bytes()),primary_xml_sources_verified=250,python_tests=8,checks_zip=pin(target),indexed_payload_files=len(files),all_zip_members_readback_verified=True,predecessor_stale_checksum_entries=5,predecessor_omitted_checksum_entries=71,current_manifest_complete_and_verified=True,previous_records_preserved=True,scientific_engines_changed=False,new_implementation_credit=0,website_deployed=False,retained_wrapper_failure='admission-2 apply/source audits and independent verifier passed. The closing wrapper then referenced the old source-review directory name and failed. This read-only closure checked the actual completed source-review directory and reran verification without reapplying metadata.',whole_goal_complete=False)
 save(public/'VALIDATION.json',record);save(out/'COMPLETED.json',record);print('PASS read-only closure; catalog2694/reviewed1219/Prism47; evidence',pin(target),'files',len(files),flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc()));print(repr(e),flush=True);raise
