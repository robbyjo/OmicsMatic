from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];data=r/'docs/literature/omics-2023-2026';lines=(data/'SHA256SUMS').read_text().splitlines();nested=[]
for line in lines:
 sha,name=line.split('  ',1)
 if Path(name).name!=name:nested.append(name)
print('NESTED',len(nested),nested[:12]);print('FILES top',len([p for p in data.iterdir() if p.is_file()]),'recursive',len([p for p in data.rglob('*') if p.is_file()]));print('REPR FIRST',repr(lines[0]))
