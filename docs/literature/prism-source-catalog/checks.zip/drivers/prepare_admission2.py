from pathlib import Path
b=Path(__file__).resolve().parent;text=(b/'run_catalog_correction.py').read_text()
for a,c in [("out=b/'admission-1'","out=b/'admission-2'"),("b/'apply-1'","b/'apply-2'"),("b/'verify-1'","b/'verify-2'"),("b/'current-method-source-review-1'","b/'current-method-source-review-2'")]:
 assert a in text,a;text=text.replace(a,c)
p=b/'run_catalog_correction2.py';assert not p.exists();p.write_text(text,newline='\n')
