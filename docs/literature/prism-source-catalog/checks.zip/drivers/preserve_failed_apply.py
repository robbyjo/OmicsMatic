import shutil
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];out=b/'admission-1/source';out.mkdir()
for name in ['prism_catalog.py','review_sources.py','test_prism_catalog.py']:shutil.copyfile(r/'tools/literature/common_statistics'/name,out/name)
