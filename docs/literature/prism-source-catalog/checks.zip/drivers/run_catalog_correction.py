import hashlib,json,subprocess,time,traceback
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];out=b/'admission-1';out.mkdir();py='C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
def save(name,value):(out/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf8')
def run(name,args):
 cmd=[py,'-X','utf8','-B',*map(str,args)];save(name+'.command.json',cmd);began=time.monotonic()
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:p=subprocess.run(cmd,cwd=r,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=180)
 save(name+'.PROCESS.json',dict(exit_code=p.returncode,seconds=time.monotonic()-began));assert p.returncode==0,name;print('PASS',name,flush=True)
try:
 program=r/'tools/literature/common_statistics/prism_catalog.py';cache='D:/projects/JLinAlg/build/literature-review/xml'
 run('tests',[r/'tools/literature/common_statistics/test_prism_catalog.py'])
 run('apply',[program,'--apply','--primary-cache',cache,'--out',b/'apply-1'])
 run('verify',[program,'--verify','--primary-cache',cache,'--out',b/'verify-1'])
 run('current-method-source-review',[r/'tools/literature/common_statistics/review_sources.py','--xml-cache',cache,'--out',b/'current-method-source-review-1'])
 source=json.loads((b/'current-method-source-review-1/SOURCE_REVIEW.json').read_bytes());assert source['catalog_source_gap']['status']=='CORRECTED_ONE_PAPER_TOOL_RECORD_WITH_FOUR_SUPPORTING_POINTERS' and source['admitted_catalog_prism_papers']==47
 save('COMPLETED.json',dict(status='PASS_ONE_SOURCE_REVIEWED_PRISM_OBSERVATION_AND_FOUR_SUPPORTS_ADMITTED',source_hashes_verified_each_audit=250,python_tests=8,observations_added=1,reviews_added=1,supporting_pointers_added=4,unrelated_observations_and_reviews_preserved=True,current_catalog_checksums_verified=True,original_stale_manifest_retained=True,scientific_implementations_changed=False,new_integration_credit=0,website_deployed=False,whole_goal_complete=False))
except Exception as e:save('FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc()));print(repr(e),flush=True);raise
