import shutil
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];old=b/'plan-1/source';old.mkdir()
for name in ['prism_catalog.py','review_sources.py','test_prism_catalog.py']:shutil.copyfile(r/'tools/literature/common_statistics'/name,old/name)
p=r/'tools/literature/common_statistics/test_prism_catalog.py';text=p.read_text();assert text.count("self.assertIn('replicate-average',t['usage_context'])")==1;p.write_text(text.replace("self.assertIn('replicate-average',t['usage_context'])","self.assertIn('replicate-means',t['usage_context'])"),newline='\n')
p=b/'plan_and_test2.py';assert not p.exists();p.write_text((b/'plan_and_test.py').read_text().replace("out=b/'plan-1'","out=b/'plan-2'").replace("b/'source-plan-1'","b/'source-plan-2'"),newline='\n')
