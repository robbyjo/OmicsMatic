import hashlib,json,subprocess,time,traceback
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];out=b/'plan-2';out.mkdir();py='C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
def save(name,value):(out/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf8')
def run(name,cmd):
 save(name+'.command.json',cmd);began=time.monotonic()
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:p=subprocess.run(cmd,cwd=r,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=120)
 save(name+'.PROCESS.json',dict(exit_code=p.returncode,seconds=time.monotonic()-began));assert p.returncode==0,name;print('PASS',name,flush=True)
try:
 run('plan',[py,'-X','utf8','-B',str(r/'tools/literature/common_statistics/prism_catalog.py'),'--plan','--primary-cache','D:/projects/JLinAlg/build/literature-review/xml','--out',str(b/'source-plan-2')])
 run('tests',[py,'-X','utf8','-B',str(r/'tools/literature/common_statistics/test_prism_catalog.py')])
 data=r/'docs/literature/omics-2023-2026';bad=[];lines=(data/'SHA256SUMS').read_text().splitlines()
 for line in lines:
  sha,name=line.split('  ',1)
  if not (data/name).is_file() or hashlib.sha256((data/name).read_bytes()).hexdigest()!=sha:bad.append(name)
 save('PREDECESSOR-MANIFEST-AUDIT.json',dict(entries=len(lines),mismatches=bad));print('Predecessor manifest',len(lines),'entries; mismatches',bad,flush=True)
 save('COMPLETED.json',dict(status='PASS_REVIEWABLE_SOURCE_CORRECTION_PLAN_AND_EIGHT_TESTS',canonical_mutation_performed=False,predecessor_manifest_mismatches=bad))
except Exception as e:save('FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc()));print(repr(e),flush=True);raise
