#!/usr/bin/env python3
# Copyright (C) 2026 JLinAlg contributors; SPDX-License-Identifier: GPL-3.0-or-later
"""Run the unchanged250-paper audit with only an exact reviewed dispatcher view."""
from pathlib import Path
import argparse,json,sys,traceback
from dispatcher import reviewed_root,pin,PATH
from setup_deseq2_reference import ROOT,save
import audit_malt_source_catalog as inherited

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',required=True,type=Path);out=p.parse_args().out.resolve();assert out.is_relative_to(ROOT/'build/literature-review/nfcore-runtime') and not out.exists();out.mkdir(parents=True)
 state=dict(status='FAIL2_CURRENT_MALT_SOURCE_AUDIT_WITH_EXACT_NATIVE_DISPATCH_VIEW',whole_goal_complete=False)
 try:
  view,review=reviewed_root(ROOT);original_root,original_argv=inherited.ROOT,sys.argv
  try:
   inherited.ROOT=view;sys.argv=[str(Path(inherited.__file__)), '--out',str(out/'primary')];code=inherited.main()
  finally:inherited.ROOT=original_root;sys.argv=original_argv
  if code:raise ValueError('Unchanged primary-source audit failed; retain primary/COMPLETED.json diagnostics')
  result=json.loads((out/'primary/COMPLETED.json').read_bytes());assert result['source_papers']==250 and result['observations']==2479 and result['reviewed_uses']==1052
  if pin((ROOT/PATH).read_bytes())!=review['current']:raise ValueError('Live dispatcher changed during the complete primary-source audit')
  state.update(status='PASS250_CURRENT_PRIMARY_SOURCES_WITH_EXACT_REVIEWED_NATIVE_DISPATCH_VIEW',dispatch_view=review,primary_audit=result,scope='All250 current primary sources and live scientific source paths; exact reviewed predecessor dispatcher bytes only',scientific_verifiers_changed=False,paper_wide_semantic_review_open=True,new_tool_credit=0)
 except Exception as error:state.update(cause=repr(error),traceback=traceback.format_exc(),required_action='Retain diagnostics; review the exact named dispatcher/source/evidence change and rerun in a NEW directory. Never refresh historical hashes blindly or count a failed audit as catalog admission.')
 save(out/'COMPLETED.json',state);print(state['status'],state.get('cause',''),flush=True);return 0 if state['status'].startswith('PASS') else 2
if __name__=='__main__':
 if not __debug__:raise RuntimeError('Never disable complete source checks')
 raise SystemExit(main())
