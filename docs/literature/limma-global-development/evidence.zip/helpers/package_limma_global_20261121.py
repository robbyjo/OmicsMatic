from pathlib import Path
import hashlib,json,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/lm-5';B=T/'build/limma-global-1';Q=T/'docs/literature/limma-global-development'
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2,ensure_ascii=False);f.write('\n')
packaged=json.loads((B/'packaged-tests-1/COMPLETED.json').read_bytes());require=lambda ok,message:None if ok else (_ for _ in ()).throw(AssertionError(message))
require(packaged['tests_per_JVM']==78 and len(packaged['hosts'])==3,'Require78 tests per3 hosts')
dispatch=json.loads((B/'dispatch-controls-1/RESULT.json').read_bytes());require(dispatch['successful_capture_verifications']==18 and dispatch['neighbor_help_comparisons']==9 and len(dispatch['source_inverse_refusals'])==7,'Global/legacy control gate')
replays=json.loads((B/'global-replays-1/COMPLETED.json').read_bytes());require(len(replays['results'])==8,'Replay gate')
examples=json.loads((B/'EXAMPLES-COMPARISON.json').read_bytes());require(len(examples['cases'])==6,'Example gate')
context=json.loads((B/'preceding-context-1/RESULT.json').read_bytes());require(context['historical_status_unchanged'] and not context['old_reader_overlay_used'] and not context['old_hashes_refreshed'],'Unchanged preceding owner gate')
legacy=json.loads((B/'normal-gradle-2/COMPLETED.json').read_bytes());require(legacy['exit_code']==0 and sum(v['tests'] for v in legacy['reports'].values())==22 and not any(v['failures'] or v['errors'] or v['skipped'] for v in legacy['reports'].values()),'LegacyCLI gate')
for host in ['windows','linux']:
    value=json.loads((B/('source-controls-'+host+'-1/RESULT.json')).read_bytes());require(value['tests']==15 and value['positive_labels']==23 and not value['canonical_metadata_modified'],'Source-role gate')
jar=Path(packaged['jar_path']);require(pin(jar.read_bytes())==packaged['jar'] and pin(jar.read_bytes())==pin((B/'normal-gradle-2/project-build/cli/omicsmatic-0.4.0.jar').read_bytes()),'Producer byte identity')
roles=json.loads((Q/'SOURCE-ROLES.json').read_bytes())
table=['# Limma and voom: reviewed source roles','', '**23 label roles across18 papers are reviewed proposals.** Canonical admission is a separate guarded step; see the [current handover](HANDOVER_CURRENT.md). Voom belongs to the limma implementation family and adds zero family credit. Existing generic native method-overlap classes are not relabeled as source-equivalent.','', '| Paper | Reported limma edition | Reported use |','| --- | --- | --- |']
for role in roles['roles']:
    if role['tool_id']!='limma':continue
    editions=', '.join(v['literal']+' ('+v['operation']+')' for v in role['reported_editions']) or 'Not stated'
    label=role['paper_id']+(' (also voom)' if any(v['paper_id']==role['paper_id'] and v['tool_id']=='voom' for v in roles['roles']) else '')
    table.append('| ['+label+'](https://doi.org/'+role['doi']+') | '+editions+' | '+role['usage_summary'].replace('|','/')+' |')
table+=['','The full operation-specific cautions, literal name/edition witnesses and paragraph hashes are in [SOURCE-CENSUS.json](limma-global-development/SOURCE-CENSUS.json). All author-runtime, complete-preparation and whole-paper claims remain false. Current related operations are a capability cross-reference, not evidence that author callables/settings were reproduced.','', 'P059 describes replacement of historical stock limma by a scrattch summary-statistic reimplementation; only its unreviewed stock-limma observation is proposed for exclusion. P237 explicitly uses edgeR voomLmFit and gains no limma observation or extra family credit.','', 'P183 linked code loads limma and calls voom before a custom weighted residual step; it also contains alternative processing, explicit zero-depth replacement and sample-name rewriting. Those preparation choices are not silently adopted. [Pinned command log](https://github.com/LiChen1990/lncRNA_circRNA_eQTL/blob/532bb9334753e4c753ca92c5d8afb34ec6215a97/eQTL_mapping/HBCC.circRNA.eQTL.com.txt#L178).','', 'P203 linked code identifies limma for voom preprocessing and preprocessCore for subsequent quantile normalization. The latter is a separate provider requiring its own scoped audit. [Pinned RNA processing code](https://github.com/liusihan/population-compare-pipeline/blob/7df0eb9112af0860c2ecb3bf7a5c61aed07bc876/RNA-seq_processing.r#L77).','', 'These linked commits predate the papers but are not proven to be the executed paper commits or editions. Author code was read without execution and is not redistributed. Public evidence stores file/Git-blob pins and ten line hashes rather than source copies.','', 'P228 retains the authors’ voomLmFit-to-limma attribution and lowercase lmfit spelling as unresolved. Checked current namespaces assign voomLmFit to edgeR and expose lmFit in limma, not lowercase lmfit. The [linked Zenodo record](https://zenodo.org/records/15391244) points to a repository returning public404 at this audit. Supply an accessible archived author-code/version statement to resolve the binding; no private/deleted reason is inferred.','', '**SKIP3:** supply the exact named permitted runtime/package/source/input or retain the dependent-analysis skip. **FAIL2:** preserve original objects, partials and diagnostics, correct the named source/data/design/numerical/convergence/capacity/process cause and retry new output. Older editions and full author workflows are not supplied by current3.68.5 qualification. See the [workflow guide](LIMMA_WORKFLOWS.md).']
(T/'docs/literature/LIMMA_SOURCE_ROLES.md').write_text('\n'.join(table)+'\n',encoding='utf-8',newline='\n')
files={}
def add(path,name):require(name not in files,'Duplicate archive path');files[name]=path.read_bytes()
for folder in ['preceding-context-1','source-controls-windows-1','source-controls-linux-1','dispatch-controls-1','global-replays-1','global-examples-1']:
    for p in sorted((B/folder).rglob('*')):
        if p.is_file():add(p,'evidence/'+folder+'/'+p.relative_to(B/folder).as_posix())
for folder in ['normal-gradle-1','normal-gradle-2']:
    for name in ['COMMAND.json','COMPLETED.json','stdout','stderr']:add(B/folder/name,'evidence/'+folder+'/'+name)
for name in ['EXAMPLES-COMPARISON.json','packaged-tests-1/COMPLETED.json','packaged-tests-1/PAYLOADS.json','dispatcher-edit-1/CHANGE.json','dispatcher-edit-1/before.java','dispatcher-edit-1/after.java']:add(B/name,'evidence/'+name)
for host in ['windows21','windows25','linux21']:
    for suffix in ['.PROCESS.json','.stdout','.stderr']:add(B/'packaged-tests-1'/(host+suffix),'evidence/packaged-tests-1/'+host+suffix)
helpers=['start_limma_global_20261121.py','prepare_limma_global_route_20261121.py','intake_limma_global_sources_20261121.py','intake_limma_author_code_20261121.py','prepare_limma_code_witnesses_20261121.py','read_limma_linked_code_availability_20261121.py','qualify_limma_primary_roles_20261121.py','qualify_limma_primary_roles_retry_20261121.py','run_limma_global_gradle_20261121.py','run_limma_workflow_gradle_20261121.py','run_packaged_limma_global_20261121.py','run_packaged_limma_workflows_20261121.py','run_limma_global_examples_20261121.py','run_limma_global_replays_20261121.py','run_limma_replays_20261121.py','run_limma_root_regressions_20261121.py','check_limma_global_dispatch_20261121.py','package_limma_global_20261121.py']
for name in helpers:add(R/'build'/name,'helpers/'+name)
archive=Q/'evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for name,raw in sorted(files.items()):z.writestr(name,raw)
save(Q/'INVENTORY.json',dict(schema_version=1,files={n:pin(v) for n,v in sorted(files.items())},synthetic_objects_only=True,author_code_or_primary_paper_full_text_redistributed=False,installed_runtime_binaries_included=False))
source_names=['src/main/java/org/jlinalg/cli/JLinAlgCli.java','src/main/resources/org/jlinalg/omics/limma_workflow.R','src/test/java/org/jlinalg/cli/LimmaWorkflowTest.java','src/test/java/org/jlinalg/cli/LimmaGlobalCliTest.java','src/test/resources/org/jlinalg/cli/limma-workflow-originals.zip','src/test/resources/org/jlinalg/cli/limma-global-preceding-root-help.txt','tools/literature/verify_limma_global.py','tools/literature/limma_dispatch_transition.py','tools/literature/limma_global_context.py','tools/literature/limma_primary.py','tools/literature/limma_source_roles.py','tools/literature/check_limma_source_roles.py','tools/literature/limma_workflow/PackagedLimmaGlobalTests.java','docs/literature/LIMMA_WORKFLOWS.md','docs/literature/LIMMA_SOURCE_ROLES.md']
source_names+=sorted(p.relative_to(T).as_posix() for p in (T/'src/main/java/org/jlinalg/cli').glob('LimmaWorkflow*.java'))
for folder in ['src/main/resources/org/jlinalg/omics/limma-workflow','examples/limma-workflows']:
    source_names+=sorted(p.relative_to(T).as_posix() for p in (T/folder).rglob('*') if p.is_file())
saved={name:pin((Q/name).read_bytes()) for name in ['AUTHOR-CODE-WITNESSES.json','SOURCE-CENSUS.json','SOURCE-ROLES.json']}
profile=dict(schema_version=1,status='PASS_SAVED_GLOBAL_LIMMA_AND23_SOURCE_ROLES_NOT_CATALOG_ADMISSION',source_inputs={n:pin((T/n).read_bytes()) for n in source_names},saved_files=saved,archive=pin(archive.read_bytes()),inventory=pin((Q/'INVENTORY.json').read_bytes()),producer=packaged['jar'],producer_path=str(jar),packaged_tests_per_JVM=78,JVMs=3,global_original_examples=6,actual_original_replays=8,source_labels=23,source_papers=18,old_model_payloads_unchanged=23567,changed_payload='org/jlinalg/cli/JLinAlgCli.class',new_catalog_credit=0,whole_goal_complete=False)
save(Q/'PROFILE.json',profile)
(Q/'README.md').write_text('''# Global limma command and reviewed source-role evidence

The normal JAR exposes `limma-tools` RUN/VERIFY/REPLAY. Seventy-eight packaged
tests pass per JVM on Windows21/25 and Linux21, with six actual original-R
global examples, eight replays,18 cross-host successful verifications, exact
neighbor help comparisons and22 existing root/GCTA regression tests.
Only JLinAlgCli.class changes; all23,567 other producer payloads are identical.

The source audit reviews23 limma/voom labels across18 papers, with two exclusions,
two pinned linked-code sources,ten exact line-hash witnesses and15 semantic
refusal controls per Windows/Linux host. Voom adds zero second-family credit.
This packet awards no canonical admission or review credit by itself.
See [the source crosswalk](../LIMMA_SOURCE_ROLES.md) and the current handover.

Run `python -B tools/literature/verify_limma_global.py --out NEW_OUTPUT` to verify
saved source/archive bytes without Java,R,primary XML or a scientific model run.
Earlier original-model qualification remains in the pinned workflow checkpoint;
its unchanged owner was verified directly without source overlays/hash refresh.
Installed runtimes,JARs,primary full text and complete private evidence still
require separate checksummed transfer. No original-R Linux execution is claimed.
''',encoding='utf-8',newline='\n')
print('Saved global limma packet:',len(files),'files;producer',packaged['jar'],flush=True)
