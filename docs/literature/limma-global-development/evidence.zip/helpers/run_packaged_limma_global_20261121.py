from pathlib import Path
import ast
R=Path('D:/projects/JLinAlg');source=(R/'build/run_packaged_limma_workflows_20261121.py').read_text(encoding='utf-8')
for old,new in {
"T=R/'build/lm-4';B=T/'build/limma-qualification-1';G=B/'normal-gradle-2'":"T=R/'build/lm-5';B=T/'build/limma-global-1';G=B/'normal-gradle-1'",
"assert pin(jar)==pin(B/'normal-gradle-1/project-build/cli/omicsmatic-0.4.0.jar')":"assert normal['reports']['org.jlinalg.cli.LimmaGlobalCliTest']['tests']==6",
"R/'build/lm-3/build/limma-workflows-1/normal-gradle-2/project-build/cli/omicsmatic-0.4.0.jar'":"R/'build/lm-4/build/limma-qualification-1/normal-gradle-4/project-build/cli/omicsmatic-0.4.0.jar'",
"['org/jlinalg/omics/limma_workflow.R']":"['org/jlinalg/cli/JLinAlgCli.class']",
".glob('LimmaWorkflowTest*.class')":".glob('Limma*Test*.class')",
"PackagedWorkflowTests":"PackagedLimmaGlobalTests",
"LIMMA_WORKFLOW_PACKAGED_PASS tests=72":"LIMMA_GLOBAL_PACKAGED_PASS tests=78",
"PASS72":"PASS78","tests_per_JVM=72":"tests_per_JVM=78","PASS_72_NORMAL_JAR_WORKFLOW_TESTS_ON_THREE_JVMS":"PASS_78_NORMAL_JAR_LIMMA_GLOBAL_TESTS_ON_THREE_JVMS"
}.items():assert old in source,old;source=source.replace(old,new)
old="launcher=O/'launcher-classes'";new="shutil.copyfile(T/'src/test/resources/org/jlinalg/cli/limma-global-preceding-root-help.txt',resources/'limma-global-preceding-root-help.txt')\n"+old;assert old in source;source=source.replace(old,new)
ast.parse(source);exec(compile(source,__file__,'exec'))
