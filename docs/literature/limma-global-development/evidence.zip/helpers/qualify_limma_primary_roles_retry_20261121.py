from pathlib import Path
import ast
R=Path('D:/projects/JLinAlg');source=(R/'build/qualify_limma_primary_roles_20261121.py').read_text(encoding='utf-8');source=source.replace("O=B/'source-role-controls-1'","O=B/'source-role-controls-2'").replace("(Q/name).open('xb')","(Q/name).open('wb')");ast.parse(source);exec(compile(source,__file__,'exec'))
