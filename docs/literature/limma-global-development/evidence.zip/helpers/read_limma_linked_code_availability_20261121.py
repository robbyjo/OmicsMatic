from pathlib import Path
import datetime,hashlib,json,urllib.error,urllib.request
R=Path('D:/projects/JLinAlg');O=R/'build/lm-5/build/limma-global-1/linked-resource-observations-1';O.mkdir();rows=[]
for name,url in [('zenodo','https://zenodo.org/api/records/15391244'),('linked-repository','https://api.github.com/repos/QihuangZhang/SMS-RNA-seq')]:
    req=urllib.request.Request(url,headers={'User-Agent':'OmicsMatic-source-role-audit','Accept':'application/json'})
    try:
        with urllib.request.urlopen(req,timeout=45) as response:raw=response.read(2*1024*1024+1);status=response.status
    except urllib.error.HTTPError as error:raw=error.read(2*1024*1024+1);status=error.code
    assert len(raw)<=2*1024*1024;(O/(name+'.response')).write_bytes(raw);rows.append(dict(name=name,url=url,status=status,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),observed_at=datetime.datetime.now(datetime.timezone.utc).isoformat()))
    print(name,status,flush=True)
assert rows[1]['status']==404
(O/'RESULT.json').write_text(json.dumps(dict(status='SAVED_PUBLIC_CODE_AVAILABILITY_OBSERVATIONS',observations=rows,linked_repository_url='https://github.com/QihuangZhang/SMS-RNA-seq',observed_repository_publicly_accessible=False,does_not_establish_private_or_deleted_reason=True,dataset_downloaded=False,author_pipeline_executed=False),indent=2)+'\n',encoding='utf-8')
