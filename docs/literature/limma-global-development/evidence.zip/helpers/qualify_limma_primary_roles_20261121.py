from pathlib import Path
import copy,importlib,json,sys
R=Path('D:/projects/JLinAlg');T=R/'build/lm-5';B=T/'build/limma-global-1';O=B/'source-role-controls-1';O.mkdir();sys.path.insert(0,str(T/'tools/literature'));p=importlib.import_module('limma_primary')
result=p.audit(R/'build/literature-review/xml',B/'author-code-intake-1');Q=T/p.FOLDER
for name,value in [('SOURCE-CENSUS.json',result),('SOURCE-ROLES.json',dict(schema_version=1,status='REVIEWED_23_LIMMA_VOOM_LABEL_ROLES_NOT_CATALOG_ADMISSION',roles=result['roles'],exclusions=result['exclusions'],new_catalog_credit=0,whole_goal_complete=False))]:
    with (Q/name).open('xb') as f:f.write(p.encoded(value))
controls=[]
def refuse(name,edit):
    value=copy.deepcopy(result);edit(value)
    try:p.validate(value)
    except (ValueError,KeyError) as error:controls.append(dict(name=name,result='EXPECTED_REFUSAL',cause=str(error)))
    else:raise AssertionError('Admitted '+name)
refuse('lost-primary-identity',lambda v:v['roles'][0].update(doi='wrong'))
refuse('wrong-role-description',lambda v:v['roles'][0].update(usage_summary='Generic GSEA instead'))
refuse('dropped-second-methylation-edition',lambda v:next(r for r in v['roles'] if r['paper_id']=='P086')['reported_editions'].pop())
refuse('silently-completed-version-family',lambda v:next(r for r in v['roles'] if r['paper_id']=='P195')['reported_editions'][0].update(literal='3.44.0'))
refuse('repaired-author-attribution',lambda v:next(r for r in v['roles'] if r['paper_id']=='P228').update(provider_attribution_unresolved=False))
refuse('voom-credited-as-batch-provider',lambda v:next(r for r in v['roles'] if r['paper_id']=='P182' and r['tool_id']=='voom').update(qualified_related_current_operations=['BATCH']))
refuse('claimed-author-run',lambda v:v['roles'][0].update(author_runtime_executed=True))
refuse('claimed-full-preparation',lambda v:v['roles'][0].update(preparation_and_author_settings_complete=True))
refuse('claimed-whole-paper',lambda v:v['roles'][0].update(whole_paper_reproduced=True))
refuse('lost-exclusion',lambda v:v['exclusions'].pop())
refuse('alias-extra-family-credit',lambda v:v.update(alias_additional_integration_credit=1))
refuse('modified-source-offset',lambda v:v['roles'][0]['source_name_witness'].update(character_offset=0))
refuse('different-pinned-code',lambda v:next(r for r in v['roles'] if r['paper_id']=='P183')['linked_code_source'].update(commit='0'*40))
refuse('dropped-alias-role',lambda v:v['roles'].pop())
(O/'RESULT.json').write_bytes(p.encoded(dict(status='PASS_FRESH_250_PRIMARY_AND23_LABEL_ROLES_WITH14_REFUSALS',roles=23,papers=18,primary_candidates=20,code_sources=2,controls=controls,new_canonical_reviews=0,canonical_metadata_modified=False)))
print('PASS all250 source identities;23 reviewed labels across18 papers;14 semantic refusals',flush=True)
