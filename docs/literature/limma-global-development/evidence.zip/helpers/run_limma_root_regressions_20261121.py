from pathlib import Path
import ast,sys
R=Path('D:/projects/JLinAlg');source=(R/'build/run_limma_global_gradle_20261121.py').read_text(encoding='utf-8');old="ast.parse(source);exec(compile(source,__file__,'exec'))";new="source=source.replace(\"'org.jlinalg.cli.Limma*Test'\",\"'org.jlinalg.cli.GctaGlobalDispatchTest','--tests','org.jlinalg.cli.JLinAlgCliTest'\")\n"+old;assert source.count(old)==1;source=source.replace(old,new);sys.argv=[__file__,'2'];ast.parse(source);exec(compile(source,__file__,'exec'))
