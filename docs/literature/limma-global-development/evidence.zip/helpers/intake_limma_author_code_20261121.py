from pathlib import Path
import hashlib,json,re,urllib.parse,urllib.request
R=Path('D:/projects/JLinAlg');T=R/'build/lm-5';B=T/'build/limma-global-1';O=B/'author-code-intake-1';O.mkdir()
def get(url,cap):
    req=urllib.request.Request(url,headers={'User-Agent':'OmicsMatic-source-role-audit','Accept':'application/vnd.github+json' if 'api.github.com' in url else 'application/octet-stream'})
    with urllib.request.urlopen(req,timeout=45) as response:raw=response.read(cap+1)
    assert len(raw)<=cap,url
    return raw
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
rows=[]
for pid,repo,branch in [('P183','LiChen1990/lncRNA_circRNA_eQTL','main'),('P203','liusihan/population-compare-pipeline','master')]:
    folder=O/pid;folder.mkdir();commit_raw=get('https://api.github.com/repos/'+repo+'/commits/'+branch,2*1024*1024);(folder/'COMMIT.json').write_bytes(commit_raw);commit=json.loads(commit_raw);sha=commit['sha'];assert re.fullmatch('[0-9a-f]{40}',sha)
    tree_raw=get('https://api.github.com/repos/'+repo+'/git/trees/'+sha+'?recursive=1',8*1024*1024);(folder/'TREE.json').write_bytes(tree_raw);tree=json.loads(tree_raw);assert not tree.get('truncated')
    selected=[r for r in tree['tree'] if r['type']=='blob' and Path(r['path']).suffix.lower() in ['.r','.rmd','.sh','.py','.md','.txt','.yml','.yaml'] and r.get('size',0)<=2*1024*1024];assert len(selected)<1000 and sum(r.get('size',0) for r in selected)<32*1024*1024
    files=[];hits=[]
    for r in selected:
        name=r['path'];p=Path(name);assert not p.is_absolute() and '..' not in p.parts
        url='https://raw.githubusercontent.com/'+repo+'/'+sha+'/'+urllib.parse.quote(name,safe='/');raw=get(url,2*1024*1024);assert len(raw)==r['size'];target=folder/'files'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);files.append(dict(path=name,url=url,git_blob_sha=r['sha'],**pin(raw)))
        try:text=raw.decode('utf-8-sig')
        except UnicodeDecodeError:continue
        lines=text.splitlines()
        for i,line in enumerate(lines):
            if re.search(r'limma|\bvoom\b|normalize[.]quantiles|normalizeBetweenArrays',line,re.I):hits.append(dict(path=name,line=i+1,text=line,context=lines[max(0,i-2):min(len(lines),i+3)]))
    result=dict(paper_id=pid,repository='https://github.com/'+repo,branch_observed=branch,commit=sha,commit_date=commit['commit']['committer']['date'],commit_metadata=pin(commit_raw),tree_metadata=pin(tree_raw),files=files,hits=hits,source_only_audit=True,author_pipeline_executed=False,paper_edition_or_commit_correspondence_proven=False)
    (folder/'RESULT.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8');rows.append(result)
    print(pid,sha,'files',len(files),'matching lines',len(hits),flush=True)
    for hit in hits:print(' ',hit['path'],hit['line'],hit['text'][:240],flush=True)
(O/'COMPLETED.json').write_text(json.dumps(dict(status='SAVED_TWO_PINNED_LINKED_AUTHOR_REPOSITORIES_READ_ONLY',repositories=[{k:v for k,v in r.items() if k not in ['files','hits']} for r in rows]),indent=2)+'\n',encoding='utf-8')
