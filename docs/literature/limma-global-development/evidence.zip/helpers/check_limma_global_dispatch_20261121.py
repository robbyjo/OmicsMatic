from pathlib import Path
import concurrent.futures,importlib.util,json,subprocess
R=Path('D:/projects/JLinAlg');T=R/'build/lm-5';B=T/'build/limma-global-1';O=B/'dispatch-controls-1';O.mkdir();jar=B/'normal-gradle-1/project-build/cli/omicsmatic-0.4.0.jar';prior=R/'build/lm-4/build/limma-qualification-1/normal-gradle-4/project-build/cli/omicsmatic-0.4.0.jar'
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
m=load('limma_transition',T/'tools/literature/limma_dispatch_transition.py');g=load('gcta_transition',T/'tools/literature/gcta_dispatch_transition.py');raw=(T/m.DISPATCH).read_bytes();before=m.dispatcher_before(raw);assert before==subprocess.check_output(['git','show',m.BASE+':'+m.DISPATCH],cwd=T);g.dispatcher_before(before)
refusals=[]
for name,bad in {'missing-route':raw.replace(m.ROUTE,b'',1),'missing-help':raw.replace(m.HELP,b'',1),'duplicate-route':raw+m.ROUTE,'duplicate-help':raw+m.HELP,'moved-route':raw.replace(m.ROUTE,b'',1)+m.ROUTE,'moved-help':raw.replace(m.HELP,b'',1)+m.HELP,'unrelated-change':raw+b'\n'}.items():
    try:m.dispatcher_before(bad)
    except ValueError as e:refusals.append(dict(name=name,cause=str(e)))
    else:raise AssertionError('Accepted '+name)
def linux(path):return '/mnt/d/'+path.relative_to(Path('D:/')).as_posix()
def run(host):
    folder=O/host;folder.mkdir();rows={}
    prefix=['wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','--exec','/usr/bin/java'] if host=='linux21' else ['C:/Program Files/Java/jdk-25/bin/java.exe' if host=='windows25' else 'C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe']
    def process(name,artifact,args):
        command=prefix+['-jar',linux(artifact) if host=='linux21' else str(artifact),*args]
        with (folder/(name+'.stdout')).open('xb') as stdout,(folder/(name+'.stderr')).open('xb') as stderr:p=subprocess.run(command,cwd=T,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=60)
        rows[name]=dict(command=command,exit_code=p.returncode);return p.returncode,(folder/(name+'.stdout')).read_bytes(),(folder/(name+'.stderr')).read_bytes()
    for name in ['LM','VOOM','EDGER_VOOM_LMFIT','BATCH','NORMALIZE','CAMERAPR']:
        capture=B/'global-examples-1'/name/'analysis';result=process('VERIFY-'+name,jar,['limma-tools','--verify',linux(capture) if host=='linux21' else str(capture)]);assert result[0]==0,(host,name,result[2])
    for command in ['gcta-tools','broad-gsea-tools','edger-tools']:
        old=process('OLD-'+command,prior,[command,'--help']);new=process('NEW-'+command,jar,[command,'--help']);assert old==new and old[0]==0,(host,command)
    (folder/'RESULT.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8');print(host,'PASS6 real global verifies and3 exact neighbor help comparisons',flush=True);return host,rows
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:hosts=dict(pool.map(run,['windows21','windows25','linux21']))
(O/'RESULT.json').write_text(json.dumps(dict(status='PASS_GLOBAL_LIMMA_DISPATCH_AND_EXACT_LEGACY_NEIGHBOR_CONTRACTS',hosts=hosts,successful_capture_verifications=18,neighbor_help_comparisons=9,source_inverse_refusals=refusals,scientific_source_changed=False),indent=2)+'\n',encoding='utf-8')
