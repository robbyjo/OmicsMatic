from pathlib import Path
import json,subprocess
R=Path('D:/projects/JLinAlg');T=R/'build/lm-5';BASE='521b04bee9289b6113a0562d0d8a8366a0f9dbdf'
assert not T.exists() and subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],cwd=R).decode().split()[0]==BASE
subprocess.run(['git','worktree','add','-b','codex/limma-global-20261121',str(T),BASE],cwd=R,check=True)
B=T/'build/limma-global-1';B.mkdir(parents=True)
(B/'START.json').write_text(json.dumps(dict(base=BASE,previous_goal_turn='progress',previous_evidence='Published 35 exact files; original error-preserving normal-JAR workflows with 46 compositions and 169 identical complete objects;72 packaged tests on3 JVMs;34 worktrees and739919 protected artifacts',task='Register the limma command and resolve primary-paper source roles before guarded admission',whole_goal_complete=False),indent=2)+'\n',encoding='utf-8')
print('Created',T,flush=True)
