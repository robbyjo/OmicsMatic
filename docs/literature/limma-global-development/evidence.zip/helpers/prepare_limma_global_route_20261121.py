from pathlib import Path
import hashlib,json,subprocess
R=Path('D:/projects/JLinAlg');T=R/'build/lm-5';B=T/'build/limma-global-1';O=B/'dispatcher-edit-1';O.mkdir()
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
name='src/main/java/org/jlinalg/cli/JLinAlgCli.java';path=T/name;before=path.read_bytes();assert pin(before)==dict(bytes=56054,sha256='8c656d6b1cb0bb17eea925f3d593684ed667ca74bc289682d166d040e3ded72b')
jar=R/'build/lm-4/build/limma-qualification-1/normal-gradle-4/project-build/cli/omicsmatic-0.4.0.jar';assert pin(jar.read_bytes())==dict(bytes=196453730,sha256='04f860d391c7a7b795b39ce75ae2a3b25c8b51b9096b5cfe798b9ebd6023fc1f')
command=['C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe','-jar',str(jar),'--help'];p=subprocess.run(command,cwd=T,stdin=subprocess.DEVNULL,capture_output=True,timeout=30);assert p.returncode==0 and not p.stderr
(O/'preceding-root-help.stdout').write_bytes(p.stdout);(O/'preceding-root-help.stderr').write_bytes(p.stderr)
target=T/'src/test/resources/org/jlinalg/cli/limma-global-preceding-root-help.txt';assert not target.exists();target.write_bytes(p.stdout)
anchor=b'            if (arguments.length > 0 && arguments[0].equals("edger-tools"))\n';help_anchor=b'              java -jar omicsmatic-<version>.jar edger-tools --help\n'
route=b'            if (arguments.length > 0 && arguments[0].equals("limma-tools"))\n                return LimmaWorkflowCli.run(Arrays.copyOfRange(arguments, 1, arguments.length), output, errorOutput);\n';help_line=b'              java -jar omicsmatic-<version>.jar limma-tools --help\n'
assert before.count(anchor)==before.count(help_anchor)==1 and b'"limma-tools"' not in before
after=before.replace(anchor,route+anchor,1).replace(help_anchor,help_line+help_anchor,1)
(O/'before.java').write_bytes(before);(O/'after.java').write_bytes(after);path.write_bytes(after)
(O/'CHANGE.json').write_text(json.dumps(dict(base='521b04bee9289b6113a0562d0d8a8366a0f9dbdf',path=name,before=pin(before),after=pin(after),lines_added=3,scientific_engines_changed=False,preceding_root_help=pin(p.stdout),preceding_producer=pin(jar.read_bytes())),indent=2)+'\n',encoding='utf-8')
module='''"""Exact additive limma global route/help inverse; no scientific source/hash waiver."""
import hashlib
DISPATCH=%r
BASE='521b04bee9289b6113a0562d0d8a8366a0f9dbdf'
BEFORE=%r
AFTER=%r
ROUTE=%r
HELP=%r
ANCHOR=%r
HELP_ANCHOR=%r

def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

def require(ok,message):
    if not ok:raise ValueError(message)

def dispatcher_before(after):
    require(after.count(ROUTE)==after.count(HELP)==1,'Missing/duplicate limma global route/help')
    before=after.replace(ROUTE,b'',1).replace(HELP,b'',1)
    require(pin(before)==BEFORE and pin(after)==AFTER,'Dispatcher differs beyond the three limma lines')
    require(before.count(ANCHOR)==before.count(HELP_ANCHOR)==1,'Ambiguous original edgeR anchors')
    require(after==before.replace(ANCHOR,ROUTE+ANCHOR,1).replace(HELP_ANCHOR,HELP+HELP_ANCHOR,1),'Limma route/help moved outside reviewed anchors')
    return before
'''%(name,pin(before),pin(after),route,help_line,anchor,help_anchor)
(T/'tools/literature/limma_dispatch_transition.py').write_text(module,encoding='utf-8',newline='\n');print('Added exactly three global limma route/help lines',pin(after),flush=True)
