from pathlib import Path
import ast,sys
R=Path('D:/projects/JLinAlg');source=(R/'build/run_limma_workflow_gradle_20261121.py').read_text(encoding='utf-8')
source=source.replace("T=R/'build/lm-3';B=T/'build/limma-workflows-1'","T=R/'build/lm-5';B=T/'build/limma-global-1'").replace("'org.jlinalg.cli.LimmaWorkflowTest'","'org.jlinalg.cli.Limma*Test'")
old="sources=O/'sources';sources.mkdir()";new="names+=['src/main/java/org/jlinalg/cli/JLinAlgCli.java','src/test/java/org/jlinalg/cli/LimmaGlobalCliTest.java','src/test/resources/org/jlinalg/cli/limma-global-preceding-root-help.txt','tools/literature/limma_dispatch_transition.py']\n"+old;assert old in source;source=source.replace(old,new)
ast.parse(source);exec(compile(source,__file__,'exec'))
