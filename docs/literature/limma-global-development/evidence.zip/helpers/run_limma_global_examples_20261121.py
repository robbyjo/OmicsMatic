from pathlib import Path
import hashlib,json,subprocess
R=Path('D:/projects/JLinAlg');T=R/'build/lm-5';B=T/'build/limma-global-1';O=B/'global-examples-1';jar=B/'normal-gradle-1/project-build/cli/omicsmatic-0.4.0.jar';script=T/'examples/limma-workflows/run_examples.py'
command=['C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe','-X','utf8','-B',str(script),'--jar',str(jar),'--java','C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe','--rscript','C:/Program Files/R/R-4.6.1/bin/Rscript.exe','--r-libraries',str(R/'build/literature-review/monocle-runtime/idep244-adopted-provider-4/libraries-requested.txt'),'--out',str(O)]
p=subprocess.run(command,cwd=T,stdin=subprocess.DEVNULL,capture_output=True,timeout=180);(B/'examples.stdout').write_bytes(p.stdout);(B/'examples.stderr').write_bytes(p.stderr);assert p.returncode==0,p.stderr.decode(errors='replace')
rows=json.loads((O/'COMPLETED.json').read_bytes());assert len(rows)==6 and all(v['exit_code']==0 and v['VERIFY_exit_code']==0 for v in rows.values())
def pins(root):return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.iterdir() if p.is_file()}
for name in rows:assert pins(O/name/'analysis/results')==pins(R/'build/lm-4/build/limma-qualification-1/normal-originals-2'/name/'analysis/results'),name
(B/'EXAMPLES-COMPARISON.json').write_text(json.dumps(dict(status='PASS_SIX_GLOBAL_COMMAND_EXAMPLES_AND_IDENTICAL_ORIGINAL_EXPORTS',command=command,exit_code=p.returncode,cases=list(rows),runner_sha256=hashlib.sha256(script.read_bytes()).hexdigest()),indent=2)+'\n',encoding='utf-8');print('PASS six global command examples; exported bytes identical to original controls',flush=True)
