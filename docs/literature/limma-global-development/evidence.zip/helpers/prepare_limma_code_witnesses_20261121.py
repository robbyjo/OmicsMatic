from pathlib import Path
import hashlib,json,re
R=Path('D:/projects/JLinAlg');T=R/'build/lm-5';B=T/'build/limma-global-1';Q=T/'docs/literature/limma-global-development';Q.mkdir()
specs={
 'P183':('eQTL_mapping/HBCC.circRNA.eQTL.com.txt',[
  ('limma-import',r'^library\(limma\)$',0),('voom-call',r'=voom\(',0),('weighted-residual-call',r'^CIRI[.]JUNCTION[.]PASS[.]voom[.]log[.]Res=calcResiduals\(',0),('zero-depth-median-rule',r'^CIRI[.]JUNCTION[.]depth\[which\(.*=median',0),('sample-name-rewrite',r'^colnames\(CIRI[.]JUNCTION[.]mat\)<-gsub',0),('alternative-untransformed-residual-path',r'^CIRI[.]JUNCTION[.]PASS[.]voom[.]log[.]Res=calcResiduals\(CIRI[.]JUNCTION[.]mat',0)]),
 'P203':('RNA-seq_processing.r',[
  ('limma-import',r'^library\(limma\)$',0),('voom-E-call',r'^log2cpm<-voom\(count2\)\$E',0),('preprocessCore-import',r'^library\(preprocessCore\)$',0),('separate-quantile-normalization',r'^log2cpm[.]fgene[.]fsample[.]qn<-normalize[.]quantiles\(',0)])}
rows=[]
for pid,(name,patterns) in specs.items():
    folder=B/'author-code-intake-1'/pid;result=json.loads((folder/'RESULT.json').read_bytes());file=next(f for f in result['files'] if f['path']==name);raw=(folder/'files'/name).read_bytes();assert hashlib.sha256(raw).hexdigest()==file['sha256'];lines=raw.decode('utf-8-sig').splitlines();witnesses=[]
    for label,pattern,which in patterns:
        hits=[i for i,line in enumerate(lines) if re.search(pattern,line)];assert len(hits)>which,(pid,label);i=hits[which];witnesses.append(dict(label=label,line_number=i+1,line_sha256=hashlib.sha256(lines[i].encode()).hexdigest(),pattern=pattern))
    rows.append(dict(paper_id=pid,repository=result['repository'],commit=result['commit'],commit_date=result['commit_date'],file=file,witnesses=witnesses,author_pipeline_executed=False,paper_executed_commit_correspondence_proven=False,source_only_audit=True,original_author_code_redistributed=False))
availability=json.loads((B/'linked-resource-observations-1/RESULT.json').read_bytes())
data=dict(schema_version=1,status='PASS_TWO_PINNED_LINKED_AUTHOR_CODE_SOURCE_WITNESSES_NOT_EXECUTION',repositories=rows,P228_public_code_observation=availability,code_only_followups=[dict(paper_id='P203',provider='preprocessCore',operation='normalize.quantiles',canonical_addition_or_credit=0,reason='Separate provider identified in linked code; requires its own scoped catalog/implementation audit')])
(Q/'AUTHOR-CODE-WITNESSES.json').write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n');print('Saved10 exact line-hash witnesses, no author code redistribution',flush=True)
