from pathlib import Path
import gzip,hashlib,json,re,sys,xml.etree.ElementTree as ET
R=Path('D:/projects/JLinAlg');T=R/'build/lm-5';B=T/'build/limma-global-1';O=B/'primary-intake-1';O.mkdir();sys.path.insert(0,str(T/'tools/literature'));from collect_omics_review import paragraphs
old=json.loads((T/'docs/literature/limma-source-review-proposal/CENSUS.json').read_bytes());pattern=re.compile(old['pattern'],re.I);reviews={r['paper_id']:r for r in old['reviews']};candidates=[]
for identity in old['source_identities']:
    with gzip.open(R/'build/literature-review/xml'/(identity['pmcid']+'.xml.gz'),'rb') as f:raw=f.read(64*1024*1024+1)
    assert len(raw)<=64*1024*1024 and hashlib.sha256(raw).hexdigest()==identity['xml_sha256'],identity['paper_id']
    root=ET.fromstring(raw);doi=[n.text for n in root.findall('front/article-meta/article-id') if n.get('pub-id-type')=='doi'];assert len(doi)==1 and doi[0].lower()==identity['doi'].lower()
    blocks=paragraphs(root);hits=[b for b in blocks if pattern.search(b['text']) or pattern.search(b.get('match_text',b['text']))]
    if not hits:continue
    pid=identity['paper_id'];assert pid in reviews,pid;spec=reviews[pid];assert [b['paragraph_index'] for b in hits]==[a['paragraph_index'] for a in spec['anchors']],pid
    for b,a in zip(hits,spec['anchors'],strict=True):assert hashlib.sha256(b['text'].encode()).hexdigest()==a['paragraph_sha256'] and hashlib.sha256(b.get('match_text',b['text']).encode()).hexdigest()==a['matching_text_sha256'],pid
    links=[]
    for n in root.iter():
        if n.tag.split('}')[-1]=='ext-link':
            href=n.get('{http://www.w3.org/1999/xlink}href','')
            if href and any(k in href.lower() for k in ['github','zenodo','figshare','codeocean','osf.io']):links.append(href)
    text='\n\n'.join('PARAGRAPH '+str(b['paragraph_index'])+' | '+b['section']+'\n'+b['text'] for b in hits)
    (O/(pid+'.txt')).write_text(text+'\n\nCODE LINKS\n'+'\n'.join(dict.fromkeys(links))+'\n',encoding='utf-8',newline='\n')
    candidates.append(dict(paper_id=pid,doi=identity['doi'],pmcid=identity['pmcid'],anchors=spec['anchors'],code_links=list(dict.fromkeys(links))))
assert len(candidates)==20
(O/'RESULT.json').write_text(json.dumps(dict(status='PASS_FRESH_250_IDENTITIES_AND_20_LIMMA_RELATED_CONTEXTS',source_identities=old['source_identities'],candidates=candidates,canonical_metadata_modified=False),indent=2)+'\n',encoding='utf-8');print('Verified all250 XML/DOI identities and all20 exact limma-related source contexts',flush=True)
