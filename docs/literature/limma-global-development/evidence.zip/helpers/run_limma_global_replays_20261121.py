from pathlib import Path
import ast
R=Path('D:/projects/JLinAlg');source=(R/'build/run_limma_replays_20261121.py').read_text(encoding='utf-8')
for old,new in {
"T=R/'build/lm-4';B=T/'build/limma-qualification-1';O=B/'normal-replays-1'":"T=R/'build/lm-5';B=T/'build/limma-global-1';O=B/'global-replays-1'",
"parent=B/'normal-originals-1'/name/'analysis'":"parent=R/'build/lm-4/build/limma-qualification-1/normal-originals-2'/name/'analysis'",
"[J,'-cp',str(jar),'org.jlinalg.cli.LimmaWorkflowCli',*args]":"[J,'-jar',str(jar),'limma-tools',*args]",
'PASS_EIGHT_NORMAL_JAR_REPLAYS_AND_IMMUTABLE_PARENTS':'PASS_EIGHT_GLOBAL_COMMAND_REPLAYS_AND_IMMUTABLE_PARENTS'
}.items():assert old in source;source=source.replace(old,new)
ast.parse(source);exec(compile(source,__file__,'exec'))
