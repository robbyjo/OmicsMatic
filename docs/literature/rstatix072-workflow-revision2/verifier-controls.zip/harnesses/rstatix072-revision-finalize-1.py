from pathlib import Path
import hashlib,json,os,zipfile
ROOT=Path('D:/projects/JLinAlg');B=ROOT/'build/literature-review/monocle-runtime';OUT=Path(__file__).with_suffix('');DATA=ROOT/'docs/literature/rstatix072-workflow-revision2';GATE=B/'rstatix072-revision-qualified-gate-1'

def pin(p):
 h=hashlib.sha256();n=0
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block);n+=len(block)
 return dict(bytes=n,sha256=h.hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf8',newline='\n')
proof=json.loads((DATA/'VALIDATION.json').read_bytes());core=json.loads((GATE/'core/COMPLETED.json').read_bytes());controls=json.loads((GATE/'refusals/COMPLETED.json').read_bytes())
assert core['status']==proof['status'] and core['linux_workflow_controls']==41
assert controls['status']=='PASS_REVISION2_FROZEN_VERIFIER_BASELINE_AND_FOUR_REFUSALS' and len(controls['refusal_controls'])==4
assert all(r['exit_code']==0 for r in json.loads((GATE/'PROCESSES.json').read_bytes()))
OUT.mkdir(exist_ok=False)
for n,wanted in proof['sources'].items():assert pin(ROOT/n)==wanted,n
before=json.loads((B/'rstatix072-revision-diagnostic-preflight-1/BEFORE.json').read_bytes())
for n,wanted in before['catalog'].items():assert pin(ROOT/n)==wanted,n
for row in before['protected']:assert pin(ROOT/row['path'])=={k:row[k] for k in ['bytes','sha256']}
row=before['canonical'];assert pin(ROOT/row['path'])=={k:row[k] for k in ['bytes','sha256']}
members=json.loads((DATA/'MEMBERS.json').read_bytes());links=json.loads((DATA/'LINK_IDENTITIES.json').read_bytes());directories=json.loads((DATA/'DIRECTORY_IDENTITIES.json').read_bytes())
blocked=[f'validation-{version}/protocols-linux/{case}/{name}' for version in [2,3] for case,name in [('warning-report-path-blocked','WARNINGS.md'),('status-report-path-blocked','analysis-status.json')]]
assert all(n in directories for n in blocked) and len(links)==2
with zipfile.ZipFile(DATA/'controls.zip') as archive:
 for link in links:
  owned=link['path'].split('/results/')[0];manifest=json.loads(archive.read(owned+'/MANIFEST.json'))
  assert manifest['files']['results/result.txt']==dict(kind='symlink',target=link['target'])
  assert link['path'] not in members
retention=dict(status='PASS_COMPLETE_LINK_AND_BLOCKED_EMPTY_DIRECTORY_IDENTITIES',retained_links=links,blocked_empty_directory_identities=blocked,all_empty_directories=len(directories),no_link_targets_followed=True,original_scientific_sources_changed=False)
save(DATA/'RETENTION_AUDIT.json',retention)
first=next(iter(members));raw_worker=next(n for n in members if n.endswith('/diagnostics/worker-status.json'))
deltas=dict(base_index=pin(DATA/'MEMBERS.json'),incomplete_index=dict(remove_exact_key=first,retained_members=len(members)-1),corrupted_index=dict(path=raw_worker,replace_field='sha256',previous_value=members[raw_worker]['sha256'],replacement='0'*64,retained_members=len(members)),all_other_values_unchanged=True,lossless_reconstruction='Read the exact base MEMBERS.json in insertion order, remove the named one key for the incomplete-index control; separately replace exactly the one named SHA256 string for the corrupted-binding control. test_verify.py executes these complete derived inputs.')
save(GATE/'NEGATIVE_INPUT_DELTAS.json',deltas)
aux={}
with zipfile.ZipFile(DATA/'verifier-controls.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9,allowZip64=True) as archive:
 for p in sorted(GATE.rglob('*')):
  if p.is_file():
   assert not p.is_symlink();name=p.relative_to(GATE).as_posix();aux[name]=pin(p);archive.write(p,name)
 archive.write(Path(__file__),'harnesses/'+Path(__file__).name);aux['harnesses/'+Path(__file__).name]=pin(Path(__file__))
save(DATA/'VERIFIER_CONTROL_MEMBERS.json',aux)
summary=json.loads((ROOT/'docs/literature/omics-2023-2026/summary.json').read_bytes())
assert summary['implementation_status_counts']['missing']==264
cumulative=dict(status='PASS_REVISION2_COMPLETE_SCIENTIFIC_POPULATION_PREDECESSORS_AND_FOUR_FROZEN_REFUSALS',base_validation=pin(DATA/'VALIDATION.json'),source_pins=proof['sources'],base_qualification=core,verifier_controls=controls,auxiliary_archive=pin(DATA/'verifier-controls.zip'),auxiliary_members=pin(DATA/'VERIFIER_CONTROL_MEMBERS.json'),auxiliary_archive_files=len(aux),retention_audit=pin(DATA/'RETENTION_AUDIT.json'),new_tool_credit=0,main_catalog_changed=False,canonical_unchanged=True,unfinished_files_preserved=23,paper_semantic_review_open=True,whole_goal_complete=False)
save(DATA/'CUMULATIVE_VERIFICATION.json',cumulative)
lines=[]
for p in sorted(DATA.iterdir()):
 if p.is_file() and p.name!='SHA256SUMS':lines.append(pin(p)['sha256']+'  '+p.name)
(DATA/'SHA256SUMS').write_text('\n'.join(lines)+'\n',encoding='ascii',newline='\n')
save(OUT/'NEXT_STEPS.json',dict(required_next='Add a zero-credit current-catalog routing update from the historical rstatix072_workflow entry point to the qualified revision2. Preserve all1156 reviews, all2671 observations, all250 papers, counts109/264, the exact historical eight-metadata views, all original source bytes and every failed attempt. Make the existing diagnostic bug and new recovery commands prominent without rewriting historical guides/proofs. Then continue missing-tool implementations and unreviewed source roles.',inventory_priority_field='Use implementation_status for admitted current coverage; current_coverage retains base extraction values for older integrations.',monocle_note='Nine Monocle paper uses are already individually reviewed, with candidate components and current-readiness guides. Do not count those as new reviews or assume a candidate is a complete reported-edition workflow.',new_tool_credit=0,whole_goal_complete=False))
save(OUT/'COMPLETED.json',dict(status=cumulative['status'],archive=proof['archive'],auxiliary_archive=cumulative['auxiliary_archive'],complete_archive_files=core['complete_archive_files'],source_files=len(proof['sources']),preserved_unfinished_files=23,canonical_unchanged=True,whole_goal_complete=False))
print(json.dumps(json.loads((OUT/'COMPLETED.json').read_bytes()),indent=2),flush=True)
