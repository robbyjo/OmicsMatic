writeLines('partial exact α',file.path(result_directory,'result.txt'))
writeChar('{"status":',file.path(result_directory,'..','diagnostics','worker-status.json'),eos=NULL)
quit(save='no',status=0,runLast=FALSE)
