dir.create(file.path(result_directory,'..','analysis-status.json'));writeLines('complete',file.path(result_directory,'result.txt'));analysis_complete <- 'COMPLETE'
