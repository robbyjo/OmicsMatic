dir.create(file.path(result_directory,'..','WARNINGS.md'));writeLines('complete',file.path(result_directory,'result.txt'));analysis_complete <- 'COMPLETE'
