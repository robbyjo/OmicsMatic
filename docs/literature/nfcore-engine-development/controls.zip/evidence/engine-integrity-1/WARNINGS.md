# FAIL2 nf-core foundation integrity controls failed

AssertionError()

Required action: No result admitted. Preserve owned roots and reports, inspect the original cause and rerun corrected controls to NEW paths. Never change scientific settings or weaken verification to hide a failure.
