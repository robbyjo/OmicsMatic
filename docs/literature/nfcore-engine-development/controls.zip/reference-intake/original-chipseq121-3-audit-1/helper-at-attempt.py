"""Read-only source-derived report-path audit; retain the historical guessed-path FAIL2 receipt."""
import csv,hashlib,json,os,re,subprocess,sys,traceback
from pathlib import Path
if sys.platform!='linux':raise SystemExit(subprocess.call(['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/python3','/mnt/d/projects/JLinAlg/build/literature-review/nfcore-runtime/audit_original_chipseq121_pcr_reference.py']))
root=Path('/mnt/d/projects/JLinAlg');base=root/'build/literature-review/nfcore-runtime';old=base/'original-chipseq121-3';out=base/'original-chipseq121-3-audit-1';assert not out.exists();out.mkdir()
def pin(p):
 h=hashlib.sha256();size=0
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):size+=len(b);h.update(b)
 return dict(bytes=size,sha256=h.hexdigest())
def save(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
state=dict(status='FAIL2_ORIGINAL_CHIPSEQ121_ADDITIONAL_PCR_CONTROL_EXECUTION_AUDIT',scientific_result_admitted=False,new_catalog_credit=False)
action='Read-only execution-intake audit only. Retain the earlier guessed-report-path FAIL2 and original insufficient-depth fixture failures. Complete native original-pipeline/scientific output contracts before admission. Preserve original reads, all defaults, failed attempts, output files and warnings. These explicitly synthetic PCR controls do not reproduce a paper or establish independent biological accuracy.'
try:
 historical=pin(old/'COMPLETED.json');prior=json.loads((old/'COMPLETED.json').read_bytes());assert prior['cause']=="AssertionError('Complete original report missing')"
 assert json.loads((old/'original-process.json').read_bytes())['exit_code']==0
 before=json.loads((old/'immutable-inputs-before.json').read_bytes());assert all(pin(Path(p))==v for p,v in before.items())
 launch=json.loads((old/'RUNNING.json').read_bytes());live=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdecimal():continue
  try:
   f=(p/'stat').read_text().rsplit(')',1)[1].split()
   if int(f[2])==launch['pid'] and int(f[3])==launch['pid'] and int(f[19])>=int(launch['process_start_ticks']) and f[0] not in ['Z','X']:live.append(p.name)
  except (FileNotFoundError,ProcessLookupError,PermissionError):pass
 assert not live,('Owned original reference processes remain alive',live)
 params=json.loads((old/'params.json').read_bytes());assert not any(k.startswith('skip_') for k in params) and 'narrow_peak' not in params and 'fingerprint_bins' not in params
 source=Path('/var/tmp/omicsmatic-nfcore-sources-1/chipseq-1.2.1');main=(source/'main.nf').read_text();config=(source/'nextflow.config').read_text()
 assert re.search(r"PEAK_TYPE\s*=\s*params\.narrow_peak\s*\?\s*['\"]narrowPeak['\"]\s*:\s*['\"]broadPeak['\"]",main)
 assert 'publishDir "${params.outdir}/multiqc/${PEAK_TYPE}"' in main and "path '*multiqc_report.html'" in main
 assert re.search(r'\bnarrow_peak\s*=\s*false\b',config) and re.search(r'\bfingerprint_bins\s*=\s*500000\b',config)
 home=Path(launch['home']);report=home/'results/multiqc/broadPeak/multiqc_report.html';assert report.is_file() and report.stat().st_size>1000
 rows=list(csv.DictReader((old/'trace.tsv').open(),delimiter='\t'));assert len(rows)==97 and all(r['status']=='COMPLETED' and r['exit']=='0' for r in rows)
 preseq=[r for r in rows if r['name'].startswith('PRESEQ (')];assert len(preseq)==6
 outputs={}
 for p in sorted((home/'results').rglob('*')):
  n=p.relative_to(home/'results').as_posix()
  if p.is_symlink():outputs[n]=dict(kind='symlink',target=os.readlink(p))
  elif p.is_file():outputs[n]=dict(kind='file',**pin(p))
  elif p.is_dir():outputs[n]=dict(kind='directory')
  else:raise AssertionError(('Unexpected special original output',n))
 save(out/'outputs-inventory.json',outputs)
 assert pin(old/'COMPLETED.json')==historical
 (out/'helper-at-attempt.py').write_bytes(Path(__file__).read_bytes())
 state.update(status='PASS_ORIGINAL_CHIPSEQ121_ADDITIONAL_PCR_CONTROL_EXECUTION_AUDIT_ONLY',task_rows=97,preseq_tasks_completed=6,
  original_output_files=sum(v['kind']=='file' for v in outputs.values()),outputs_inventory=pin(out/'outputs-inventory.json'),
  report=dict(path=str(report),**pin(report)),source_report_contract=dict(main=pin(source/'main.nf'),config=pin(source/'nextflow.config'),
   original_publish_dir='${params.outdir}/multiqc/${PEAK_TYPE}',PEAK_TYPE='broadPeak',default_narrow_peak=False,default_fingerprint_bins=500000),
  historical_path_check_failure_preserved=historical,original_source_inputs_image_unchanged=True,owned_processes_alive=[],
  further_native_scientific_audit_required=True,home=str(home),full_nfcore_adapter=False)
except Exception as error:state.update(cause=repr(error),traceback=traceback.format_exc())
state['required_action']=action;save(out/'COMPLETED.json',state);(out/'WARNINGS.md').write_text('# '+state['status']+'\n\n'+state.get('cause','Original full reference execution only; no scientific result or tool credit admitted.')+'\n\nRequired action: '+action+'\n')
print(state['status'],state.get('cause',''),flush=True);raise SystemExit(0 if state['status'].startswith('PASS_') else 2)
