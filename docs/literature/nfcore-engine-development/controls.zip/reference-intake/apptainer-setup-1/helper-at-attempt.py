"""Prepare a private, source-reviewed Apptainer bootstrap; no bioinformatics result admission."""
import hashlib,json,os,shutil,stat,subprocess,sys,traceback,urllib.request
from pathlib import Path
if sys.platform!='linux':
    command=['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/python3','/mnt/d/projects/JLinAlg/build/literature-review/nfcore-runtime/prepare_apptainer_runtime.py']
    raise SystemExit(subprocess.call(command))
ROOT=Path('/mnt/d/projects/JLinAlg');BASE=ROOT/'build/literature-review/nfcore-runtime';out=BASE/'apptainer-setup-1'
assert not out.exists();out.mkdir()
home=Path('/var/tmp/omicsmatic-nfcore-apptainer-1');bootstrap=Path('/var/tmp/omicsmatic-nfcore-apptainer-bootstrap-1')
assert not home.exists() and not bootstrap.exists() and home.parent==bootstrap.parent==Path('/var/tmp')
def save(path,value):path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n',encoding='utf8',newline='\n')
def pin(path):
    h=hashlib.sha256();size=0
    with path.open('rb') as f:
        for data in iter(lambda:f.read(1048576),b''):size+=len(data);h.update(data)
    return dict(bytes=size,sha256=h.hexdigest())
def run(label,args,env=None,timeout=1800):
    save(out/(label+'.command.json'),dict(command=args))
    with (out/(label+'.stdout')).open('xb') as so,(out/(label+'.stderr')).open('xb') as se:
        result=subprocess.run(args,stdin=subprocess.DEVNULL,stdout=so,stderr=se,env=env,cwd=out,timeout=timeout)
    save(out/(label+'.process.json'),dict(exit_code=result.returncode));return result.returncode
state=dict(status='SKIP3_PRIVATE_APPTAINER_PREREQUISITES_UNAVAILABLE',scientific_analysis_executed=False,new_catalog_credit=False)
try:
    for label,command in [('user-namespace',['/usr/bin/unshare','--user','--map-root-user','/usr/bin/true']),('mount-namespace',['/usr/bin/unshare','--mount','/usr/bin/true'])]:
        if run(label,command,timeout=30):raise RuntimeError('Required permitted namespace is unavailable; leave container analyses skipped, without changing host protections')
    lock=json.loads((ROOT/'src/main/resources/org/jlinalg/omics/scdrs/scdrs-workflow-lock.json').read_bytes())['bootstrap']
    mamba=ROOT/'build/literature-review/scdrs-runtime/workflow-profile-installed-1/micromamba';assert pin(mamba)=={k:lock[k] for k in ['bytes','sha256']}
    before=pin(mamba);env=dict(os.environ,HOME=str(out/'child-home'),MAMBA_ROOT_PREFIX=str(out/'mamba-root'),MAMBA_NO_BANNER='1',LC_ALL='C.UTF-8')
    (out/'child-home').mkdir()
    command=[str(mamba),'--no-rc','create','-y','-p',str(bootstrap),'--override-channels','-c','conda-forge','rpm-tools=6.1.0','cpio=2.15','curl']
    if run('bootstrap-create',command,env):raise RuntimeError('Permitted private installer-dependency preparation failed; inspect retained logs')
    if run('bootstrap-explicit',[str(mamba),'--no-rc','list','-p',str(bootstrap),'--explicit'],env):raise RuntimeError('Cannot freeze bootstrap identities')
    records=[]
    for p in sorted((bootstrap/'conda-meta').glob('*.json')):
        d=json.loads(p.read_bytes());records.append({k:d.get(k) for k in ['name','version','build','url','sha256','md5','fn']})
    save(out/'bootstrap-package-lock.json',records)
    for name in ['curl','rpm2cpio','cpio']:assert (bootstrap/'bin'/name).is_file()
    intake=BASE/'apptainer-intake-1';source=intake/'install-unprivileged.sh';wanted=json.loads((intake/'installer-pin.json').read_bytes());assert pin(source)=={k:wanted[k] for k in ['bytes','sha256']}
    release=json.loads((intake/'latest-release.json').read_bytes());assert release['tag_name']=='v1.5.5'
    asset=next(a for a in release['assets'] if a['name']=='apptainer-1.5.5-1.x86_64.rpm')
    archives=out/'archives';archives.mkdir();rpm=archives/asset['name']
    request=urllib.request.Request(asset['browser_download_url'],headers={'User-Agent':'OmicsMatic-private-runtime-setup'})
    with urllib.request.urlopen(request,timeout=120) as response,rpm.open('xb') as target:shutil.copyfileobj(response,target)
    assert pin(rpm)==dict(bytes=asset['size'],sha256=asset['digest'].removeprefix('sha256:'))
    downloads=out/'captured-downloads';downloads.mkdir();wrappers=out/'recording-bin';wrappers.mkdir()
    recorder='''#!/usr/bin/python3
import hashlib,json,os,subprocess,sys
from pathlib import Path
base=Path(BASE);url=sys.argv[-1];assert url.startswith('https://')
result=subprocess.run([REAL,*sys.argv[1:]],stdout=subprocess.PIPE)
raw=result.stdout;digest=hashlib.sha256(raw).hexdigest();key=hashlib.sha256(url.encode()).hexdigest()+'-'+digest
file=base/(key+'.bin')
if file.exists():assert file.read_bytes()==raw
else:file.write_bytes(raw)
(base/(key+'.json')).write_text(json.dumps(dict(url=url,command=sys.argv[1:],exit_code=result.returncode,bytes=len(raw),sha256=digest),indent=2)+'\\n')
sys.stdout.buffer.write(raw);raise SystemExit(result.returncode)
'''.replace('BASE',repr(str(downloads))).replace('REAL',repr(str(bootstrap/'bin/curl')))
    (wrappers/'curl').write_text(recorder,encoding='utf8',newline='\n');(wrappers/'curl').chmod(0o755)
    env.update(PATH=str(wrappers)+':'+str(bootstrap/'bin')+':/usr/bin:/bin')
    if run('official-private-install',['/usr/bin/bash',str(source),'-e','-d','el8','-v',str(rpm),str(home)],env):raise RuntimeError('Original relocatable installation failed; no dependent analysis admission')
    if run('apptainer-version',[str(home/'bin/apptainer'),'version'],env,30):raise RuntimeError('Installed private runtime health failed')
    assert (out/'apptainer-version.stdout').read_text().strip()=='1.5.5'
    inventory={}
    for path in sorted(home.rglob('*')):
        if path.is_symlink():
            assert path.resolve().is_relative_to(home);inventory[path.relative_to(home).as_posix()]=dict(kind='symlink',target=os.readlink(path))
        elif path.is_file():
            mode=stat.S_IMODE(path.stat().st_mode);assert not mode&0o6000,('Unexpected setuid/setgid helper',path)
            inventory[path.relative_to(home).as_posix()]=dict(kind='file',mode=mode,**pin(path))
    save(out/'private-runtime-inventory.json',inventory);assert pin(mamba)==before
    state.update(status='PASS_PRIVATE_APPTAINER155_INSTALL_ONLY',home=str(home),bootstrap=str(bootstrap),installer=pin(source),
        original_apptainer_rpm=pin(rpm),runtime_entries=len(inventory),bootstrap_packages=len(records),
        source_relocation_performed_by_original_installer=True,shared_environments_modified=False,host_security_configuration_changed=False,
        captured_download_records=len(list(downloads.glob('*.json'))),hashes_are_authenticity=False)
except Exception as error:
    state['cause']=repr(error);(out/'error.traceback').write_text(traceback.format_exc())
state['required_action']='Read WARNINGS.md and retained setup/process logs. SKIP dependent container analyses until the exact permitted private runtime and original pipeline images are admitted. If installation is forbidden or unavailable, leave analysis skipped. Resolve named integrity/input/capacity failures before retrying NEW paths. Installation/namespace health is not bioinformatics, whole-paper or catalog admission. Do not change host security protections or silently replace source versions.'
save(out/'COMPLETED.json',state);(out/'WARNINGS.md').write_text('# '+state['status']+'\n\n'+state.get('cause','Private setup only; no scientific result.')+'\n\nREQUIRED ACTION: '+state['required_action']+'\n')
print(state['status'],state.get('cause',''),flush=True);raise SystemExit(0 if state['status'].startswith('PASS_') else 3)
