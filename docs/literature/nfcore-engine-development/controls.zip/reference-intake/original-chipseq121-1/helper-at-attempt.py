"""Run the complete original ChIP-seq1.2.1 upstream fixture with its original image and scientific defaults."""
import csv,hashlib,json,os,signal,subprocess,sys,time,traceback
from pathlib import Path
if sys.platform!='linux':raise SystemExit(subprocess.call(['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/python3','/mnt/d/projects/JLinAlg/build/literature-review/nfcore-runtime/run_original_chipseq121.py']))
root=Path('/mnt/d/projects/JLinAlg');base=root/'build/literature-review/nfcore-runtime';out=base/'original-chipseq121-1';assert not out.exists();out.mkdir()
home=Path('/var/tmp/omicsmatic-nfcore-original-chipseq121-1');assert not home.exists();home.mkdir();(home/'bin').mkdir()
source=Path('/var/tmp/omicsmatic-nfcore-sources-1/chipseq-1.2.1');data=Path('/var/tmp/omicsmatic-nfcore-chipseq121-controls-1')
engine=root/'build/literature-review/nextflow-runtime/managed-setup-development-1/home-21-v2';apptainer=Path('/var/tmp/omicsmatic-nfcore-apptainer-1/bin/singularity');image=Path('/var/tmp/omicsmatic-nfcore-images-1/nfcore-chipseq-1.2.1.sif')
def pin(path):
    h=hashlib.sha256();size=0
    with path.open('rb') as stream:
        for b in iter(lambda:stream.read(1048576),b''):size+=len(b);h.update(b)
    return dict(bytes=size,sha256=h.hexdigest())
def save(path,data):path.write_text(json.dumps(data,indent=2)+'\n',encoding='utf8',newline='\n')
before={str(p):pin(p) for p in [*source.rglob('*'),*data.rglob('*') ,image] if p.is_file()}
save(out/'immutable-inputs-before.json',before)
(out/'helper-at-attempt.py').write_bytes(Path(__file__).read_bytes())
wrapper=home/'bin/singularity';wrapper.write_text('#!/usr/bin/bash\nexec '+repr(str(apptainer))+' "$@"\n');wrapper.chmod(0o755)
params=dict(input=str(data/'local-design.csv'),fasta=str(data/'reference/genome.fa'),gtf=str(data/'reference/genes.gtf'),macs_gsize=1.2e7,
    custom_config_base=str(data/'external-configs'),outdir=str(home/'results'),max_cpus=4,max_memory='8.GB',max_time='2.h')
save(out/'params.json',params)
config="includeConfig '"+str(source/'nextflow.config')+"'\nprocess.container = '"+str(image)+"'\nexecutor.cpus = 4\nexecutor.memory = '24.GB'\nsingularity.cacheDir = '"+str(home/'container-cache')+"'\nsingularity.autoMounts = true\n"
(out/'original-runtime-binding.config').write_text(config)
env=dict(PATH=str(home/'bin')+':/usr/bin:/bin',HOME=str(home/'child-home'),LANG='C.UTF-8',LC_ALL='C.UTF-8',TZ='UTC',
    NXF_HOME=str(home/'.nextflow'),CAPSULE_CACHE_DIR=str(engine/'capsule'),NXF_JAVA_HOME=str(engine/'java'),NXF_OFFLINE='true',NXF_DISABLE_CHECK_LATEST='true',NXF_ANSI_LOG='false',NXF_PLUGINS_DEFAULT='false',NXF_ENABLE_SECRETS='false',
    NXF_OPTS='-Xms32m -Xmx2048m -XX:ReservedCodeCacheSize=128m -XX:ActiveProcessorCount=4',
    APPTAINER_CACHEDIR=str(home/'container-cache'),APPTAINER_TMPDIR=str(home/'container-tmp'),APPTAINER_MKSQUASHFS_PROCS='2')
for p in ['child-home','container-tmp']: (home/p).mkdir()
command=['/usr/bin/bash',str(engine/'nextflow'),'-C',str(out/'original-runtime-binding.config'),'-log',str(out/'nextflow.log'),'run',str(source/'main.nf'),'-params-file',str(out/'params.json'),'-profile','singularity','-with-trace',str(out/'trace.tsv'),'-work-dir',str(home/'work'),'-ansi-log','false']
save(out/'invocation.json',dict(command=command,environment=env,working_directory=str(home),
    original_source_modified=False,original_image=pin(image),scientific_defaults_preserved=True,fingerprint_bins=500000,
    upstream_test_profile_not_selected=True,all_six_upstream_samples_and_twelve_fastq_files_used=True,author_configuration_inferred=False))
state=dict(status='FAIL2_ORIGINAL_CHIPSEQ121_REFERENCE_ATTEMPT',scientific_result_admitted=False,new_catalog_credit=False)
action='Preserve all original logs,trace,work and outputs. Require complete original task/output and scientific contracts before any admission. SKIP dependent analysis if permitted prerequisites are unavailable or installation is forbidden. Resolve the named cause and retry NEW paths; do not disable branches,reduce scientific defaults,repair IDs/NA or silently replace versions to hide failure. This fixture is not paper data or biological validation.'
(out/'WARNINGS.md').write_text('# RUNNING original ChIP-seq reference; no result admitted\n\nREQUIRED ACTION: '+action+'\n')
process=None;started=time.monotonic()
try:
    with (out/'original.stdout').open('xb') as so,(out/'original.stderr').open('xb') as se:
        process=subprocess.Popen(command,cwd=home,env=env,stdin=subprocess.DEVNULL,stdout=so,stderr=se,start_new_session=True)
        save(out/'RUNNING.json',dict(pid=process.pid,process_start_ticks=Path('/proc/'+str(process.pid)+'/stat').read_text().split()[21],home=str(home),command=command))
        code=process.wait(timeout=21600)
    save(out/'original-process.json',dict(exit_code=code,pid=process.pid,elapsed_seconds=time.monotonic()-started))
    assert all(pin(Path(p))==v for p,v in before.items()),'Immutable original source/input/image bytes changed'
    if code:raise RuntimeError('Original pipeline exited '+str(code)+'; inspect complete logs and trace')
    rows=list(csv.DictReader((out/'trace.tsv').open(),delimiter='\t'));assert rows
    assert all(r.get('status') in ['COMPLETED','CACHED'] and r.get('exit') in ['0','-',''] for r in rows),('Unresolved original task failures',[(r.get('name'),r.get('status'),r.get('exit')) for r in rows if r.get('status') not in ['COMPLETED','CACHED']])
    assert (home/'results/MultiQC/multiqc_report.html').is_file() or (home/'results/multiqc/multiqc_report.html').is_file(),'Complete original report missing'
    state.update(status='PASS_ORIGINAL_CHIPSEQ121_COMPLETE_UPSTREAM_REFERENCE_ONLY',home=str(home),task_rows=len(rows),original_output_files=sum(p.is_file() for p in (home/'results').rglob('*')),
        further_native_scientific_audit_required=True,elapsed_seconds=time.monotonic()-started)
except Exception as error:state.update(cause=repr(error),traceback=traceback.format_exc(),home=str(home))
finally:
    if process is not None and process.poll() is None:
        os.killpg(process.pid,signal.SIGTERM)
        try:process.wait(timeout=30)
        except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=30)
state['required_action']=action;save(out/'COMPLETED.json',state);(out/'WARNINGS.md').write_text('# '+state['status']+'\n\n'+state.get('cause','Original reference execution only; complete native/role/catalog admission remains pending.')+'\n\nREQUIRED ACTION: '+action+'\n')
print(state['status'],state.get('cause',''),flush=True);raise SystemExit(0 if state['status'].startswith('PASS_') else 2)
