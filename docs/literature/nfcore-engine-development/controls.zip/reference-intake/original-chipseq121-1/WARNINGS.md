# FAIL2_ORIGINAL_CHIPSEQ121_REFERENCE_ATTEMPT

RuntimeError('Original pipeline exited 1; inspect complete logs and trace')

REQUIRED ACTION: Preserve all original logs,trace,work and outputs. Require complete original task/output and scientific contracts before any admission. SKIP dependent analysis if permitted prerequisites are unavailable or installation is forbidden. Resolve the named cause and retry NEW paths; do not disable branches,reduce scientific defaults,repair IDs/NA or silently replace versions to hide failure. This fixture is not paper data or biological validation.
