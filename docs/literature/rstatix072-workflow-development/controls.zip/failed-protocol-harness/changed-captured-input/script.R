writeLines('changed',file.path(input_directory,'literal.txt'));writeLines('complete',file.path(result_directory,'result.txt'));analysis_complete <- 'COMPLETE'
