writeChar('x',file.path(result_directory,'result.txt'),eos=NULL);analysis_complete <- 'COMPLETE'
