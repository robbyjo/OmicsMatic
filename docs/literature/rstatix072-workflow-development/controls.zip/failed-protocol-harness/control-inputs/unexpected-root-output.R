writeLines('extra','undeclared-result.txt');writeLines('complete',file.path(result_directory,'result.txt'));analysis_complete <- 'COMPLETE'
