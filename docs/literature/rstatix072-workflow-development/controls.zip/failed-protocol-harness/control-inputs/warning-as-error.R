options(warn=2);warning('must remain an original error');writeLines('UNREACHED',file.path(result_directory,'result.txt'));analysis_complete <- 'COMPLETE'
