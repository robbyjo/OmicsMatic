writeLines('partial exact α',file.path(result_directory,'result.txt'));quit(save='no',status=0,runLast=FALSE)
