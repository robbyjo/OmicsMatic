writeLines('extra',file.path(input_directory,'extra.txt'));writeLines('complete',file.path(result_directory,'result.txt'));analysis_complete <- 'COMPLETE'
