message('literal original message α'); warning('original warning line1\noriginal warning line2'); writeLines('complete',file.path(result_directory,'result.txt')); analysis_complete <- 'COMPLETE'
