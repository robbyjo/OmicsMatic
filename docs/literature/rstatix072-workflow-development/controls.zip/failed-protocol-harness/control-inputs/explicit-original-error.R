writeLines('partial exact α',file.path(result_directory,'result.txt'));stop('original explicit failure α')
