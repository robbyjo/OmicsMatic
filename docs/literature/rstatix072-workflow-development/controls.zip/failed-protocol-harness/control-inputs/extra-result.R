writeLines('complete',file.path(result_directory,'result.txt'));writeLines('extra',file.path(result_directory,'extra.txt'));analysis_complete <- 'COMPLETE'
