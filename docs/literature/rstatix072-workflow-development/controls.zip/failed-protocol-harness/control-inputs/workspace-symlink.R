file.symlink(file.path(input_directory,'literal.txt'),file.path(result_directory,'result.txt'));analysis_complete <- 'COMPLETE'
