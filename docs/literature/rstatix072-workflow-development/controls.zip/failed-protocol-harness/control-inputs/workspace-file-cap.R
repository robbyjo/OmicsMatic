for(i in 1:120)writeLines('x',file.path(result_directory,paste0(i,'.txt')));Sys.sleep(3);analysis_complete <- 'COMPLETE'
