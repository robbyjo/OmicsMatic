writeLines('complete',file.path(result_directory,'result.txt'))
