writeLines('before error',file.path(result_directory,'result.txt'));rstatix::shapiro_test(rep(1,6));analysis_complete <- 'COMPLETE'
