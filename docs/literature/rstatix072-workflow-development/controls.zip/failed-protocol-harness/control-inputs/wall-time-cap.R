Sys.sleep(30);writeLines('complete',file.path(result_directory,'result.txt'));analysis_complete <- 'COMPLETE'
