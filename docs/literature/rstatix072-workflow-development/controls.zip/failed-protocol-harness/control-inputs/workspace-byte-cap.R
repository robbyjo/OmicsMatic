writeBin(raw(40*1024*1024),file.path(result_directory,'result.txt'));Sys.sleep(3);analysis_complete <- 'COMPLETE'
