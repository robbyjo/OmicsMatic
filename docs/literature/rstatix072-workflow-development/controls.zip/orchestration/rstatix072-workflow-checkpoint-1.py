from pathlib import Path
import hashlib,json,os,shutil,subprocess,zipfile
ROOT=Path('/mnt/d/projects/JLinAlg');BASE=ROOT/'build/literature-review/monocle-runtime';OUT=BASE/'rstatix072-workflow-checkpoint-1';OUT.mkdir(exist_ok=False)
def pin(p):
 h=hashlib.sha256();size=0
 with p.open('rb') as f:
  for raw in iter(lambda:f.read(1048576),b''):h.update(raw);size+=len(raw)
 return dict(bytes=size,sha256=h.hexdigest())
def save(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf8',newline='\n')
baseline=json.loads((BASE/'rstatix072-workflow-preflight-1/PROTECTED_BASELINE.json').read_bytes())
for row in baseline['protected']+[baseline['canonical']]:assert pin(ROOT/row['path'])=={k:row[k] for k in ['bytes','sha256']},row['path']
linux=json.loads((BASE/'rstatix072-workflow-protocols-linux-2/COMPLETED.json').read_bytes());windows=json.loads((BASE/'rstatix072-workflow-protocols-windows-1/COMPLETED.json').read_bytes());assert linux['controls']==31 and windows['controls']==1
comparison=json.loads((BASE/'rstatix072-workflow-initial-2/COMPLETE_COMPARISON.json').read_bytes());assert (comparison['complete_calls'],comparison['complete_returned_rows'],comparison['complete_returned_cells'])==(248,444,5664)
assert json.loads((BASE/'rstatix072-workflow-qualified-bridge-1/COMPLETED.json').read_bytes())['scientific_sources_overridden']==False
DATA=ROOT/'docs/literature/rstatix072-workflow-development';DATA.mkdir(exist_ok=False);(DATA/'.gitattributes').write_text('* -text whitespace=cr-at-eol\n',encoding='ascii',newline='\n')
shutil.copyfile(BASE/'rstatix072-workflow-qualified-bridge-1/catalog-before.zip',DATA/'catalog-before.zip')
sources=[p for p in sorted((ROOT/'tools/literature/rstatix072_workflow').iterdir()) if p.is_file()]
sources += [ROOT/'docs/literature/RSTATIX072_WORKFLOW_DEVELOPMENT.md',ROOT/'LICENSE']
source_pins={p.relative_to(ROOT).as_posix():pin(p) for p in sources};members={};links={}
def add(p,n):
 assert p.is_file() and not p.is_symlink() and n not in members,n;assert '\\' not in n,n;members[n]=p
def tree(p,prefix):
 assert p.is_dir(),p
 for f in sorted(p.rglob('*')):
  name=prefix+'/'+f.relative_to(p).as_posix()
  if f.is_symlink():links[name]=dict(kind='symlink',target=os.readlink(f));continue
  if f.is_file():add(f,name)
for p in sources:add(p,'current-source/'+p.relative_to(ROOT).as_posix())
tree(BASE/'rstatix072-workflow-direct-reference-1','original/direct-reference')
tree(BASE/'rstatix072-workflow-complete-2','public/complete')
tree(BASE/'rstatix072-workflow-public-example-1','public/example')
tree(BASE/'rstatix072-workflow-protocols-linux-2','protocols/linux')
tree(BASE/'rstatix072-workflow-protocols-windows-1','protocols/windows')
tree(BASE/'rstatix072-workflow-protocols-linux-1','failed-protocol-harness')
fixtures=BASE/'rstatix072-workflow-fixtures-1'
for n in ['cases.rds','fixture-manifest.json','request.json','request-2.json']:add(fixtures/n,'fixtures/'+n)
bad_request=json.loads((fixtures/'request.json').read_bytes());bad_output=(fixtures/bad_request['out']).resolve();assert bad_output.is_relative_to(fixtures.resolve()) and bad_output.is_dir()
tree(bad_output,'failed-posix-harness/owned-output')
save(OUT/'FAILED_POSIX_OUTPUT_LOCATION.json',dict(original_owned_output=str(bad_output),stored_alias='failed-posix-harness/owned-output',reason='The first Windows-side harness serialized Linux paths with literal backslashes. All unadmitted output bytes are retained under a portable archive alias; literal original paths remain in the request/location record.',original_analysis_launched=(bad_output/'process-live.json').exists()))
add(OUT/'FAILED_POSIX_OUTPUT_LOCATION.json','failed-posix-harness/FAILED_POSIX_OUTPUT_LOCATION.json')
tree(BASE/'rstatix072-workflow-initial-1','failed-posix-harness/driver')
add(BASE/'rstatix072-workflow-initial-2/COMPLETE_COMPARISON.json','validation/COMPLETE_COMPARISON.json')
tree(BASE/'rstatix072-workflow-initial-2','validation/driver')
tree(BASE/'rstatix072-workflow-metadata-boundaries-1','validation/metadata-boundaries')
add(BASE/'rstatix072-workflow-qualified-bridge-1/COMPLETED.json','validation/UNCHANGED_NATIVE_PROVIDER_GATE.json')
for name in ['rstatix072-workflow-initial-1.py','rstatix072-workflow-initial-2.py','rstatix072-workflow-checkpoint-1.py']:add(BASE/name,'orchestration/'+name)
save(OUT/'RETAINED_LINK_IDENTITIES.json',dict(status='RETAINED_FORBIDDEN_LINK_IDENTITIES_WITHOUT_DEREFERENCING',links=links,symlink_targets_not_read=True));add(OUT/'RETAINED_LINK_IDENTITIES.json','diagnostics/RETAINED_LINK_IDENTITIES.json')
with zipfile.ZipFile(DATA/'controls.zip','x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,p in sorted(members.items()):
  info=zipfile.ZipInfo(n,(2026,11,13,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,p.read_bytes())
layout=dict(status='COMPLETE_RETAINED_ORIGINAL_RSTATIX_SCRIPT_RESULTS_OBJECTS_CONDITIONS_PROTOCOLS_AND_FAILED_ATTEMPTS',files={n:pin(p) for n,p in sorted(members.items())},retained_link_identities=links,
 scientific_regular_inputs_outputs_or_diagnostics_omitted=False,private_dependency_runtime_redistributed=False,
 original_native_provider_checkpoint='docs/literature/rstatix072-development-checkpoint',private_provider_runtime_note='The already-qualified installed R/dependency runtime stays private. Its complete locked profile, original source and native/provider controls remain in the earlier checkpoint; both runtime instances and their fingerprints are retained in original-provider.json per run.')
save(DATA/'CONTROLS_LAYOUT.json',layout)
native='docs/literature/rstatix072-development-checkpoint'
records={native+'/'+n:pin(ROOT/native/n) for n in ['VALIDATION.json','CONTROLS_LAYOUT.json','SHA256SUMS','ARTIFACTS.json','CENSUS.json','VERIFIER_BOUNDARIES.json','verifier-boundary-controls.zip']}
artifacts={p.relative_to(ROOT).as_posix():dict(kind='source-entrypoint-or-original-R-worker',**pin(p)) for p in [ROOT/'tools/literature/rstatix072_workflow/run.py',ROOT/'tools/literature/rstatix072_workflow/OriginalWorker.R',ROOT/'tools/literature/rstatix072_workflow/make_example.py']};save(DATA/'ARTIFACTS.json',artifacts)
shutil.copyfile(ROOT/native/'CENSUS.json',DATA/'CENSUS.json');shutil.copyfile(ROOT/'tools/literature/rstatix072/paper-use-intake.json',DATA/'PAPER_USE.json')
proof=dict(status='PASS_ORIGINAL_RSTATIX072_COMPLETE_SCRIPT_WORKFLOW_DEVELOPMENT',sources=source_pins,qualified_component_records=records,archive=pin(DATA/'controls.zip'),controls_layout=pin(DATA/'CONTROLS_LAYOUT.json'),catalog_before=pin(DATA/'catalog-before.zip'),
 complete_archive_files=len(members),retained_link_identities=len(links),original_package_version='0.7.2',original_R_version='4.5.3',original_namespace_functions=339,original_exports=126,
 complete_original_calls=248,complete_result_files=250,complete_returned_rows=444,complete_returned_cells=5664,public_protocol_controls_linux=31,public_platform_refusals_windows=1,
 public_example_operations=7,original_warning_as_error_semantics_preserved=True,full_original_RDS_objects_attributes_arguments_conditions_RNG_compared=True,formula_execution_environment_pointers_compared=False,opaque_RDS_byte_parity_claimed=False,
 original_scientific_source_modified=False,existing_scientific_verifiers_modified=False,native_provider_checkpoint_changed=False,main_catalog_modified=False,
 canonical_unchanged=True,unfinished_files_preserved=23,failed_posix_path_request_retained=True,failed_existing_output_harness_retained=True,
 new_tool_credit=0,whole_tool_qualified=False,paper_reproduced=False,whole_goal_complete=False,previous_goal_turn_classification='progress')
save(DATA/'VALIDATION.json',proof)
(DATA/'SHA256SUMS').write_text(''.join(pin(DATA/n)['sha256']+'  '+n+'\n' for n in ['controls.zip','CONTROLS_LAYOUT.json','catalog-before.zip','ARTIFACTS.json','CENSUS.json','PAPER_USE.json','VALIDATION.json']),encoding='ascii',newline='\n')
for row in baseline['protected']+[baseline['canonical']]:assert pin(ROOT/row['path'])=={k:row[k] for k in ['bytes','sha256']},row['path']
save(OUT/'COMPLETED.json',dict(status=proof['status'],complete_archive_files=len(members),retained_links=len(links),archive=proof['archive'],sources=len(source_pins),main_catalog_unchanged=True,new_tool_credit=0));print(json.dumps(dict(status=proof['status'],complete_archive_files=len(members),retained_links=len(links),archive=proof['archive'],sources=len(source_pins))),flush=True)
