from pathlib import Path,PurePosixPath
import concurrent.futures,json,os,subprocess,sys,time
ROOT=Path('D:/projects/JLinAlg');BASE=ROOT/'build/literature-review/monocle-runtime';OUT=Path(__file__).with_suffix('');OUT.mkdir(exist_ok=False)
LROOT='/mnt/d/projects/JLinAlg';LBASE=LROOT+'/build/literature-review/monocle-runtime';wsl=['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','-u','root','--'];env=dict(os.environ);env['PYTHONDONTWRITEBYTECODE']='1'
def save(n,x):(OUT/n).write_text(json.dumps(x,indent=2)+'\n',encoding='utf8',newline='\n')
def run(label,command,expected=0):
 command=list(map(str,command));start=time.time()
 with (OUT/(label+'.stdout')).open('xb') as so,(OUT/(label+'.stderr')).open('xb') as se:
  p=subprocess.Popen(command,cwd=ROOT,env=env,stdin=subprocess.DEVNULL,stdout=so,stderr=se);save(label+'.live.json',dict(command=command,pid=p.pid,started_unix=start));code=p.wait(timeout=1200)
 row=dict(label=label,command=command,exit_code=code,expected_exit=expected,elapsed_seconds=time.time()-start);save(label+'.process.json',row);print(label,'exit',code,flush=True);return row
provider=LBASE+'/rstatix072-provider-2';fixtures=LBASE+'/rstatix072-workflow-fixtures-1';rscript=LBASE+'/rstatix072-runtime-install-1/.pixi/envs/default/bin/Rscript'
sys.path.insert(0,str(ROOT/'tools/literature/rstatix072_workflow'));from make_example import request
request_path=BASE/'rstatix072-workflow-fixtures-1/request-2.json'
value=request(PurePosixPath(provider),PurePosixPath(LROOT+'/tools/literature/rstatix072_workflow/OriginalControl.R'),{'cases.rds':PurePosixPath(fixtures+'/cases.rds')},{**{f'{i:04d}.tsv':1 for i in range(1,249)},'complete-index.tsv':1,'complete-original-results.rds':1},'ALL_248_ORIGINAL_RSTATIX072_CALLS_RETURNED',PurePosixPath(LBASE+'/rstatix072-workflow-complete-2'))
value['analysis_population']='All248 predeclared complete original rstatix function cases; every result row/column, attributes, arguments, warnings and RNG states are retained.'
request_path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf8',newline='\n')
commands=[('complete-public-workflow',wsl+['/usr/bin/python3',LROOT+'/tools/literature/rstatix072_workflow/run.py','--request',fixtures+'/request-2.json'])]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(lambda x:run(*x),commands))
save('PROCESSES.json',results);assert all(x['exit_code']==0 for x in results),results
comparison=run('full-original-comparison',wsl+[rscript,'--vanilla',LROOT+'/tools/literature/rstatix072_workflow/CompareOriginal.R',LBASE+'/rstatix072-workflow-direct-reference-1',LBASE+'/rstatix072-workflow-complete-2/results',LBASE+'/rstatix072-workflow-initial-2/COMPLETE_COMPARISON.json']);results.append(comparison);save('PROCESSES.json',results);assert comparison['exit_code']==0
save('COMPLETED.json',dict(status='PASS_COMPLETE_ORIGINAL_RSTATIX072_SCRIPT_WORKFLOW_AND_FULL_REFERENCE_OBJECTS',calls=results,comparison=json.loads((OUT/'COMPLETE_COMPARISON.json').read_bytes()),whole_goal_complete=False,new_tool_credit=0))
