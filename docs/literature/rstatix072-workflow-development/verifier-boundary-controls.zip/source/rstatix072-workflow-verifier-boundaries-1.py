from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time,zipfile
ROOT=Path('D:/projects/JLinAlg');BASE=ROOT/'build/literature-review/monocle-runtime';OUT=Path(__file__).with_suffix('');OUT.mkdir(exist_ok=False)
DATA='docs/literature/rstatix072-workflow-development';original=ROOT/DATA;proof=json.loads((original/'VALIDATION.json').read_bytes())
def rawpin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def pin(p):return rawpin(p.read_bytes())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8',newline='\n')
before={p.name:pin(p) for p in original.iterdir() if p.is_file()};calls=[]
env=dict(os.environ);env['PYTHONDONTWRITEBYTECODE']='1';env['PYTHONPATH']=str(ROOT/'tools/literature')
for case in ['changed-current-source','missing-evidence-archive','resealed-portable-table','resealed-missing-original-object']:
 scope=OUT/case;scope.mkdir();root=scope/'repo';root.mkdir();assert root.resolve().is_relative_to(BASE.resolve())
 for name in proof['sources']:
  target=root/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/name,target)
 data=root/DATA;data.mkdir(parents=True,exist_ok=True);shutil.copyfile(original/'VALIDATION.json',data/'VALIDATION.json')
 if case=='changed-current-source':
  target=root/'tools/literature/rstatix072_workflow/run.py';target.write_bytes(target.read_bytes()+b'\n# Deliberate isolated source refusal control.\n')
 else:
  for name in proof['qualified_component_records']:
   target=root/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/name,target)
  if case!='missing-evidence-archive':
   for p in original.iterdir():
    if p.is_file():shutil.copyfile(p,data/p.name)
   with zipfile.ZipFile(data/'controls.zip') as z:members={n:z.read(n) for n in z.namelist()}
   prefix='public/complete/';manifest=json.loads(members[prefix+'MANIFEST.json']);results=json.loads(members[prefix+'result-files.json']);layout=json.loads((data/'CONTROLS_LAYOUT.json').read_bytes())
   if case=='resealed-portable-table':
    name=prefix+'results/0001.tsv';members[name]+=b'DELIBERATE_FORGED_COMPLETE_TABLE_ROW\n';manifest['files']['results/0001.tsv']=rawpin(members[name]);results['0001.tsv']=rawpin(members[name]);layout['files'][name]=rawpin(members[name])
   else:
    name=prefix+'results/complete-original-results.rds';del members[name];del layout['files'][name];del manifest['files']['results/complete-original-results.rds'];del results['complete-original-results.rds']
   members[prefix+'result-files.json']=(json.dumps(results)+'\n').encode();manifest['files']['result-files.json']=rawpin(members[prefix+'result-files.json']);members[prefix+'MANIFEST.json']=(json.dumps(manifest)+'\n').encode()
   for n in [prefix+'result-files.json',prefix+'MANIFEST.json']:layout['files'][n]=rawpin(members[n])
   rebuilt=scope/'deliberately-resealed-controls.zip'
   with zipfile.ZipFile(rebuilt,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,raw in members.items():z.writestr(n,raw)
   shutil.copyfile(rebuilt,data/'controls.zip');save(data/'CONTROLS_LAYOUT.json',layout);v=json.loads((data/'VALIDATION.json').read_bytes());v['archive']=pin(data/'controls.zip');v['controls_layout']=pin(data/'CONTROLS_LAYOUT.json');save(data/'VALIDATION.json',v)
   (data/'SHA256SUMS').write_text(''.join(pin(data/n)['sha256']+'  '+n+'\n' for n in ['controls.zip','CONTROLS_LAYOUT.json','catalog-before.zip','ARTIFACTS.json','CENSUS.json','PAPER_USE.json','VALIDATION.json']),encoding='ascii',newline='\n')
   if case=='resealed-portable-table':(scope/'deliberately-forged-table.tsv').write_bytes(members[name])
 command=list(map(str,[sys.executable,root/'tools/literature/rstatix072_workflow/verify.py','--out',root/'build/literature-review/monocle-runtime/verify-control']));start=time.time();r=subprocess.run(command,env=env,stdin=subprocess.DEVNULL,capture_output=True,timeout=180);expected=3 if case=='missing-evidence-archive' else 2
 (scope/'process.stdout').write_bytes(r.stdout);(scope/'process.stderr').write_bytes(r.stderr);row=dict(case=case,command=command,exit_code=r.returncode,expected_exit=expected,elapsed_seconds=time.time()-start);calls.append(row);save(scope/'process.json',row);assert r.returncode==expected,row
 diagnostic=json.loads((root/'build/literature-review/monocle-runtime/verify-control/FAILURE.json').read_bytes())
 wanted={'changed-current-source':'Current qualified source/evidence differs','missing-evidence-archive':None,'resealed-portable-table':'Complete portable original result differs','resealed-missing-original-object':'Incomplete250-file original scientific result population'}[case]
 assert wanted is None or wanted in diagnostic['cause'],(case,diagnostic['cause']);print(case,'refused',flush=True)
assert all(pin(original/n)==wanted for n,wanted in before.items()),'Actual qualified checkpoint changed'
save(OUT/'COMPLETED.json',dict(status='PASS_FROZEN_ORIGINAL_RSTATIX_WORKFLOW_VERIFIER_SOURCE_ARCHIVE_AND_RESEALED_COMPLETE_RESULT_REFUSALS',controls=4,calls=calls,
 actual_qualified_data_unchanged=True,scientific_sources_or_verifier_definitions_overridden=False,metadata_helper_imports_from_live_project=True,original_analysis_executed=False))
