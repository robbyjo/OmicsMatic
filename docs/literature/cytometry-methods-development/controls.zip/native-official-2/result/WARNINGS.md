# Scope, warnings and required actions

Native Java complete single-dataset FCS stored channels, explicit amplifier-to-scale interpretation and Gating-ML 2.0 gates. No gate learning, proprietary FlowJo/FACSDiva workspace import, vendor equivalence, calibration, time-in-seconds conversion or paper-specific settings are inferred. Negative results are retained; undefined/nonfinite events refuse the complete requested population. The historical ISAC test archive contains unresolved reference contradictions; this profile does not claim full standard-suite compliance.

Require exit 0, COMPLETED.json and analysis.json result_admitted=true before use. SKIP3: dependent analysis skipped because a required format/capability or permitted file access is unavailable. Supply a supported complete FCS/Gating-ML export and permitted paths, then retry NEW output. FAIL2: no complete result admitted. Preserve original inputs and partial output; read FAILURE.txt and WARNINGS.md, correct the named definition, numerical domain, metadata, integrity or capacity problem and retry NEW output. Never drop events, repair identifiers, clip negatives, replace nonfinite values or alter original gates to force success. Windows launchers may lose Unicode arguments: use an ASCII request pathname with Unicode paths inside UTF-8 JSON.

- Explicit numeric policy permits outer ASCII spaces in recognized numeric metadata tokens. Original keyword values and parameter names remain unchanged; tabs, other whitespace and malformed values are not repaired.

- Stored channels only: no gain, antilog, time, compensation, calibration, display transform or gate is inferred. Floating negative/over-range/nonfinite values remain visible. This profile does not validate a CRC or claim complete FCS conformance.

- Channel-to-scale uses the declared PnE/PnR antilog or PnG division (unit gain when absent). It applies no compensation by itself, no calibration, no time-in-seconds conversion and no display/gating transform. Gating-ML must select further operations explicitly.
