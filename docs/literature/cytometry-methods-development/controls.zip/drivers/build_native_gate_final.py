import hashlib,json,os,shutil,subprocess,time,traceback,xml.etree.ElementTree as ET
from pathlib import Path
base=Path(__file__).resolve().parent;root=base.parents[1];out=base/'build-3';out.mkdir()
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return dict(bytes=p.stat().st_size,sha256=h.hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
try:
 sources=[p for d in ['src/main/java/org/jlinalg/cytometry','src/test/java/org/jlinalg/cytometry','src/main/resources/org/jlinalg/cytometry','src/test/resources/org/jlinalg/cytometry','tools/literature/cytometry'] for p in (root/d).rglob('*') if p.is_file() and p.suffix!='.pyc']+[root/'src/main/java/org/jlinalg/cli/CytometryGateCli.java',root/'src/main/java/org/jlinalg/cli/JLinAlgCli.java',root/'src/test/java/org/jlinalg/cli/CytometryGateCliTest.java',root/'LICENSES/stanford-cytometry-transforms.txt']
 guards={p.relative_to(root).as_posix():pin(p) for p in sources};save(out/'SOURCES.json',guards)
 for name in guards:
  copy=out/'sources'/name;copy.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/name,copy)
 rel=out.relative_to(root).as_posix();init=out/'private.gradle';init.write_text("gradle.projectsEvaluated {\n rootProject.tasks.named('executableJar') { destinationDirectory.set(rootProject.layout.projectDirectory.dir('"+rel+"/jar')) }\n rootProject.tasks.named('test') { reports.junitXml.outputLocation.set(rootProject.layout.projectDirectory.dir('"+rel+"/test-results')); reports.html.outputLocation.set(rootProject.layout.projectDirectory.dir('"+rel+"/test-report')) }\n}\n",encoding='utf8',newline='\n')
 command=[str(root/'gradlew.bat'),'--no-daemon','--console=plain','-I',str(init),':test','--tests','org.jlinalg.cytometry.*','--tests','org.jlinalg.cli.CytometryGateCliTest',':executableJar'];save(out/'command.json',command);began=time.monotonic();env=dict(os.environ,JAVA_HOME='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot')
 with (out/'stdout').open('xb') as so,(out/'stderr').open('xb') as se:r=subprocess.run(command,cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=900)
 save(out/'PROCESS.json',dict(exit_code=r.returncode,seconds=time.monotonic()-began));assert r.returncode==0
 trees=[ET.parse(p).getroot() for p in (out/'test-results').glob('TEST-*.xml')];counts={k:sum(int(t.attrib.get(k,0)) for t in trees) for k in ['tests','failures','errors','skipped']};assert counts==dict(tests=25,failures=0,errors=0,skipped=0),counts
 assert all(pin(root/n)==identity for n,identity in guards.items())
 save(out/'COMPLETED.json',dict(status='PASS_FOCUSED_WINDOWS_NATIVE_CYTOMETRY_GATE_BUILD',junit=counts,artifact=pin(out/'jar/omicsmatic-0.4.0.jar'),new_catalog_integrations=0,full_standard_suite_pass_claimed=False))
 print('PASS focused Windows tests and packaged command',counts,flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc()));print(repr(e),flush=True);raise
