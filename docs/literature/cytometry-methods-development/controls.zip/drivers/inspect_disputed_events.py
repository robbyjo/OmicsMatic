from pathlib import Path
import numpy as np
base=Path(__file__).resolve().parent;src=base/'standard/Gating-ML 2.0 Full 20130122/Compliance tests/set 2';actual=base/'official-controls-3/set-2'
path=base/'official-inputs-1/scaled-2.tsv'
with path.open() as f:
 names=f.readline().strip().split('\t');data=np.loadtxt(f,delimiter='\t')
xy=data[:,[names.index('FITC-A'),names.index('PE-A')]];scaled=np.arcsinh(xy*np.sinh(4.5*np.log(10))/262144)/(4.5*np.log(10))
a=np.loadtxt(actual/'Results_Poly1ua.txt',dtype=int);b=np.loadtxt(src/'Results_Poly1ua.txt',dtype=int);bad=np.flatnonzero(a!=b)
print('mismatches',len(bad),'both_negative',np.sum(np.all(scaled[bad]<0,axis=1)),'one_negative',np.sum(np.any(scaled[bad]<0,axis=1)),'uncompensated_input_min',np.min(xy,axis=0))
for i in bad[:20]:print(int(i),'raw',xy[i].tolist(),'asinh',scaled[i].tolist(),'native',int(a[i]),'expected',int(b[i]))
print('EXPECTED_SUMMARY_SET2')
for line in (src.parent/'Summary.csv').read_text().splitlines():
 if line.startswith('set 2'):print(line)
