package org.jlinalg.cli;
import java.io.BufferedWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.jlinalg.cytometry.CytometryCompensation;
import org.jlinalg.cytometry.GatingMl20;

public final class GatingProbe {
    private GatingProbe() { }
    @SuppressWarnings("unchecked") public static void main(String[] args) throws Exception {
        Path out=Path.of(args[3]); Files.createDirectory(out);
        Map<String,Object> metadata=(Map<String,Object>)SimpleJson.parse(Files.readString(Path.of(args[2]),StandardCharsets.UTF_8));
        Map<String,Object> keywords=(Map<String,Object>)metadata.get("compensation_keywords");
        GatingMl20.FcsCompensation fcs=GatingMl20.FcsCompensation.absent();
        if (!keywords.isEmpty()) {
            if (keywords.size()!=1 || !keywords.containsKey("spill")) throw new IllegalArgumentException("Unexpected original compensation description");
            String[] values=keywords.get("spill").toString().split(",",-1); int n=Integer.parseInt(values[0]);
            List<String> names=List.of(Arrays.copyOfRange(values,1,n+1)); double[][] matrix=new double[n][n];
            if (values.length!=1+n+n*n) throw new IllegalArgumentException("Incomplete original matrix");
            for(int i=0;i<n;i++) for(int j=0;j<n;j++) matrix[i][j]=Double.parseDouble(values[1+n+i*n+j]);
            fcs=GatingMl20.FcsCompensation.available(CytometryCompensation.spectrum(names,names,matrix,1e-12));
        }
        try(var input=Files.newBufferedReader(Path.of(args[1]),StandardCharsets.UTF_8)) {
            List<String> names=List.of(input.readLine().split("\t",-1));
            GatingMl20 program=GatingMl20.read(Path.of(args[0]),names,fcs,1e-12,GatingMl20.Limits.defaults());
            var evaluator=program.evaluator();var writers=new ArrayList<BufferedWriter>();boolean[] inside=new boolean[program.gates().size()];long[] counts=new long[inside.length];long events=0;
            try {
                for(var gate:program.gates()) writers.add(Files.newBufferedWriter(out.resolve("Results_"+gate.id()+".txt"),StandardCharsets.UTF_8));
                for(String line;(line=input.readLine())!=null;) {
                    String[] cells=line.split("\t",-1);if(cells.length!=names.size()) throw new IllegalArgumentException("Incomplete original prepared event");
                    double[] row=Arrays.stream(cells).mapToDouble(Double::parseDouble).toArray();evaluator.evaluate(row,inside);
                    for(int i=0;i<inside.length;i++) { writers.get(i).write(inside[i]?"1\n":"0\n");if(inside[i])counts[i]++; }
                    events++;
                }
            } finally {for(var writer:writers)writer.close();}
            var results=new LinkedHashMap<String,Object>();for(int i=0;i<inside.length;i++)results.put(program.gates().get(i).id(),counts[i]);
            Files.writeString(out.resolve("COMPLETED.json"),NextflowJson.json(Map.of("status","COMPLETE_PREPARED_SCALE_GATING_COMPONENT_ONLY","events",events,"counts",results,"warnings",program.warnings()))+"\n",StandardCharsets.UTF_8);
            System.out.println("PASS original prepared events="+events+" gates="+inside.length);
        }
    }
}
