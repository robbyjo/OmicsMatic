from pathlib import Path
b=Path(__file__).resolve().parent;text=(b/'close_evidence.py').read_text();text=text.replace("out=base/'public-controls-1'","out=base/'public-controls-2'")
old="body=derived[derived.index('package org.jlinalg.cytometry.internal.stanford;'):];assert body==text,name";assert text.count(old)==1;text=text.replace(old,"body=derived.split(' */\\n',1)[1];assert body==text,name")
text=text.replace("'EVIDENCE_CLOSURE_FAILURE.json'","'EVIDENCE_CLOSURE_FAILURE_V2.json'")
old="save(out/'STANFORD_DERIVATION.json',derivation)";assert text.count(old)==1;text=text.replace(old,old+"\n copy(base/'EVIDENCE_CLOSURE_FAILURE.json','retained-closure-harness-failure/FAILURE.json')\n save(out/'retained-closure-harness-failure/EXPLANATION.json',dict(cause='First verifier removed an original leading Javadoc block while locating the package declaration, causing a false mismatch for Transform.java. Corrected verifier removes only the added BSD header and compares every remaining character. No algorithm or original source changed.'))")
p=b/'close_evidence_v2.py';assert not p.exists();p.write_text(text,newline='\n')
