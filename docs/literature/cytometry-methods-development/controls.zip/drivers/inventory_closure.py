from pathlib import Path
import json
b=Path(__file__).resolve().parent
for d in [b/'flowutils-source-1',b/'flowutils-reference-1',b.parent/'cytometry-high-impact-1/upstream-3',b/'original-java']:
 print(str(d));print([(p.name,p.stat().st_size) for p in d.iterdir() if p.is_file()])
v=json.loads((b/'validation-2/COMPLETED.json').read_bytes());print('final',v['artifact'],v['windows_junit'],v['changed_predecessor_entries'])
print('audit',json.loads((b/'source-discrepancy-audit-3/AUDIT.json').read_bytes())['status'])
