from pathlib import Path
import difflib,json,zipfile
b=Path(__file__).resolve().parent;r=b.parents[1];v=json.loads((b/'VENDORED_TRANSFORMS.json').read_bytes())
with zipfile.ZipFile(b.parent/'cytometry-high-impact-1/upstream-3/GatingML20-specification.zip') as z:
 for name,record in v['files'].items():
  if not name.endswith('/Transform.java'):continue
  expected=z.read(record['original_archive_member']).replace(b'\r\r\n',b'\n').replace(b'\r\n',b'\n').decode().replace('package edu.stanford.facs.transform;','package org.jlinalg.cytometry.internal.stanford;');project=(r/name).read_text();actual=project[project.index('package org.jlinalg.cytometry.internal.stanford;'):]
  print('prefix original',repr(expected[:200]));print('split firstblock',project.split(' */\n',1)[1]==expected);print(''.join(list(difflib.unified_diff(expected.splitlines(True),actual.splitlines(True)))[:20]))
