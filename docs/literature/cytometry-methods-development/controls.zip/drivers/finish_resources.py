import hashlib,json,shutil
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1]
source=b/'gating-input-fixtures-1/gating-input-controls.tsv';dest=r/'src/test/resources/org/jlinalg/cytometry/gating-input-controls.tsv'
assert not dest.exists();shutil.copyfile(source,dest)
attr=dest.parent/'.gitattributes';text=attr.read_text();assert 'gating-input-controls.tsv' not in text;attr.write_text(text+'gating-input-controls.tsv -text\n',newline='\n')
license=r/'LICENSES/stanford-cytometry-transforms.txt';dest=r/'src/main/resources/org/jlinalg/cytometry/gatingml20/LICENSE-Stanford-transforms.txt';assert not dest.exists();shutil.copyfile(license,dest)
h=r/'src/main/java/org/jlinalg/cytometry/internal/stanford/Hyperlog.java';text=h.read_text();print('\n'.join(text.splitlines()[:42]))
print('JLinAlgCli entry\n'+'\n'.join((r/'src/main/java/org/jlinalg/cli/JLinAlgCli.java').read_text().splitlines()[48:85]))
print('helpers\n'+'\n'.join((r/'src/main/java/org/jlinalg/cli/NextflowFiles.java').read_text().splitlines()[:100]))
