import re
from pathlib import Path
from pypdf import PdfReader
base=Path(__file__).resolve().parent;text='\n'.join(p.extract_text() for p in PdfReader(base.parent/'cytometry-high-impact-1/upstream-3/FCS31-normative-reference.pdf').pages)
for term in ['If f2','f2 is','f2 = 0','zero','Appendix A: Calibration']:
 print('\nTERM',term)
 matches=list(re.finditer(re.escape(term),text,re.I))
 for m in matches[-4:]:print(text[max(0,m.start()-160):m.start()+950])
