from pathlib import Path
text=(Path(__file__).parent/'normative-text.txt').read_text(encoding='utf8').splitlines()
for a,b in [(685,765),(860,915),(2810,2840)]:
 print('\nLINES',a,b);print('\n'.join(text[a-1:b]))
