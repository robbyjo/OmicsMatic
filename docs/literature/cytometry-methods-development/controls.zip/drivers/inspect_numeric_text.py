import json,re
from pathlib import Path
b=Path(__file__).resolve().parent
p=b/'standard/Gating-ML 2.0 Full 20130122/Compliance tests/set 2/data2.fcs';raw=p.read_bytes();ts=int(raw[10:18]);te=int(raw[18:26]);s=raw[ts:te+1]
for k in [b'$TOT',b'$PAR',b'$NEXTDATA',b'$BEGINDATA',b'$ENDDATA',b'$P1B',b'$P1R',b'$P1E',b'$P1G']:
 i=s.find(k);print(k,repr(s[i:i+65]))
print('head',repr(s[:120]),'tail',repr(s[-120:]))
from pypdf import PdfReader
pdf=b.parent/'cytometry-high-impact-1/upstream-3/FCS31-normative-reference.pdf'
text='\n'.join(page.extract_text() for page in PdfReader(str(pdf)).pages)
for m in re.finditer(r'(?i)padding|blanks|leading spaces|trailing spaces|white.?space',text):print(text[max(0,m.start()-170):m.end()+300])
m=Path('C:/Users/User/.codex/memories/MEMORY.md').read_text(encoding='utf8').splitlines();print('memory700',m[699])
