import re,zipfile,json
from pathlib import Path
from pypdf import PdfReader
base=Path(__file__).resolve().parent;standard=base/'standard/Gating-ML 2.0 Full 20130122'
reader=PdfReader(standard/'Specification/GatingML_2.0_Specification.pdf')
text='\n'.join(p.extract_text() for p in reader.pages);(base/'normative-text.txt').write_text(text,encoding='utf8')
for term in ['Permission','copyright','license','boundary','boundaries','winding','ray','compensation','channel values','logarithmic amplifier','NaN']:
 print('\nTERM',term)
 for m in list(re.finditer(re.escape(term),text,re.I))[:4]:print(text[max(0,m.start()-180):m.end()+550])
with zipfile.ZipFile(base.parent/'cytometry-high-impact-1/upstream-3/GatingML20-specification.zip') as z:
 n=next(n for n in z.namelist() if n.endswith('/package.html'));body=z.read(n).decode('utf8');(base/'original-java/package.html').write_bytes(z.read(n));print('\nJAVA PACKAGE DOCUMENTATION\n',re.sub('<[^>]+>',' ',body))
