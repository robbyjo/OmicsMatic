import hashlib,json,subprocess,time,traceback
from pathlib import Path
b=Path(__file__).resolve().parent;out=b/'original-invalid-model-1';out.mkdir();jar=b/'build-4/jar/omicsmatic-0.4.0.jar';jdk=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin')
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def run(name,cmd):
 cmd=list(map(str,cmd));save(out/(name+'.command.json'),cmd);began=time.monotonic()
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:r=subprocess.run(cmd,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=120)
 save(out/(name+'.PROCESS.json'),dict(exit_code=r.returncode,seconds=time.monotonic()-began));assert r.returncode==0
try:
 source=b/'GatingDefinitionCheck.java';save(out/'SOURCES.json',dict(probe=pin(source),jar=pin(jar)));(out/'classes').mkdir()
 run('javac',[jdk/'javac.exe','--release','17','-Xlint:all','-Werror','-cp',jar,'-d',out/'classes',source]);run('check',[jdk/'java.exe','-cp',str(out/'classes')+';'+str(jar),'org.jlinalg.cli.GatingDefinitionCheck',b/'standard/Gating-ML 2.0 Full 20130122/Compliance tests/set 1/gates1.xml',b/'official-inputs-1/scaled-1.tsv'])
 save(out/'COMPLETED.json',dict(status='PASS_EXPECTED_FULL_ORIGINAL_SET1_MODEL_REFUSAL_BEFORE_EVENTS',original_xml_unchanged=True,events_evaluated=0,gate='Ellipsoid3D',cause='asymmetric covariance',raw_set1_fcs_ingestion_claimed=False,full_standard_suite_passed=False));print((out/'check.stdout').read_text(),flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc()));raise
