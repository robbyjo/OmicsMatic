import hashlib,json,subprocess,sys,urllib.request,zipfile
from pathlib import Path,PurePosixPath
base=Path(__file__).resolve().parent;out=base/'flowutils-source-1';out.mkdir()
def fetch(url,name):
 with urllib.request.urlopen(url,timeout=120) as response:raw=response.read(16777217)
 assert len(raw)<=16777216;(out/name).write_bytes(raw);return raw
meta=json.loads(fetch('https://pypi.org/pypi/FlowUtils/1.2.2/json','pypi.json'))
print('VERSION',meta['info']['version'],'REQUIRES',meta['info']['requires_dist'],'ARTIFACTS',[(x['filename'],x['size']) for x in meta['urls']],flush=True)
source=[x for x in meta['urls'] if x['packagetype']=='sdist'];assert len(source)==1;source=source[0]
raw=fetch(source['url'],'flowutils-1.2.2.tar.gz');assert hashlib.sha256(raw).hexdigest()==source['digests']['sha256']
(out/'INTAKE.json').write_text(json.dumps(dict(version='1.2.2',url=source['url'],bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),scientific_execution_performed=False),indent=2)+'\n')
