import json,xml.etree.ElementTree as ET
from pathlib import Path
base=Path(__file__).resolve().parent;official=base/'standard/Gating-ML 2.0 Full 20130122/Compliance tests/set 2';actual=base/'official-controls-3/set-2';g='{http://www.isac-net.org/std/Gating-ML/v2.0/gating}'
print('SUMMARY\n',(official.parent/'Summary.csv').read_text(encoding='utf8')[:3500])
print('ACTUAL',sorted(p.name for p in actual.glob('Results_*.txt')));print('EXPECTED',sorted(p.name for p in official.glob('Results_*.txt')))
for e in ET.parse(official/'gates2.xml').getroot().findall(g+'PolygonGate'):
 name=e.attrib[g+'id'];source=official/('Results_'+name+'.txt')
 if not source.exists():print('EXPECTED_FILENAME_NOT_FOUND_FOR_GATE',name,ET.tostring(e,encoding='unicode')[:2000]);continue
 a=(actual/('Results_'+name+'.txt')).read_bytes().splitlines();b=source.read_bytes().splitlines();bad=[i for i,(x,y) in enumerate(zip(a,b)) if x!=y]
 print(name,'actual',a.count(b'1'),'expected',b.count(b'1'),'differences',len(bad),'first',bad[:12]);print(ET.tostring(e,encoding='unicode')[:4000] if bad else '')
