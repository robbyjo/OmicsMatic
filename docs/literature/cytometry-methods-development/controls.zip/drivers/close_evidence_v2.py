import hashlib,json,re,shutil,traceback,zipfile
from pathlib import Path
base=Path(__file__).resolve().parent;root=base.parents[1];out=base/'public-controls-2';out.mkdir();public=root/'docs/literature/cytometry-methods-development';built=base/'build-4'
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 return dict(bytes=p.stat().st_size,sha256=h.hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def copy(source,member):
 target=out/member;target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists(),member;shutil.copyfile(source,target)
try:
 validation=json.loads((base/'validation-2/COMPLETED.json').read_bytes());assert validation['windows_junit']==validation['linux_junit']==dict(tests=26,failures=0,errors=0,skipped=0)
 guards=json.loads((built/'SOURCES.json').read_bytes());assert all(pin(root/n)==v for n,v in guards.items())
 for name in guards:copy(root/name,'current-source/'+name)
 # Verify the derivation against the original archive, allowing only recorded non-numerical changes.
 archive=base.parent/'cytometry-high-impact-1/upstream-3/GatingML20-specification.zip';vendor=json.loads((base/'VENDORED_TRANSFORMS.json').read_bytes());derivation={}
 with zipfile.ZipFile(archive) as z:
  for name,record in vendor['files'].items():
   original=z.read(record['original_archive_member']);text=original.replace(b'\r\r\n',b'\n').replace(b'\r\n',b'\n').decode();text=text.replace('package edu.stanford.facs.transform;','package org.jlinalg.cytometry.internal.stanford;')
   if name.endswith('TransformParameterException.java'):text=text.replace('extends IllegalArgumentException\n{','extends IllegalArgumentException\n{\n\tprivate static final long serialVersionUID = 1L;')
   if name.endswith('Hyperlog.java'):text=text.replace('public class Hyperlog','@SuppressWarnings("this-escape") // Original constructor calls its own inverse; instantiated directly by the project wrapper.\npublic class Hyperlog')
   derived=(root/name).read_text();body=derived.split(' */\n',1)[1];assert body==text,name
   derivation[name]=dict(original=record['original_sha256'],derived=pin(root/name),algorithm_body_matches_after_only_documented_changes=True)
 save(out/'STANFORD_DERIVATION.json',derivation)
 copy(base/'EVIDENCE_CLOSURE_FAILURE.json','retained-closure-harness-failure/FAILURE.json')
 save(out/'retained-closure-harness-failure/EXPLANATION.json',dict(cause='First verifier removed an original leading Javadoc block while locating the package declaration, causing a false mismatch for Transform.java. Corrected verifier removes only the added BSD header and compares every remaining character. No algorithm or original source changed.'))
 for p in base.glob('*.py'):copy(p,'drivers/'+p.name)
 for p in base.glob('*.java'):copy(p,'drivers/'+p.name)
 for name in ['SPEC_ARCHIVE.json','VENDORED_TRANSFORMS.json','VENDORED_TRANSFORMS_V2.json']:copy(base/name,'provenance/'+name)
 copy(archive,'upstream-original/GatingML20-specification.zip')
 for folder in ['original-java','official-inputs-1','independent-polygons-1','source-discrepancy-audit-1','source-discrepancy-audit-2','source-discrepancy-audit-3','gating-input-fixtures-1','gating-input-fixtures-2','native-official-1','native-official-2','native-official-3','original-invalid-model-1','official-controls-1','official-controls-2','official-controls-3','validation-1','validation-2','flowutils-source-1','flowutils-reference-1']:
  directory=base/folder
  for p in directory.rglob('*'):
   if not p.is_file() or any(x in p.relative_to(directory).parts for x in ['classes','site-packages','test-classes']):continue
   copy(p,folder+'/'+p.relative_to(directory).as_posix())
 for folder in ['build-1','build-2','build-3','build-4']:
  directory=base/folder
  for p in directory.rglob('*'):
   if not p.is_file() or any(x in p.relative_to(directory).parts for x in ['jar','test-report']):continue
   copy(p,folder+'/'+p.relative_to(directory).as_posix())
 for filename in ['flowio-1.4.0.tar.gz','flowio-1.4.0-pypi.json','FCS31-normative-reference.pdf']:copy(base.parent/'cytometry-high-impact-1/upstream-3'/filename,'upstream-original/'+filename)
 old=root/'docs/literature/fcs-reader-development';copy(old/'controls.zip','historical-reader/controls.zip');copy(old/'VALIDATION.json','historical-reader/VALIDATION.json')
 for p in public.iterdir():
  if p.is_file() and p.suffix=='.md':copy(p,'documentation/'+p.name)
 for name in ['docs/vignettes/cytometry-gating.md','docs/vignettes/fcs-stored-channels.md','docs/literature/IMPLEMENTATION_PRIORITY.md']:copy(root/name,'documentation/'+Path(name).name)
 copy(old/'LICENSE-GPL-3.txt','LICENSE-GPL-3.txt');copy(root/'LICENSES/stanford-cytometry-transforms.txt','LICENSE-Stanford-transforms.txt')
 runtime=root/'build/nfcore-atacseq121-1/linux-test-runtime-1/junit-platform-console-standalone-1.13.4.jar';save(out/'REFERENCE_RUNTIME.json',dict(junit_console=pin(runtime),junit_filename=runtime.name,python='3.12.14',numpy='2.3.5',flowutils='1.2.2',runtime_binaries_omitted_except_small_bsd_reference_wheel=True))
 contents={p.relative_to(out).as_posix():pin(p) for p in sorted(out.rglob('*')) if p.is_file()};save(out/'INDEX.json',dict(schema_version=1,payload_files=contents))
 target=public/'controls.zip';assert not target.exists()
 with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in sorted(out.rglob('*')):
   if p.is_file():z.write(p,p.relative_to(out).as_posix())
 with zipfile.ZipFile(target) as z:
  assert len(z.namelist())==len(set(z.namelist()))==len(contents)+1
  assert json.loads(z.read('INDEX.json'))['payload_files']==contents
  for name,identity in contents.items():
   raw=z.read(name);assert dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())==identity,name
 audit=base/'source-discrepancy-audit-3/AUDIT.json';assert not (public/'REFERENCE_AUDIT.json').exists();shutil.copyfile(audit,public/'REFERENCE_AUDIT.json')
 report=dict(validation,controls_zip=pin(target),indexed_payload_files=len(contents),all_zip_members_readback_verified=True,artifact_relative_private_path='build/cytometry-methods-1/build-4/jar/omicsmatic-0.4.0.jar',numpy_compensation_reference_cases=88,independent_bridge_files=12,independent_storage_cases=25,reference_audit=pin(public/'REFERENCE_AUDIT.json'),source_definitions_untouched=True,invalid_original_set1_model_expected_refusal=json.loads((base/'original-invalid-model-1/COMPLETED.json').read_bytes()),new_catalog_integrations=0)
 save(public/'VALIDATION.json',report)
 (public/'SHA256SUMS').write_text(''.join(pin(p)['sha256']+'  '+p.name+'\n' for p in sorted(public.iterdir()) if p.is_file() and p.name!='SHA256SUMS'),encoding='utf8',newline='\n')
 assert all(pin(root/n)==v for n,v in guards.items())
 save(base/'EVIDENCE_CLOSED.json',dict(status='PASS_INDEXED_READBACK_VERIFIED_EVIDENCE_CLOSED',controls=pin(target),payload_files=len(contents),validation=pin(public/'VALIDATION.json')))
 print('PASS evidence',pin(target),'payload files',len(contents),flush=True)
except Exception as e:save(base/'EVIDENCE_CLOSURE_FAILURE_V2.json',dict(error=repr(e),traceback=traceback.format_exc()));print(repr(e),flush=True);raise
