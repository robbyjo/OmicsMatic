from pathlib import Path
import xml.etree.ElementTree as E
b=Path(__file__).resolve().parent;t='{http://www.isac-net.org/std/Gating-ML/v2.0/transformations}'
root=E.parse(b/'standard/Gating-ML 2.0 Full 20130122/Compliance tests/set 1/gates1.xml').getroot();e=root.find(t+'spectrumMatrix');print(E.tostring(e,encoding='unicode')[:4000])
print('\n'.join((b/'standard/Gating-ML 2.0 Full 20130122/XSD/Transformations.v2.0.xsd').read_text().splitlines()[-100:]))
