import csv,hashlib,json,xml.etree.ElementTree as ET
from fractions import Fraction
from pathlib import Path
import numpy as np
base=Path(__file__).resolve().parent;out=base/'source-discrepancy-audit-1';out.mkdir();source=base/'standard/Gating-ML 2.0 Full 20130122/Compliance tests';actual=base/'official-controls-3/set-2'
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
g='{http://www.isac-net.org/std/Gating-ML/v2.0/gating}';dt='{http://www.isac-net.org/std/Gating-ML/v2.0/datatypes}'
doc=ET.parse(source/'set 1/gates1.xml').getroot();el=next(e for e in doc.findall(g+'EllipsoidGate') if e.attrib[g+'id']=='Ellipsoid3D');cov=np.array([[float(x.attrib[dt+'value']) for x in row] for row in el.find(g+'covarianceMatrix')]);assert cov[0,2]!=cov[2,0] and np.min(np.linalg.eigvalsh((cov+cov.T)/2))<0
summary=list(csv.DictReader((source/'Summary.csv').read_text().splitlines()));gateids={e.attrib[g+'id'] for e in ET.parse(source/'set 2/gates2.xml').getroot() if e.tag.startswith(g) and e.tag!=g+'QuadrantGate'}
records=[]
for row in summary:
 if row['Folder']!='set 2':continue
 gate=row['Gate'];native=actual/('Results_'+gate+'.txt');expected=source/'set 2'/row['Expected result details file']
 if not native.exists():
  records.append(dict(gate=gate,status='SUMMARY_GATE_ID_NOT_IN_XML',summary=row,native_exists=False));continue
 if not expected.exists():records.append(dict(gate=gate,status='EXPECTED_FILENAME_MISSING',summary=row));continue
 a=native.read_bytes().splitlines();b=expected.read_bytes().splitlines();assert len(a)==len(b)==10000;bad=[i+1 for i,(x,y) in enumerate(zip(a,b)) if x!=y]
 records.append(dict(gate=gate,status='EXACT_ORIGINAL_MATCH' if not bad else 'RETAINED_ORIGINAL_MEMBERSHIP_DISCREPANCY',original=pin(expected),native=pin(native),mismatches=len(bad),event_indices_1based=bad))
comparison=json.loads((base/'independent-polygons-1/COMPARISON.json').read_bytes());assert sum(r['native_vs_flowutils_differences']!=0 for r in comparison['cases'])==1
datafile=base/'official-inputs-1/scaled-2.tsv'
with datafile.open() as f:names=f.readline().rstrip('\n').split('\t');data=np.loadtxt(f,delimiter='\t')
e=next(e for e in ET.parse(source/'set 2/gates2.xml').getroot().findall(g+'PolygonGate') if e.attrib[g+'id']=='Poly1u');vertices=[[Fraction(float(c.attrib[dt+'value'])) for c in v] for v in e.findall(g+'vertex')]
a=np.loadtxt(actual/'Results_Poly1u.txt',dtype=int);b=np.loadtxt(base/'independent-polygons-1/FlowUtils_Poly1u.txt',dtype=int);proof=[]
for index in np.flatnonzero(a!=b):
 point=[Fraction(float(data[index,names.index(e.find(g+'dimension').find(dt+'fcs-dimension').attrib[dt+'name'])])),Fraction(float(data[index,names.index(e.findall(g+'dimension')[1].find(dt+'fcs-dimension').attrib[dt+'name'])]))]
 edges=[]
 for j,v in enumerate(vertices):
  w=vertices[(j+1)%len(vertices)];cross=(w[0]-v[0])*(point[1]-v[1])-(w[1]-v[1])*(point[0]-v[0])
  if cross==0 and all(min(v[k],w[k])<=point[k]<=max(v[k],w[k]) for k in [0,1]):edges.append(j+1)
 assert a[index]==1 and b[index]==0 and edges
 proof.append(dict(event_1based=int(index+1),exact_binary_rational_point=list(map(str,point)),exact_boundary_edges_1based=edges,native_and_official_membership=1,flowutils_membership=0))
assert len(proof)==3
report=dict(status='AUDITED_SOURCE_CONTRADICTIONS_NO_EXPECTED_FILES_CHANGED',invalid_set1_gate=dict(id='Ellipsoid3D',covariance=cov.tolist(),symmetric=False,symmetric_part_eigenvalues=np.linalg.eigvalsh((cov+cov.T)/2).tolist(),required_source_rule='Normative section5.3.3(j) requires symmetric positive-definite covariance; native full-file admission refused.'),set2_gate_comparisons=records,set2_independent_polygons=comparison,exact_inclusive_boundary_proof=proof,all_original_expected_files_unchanged=True,full_standard_suite_pass_claimed=False,source_files={str(p.relative_to(source)):pin(p) for p in source.rglob('*') if p.is_file()})
(out/'AUDIT.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print('PASS read-only audit: original24 exact matches; five complete polygon bitmap discrepancies; one missing/orphan expected-name pair; three exact boundary points explain the FlowUtils difference',flush=True)
