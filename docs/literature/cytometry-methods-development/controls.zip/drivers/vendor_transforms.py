import hashlib,json,re,zipfile
from pathlib import Path
base=Path(__file__).resolve().parent;root=base.parents[1]
archive=base.parent/'cytometry-high-impact-1/upstream-3/GatingML20-specification.zip'
target=root/'src/main/java/org/jlinalg/cytometry/internal/stanford';target.mkdir(parents=True,exist_ok=False)
records={}
with zipfile.ZipFile(archive) as z:
 package=z.read(next(n for n in z.namelist() if n.endswith('/package.html'))).decode('utf8')
 license_text=re.sub('<[^>]*>',' ',package[package.index('Copyright (c) 2009'):package.index('The Logicle method is patented')])
 license_text='\n'.join(line.strip() for line in license_text.replace('\r','\n').splitlines() if line.strip())
 assert 'Redistribution and use in source and binary forms, with or without modification' in license_text
 notice=root/'LICENSES/stanford-cytometry-transforms.txt';assert not notice.exists();notice.write_text(license_text+'\n\nOriginal package documentation and source hashes are retained in the cytometry methods evidence.\n',encoding='utf8',newline='\n')
 for name in z.namelist():
  if not name.endswith('.java') or name.endswith('/TestTransforms.java'):continue
  original=z.read(name);text=original.replace(b'\r\r\n',b'\n').replace(b'\r\n',b'\n').decode('utf8')
  assert text.count('package edu.stanford.facs.transform;')==1
  text=text.replace('package edu.stanford.facs.transform;','package org.jlinalg.cytometry.internal.stanford;')
  if name.endswith('/TransformParameterException.java'):
   anchor='extends IllegalArgumentException\n{';assert text.count(anchor)==1;text=text.replace(anchor,anchor+'\n\tprivate static final long serialVersionUID = 1L;')
  text='/*\n * SPDX-License-Identifier: BSD-3-Clause\n'+''.join(' * '+line+'\n' for line in license_text.splitlines())+' *\n * Project changes: package relocation, line endings, and serialVersionUID only.\n */\n'+text
  dest=target/Path(name).name;dest.write_text(text,encoding='utf8',newline='\n')
  records[dest.relative_to(root).as_posix()]=dict(original_archive_member=name,original_bytes=len(original),original_sha256=hashlib.sha256(original).hexdigest(),bytes=dest.stat().st_size,sha256=hashlib.sha256(dest.read_bytes()).hexdigest())
out=base/'VENDORED_TRANSFORMS.json';out.write_text(json.dumps(dict(status='VENDORED_BSD_JAVA_REFERENCE_ALGORITHMS_UNCHANGED',source_archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),files=records,notice=str(notice.relative_to(root))),indent=2)+'\n',encoding='utf8')
print('PASS',len(records),'original Java algorithm bodies preserved; relocated package and complete BSD notices')
