import hashlib,json,subprocess,time,traceback
from pathlib import Path
base=Path(__file__).resolve().parent;root=base.parents[1];out=base/'official-controls-3';out.mkdir()
jdk=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin');jar=base.parent/'cytometry-high-impact-1/build-1/jar/omicsmatic-0.4.0.jar'
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def run(label,command):
 command=list(map(str,command));save(out/(label+'.command.json'),command);began=time.monotonic()
 with (out/(label+'.stdout')).open('xb') as so,(out/(label+'.stderr')).open('xb') as se:r=subprocess.run(command,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=300)
 save(out/(label+'.PROCESS.json'),dict(exit_code=r.returncode,seconds=time.monotonic()-began));assert r.returncode==0,label;print('PASS',label,flush=True)
try:
 sources=list((root/'src/main/java/org/jlinalg/cytometry').glob('*.java'))+list((root/'src/main/java/org/jlinalg/cytometry/internal/stanford').glob('*.java'))+[base/'GatingProbe.java']
 identities={str(p):pin(p) for p in sources};save(out/'SOURCES.json',identities)
 (out/'classes').mkdir();run('javac',[jdk/'javac.exe','--release','17','-Xlint:all','-Werror','-cp',jar,'-d',out/'classes',*sources])
 classpath=str(out/'classes')+';'+str(root/'src/main/resources')+';'+str(jar);proof=[]
 for i in [2]:
  official=base/('standard/Gating-ML 2.0 Full 20130122/Compliance tests/set '+str(i));expected={p.name:pin(p) for p in official.glob('Results_*.txt')}
  run('set-'+str(i),[jdk/'java.exe','-Xmx2048m','-cp',classpath,'org.jlinalg.cli.GatingProbe',official/('gates'+str(i)+'.xml'),base/('official-inputs-1/scaled-'+str(i)+'.tsv'),base/('official-inputs-1/metadata-'+str(i)+'.json'),out/('set-'+str(i))])
  actual={p.name:pin(p) for p in (out/('set-'+str(i))).glob('Results_*.txt')};assert actual==expected,[name for name in set(actual)|set(expected) if actual.get(name)!=expected.get(name)]
  proof.append(dict(set=i,events=13367 if i==1 else 10000,gates=len(expected),all_complete_membership_files_match=True));print('PASS',len(expected),'complete expected membership files',flush=True)
 assert all(pin(Path(p))==value for p,value in identities.items())
 save(out/'COMPLETED.json',dict(status='PASS_SELECTED_COMPLETE_OFFICIAL_SET2_ON_ORIGINAL_PREPARED_SCALE_VALUES',sets=proof,source_files_unchanged=True,full_set1_refusal_retained='official-controls-2: invalid asymmetric/non-positive-definite Ellipsoid3D covariance; no source repair or full-set1 admission',raw_native_fcs_ingestion_claimed=False,new_catalog_integrations=0))
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc()));print(repr(e),flush=True);raise
