import re,xml.etree.ElementTree as ET
from pathlib import Path
base=Path(__file__).resolve().parent;text=(base/'normative-text.txt').read_text(encoding='utf8')
for section in ['4.1 Referencing','4.2 Referencing','4.4 Gate','5.1.1 De','5.4.1 De','5.5.3','6.1.1','6.1.3','7.4 Validity','7.6.1 Standard']:
 matches=list(re.finditer(r'(?m)^'+re.escape(section),text))
 if matches:
  m=matches[-1];print('\nSECTION',section,'\n',text[m.start():m.start()+3500])
for p in (base/'standard/Gating-ML 2.0 Full 20130122/Compliance tests').glob('set */gates*.xml'):
 tree=ET.parse(p).getroot();print('\nDEFINITIONS',p.name)
 for el in tree:
  tag=el.tag.rsplit('}',1)[-1]
  if tag in ['transformation','spectrumMatrix','QuadrantGate','BooleanGate']:
   print(ET.tostring(el,encoding='unicode')[:3000])
