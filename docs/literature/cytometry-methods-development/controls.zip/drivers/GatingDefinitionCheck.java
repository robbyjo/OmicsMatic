package org.jlinalg.cli;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import org.jlinalg.cytometry.GatingMl20;

/** Reference control only: original whole XML must refuse invalid covariance before events. */
public final class GatingDefinitionCheck {
    private GatingDefinitionCheck() { }
    public static void main(String[] args)throws Exception {
        List<String> names;
        try(var input=Files.newBufferedReader(Path.of(args[1]),StandardCharsets.UTF_8)) {names=List.of(input.readLine().split("\t",-1));}
        try {GatingMl20.read(Path.of(args[0]),names,GatingMl20.FcsCompensation.absent(),1e-12,GatingMl20.Limits.defaults());}
        catch(IOException expected) {
            if(!expected.getMessage().contains("Ellipsoid3D")||!expected.getMessage().contains("symmetric"))throw expected;
            System.out.println("PASS expected complete original set1 model refusal before any events: "+expected.getMessage());return;
        }
        throw new AssertionError("Original invalid covariance was admitted");
    }
}
