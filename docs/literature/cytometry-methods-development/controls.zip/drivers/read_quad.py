from pathlib import Path
r=Path(__file__).resolve().parents[2]
print('\n'.join((r/'src/main/resources/org/jlinalg/cytometry/gatingml20/Gating-ML.v2.0.xsd').read_text().splitlines()[60:125]))
