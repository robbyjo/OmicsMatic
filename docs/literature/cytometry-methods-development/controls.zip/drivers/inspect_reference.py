import json,subprocess,zipfile,importlib.util
from pathlib import Path
base=Path(__file__).resolve().parent;standard=base/'standard/Gating-ML 2.0 Full 20130122'
print((standard/'Readme.txt').read_text());print((standard/'Compliance tests/readme.txt').read_text())
with zipfile.ZipFile(base.parent/'cytometry-high-impact-1/upstream-3/GatingML20-specification.zip') as z:
 for n in z.namelist():
  if n.endswith('.java'):
   text=z.read(n).decode('utf8');print('\nJAVA',Path(n).name,'\n',text[:1500])
   p=base/'original-java'/Path(n).name;p.parent.mkdir(exist_ok=True);p.write_bytes(z.read(n))
for name in ['pypdf','fitz','numpy','scipy']:print(name,bool(importlib.util.find_spec(name)))
code="import shutil;print(shutil.which('pdftotext'));print(shutil.which('Rscript'))"
r=subprocess.run(['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--exec','/usr/bin/python3','-c',code],capture_output=True,timeout=60);print(r.stdout.decode(),r.stderr.decode())
for p in (standard/'XSD').glob('*.xsd'):
 print('\nXSD',p.name);print(p.read_text()[:6000])
