import hashlib,json,sys,xml.etree.ElementTree as ET
from pathlib import Path
import numpy as np
base=Path(__file__).resolve().parent;out=base/'independent-polygons-1';out.mkdir();sys.path.insert(0,str(base/'flowutils-reference-1/site-packages'))
import flowutils
g='{http://www.isac-net.org/std/Gating-ML/v2.0/gating}';t='{http://www.isac-net.org/std/Gating-ML/v2.0/transformations}';d='{http://www.isac-net.org/std/Gating-ML/v2.0/datatypes}'
src=base/'standard/Gating-ML 2.0 Full 20130122/Compliance tests/set 2';tree=ET.parse(src/'gates2.xml').getroot()
transforms={e.attrib[t+'id']:list(e)[0] for e in tree.findall(t+'transformation')};meta=json.loads((base/'official-inputs-1/metadata-2.json').read_bytes())
path=base/'official-inputs-1/scaled-2.tsv'
with path.open() as f:names=f.readline().rstrip('\n').split('\t');data=np.loadtxt(f,delimiter='\t')
parts=meta['compensation_keywords']['spill'].split(',');n=int(parts[0]);comp_names=parts[1:n+1];s=np.array(list(map(float,parts[n+1:]))).reshape(n,n);columns=[names.index(x) for x in comp_names]
compensated=data.copy();compensated[:,columns]=np.linalg.solve(s.T,data[:,columns].T).T
records=[]
for e in tree.findall(g+'PolygonGate'):
 gate=e.attrib[g+'id'];vectors=[]
 for dim in e.findall(g+'dimension'):
  index=names.index(dim.find(d+'fcs-dimension').attrib[d+'name']);values=(data if dim.attrib[g+'compensation-ref']=='uncompensated' else compensated)[:,index].copy()
  transform=dim.attrib.get(g+'transformation-ref')
  if transform:
   el=transforms[transform];a={key.rsplit('}',1)[-1].lower():float(v) for key,v in el.attrib.items()};kind=el.tag.rsplit('}',1)[-1];function=flowutils.transforms.asinh if kind=='fasinh' else getattr(flowutils.transforms,kind);values=function(values,None,**a)
  vectors.append(values)
 vertices=np.array([[float(c.attrib[d+'value']) for c in v] for v in e.findall(g+'vertex')]);points=np.column_stack(vectors)
 result=flowutils.gating.points_in_polygon(vertices,points);native=np.loadtxt(base/('official-controls-3/set-2/Results_'+gate+'.txt'),dtype=int).astype(bool)
 original_path=src/('Results_'+gate+'.txt');original=np.loadtxt(original_path,dtype=int).astype(bool) if original_path.exists() else None
 record=dict(gate=gate,events=len(result),native_inside=int(np.sum(native)),flowutils_inside=int(np.sum(result)),native_vs_flowutils_differences=int(np.sum(native!=result)),original_inside=int(np.sum(original)) if original is not None else None,original_vs_flowutils_differences=int(np.sum(original!=result)) if original is not None else None,original_expected_file_exists=original is not None)
 records.append(record);print(record,flush=True)
 (out/('FlowUtils_'+gate+'.txt')).write_bytes(b''.join(b'1\n' if x else b'0\n' for x in result))
(out/'COMPARISON.json').write_text(json.dumps(dict(flowutils=flowutils.__version__,numpy=np.__version__,cases=records,originals_unchanged=True,full_standard_suite_pass_claimed=False),indent=2)+'\n')
assert all(r['native_vs_flowutils_differences']==0 for r in records)
(out/'COMPLETED.json').write_text(json.dumps(dict(status='PASS_NATIVE_VS_PINNED_FLOWUTILS_ALL8_COMPLETE_POLYGONS',events_each=10000,total_memberships=80000,original_gold_discrepancies_retained=True),indent=2)+'\n')
