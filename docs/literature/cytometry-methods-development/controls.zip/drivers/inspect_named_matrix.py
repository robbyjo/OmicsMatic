from pathlib import Path
b=Path(__file__).resolve().parent
text=(b/'normative-text.txt').read_text()
for term in ['matrix-inverted-already','position element','Each quadrant','each quadrant']:
 i=text.find(term);print('\nTERM',term,'\n',text[max(0,i-250):i+1600])
x=(b/'standard/Gating-ML 2.0 Full 20130122/XSD/Transformations.v2.0.xsd').read_text().splitlines()
for i,s in enumerate(x):
 if 'spectrumMatrix_Type' in s:print('\n'.join(x[i:i+65]))
