import csv,hashlib,json,shutil,subprocess,time,traceback,xml.etree.ElementTree as ET,zipfile
from pathlib import Path
base=Path(__file__).resolve().parent;root=base.parents[1];out=base/'validation-1';out.mkdir();built=base/'build-3';jar=built/'jar/omicsmatic-0.4.0.jar'
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 return dict(bytes=p.stat().st_size,sha256=h.hexdigest())
def lp(p):return '/mnt/d/projects/JLinAlg/build/high-impact-stats-1/'+p.relative_to(root).as_posix()
def run(label,command,expected=0):
 command=list(map(str,command));save(out/(label+'.command.json'),command);began=time.monotonic()
 with (out/(label+'.stdout')).open('xb') as so,(out/(label+'.stderr')).open('xb') as se:r=subprocess.run(command,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=300)
 save(out/(label+'.PROCESS.json'),dict(exit_code=r.returncode,expected=expected,seconds=time.monotonic()-began));assert r.returncode==expected,label;print('PASS',label,flush=True)
try:
 assert json.loads((built/'COMPLETED.json').read_bytes())['junit']==dict(tests=25,failures=0,errors=0,skipped=0)
 guards=json.loads((built/'SOURCES.json').read_bytes());assert all(pin(root/n)==v for n,v in guards.items())
 predecessor=base.parent/'cytometry-high-impact-1/build-1/jar/omicsmatic-0.4.0.jar'
 with zipfile.ZipFile(predecessor) as a,zipfile.ZipFile(jar) as b:
  assert set(a.namelist()).issubset(b.namelist());changed=[n for n in a.namelist() if a.read(n)!=b.read(n)]
  assert all(n=='org/jlinalg/cli/JLinAlgCli.class' or n.startswith('org/jlinalg/cytometry/FcsReader') for n in changed),changed
  added=sorted(set(b.namelist())-set(a.namelist()));assert all(n.startswith('org/jlinalg/cytometry/') or n.startswith('org/jlinalg/cli/CytometryGateCli') for n in added),added
  assert b.read('org/jlinalg/cytometry/gatingml20/LICENSE-Stanford-transforms.txt')==(root/'LICENSES/stanford-cytometry-transforms.txt').read_bytes()
 for folder in ['org/jlinalg/cytometry']:
  shutil.copytree(root/'build/classes/java/test'/folder,out/'test-classes'/folder)
 for p in (root/'build/classes/java/test/org/jlinalg/cli').glob('CytometryGateCliTest*.class'):
  d=out/'test-classes/org/jlinalg/cli'/p.name;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d)
 shutil.copytree(root/'build/resources/test/org/jlinalg/cytometry',out/'test-resources/org/jlinalg/cytometry')
 cp=lp(jar)+':'+lp(out/'test-classes')+':'+lp(out/'test-resources');prefix=['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--exec','/usr/bin/java','-Xmx2048m']
 cmd=prefix+['-jar',lp(root/'build/nfcore-atacseq121-1/linux-test-runtime-1/junit-platform-console-standalone-1.13.4.jar'),'execute','--class-path',cp]
 for cls in ['org.jlinalg.cytometry.FcsReaderTest','org.jlinalg.cytometry.CytometryMethodsTest','org.jlinalg.cytometry.FcsGatingInputTest','org.jlinalg.cli.CytometryGateCliTest']:cmd+=['--select-class',cls]
 cmd+=['--reports-dir',lp(out/'linux-junit-reports'),'--disable-ansi-colors'];run('linux-junit',cmd)
 trees=[ET.parse(p).getroot() for p in (out/'linux-junit-reports').glob('TEST-*.xml')];counts={k:sum(int(t.attrib.get(k,0)) for t in trees) for k in ['tests','failures','errors','skipped']};assert counts==dict(tests=25,failures=0,errors=0,skipped=0),counts
 request=json.loads((base/'native-official-2/request.json').read_bytes());request['fcs']=lp(Path(request['fcs']));request['gating_ml']=lp(Path(request['gating_ml']));request['out']=lp(out/'linux-native-result');save(out/'linux-request.json',request)
 run('linux-native-official',prefix+['-jar',lp(jar),'cytometry-tools','GATE','--request',lp(out/'linux-request.json')])
 for name in ['memberships.tsv','counts.tsv']:assert pin(out/'linux-native-result'/name)==pin(base/'native-official-2/result'/name),name
 command=[str(Path('C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')),'-X','utf8','-B',str(root/'tools/literature/cytometry/audit_gating_reference.py'),'--archive',str(base.parent/'cytometry-high-impact-1/upstream-3/GatingML20-specification.zip'),'--standard',str(base/'standard/Gating-ML 2.0 Full 20130122'),'--native-run',str(base/'native-official-2/result'),'--flowutils-polygons',str(base/'independent-polygons-1'),'--prepared-scale',str(base/'official-inputs-1/scaled-2.tsv'),'--out',str(base/'source-discrepancy-audit-2')];run('archive-and-independent-audit',command)
 assert all(pin(root/n)==v for n,v in guards.items())
 save(out/'COMPLETED.json',dict(status='PASS_PACKAGED_NATIVE_CYTOMETRY_TWO_PLATFORM_VALIDATION',artifact=pin(jar),windows_junit=counts,linux_junit=counts,overlapping_same_tests=True,original_raw_events_each_platform=10000,gates=30,complete_memberships_each_platform=300000,windows_linux_tables_byte_identical=True,predecessor=pin(predecessor),changed_predecessor_entries=changed,added_entries=added,all_unrelated_predecessor_members_byte_identical=True,stanford_binary_license_present=True,full_standard_suite_passed=False,new_catalog_integrations=0,whole_goal_complete=False))
 print('PASS two-platform25 tests and complete raw-file gate populations; independent audit closed',flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc()));print(repr(e),flush=True);raise
