import hashlib,json,shutil,zipfile
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1]
src=b/'gating-input-fixtures-2/gating-input-controls.tsv';dst=r/'src/test/resources/org/jlinalg/cytometry/gating-input-controls.tsv'
assert hashlib.sha256(dst.read_bytes()).hexdigest()=='a707dd94ea6a6d05f560709a7fcbbc44f314bf1d64fc7024f067b0c8ea7eb30d';shutil.copyfile(src,dst)
p=r/'src/test/java/org/jlinalg/cytometry/FcsGatingInputTest.java';text=p.read_text();assert text.count('a707dd94ea6a6d05f560709a7fcbbc44f314bf1d64fc7024f067b0c8ea7eb30d')==1;p.write_text(text.replace('a707dd94ea6a6d05f560709a7fcbbc44f314bf1d64fc7024f067b0c8ea7eb30d','551a488cb64e24b277131558ed929c4dfe5dee6020277dac3430d79fced63ee6'),newline='\n')
p=r/'src/main/java/org/jlinalg/cli/CytometryGateCli.java';text=p.read_text();assert text.count('text_policy=EXACT|ALLOW_TRAILING_SPACE_PADDING, compensation')==1;p.write_text(text.replace('text_policy=EXACT|ALLOW_TRAILING_SPACE_PADDING, compensation','text_policy=EXACT|ALLOW_TRAILING_SPACE_PADDING, numeric_policy=EXACT|ALLOW_ASCII_SPACE_PADDING, compensation'),newline='\n')
text=(b/'build_native_gate.py').read_text().replace("out=base/'build-2'","out=base/'build-3'").replace('dict(tests=22,','dict(tests=25,');p=b/'build_native_gate_final.py';assert not p.exists();p.write_text(text,newline='\n')
text=(b/'check_native_official.py').read_text().replace("out=base/'native-official-1'","out=base/'native-official-2'").replace("base/'build-2/","base/'build-3/").replace("text_policy='EXACT',","text_policy='EXACT',numeric_policy='ALLOW_ASCII_SPACE_PADDING',");p=b/'check_native_official_final.py';assert not p.exists();p.write_text(text,newline='\n')
with zipfile.ZipFile(b.parent/'cytometry-high-impact-1/upstream-3/GatingML20-specification.zip') as z:print('ZIPnames',z.namelist()[:4])
files={}
for p in (r/'src/main/java/org/jlinalg/cytometry/internal/stanford').glob('*.java'):
 raw=p.read_bytes();files[p.name]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
record=dict(status='SOURCE_DERIVATION_RECORD_V2_NO_ALGORITHM_CHANGES',previous_record=dict(path='VENDORED_TRANSFORMS.json',sha256=hashlib.sha256((b/'VENDORED_TRANSFORMS.json').read_bytes()).hexdigest()),additional_change='Hyperlog constructor lint-suppression annotation and accurate project-change comment; no numerical algorithm modification',derived=files)
(b/'VENDORED_TRANSFORMS_V2.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
