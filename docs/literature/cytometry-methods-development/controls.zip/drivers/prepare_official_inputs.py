import hashlib,json,math,sys
from pathlib import Path
base=Path(__file__).resolve().parent;out=base/'official-inputs-1';out.mkdir()
sys.path.insert(0,str(base.parent/'cytometry-high-impact-1/upstream-3/flowio-source/flowio-1.4.0/src'))
import flowio,numpy as np
records=[]
for i in [1,2]:
 source=base/('standard/Gating-ML 2.0 Full 20130122/Compliance tests/set '+str(i)+'/data'+str(i)+'.fcs')
 raw=source.read_bytes();data=flowio.FlowData(str(source));assert len(data.events)==data.event_count*data.channel_count
 counts=np.asarray(data.events,dtype=np.float64).reshape(data.event_count,data.channel_count)
 scaled=np.empty_like(counts);metadata=[]
 for index in range(data.channel_count):
  p='p'+str(index+1);e=list(map(float,data.text[p+'e'].split(',')));g=float(data.text.get(p+'g','1'));r=float(data.text[p+'r'])
  assert len(e)==2 and g>0 and r>0
  if e[0]>0:
   f2=1 if e[1]==0 else e[1];scaled[:,index]=f2*np.power(10,e[0]*counts[:,index]/r)
  else:scaled[:,index]=counts[:,index]/g
  metadata.append(dict(name=data.text[p+'n'],range=data.text[p+'r'],amplification=data.text[p+'e'],gain=data.text.get(p+'g')))
 with (out/('scaled-'+str(i)+'.tsv')).open('w',encoding='utf8',newline='\n') as f:
  f.write('\t'.join(p['name'] for p in metadata)+'\n')
  for row in scaled:f.write('\t'.join(format(float(x),'.17g') for x in row)+'\n')
 comp={k:v for k,v in data.text.items() if k.lower() in ['spillover','spill','comp']}
 record=dict(set=i,source=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()),flowio=flowio.__version__,numpy=np.__version__,edition=data.version,data_type=data.data_type,events=data.event_count,metadata=metadata,compensation_keywords=comp)
 (out/('metadata-'+str(i)+'.json')).write_text(json.dumps(record,indent=2)+'\n',encoding='utf8');records.append(record)
 assert source.read_bytes()==raw
 print(i,data.event_count,data.version,data.data_type,'channels',metadata,'compensation keys',list(comp),flush=True)
root=base.parents[1];dest=root/'src/main/resources/org/jlinalg/cytometry/gatingml20';dest.mkdir(parents=True,exist_ok=False)
schema={}
for p in (base/'standard/Gating-ML 2.0 Full 20130122/XSD').glob('*.xsd'):
 raw=p.read_bytes();(dest/p.name).write_bytes(raw);schema[p.name]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
(dest/'.gitattributes').write_text('*.xsd -text\n',encoding='utf8',newline='\n')
(out/'SCHEMAS.json').write_text(json.dumps(schema,indent=2)+'\n');print('SCHEMAS',schema)
(out/'COMPLETED.json').write_text(json.dumps(dict(status='PASS_COMPLETE_ORIGINAL_STORED_TO_SCALE_REFERENCE_INPUTS_ONLY',sets=records,source_files_unchanged=True,original_expected_memberships_modified=False),indent=2)+'\n',encoding='utf8')
