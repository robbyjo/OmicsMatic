import hashlib,json,subprocess,sys,zipfile
from pathlib import Path,PurePosixPath
base=Path(__file__).resolve().parent;out=base/'flowutils-reference-1';out.mkdir();meta=json.loads((base/'flowutils-source-1/pypi.json').read_bytes())
tag='cp'+str(sys.version_info.major)+str(sys.version_info.minor)
row=[r for r in meta['urls'] if r['filename']==f'flowutils-1.2.2-{tag}-{tag}-win_amd64.whl'];assert len(row)==1;row=row[0]
dest=out/row['filename'];linux='/mnt/d/projects/JLinAlg/build/high-impact-stats-1/'+dest.relative_to(base.parents[1]).as_posix()
code="import urllib.request;from pathlib import Path;import sys;req=urllib.request.Request(sys.argv[1],headers={'User-Agent':'OmicsMatic-pinned-research-reference'});r=urllib.request.urlopen(req,timeout=90);body=r.read(1048577);assert len(body)<=1048576;Path(sys.argv[2]).write_bytes(body)"
r=subprocess.run(['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--exec','/usr/bin/python3','-c',code,row['url'],linux],capture_output=True,timeout=120);assert r.returncode==0,r.stderr.decode()
raw=dest.read_bytes();assert len(raw)==row['size'] and hashlib.sha256(raw).hexdigest()==row['digests']['sha256']
target=out/'site-packages';target.mkdir()
with zipfile.ZipFile(dest) as z:
 for name in z.namelist():
  p=PurePosixPath(name);assert not p.is_absolute() and '..' not in p.parts
  path=target.joinpath(*p.parts);path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(z.read(name))
sys.path.insert(0,str(target));import flowutils,numpy,inspect
assert flowutils.__version__=='1.2.2' and numpy.__version__.split('.')[0]=='2'
record=dict(status='PASS_WORKSPACE_ONLY_VERIFIED_FLOWUTILS_REFERENCE',python=sys.version,flowutils=flowutils.__version__,numpy=numpy.__version__,wheel=dict(url=row['url'],bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()),global_packages_modified=False,scientific_analysis_executed=False)
(out/'COMPLETED.json').write_text(json.dumps(record,indent=2)+'\n')
for name in ['logicle','hyperlog','asinh']:print(name,inspect.signature(getattr(flowutils.transforms,name)))
print('PASS original private reference runtime',tag,flowutils.__version__,numpy.__version__)
