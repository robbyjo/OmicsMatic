import re,xml.etree.ElementTree as ET
from pathlib import Path
import numpy as np
base=Path(__file__).resolve().parent;g='{http://www.isac-net.org/std/Gating-ML/v2.0/gating}';d='{http://www.isac-net.org/std/Gating-ML/v2.0/datatypes}'
for p in (base/'standard/Gating-ML 2.0 Full 20130122/Compliance tests').glob('set */gates*.xml'):
 for e in ET.parse(p).getroot().findall(g+'EllipsoidGate'):
  a=np.array([[float(x.attrib[d+'value']) for x in r] for r in e.find(g+'covarianceMatrix')])
  print(p.name,e.attrib[g+'id'],a.tolist(),'eig',np.linalg.eigvalsh(a).tolist(),'det',np.linalg.det(a))
text=(base/'normative-text.txt').read_text(encoding='utf8');matches=list(re.finditer(r'(?m)^5\.3\.3',text));print(text[matches[-1].start():matches[-1].start()+5000])
