from pathlib import Path
b=Path(__file__).resolve().parent
changes=[('build_native_gate_final.py','build_native_gate_closed.py',[("out=base/'build-3'","out=base/'build-4'"),('dict(tests=25,','dict(tests=26,')]),('check_native_official_final.py','check_native_official_closed.py',[("out=base/'native-official-2'","out=base/'native-official-3'"),("base/'build-3/","base/'build-4/")]),('validate_packaged.py','validate_packaged_closed.py',[("out=base/'validation-1'","out=base/'validation-2'"),("built=base/'build-3'","built=base/'build-4'"),('dict(tests=25,','dict(tests=26,'),("native-official-2","native-official-3"),("source-discrepancy-audit-2","source-discrepancy-audit-3"),('two-platform25','two-platform26')])]
for old,new,replacements in changes:
 text=(b/old).read_text()
 for x,y in replacements:
  assert x in text,x;text=text.replace(x,y)
 p=b/new;assert not p.exists();p.write_text(text,newline='\n')
