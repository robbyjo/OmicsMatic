import hashlib,json,subprocess,time,traceback
from pathlib import Path
base=Path(__file__).resolve().parent;root=base.parents[1];out=base/'native-official-1';out.mkdir();jar=base/'build-2/jar/omicsmatic-0.4.0.jar';jdk=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin')
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
try:
 official=base/'standard/Gating-ML 2.0 Full 20130122/Compliance tests/set 2'
 request=dict(schema_version=1,fcs=str(official/'data2.fcs'),gating_ml=str(official/'gates2.xml'),out=str(out/'result'),legacy_charset='ISO-8859-1',text_policy='EXACT',compensation='AUTO',legacy_zero_log_minimum_as_one=False,svd_relative_cutoff=1e-12,population_declaration='All10000 original ISAC set2 events, complete original axis and acquisition order',gating_provenance='Unchanged complete ISAC Gating-ML2.0 20130122 set2 gates2.xml; reference discrepancies are audited separately')
 save(out/'request.json',request);command=[str(jdk/'java.exe'),'-Xmx2048m','-jar',str(jar),'cytometry-tools','GATE','--request',str(out/'request.json')];save(out/'command.json',command);save(out/'ARTIFACT.json',pin(jar));began=time.monotonic()
 with (out/'stdout').open('xb') as so,(out/'stderr').open('xb') as se:r=subprocess.run(command,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=300)
 save(out/'PROCESS.json',dict(exit_code=r.returncode,seconds=time.monotonic()-began));print('native exit',r.returncode,flush=True);assert r.returncode==0
 old=base/'official-controls-3/set-2';import csv
 with (out/'result/memberships.tsv').open(encoding='utf8',newline='') as f:rows=list(csv.reader(f,delimiter='\t'))
 assert len(rows)==10001 and len(rows[0])==31
 for j,gate in enumerate(rows[0][1:],1):assert b''.join((row[j]+'\n').encode() for row in rows[1:])==(old/('Results_'+gate+'.txt')).read_bytes(),gate
 save(out/'COMPLETED.json',dict(status='PASS_PACKAGED_NATIVE_FCS_SCALE_COMPENSATION_AND_ALL30_SET2_GATES',events=10000,gates=30,all300000_memberships_equal_retained_prepared_component=True,full_standard_suite_pass_claimed=False))
 print('PASS all300000 native raw-file memberships match retained prepared-component outputs',flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc()));print(repr(e),flush=True);raise
