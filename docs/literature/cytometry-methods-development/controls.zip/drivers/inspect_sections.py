import re,xml.etree.ElementTree as ET
from pathlib import Path
base=Path(__file__).resolve().parent;text=(base/'normative-text.txt').read_text(encoding='utf8')
for start,stop in [('4.2','4.3'),('4.3','4.4'),('5.1.3','5.1.4'),('5.4.3','5.4.4'),('6.2.1','6.2.2'),('6.2.3','6.2.4'),('7.6.1','7.6.2'),('7.6.2','8 Additional')]:
 a=[m.start() for m in re.finditer(re.escape(start),text)]
 if not a:continue
 begin=a[-1];end=text.find(stop,begin+len(start));print('\nSECTION',start,'\n',text[begin:end if end>begin else begin+5000][:7000])
for p in (base/'standard/Gating-ML 2.0 Full 20130122/Compliance tests').glob('set */gates*.xml'):
 tree=ET.fromstring(p.read_bytes());print('\nFILE',p.name,'ROOTCHILDREN',len(tree))
 for el in list(tree)[:4]:print(ET.tostring(el,encoding='unicode')[:4000])
