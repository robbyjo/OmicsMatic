# FAIL2 native FRiP validation

AssertionError(('b-fraction-default', 1, 1))

Required action: preserve original outputs and flags. Inspect the named denominator, overlap, reference or read-group discrepancy. No result admitted; never clamp fractions, repair identifiers or substitute source ratios.
