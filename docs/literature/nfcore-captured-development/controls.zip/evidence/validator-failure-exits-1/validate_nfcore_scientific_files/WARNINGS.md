# FAIL2 NO COMPONENT RESULT

AssertionError(('actual-captured-engine', 1, 'Error: Unable to access jarfile /mnt/d/projects/JLinAlg/build/literature-review/nfcore-runtime/validator-failure-exits-1/missing-capture.jar\n'))

Required action: preserve all evidence, inspect the named cause and rerun corrected controls to a new path. Do not shorten data, infer identifiers or weaken verification.
