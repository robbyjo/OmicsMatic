nextflow.enable.dsl=2
params.sheet=null
params.outdir=null
params.fail=false
process READ {
    publishDir params.outdir, mode: 'copy'
    input:
    path sheet
    output:
    path 'observed.txt'
    script:
    if (params.fail) 'exit 7'
    else """
    cat -- "\$(cat -- ${sheet})" > observed.txt
    printf '%s\n' '${task.cpus}' '${task.memory.toMega()}' '${task.time.seconds}' '${params.exact}' >> observed.txt
    """
}
workflow { READ(file(params.sheet, checkIfExists: true)) }
