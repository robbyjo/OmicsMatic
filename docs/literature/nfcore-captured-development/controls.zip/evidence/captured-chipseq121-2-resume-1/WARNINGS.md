# FAIL2_CAPTURED_CHIPSEQ121_DIAGNOSTIC_RESUME

AssertionError()

Required action: Retain prior failed attempts and all raw owned-process observations. This is an explicit monitor-only diagnostic successor with the same captured recipe, software image, biological inputs, scientific defaults and capacities. No nf-core scientific result is admitted until complete original-pipeline and native output contracts pass.
