# FAIL2_CAPTURED_CHIPSEQ121_CONTROL

RuntimeError('Captured Java engine exited 2; inspect retained original logs and latest failure')

Required action: Complete captured-pipeline execution control only. Require the native original-pipeline scientific output audit before nf-core tool admission. Preserve every attempt and original input, image, config, result and warning. SKIP3 means skip dependent analysis until the exact permitted prerequisite is available. FAIL2 means no result admitted: correct the named cause and retry NEW paths; keep scientific defaults and original program bodies intact. The PCR input is explicitly synthetic and provides no independent biological or paper-reproduction validation.
