# Nextflow process FAIL2 failed

java.io.IOException: Owned thread group remains unassessable after one requested polling interval; no live gauge or result admitted

Required action: preserve this directory, stdout, stderr and process ledger. Admit results only after the complete scientific output audit. Correct any failure and rerun to a new output directory.
