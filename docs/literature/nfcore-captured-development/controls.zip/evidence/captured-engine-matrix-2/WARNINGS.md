# FAIL2: nf-core foundation validation failed

AssertionError(('21.04.1', 'success', 'resume', 2))

Required action: No result admitted. Preserve every owned root and report, inspect the named original logs, correct the cause and rerun to NEW output paths. Do not change original software, scientific defaults or admission rules to turn a failed control into a success.
