# FAIL2: nf-core foundation validation failed

AssertionError(('22.10.6', 'success', 'run', 2))

Required action: No result admitted. Preserve every owned root and report, inspect the named original logs, correct the cause and rerun to NEW output paths. Do not change original software, scientific defaults or admission rules to turn a failed control into a success.
