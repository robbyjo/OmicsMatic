"""Resume the unchanged captured request with an explicitly recorded diagnostic monitor successor."""
import hashlib,json,os,signal,subprocess,sys,time,traceback
from pathlib import Path
if sys.platform!='linux':raise SystemExit(subprocess.call(['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/python3','/mnt/d/projects/JLinAlg/build/literature-review/nfcore-runtime/resume_captured_chipseq121_coherent.py']))
root=Path('/mnt/d/projects/JLinAlg');base=root/'build/literature-review/nfcore-runtime';out=base/'captured-chipseq121-3-resume-1';assert not out.exists();out.mkdir()
session=Path('/var/tmp/omicsmatic-nfcore-captured-chipseq121-3/engine');jar=base/'captured-build21-7/nfcore-captured-development.jar'
def pin(p):
 h=hashlib.sha256();size=0
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):size+=len(b);h.update(b)
 return dict(bytes=size,sha256=h.hexdigest())
def save(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
state=dict(status='FAIL2_CAPTURED_CHIPSEQ121_DIAGNOSTIC_RESUME',scientific_result_admitted=False,new_catalog_credit=False);process=None
action='Retain prior failed attempts and all raw owned-process observations. This is an explicit monitor-only diagnostic successor with the same captured recipe, software image, biological inputs, scientific defaults and capacities. No nf-core scientific result is admitted until complete original-pipeline and native output contracts pass.'
try:
 latest=json.loads((session/'latest.json').read_bytes());assert latest['status']=='FAIL2';previous=session/'attempts'/latest['attempt']
 ledger=json.loads((previous/'process/process.json').read_bytes());assert ledger['owned_live_after_cleanup']==[]
 for identity in ledger['owned_processes']:
  stat=Path('/proc')/str(identity['pid'])/'stat'
  try:
   fields=stat.read_text().rsplit(')',1)[1].split()
   assert int(fields[19])!=identity['startTicks'] or fields[0] in ['Z','X','x'],('Owned process remains live',identity['pid'])
  except FileNotFoundError:pass
 immutable=json.loads((base/'captured-chipseq121-3/immutable-before.json').read_bytes());assert all(pin(Path(p))==v for p,v in immutable.items())
 saved={str(p):pin(p) for p in [session/'request.json',previous/'FAILURE.json',previous/'working-after.json']}
 expected=json.loads((jar.parent/'COMPLETED.json').read_bytes())['artifact'];assert pin(jar)=={k:expected[k] for k in ['bytes','sha256']}
 home=root/'build/literature-review/nextflow-runtime/managed-setup-development-1/home-21-v2';report=base/'engine-host-recheck-1/report-21-v2'
 command=['/usr/bin/java','-Xmx1024m','-XX:ActiveProcessorCount=4','-jar',str(jar),'--resume',str(session),'--home',str(home),'--setup-report',str(report)]
 save(out/'invocation.json',dict(command=command,artifact=pin(jar),previous_records=saved,driver_change='Bounded coherent observations within the requested polling interval and identity-only cleanup; owned raw observations and retries retained. No live gauge imputed; original engine/workflow/image/inputs/capacities unchanged.'))
 (out/'helper-at-attempt.py').write_bytes(Path(__file__).read_bytes());(out/'WARNINGS.md').write_text('# RUNNING diagnostic resume; no scientific result admitted\n\nRequired action: '+action+'\n')
 started=time.monotonic()
 with (out/'process.stdout').open('xb') as so,(out/'process.stderr').open('xb') as se:
  process=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=so,stderr=se,start_new_session=True)
  save(out/'RUNNING.json',dict(pid=process.pid,process_start_ticks=Path('/proc') .joinpath(str(process.pid),'stat').read_text().rsplit(')',1)[1].split()[19]))
  code=process.wait(timeout=14400)
 save(out/'process.json',dict(exit_code=code,elapsed_seconds=time.monotonic()-started));assert all(pin(Path(p))==v for p,v in saved.items())
 assert all(pin(Path(p))==v for p,v in immutable.items())
 if code:raise RuntimeError('Diagnostic captured resume exited '+str(code)+'; inspect complete owned-process raw readings and latest failure')
 state.update(status='PASS_CAPTURED_CHIPSEQ121_RESUME_EXECUTION_ONLY',session=str(session),further_native_scientific_audit_required=True)
except Exception as error:state.update(cause=repr(error),traceback=traceback.format_exc())
finally:
 if process is not None and process.poll() is None:
  os.killpg(process.pid,signal.SIGTERM)
  try:process.wait(timeout=30)
  except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=30)
state['required_action']=action;save(out/'COMPLETED.json',state);(out/'WARNINGS.md').write_text('# '+state['status']+'\n\n'+state.get('cause','Execution control only; native scientific output audit pending.')+'\n\nRequired action: '+action+'\n');print(state['status'],state.get('cause',''),flush=True);raise SystemExit(0 if state['status'].startswith('PASS_') else 2)
