# PASS_CAPTURED_CHIPSEQ121_RESUME_EXECUTION_ONLY

Execution control only; native scientific output audit pending.

Required action: Retain prior failed attempts and all raw owned-process observations. This is an explicit monitor-only diagnostic successor with the same captured recipe, software image, biological inputs, scientific defaults and capacities. No nf-core scientific result is admitted until complete original-pipeline and native output contracts pass.
