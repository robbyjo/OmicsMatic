# FAIL2 no component result admitted

java.io.IOException: Required declared input member is missing: r0/materialized/workflow-α's data/.gitattributes

Required action: this is a native component audit, with no nf-core tool or biological admission. Require the complete original pipeline/runtime/scientific contracts before downstream claims. Preserve original outputs, IDs, flags, failures and source numeric tokens. FAIL2 means the named contract is incomplete or inconsistent; no component result admitted. Correct the named cause and use a new audit path. Hashes establish integrity, not authenticity. Cell Ranger remains excluded.
