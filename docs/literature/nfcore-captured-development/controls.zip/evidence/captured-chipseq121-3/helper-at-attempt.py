"""Execute the complete original ChIP-seq121 PCR control through the frozen Java capture/process engine."""
import hashlib,json,os,shutil,signal,subprocess,sys,time,traceback
from pathlib import Path
if sys.platform!='linux':raise SystemExit(subprocess.call(['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/python3','/mnt/d/projects/JLinAlg/build/literature-review/nfcore-runtime/run_captured_chipseq121_v3.py']))
root=Path('/mnt/d/projects/JLinAlg');base=root/'build/literature-review/nfcore-runtime';out=base/'captured-chipseq121-3';assert not out.exists();out.mkdir()
owned=Path('/var/tmp/omicsmatic-nfcore-captured-chipseq121-3');assert not owned.exists();owned.mkdir();materialized=owned/'materialized';materialized.mkdir();session=owned/'engine'
source=Path('/var/tmp/omicsmatic-nfcore-sources-1/chipseq-1.2.1');original_data=Path('/var/tmp/omicsmatic-nfcore-chipseq121-controls-1');pcr_data=Path('/var/tmp/omicsmatic-nfcore-chipseq121-pcr-controls-1');apptainer=Path('/var/tmp/omicsmatic-nfcore-apptainer-1');image=Path('/var/tmp/omicsmatic-nfcore-images-1/nfcore-chipseq-1.2.1.sif')
def pin(p):
 h=hashlib.sha256();size=0
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b);size+=len(b)
 return dict(bytes=size,sha256=h.hexdigest())
def save(p,d):p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf8',newline='\n')
jar=base/'captured-build21-6/nfcore-captured-development.jar';build=json.loads((jar.parent/'COMPLETED.json').read_bytes());assert pin(jar)=={k:build['artifact'][k] for k in ['bytes','sha256']}
state=dict(status='FAIL2_CAPTURED_CHIPSEQ121_CONTROL',scientific_result_admitted=False,new_catalog_credit=False,owned_linux_root=str(owned))
action='Complete captured-pipeline execution control only. Require the native original-pipeline scientific output audit before nf-core tool admission. Preserve every attempt and original input, image, config, result and warning. SKIP3 means skip dependent analysis until the exact permitted prerequisite is available. FAIL2 means no result admitted: correct the named cause and retry NEW paths; keep scientific defaults and original program bodies intact. The PCR input is explicitly synthetic and provides no independent biological or paper-reproduction validation.'
process=None
try:
 before={str(p):pin(p) for directory in [source,original_data,pcr_data,apptainer] for p in directory.rglob('*') if p.is_file() and not p.is_symlink()};before[str(image)]=pin(image)
 save(out/'immutable-before.json',before)
 shutil.copytree(source,materialized/'workflow');shutil.copytree(original_data/'external-configs',materialized/'external-configs');shutil.copytree(original_data/'reference',materialized/'reference');shutil.copytree(pcr_data/'reads',materialized/'reads')
 (materialized/'original-design.csv').write_bytes((original_data/'original-design.csv').read_bytes())
 (materialized/'pcr-source-design.csv').write_bytes((pcr_data/'local-design.csv').read_bytes())
 # Only the two path cells change. Identifiers, row order and non-path fields remain literal.
 lines=(pcr_data/'local-design.csv').read_text().splitlines();derived=[lines[0]];mapping=[]
 assert lines[0]=='group,replicate,fastq_1,fastq_2,antibody,control' and len(lines)==7
 for line in lines[1:]:
  cells=line.split(',');assert len(cells)==6;original=list(cells)
  for index in [2,3]:
   path=Path(cells[index]);assert path.parent==pcr_data/'reads' and ',' not in path.name
   cells[index]=str(session/'workspace/resources/r0/materialized/reads'/path.name)
  assert [cells[i] for i in [0,1,4,5]]==[original[i] for i in [0,1,4,5]]
  derived.append(','.join(cells));mapping.append(dict(original=original,derived=cells))
 (materialized/'design.csv').write_text('\n'.join(derived)+'\n',encoding='utf8',newline='\n');save(out/'path-bindings.json',mapping)
 (materialized/'workflow/runtime').mkdir()
 overlay="process.container = '"+str(image)+"'\nexecutor.cpus = 4\nexecutor.memory = '24.GB'\nsingularity.cacheDir = '"+str(session/'workspace/execution/container-cache')+"'\nsingularity.autoMounts = true\n"
 (materialized/'workflow/runtime/host.config').write_text(overlay)
 assert all(pin(materialized/'workflow'/p.relative_to(source))==pin(p) for p in source.rglob('*') if p.is_file())
 golden=json.loads((base/'original-chipseq121-3-audit-1/outputs-inventory.json').read_bytes())
 outputs=[dict(path=n,kind='file',allow_empty=v['bytes']==0) for n,v in golden.items() if v['kind']=='file'];assert len(outputs)==367
 recipe=dict(schema_version=1,engine_profile='linux-x86_64-nextflow-21.04.1',workflow=dict(path=str(materialized/'workflow'),entrypoint='main.nf',configs=['nextflow.config','runtime/host.config'],profiles=['singularity']),
  resources={name:dict(path=str(path)) for name,path in dict(bundle=materialized,design=materialized/'design.csv',fasta=materialized/'reference/genome.fa',gtf=materialized/'reference/genes.gtf',external_configs=materialized/'external-configs').items()},
  parameters=dict(input={'$input':'design'},fasta={'$input':'fasta'},gtf={'$input':'gtf'},custom_config_base={'$input':'external_configs'},outdir={'$output':''},tracedir={'$output':'pipeline_info'},macs_gsize=1.2e7,max_cpus=4,max_memory='8.GB',max_time='2.h'),
  required_tools=[dict(name='singularity',path=str(apptainer/'bin/singularity'))],outputs=outputs,require_tasks=True,
  limits=dict(wall_seconds=7200,cpu_seconds=7200,address_space_bytes=68719476736,workspace_bytes=274877906944,processes=512,threads=16384,sampled_rss_bytes=34359738368,java_heap_mib=2048,java_cpus=4,poll_millis=500,metadata_bytes=67108864))
 save(out/'recipe.json',recipe);(out/'helper-at-attempt.py').write_bytes(Path(__file__).read_bytes())
 engine=root/'build/literature-review/nextflow-runtime/managed-setup-development-1/home-21-v2';report=base/'engine-host-recheck-1/report-21-v2'
 command=['/usr/bin/java','-Xmx1024m','-XX:ActiveProcessorCount=4','-jar',str(jar),'--recipe',str(out/'recipe.json'),'--home',str(engine),'--setup-report',str(report),'--out',str(session)]
 save(out/'invocation.json',dict(command=command,artifact=pin(jar),original_source_bodies_modified=False,source_config_extra='runtime/host.config contains only pinned software/resource bindings',default_fingerprint_bins=500000,source_derived_tracedir_binding='${outdir}/pipeline_info',PCR_control_derivative=True,all_original_reads_retained=True))
 (out/'WARNINGS.md').write_text('# RUNNING captured original ChIP-seq121 control; no scientific result admitted\n\nRequired action: '+action+'\n')
 started=time.monotonic()
 with (out/'process.stdout').open('xb') as so,(out/'process.stderr').open('xb') as se:
  process=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=so,stderr=se,start_new_session=True)
  save(out/'RUNNING.json',dict(pid=process.pid,process_start_ticks=Path('/proc/'+str(process.pid)+'/stat').read_text().rsplit(')',1)[1].split()[19],command=command))
  code=process.wait(timeout=14400)
 save(out/'process.json',dict(exit_code=code,elapsed_seconds=time.monotonic()-started))
 assert all(pin(Path(p))==v for p,v in before.items()),'Original source/data/software/image changed'
 if code:raise RuntimeError('Captured Java engine exited '+str(code)+'; inspect retained original logs and latest failure')
 verified=subprocess.run(['/usr/bin/java','-Xmx512m','-jar',str(jar),'--verify',str(session)],capture_output=True,timeout=600)
 (out/'verify.stdout').write_bytes(verified.stdout);(out/'verify.stderr').write_bytes(verified.stderr);assert verified.returncode==0
 latest=json.loads((session/'latest.json').read_bytes());attempt=session/'attempts'/latest['attempt'];assert latest['status']=='COMPLETED'
 state.update(status='PASS_CAPTURED_ORIGINAL_CHIPSEQ121_CONTROL_EXECUTION_ONLY',attempt=str(attempt),further_native_scientific_audit_required=True,elapsed_seconds=time.monotonic()-started,declared_expected_files=367)
except Exception as error:state.update(cause=repr(error),traceback=traceback.format_exc())
finally:
 if process is not None and process.poll() is None:
  os.killpg(process.pid,signal.SIGTERM)
  try:process.wait(timeout=30)
  except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=30)
state['required_action']=action;save(out/'COMPLETED.json',state);(out/'WARNINGS.md').write_text('# '+state['status']+'\n\n'+state.get('cause','Captured execution only; complete native scientific output and tool admission remain pending.')+'\n\nRequired action: '+action+'\n')
print(state['status'],state.get('cause',''),flush=True);raise SystemExit(0 if state['status'].startswith('PASS_') else 2)
