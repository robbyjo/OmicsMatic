# ORIGINAL PLINK ASSOCIATION FAILED

java.io.IOException: Phenotype does not match --binary-coding at Id[fid=F000, iid=S003]



Required action: inspect WARNINGS.md, sample-ledger.tsv, session.yaml and retained upstream logs. Correct the named inputs, model/coding, covariates or resource limit, then rerun to a new output directory. Original ERRCODE/NA rows are unreportable; finite provisional estimates never override an error. Do not treat blank estimates or P-values as zero. No population structure, relatedness or other confounding adjustment is inferred. Where permitted run python tools/literature/install_plink.py --home NEW_PRIVATE_HOME --allow-install; add --allow-download only for permitted missing downloads. Supply that sealed home using --home or JLINALG_PLINK_HOME. Missing, changed, unsupported or forbidden dependencies skip the original analysis with exit 3. Preserve diagnostics and changed homes; use a new path rather than re-sealing a changed binary. A version probe is not scientific validation.
