# ORIGINAL PLINK ASSOCIATION WARNINGS

2 regression rows are UNREPORTABLE. Canonical numeric estimates are blank; raw original fields remain in upstream\result.TRAIT.glm.linear. Required action: inspect upstream_error/NA, convergence, genotype counts, separation and model rank before any downstream inference.

Genome build was explicitly unspecified. Required action: establish assembly and variant provenance before genomic interpretation; this workflow does not validate the reference genome.
