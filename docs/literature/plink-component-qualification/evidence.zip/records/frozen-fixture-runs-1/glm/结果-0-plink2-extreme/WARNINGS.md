# ORIGINAL PLINK ASSOCIATION WARNINGS

1 rows retain P-value resolution only in negative_log10_p; p is blank. Required action: use the log field and original textual report for comparisons; never turn the blank into zero.

Genome build was explicitly unspecified. Required action: establish assembly and variant provenance before genomic interpretation; this workflow does not validate the reference genome.
