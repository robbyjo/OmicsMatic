# ORIGINAL PLINK ASSOCIATION WARNINGS

Original PLINK1 did not report standard errors for 96 rows. Required action: request --confidence-level (for example 0.95) to obtain original reported SE before SE-dependent meta-analysis; no SE is reconstructed from rounded beta/statistic fields.

Original plink1 emitted warnings in upstream/glm.stderr. Required action: read that complete retained file before interpreting the analysis.

Original plink1 emitted warnings in upstream/result.log. Required action: read that complete retained file before interpreting the analysis.

Genome build was explicitly unspecified. Required action: establish assembly and variant provenance before genomic interpretation; this workflow does not validate the reference genome.

Only an intercept and additive genotype were fitted. Required action: justify the explicit --covariates none choice and assess population structure, relatedness and confounding before inference.
