# ORIGINAL PLINK ASSOCIATION WARNINGS

2 regression rows are UNREPORTABLE. Canonical numeric estimates are blank; raw original fields remain in upstream\result.assoc.linear. Required action: inspect upstream_error/NA, convergence, genotype counts, separation and model rank before any downstream inference.

Original PLINK1 did not report standard errors for 94 rows. Required action: request --confidence-level (for example 0.95) to obtain original reported SE before SE-dependent meta-analysis; no SE is reconstructed from rounded beta/statistic fields.

Original plink1 emitted warnings in upstream/glm.stderr. Required action: read that complete retained file before interpreting the analysis.

Original plink1 emitted warnings in upstream/result.log. Required action: read that complete retained file before interpreting the analysis.

Genome build was explicitly unspecified. Required action: establish assembly and variant provenance before genomic interpretation; this workflow does not validate the reference genome.
