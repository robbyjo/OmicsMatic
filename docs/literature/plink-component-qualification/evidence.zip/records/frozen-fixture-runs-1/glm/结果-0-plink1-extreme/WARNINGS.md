# ORIGINAL PLINK ASSOCIATION WARNINGS

1 original P-values were printed as zero and have no resolved log P-value. Required action: obtain an original report with adequate log-P resolution; do not assign a floor or infer significance from an invented zero.

Original PLINK1 did not report standard errors for 95 rows. Required action: request --confidence-level (for example 0.95) to obtain original reported SE before SE-dependent meta-analysis; no SE is reconstructed from rounded beta/statistic fields.

Original plink1 emitted warnings in upstream/glm.stderr. Required action: read that complete retained file before interpreting the analysis.

Original plink1 emitted warnings in upstream/result.log. Required action: read that complete retained file before interpreting the analysis.

Genome build was explicitly unspecified. Required action: establish assembly and variant provenance before genomic interpretation; this workflow does not validate the reference genome.
