# ORIGINAL PLINK ASSOCIATION WARNINGS

Original PLINK1 did not report standard errors for 96 rows. Required action: request --confidence-level (for example 0.95) to obtain original reported SE before SE-dependent meta-analysis; no SE is reconstructed from rounded beta/statistic fields.

Genome build was explicitly unspecified. Required action: establish assembly and variant provenance before genomic interpretation; this workflow does not validate the reference genome.
