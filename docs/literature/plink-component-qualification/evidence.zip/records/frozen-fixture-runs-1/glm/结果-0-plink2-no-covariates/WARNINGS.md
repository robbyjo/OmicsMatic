# ORIGINAL PLINK ASSOCIATION WARNINGS

Genome build was explicitly unspecified. Required action: establish assembly and variant provenance before genomic interpretation; this workflow does not validate the reference genome.

Only an intercept and additive genotype were fitted. Required action: justify the explicit --covariates none choice and assess population structure, relatedness and confounding before inference.
