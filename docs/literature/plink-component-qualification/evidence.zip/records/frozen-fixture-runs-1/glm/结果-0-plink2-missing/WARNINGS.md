# ORIGINAL PLINK ASSOCIATION WARNINGS

2 samples were explicitly excluded for missing phenotype/covariates; inspect sample-ledger.tsv. Required action: assess selection bias and cohort eligibility. Per-variant missing genotypes further reduce n without imputation.

Genome build was explicitly unspecified. Required action: establish assembly and variant provenance before genomic interpretation; this workflow does not validate the reference genome.
