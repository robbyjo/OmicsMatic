# ORIGINAL PLINK ASSOCIATION WARNINGS

1 regression rows are UNREPORTABLE. Canonical numeric estimates are blank; raw original fields remain in upstream\result.TRAIT.glm.logistic. Required action: inspect upstream_error/NA, convergence, genotype counts, separation and model rank before any downstream inference.

Original plink2 emitted warnings in upstream/glm.stderr. Required action: read that complete retained file before interpreting the analysis.

Original plink2 emitted warnings in upstream/result.log. Required action: read that complete retained file before interpreting the analysis.

Genome build was explicitly unspecified. Required action: establish assembly and variant provenance before genomic interpretation; this workflow does not validate the reference genome.
