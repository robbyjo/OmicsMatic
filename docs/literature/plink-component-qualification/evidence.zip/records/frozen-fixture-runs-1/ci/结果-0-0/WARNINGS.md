# ORIGINAL PLINK ASSOCIATION WARNINGS

Original plink1 emitted warnings in upstream/glm.stderr. Required action: read that complete retained file before interpreting the analysis.

Original plink1 emitted warnings in upstream/result.log. Required action: read that complete retained file before interpreting the analysis.

Genome build was explicitly unspecified. Required action: establish assembly and variant provenance before genomic interpretation; this workflow does not validate the reference genome.
