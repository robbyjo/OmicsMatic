# ORIGINAL PLINK ASSOCIATION WARNINGS

Genome build was explicitly unspecified. Required action: establish assembly and variant provenance before genomic interpretation; this workflow does not validate the reference genome.
