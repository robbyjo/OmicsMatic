# ORIGINAL LD PRUNING WARNINGS

5 reference genotype cells are missing under --missing-genotypes upstream. Required action: review variant-reference.tsv and the selected original version's unphased-hard-call pruning behavior. Marginal variable-call checks do not establish reportability of every pair or a global independence guarantee;no native imputation was applied.

Genome build is unspecified. Required action: establish assembly/coordinate provenance before genomic interpretation;the window uses the supplied BIM bp coordinates.

Initial sample include/autosome/unresolved-allele policies excluded source rows before pruning. Required action: inspect sample-reference.tsv and variant-decisions.tsv;those exclusions are distinct from the original LD-pruned family.
