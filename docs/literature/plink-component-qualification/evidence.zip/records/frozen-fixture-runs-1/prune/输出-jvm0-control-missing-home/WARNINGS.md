# ORIGINAL LD PRUNING SKIPPED

org.jlinalg.cli.PlinkRuntime$Unavailable: Original PLINK dependency unavailable or changed: Missing, linked or escaping original runtime member: .jlinalg-plink.json



Required action: read WARNINGS.md, session.yaml, variant-reference.tsv and original upstream logs. Correct the named input, reference population, window units/order, minimum call count or resource bound, then rerun to a new output directory. Resolve nonvariable/unobserved markers with a reviewed QC workflow. No filter, threshold or --bad-ld override is inferred. Where permitted run python tools/literature/install_plink.py --home NEW_PRIVATE_HOME --allow-install; add --allow-download only for permitted missing downloads. Supply that sealed home using --home or JLINALG_PLINK_HOME. Missing, changed, unsupported or forbidden dependencies skip the original analysis with exit 3. Preserve diagnostics and changed homes; use a new path rather than re-sealing a changed binary. A version probe is not scientific validation.
