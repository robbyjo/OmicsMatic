# ORIGINAL PCA SKIPPED

org.jlinalg.cli.PlinkRuntime$Unavailable: Original PLINK dependency unavailable or changed: Missing, linked or escaping original runtime member: .jlinalg-plink.json



Required action: read WARNINGS.md,session.yaml,variant-reference.tsv,eigen-quality.tsv when present,and retained upstream logs. Correct the named panel,independent sample masks,component count,explicit approximation tolerance or resource limits;rerun to a new directory. Review low-frequency markers with a declared QC/panel selection;this command never adds --grm-maf yes-really/--bad-freqs,changes the algorithm or silently removes markers. Where permitted run python tools/literature/install_plink.py --home NEW_PRIVATE_HOME --allow-install; add --allow-download only for permitted missing downloads. Supply that sealed home using --home or JLINALG_PLINK_HOME. Missing, changed, unsupported or forbidden dependencies skip the original analysis with exit 3. Preserve diagnostics and changed homes; use a new path rather than re-sealing a changed binary. A version probe is not scientific validation.
