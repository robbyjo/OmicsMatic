# PACKAGED CI VALIDATION FAILED

AssertionError()

Required action: inspect verification.json and retained API/GLM stdout, stderr and analysis warnings. Correct the cause and rerun to a new --work directory; failed validation does not establish a working implementation.
