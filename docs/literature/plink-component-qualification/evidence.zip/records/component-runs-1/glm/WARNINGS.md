# PLINK PACKAGED VALIDATION FAILED

AssertionError('known.bim')

Required action: inspect verification.json and retained per-call stdout/stderr and analysis warnings. Correct the cause, then rerun to a new --work directory. Failed validation is not evidence of a working adapter.
