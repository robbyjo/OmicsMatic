# PACKAGED PRUNING VALIDATION FAILED

AssertionError('cases.tsv')

Required action: inspect verification.json,producer snapshot,recipes,stdout/stderr and original upstream reports. Identify the input,verifier,adapter or original-program cause;correct it and rerun to a new work directory. This failed attempt does not establish a working implementation.
