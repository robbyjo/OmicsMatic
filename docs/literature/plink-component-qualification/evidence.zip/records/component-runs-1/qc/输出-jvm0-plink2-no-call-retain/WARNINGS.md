# ORIGINAL GENOTYPE QC WARNINGS

Decision-stage HWE has 1 unreportable markers retained under the explicit policy. Required action: inspect reference-cohort call counts and allele metadata;do not interpret a zero-call original P=1 as a tested equilibrium result. Original masks are still respected.

Final HWE has 1 unreportable markers retained under the explicit policy. Required action: inspect reference-cohort call counts and allele metadata;do not interpret a zero-call original P=1 as a tested equilibrium result. Original masks are still respected.

Genome build is explicitly unspecified. Required action: establish assembly/coordinate provenance before genomic interpretation;this workflow validates genotype/identity preservation,not a reference assembly.

Initial policy excluded 1 samples and 2 variants before genotype QC. Required action: inspect the explicit sample include flags,autosome scope and unresolved-allele policy in the decision tables;these exclusions are not downstream HWE/MAF failures.
