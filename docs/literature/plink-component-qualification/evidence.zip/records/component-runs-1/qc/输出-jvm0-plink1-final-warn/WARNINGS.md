# ORIGINAL GENOTYPE QC WARNINGS

One-pass QC retained 1 samples and 0 variants failing final-cohort criteria,as permitted by --final-check warn. Required action: review final-threshold-violations.tsv and the declared operation order;use --final-check fail or an explicitly justified additional QC pass before claiming all final thresholds are met. No threshold was relaxed automatically.

Genome build is explicitly unspecified. Required action: establish assembly/coordinate provenance before genomic interpretation;this workflow validates genotype/identity preservation,not a reference assembly.

Initial policy excluded 1 samples and 2 variants before genotype QC. Required action: inspect the explicit sample include flags,autosome scope and unresolved-allele policy in the decision tables;these exclusions are not downstream HWE/MAF failures.
