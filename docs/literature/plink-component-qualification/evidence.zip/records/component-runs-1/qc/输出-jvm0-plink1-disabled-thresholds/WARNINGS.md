# ORIGINAL GENOTYPE QC WARNINGS

1 retained variants have unresolved allele labels under the explicit retain-with-warning policy. Required action: resolve their allele metadata before genetic-effect interpretation;raw call preservation does not establish allele identity.

1 retained markers have no observed calls. Required action: exclude or replace them before analyses requiring observed genotype information;they are not evidence of HWE or absence of variation.

Genome build is explicitly unspecified. Required action: establish assembly/coordinate provenance before genomic interpretation;this workflow validates genotype/identity preservation,not a reference assembly.

Initial policy excluded 1 samples and 1 variants before genotype QC. Required action: inspect the explicit sample include flags,autosome scope and unresolved-allele policy in the decision tables;these exclusions are not downstream HWE/MAF failures.
