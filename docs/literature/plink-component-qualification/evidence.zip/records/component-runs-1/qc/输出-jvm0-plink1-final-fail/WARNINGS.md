# ORIGINAL GENOTYPE QC FAILED

java.io.IOException: One-pass QC retained individuals/variants which fail final-cohort criteria;see final-threshold-violations.tsv. No filtered genotype set was published



Required action: inspect WARNINGS.md, session.yaml, sample-decisions.tsv, variant-decisions.tsv, final-threshold-violations.tsv and retained upstream logs. Correct the named input, explicit reference population, threshold, operation order or resource bound and rerun to a new output directory. No threshold or statistic is relaxed automatically. Failed filtered genotype files are quarantined under partial/. Where permitted run python tools/literature/install_plink.py --home NEW_PRIVATE_HOME --allow-install; add --allow-download only for permitted missing downloads. Supply that sealed home using --home or JLINALG_PLINK_HOME. Missing, changed, unsupported or forbidden dependencies skip the original analysis with exit 3. Preserve diagnostics and changed homes; use a new path rather than re-sealing a changed binary. A version probe is not scientific validation.
