# GENOTYPE SCORING FAILED

java.io.IOException: No sample has a reportable score after omission

Genome build is explicitly unspecified. Required action: verify model/genotype variant identity and assembly provenance before genomic interpretation. Exact ID/allele matching does not validate coordinates or perform liftOver.

Explicit omission excluded 104 missing variant contributions and their denominator alleles. Required action: review sample-specific denominators; these averages differ from mean-imputed averages and sums are not zero-imputed complete models.

13 samples have no observed scored dosages. Sum/average fields are blank, not zero. Required action: provide valid genotypes or a scientifically justified explicit mean-imputation model before using those samples.

Required action: correct the named input, allele pair, declared missing policy or explicit resource limit and rerun to a new writable output directory. Preserve the original files. Native scoring needs only Java and never installs software. Supply a variant-major BED/BIM/FAM set with exact unique FID/IID pairs and one resolved biallelic record for every model variant. Only human diploid autosomal hard calls are supported by this command. Mean imputation requires supplied effect-allele frequencies; target-cohort frequencies are not estimated implicitly. Failed scientific streams are quarantined under partial/.
