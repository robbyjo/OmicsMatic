# GENOTYPE SCORE WARNINGS

Genome build is explicitly unspecified. Required action: verify model/genotype variant identity and assembly provenance before genomic interpretation. Exact ID/allele matching does not validate coordinates or perform liftOver.

Explicit omission excluded 85 missing variant contributions and their denominator alleles. Required action: review sample-specific denominators; these averages differ from mean-imputed averages and sums are not zero-imputed complete models.

1 samples have no observed scored dosages. Sum/average fields are blank, not zero. Required action: provide valid genotypes or a scientifically justified explicit mean-imputation model before using those samples.
