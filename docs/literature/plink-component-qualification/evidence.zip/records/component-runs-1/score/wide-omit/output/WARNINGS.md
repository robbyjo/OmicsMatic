# GENOTYPE SCORE WARNINGS

Genome build is explicitly unspecified. Required action: verify model/genotype variant identity and assembly provenance before genomic interpretation. Exact ID/allele matching does not validate coordinates or perform liftOver.

Explicit omission excluded 1327 missing variant contributions and their denominator alleles. Required action: review sample-specific denominators; these averages differ from mean-imputed averages and sums are not zero-imputed complete models.
