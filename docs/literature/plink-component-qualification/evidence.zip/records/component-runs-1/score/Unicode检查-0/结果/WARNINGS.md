# GENOTYPE SCORE WARNINGS

Genome build is explicitly unspecified. Required action: verify model/genotype variant identity and assembly provenance before genomic interpretation. Exact ID/allele matching does not validate coordinates or perform liftOver.
