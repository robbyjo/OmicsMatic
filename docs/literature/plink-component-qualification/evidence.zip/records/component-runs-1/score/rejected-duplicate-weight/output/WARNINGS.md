# GENOTYPE SCORING FAILED

java.io.IOException: Duplicate weight variant ID: rs10000



Required action: correct the named input, allele pair, declared missing policy or explicit resource limit and rerun to a new writable output directory. Preserve the original files. Native scoring needs only Java and never installs software. Supply a variant-major BED/BIM/FAM set with exact unique FID/IID pairs and one resolved biallelic record for every model variant. Only human diploid autosomal hard calls are supported by this command. Mean imputation requires supplied effect-allele frequencies; target-cohort frequencies are not estimated implicitly. Failed scientific streams are quarantined under partial/.
