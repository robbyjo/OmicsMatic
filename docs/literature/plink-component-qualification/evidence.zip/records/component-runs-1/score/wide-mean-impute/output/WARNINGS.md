# GENOTYPE SCORE WARNINGS

Genome build is explicitly unspecified. Required action: verify model/genotype variant identity and assembly provenance before genomic interpretation. Exact ID/allele matching does not validate coordinates or perform liftOver.

Explicit mean imputation replaced 1327 missing dosages using supplied effect-allele frequencies. Required action: verify that frequency panel and model eligibility. Observed alleles differ from the average denominator, which includes imputed variants.
