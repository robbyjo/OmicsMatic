/*
 * Copyright (C) 2026 JLinAlg contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
package org.jlinalg.genetics;

import java.io.BufferedReader;
import java.io.EOFException;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Greedy PLINK-style clumping over a variant-major PLINK 1 BED reference.
 *
 * <p>Pairwise LD is the unphased maximum-likelihood haplotype r-squared used
 * by PLINK's {@code --clump}, evaluated over founders with nonmissing calls.
 * Index variants are considered by ascending p-value independently per
 * group.</p>
 */
public final class PlinkBedLdClumper {
    private static final byte[] BED_HEADER = {
        (byte) 0x6c, (byte) 0x1b, (byte) 0x01};

    private PlinkBedLdClumper() { }

    /** A1-dosage Pearson LD with mean-imputed missing calls among founders. */
    public record SignedLd(List<String> variants, List<String> chromosomes,
            List<Long> positions, List<String> effectAlleles, List<String> otherAlleles,
            double[][] correlation, int founders) {
        public SignedLd {
            variants = List.copyOf(variants); chromosomes = List.copyOf(chromosomes);
            positions = List.copyOf(positions); effectAlleles = List.copyOf(effectAlleles);
            otherAlleles = List.copyOf(otherAlleles);
            correlation = Arrays.stream(correlation).map(double[]::clone).toArray(double[][]::new);
        }
        @Override public double[][] correlation() { return Arrays.stream(correlation).map(double[]::clone).toArray(double[][]::new); }
    }

    /** Extracts signed genotype correlation, not haplotype r-squared used by clump. */
    public static SignedLd signedCorrelation(Path prefix, List<String> variants) throws IOException {
        if (variants.isEmpty() || variants.size() > 5000 || new HashSet<>(variants).size() != variants.size())
            throw new IllegalArgumentException("Signed LD requires 1-5000 unique variant IDs");
        Reference reference = Reference.open(prefix, new HashSet<>(variants));
        int founders = 0;
        for (boolean founder : reference.founders()) if (founder) founders++;
        if (founders < 3) throw new IOException("At least three reference founders are required");
        double[][] standardized = new double[variants.size()][founders];
        List<String> chromosomes = new ArrayList<>(), effect = new ArrayList<>(), other = new ArrayList<>();
        List<Long> positions = new ArrayList<>();
        try (FileChannel bed = reference.openBed()) {
            for (int index = 0; index < variants.size(); index++) {
                Variant variant = reference.variants().get(variants.get(index));
                if (variant == null) throw new IOException("Variant absent from reference: " + variants.get(index));
                chromosomes.add(variant.chromosome()); positions.add(variant.position());
                effect.add(variant.effectAllele()); other.add(variant.otherAllele());
                byte[] genotypes = reference.readGenotypes(bed, variant.bedIndex());
                double total = 0; int observed = 0;
                for (int sample = 0; sample < genotypes.length; sample++)
                    if (reference.founders()[sample] && genotypes[sample] >= 0) { total += genotypes[sample]; observed++; }
                if (observed < Math.max(3, (int) Math.ceil(founders * 0.95))) throw new IOException("Reference call rate below 95% for " + variant.id());
                double mean = total / observed, sumSquares = 0;
                int next = 0;
                for (int sample = 0; sample < genotypes.length; sample++) if (reference.founders()[sample]) {
                    double centered = genotypes[sample] < 0 ? 0 : genotypes[sample] - mean;
                    standardized[index][next++] = centered;
                    sumSquares += centered * centered;
                }
                if (!(sumSquares > 0)) throw new IOException("Monomorphic reference variant: " + variant.id());
                double norm = Math.sqrt(sumSquares);
                for (int sample = 0; sample < founders; sample++) standardized[index][sample] /= norm;
            }
        }
        double[][] correlation = new double[variants.size()][variants.size()];
        for (int i = 0; i < variants.size(); i++) {
            correlation[i][i] = 1;
            for (int j = 0; j < i; j++) {
                double dot = 0;
                for (int sample = 0; sample < founders; sample++) dot += standardized[i][sample] * standardized[j][sample];
                correlation[i][j] = correlation[j][i] = Math.max(-1, Math.min(1, dot));
            }
        }
        return new SignedLd(variants, chromosomes, positions, effect, other, correlation, founders);
    }

    /**
     * Clumps unique group/variant candidates against a PLINK fileset prefix.
     *
     * @param plinkPrefix path without {@code .bed/.bim/.fam}
     * @param candidates candidate variants in their desired output order
     * @param options clumping thresholds
     * @return retained variants and exclusions
     * @throws IOException when the reference is malformed or unreadable
     */
    public static LdClumpResult clump(Path plinkPrefix,
            List<LdClumpCandidate> candidates, LdClumpOptions options)
            throws IOException {
        if (plinkPrefix == null) throw new NullPointerException("plinkPrefix");
        if (candidates == null) throw new NullPointerException("candidates");
        if (options == null) throw new NullPointerException("options");
        validateUnique(candidates);
        Reference reference = Reference.open(plinkPrefix,
            candidates.stream().map(LdClumpCandidate::variantId)
                .collect(java.util.stream.Collectors.toSet()));
        Map<String, List<IndexedCandidate>> groups = new LinkedHashMap<>();
        for (int index = 0; index < candidates.size(); index++) {
            LdClumpCandidate candidate = candidates.get(index);
            groups.computeIfAbsent(candidate.group(), ignored -> new ArrayList<>())
                .add(new IndexedCandidate(candidate, index));
        }

        Set<Integer> retainedIndexes = new HashSet<>();
        List<IndexedExclusion> exclusions = new ArrayList<>();
        try (FileChannel bed = reference.openBed()) {
            Map<Long, byte[]> genotypes = new HashMap<>();
            for (List<IndexedCandidate> group : groups.values())
                clumpGroup(group, reference, bed, genotypes, options,
                    retainedIndexes, exclusions);
        }

        List<LdClumpCandidate> retained = new ArrayList<>();
        for (int index = 0; index < candidates.size(); index++)
            if (retainedIndexes.contains(index)) retained.add(candidates.get(index));
        exclusions.sort(Comparator.comparingInt(IndexedExclusion::index));
        return new LdClumpResult(retained, exclusions.stream()
            .map(IndexedExclusion::exclusion).toList());
    }

    private static void clumpGroup(List<IndexedCandidate> group,
            Reference reference, FileChannel bed, Map<Long, byte[]> genotypes,
            LdClumpOptions options, Set<Integer> retained,
            List<IndexedExclusion> exclusions) throws IOException {
        // ieugwasr::ld_clump() returns a one-row group without consulting PLINK.
        if (group.size() == 1) {
            retained.add(group.get(0).index());
            return;
        }
        List<IndexedCandidate> ordered = new ArrayList<>();
        for (IndexedCandidate indexed : group) {
            Variant variant = reference.variants().get(
                indexed.candidate().variantId());
            if (variant == null) {
                exclusions.add(new IndexedExclusion(indexed.index(),
                    new LdClumpExclusion(indexed.candidate(),
                        LdClumpExclusionReason.ABSENT_FROM_REFERENCE,
                        null, Double.NaN)));
            } else if (indexed.candidate().pValue()
                    > options.indexPValueThreshold()) {
                exclusions.add(new IndexedExclusion(indexed.index(),
                    new LdClumpExclusion(indexed.candidate(),
                        LdClumpExclusionReason.ABOVE_INDEX_P_VALUE_THRESHOLD,
                        null, Double.NaN)));
            } else ordered.add(indexed);
        }
        ordered.sort(Comparator
            .comparingDouble((IndexedCandidate value) ->
                value.candidate().pValue())
            .thenComparingInt(IndexedCandidate::index));
        Set<String> assigned = new LinkedHashSet<>();
        long windowBases = Math.multiplyExact(
            (long) options.windowKilobases(), 1_000L);
        for (int index = 0; index < ordered.size(); index++) {
            IndexedCandidate lead = ordered.get(index);
            if (!assigned.add(lead.candidate().variantId())) continue;
            retained.add(lead.index());
            Variant leadVariant = reference.variants().get(
                lead.candidate().variantId());
            byte[] leadGenotypes = genotypes.computeIfAbsent(
                leadVariant.bedIndex(), ignored -> uncheckedRead(
                    reference, bed, leadVariant.bedIndex()));
            for (int otherIndex = index + 1;
                    otherIndex < ordered.size(); otherIndex++) {
                IndexedCandidate other = ordered.get(otherIndex);
                if (assigned.contains(other.candidate().variantId())) continue;
                Variant otherVariant = reference.variants().get(
                    other.candidate().variantId());
                if (!leadVariant.chromosome().equals(otherVariant.chromosome())
                        || distance(leadVariant.position(), otherVariant.position())
                            > windowBases) continue;
                byte[] otherGenotypes = genotypes.computeIfAbsent(
                    otherVariant.bedIndex(), ignored -> uncheckedRead(
                        reference, bed, otherVariant.bedIndex()));
                double rSquared = haplotypeRSquared(leadGenotypes,
                    otherGenotypes, reference.founders());
                if (Double.isFinite(rSquared)
                        && rSquared > options.rSquaredThreshold()) {
                    assigned.add(other.candidate().variantId());
                    exclusions.add(new IndexedExclusion(other.index(),
                        new LdClumpExclusion(other.candidate(),
                            LdClumpExclusionReason.IN_LINKAGE_DISEQUILIBRIUM,
                            lead.candidate().variantId(), rSquared)));
                }
            }
        }
    }

    private static byte[] uncheckedRead(Reference reference, FileChannel bed,
            long bedIndex) {
        try {
            return reference.readGenotypes(bed, bedIndex);
        } catch (IOException exception) {
            throw new GenotypeReadFailure(exception);
        }
    }

    private static long distance(long first, long second) {
        long difference = first - second;
        if (difference == Long.MIN_VALUE) return Long.MAX_VALUE;
        return Math.abs(difference);
    }

    private static double haplotypeRSquared(byte[] first, byte[] second,
            boolean[] founders) {
        long[][] counts = new long[3][3];
        long observations = 0;
        for (int sample = 0; sample < founders.length; sample++) {
            if (!founders[sample]) continue;
            int a = first[sample];
            int b = second[sample];
            if (a < 0 || b < 0) continue;
            counts[a][b]++;
            observations++;
        }
        if (observations == 0) return Double.NaN;

        double alleleA = 0.0;
        double alleleB = 0.0;
        for (int a = 0; a <= 2; a++) for (int b = 0; b <= 2; b++) {
            alleleA += a * counts[a][b];
            alleleB += b * counts[a][b];
        }
        alleleA /= 2.0 * observations;
        alleleB /= 2.0 * observations;
        if (!(alleleA > 0.0 && alleleA < 1.0
                && alleleB > 0.0 && alleleB < 1.0)) return Double.NaN;

        double[] fixed = fixedHaplotypeCounts(counts);
        double doubleHeterozygotes = counts[1][1];
        double[] frequency = null;
        double bestLikelihood = Double.NEGATIVE_INFINITY;
        // Every interior stationary point satisfies the EM self-consistency
        // cubic, but need not maximize the likelihood. Evaluate all its roots
        // and both endpoints; no iterative phase start can abort the clump.
        for (double phase : stationaryPhases(fixed, doubleHeterozygotes, observations)) {
            double[] candidate = phaseFrequencies(fixed, doubleHeterozygotes, phase, observations);
            double likelihood = haplotypeLogLikelihood(counts, candidate);
            if (likelihood > bestLikelihood) {
                bestLikelihood = likelihood;
                frequency = candidate;
            }
        }
        if (frequency == null)
            throw new IllegalStateException("unphased LD likelihood is not finite");
        double pA = frequency[2] + frequency[3];
        double pB = frequency[1] + frequency[3];
        double denominator = pA * (1.0 - pA) * pB * (1.0 - pB);
        if (!(denominator > 0.0)) return Double.NaN;
        double disequilibrium = frequency[3] - pA * pB;
        return Math.min(1.0, disequilibrium * disequilibrium / denominator);
    }

    private static double[] stationaryPhases(double[] fixed, double heterozygotes, long observations) {
        if (heterozygotes == 0) return new double[] {0};
        double scale = 2.0 * observations;
        double h = heterozygotes / scale;
        double a = fixed[0] / scale, b = fixed[1] / scale;
        double c = fixed[2] / scale, d = fixed[3] / scale;
        // A(t)=(a+h*t)(d+h*t), B(t)=(b+h-h*t)(c+h-h*t).
        // F(t)=t*(A+B)-A. In the positive interior, likelihood derivative
        // has sign -F(t), times a strictly positive factor. Thus its only
        // stationary points are roots of this cubic (including multiplicities).
        double c0 = -a * d;
        double c1 = a * d + (b + h) * (c + h) - h * (a + d);
        double c2 = h * (a + d - b - c - 3 * h);
        double c3 = 2 * h * h;
        List<Double> partitions = new ArrayList<>(List.of(0.0, 1.0));
        // Roots of F' partition [0,1] into monotone intervals, so bisection
        // on each sign-changing interval isolates every simple root.
        double discriminant = Math.fma(c2, c2, -3 * c3 * c1);
        if (discriminant >= 0) {
            double root = Math.sqrt(discriminant);
            double q = -c2 - Math.copySign(root, c2);
            double first = q / (3 * c3);
            double second = q == 0 ? -c2 / (3 * c3) : c1 / q;
            if (first > 0 && first < 1) partitions.add(first);
            if (second > 0 && second < 1) partitions.add(second);
        }
        partitions.sort(Double::compare);
        // Including the derivative roots themselves handles repeated cubic
        // roots without a fragile near-zero test; extra feasible candidates
        // cannot exceed the true global maximum.
        List<Double> candidates = new ArrayList<>(partitions);
        for (int interval = 1; interval < partitions.size(); interval++) {
            double lo = partitions.get(interval - 1), hi = partitions.get(interval);
            double flo = phasePolynomial(lo, c0, c1, c2, c3);
            double fhi = phasePolynomial(hi, c0, c1, c2, c3);
            if (flo == 0 || fhi == 0 || Math.copySign(1, flo) == Math.copySign(1, fhi)) continue;
            for (int iteration = 0; iteration < 80; iteration++) {
                double mid = lo + (hi - lo) / 2;
                if (mid == lo || mid == hi) break;
                double value = phasePolynomial(mid, c0, c1, c2, c3);
                if (value == 0) { lo = mid; hi = mid; break; }
                if (Math.copySign(1, value) == Math.copySign(1, flo)) { lo = mid; flo = value; }
                else hi = mid;
            }
            candidates.add(lo + (hi - lo) / 2);
        }
        return candidates.stream().mapToDouble(Double::doubleValue).toArray();
    }

    private static double phasePolynomial(double t, double c0, double c1, double c2, double c3) {
        return Math.fma(t, Math.fma(t, Math.fma(t, c3, c2), c1), c0);
    }

    private static double[] phaseFrequencies(double[] fixed, double heterozygotes,
            double phase, long observations) {
        return new double[] {(fixed[0] + heterozygotes * phase) / (2.0 * observations),
            (fixed[1] + heterozygotes * (1 - phase)) / (2.0 * observations),
            (fixed[2] + heterozygotes * (1 - phase)) / (2.0 * observations),
            (fixed[3] + heterozygotes * phase) / (2.0 * observations)};
    }

    private static double haplotypeLogLikelihood(long[][] counts, double[] f) {
        double[][] probability = {{f[0]*f[0],2*f[0]*f[1],f[1]*f[1]},
            {2*f[0]*f[2],2*(f[0]*f[3]+f[1]*f[2]),2*f[1]*f[3]},
            {f[2]*f[2],2*f[2]*f[3],f[3]*f[3]}};
        double value = 0;
        for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++)
            if (counts[i][j] > 0) value += counts[i][j] * Math.log(probability[i][j]);
        return value;
    }

    private static double[] fixedHaplotypeCounts(long[][] counts) {
        double[] result = new double[4];
        result[0] += 2.0 * counts[0][0];
        result[0] += counts[0][1] + counts[1][0];
        result[1] += counts[0][1] + 2.0 * counts[0][2] + counts[1][2];
        result[2] += counts[1][0] + 2.0 * counts[2][0] + counts[2][1];
        result[3] += counts[1][2] + counts[2][1] + 2.0 * counts[2][2];
        return result;
    }

    private static void validateUnique(List<LdClumpCandidate> candidates) {
        Set<String> seen = new HashSet<>();
        for (LdClumpCandidate candidate : candidates) {
            String key = candidate.group() + '\u0000' + candidate.variantId();
            if (!seen.add(key)) throw new IllegalArgumentException(
                "candidate variants must be unique within each group: "
                    + candidate.variantId());
        }
    }

    private record IndexedCandidate(LdClumpCandidate candidate, int index) { }
    private record IndexedExclusion(int index, LdClumpExclusion exclusion) { }
    private record Variant(String chromosome, String id, long position,
            long bedIndex, String effectAllele, String otherAllele) { }

    private static final class GenotypeReadFailure extends RuntimeException {
        private static final long serialVersionUID = 1L;
        GenotypeReadFailure(IOException cause) { super(cause); }
    }

    private record Reference(Path bed, boolean[] founders,
            Map<String, Variant> variants, int sampleCount,
            int bytesPerVariant) {
        static Reference open(Path prefix, Set<String> requested)
                throws IOException {
            Path bed = Path.of(prefix + ".bed");
            Path bim = Path.of(prefix + ".bim");
            Path fam = Path.of(prefix + ".fam");
            boolean[] founders = readFounders(fam);
            Map<String, Variant> variants = readVariants(bim, requested);
            int bytesPerVariant = (founders.length + 3) / 4;
            long variantCount;
            try (java.util.stream.Stream<String> lines = Files.lines(bim,
                    StandardCharsets.UTF_8)) {
                variantCount = lines.filter(line -> !line.isBlank()).count();
            }
            long expected = Math.addExact(3L,
                Math.multiplyExact(variantCount, bytesPerVariant));
            if (Files.size(bed) != expected) throw new IOException(
                "PLINK BED size does not match BIM/FAM dimensions: " + bed);
            try (FileChannel channel = FileChannel.open(bed,
                    StandardOpenOption.READ)) {
                ByteBuffer header = ByteBuffer.allocate(3);
                readFully(channel, header, 0L);
                if (!Arrays.equals(header.array(), BED_HEADER))
                    throw new IOException(
                        "reference is not a variant-major PLINK 1 BED: " + bed);
            }
            return new Reference(bed, founders, variants, founders.length,
                bytesPerVariant);
        }

        FileChannel openBed() throws IOException {
            return FileChannel.open(bed, StandardOpenOption.READ);
        }

        byte[] readGenotypes(FileChannel channel, long variantIndex)
                throws IOException {
            ByteBuffer packed = ByteBuffer.allocate(bytesPerVariant);
            long offset = Math.addExact(3L,
                Math.multiplyExact(variantIndex, bytesPerVariant));
            readFully(channel, packed, offset);
            byte[] result = new byte[sampleCount];
            for (int sample = 0; sample < sampleCount; sample++) {
                int code = (packed.array()[sample / 4] >>>
                    (2 * (sample % 4))) & 3;
                result[sample] = switch (code) {
                    case 0 -> 2;
                    case 2 -> 1;
                    case 3 -> 0;
                    default -> -1;
                };
            }
            return result;
        }

        private static void readFully(FileChannel channel, ByteBuffer target,
                long position) throws IOException {
            while (target.hasRemaining()) {
                int count = channel.read(target, position + target.position());
                if (count < 0) throw new EOFException("truncated PLINK BED");
                if (count == 0) continue;
            }
        }

        private static boolean[] readFounders(Path fam) throws IOException {
            List<Boolean> values = new ArrayList<>();
            try (BufferedReader input = Files.newBufferedReader(fam,
                    StandardCharsets.UTF_8)) {
                for (String line; (line = input.readLine()) != null;) {
                    if (line.isBlank()) continue;
                    String[] fields = line.trim().split("\\s+");
                    if (fields.length < 6) throw new IOException(
                        "PLINK FAM row has fewer than six fields: " + fam);
                    values.add(fields[2].equals("0") && fields[3].equals("0"));
                }
            }
            if (values.isEmpty()) throw new IOException("PLINK FAM is empty: " + fam);
            boolean[] result = new boolean[values.size()];
            for (int index = 0; index < result.length; index++)
                result[index] = values.get(index);
            if (values.stream().noneMatch(Boolean::booleanValue))
                throw new IOException("PLINK reference contains no founders: " + fam);
            return result;
        }

        private static Map<String, Variant> readVariants(Path bim,
                Set<String> requested) throws IOException {
            Map<String, Variant> result = new HashMap<>();
            Set<String> allIds = new HashSet<>();
            long index = 0;
            try (BufferedReader input = Files.newBufferedReader(bim,
                    StandardCharsets.UTF_8)) {
                for (String line; (line = input.readLine()) != null;) {
                    if (line.isBlank()) continue;
                    String[] fields = line.trim().split("\\s+");
                    if (fields.length < 6) throw new IOException(
                        "PLINK BIM row has fewer than six fields: " + bim);
                    if (!allIds.add(fields[1])) throw new IOException(
                        "duplicate variant ID in PLINK BIM: " + fields[1]);
                    if (requested.contains(fields[1])) {
                        long position;
                        try {
                            position = Long.parseLong(fields[3]);
                        } catch (NumberFormatException exception) {
                            throw new IOException("invalid PLINK BIM position for "
                                + fields[1], exception);
                        }
                        result.put(fields[1], new Variant(fields[0], fields[1],
                            position, index, fields[4], fields[5]));
                    }
                    index++;
                }
            }
            if (index == 0) throw new IOException("PLINK BIM is empty: " + bim);
            return Map.copyOf(result);
        }
    }
}
