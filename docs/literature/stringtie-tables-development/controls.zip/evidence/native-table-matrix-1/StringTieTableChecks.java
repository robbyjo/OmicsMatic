import java.io.File;import java.io.PrintWriter;
import org.junit.platform.launcher.core.*;import org.junit.platform.launcher.listeners.*;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;
public final class StringTieTableChecks {public static void main(String[] args)throws Exception {
for(Class<?> type:new Class<?>[]{org.jlinalg.sequence.StringTieGtf.class,org.jlinalg.sequence.StringTieTables.class})if(!type.getProtectionDomain().getCodeSource().getLocation().toURI().equals(new File(args[0]).toURI()))throw new AssertionError("Wrong actual audit JAR");
var listener=new SummaryGeneratingListener();LauncherFactory.create().execute(LauncherDiscoveryRequestBuilder.request().selectors(selectClass("org.jlinalg.sequence.StringTieGtfTest"),selectClass("org.jlinalg.sequence.StringTieTablesTest")).build(),listener);
var s=listener.getSummary();s.printTo(new PrintWriter(System.out));s.printFailuresTo(new PrintWriter(System.out));
if(s.getTestsFoundCount()!=191||s.getTestsSucceededCount()!=191||s.getTestsSkippedCount()!=0||s.getTestsAbortedCount()!=0||s.getTestsFailedCount()!=0||s.getContainersFailedCount()!=0)throw new AssertionError("Incomplete GTF/table checks");
System.out.println("COMPLETE_STRINGTIE_TABLE_CHECKS 191 NO_SKIPS");}}
