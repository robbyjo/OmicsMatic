package org.jlinalg.cli;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import org.junit.platform.launcher.core.*;
import org.junit.platform.launcher.listeners.*;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;
public class SalmonRuntimeChecks {
 public static void main(String[] args)throws Exception {
  for(String name:new String[]{"org.jlinalg.cli.SalmonRuntime","org.jlinalg.cli.SalmonHealth","org.jlinalg.cli.SalmonSetupEvidence"})if(!Class.forName(name).getProtectionDomain().getCodeSource().getLocation().toURI().equals(new File(args[0]).toURI()))throw new AssertionError("Wrong actual JAR");
  if(args[1].equals("tests")) {
   var listener=new SummaryGeneratingListener();LauncherFactory.create().execute(LauncherDiscoveryRequestBuilder.request().selectors(selectClass("org.jlinalg.cli.SalmonHealthTest"),selectClass("org.jlinalg.cli.SalmonSetupEvidenceTest"),selectClass("org.jlinalg.sequence.SalmonQuantificationTest"),selectClass("org.jlinalg.sequence.SalmonInferentialReplicatesTest")).build(),listener);
   var s=listener.getSummary();s.printTo(new PrintWriter(System.out));s.printFailuresTo(new PrintWriter(System.out));
   if(s.getTestsFoundCount()!=162||s.getTestsSucceededCount()!=162||s.getTestsSkippedCount()!=0||s.getTestsAbortedCount()!=0||s.getTestsFailedCount()!=0||s.getContainersFailedCount()!=0)throw new AssertionError("Incomplete native Salmon runtime checks");
   System.out.println("COMPLETE_NATIVE_SALMON_CASES 162 NO_SKIPS");return;
  }
  String mode=args[1],profile=args[2];Path home=Path.of(args[3]),setup=Path.of(args[4]),work=Path.of(args[5]);
  var limits=SalmonRuntime.Limits.defaults();
  if(mode.equals("missing"))home=work.getParent().resolve("absent-home");
  if(mode.equals("wrong-profile"))profile=profile.endsWith("1.8.0")?"linux-x86_64-salmon-1.1.0":"linux-x86_64-salmon-1.8.0";
  if(mode.equals("image-capacity"))limits=new SalmonRuntime.Limits(limits.host(),limits.process(),limits.setup(),1);
  var injected=new AtomicBoolean();
  Runnable cancellation=()->{
   if(mode.equals("cancel-after-version")&&Files.exists(work.resolve("probes/version/process.json")))throw new java.util.concurrent.CancellationException("controlled native cancellation after clean original version process");
   if(mode.equals("late-finalization")&&Files.exists(work.resolve("metadata/health.json"))&&injected.compareAndSet(false,true))try{Files.writeString(work.resolve("COMPLETED.json"),"{\"controlled_untrusted_collision\":true}\n",StandardOpenOption.CREATE_NEW);}catch(IOException e){throw new java.io.UncheckedIOException(e);}
  };
  try {
   var admitted=SalmonRuntime.admit(profile,home,setup,work,limits,cancellation);admitted.verify(()->{});
   if(!mode.equals("admit"))throw new AssertionError("Negative control admitted a runtime");
   System.out.println(NextflowJson.json(Map.of("status","passed-native-runtime-health-only","profile",admitted.profile(),"version",admitted.version(),"work",work.toString(),"complete_health_rows",admitted.health().stream().mapToInt(r->r.table().rows().size()).sum(),"complete_bootstrap_values",admitted.health().stream().mapToLong(r->r.replicates().values()).sum(),"user_analysis_admitted",false,"complete_native_files",SalmonRuntime.tree(work,limits.process(),()->{}))));
  } catch(IOException expected) {
   if(mode.equals("admit"))throw expected;
   if(mode.equals("missing")!= (expected instanceof SalmonRuntime.Unavailable))throw new AssertionError("Wrong SKIP3/FAIL2 classification",expected);
   if(Files.exists(work.resolve("COMPLETED.json")))throw new AssertionError("Failed admission retained a completion marker",expected);
   String warning=Files.readString(work.resolve("WARNINGS.md"));if(!warning.contains("Required action:")||!warning.contains(mode.equals("missing")?"SKIP3":"FAIL2"))throw new AssertionError("Missing prominent recovery");
   if(mode.equals("late-finalization")&&(!injected.get()||!Files.exists(work.resolve("COMPLETED-REVOKED.json"))||!Files.exists(work.resolve("health/health-vb/quant.sf"))))throw new AssertionError("Late failure did not preserve complete original health and revoke the marker");
   System.out.println(NextflowJson.json(Map.of("status","passed-expected-native-admission-rejection","mode",mode,"error",expected.toString(),"exit_class",mode.equals("missing")?3:2,"work",work.toString(),"user_analysis_admitted",false,"complete_native_files",SalmonRuntime.tree(work,SalmonRuntime.Limits.defaults().process(),()->{}))));
  }
 }
}
