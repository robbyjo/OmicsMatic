package org.jlinalg.cli;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import org.jlinalg.sequence.*;
public class SalmonIndexControls {
 static void write(Path p,Object v)throws IOException{Files.writeString(p,NextflowJson.json(v)+"\n",StandardOpenOption.CREATE_NEW);}
 static Map<String,Object> fingerprint(NextflowFiles.Pin p){return Map.of("bytes",p.bytes(),"sha256",p.sha256());}
 static List<String> names(SalmonIndexReferences.Summary r){return r.references().stream().map(SalmonIndexReferences.Reference::name).toList();}
 static Map<String,Object> reference(SalmonIndexReferences.Reference r){return Map.of("ordinal",r.ordinal(),"name",r.name(),"original_length",r.originalLength(),"normalized_length",r.normalizedLength(),"contig_reference_id",r.contigReferenceId());}
 public static void main(String[] args)throws Exception {
  for(String name:new String[]{"org.jlinalg.cli.SalmonRuntime","org.jlinalg.sequence.SalmonIndexReferences","org.jlinalg.sequence.SalmonQuantification"})if(!Class.forName(name).getProtectionDomain().getCodeSource().getLocation().toURI().equals(new File(args[0]).toURI()))throw new AssertionError("Wrong actual JAR");
  String version=args[1];Path home=Path.of(args[2]),setup=Path.of(args[3]),root=Path.of(args[4]),specification=Path.of(args[5]);Files.createDirectory(root);
  var limits=SalmonRuntime.Limits.defaults();System.err.println("RUNTIME_HEALTH_START "+version);var admitted=SalmonRuntime.admit("linux-x86_64-salmon-"+version,home,setup,root.resolve("host"),limits,()->{});System.err.println("RUNTIME_HEALTH_COMPLETE "+version);
  var specPin=NextflowFiles.pin(specification,8388608,()->{});var spec=SalmonHealth.json(specification);var results=new ArrayList<Object>();
  for(Object item:NextflowFiles.list(spec.get("cases"))) {
   var test=NextflowFiles.object(item);String id=NextflowFiles.text(test.get("id"));if(!id.matches("[a-z0-9-]{1,80}"))throw new IOException("Unsafe controlled case ID");
   System.err.println("INDEX_CASE_START "+version+" "+id);Path area=root.resolve(id),input=area.resolve("inputs"),index=area.resolve("index");Files.createDirectory(area);Files.createDirectory(input);Files.createDirectory(index);
   Path fasta=input.resolve("reference.fa");Files.writeString(fasta,NextflowFiles.text(test.get("fasta")),StandardOpenOption.CREATE_NEW);
   var command=new ArrayList<>(List.of(home.resolve("bin/salmon").toString(),"--no-version-check","index","-t",fasta.toString(),"-i",index.toString(),"-k","15","-p","2"));
   if(Boolean.TRUE.equals(test.get("keep_duplicates")))command.add("--keepDuplicates");if(Boolean.TRUE.equals(test.get("gencode")))command.add("--gencode");
   if(!version.equals("1.0.0"))command.add("--keepFixedFasta");
   if(test.get("decoys")!=null){Path p=input.resolve("decoys.txt");Files.writeString(p,NextflowFiles.text(test.get("decoys")),StandardOpenOption.CREATE_NEW);command.add("-d");command.add(p.toString());}
   var inputTree=SalmonRuntime.tree(input,limits.process(),()->{});boolean observeMissing=Boolean.TRUE.equals(test.get("observe_missing_decoy_old_editions"))&&Set.of("1.0.0","1.1.0").contains(version);boolean expectedFailure=Boolean.TRUE.equals(test.get("expected_failure"))&&!observeMissing;IOException processFailure=null;
   try{RsemProcess.executeOwned(command,admitted.environment(),area.resolve("index-process"),limits.process(),()->{admitted.verify(()->{});if(!inputTree.equals(SalmonRuntime.tree(input,limits.process(),()->{})))throw new IOException("Protected original edge input changed");},()->{},List.of(input,index,admitted.work()));}
   catch(IOException failed){processFailure=failed;}
   if(!inputTree.equals(SalmonRuntime.tree(input,limits.process(),()->{})))throw new IOException("Original edge input changed");admitted.verify(()->{});
   var indexLedger=SalmonHealth.json(area.resolve("index-process/process.json"));long exit=((Number)indexLedger.get("exit_code")).longValue();
   System.err.println("INDEX_CASE_EXIT "+version+" "+id+" "+exit);var row=new LinkedHashMap<String,Object>();row.put("id",id);row.put("command",command);row.put("index_exit",exit);row.put("fixed_fasta_retention_option_available",!version.equals("1.0.0"));row.put("user_analysis_admitted",false);
   if(expectedFailure||(observeMissing&&processFailure!=null)){if(processFailure==null||exit==0)throw new AssertionError("Original invalid decoy case did not fail");row.put("status","original-index-rejected-no-result");row.put("error",processFailure.toString());}
   else {
    if(processFailure!=null)throw processFailure;var positions=new ArrayList<Object>();SalmonIndexReferences.Summary decoded;
    try(var table=Files.newInputStream(index.resolve("ctable.bin"));var complete=Files.newInputStream(index.resolve("complete_ref_lens.bin"));var normalized=Files.newInputStream(index.resolve("reflengths.bin"))){decoded=SalmonIndexReferences.read(table,complete,normalized,new SalmonIndexReferences.Limits(1000,100000,8192,1000000,33554432,16777216),(o,c,f,n,p,fw)->positions.add(Map.of("ordinal",o,"contig_reference",c,"full_reference",f,"name",n,"start",p,"forward",fw)),()->{});}
    Object expectedNames=test.get("expected_full_names");if(test.get("expected_full_names_by_edition") instanceof Map<?,?> editions&&editions.containsKey(version))expectedNames=editions.get(version);
    if(!names(decoded).equals(expectedNames))throw new AssertionError("Original index population differs from controlled input expectations: "+id+" "+names(decoded));
    row.put("status","complete-original-index-and-native-reference-table-observed");row.put("references",decoded.references().stream().map(SalmonIndexControls::reference).toList());row.put("positions",positions);row.put("index_info",SalmonMetadata.read(index.resolve("info.json"),8388608,100000));
    if(observeMissing){row.put("status","original-index-accepted-unmatched-decoy-declaration-no-user-result");row.put("requested_raw_decoy_coverage",false);row.put("required_action","Reject the unmatched declared name before analysis; an original zero exit does not establish decoy coverage.");}
    row.put("ctable",fingerprint(NextflowFiles.pin(index.resolve("ctable.bin"),33554432,()->{})));row.put("refseq",fingerprint(NextflowFiles.pin(index.resolve("refseq.bin"),33554432,()->{})));
    Path duplicates=index.resolve("duplicate_clusters.tsv");row.put("duplicate_clusters",Files.exists(duplicates)?SalmonHealth.utf8(duplicates):null);
    if(test.get("reads")!=null) {
     Path reads=input.resolve("reads.fastq"),quant=area.resolve("quant");Files.writeString(reads,NextflowFiles.text(test.get("reads")),StandardOpenOption.CREATE_NEW);Files.createDirectory(quant);
     var quantInputs=SalmonRuntime.tree(input,limits.process(),()->{});var indexTree=SalmonRuntime.tree(index,limits.process(),()->{});
     var quantCommand=List.of(home.resolve("bin/salmon").toString(),"--no-version-check","quant","-i",index.toString(),"-l","U","-r",reads.toString(),"--fldMean","40","--fldSD","5","--useEM","--minAssignedFrags","1","-p","2","-o",quant.toString());
     RsemProcess.executeOwned(quantCommand,admitted.environment(),area.resolve("quant-process"),limits.process(),()->{admitted.verify(()->{});if(!quantInputs.equals(SalmonRuntime.tree(input,limits.process(),()->{}))||!indexTree.equals(SalmonRuntime.tree(index,limits.process(),()->{})))throw new IOException("Protected index/reads changed during controlled quantification");},()->{},List.of(input,index,quant,admitted.work()));
     Set<String> decoys=test.get("decoys")==null?Set.of():Set.copyOf(NextflowFiles.text(test.get("decoys")).lines().toList());var targets=decoded.references().stream().filter(r->!decoys.contains(r.name())).map(r->new SalmonQuantification.Target(r.name(),r.originalLength())).toList();
     var retainedDecoys=new HashSet<>(decoys);retainedDecoys.retainAll(names(decoded));var info=SalmonMetadata.read(index.resolve("info.json"),8388608,100000);
     var ledger=SalmonDecoyAssignment.assign(decoded,(int)SalmonMetadata.integer(info.get("k"),31),SalmonMetadata.integer(info.get("num_decoys"),1000),SalmonMetadata.unsigned(info.get("first_decoy_index")),retainedDecoys,()->{});
     row.put("source_declared_decoy_disagreements",ledger.disagreements());row.put("original_runtime_num_decoys",ledger.originalRuntimeDecoys());row.put("declared_and_runtime_populations_agree",ledger.matchesDeclaredPopulation());
     row.put("complete_decoy_assignments",ledger.assignments().stream().map(r->Map.of("name",r.reference().name(),"short_reference",r.shortReference(),"declared_decoy",r.declaredDecoy(),"original_runtime_decoy",r.originalRuntimeDecoy())).toList());
     row.put("quant_command",quantCommand);row.put("quant_meta",SalmonHealth.json(quant.resolve("aux_info/meta_info.json")));row.put("expected_nondecoy_names",targets.stream().map(SalmonQuantification.Target::name).toList());
     var sourceTable=SalmonQuantification.read(new StringReader(SalmonHealth.utf8(quant.resolve("quant.sf"))),ledger.originalRuntimeNondecoys(),3,8388608,8192,()->{});long sourceAssigned=((Number)SalmonHealth.json(quant.resolve("lib_format_counts.json")).get("num_assigned_fragments")).longValue();SalmonQuantification.audit(sourceTable,sourceAssigned,()->{});
     if(((Number)SalmonHealth.json(quant.resolve("aux_info/meta_info.json")).get("num_decoy_targets")).longValue()!=ledger.originalRuntimeDecoys())throw new IOException("Original runtime decoy counter does not match the source ledger");
     row.put("source_as_run_audit","complete-source-compatible-population-and-arithmetic-pass-requested-coverage-separate");row.put("source_as_run_rows",sourceTable.rows().size());
     try {var table=SalmonQuantification.read(new StringReader(SalmonHealth.utf8(quant.resolve("quant.sf"))),targets,3,8388608,8192,()->{});long assigned=((Number)SalmonHealth.json(quant.resolve("lib_format_counts.json")).get("num_assigned_fragments")).longValue();var arithmetic=SalmonQuantification.audit(table,assigned,()->{});row.put("quant_audit","complete-independent-population-and-printed-arithmetic-pass");row.put("quant_rows",table.rows().size());row.put("assigned_fragments",assigned);row.put("printed_count_sum",arithmetic.printedCountSum());}
     catch(IOException discrepancy){row.put("quant_audit","source-boundary-discrepancy-retained-no-user-result");row.put("quant_audit_error",discrepancy.toString());}
    }
   }
   write(area.resolve("OBSERVATION.json"),row);results.add(row);System.err.println("INDEX_CASE_RECORDED "+version+" "+id);
  }
  admitted.verify(()->{});if(!specPin.equals(NextflowFiles.pin(specification,8388608,()->{})))throw new IOException("Control specification changed");
  write(root.resolve("OBSERVED.json"),Map.of("status","complete-original-index-edge-observations-not-user-analysis","version",version,"cases",results,"user_analysis_admitted",false));
  System.out.println(NextflowJson.json(Map.of("version",version,"cases",results.size(),"complete_native_files",SalmonRuntime.tree(root,limits.process(),()->{}),"user_analysis_admitted",false)));
 }
}
