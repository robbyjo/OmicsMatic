# Salmon FAIL2 — NO RUNTIME/RESULT ADMITTED

java.nio.file.FileAlreadyExistsException: /var/tmp/omicsmatic-salmon-native-admission-7kesy55e/late-finalization/COMPLETED.json

Required action: inspect WARNINGS.md, FAILURE.json when present, the complete native host/health inventory and every retained process stdout/stderr/ledger. SKIP3 means a permitted exact runtime, helper, host resource or capability is unavailable: skip dependent analysis and complete only permitted explicit setup. FAIL2 means invalid input, changed evidence, process, numerical, capacity, cancellation or finalization failure: no result is admitted. Preserve partials and use NEW paths after correction. No installation or download occurs during native admission. Synthetic runtime health does not admit a user fit or certify biological accuracy. Cell Ranger remains excluded.
