import java.io.*;
import org.junit.platform.launcher.core.*;import org.junit.platform.launcher.listeners.*;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;
public class SalmonQuantAdmissionChecks {
 public static void main(String[] args)throws Exception {
  for(String n:new String[]{"SalmonQuantRecipe","SalmonAlignments","SalmonQuantAudit","SalmonQuantInputs","SalmonIndexWorkflow","SalmonRuntime"})if(!Class.forName("org.jlinalg.cli."+n).getProtectionDomain().getCodeSource().getLocation().toURI().equals(new File(args[0]).toURI()))throw new AssertionError("Wrong actual JAR");
  var listener=new SummaryGeneratingListener();LauncherFactory.create().execute(LauncherDiscoveryRequestBuilder.request().selectors(selectClass("org.jlinalg.cli.SalmonAlignmentsTest"),selectClass("org.jlinalg.cli.SalmonDecoyAssignmentTest"),selectClass("org.jlinalg.cli.SalmonHealthTest"),selectClass("org.jlinalg.cli.SalmonIndexAuditTest"),selectClass("org.jlinalg.cli.SalmonIndexRecipeTest"),selectClass("org.jlinalg.cli.SalmonMetadataTest"),selectClass("org.jlinalg.cli.SalmonQuantAuditTest"),selectClass("org.jlinalg.cli.SalmonQuantInputsTest"),selectClass("org.jlinalg.cli.SalmonQuantRecipeTest"),selectClass("org.jlinalg.cli.SalmonReadsTest"),selectClass("org.jlinalg.cli.SalmonReferencesTest"),selectClass("org.jlinalg.cli.SalmonSetupEvidenceTest"),selectClass("org.jlinalg.sequence.SalmonIndexReferencesTest"),selectClass("org.jlinalg.sequence.SalmonInferentialReplicatesTest"),selectClass("org.jlinalg.sequence.SalmonQuantificationTest")).build(),listener);
  var s=listener.getSummary();s.printTo(new PrintWriter(System.out));s.printFailuresTo(new PrintWriter(System.out));
  if(s.getTestsFoundCount()!=425||s.getTestsSucceededCount()!=425||s.getTestsSkippedCount()!=0||s.getTestsAbortedCount()!=0||s.getTestsFailedCount()!=0||s.getContainersFailedCount()!=0)throw new AssertionError("Incomplete Salmon input/output contracts");
  System.out.println("COMPLETE_SALMON_CASES 425 NO_SKIPS NO_USER_FIT_ADMITTED");
 }
}
