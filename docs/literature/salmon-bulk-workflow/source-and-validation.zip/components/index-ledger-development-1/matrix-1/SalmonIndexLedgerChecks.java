import java.io.*;
import org.junit.platform.launcher.core.*;
import org.junit.platform.launcher.listeners.*;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;
public class SalmonIndexLedgerChecks {
 public static void main(String[] args)throws Exception {
  for(String name:new String[]{"org.jlinalg.cli.SalmonMetadata","org.jlinalg.sequence.SalmonDecoyAssignment","org.jlinalg.sequence.SalmonIndexReferences","org.jlinalg.cli.SalmonRuntime","org.jlinalg.sequence.SalmonQuantification"})if(!Class.forName(name).getProtectionDomain().getCodeSource().getLocation().toURI().equals(new File(args[0]).toURI()))throw new AssertionError("Wrong actual JAR");
  var listener=new SummaryGeneratingListener();LauncherFactory.create().execute(LauncherDiscoveryRequestBuilder.request().selectors(selectClass("org.jlinalg.cli.SalmonMetadataTest"),selectClass("org.jlinalg.cli.SalmonDecoyAssignmentTest"),selectClass("org.jlinalg.sequence.SalmonIndexReferencesTest"),selectClass("org.jlinalg.cli.SalmonHealthTest"),selectClass("org.jlinalg.cli.SalmonSetupEvidenceTest"),selectClass("org.jlinalg.sequence.SalmonQuantificationTest"),selectClass("org.jlinalg.sequence.SalmonInferentialReplicatesTest")).build(),listener);
  var s=listener.getSummary();s.printTo(new PrintWriter(System.out));s.printFailuresTo(new PrintWriter(System.out));
  if(s.getTestsFoundCount()!=241||s.getTestsSucceededCount()!=241||s.getTestsSkippedCount()!=0||s.getTestsAbortedCount()!=0||s.getTestsFailedCount()!=0||s.getContainersFailedCount()!=0)throw new AssertionError("Incomplete native Salmon population ledger checks");
  System.out.println("COMPLETE_SALMON_CASES 241 DECLARED_SOURCE_BOUNDARY_COUNTEREXAMPLES 3 OMITTED_NAMES_PRESERVED NO_SKIPS");
 }
}
