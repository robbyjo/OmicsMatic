package org.jlinalg.cli;
import java.io.*;import java.nio.file.*;import java.util.*;
import org.junit.platform.launcher.core.*;import org.junit.platform.launcher.listeners.*;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;
public class SalmonIndexWorkflowChecks {
 public static void main(String[] args)throws Exception {
  for(String n:new String[]{"SalmonIndexWorkflow","SalmonIndexAudit","SalmonIndexRecipe","SalmonReads","SalmonReferences","SalmonRuntime"})if(!Class.forName("org.jlinalg.cli."+n).getProtectionDomain().getCodeSource().getLocation().toURI().equals(new File(args[0]).toURI()))throw new AssertionError("Wrong actual JAR");
  if(args[1].equals("tests")){
   var listener=new SummaryGeneratingListener();LauncherFactory.create().execute(LauncherDiscoveryRequestBuilder.request().selectors(selectClass("org.jlinalg.cli.SalmonDecoyAssignmentTest"),selectClass("org.jlinalg.cli.SalmonHealthTest"),selectClass("org.jlinalg.cli.SalmonIndexAuditTest"),selectClass("org.jlinalg.cli.SalmonIndexRecipeTest"),selectClass("org.jlinalg.cli.SalmonMetadataTest"),selectClass("org.jlinalg.cli.SalmonReadsTest"),selectClass("org.jlinalg.cli.SalmonReferencesTest"),selectClass("org.jlinalg.cli.SalmonSetupEvidenceTest"),selectClass("org.jlinalg.sequence.SalmonIndexReferencesTest"),selectClass("org.jlinalg.sequence.SalmonInferentialReplicatesTest"),selectClass("org.jlinalg.sequence.SalmonQuantificationTest")).build(),listener);
   var s=listener.getSummary();s.printTo(new PrintWriter(System.out));s.printFailuresTo(new PrintWriter(System.out));
   if(s.getTestsFoundCount()!=344||s.getTestsSucceededCount()!=344||s.getTestsSkippedCount()!=0||s.getTestsAbortedCount()!=0||s.getTestsFailedCount()!=0||s.getContainersFailedCount()!=0)throw new AssertionError("Incomplete focused cases");
   System.out.println("COMPLETE_SALMON_CASES 344 NO_SKIPS");return;
  }
  if(args[1].equals("build")){
   System.err.println("INDEX_WORKFLOW_START "+args[2]);var result=SalmonIndexWorkflow.start(Path.of(args[3]),Path.of(args[4]),Path.of(args[5]),Path.of(args[6]),()->{});
   if(result.audit().ledger().decoys().matchesDeclaredPopulation()||result.audit().ledger().decoys().disagreements().size()!=1)throw new AssertionError("Disagreement erased");
   SalmonIndexWorkflow.verify(result.root(),()->{});System.out.println(NextflowJson.json(Map.of("profile",result.recipe().profile(),"audit",result.audit().summary(),"complete_native_files",SalmonIndexWorkflow.inventory(result.root(),result.recipe().limits().process(),()->{}))));
   System.err.println("INDEX_WORKFLOW_COMPLETE "+args[2]);return;
  }
  if(args[1].equals("verify")){
   var result=SalmonIndexWorkflow.verify(Path.of(args[2]),()->{});System.out.println("COMPLETE_PORTABLE_INDEX_ONLY "+result.recipe().profile()+" EXPRESSION_NOT_ADMITTED");return;
  }
  throw new AssertionError("Unknown control operation");
 }
}
