package org.jlinalg.cli;
import java.io.*;import java.nio.file.*;import java.util.*;import java.util.concurrent.CancellationException;
import htsjdk.samtools.*;
import org.junit.platform.launcher.core.*;import org.junit.platform.launcher.listeners.*;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;
public class SalmonQuantWorkflowChecks {
 static void write(Path p,Object v)throws IOException{Files.writeString(p,NextflowJson.json(v)+"\n",StandardOpenOption.CREATE_NEW);}
 static Map<String,Object> receipt(String id,SalmonQuantWorkflow.Result r){return Map.of("id",id,"input",r.inputs().document(),"output",r.output().document(),"manifest",SalmonIndexWorkflow.fingerprint(r.manifest()),"declared_retained_population_admitted",r.inputs().declaredRetainedPopulationMatchesSource());}
 static void reject(String id,Path recipe,SalmonRuntime.Admitted admitted,Path root,int code,Runnable check)throws Exception{
  try{SalmonQuantWorkflow.startWithAdmitted(recipe,admitted,root,check);throw new AssertionError("Rejected attempt returned a result");}
  catch(IOException failed){if((failed instanceof SalmonRuntime.Unavailable?3:2)!=code||Files.exists(root.resolve("COMPLETED.json")))throw new AssertionError("Wrong rejection",failed);}
  var f=NextflowFiles.object(NextflowFiles.json(root.resolve("FAILURE.json"),1048576));if(NextflowFiles.integer(f.get("exit_code"),2,3)!=code)throw new AssertionError("Wrong failure diagnostic");
  System.err.println("FIT_REJECTED "+id+" "+code);
 }
 public static void main(String[] args)throws Exception{
  for(String n:new String[]{"SalmonQuantWorkflow","SalmonQuantInputs","SalmonQuantAudit","SalmonIndexWorkflow","SalmonRuntime","SalmonToolsCli","SalmonSetupExport"})if(!Class.forName("org.jlinalg.cli."+n).getProtectionDomain().getCodeSource().getLocation().toURI().equals(new File(args[0]).toURI()))throw new AssertionError("Wrong actual JAR");
  if(args[1].equals("tests")){
   var listener=new SummaryGeneratingListener();LauncherFactory.create().execute(LauncherDiscoveryRequestBuilder.request().selectors(selectClass("org.jlinalg.cli.SalmonAlignmentsTest"),selectClass("org.jlinalg.cli.SalmonDecoyAssignmentTest"),selectClass("org.jlinalg.cli.SalmonHealthTest"),selectClass("org.jlinalg.cli.SalmonIndexAuditTest"),selectClass("org.jlinalg.cli.SalmonIndexRecipeTest"),selectClass("org.jlinalg.cli.SalmonMetadataTest"),selectClass("org.jlinalg.cli.SalmonQuantAuditTest"),selectClass("org.jlinalg.cli.SalmonQuantInputsTest"),selectClass("org.jlinalg.cli.SalmonQuantRecipeTest"),selectClass("org.jlinalg.cli.SalmonQuantWorkflowBoundaryTest"),selectClass("org.jlinalg.cli.SalmonReadsTest"),selectClass("org.jlinalg.cli.SalmonReferencesTest"),selectClass("org.jlinalg.cli.SalmonSetupEvidenceTest"),selectClass("org.jlinalg.cli.SalmonSetupExportTest"),selectClass("org.jlinalg.cli.SalmonToolsCliTest"),selectClass("org.jlinalg.sequence.SalmonIndexReferencesTest"),selectClass("org.jlinalg.sequence.SalmonInferentialReplicatesTest"),selectClass("org.jlinalg.sequence.SalmonQuantificationTest")).build(),listener);var s=listener.getSummary();s.printTo(new PrintWriter(System.out));s.printFailuresTo(new PrintWriter(System.out));
   if(s.getTestsFoundCount()!=446||s.getTestsSucceededCount()!=446||s.getTestsSkippedCount()!=0||s.getTestsAbortedCount()!=0||s.getTestsFailedCount()!=0||s.getContainersFailedCount()!=0)throw new AssertionError("Incomplete workflow cases");System.out.println("COMPLETE_SALMON_CASES 446 NO_SKIPS");return;
  }
  if(args[1].equals("verify")){if(SalmonToolsCli.run(new String[]{"--verify",args[2]},System.out,System.err)!=0)throw new AssertionError("Public portable verification failed");return;}
  if(!args[1].equals("native"))throw new AssertionError("Unknown operation");
  Path specification=Path.of(args[2]),root=Path.of(args[3]);var specPin=NextflowFiles.pin(specification,8388608,()->{});var spec=NextflowFiles.object(NextflowFiles.json(specification,8388608));
  Files.createDirectory(root);Files.createDirectory(root.resolve("recipes"));String version=NextflowFiles.text(spec.get("version")),profile="linux-x86_64-salmon-"+version;Path home=Path.of(NextflowFiles.text(spec.get("home"))),setup=Path.of(NextflowFiles.text(spec.get("setup")));
  Path indexRecipe=root.resolve("recipes/index.json");write(indexRecipe,spec.get("index_recipe"));System.err.println("CLEAN_INDEX_START "+version);
  var index=SalmonIndexWorkflow.start(indexRecipe,home,setup,root.resolve("clean-index"),()->{});if(!index.audit().ledger().decoys().matchesDeclaredPopulation())throw new AssertionError("Clean declared population mismatch");System.err.println("CLEAN_INDEX_COMPLETE "+version);
  System.err.println("FIT_RUNTIME_START "+version);var admitted=SalmonRuntime.admit(profile,home,setup,root.resolve("admission"),SalmonRuntime.Limits.defaults(),()->{});System.err.println("FIT_RUNTIME_COMPLETE "+version);
  Path conversions=Files.createDirectory(root.resolve("input-conversion")),bam=conversions.resolve("alignments.bam"),sam=Path.of(NextflowFiles.text(spec.get("original_sam")));
  var samPin=NextflowFiles.pin(sam,16777216,()->{});try(var reader=SamReaderFactory.makeDefault().validationStringency(ValidationStringency.STRICT).open(sam);var writer=new SAMFileWriterFactory().makeBAMWriter(reader.getFileHeader(),true,bam);var it=reader.iterator()){while(it.hasNext())writer.addAlignment(it.next());}
  var fits=new ArrayList<Object>();
  for(Object value:NextflowFiles.list(spec.get("fits"))){var row=NextflowFiles.object(value);String id=NextflowFiles.text(row.get("id"));if(!id.matches("[a-z0-9-]{1,80}"))throw new AssertionError("Unsafe owned ID");
   Object recipe=row.get("recipe");if(id.equals("alignment-bam-vb-5")){var r=new LinkedHashMap<Object,Object>(NextflowFiles.object(recipe));r.put("alignments",Map.of("path",bam.toString(),"format","BAM","layout","PAIRED"));recipe=r;}
   Path path=root.resolve("recipes/"+id+".json");write(path,recipe);System.err.println("FIT_START "+version+" "+id);
   var result=SalmonQuantWorkflow.startWithAdmitted(path,admitted,root.resolve(id),()->{});SalmonQuantWorkflow.verify(result.root(),()->{});
   if(result.output().table().rows().size()!=NextflowFiles.integer(row.get("targets"),1,1000)||result.inputs().declaredRetainedPopulationMatchesSource()!=Boolean.TRUE.equals(row.get("declared")))throw new AssertionError("Incomplete fit population");
   fits.add(receipt(id,result));write(root.resolve(id+"-OBSERVED.json"),receipt(id,result));System.err.println("FIT_COMPLETE "+version+" "+id);
  }
  Path strict=root.resolve("recipes/strict-declared.json");write(strict,spec.get("strict_recipe"));reject("strict-declared",strict,admitted,root.resolve("strict-declared"),3,()->{});if(Files.exists(root.resolve("strict-declared/quant-process")))throw new AssertionError("Skipped population launched a user fit");
  Path insufficient=root.resolve("recipes/insufficient-assigned.json");write(insufficient,spec.get("insufficient_recipe"));reject("insufficient-assigned",insufficient,admitted,root.resolve("insufficient-assigned"),2,()->{});
  var process=NextflowFiles.object(NextflowFiles.json(root.resolve("insufficient-assigned/quant-process/process.json"),1048576));if(NextflowFiles.integer(process.get("exit_code"),0,255)==0||!NextflowFiles.list(process.get("owned_live_after_cleanup")).isEmpty())throw new AssertionError("Expected original failure did not terminate");
  Map<String,Object> cliFit=Map.of();
  if(version.equals("1.9.0")){
   Path capacity=root.resolve("recipes/bootstrap-capacity.json");write(capacity,spec.get("capacity_recipe"));reject("bootstrap-capacity",capacity,admitted,root.resolve("bootstrap-capacity"),2,()->{});if(Files.exists(root.resolve("bootstrap-capacity/quant-process")))throw new AssertionError("Capacity failure launched a fit");
   Path late=root.resolve("recipes/late-finalization.json"),lateRoot=root.resolve("late-finalization");write(late,spec.get("late_recipe"));reject("late-finalization",late,admitted,lateRoot,2,()->{if(Files.exists(lateRoot.resolve("COMPLETED.json")))throw new CancellationException("Controlled post-completion finalization cancellation");});
   if(!Files.exists(lateRoot.resolve("OUTPUT-AUDIT.json"))||!Files.exists(lateRoot.resolve("WARNINGS-before-failure.md")))throw new AssertionError("Late original output/warnings lost");
   Path unexpected=root.resolve("recipes/unexpected-finalization.json"),unexpectedRoot=root.resolve("unexpected-finalization");write(unexpected,spec.get("late_recipe"));reject("unexpected-finalization",unexpected,admitted,unexpectedRoot,2,()->{if(Files.exists(unexpectedRoot.resolve("COMPLETED.json")))throw new AssertionError("Controlled unexpected post-completion guard error");});
   if(!Files.exists(unexpectedRoot.resolve("OUTPUT-AUDIT.json"))||!Files.exists(unexpectedRoot.resolve("WARNINGS-before-failure.md")))throw new AssertionError("Unexpected-error prefix lost");
   System.err.println("PUBLIC_CLI_START "+version);Path cliRoot=root.resolve("cli-alignment");var stdout=new ByteArrayOutputStream();var stderr=new ByteArrayOutputStream();int code;
   try(var o=new PrintStream(stdout,true,java.nio.charset.StandardCharsets.UTF_8);var e=new PrintStream(stderr,true,java.nio.charset.StandardCharsets.UTF_8)){code=SalmonToolsCli.run(new String[]{"--recipe",root.resolve("recipes/alignment-sam-em-3.json").toString(),"--home",home.toString(),"--setup-report",setup.toString(),"--out",cliRoot.toString()},o,e);}
   Files.write(root.resolve("cli.stdout"),stdout.toByteArray(),StandardOpenOption.CREATE_NEW);Files.write(root.resolve("cli.stderr"),stderr.toByteArray(),StandardOpenOption.CREATE_NEW);if(code!=0)throw new AssertionError("Public original CLI failed, exit "+code);
   cliFit=receipt("cli-alignment",SalmonQuantWorkflow.verify(cliRoot,()->{}));System.err.println("PUBLIC_CLI_COMPLETE "+version);
  }
  admitted.verify(()->{});if(!samPin.equals(NextflowFiles.pin(sam,16777216,()->{}))||!specPin.equals(NextflowFiles.pin(specification,8388608,()->{})))throw new AssertionError("Original protocol input/specification changed");
  write(root.resolve("OBSERVED.json"),Map.of("status","complete-controlled-original-bulk-workflows-not-biological-validation","version",version,"fits",fits,"cli_fit",cliFit,"strict_population_skipped",true,"original_insufficient_mass_rejected",true));
  System.out.println(NextflowJson.json(Map.of("version",version,"fits",fits,"cli_fit",cliFit,"complete_native_files",SalmonIndexWorkflow.inventory(root,index.recipe().limits().process(),()->{}))));
 }
}
