# Salmon index only — no expression analysis admitted

WARNING: Original preprocessing may replace ambiguous bases, clip poly-A tails and remove references; inspect every row in REFERENCE-LEDGER.jsonl. Duplicate-cluster output alone is not an exclusion list.

WARNING: 0 raw references were not retained; reasons require separate original evidence. 0 retained reference assignments differ between declared decoys and the original runtime. No missing transcript is treated as biological zero.

Required action: inspect WARNINGS.md, FAILURE.json when present, REFERENCE-LEDGER.jsonl and original index-process/process.stderr and process.stdout. SKIP3 means an exact permitted runtime, helper or requested capability is unavailable: skip dependent analysis and complete only permitted setup. FAIL2 means invalid input, changed evidence, process, capacity, cancellation or finalization failure: no result is admitted. Preserve the attempt and use NEW paths after correction. An index is not an expression result. Short-reference/decoy disagreements remain explicit; no missing expression row is imputed. Portable verification checks complete captured bytes and contracts, not the current producer host, graph mathematical equivalence, execution authenticity or biological accuracy. No installation/download occurs during index construction.
