args <- commandArgs(TRUE);stopifnot(length(args)==2L)
source <- args[[1L]];out <- args[[2L]]
stopifnot(!file.exists(out));dir.create(out)
library(scrattch.bigcat)
ns <- asNamespace("scrattch.bigcat")
stopifnot(as.character(packageVersion("scrattch.bigcat"))=="0.0.5")
definitions <- list();factories <- list()
walk <- function(x,path,location="") {
  if(is.call(x)&&identical(x[[1L]],as.name("function"))) {
    definitions[[length(definitions)+1L]] <<- list(path=path,location=location,formals=x[[2L]],body=x[[3L]])
  }
  if(is.call(x)||is.expression(x)||is.pairlist(x)||is.list(x)) {
    for(i in seq_along(x)) {
      item <- x[i]
      if(!identical(item,alist(x=)[1L])) {
        tryCatch(walk(x[[i]],path,paste0(location,"/",i)),error=function(e) {
          if(!grepl("argument.*missing",conditionMessage(e)))stop(e)
        })
      }
    }
  }
}
for(path in sort(list.files(file.path(source,"R"),pattern="[.][rR]$",full.names=TRUE))) {
  parsed <- parse(path,keep.source=FALSE)
  walk(parsed,basename(path))
  for(x in parsed) {
    if(is.call(x)&&as.character(x[[1L]])[[1L]] %in% c("<-","=")&&is.symbol(x[[2L]])&&
       is.call(x[[3L]])&&identical(x[[3L]][[1L]],as.name("colorRampPalette"))) {
      factories[[as.character(x[[2L]])]] <- list(path=basename(path),expression=x[[3L]])
    }
  }
}
functions <- Filter(function(n)is.function(get(n,envir=ns,inherits=FALSE)),ls(ns,all.names=TRUE))
audit <- list();unmatched <- character()
for(name in functions) {
  f <- get(name,envir=ns,inherits=FALSE)
  matches <- Filter(function(x)identical(formals(f),x$formals)&&identical(body(f),x$body),definitions)
  factory <- factories[[name]]
  factory.match <- FALSE
  if(!length(matches)&&!is.null(factory)) {
    direct <- eval(factory$expression,envir=ns)
    factory.match <- identical(formals(f),formals(direct))&&identical(body(f),body(direct))
  }
  if(!length(matches)&&!factory.match)unmatched <- c(unmatched,name)
  audit[[name]] <- list(original_AST_matches=lapply(matches,function(x)x[c("path","location")]),
    original_factory_match=factory.match,factory=if(factory.match)list(path=factory$path,expression=deparse(factory$expression))else NULL,
    formals=deparse(formals(f)),body=deparse(body(f)),source_unchanged=length(matches)>0L||factory.match)
}
named <- c("build_dend","plot_constellation","i_harmonize","iter_clust_big","find_doublet_by_marker","select_N_markers","map_cells_knn_big","impute_cross_big")
stopifnot(all(named %in% functions))
deps <- c("scrattch.bigcat","arrow","BiocNeighbors","bigstatsr","leidenAlg","matrixStats","Matrix","Rcpp","RcppParallel","dplyr","ggplot2","pvclust")
versions <- setNames(lapply(deps,function(x)as.character(packageVersion(x))),deps)
record <- list(status=if(length(unmatched))"FAIL_ORIGINAL_NAMESPACE_AST_UNMATCHED"else"PASS_COMPLETE_ORIGINAL_NAMESPACE_AST_AUDIT",
  R=as.character(getRversion()),functions=length(functions),original_function_literals=length(definitions),unmatched=unmatched,
  package_versions=versions,reported_functions=named,functions_audited=audit,new_family_credit=0,whole_goal_complete=FALSE)
saveRDS(list(record=record,session=sessionInfo()),file.path(out,"complete-original-namespace-audit.rds"),version=3)
jsonlite::write_json(record,file.path(out,"AUDIT.json"),pretty=TRUE,auto_unbox=TRUE,null="null")
cat(record$status,length(functions),"functions",length(unmatched),"unmatched\n")
if(length(unmatched))quit(save="no",status=2L,runLast=FALSE)
