import org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder;
import org.junit.platform.launcher.core.LauncherFactory;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;
import org.junit.platform.engine.discovery.DiscoverySelectors;
import java.io.PrintWriter;
public class NativeTestMain {
    public static void main(String[] args) {
        var builder=LauncherDiscoveryRequestBuilder.request();
        for(String name:args)builder.selectors(DiscoverySelectors.selectClass(name));
        var listener=new SummaryGeneratingListener();
        var launcher=LauncherFactory.create();launcher.registerTestExecutionListeners(listener);
        launcher.execute(builder.build());
        var out=new PrintWriter(System.out,true);
        listener.getSummary().printTo(out);listener.getSummary().printFailuresTo(out);
        if(listener.getSummary().getTestsFailedCount()>0)System.exit(2);
    }
}
