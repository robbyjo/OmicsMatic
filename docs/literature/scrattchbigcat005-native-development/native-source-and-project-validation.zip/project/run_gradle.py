from pathlib import Path
import hashlib,json,os,subprocess,sys,xml.etree.ElementTree as ET,zipfile
ROOT=Path('D:/projects/JLinAlg');OUT=Path(__file__).resolve().parent;CHECKOUT=ROOT/'build/bigcat-native-1'
snapshot=json.loads((OUT/'TEST-SNAPSHOT.json').read_bytes())
def pin(p):
 b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
assert all(pin(CHECKOUT/n)==v and pin(ROOT/n)==v for n,v in snapshot['selected_files'].items())
command=[str(CHECKOUT/'gradlew.bat'),'test','--tests','org.jlinalg.singlecell.scrattch.ScrattchBigcat005Test',
 '--tests','org.jlinalg.singlecell.scrattch.ScrattchMapping02Test','jar','--no-daemon','--no-parallel']
with (OUT/'gradle.stdout').open('xb') as stdout,(OUT/'gradle.stderr').open('xb') as stderr:
 child=subprocess.Popen(command,cwd=CHECKOUT,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr)
 (OUT/'GRADLE-LIVE.json').write_text(json.dumps(dict(controller_pid=os.getpid(),child_pid=child.pid,command=command),indent=2)+'\n')
 while True:
  try:code=child.wait(timeout=15);break
  except subprocess.TimeoutExpired:print('SAME_ISOLATED_NATIVE_GRADLE_CHILD_RUNNING',child.pid,flush=True)
(OUT/'GRADLE-PROCESS.json').write_text(json.dumps(dict(command=command,exit_code=code),indent=2)+'\n')
if code:
 print('FAIL_ISOLATED_NATIVE_GRADLE',code,flush=True);print((OUT/'gradle.stdout').read_text(encoding='utf-8',errors='replace')[-8500:]);print((OUT/'gradle.stderr').read_text(encoding='utf-8',errors='replace')[-4500:]);raise SystemExit(code)
reports={}
for name in ['ScrattchBigcat005Test','ScrattchMapping02Test']:
 path=CHECKOUT/'build/test-results/test'/('TEST-org.jlinalg.singlecell.scrattch.'+name+'.xml')
 node=ET.parse(path).getroot();assert node.attrib['tests']=='2' and node.attrib['failures']=='0' and node.attrib['errors']=='0',node.attrib
 reports[name]=dict(node.attrib)
jar=CHECKOUT/'build/libs/omicsmatic-0.3.7.jar'
with zipfile.ZipFile(jar) as z:
 for name in ['org/jlinalg/singlecell/scrattch/ScrattchBigcat005.class','META-INF/licenses/scrattch-bigcat005.txt']:
  assert name in z.namelist(),name
 assert z.read('META-INF/licenses/scrattch-bigcat005.txt')==(ROOT/'src/main/resources/META-INF/licenses/scrattch-bigcat005.txt').read_bytes()
assert all(pin(CHECKOUT/n)==v and pin(ROOT/n)==v for n,v in snapshot['selected_files'].items()),'Selected source changed during validation'
record=dict(status='PASS_ISOLATED_NATIVE_JAVA_TESTS_AND_LIBRARY_PACKAGING',base=snapshot['base'],selected_files=snapshot['selected_files'],
 tests=reports,jar=pin(jar),native_marker_original_cases=753,native_marker_returns=303,native_marker_original_errors=450,
 native_marker_numeric_bit_comparisons=7168,existing_mapping_original_cases=318,root_Gradle_executed=False,
 shared_CLI_written=False,catalog_changed=False,new_family_credit=0,whole_goal_complete=False)
(OUT/'COMPLETED.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
