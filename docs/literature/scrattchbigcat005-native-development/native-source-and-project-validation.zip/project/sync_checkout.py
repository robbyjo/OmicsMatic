from pathlib import Path
import hashlib,json,shutil
ROOT=Path('D:/projects/JLinAlg');HERE=Path(__file__).resolve().parent;CHECKOUT=ROOT/'build/bigcat-native-1'
prepared=json.loads((HERE/'PREPARED.json').read_bytes())
selected=list(prepared['selected_files'])
selected += [p.relative_to(ROOT).as_posix() for p in (ROOT/'tools/literature/scrattchbigcat005').iterdir() if p.is_file()]
selected=sorted(set(selected))
def pin(p):
 raw=p.read_bytes();return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
for n in selected:
 target=CHECKOUT/n;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/n,target);assert pin(target)==pin(ROOT/n)
(HERE/'TEST-SNAPSHOT.json').write_text(json.dumps(dict(base=prepared['base'],selected_files={n:pin(ROOT/n) for n in selected}),indent=2)+'\n')
print('SYNCED_EXACT_NATIVE_TEST_SNAPSHOT',len(selected),flush=True)
