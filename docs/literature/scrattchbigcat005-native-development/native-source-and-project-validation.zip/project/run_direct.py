from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
ROOT=Path('D:/projects/JLinAlg');HERE=Path(__file__).resolve().parent
OUT=HERE/('direct-'+sys.argv[1]);OUT.mkdir(exist_ok=False);CLASSES=OUT/'classes';CLASSES.mkdir()
CACHE=Path('C:/Users/User/.gradle/caches/modules-2/files-2.1')
packages=['org.junit.jupiter/junit-jupiter-api','org.junit.jupiter/junit-jupiter-engine',
 'org.junit.platform/junit-platform-commons','org.junit.platform/junit-platform-engine','org.junit.platform/junit-platform-launcher',
 'org.opentest4j/opentest4j','org.apiguardian/apiguardian-api']
jars=[]
for name in packages:
 matches=list((CACHE/name).rglob('*.jar'));assert len(matches)==1,(name,matches);jars.extend(matches)
sources=[ROOT/'src/main/java/org/jlinalg/singlecell/scrattch'/n for n in ['ScrattchBigcat005.java','ScrattchMapping02.java']]
sources += [ROOT/'src/test/java/org/jlinalg/singlecell/scrattch'/n for n in ['ScrattchBigcat005Test.java','ScrattchMapping02Test.java']]
sources += [HERE/'NativeTestMain.java']
def pin(p):
 b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def run(label,command):
 command=list(map(str,command))
 with (OUT/(label+'.stdout')).open('xb') as stdout,(OUT/(label+'.stderr')).open('xb') as stderr:
  child=subprocess.run(command,cwd=OUT,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr)
 (OUT/(label+'-PROCESS.json')).write_text(json.dumps(dict(command=command,exit_code=child.returncode),indent=2)+'\n')
 return child.returncode
before={str(p):pin(p) for p in sources+jars}
java=shutil.which('java');javac=shutil.which('javac');assert java and javac
run('java-version',[java,'--version']);run('javac-version',[javac,'--version'])
cp=os.pathsep.join(map(str,jars))
assert run('compile',[javac,'--release','21','-encoding','UTF-8','-cp',cp,'-d',CLASSES,*sources])==0,'Inspect compile.stderr'
for name in ['scrattchbigcat005-native-marker-reference.zip','scrattchmapping02-native-reference.zip']:
 shutil.copyfile(ROOT/'src/test/resources'/name,CLASSES/name)
code=run('source-comparisons',[java,'-cp',str(CLASSES)+os.pathsep+cp,'NativeTestMain',
 'org.jlinalg.singlecell.scrattch.ScrattchBigcat005Test','org.jlinalg.singlecell.scrattch.ScrattchMapping02Test'])
assert before=={str(p):pin(p) for p in sources+jars},'Inputs changed concurrently'
(OUT/'COMPLETED.json' if code==0 else OUT/'FAILURE.json').write_text(json.dumps(dict(status='PASS_SOURCE_COMPARISONS' if code==0 else 'FAIL_SOURCE_COMPARISONS',
 exit_code=code,source_inputs=before,root_Gradle_executed=False,shared_CLI_written=False),indent=2)+'\n')
print('DIRECT_NATIVE_SOURCE_COMPARISON_EXIT',code,flush=True)
print((OUT/'source-comparisons.stdout').read_text(encoding='utf-8'))
raise SystemExit(code)
