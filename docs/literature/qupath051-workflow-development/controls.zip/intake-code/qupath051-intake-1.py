from pathlib import Path
import gzip,hashlib,json,re,subprocess,sys,urllib.request,xml.etree.ElementTree as ET
ROOT=Path('D:/projects/JLinAlg');OUT=Path(__file__).with_suffix('');OUT.mkdir(exist_ok=False);sys.path.insert(0,str(ROOT/'tools/literature'))
from collect_omics_review import paragraphs
from palette_allelic_catalog.model import encoded,pin,META
papers=json.loads((ROOT/'docs/literature/omics-2023-2026/papers.json').read_bytes());matches=[];census=[]
for paper in papers:
 raw=gzip.decompress((ROOT/'build/literature-review/xml'/(paper['pmcid']+'.xml.gz')).read_bytes());assert hashlib.sha256(raw).hexdigest()==paper['xml_sha256'];xml=ET.fromstring(raw)
 assert paper['doi'].lower() in [str(e.text).lower() for e in xml.findall('front/article-meta/article-id') if e.get('pub-id-type')=='doi']
 ps=paragraphs(xml);found=[]
 for p in ps:
  if re.search(r'(?<![A-Za-z0-9_])QuPath(?![A-Za-z0-9_])',p['match_text'],re.I):
   found.append(p['paragraph_index']);matches.append(dict(paper_id=paper['paper_id'],pmcid=paper['pmcid'],doi=paper['doi'],xml_sha256=paper['xml_sha256'],paragraph_index=p['paragraph_index'],section=p['section'],paragraph_sha256=hashlib.sha256(p['text'].encode('utf8')).hexdigest(),text=p['text']))
 census.append(dict(paper_id=paper['paper_id'],pmcid=paper['pmcid'],doi=paper['doi'],xml_sha256=paper['xml_sha256'],named_paragraphs=found))
(OUT/'PRIMARY_PARAGRAPHS.json').write_bytes(encoded(matches));(OUT/'CENSUS.json').write_bytes(encoded(census));(OUT/'BEFORE_METADATA.json').write_bytes(encoded({n:pin(ROOT/n) for n in META}))
def fetch(label,url):
 req=urllib.request.Request(url,headers={'User-Agent':'OmicsMatic-source-intake','Accept':'application/vnd.github+json'})
 with urllib.request.urlopen(req,timeout=60) as response:raw=response.read()
 (OUT/label).write_bytes(raw);return json.loads(raw)
release=fetch('release.json','https://api.github.com/repos/qupath/qupath/releases/tags/v0.5.1')
tag=fetch('tag-ref.json','https://api.github.com/repos/qupath/qupath/git/ref/tags/v0.5.1')
tree=fetch('source-tree.json','https://api.github.com/repos/qupath/qupath/git/trees/'+tag['object']['sha']+'?recursive=1')
print(json.dumps(dict(papers=250,qupath_papers=len({m['paper_id'] for m in matches}),named_paragraphs=len(matches),release_tag=release['tag_name'],tag_object=tag['object'],assets=[dict(name=a['name'],bytes=a['size'],url=a['browser_download_url'],digest=a.get('digest')) for a in release['assets']],license_paths=[r['path'] for r in tree['tree'] if 'license' in r['path'].lower()][:15]),indent=2),flush=True)
