from pathlib import Path
import concurrent.futures,hashlib,json,time,urllib.request,urllib.error
ROOT=Path('D:/projects/JLinAlg');BASE=ROOT/'build/literature-review/monocle-runtime';OUT=Path(__file__).with_suffix('');OUT.mkdir(exist_ok=False)
release=json.loads((BASE/'qupath051-intake-1/release.json').read_bytes());COMMIT='4e6bfc31904be7ee39c10d457149cb962002e1f2'
rows=[dict(name=a['name'],url=a['browser_download_url'],bytes=a['size']) for a in release['assets'] if a['name'] in ['QuPath-v0.5.1-Windows.zip','QuPath-v0.5.1-Linux.tar.xz']]
rows += [dict(name='qupath-'+COMMIT+'.tar.gz',url='https://codeload.github.com/qupath/qupath/tar.gz/'+COMMIT),dict(name='LICENSE-QuPath-original.txt',url='https://raw.githubusercontent.com/qupath/qupath/'+COMMIT+'/LICENSE')]
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf8',newline='\n')
def download(row):
 start=time.time();size=0;sha=hashlib.sha256();last=0;req=urllib.request.Request(row['url'],headers={'User-Agent':'OmicsMatic-original-source-intake'})
 try:
  with urllib.request.urlopen(req,timeout=90) as response,(OUT/row['name']).open('xb') as target:
   while True:
    chunk=response.read(1024*1024)
    if not chunk:break
    target.write(chunk);size+=len(chunk);sha.update(chunk)
    if size-last>=16*1024*1024:last=size;save(row['name']+'.progress.json',dict(bytes=size,started_unix=start,elapsed_seconds=time.time()-start))
  result=dict(status='DOWNLOADED_OFFICIAL_ASSET_NO_UPSTREAM_DIGEST_PUBLISHED',url=row['url'],bytes=size,sha256=sha.hexdigest(),elapsed_seconds=time.time()-start)
  if 'bytes' in row:assert size==row['bytes'],'Official release asset size differs'
  save(row['name']+'.receipt.json',result);print(row['name'],size,sha.hexdigest(),flush=True);return result
 except Exception as error:
  save(row['name']+'.failure.json',dict(status='DOWNLOAD_FAILED_NO_INSTALL_OR_ANALYSIS',url=row['url'],bytes_received=size,cause=repr(error),elapsed_seconds=time.time()-start));raise
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(download,rows))
save('DOWNLOADS.json',dict(status='COMPLETE_OFFICIAL_QUPATH051_BINARY_SOURCE_AND_LICENSE_DOWNLOADS',source_commit=COMMIT,files={r['name']:v for r,v in zip(rows,results,strict=True)},installed=False,analysis_executed=False))
