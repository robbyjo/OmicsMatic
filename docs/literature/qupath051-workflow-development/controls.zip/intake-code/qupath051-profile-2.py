from pathlib import Path
import subprocess,sys
OUT=Path(__file__).with_suffix('');OUT.mkdir(exist_ok=False)
old=Path(__file__).with_name('qupath051-profile-1.py').read_text(encoding='utf8')
for before,after in [('runtime/bin/java.exe','runtime/release'),('QuPath-v0.5.1-Linux/QuPath/lib/runtime/bin/java','QuPath-v0.5.1-Linux/QuPath/lib/runtime/release'),
 ('launcher=launcher,java=java','launcher=launcher,java_runtime_release=java,embedded_java_version="21.0.2"'),("'launcher','java'","'launcher','java_runtime_release','embedded_java_version'")]:
 assert before in old,before;old=old.replace(before,after)
script=OUT/'generate.py';script.write_text(old.replace("OUT.mkdir(exist_ok=False)","OUT.mkdir(exist_ok=False)"),encoding='utf8',newline='\n')
# Retain the first failed intake unchanged; execute a new corrected generator.
with (OUT/'process.stdout').open('xb') as so,(OUT/'process.stderr').open('xb') as se:
 result=subprocess.run([sys.executable,script],cwd='D:/projects/JLinAlg',stdin=subprocess.DEVNULL,stdout=so,stderr=se)
print((OUT/'process.stdout').read_text(),flush=True)
if result.returncode:print((OUT/'process.stderr').read_text(),flush=True)
raise SystemExit(result.returncode)
