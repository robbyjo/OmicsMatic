from pathlib import Path
import hashlib,json,sys,tarfile,zipfile
ROOT=Path('D:/projects/JLinAlg');B=ROOT/'build/literature-review/monocle-runtime';OUT=Path(__file__).with_suffix('');OUT.mkdir(exist_ok=False);HERE=ROOT/'tools/literature/qupath051'
def rawpin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def pin(p):return rawpin(p.read_bytes())
def safe(name):
 assert name and not name.startswith('/') and '\\' not in name and ':' not in name and all(k not in ['', '.', '..'] for k in name.split('/')),name
downloads=json.loads((B/'qupath051-download-1/DOWNLOADS.json').read_bytes());platforms={}
for platform,name,launcher,java in [('windows-x86_64','QuPath-v0.5.1-Windows.zip','QuPath-0.5.1 (console).exe','runtime/bin/java.exe'),
 ('linux-x86_64','QuPath-v0.5.1-Linux.tar.xz','QuPath-v0.5.1-Linux/QuPath/bin/QuPath','QuPath-v0.5.1-Linux/QuPath/lib/runtime/bin/java')]:
 archive=B/'qupath051-download-1'/name;receipt=downloads['files'][name];assert pin(archive)=={k:receipt[k] for k in ['bytes','sha256']};members={};dirs=[]
 if name.endswith('.zip'):
  with zipfile.ZipFile(archive) as z:
   assert len(z.namelist())==len(set(z.namelist()))
   for m in z.infolist():
    n=m.filename.rstrip('/');safe(n)
    if m.is_dir():dirs.append(n);continue
    assert (m.external_attr>>16)&0o170000!=0o120000
    members[n]=dict(**rawpin(z.read(m)),mode=(m.external_attr>>16)&0o777)
 else:
  with tarfile.open(archive) as t:
   infos=t.getmembers();assert len(infos)==len({m.name for m in infos})
   for m in infos:
    safe(m.name)
    if m.isdir():dirs.append(m.name);continue
    assert m.isfile() and not m.issym() and not m.islnk()
    members[m.name]=dict(**rawpin(t.extractfile(m).read()),mode=m.mode&0o777)
 assert launcher in members and java in members
 platforms[platform]=dict(archive=dict(name=name,url=receipt['url'],**pin(archive)),launcher=launcher,java=java,
  files=members,directories=sorted(dirs),file_count=len(members),installed_bytes=sum(m['bytes'] for m in members.values()))
source=B/'qupath051-source-intake-2/source';source_files={p.relative_to(source).as_posix():pin(p) for p in sorted(source.rglob('*')) if p.is_file()};assert len(source_files)==1097
source_archive=B/'qupath051-download-1/qupath-4e6bfc31904be7ee39c10d457149cb962002e1f2.tar.gz'
profile=dict(schema_version=1,version='0.5.1',repository='https://github.com/qupath/qupath',source_commit='4e6bfc31904be7ee39c10d457149cb962002e1f2',
 source_archive=dict(name=source_archive.name,url='https://codeload.github.com/qupath/qupath/tar.gz/4e6bfc31904be7ee39c10d457149cb962002e1f2',**pin(source_archive)),
 source_archive_root='qupath-4e6bfc31904be7ee39c10d457149cb962002e1f2',source_members=source_files,platforms=platforms,
 original_license=dict(name='GPL-3.0-or-later',source_path='LICENSE',**pin(source/'LICENSE')),
 asset_integrity_note='No upstream release digest was published for these assets. Pins record complete official downloads and do not authenticate the producer or prove a reproducible source build.',
 original_scientific_source_modified=False,source_build_reproduced=False,external_extensions_qualified=False,new_tool_credit=0,whole_goal_complete=False)
path=HERE/'source-profile.json';assert not path.exists();path.write_text(json.dumps(profile,indent=2)+'\n',encoding='utf8',newline='\n')
license=HERE/'licenses/LICENSE-QuPath-original.txt';license.parent.mkdir(exist_ok=False);license.write_bytes((source/'LICENSE').read_bytes())
(OUT/'PROFILE.json').write_text(json.dumps(dict(profile=pin(path),platforms={k:{n:v[n] for n in ['file_count','installed_bytes','launcher','java']} for k,v in platforms.items()},source_files=1097),indent=2)+'\n',encoding='utf8',newline='\n');print((OUT/'PROFILE.json').read_text(),flush=True)
