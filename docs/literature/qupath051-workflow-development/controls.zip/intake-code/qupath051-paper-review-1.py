from pathlib import Path
import json,re,sys
ROOT=Path('D:/projects/JLinAlg');sys.path.insert(0,str(ROOT/'tools/literature'))
from palette_allelic_catalog.model import encoded
B=ROOT/'build/literature-review/monocle-runtime';anchors=json.loads((B/'qupath051-intake-1/PRIMARY_PARAGRAPHS.json').read_bytes())
specs={
'P009':('0.5.1','Segmented DAPI nuclei, expanded cells by2 micrometers, applied manual marker thresholds and measured cell/nuclear intensities. Centroid distances defined T-cell proximity and nearest-NSC comparisons.','Manual marker thresholds, anatomic ROIs, source channels, distance choices and section/mouse aggregation are separate caller decisions. Both primary image-analysis paragraphs report0.5.1.'),
'P020':('0.6.0','Used foreground pixel classification, manual stroma exclusion and optical-density cell detection to quantify Ki-67-positive fractions, with pathologist review.','The paper reports0.6.0, not selected0.5.1. Author pixel classifiers, manual ROIs and review decisions are not recovered.'),
'P021':('unreported','Ran cell detection and subcellular RNAscope puncta detection on stitched ROIs, exported detection measurements, then summarized marker-positive cell fractions from QuPath tables.','Fiji stitching/channel alignment and downstream R summaries are separate. The output-table analysis paragraph is not another QuPath execution or a reported software edition.'),
'P024':('unreported','Selected tissue ROIs, detected DAPI nuclei/cell borders and RNAscope puncta, and exported per-cell measurements for custom cell-type/count summaries.','Fiji stitching, manually chosen ROIs/thresholds, custom Python summaries, CLR transformation and group tests are separate. No software edition or author script is inferred.'),
'P040':('0.5.1','Used original positive-cell detection on H-DAB slide ROIs with nuclear segmentation, cell expansion and cytoplasmic DAB intensity classes, then exported ROI measurements.','Numeric stain vectors and author ROI selections remain unknown. The paper reports threshold values0.08/0.16/0.24 and detailed segmentation parameters; reported area-unit wording remains literal and is not silently repaired to application units.'),
'P049':('0.4.3','Read multiplex RNA-FISH images, selected the RGC layer, detected DAPI cells and subcellular spots, then combined single-measurement and composite classifiers for double-positive cells.','The reported0.4.3 edition, LIF image-series choices, classifier thresholds and trained/custom classifier resources are separate from selected0.5.1.'),
'P056':('unreported','Performed immunohistochemistry and RNAscope image analysis and quantification.','The named primary paragraph does not specify the QuPath edition, segmentation algorithm, thresholds or exported data structure; statistical and plotting tools in the paragraph are separate.'),
'P058':('0.4.1','Manually annotated polygon ROIs, used positive-cell and composite classification for labelled nuclei, exported ROI counts and nuclear fluorescence measurements.','The paper reports0.4.1. Its coronal-series count scaling, ROI decisions and downstream Wilcoxon tests are separate. The acknowledgement of QuPath advice is not another execution.'),
'P098':('unreported','Imaging scientists quantified tumor-sample immunohistochemistry images in a blinded manner.','The primary paragraph does not identify the QuPath edition, cell algorithm or thresholds. Blinding and study-design statements are not algorithm settings.'),
'P158':('v.0.2.3 to v.0.4.3','Used custom StarDist-based nuclei classification, manual channel-intensity thresholds and exported nuclei measurements for downstream expression summaries.','The literal reported edition range is retained and does not include selected0.5.1. The custom StarDist classifier/extension, trained model, manual thresholds and Python summaries are separate; stock QuPath alone does not recover them.'),
'P161':('unreported','Aligned H&E slide images and supported pathologist histologic-neighborhood annotations, whose locations were used downstream in spatial analysis.','The transformation/registration algorithm, annotation decisions and QuPath edition are unreported. GeoPandas, SCANPY, CellPhoneDB and CytoSignal roles remain separate.'),
'P226':('unreported','Detected H2B-mRuby nuclei, expanded them2 micrometers to define perinuclear regions and filtered detections using morphology and fluorescence measurements.','Rolling-ball background subtraction was done in Nikon NIS Elements. QuPath edition and filtering thresholds are unreported; no preprocessing or threshold choice is inferred.')}
rows=[]
for paper_id,(version,summary,scope) in specs.items():
 found=[a for a in anchors if a['paper_id']==paper_id];assert found
 rows.append(dict(paper_id=paper_id,pmcid=found[0]['pmcid'],doi=found[0]['doi'],primary_xml_sha256=found[0]['xml_sha256'],
  version_reported_near_name=version,use_summary=summary,implementation_scope_note=scope,
  review_scope='Complete named primary paragraphs; broad whole-paper semantic review remains open.',
  supporting_evidence=[{k:a[k] for k in ['paragraph_index','paragraph_sha256','section']} for a in found],
  named_anchor_classification={str(a['paragraph_index']):('acknowledgement-only' if (paper_id,a['paragraph_index'])==('P058',73) else 'downstream-output-table-analysis' if (paper_id,a['paragraph_index'])==('P021',78) else 'image-analysis-role') for a in found}))
assert len(rows)==12 and sum(len(r['supporting_evidence']) for r in rows)==16
path=ROOT/'tools/literature/qupath051/paper-use-intake.json';assert not path.exists()
path.write_bytes(encoded(dict(status='TWELVE_INDIVIDUAL_PRIMARY_QUPATH_ROLE_REVIEWS_NOT_MAIN_CATALOG_ADMISSION',reviews=rows,
 selected_original_version='0.5.1',selected_source_commit='4e6bfc31904be7ee39c10d457149cb962002e1f2',
 source_census_papers=250,named_papers=12,named_paragraphs=16,main_catalog_modified=False,new_tool_credit=0,whole_goal_complete=False)))
print('Recorded12 individual paper-family roles and all16 named anchors, preserving version ranges and separate custom/other-tool work',flush=True)
