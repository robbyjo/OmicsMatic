import java.nio.file.*
import java.nio.charset.StandardCharsets
def root = Paths.get(args[0])
Files.writeString(root.resolve('complete.txt'), 'full original class=' + Class.forName('qupath.lib.images.ImageData').getName() + '\n', StandardCharsets.UTF_8)
return 'QUPATH051_COMPLETE_ORIGINAL_SCRIPT'
