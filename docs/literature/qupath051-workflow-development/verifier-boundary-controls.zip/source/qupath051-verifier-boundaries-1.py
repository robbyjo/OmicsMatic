from pathlib import Path
import copy,hashlib,json,shutil,subprocess,sys,time,zipfile
ROOT=Path('D:/projects/JLinAlg');BASE=ROOT/'build/literature-review/monocle-runtime';OUT=Path(__file__).with_suffix('');OUT.mkdir(exist_ok=False)
DATA='docs/literature/qupath051-workflow-development';original=ROOT/DATA;proof=json.loads((original/'VALIDATION.json').read_bytes())
def pin(path):
 raw=path.read_bytes();return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def rawpin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf8',newline='\n')
before={p.name:pin(p) for p in original.iterdir() if p.is_file()};calls=[]
for case in ['changed-current-source','missing-artifact','resealed-portable-result','resealed-missing-raw-hierarchy']:
 scope=OUT/case;scope.mkdir();root=scope/'repo';root.mkdir();assert root.resolve().is_relative_to(BASE.resolve())
 for name in proof['sources']:
  target=root/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/name,target)
 data=root/DATA;data.mkdir(parents=True,exist_ok=True)
 for source in original.iterdir():
  if source.is_file():shutil.copyfile(source,data/source.name)
 if case=='changed-current-source':
  target=root/'src/main/java/org/jlinalg/cli/QuPath051WorkflowCli.java';target.write_bytes(target.read_bytes()+b'\n// Deliberately changed isolated fake source for refusal testing.\n')
 elif case=='missing-artifact':
  target=next(data.glob('*windows21-development.jar'));assert target.resolve().is_relative_to(root.resolve());target.unlink()
 else:
  path=data/'controls.zip';layout=json.loads((data/'CONTROLS_LAYOUT.json').read_bytes());v=json.loads((data/'VALIDATION.json').read_bytes())
  with zipfile.ZipFile(path) as z:members={name:z.read(name) for name in z.namelist()}
  prefix='public/windows21/actual/complete-cells/';manifest=json.loads(members[prefix+'MANIFEST.json'])
  if case=='resealed-portable-result':
   name=prefix+'results/all-16.measurements.tsv';members[name]+=b'DELIBERATE_FAKE_CONTROL_ROW\n';manifest['files']['results/all-16.measurements.tsv'].update(rawpin(members[name]));layout['files'][name]=rawpin(members[name])
  else:
   name=prefix+'results/blank.raw.qpdata';del members[name];del layout['files'][name];del manifest['files']['results/blank.raw.qpdata']
  members[prefix+'MANIFEST.json']=(json.dumps(manifest,sort_keys=True)+'\n').encode();layout['files'][prefix+'MANIFEST.json']=rawpin(members[prefix+'MANIFEST.json'])
  rebuilt=scope/'deliberately-resealed-controls.zip'
  with zipfile.ZipFile(rebuilt,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
   for name,raw in members.items():z.writestr(name,raw)
  shutil.copyfile(rebuilt,path);save(data/'CONTROLS_LAYOUT.json',layout);v['archive']=pin(path);v['controls_layout']=pin(data/'CONTROLS_LAYOUT.json');save(data/'VALIDATION.json',v)
  (data/'SHA256SUMS').write_text(''.join(pin(data/name)['sha256']+'  '+name+'\n' for name in ['controls.zip','CONTROLS_LAYOUT.json','ARTIFACTS.json','CENSUS.json','VALIDATION.json']),encoding='ascii',newline='\n')
 command=[sys.executable,root/'tools/literature/qupath051/verify.py','--out',root/'build/literature-review/monocle-runtime/verify-control'];start=time.time();result=subprocess.run(list(map(str,command)),stdin=subprocess.DEVNULL,capture_output=True,timeout=120);expected_exit=3 if case=='missing-artifact' else 2
 (scope/'process.stdout').write_bytes(result.stdout);(scope/'process.stderr').write_bytes(result.stderr);row=dict(case=case,command=list(map(str,command)),exit_code=result.returncode,expected_exit=expected_exit,elapsed_seconds=time.time()-start);calls.append(row);save(scope/'process.json',row)
 if result.returncode!=expected_exit:raise ValueError('Frozen saved-evidence gate did not reject/skip '+case)
 diagnostic=json.loads((root/'build/literature-review/monocle-runtime/verify-control/FAILURE.json').read_bytes())
 expected={'changed-current-source':'Qualified source differs','missing-artifact':None,'resealed-portable-result':'Complete portable original output differs','resealed-missing-raw-hierarchy':'Incomplete25-file original scientific output population'}[case]
 # Missing artifacts skip dependent verification; contradictory or forged data fail.
 if expected and expected not in diagnostic['cause']:raise ValueError('Refusal came from an unrelated guard: '+case+': '+diagnostic['cause'])
 print(case,'rejected',flush=True)
assert all(pin(original/name)==wanted for name,wanted in before.items()),'Actual qualified data changed'
save(OUT/'COMPLETED.json',dict(status='PASS_FROZEN_QUPATH_VERIFIER_SOURCE_ARTIFACT_AND_RESEALED_FULL_RESULT_REFUSALS',controls=4,calls=calls,actual_qualified_data_unchanged=True,original_analysis_executed=False))
