"""Publish handover/publication/cleanup receipts without changing scientific source."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,subprocess,sys,urllib.parse,urllib.request,zipfile
from handover_inventory_20261122_111 import snapshot,save,pin,git,entries
R=Path('D:/projects/JLinAlg');T=R/'build/fu-1';O=R/'build/git-publish/20261123-scenic-capture-303';P=T/'docs/literature/scenic-workflow-checkpoint-20261123'
source=json.loads((O/'PUSHED.json').read_bytes());base=source['commit'];cleanup=json.loads((O/'CLEANUP.json').read_bytes())
assert cleanup['status']=='COMPLETE_VERIFIED_REDUNDANT_COMPILER_COPIES_ONLY'
assert git('rev-parse','HEAD',cwd=T).decode().strip()==base
assert git('ls-remote','origin','refs/heads/main',cwd=T).decode().split()[0]==base
assert not git('diff','--cached','--name-only',cwd=T)
reader=subprocess.run([sys.executable,'-X','utf8','-B',str(T/'tools/literature/verify_scenic_workflow_checkpoint.py'),'--jar',str(T/'build/scenic-3/normal-build-4/project-build/cli/omicsmatic-0.4.0.jar')],cwd=T,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(O/'FINAL-READER.stdout').write_bytes(reader.stdout);(O/'FINAL-READER.stderr').write_bytes(reader.stderr);assert reader.returncode==0,reader.stderr
owners=snapshot();initial=json.loads((O/'WORKTREES-BEFORE.json').read_bytes());assert len(owners)==len(initial)==19
for old in initial:
 if Path(old['worktree'])!=T:assert next(r for r in owners if r['worktree']==old['worktree'])==old,old['worktree']
indexes=json.loads((O/'INDEXES-BEFORE.json').read_bytes());assert all(pin(Path(row['path']))==row['identity'] for owner,row in indexes.items() if Path(owner)!=T)
items={}
for number in range(348,355):
 for f in (R/'build').glob('*20261123_'+str(number)+'.*'):
  if f.suffix in ('.py','.ps1'):items['helpers/'+f.name]=f.read_bytes()
for name in ('PUBLICATION-FILES.json','RAW-READBACK.json','HOSTED-RUNS.json','PRESERVATION-AFTER.json','CLEANUP-PLAN.json','CLEANUP.json','FINAL-READER.stdout','FINAL-READER.stderr'):items['receipts/'+name]=(O/name).read_bytes()
manifest={name:dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()) for name,raw in sorted(items.items())}
with zipfile.ZipFile(P/'finalization.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,raw in sorted(items.items()):
  info=zipfile.ZipInfo(name,date_time=(2026,11,23,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,raw)
save(P/'FINALIZATION-FILES.json',manifest)
save(P/'PUBLICATION.json',dict(status='IMPLEMENTATION_PUBLICATION_AND_POST_PUBLICATION_COMPILER_CLEANUP_RECORDED',implementation_commit=base,implementation_files_byte_exact_on_public_GitHub=len(json.loads((O/'RAW-READBACK.json').read_bytes())['files']),only_pushed_ref='refs/heads/main',force=False,finalization_archive=pin(P/'finalization.zip'),finalization_manifest=pin(P/'FINALIZATION-FILES.json'),cleanup=pin(P/'CLEANUP.json'),after_cleanup_checkpoint_reader=json.loads(reader.stdout),other_worktrees_preserved=18,total_worktrees_retained=19,other_indexes_preserved=18,restricted_histories_exported=False,installed_runtime_or_executable_JAR_published=False,whole_goal_complete=False))
readme=P/'README.md';readme.write_bytes(readme.read_bytes()+b'\n`PUBLICATION.json` records the implementation commit and public byte readback.\n`CLEANUP.json` lists only removed, verified redundant compiler copies and their\nrecovery locations. `finalization.zip` and `FINALIZATION-FILES.json` retain the\nexact readback/cleanup helper sources and receipts; private worktree inventories\nand restricted historical payloads are excluded. Exact JARs, runtimes, source,\nscientific captures and failed unit contexts remain retained locally.\n')
names=sorted('docs/literature/scenic-workflow-checkpoint-20261123/'+name for name in ('CLEANUP.json','FINALIZATION-FILES.json','PUBLICATION.json','README.md','finalization.zip'))
assert set(r['path'] for r in entries(T))==set(names)
git('add','--',*names,cwd=T);git('diff','--cached','--check',cwd=T)
assert set(git('diff','--cached','--name-only','-z',cwd=T).decode().strip('\0').split('\0'))==set(names)
for name in names:assert git('show',':'+name,cwd=T)==(T/name).read_bytes(),name
save(O/'FINALIZATION-PUBLICATION-FILES.json',{name:pin(T/name) for name in names})
print(git('commit','-m','Record SCENIC handover publication and verified compiler cleanup',cwd=T).decode(),flush=True)
head=git('rev-parse','HEAD',cwd=T).decode().strip();save(O/'FINALIZATION-COMMITTED.json',dict(commit=head,implementation_commit=base,files=len(names)))
p=subprocess.run(['git','push','origin',head+':refs/heads/main'],cwd=T,stdout=subprocess.PIPE,stderr=subprocess.PIPE);(O/'final-push.stdout').write_bytes(p.stdout);(O/'final-push.stderr').write_bytes(p.stderr)
assert p.returncode==0,p.stderr
assert git('ls-remote','origin','refs/heads/main',cwd=T).decode().split()[0]==head
git('fetch','--no-tags','origin','main',cwd=T)
def read(name):
 url='https://raw.githubusercontent.com/robbyjo/OmicsMatic/'+head+'/'+urllib.parse.quote(name,safe='/')
 with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'OmicsMatic-handover-readback'}),timeout=45) as response:raw=response.read()
 assert raw==(T/name).read_bytes(),name
 return name,pin(T/name)
with ThreadPoolExecutor(max_workers=5) as pool:readback=dict(pool.map(read,names))
assert not git('status','--porcelain=v1',cwd=T)
after=snapshot();save(O/'WORKTREES-FINAL.json',after)
for old in initial:
 now=next(r for r in after if r['worktree']==old['worktree'])
 if Path(old['worktree'])==T:assert now['HEAD']==head and now['status']==[]
 else:assert now==old,old['worktree']
assert all(pin(Path(row['path']))==row['identity'] for owner,row in indexes.items() if Path(owner)!=T)
unmerged=git('for-each-ref','--no-merged=refs/remotes/origin/main','--format=%(refname) %(objectname)','refs/heads').decode().splitlines();assert unmerged==json.loads((O/'UNPUBLISHED-REFS-BEFORE.json').read_bytes())['refs']
save(O/'FINALIZATION-PUSHED.json',dict(commit=head,implementation_commit=base,public_readback=readback,only_ref='refs/heads/main',force=False,worktrees=19,other_owners_and_indexes_identical=18,current_checkout_clean=True,verified_removed_content_bytes=cleanup['verified_file_bytes'],measured_free_space_change=cleanup['measured_free_space_change'],whole_goal_complete=False))
print(json.dumps(dict(main=head,implementation_commit=base,implementation_files=45,finalization_files=len(readback),all_public_bytes_checked=True,other_owners_preserved=18,verified_removed_content_bytes=cleanup['verified_file_bytes'],measured_free_space_change=cleanup['measured_free_space_change']),indent=2))
