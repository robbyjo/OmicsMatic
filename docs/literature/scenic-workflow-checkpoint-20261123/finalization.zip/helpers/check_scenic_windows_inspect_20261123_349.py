"""Check saved final Linux capture with the same exact JAR on Windows JVMs."""
from pathlib import Path
import json,subprocess
T=Path('D:/projects/JLinAlg/build/fu-1');B=T/'build/scenic-3';D=B/'windows-inspect-1';D.mkdir();rows=[]
jar=B/'normal-build-4/project-build/cli/omicsmatic-0.4.0.jar';capture=B/'java-probe-4/run'
for host,java in [('windows21','C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe'),('windows25','C:/Program Files/Java/jdk-25/bin/java.exe')]:
 args=[java,'-jar',str(jar),'scenic-tools','--inspect',str(capture)]
 p=subprocess.run(args,cwd=T,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 (D/(host+'.stdout')).write_bytes(p.stdout);(D/(host+'.stderr')).write_bytes(p.stderr)
 row=dict(host=host,exit_code=p.returncode,stdout=p.stdout.decode('utf-8'),stderr=p.stderr.decode('utf-8'),fresh_scientific_fit_executed=False);rows.append(row)
 assert p.returncode==0,row
result=dict(status='PASS_FINAL_LINUX_CAPTURE_INSPECTION_ON_WINDOWS21_AND_WINDOWS25',checks=rows,exact_same_producer_JAR=True)
(D/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
path=T/'docs/literature/scenic-workflow-checkpoint-20261123/READBACK.json';readback=json.loads(path.read_bytes());readback['additional_capture_inspection']=result;path.write_text(json.dumps(readback,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
