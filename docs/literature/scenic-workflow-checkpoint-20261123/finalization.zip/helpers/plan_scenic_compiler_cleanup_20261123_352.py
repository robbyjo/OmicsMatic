"""Identify only exact redundant compiler copies recoverable from retained artifacts."""
from pathlib import Path
import hashlib,json,zipfile
from handover_inventory_20261122_111 import pin,save
R=Path('D:/projects/JLinAlg');T=R/'build/fu-1';B=T/'build/scenic-3';O=R/'build/git-publish/20261123-scenic-capture-303';P=T/'docs/literature/scenic-workflow-checkpoint-20261123'
assert json.loads((O/'RAW-READBACK.json').read_bytes())['failures']=={}
manifest=json.loads((P/'FILES.json').read_bytes());omissions=json.loads((P/'OMISSIONS.json').read_bytes());omitted={row['path']:row['identity'] for row in omissions['individual_omissions']}
candidates=[]
for number in range(1,5):candidates.append((B/f'normal-build-{number}/project-build/classes/java/main',B/f'normal-build-{number}/project-build/cli/omicsmatic-0.4.0.jar'))
for number in range(1,4):candidates.append((B/f'development-build-{number}/classes',B/f'development-build-{number}/scenic-development.jar'))
for number in (2,3,4):
 for host in ('windows21','windows25','linux21'):candidates.append((B/f'unit-check-{number}/{host}/classes',None))
plan=[];retained=[]
for directory,jar in candidates:
 if not directory.exists():continue
 files=sorted(p for p in directory.rglob('*') if p.is_file());assert files and all(p.suffix=='.class' and not p.is_symlink() for p in files)
 rows={p.relative_to(directory).as_posix():pin(p) for p in files}
 if jar:
  identity=pin(jar)
  expected=json.loads((B/jar.relative_to(B).parts[0]/'RESULT.json').read_bytes())['producer'] if jar.name!='scenic-development.jar' else omitted[jar.relative_to(B).as_posix()]
  assert identity=={k:v for k,v in expected.items() if k!='path'}
  with zipfile.ZipFile(jar) as z:
   equal=all(name in z.namelist() and z.read(name)==(directory/name).read_bytes() for name in rows)
  if not equal:retained.append(dict(path=str(directory),reason='Not every class was byte-identical to the retained producer'));continue
  recovery=dict(kind='retained_exact_JAR',path=str(jar),identity=identity)
 else:
  assert all(manifest[(directory/name).relative_to(B).as_posix()]==identity for name,identity in rows.items())
  recovery=dict(kind='public_content_addressed_evidence_archive',path='docs/literature/scenic-workflow-checkpoint-20261123/evidence.zip',logical_prefix=directory.relative_to(B).as_posix(),identity=pin(P/'evidence.zip'))
 plan.append(dict(path=str(directory),files=rows,file_count=len(rows),bytes=sum(row['bytes'] for row in rows.values()),recovery=recovery))
save(O/'CLEANUP-PLAN.json',dict(task_root=str(B),directories=plan,retained=retained,remove_worktrees=False,remove_JARs=False,remove_runtimes=False,remove_scientific_captures=False,failed_unit_context_preserved=True))
print(json.dumps(dict(directories=len(plan),verified_redundant_bytes=sum(row['bytes'] for row in plan),files=sum(row['file_count'] for row in plan),retained=retained),indent=2))
