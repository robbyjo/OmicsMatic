"""Publish the selected, reviewed workflow and handover; preserve every owner."""
from pathlib import Path
import ast,hashlib,json,subprocess
from handover_inventory_20261122_111 import snapshot,save,pin,git,entries
R=Path('D:/projects/JLinAlg');T=R/'build/fu-1';O=R/'build/git-publish/20261123-scenic-capture-303';P=T/'docs/literature/scenic-workflow-checkpoint-20261123';base='045618f5f62b8b6ad24bab68faf546ed760007fc'
assert git('rev-parse','HEAD',cwd=T).decode().strip()==base
assert not git('diff','--cached','--name-only',cwd=T)
assert git('ls-remote','origin','refs/heads/main',cwd=T).decode().split()[0]==base
owners=snapshot();save(O/'WORKTREES-BEFORE-PUSH.json',owners)
initial=json.loads((O/'WORKTREES-BEFORE.json').read_bytes());assert len(owners)==len(initial)==19
for old in initial:
 now=next(r for r in owners if r['worktree']==old['worktree'])
 if Path(old['worktree'])!=T:assert now==old,old['worktree']
indexes=json.loads((O/'INDEXES-BEFORE.json').read_bytes())
assert all(pin(Path(row['path']))==row['identity'] for owner,row in indexes.items() if Path(owner)!=T)
unmerged=git('for-each-ref','--no-merged=refs/remotes/origin/main','--format=%(refname) %(objectname)','refs/heads').decode().splitlines()
save(O/'UNPUBLISHED-REFS-BEFORE.json',dict(refs=unmerged));assert len(unmerged)==10 and all('codex/handover-20261122-owner' in r or 'codex/release-v0.3.1 ' in r for r in unmerged)
fixed=['.gitattributes','docs/literature/HANDOVER_CURRENT.md','docs/literature/HANDOVER_2026-11-23.md','docs/literature/HANDOVER_SCENIC_WORKFLOW_2026-11-23.md','docs/literature/SCENIC_WORKFLOWS.md','src/main/java/org/jlinalg/cli/JLinAlgCli.java','tools/literature/scenic_dispatch_compatibility.py','tools/literature/verify_scenic_workflow_checkpoint.py']
names=set(fixed)
for pattern in ('src/main/java/org/jlinalg/cli/Scenic*.java','src/test/java/org/jlinalg/cli/Scenic*.java','src/main/resources/org/jlinalg/omics/scenic-workflow/*','tools/literature/scenic_workflow/*','examples/scenic-workflow/*','examples/scenic-workflow/.gitignore','docs/literature/scenic-workflow-checkpoint-20261123/*'):
 names.update(p.relative_to(T).as_posix() for p in T.glob(pattern) if p.is_file())
names=sorted(names);assert set(r['path'] for r in entries(T))==set(names)
for name in names:
 p=T/name;assert p.stat().st_size<8_000_000,name
 if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'),filename=name)
git('diff','--check',cwd=T)
state=json.loads((P/'READBACK.json').read_bytes());assert len(state['readers'])==2 and len(state['controls'])==3 and len(state['additional_capture_inspection']['checks'])==2
git('add','--',*names,cwd=T)
assert set(git('diff','--cached','--name-only','-z',cwd=T).decode().strip('\0').split('\0'))==set(names)
git('diff','--cached','--check',cwd=T)
files={}
for name in names:
 raw=git('show',':'+name,cwd=T);assert raw==(T/name).read_bytes(),('Staged conversion',name)
 files[name]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
save(O/'PUBLICATION-FILES.json',files)
print(git('commit','-m','Add scoped SCENIC workflows and save validated toolbox handover',cwd=T).decode(),flush=True)
head=git('rev-parse','HEAD',cwd=T).decode().strip();save(O/'COMMITTED.json',dict(commit=head,base=base,files=len(files)))
p=subprocess.run(['git','push','origin',head+':refs/heads/main'],cwd=T,stdout=subprocess.PIPE,stderr=subprocess.PIPE);(O/'push.stdout').write_bytes(p.stdout);(O/'push.stderr').write_bytes(p.stderr);save(O/'PUSH.json',dict(commit=head,exit_code=p.returncode,force=False,only_ref='refs/heads/main'))
if p.returncode:raise RuntimeError(p.stderr.decode(errors='replace'))
assert git('ls-remote','origin','refs/heads/main',cwd=T).decode().split()[0]==head
git('fetch','--no-tags','origin','main',cwd=T);assert git('rev-parse','refs/remotes/origin/main',cwd=T).decode().strip()==head
assert not git('status','--porcelain=v1',cwd=T)
save(O/'PUSHED.json',dict(commit=head,files=len(files),force=False,restricted_refs_exported=False))
print(json.dumps(dict(main=head,files=len(files),push_verified=True,all_other_owners_and_indexes_preserved=18),indent=2))
