$ErrorActionPreference = 'Stop'
$taskRoot = [IO.Path]::GetFullPath('D:\projects\JLinAlg\build\fu-1\build\scenic-3')
$workspaceRoot = [IO.Path]::GetFullPath('D:\projects\JLinAlg')
$receiptRoot = 'D:\projects\JLinAlg\build\git-publish\20261123-scenic-capture-303'
$plan = Get-Content -LiteralPath (Join-Path $receiptRoot 'CLEANUP-PLAN.json') -Raw | ConvertFrom-Json
if ([IO.Path]::GetFullPath($plan.task_root) -cne $taskRoot) { throw 'Unexpected cleanup root' }
$active = @(Get-CimInstance Win32_Process -Filter "Name='java.exe' OR Name='python.exe' OR Name='python3.exe'" | Where-Object {$_.CommandLine -and $_.CommandLine.Replace('/','\').Contains($taskRoot)})
if ($active.Count -ne 0) { throw 'A process still references the feature evidence root; preserve all compiler copies' }
$linux = & wsl.exe -d JLinAlg-Omics-SAIGE-20261026 -- /bin/ps -C java,python,python3,python3.10 -o pid=,comm=
if ($LASTEXITCODE -ne 1 -or $linux) { throw 'A Linux Java/Python process remains or process inspection failed; preserve copies' }
$checked = @()
foreach ($item in $plan.directories) {
    $target = [IO.Path]::GetFullPath($item.path)
    if (-not $target.StartsWith($taskRoot + '\', [StringComparison]::OrdinalIgnoreCase)) { throw "Path escapes feature root: $target" }
    if ($target -notmatch '\\(classes|classes\\java\\main)$') { throw "Not an approved compiler-copy directory: $target" }
    $resolved = (Resolve-Path -LiteralPath $target).ProviderPath
    if ($resolved -cne $target) { throw "Resolved cleanup target changed: $target" }
    $cursor = $target
    while ($cursor.Length -ge $workspaceRoot.Length) {
        if ((Get-Item -LiteralPath $cursor -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Reparse point: $cursor" }
        $cursor = Split-Path -Parent $cursor
    }
    $children = @(Get-ChildItem -LiteralPath $target -Force -Recurse)
    if (@($children | Where-Object {$_.Attributes -band [IO.FileAttributes]::ReparsePoint}).Count) { throw "Nested reparse point: $target" }
    $files = @($children | Where-Object {-not $_.PSIsContainer})
    if ($files.Count -ne $item.file_count) { throw "Compiler-copy member count changed: $target" }
    foreach ($file in $files) {
        $relative = $file.FullName.Substring($target.Length + 1).Replace('\','/')
        $saved = $item.files.PSObject.Properties[$relative]
        if (-not $saved -or $file.Extension -cne '.class' -or $file.Length -ne $saved.Value.bytes) { throw "Unexpected compiler member: $($file.FullName)" }
        $hash = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($hash -cne $saved.Value.sha256) { throw "Compiler copy changed: $($file.FullName)" }
    }
    if ($item.recovery.kind -eq 'retained_exact_JAR') {
        $jar = Get-Item -LiteralPath $item.recovery.path
        if ($jar.Length -ne $item.recovery.identity.bytes -or (Get-FileHash -LiteralPath $jar.FullName -Algorithm SHA256).Hash.ToLowerInvariant() -cne $item.recovery.identity.sha256) { throw 'Recovery JAR changed' }
    } else {
        $archive = 'D:\projects\JLinAlg\build\fu-1\docs\literature\scenic-workflow-checkpoint-20261123\evidence.zip'
        if ((Get-Item -LiteralPath $archive).Length -ne $item.recovery.identity.bytes -or (Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -cne $item.recovery.identity.sha256) { throw 'Recovery archive changed' }
    }
    $checked += [PSCustomObject]@{path=$target;files=$item.file_count;bytes=$item.bytes;recovery=$item.recovery}
    Write-Output "Verified compiler-copy directory $($checked.Count)/$(@($plan.directories).Count): $($item.file_count) files"
}
$before = ([IO.DriveInfo]::new('D:\')).AvailableFreeSpace
$removed = @()
foreach ($item in $checked) {
    Remove-Item -LiteralPath $item.path -Recurse -Force
    if (Test-Path -LiteralPath $item.path) { throw "Cleanup target remains: $($item.path)" }
    $removed += $item
    Write-Output "Removed verified compiler-copy directory $($removed.Count)/$($checked.Count)"
}
$after = ([IO.DriveInfo]::new('D:\')).AvailableFreeSpace
$receipt = [ordered]@{status='COMPLETE_VERIFIED_REDUNDANT_COMPILER_COPIES_ONLY';time_utc=[DateTime]::UtcNow.ToString('o');root=$taskRoot;removed=$removed;removed_directories=$removed.Count;removed_files=($removed | Measure-Object -Property files -Sum).Sum;verified_file_bytes=($removed | Measure-Object -Property bytes -Sum).Sum;disk_free_before=$before;disk_free_after=$after;measured_free_space_change=$after-$before;note='Measured free-space change includes filesystem allocation and unrelated system activity; verified_file_bytes is the exact redundant file content removed.';preserved=@('all 19 worktrees','all source and local edits','all exact executable JARs','all installed runtimes','all scientific captures and raw failures','failed unit-check-1 context','all test reports and source contexts','restricted histories');linux_java_python_processes_at_check=0;windows_processes_referencing_task_root_at_check=0;plan_sha256=(Get-FileHash -LiteralPath (Join-Path $receiptRoot 'CLEANUP-PLAN.json') -Algorithm SHA256).Hash.ToLowerInvariant()}
$json = $receipt | ConvertTo-Json -Depth 15
[IO.File]::WriteAllText((Join-Path $receiptRoot 'CLEANUP.json'), $json + "`n", [Text.UTF8Encoding]::new($false))
[IO.File]::WriteAllText('D:\projects\JLinAlg\build\fu-1\docs\literature\scenic-workflow-checkpoint-20261123\CLEANUP.json', $json + "`n", [Text.UTF8Encoding]::new($false))
$receipt | Select-Object status,removed_directories,removed_files,verified_file_bytes,measured_free_space_change | ConvertTo-Json
