"""Record current checkpoint readback and controlled metadata/source refusals."""
from pathlib import Path
from unittest.mock import patch
import importlib.util,json,subprocess,sys
R=Path('D:/projects/JLinAlg');T=R/'build/fu-1';B=T/'build/scenic-3';D=B/'checkpoint-readback-1';D.mkdir();P=T/'docs/literature/scenic-workflow-checkpoint-20261123'
def save(path,obj):path.write_text(json.dumps(obj,indent=2)+'\n',encoding='utf-8')
reader=T/'tools/literature/verify_scenic_workflow_checkpoint.py';jar=B/'normal-build-4/project-build/cli/omicsmatic-0.4.0.jar'
records=[]
for host,args in [('windows',[sys.executable,'-X','utf8','-B',str(reader),'--jar',str(jar)]),('linux',['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/python3','-B','/mnt/d/projects/JLinAlg/build/fu-1/tools/literature/verify_scenic_workflow_checkpoint.py','--jar','/mnt/d/projects/JLinAlg/build/fu-1/build/scenic-3/normal-build-4/project-build/cli/omicsmatic-0.4.0.jar'])]:
 result=subprocess.run(args,cwd=T,stdout=subprocess.PIPE,stderr=subprocess.PIPE);(D/(host+'.stdout')).write_bytes(result.stdout);(D/(host+'.stderr')).write_bytes(result.stderr)
 assert result.returncode==0,(host,result.stderr)
 records.append(dict(host=host,exit_code=result.returncode,measured=json.loads(result.stdout)))
sys.path.insert(0,str(reader.parent));spec=importlib.util.spec_from_file_location('scenic_checkpoint_control',reader);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
original_read=Path.read_bytes;controls=[]
for label,target,change in [('false-credit',P/'STATUS.json',lambda raw:json.dumps(dict(json.loads(raw),new_family_credit=1)).encode()),('changed-archive',P/'evidence.zip',lambda raw:raw[:-1]+bytes([raw[-1]^1])),('changed-source',T/'src/main/java/org/jlinalg/cli/ScenicWorkflowContracts.java',lambda raw:raw+b'\n// controlled change\n')]:
 def changed_read(path):
  raw=original_read(path)
  return change(raw) if path==target else raw
 with patch.object(Path,'read_bytes',changed_read):
  try:module.verify(T)
  except ValueError as error:controls.append(dict(case=label,refused=True,error=str(error),physical_files_changed=False))
  else:raise AssertionError('Controlled change was accepted: '+label)
save(D/'RESULT.json',dict(status='PASS_CHECKPOINT_READBACK_AND_THREE_IN_MEMORY_CHANGE_CONTROLS',readers=records,controls=controls,physical_files_changed=False,fresh_scientific_fit_executed=False))
save(P/'READBACK.json',json.loads((D/'RESULT.json').read_bytes()))
print(json.dumps(dict(readers_passed=len(records),change_controls_refused=len(controls),fresh_scientific_fit_executed=False),indent=2))
