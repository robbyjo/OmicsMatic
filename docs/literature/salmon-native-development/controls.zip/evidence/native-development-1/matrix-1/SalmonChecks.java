import java.io.*;
import java.nio.*;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import org.jlinalg.sequence.SalmonInferentialReplicates;
import org.junit.platform.launcher.core.*;
import org.junit.platform.launcher.listeners.*;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;
public class SalmonChecks {
 public static void main(String[] args)throws Exception {
  if(!SalmonInferentialReplicates.class.getProtectionDomain().getCodeSource().getLocation().toURI().equals(new File(args[0]).toURI()))throw new AssertionError("Wrong actual JAR");
  var listener=new SummaryGeneratingListener();LauncherFactory.create().execute(LauncherDiscoveryRequestBuilder.request().selectors(selectClass("org.jlinalg.sequence.SalmonInferentialReplicatesTest")).build(),listener);
  var s=listener.getSummary();s.printTo(new PrintWriter(System.out));s.printFailuresTo(new PrintWriter(System.out));
  if(s.getTestsFoundCount()!=27||s.getTestsSucceededCount()!=27||s.getTestsSkippedCount()!=0||s.getTestsAbortedCount()!=0||s.getTestsFailedCount()!=0||s.getContainersFailedCount()!=0)throw new AssertionError("Incomplete native checks");
  long total=0;
  for(String[] spec:new String[][]{{"1.0.0/paired-em-bias-50","50","2000","cb6d1beb37fec3deb41a9898aea8cd026d5ec6b1d8577d36bff323750a90a428"},{"1.0.0/paired-vb-pos-100","100","4000","e0b01573f346ac65d274e6b3d269d670e8a376e18fc8018fc9e743a3256179b1"},{"1.0.0/single-em-5","5","200","9e7b2c0b655eccc62e5f586a4bbe31d734dcb2bceee861a66f435bc8fa402578"},{"1.0.0/alignment-em-3","3","120","e03d09bf6d573dc770309509864c37362316716b43d52ae6f0f328ec6d87fa87"},{"1.1.0/paired-em-bias-50","50","2000","0bd20f1e2209b42ccbc6aacf8e0fe7c7f156f471a40b26a0f069ccca22e2606e"},{"1.1.0/paired-vb-pos-100","100","4000","c3b2e0d0d5c95e28288a31ac0fe2667b8b2ede1281e50b64e019183d08dbcd38"},{"1.1.0/single-em-5","5","200","e9621a89c07635eb0fbc3226f6176636b4f2b898a843ed0de479593065f1898e"},{"1.1.0/alignment-em-3","3","120","53fb5fe4e3de981e4745afb4fabe1eddd8dd72e1a8a56d02f0a60904e025c68a"},{"1.5.2/paired-em-bias-50","50","2000","1c5d92bd92298221de0437324277b1f5431367b88ce1df28fd05974d41d0ff5f"},{"1.5.2/paired-vb-pos-100","100","4000","8f668c492bc1fa81362cd2a7817cb9c39c9bce20a82a17570a4522855e86b569"},{"1.5.2/single-em-5","5","200","5f43f3e600bb354386d6db7cb575f1dbce050be0a894bbad2959d4df646c7bc4"},{"1.5.2/alignment-em-3","3","120","6ec4d3482360ddb0012e92f4a7b24731fa80af5355b7ea3139414553746d3acf"},{"1.8.0/paired-em-bias-50","50","2000","987882281cf37b5041b276db3269381f59fe6c2dd01a84ea90f0ae38fca821de"},{"1.8.0/paired-vb-pos-100","100","4000","5d138c26dfa28e295f3888c5ce55849083eaa58208c757e83017fe6aec915da2"},{"1.8.0/single-em-5","5","200","e5055995fd8ba3c96fe2aa1f1ac93555d99782fca084f448b34ec63116075ef6"},{"1.8.0/alignment-em-3","3","120","a5bb7f767c320235afc1a7cd6a2bfa53fd60cc63839c87ef10d5d4962db3c063"},{"1.9.0/paired-em-bias-50","50","2000","640f37d6cc2cddca36c01cb4ce182a16e003ad4a48d1448e70fd58f1fc8c30b2"},{"1.9.0/paired-vb-pos-100","100","4000","42e2d89af89900df3f533ca170704e4b2c49b5a556dc37cb3437a234645482fa"},{"1.9.0/single-em-5","5","200","dfe0966bcf3472e80507274fe2dcac70952aa6ae368d537d334df0e8de2d4516"},{"1.9.0/alignment-em-3","3","120","10c993d13378b996e71d97d43167e1c4fcc252dbce8683da9799117bd17ac93b"}}) {
   Path folder=Path.of(args[1]).resolve(spec[0]);var rows=Files.readAllLines(folder.resolve("quant.sf"));var names=rows.subList(1,rows.size()).stream().map(line->line.split("\t",-1)[0]).toList();
   MessageDigest digest=MessageDigest.getInstance("SHA-256");ByteBuffer value=ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN);
   var summary=SalmonInferentialReplicates.read(Files.newInputStream(folder.resolve("aux_info/bootstrap/names.tsv.gz")),Files.newInputStream(folder.resolve("aux_info/bootstrap/bootstraps.gz")),names,Integer.parseInt(spec[1]),Long.parseLong(spec[2]),(replicate,index,name,count)->{value.putLong(0,Double.doubleToRawLongBits(count));digest.update(value.array());},()->{});
   if(summary.values()!=Long.parseLong(spec[2])||!summary.targets().equals(names)||!HexFormat.of().formatHex(digest.digest()).equals(spec[3]))throw new AssertionError("Original binary population differs: "+spec[0]);
   total+=summary.values();System.out.println("ORIGINAL_EXACT "+spec[0]+" "+summary.values()+" "+spec[3]);
  }
  if(total!=31600)throw new AssertionError("Incomplete original population");System.out.println("ALL_ORIGINAL_VALUES_EXACT "+total);
 }
}
