# FAIL2_CELLCHAT_NATIVE_COMPONENT_CONTROLS

AssertionError('P-value mismatch with no reported numerical boundary')

Required action: use unchanged original R for authoritative permutation p-values; do not silently round, repair ties or claim statistical equivalence. Missing/forbidden runtime means SKIP3 and dependent analysis skipped. Invalid input or process/integrity/capacity failure means FAIL2 and no result admitted. Preserve failed attempts and use NEW output paths. No full CellChat workflow or catalog implementation credit is admitted here.
