# PASS_OFFICIAL_GPL_CELLCHAT_METADATA_CAPTURE_ONLY

Only official metadata captured; no package or scientific analysis was run.

Required action: if download/install is unavailable or forbidden, skip dependent original-reference analysis. Preserve this attempt; supply exact permitted source/dependencies in NEW private paths. Do not substitute current development code for a reported historical edition or infer database-only use as package execution.
