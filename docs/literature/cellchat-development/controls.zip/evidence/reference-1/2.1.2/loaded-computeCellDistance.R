function (coordinates, interaction.range = NULL, ratio = NULL, 
    tol = NULL) 
{
    if (ncol(coordinates) == 2) {
        colnames(coordinates) <- c("x_cent", "y_cent")
    }
    else {
        stop("Please check the input 'coordinates' and make sure it is a two column matrix.")
    }
    d.spatial <- stats::dist(coordinates)
    if (!is.null(ratio)) {
        d.spatial <- d.spatial * ratio
    }
    if (!is.null(interaction.range) & !is.null(tol)) {
        message("\n Apply a predefined spatial distance threshold based on the interaction length...")
        d.spatial[d.spatial > (interaction.range + tol)] <- NaN
    }
    return(d.spatial)
}
