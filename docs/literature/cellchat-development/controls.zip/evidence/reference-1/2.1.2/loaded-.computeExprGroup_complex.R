function (complex_input, data.use, complex, group, FunMean) 
{
    Rsubunits <- complex_input[complex, ] %>% dplyr::select(starts_with("subunit"))
    my.sapply <- ifelse(test = future::nbrOfWorkers() == 1, yes = pbapply::pbsapply, 
        no = future.apply::future_sapply)
    data.complex = my.sapply(X = 1:nrow(Rsubunits), FUN = function(x) {
        RsubunitsV <- unlist(Rsubunits[x, ], use.names = F)
        RsubunitsV <- RsubunitsV[RsubunitsV != ""]
        RsubunitsV <- intersect(RsubunitsV, rownames(data.use))
        if (length(RsubunitsV) > 1) {
            data.avg <- aggregate(t(data.use[RsubunitsV, , drop = FALSE]), 
                list(group), FUN = FunMean)
            data.avg <- t(data.avg[, -1])
        }
        else if (length(RsubunitsV) == 1) {
            data.avg <- aggregate(matrix(data.use[RsubunitsV, 
                ], ncol = 1), list(group), FUN = FunMean)
            data.avg <- t(data.avg[, -1])
        }
        else {
            data.avg = matrix(0, nrow = 1, ncol = length(unique(group)))
        }
        return(geometricMean(data.avg))
    })
    data.complex <- t(data.complex)
    return(data.complex)
}
