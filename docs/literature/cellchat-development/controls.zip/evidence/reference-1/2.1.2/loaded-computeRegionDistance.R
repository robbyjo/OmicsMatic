function (coordinates, meta, interaction.range = NULL, ratio = NULL, 
    tol = NULL, k.min = 10, contact.dependent = TRUE, contact.range = NULL, 
    contact.knn.k = NULL, do.symmetric = TRUE) 
{
    trim <- 0.1
    FunMean <- function(x) mean(x, trim = trim, na.rm = TRUE)
    group <- meta$group
    numCluster <- nlevels(group)
    level.use <- levels(group)
    level.use <- level.use[level.use %in% unique(group)]
    samples <- meta$samples
    samples.use <- levels(samples)
    d.spatial <- array(NaN, dim = c(numCluster, numCluster, length(samples.use)))
    adj.spatial <- array(0, dim = c(numCluster, numCluster, length(samples.use)))
    adj.contact <- array(0, dim = c(numCluster, numCluster, length(samples.use)))
    adj.contact.knn <- array(0, dim = c(numCluster, numCluster, 
        length(samples.use)))
    if (contact.dependent == TRUE & !is.null(contact.knn.k)) {
        nn.ranked <- matrix(NA, nrow = nrow(coordinates), ncol = contact.knn.k)
        for (k in 1:length(samples.use)) {
            idx.k <- which(samples == samples.use[k])
            my.knn <- suppressWarnings(BiocNeighbors::findKNN(coordinates[idx.k, 
                ], k = contact.knn.k, BNPARAM = BiocNeighbors::AnnoyParam(), 
                get.index = TRUE))
            nn.ranked[idx.k, ] <- my.knn$index
        }
        k.min.contact <- k.min
    }
    else {
        nn.ranked <- matrix(1, nrow = nrow(coordinates), ncol = 1)
        k.min.contact <- -1
    }
    if (contact.dependent == TRUE) {
        if (is.null(contact.range) & is.null(contact.knn.k)) {
            stop("Please check the documentation of `computeCommunProb` and provide the value of either `contact.range` or `contact.knn.k`")
        }
    }
    else {
        contact.range <- 10000
    }
    for (k in 1:length(samples.use)) {
        idx.k <- samples == samples.use[k]
        for (i in 1:numCluster) {
            for (j in 1:numCluster) {
                idx.i <- which((group == level.use[i]) & idx.k)
                idx.j <- which((group == level.use[j]) & idx.k)
                if (length(idx.i) == 0 | length(idx.j) == 0) {
                  next
                }
                data.spatial.i <- coordinates[idx.i, , drop = FALSE]
                data.spatial.j <- coordinates[idx.j, , drop = FALSE]
                qout <- suppressWarnings(BiocNeighbors::queryKNN(data.spatial.j, 
                  data.spatial.i, k = 1, BNPARAM = BiocNeighbors::AnnoyParam(), 
                  get.index = TRUE))
                qout$distance <- qout$distance * ratio[k]
                idx <- qout$distance - interaction.range < tol[k]
                adj.spatial[i, j, k] <- (length(unique(qout$index[idx])) >= 
                  k.min) * 1
                idx2 <- qout$distance - contact.range < tol[k]
                adj.contact[i, j, k] <- (length(unique(qout$index[idx2])) >= 
                  k.min) * 1
                knn.i <- unique(as.vector(nn.ranked[idx.i, ]))
                adj.contact.knn[i, j, k] <- (length(intersect(knn.i, 
                  unique(qout$index[idx]))) >= k.min.contact) * 
                  1
                d.spatial[i, j, k] <- FunMean(qout$distance)
            }
        }
    }
    d.spatial <- apply(d.spatial, c(1, 2), function(x) mean(x, 
        na.rm = TRUE))
    adj.spatial <- apply(adj.spatial, c(1, 2), mean)
    adj.contact <- apply(adj.contact, c(1, 2), mean)
    adj.contact.knn <- apply(adj.contact.knn, c(1, 2), mean)
    adj.spatial[adj.spatial > 0] <- 1
    adj.contact[adj.contact > 0] <- 1
    adj.contact.knn[adj.contact.knn > 0] <- 1
    if (do.symmetric) {
        adj.spatial <- adj.spatial * t(adj.spatial)
        adj.contact <- adj.contact * t(adj.contact)
        adj.contact.knn <- adj.contact.knn * t(adj.contact.knn)
    }
    d.spatial <- (d.spatial + t(d.spatial))/2
    adj.spatial[adj.spatial == 0] <- NaN
    d.spatial <- d.spatial * adj.spatial
    rownames(d.spatial) <- levels(group)
    colnames(d.spatial) <- levels(group)
    if (length(contact.knn.k) > 0) {
        adj.contact = adj.contact.knn
    }
    res <- list(d.spatial = d.spatial, adj.contact = adj.contact)
    return(res)
}
