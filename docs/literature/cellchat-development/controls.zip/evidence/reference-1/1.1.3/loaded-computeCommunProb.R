function (object, type = c("triMean", "truncatedMean", "median"), 
    trim = NULL, LR.use = NULL, raw.use = TRUE, population.size = FALSE, 
    do.fast = TRUE, nboot = 100, seed.use = 1L, Kh = 0.5, n = 1) 
{
    type <- match.arg(type)
    FunMean <- switch(type, triMean = triMean, truncatedMean = function(x) mean(x, 
        trim = trim, na.rm = TRUE), median = function(x) median(x, 
        na.rm = TRUE))
    if (raw.use) {
        data <- as.matrix(object@data.signaling)
    }
    else {
        data <- object@data.project
    }
    if (is.null(LR.use)) {
        pairLR.use <- object@LR$LRsig
    }
    else {
        pairLR.use <- LR.use
    }
    complex_input <- object@DB$complex
    cofactor_input <- object@DB$cofactor
    my.sapply <- ifelse(test = future::nbrOfWorkers() == 1, yes = sapply, 
        no = future.apply::future_sapply)
    ptm = Sys.time()
    pairLRsig <- pairLR.use
    group <- object@idents
    geneL <- as.character(pairLRsig$ligand)
    geneR <- as.character(pairLRsig$receptor)
    nLR <- nrow(pairLRsig)
    numCluster <- nlevels(group)
    if (numCluster != length(unique(group))) {
        stop("Please check `unique(object@idents)` and ensure that the factor levels are correct!\n         You may need to drop unused levels using 'droplevels' function. e.g.,\n         `meta$labels = droplevels(meta$labels, exclude = setdiff(levels(meta$labels),unique(meta$labels)))`")
    }
    data.use <- data/max(data)
    nC <- ncol(data.use)
    if (do.fast) {
        data.use.avg <- aggregate(t(data.use), list(group), FUN = FunMean)
        data.use.avg <- t(data.use.avg[, -1])
        colnames(data.use.avg) <- levels(group)
        dataLavg <- computeExpr_LR(geneL, data.use.avg, complex_input)
        dataRavg <- computeExpr_LR(geneR, data.use.avg, complex_input)
        dataRavg.co.A.receptor <- computeExpr_coreceptor(cofactor_input, 
            data.use.avg, pairLRsig, type = "A")
        dataRavg.co.I.receptor <- computeExpr_coreceptor(cofactor_input, 
            data.use.avg, pairLRsig, type = "I")
        dataRavg <- dataRavg * dataRavg.co.A.receptor/dataRavg.co.I.receptor
        dataLavg2 <- t(replicate(nrow(dataLavg), as.numeric(table(group))/nC))
        dataRavg2 <- dataLavg2
        index.agonist <- which(!is.na(pairLRsig$agonist) & pairLRsig$agonist != 
            "")
        index.antagonist <- which(!is.na(pairLRsig$antagonist) & 
            pairLRsig$antagonist != "")
        Prob <- array(0, dim = c(numCluster, numCluster, nLR))
        Pval <- array(0, dim = c(numCluster, numCluster, nLR))
        set.seed(seed.use)
        permutation <- replicate(nboot, sample.int(nC, size = nC))
        data.use.avg.boot <- my.sapply(X = 1:nboot, FUN = function(nE) {
            groupboot <- group[permutation[, nE]]
            data.use.avgB <- aggregate(t(data.use), list(groupboot), 
                FUN = FunMean)
            data.use.avgB <- t(data.use.avgB[, -1])
            return(data.use.avgB)
        }, simplify = FALSE)
        pb <- txtProgressBar(min = 0, max = nLR, style = 3, file = stderr())
        for (i in 1:nLR) {
            dataLR <- Matrix::crossprod(matrix(dataLavg[i, ], 
                nrow = 1), matrix(dataRavg[i, ], nrow = 1))
            P1 <- dataLR^n/(Kh^n + dataLR^n)
            if (sum(P1) == 0) {
                Pnull = P1
                Prob[, , i] <- Pnull
                p = 1
                Pval[, , i] <- matrix(p, nrow = numCluster, ncol = numCluster, 
                  byrow = FALSE)
            }
            else {
                if (is.element(i, index.agonist)) {
                  data.agonist <- computeExpr_agonist(data.use = data.use.avg, 
                    pairLRsig, cofactor_input, index.agonist = i, 
                    Kh = Kh, n = n)
                  P2 <- Matrix::crossprod(matrix(data.agonist, 
                    nrow = 1))
                }
                else {
                  P2 <- matrix(1, nrow = numCluster, ncol = numCluster)
                }
                if (is.element(i, index.antagonist)) {
                  data.antagonist <- computeExpr_antagonist(data.use = data.use.avg, 
                    pairLRsig, cofactor_input, index.antagonist = i, 
                    Kh = Kh, n = n)
                  P3 <- Matrix::crossprod(matrix(data.antagonist, 
                    nrow = 1))
                }
                else {
                  P3 <- matrix(1, nrow = numCluster, ncol = numCluster)
                }
                if (population.size) {
                  P4 <- Matrix::crossprod(matrix(dataLavg2[i, 
                    ], nrow = 1), matrix(dataRavg2[i, ], nrow = 1))
                }
                else {
                  P4 <- matrix(1, nrow = numCluster, ncol = numCluster)
                }
                Pnull = P1 * P2 * P3 * P4
                Prob[, , i] <- Pnull
                Pnull <- as.vector(Pnull)
                Pboot <- sapply(X = 1:nboot, FUN = function(nE) {
                  data.use.avgB <- data.use.avg.boot[[nE]]
                  dataLavgB <- computeExpr_LR(geneL[i], data.use.avgB, 
                    complex_input)
                  dataRavgB <- computeExpr_LR(geneR[i], data.use.avgB, 
                    complex_input)
                  dataRavgB.co.A.receptor <- computeExpr_coreceptor(cofactor_input, 
                    data.use.avgB, pairLRsig[i, , drop = FALSE], 
                    type = "A")
                  dataRavgB.co.I.receptor <- computeExpr_coreceptor(cofactor_input, 
                    data.use.avgB, pairLRsig[i, , drop = FALSE], 
                    type = "I")
                  dataRavgB <- dataRavgB * dataRavgB.co.A.receptor/dataRavgB.co.I.receptor
                  dataLRB = Matrix::crossprod(dataLavgB, dataRavgB)
                  P1.boot <- dataLRB^n/(Kh^n + dataLRB^n)
                  if (is.element(i, index.agonist)) {
                    data.agonist <- computeExpr_agonist(data.use = data.use.avgB, 
                      pairLRsig, cofactor_input, index.agonist = i, 
                      Kh = Kh, n = n)
                    P2.boot <- Matrix::crossprod(matrix(data.agonist, 
                      nrow = 1))
                  }
                  else {
                    P2.boot <- matrix(1, nrow = numCluster, ncol = numCluster)
                  }
                  if (is.element(i, index.antagonist)) {
                    data.antagonist <- computeExpr_antagonist(data.use = data.use.avgB, 
                      pairLRsig, cofactor_input, index.antagonist = i, 
                      Kh = Kh, n = n)
                    P3.boot <- Matrix::crossprod(matrix(data.antagonist, 
                      nrow = 1))
                  }
                  else {
                    P3.boot <- matrix(1, nrow = numCluster, ncol = numCluster)
                  }
                  if (population.size) {
                    groupboot <- group[permutation[, nE]]
                    dataLavg2B <- as.numeric(table(groupboot))/nC
                    dataLavg2B <- matrix(dataLavg2B, nrow = 1)
                    dataRavg2B <- dataLavg2B
                    P4.boot = Matrix::crossprod(dataLavg2B, dataRavg2B)
                  }
                  else {
                    P4.boot = matrix(1, nrow = numCluster, ncol = numCluster)
                  }
                  Pboot = P1.boot * P2.boot * P3.boot * P4.boot
                  return(as.vector(Pboot))
                })
                Pboot <- matrix(unlist(Pboot), nrow = length(Pnull), 
                  ncol = nboot, byrow = FALSE)
                nReject <- rowSums(Pboot - Pnull >= 0)
                p = nReject/nboot
                Pval[, , i] <- matrix(p, nrow = numCluster, ncol = numCluster, 
                  byrow = FALSE)
            }
            setTxtProgressBar(pb = pb, value = i)
        }
        close(con = pb)
    }
    else {
        dataL <- computeExpr_LR(geneL, data.use, complex_input)
        dataR <- computeExpr_LR(geneR, data.use, complex_input)
        dataR.co.A.receptor <- computeExpr_coreceptor(cofactor_input, 
            data.use, pairLRsig, type = "A")
        dataR.co.I.receptor <- computeExpr_coreceptor(cofactor_input, 
            data.use, pairLRsig, type = "I")
        dataR <- dataR * dataR.co.A.receptor/dataR.co.I.receptor
        dataLavg <- aggregate(t(dataL), list(group), FUN = FunMean)
        dataLavg <- t(dataLavg[, -1])
        rownames(dataLavg) <- geneL
        dataRavg <- aggregate(t(dataR), list(group), FUN = FunMean)
        dataRavg <- t(dataRavg[, -1])
        rownames(dataRavg) <- geneR
        dataL.binary = (dataL > 0) * 1
        dataR.binary = (dataR > 0) * 1
        dataLavg2 <- aggregate(t(dataL.binary), list(group), 
            FUN = sum)
        dataLavg2 <- t(dataLavg2[, -1])/nC
        dataRavg2 <- aggregate(t(dataR.binary), list(group), 
            FUN = sum)
        dataRavg2 <- t(dataRavg2[, -1])/nC
        index.agonist <- which(!is.na(pairLRsig$agonist) & pairLRsig$agonist != 
            "")
        index.antagonist <- which(!is.na(pairLRsig$antagonist) & 
            pairLRsig$antagonist != "")
        set.seed(seed.use)
        permutation <- replicate(nboot, sample.int(nC, size = nC))
        Prob <- array(0, dim = c(numCluster, numCluster, nLR))
        Pval <- array(0, dim = c(numCluster, numCluster, nLR))
        pb <- txtProgressBar(min = 0, max = nLR, style = 3, file = stderr())
        for (i in 1:nLR) {
            dataLR <- Matrix::crossprod(matrix(dataLavg[i, ], 
                nrow = 1), matrix(dataRavg[i, ], nrow = 1))
            P1 <- dataLR^n/(Kh^n + dataLR^n)
            if (sum(P1) == 0) {
                Pnull = P1
                Prob[, , i] <- Pnull
                p = 1
                Pval[, , i] <- matrix(p, nrow = numCluster, ncol = numCluster, 
                  byrow = FALSE)
            }
            else {
                if (is.element(i, index.agonist)) {
                  data.agonist <- computeExprGroup_agonist(data.use = data.use, 
                    pairLRsig, cofactor_input, group = group, 
                    index.agonist = i, Kh = Kh, FunMean = FunMean, 
                    n = n)
                  P2 <- Matrix::crossprod(matrix(data.agonist, 
                    nrow = 1))
                }
                else {
                  P2 <- matrix(1, nrow = numCluster, ncol = numCluster)
                }
                if (is.element(i, index.antagonist)) {
                  data.antagonist <- computeExprGroup_antagonist(data.use = data.use, 
                    pairLRsig, cofactor_input, group = group, 
                    index.antagonist = i, Kh = Kh, FunMean = FunMean, 
                    n = n)
                  P3 <- Matrix::crossprod(matrix(data.antagonist, 
                    nrow = 1))
                }
                else {
                  P3 <- matrix(1, nrow = numCluster, ncol = numCluster)
                }
                if (population.size) {
                  P4 <- Matrix::crossprod(matrix(dataLavg2[i, 
                    ], nrow = 1), matrix(dataRavg2[i, ], nrow = 1))
                }
                else {
                  P4 <- matrix(1, nrow = numCluster, ncol = numCluster)
                }
                Pnull = P1 * P2 * P3 * P4
                Prob[, , i] <- Pnull
                Pnull <- as.vector(Pnull)
                dataL.i <- dataL[i, ]
                dataR.i <- dataR[i, ]
                dataL2.i <- dataL.binary[i, ]
                dataR2.i <- dataR.binary[i, ]
                Pboot <- my.sapply(X = 1:nboot, FUN = function(nE) {
                  groupboot <- group[permutation[, nE]]
                  dataLavgB <- aggregate(matrix(dataL.i, ncol = 1), 
                    list(groupboot), FUN = FunMean)
                  dataLavgB <- t(dataLavgB[, -1])
                  dataLavgB <- matrix(dataLavgB, nrow = 1)
                  dataRavgB <- aggregate(matrix(dataR.i, ncol = 1), 
                    list(groupboot), FUN = FunMean)
                  dataRavgB <- t(dataRavgB[, -1])
                  dataRavgB <- matrix(dataRavgB, nrow = 1)
                  dataLRB = Matrix::crossprod(dataLavgB, dataRavgB)
                  P1.boot <- dataLRB^n/(Kh^n + dataLRB^n)
                  if (is.element(i, index.agonist)) {
                    data.agonist <- computeExprGroup_agonist(data.use = data.use, 
                      pairLRsig, cofactor_input, group = groupboot, 
                      index.agonist = i, Kh = Kh, FunMean = FunMean, 
                      n = n)
                    P2.boot <- Matrix::crossprod(matrix(data.agonist, 
                      nrow = 1))
                  }
                  else {
                    P2.boot <- matrix(1, nrow = numCluster, ncol = numCluster)
                  }
                  if (is.element(i, index.antagonist)) {
                    data.antagonist <- computeExprGroup_antagonist(data.use = data.use, 
                      pairLRsig, cofactor_input, group = groupboot, 
                      index.antagonist = i, Kh = Kh, FunMean = FunMean, 
                      n = n)
                    P3.boot <- Matrix::crossprod(matrix(data.antagonist, 
                      nrow = 1))
                  }
                  else {
                    P3.boot <- matrix(1, nrow = numCluster, ncol = numCluster)
                  }
                  dataLavg2B <- by(matrix(dataL2.i, ncol = 1), 
                    groupboot, sum)/nC
                  dataLavg2B <- matrix(dataLavg2B, nrow = 1)
                  dataRavg2B <- by(matrix(dataR2.i, ncol = 1), 
                    groupboot, sum)/nC
                  dataRavg2B <- matrix(dataRavg2B, nrow = 1)
                  if (population.size) {
                    P4.boot = Matrix::crossprod(dataLavg2B, dataRavg2B)
                  }
                  else {
                    P4.boot = matrix(1, nrow = numCluster, ncol = numCluster)
                  }
                  Pboot = P1.boot * P2.boot * P3.boot * P4.boot
                  return(as.vector(Pboot))
                })
                Pboot <- matrix(unlist(Pboot), nrow = length(Pnull), 
                  ncol = nboot, byrow = FALSE)
                nReject <- rowSums(Pboot - Pnull >= 0)
                p = nReject/nboot
                Pval[, , i] <- matrix(p, nrow = numCluster, ncol = numCluster, 
                  byrow = FALSE)
            }
            setTxtProgressBar(pb = pb, value = i)
        }
        close(con = pb)
    }
    Pval[Prob == 0] <- 1
    dimnames(Prob) <- list(levels(group), levels(group), rownames(pairLRsig))
    dimnames(Pval) <- dimnames(Prob)
    net <- list(prob = Prob, pval = Pval)
    execution.time = Sys.time() - ptm
    object@options$run.time <- as.numeric(execution.time, units = "secs")
    object@options$parameter <- list(type.mean = type, trim = trim, 
        raw.use = raw.use, population.size = population.size, 
        nboot = nboot, seed.use = seed.use, Kh = Kh, n = n)
    object@net <- net
    return(object)
}
