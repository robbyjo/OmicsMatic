function (object = NULL, net = NULL, pairLR.use = NULL, thresh = 0.05) 
{
    if (is.null(net)) {
        net <- object@net
    }
    if (is.null(pairLR.use)) {
        pairLR.use <- object@LR$LRsig
    }
    prob <- net$prob
    prob[net$pval > thresh] <- 0
    pathways <- unique(pairLR.use$pathway_name)
    group <- factor(pairLR.use$pathway_name, levels = pathways)
    prob.pathways <- aperm(apply(prob, c(1, 2), by, group, sum), 
        c(2, 3, 1))
    pathways.sig <- pathways[apply(prob.pathways, 3, sum) != 
        0]
    prob.pathways.sig <- prob.pathways[, , pathways.sig]
    idx <- sort(apply(prob.pathways.sig, 3, sum), decreasing = TRUE, 
        index.return = TRUE)$ix
    pathways.sig <- pathways.sig[idx]
    prob.pathways.sig <- prob.pathways.sig[, , idx]
    if (is.null(object)) {
        netP = list(pathways = pathways.sig, prob = prob.pathways.sig)
        return(netP)
    }
    else {
        object@netP$pathways <- pathways.sig
        object@netP$prob <- prob.pathways.sig
        return(object)
    }
}
