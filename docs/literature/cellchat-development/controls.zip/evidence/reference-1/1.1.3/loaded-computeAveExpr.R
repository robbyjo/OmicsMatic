function (object, features = NULL, group.by = NULL, type = c("triMean", 
    "truncatedMean", "median"), trim = NULL, slot.name = c("data.signaling", 
    "data"), data.use = NULL) 
{
    type <- match.arg(type)
    slot.name <- match.arg(slot.name)
    FunMean <- switch(type, triMean = triMean, truncatedMean = function(x) mean(x, 
        trim = trim, na.rm = TRUE), median = function(x) median(x, 
        na.rm = TRUE))
    if (is.null(data.use)) {
        data.use <- slot(object, slot.name)
    }
    if (is.null(features)) {
        features.use <- row.names(data.use)
    }
    else {
        features.use <- intersect(features, row.names(data.use))
    }
    data.use <- data.use[features.use, , drop = FALSE]
    data.use <- as.matrix(data.use)
    if (is.null(group.by)) {
        labels <- object@idents
        if (!is.factor(labels)) {
            message("Use the joint cell labels from the merged CellChat object")
            labels <- object@idents$joint
        }
    }
    else {
        labels <- object@meta[[group.by]]
    }
    if (!is.factor(labels)) {
        labels <- factor(labels)
    }
    data.use.avg <- aggregate(t(data.use), list(labels), FUN = FunMean)
    data.use.avg <- t(data.use.avg[, -1])
    rownames(data.use.avg) <- features.use
    colnames(data.use.avg) <- levels(labels)
    return(data.use.avg)
}
