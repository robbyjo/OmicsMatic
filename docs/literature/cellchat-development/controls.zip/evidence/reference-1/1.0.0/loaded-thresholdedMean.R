function (x, trim = 0.1, na.rm = TRUE) 
{
    percent <- Matrix::nnzero(x)/length(x)
    if (percent < trim) {
        return(0)
    }
    else {
        return(mean(x, na.rm = na.rm))
    }
}
