function (data.use, pairLRsig, cofactor_input, group, index.antagonist, 
    Kh, FunMean, n) 
{
    antagonist <- pairLRsig$antagonist[index.antagonist]
    antagonist.ind <- cofactor_input[antagonist, grepl("cofactor", 
        colnames(cofactor_input))]
    antagonist.indV <- unlist(antagonist.ind, use.names = F)
    antagonist.indV <- antagonist.indV[antagonist.indV != ""]
    antagonist.indV <- intersect(antagonist.indV, rownames(data.use))
    if (length(antagonist.indV) == 1) {
        data.avg <- aggregate(matrix(data.use[antagonist.indV, 
            ], ncol = 1), list(group), FUN = FunMean)
        data.avg <- t(data.avg[, -1])
        data.antagonist <- Kh^n/(Kh^n + data.avg^n)
    }
    else if (length(antagonist.indV) > 1) {
        data.avg <- aggregate(t(data.use[antagonist.indV, ]), 
            list(group), FUN = FunMean)
        data.avg <- t(data.avg[, -1])
        data.antagonist <- apply(Kh^n/(Kh^n + data.avg^n), 2, 
            prod)
    }
    else {
        data.antagonist = matrix(1, nrow = 1, ncol = length(unique(group)))
    }
    return(data.antagonist)
}
