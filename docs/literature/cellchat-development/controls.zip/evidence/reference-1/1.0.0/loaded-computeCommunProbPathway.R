function (object, thresh = 0.05) 
{
    net <- object@net
    pairLR.use <- object@LR$LRsig
    prob <- net$prob
    prob[net$pval > thresh] <- 0
    pathways <- unique(pairLR.use$pathway_name)
    group <- factor(pairLR.use$pathway_name, levels = pathways)
    prob.pathways <- aperm(apply(prob, c(1, 2), by, group, sum), 
        c(2, 3, 1))
    pathways.sig <- pathways[apply(prob.pathways, 3, sum) != 
        0]
    prob.pathways.sig <- prob.pathways[, , pathways.sig]
    object@netP$pathways <- pathways.sig
    object@netP$prob <- prob.pathways.sig
    return(object)
}
