function (object, type = c("triMean", "truncatedMean", "median"), 
    trim = NULL, LR.use = NULL, raw.use = FALSE, population.size = FALSE, 
    nboot = 100, seed.use = 1L, Kh = 0.5, n = 1) 
{
    type <- match.arg(type)
    if (raw.use) {
        data <- as.matrix(object@data.signaling)
    }
    else {
        data <- object@data.project
    }
    if (is.null(LR.use)) {
        pairLR.use <- object@LR$LRsig
    }
    else {
        pairLR.use <- LR.use
    }
    complex_input <- object@DB$complex
    cofactor_input <- object@DB$cofactor
    my.sapply <- ifelse(test = future::nbrOfWorkers() == 1, yes = pbapply::pbsapply, 
        no = future.apply::future_sapply)
    ptm = Sys.time()
    pairLRsig <- pairLR.use
    group <- object@idents
    geneL <- as.character(pairLRsig$ligand)
    geneR <- as.character(pairLRsig$receptor)
    nLR <- nrow(pairLRsig)
    numCluster <- nlevels(group)
    data.use <- data/max(data)
    nC <- ncol(data.use)
    index.singleL <- which(geneL %in% rownames(data.use))
    dataL1 <- data.use[geneL[index.singleL], ]
    dataL <- matrix(nrow = nLR, ncol = nC)
    dataL[index.singleL, ] <- dataL1
    index.complexL <- setdiff(1:nLR, index.singleL)
    if (length(index.complexL) > 0) {
        complex <- geneL[index.complexL]
        data.complex <- computeExpr_complex(complex_input, data.use, 
            complex)
        dataL[index.complexL, ] <- data.complex
    }
    index.singleR <- which(geneR %in% rownames(data.use))
    dataR1 <- data.use[geneR[index.singleR], ]
    dataR <- matrix(nrow = nLR, ncol = nC)
    dataR[index.singleR, ] <- dataR1
    index.complexR <- setdiff(1:nLR, index.singleR)
    if (length(index.complexR) > 0) {
        complex <- geneR[index.complexR]
        data.complex <- computeExpr_complex(complex_input, data.use, 
            complex)
        dataR[index.complexR, ] <- data.complex
    }
    index.co.A.receptor <- which(!is.na(pairLRsig$co_A_receptor) & 
        pairLRsig$co_A_receptor != "")
    if (length(index.co.A.receptor) > 0) {
        dataR.co.A.receptor <- computeExpr_coreceptor(cofactor_input, 
            data.use, coreceptor.all = pairLRsig$co_A_receptor, 
            index.coreceptor = index.co.A.receptor)
    }
    else {
        dataR.co.A.receptor <- matrix(1, nrow = nrow(dataR), 
            ncol = ncol(dataR))
    }
    index.co.I.receptor <- which(!is.na(pairLRsig$co_I_receptor) & 
        pairLRsig$co_I_receptor != "")
    if (length(index.co.I.receptor) > 0) {
        dataR.co.I.receptor <- computeExpr_coreceptor(cofactor_input, 
            data.use, coreceptor.all = pairLRsig$co_I_receptor, 
            index.coreceptor = index.co.I.receptor)
    }
    else {
        dataR.co.I.receptor <- matrix(1, nrow = nrow(dataR), 
            ncol = ncol(dataR))
    }
    dataR <- dataR * dataR.co.A.receptor/dataR.co.I.receptor
    FunMean <- switch(type, triMean = triMean, truncatedMean = function(x) mean(x, 
        trim = trim, na.rm = TRUE), median = function(x) median(x, 
        na.rm = TRUE))
    dataLavg <- aggregate(t(dataL), list(group), FUN = FunMean)
    dataLavg <- t(dataLavg[, -1])
    dataRavg <- aggregate(t(dataR), list(group), FUN = FunMean)
    dataRavg <- t(dataRavg[, -1])
    dataL.binary = (dataL > 0) * 1
    dataR.binary = (dataR > 0) * 1
    dataLavg2 <- aggregate(t(dataL.binary), list(group), FUN = sum)
    dataLavg2 <- t(dataLavg2[, -1])/nC
    dataRavg2 <- aggregate(t(dataR.binary), list(group), FUN = sum)
    dataRavg2 <- t(dataRavg2[, -1])/nC
    index.agonist <- which(!is.na(pairLRsig$agonist) & pairLRsig$agonist != 
        "")
    index.antagonist <- which(!is.na(pairLRsig$antagonist) & 
        pairLRsig$antagonist != "")
    set.seed(seed.use)
    permutation <- replicate(nboot, sample.int(nC, size = nC))
    Prob <- array(0, dim = c(numCluster, numCluster, nLR))
    Pval <- array(0, dim = c(numCluster, numCluster, nLR))
    for (i in 1:nLR) {
        dataLR <- Matrix::crossprod(matrix(dataLavg[i, ], nrow = 1), 
            matrix(dataRavg[i, ], nrow = 1))
        P1 <- dataLR^n/(Kh^n + dataLR^n)
        if (sum(P1) == 0) {
            Pnull = P1
            Prob[, , i] <- Pnull
            p = 1
            Pval[, , i] <- matrix(p, nrow = numCluster, ncol = numCluster, 
                byrow = FALSE)
        }
        else {
            if (is.element(i, index.agonist)) {
                data.agonist <- computeExpr_agonist(data.use = data.use, 
                  pairLRsig, cofactor_input, group = group, index.agonist = i, 
                  Kh = Kh, FunMean = FunMean, n = n)
                P2 <- Matrix::crossprod(matrix(data.agonist, 
                  nrow = 1))
            }
            else {
                P2 <- matrix(1, nrow = numCluster, ncol = numCluster)
            }
            if (is.element(i, index.antagonist)) {
                data.antagonist <- computeExpr_antagonist(data.use = data.use, 
                  pairLRsig, cofactor_input, group = group, index.antagonist = i, 
                  Kh = Kh, FunMean = FunMean, n = n)
                P3 <- Matrix::crossprod(matrix(data.antagonist, 
                  nrow = 1))
            }
            else {
                P3 <- matrix(1, nrow = numCluster, ncol = numCluster)
            }
            if (population.size) {
                P4 <- Matrix::crossprod(matrix(dataLavg2[i, ], 
                  nrow = 1), matrix(dataRavg2[i, ], nrow = 1))
            }
            else {
                P4 <- matrix(1, nrow = numCluster, ncol = numCluster)
            }
            Pnull = P1 * P2 * P3 * P4
            Prob[, , i] <- Pnull
            Pnull <- as.vector(Pnull)
            dataL.i <- dataL[i, ]
            dataR.i <- dataR[i, ]
            dataL2.i <- dataL.binary[i, ]
            dataR2.i <- dataR.binary[i, ]
            Pboot <- my.sapply(X = 1:nboot, FUN = function(nE) {
                groupboot <- group[permutation[, nE]]
                dataLavgB <- aggregate(matrix(dataL.i, ncol = 1), 
                  list(groupboot), FUN = FunMean)
                dataLavgB <- t(dataLavgB[, -1])
                dataLavgB <- matrix(dataLavgB, nrow = 1)
                dataRavgB <- aggregate(matrix(dataR.i, ncol = 1), 
                  list(groupboot), FUN = FunMean)
                dataRavgB <- t(dataRavgB[, -1])
                dataRavgB <- matrix(dataRavgB, nrow = 1)
                dataLRB = Matrix::crossprod(dataLavgB, dataRavgB)
                P1.boot <- dataLRB^n/(Kh^n + dataLRB^n)
                if (is.element(i, index.agonist)) {
                  data.agonist <- computeExpr_agonist(data.use = data.use, 
                    pairLRsig, cofactor_input, group = groupboot, 
                    index.agonist = i, Kh = Kh, FunMean = FunMean, 
                    n = n)
                  P2.boot <- Matrix::crossprod(matrix(data.agonist, 
                    nrow = 1))
                }
                else {
                  P2.boot <- matrix(1, nrow = numCluster, ncol = numCluster)
                }
                if (is.element(i, index.antagonist)) {
                  data.antagonist <- computeExpr_antagonist(data.use = data.use, 
                    pairLRsig, cofactor_input, group = groupboot, 
                    index.antagonist = i, Kh = Kh, FunMean = FunMean, 
                    n = n)
                  P3.boot <- Matrix::crossprod(matrix(data.antagonist, 
                    nrow = 1))
                }
                else {
                  P3.boot <- matrix(1, nrow = numCluster, ncol = numCluster)
                }
                dataLavg2B <- by(matrix(dataL2.i, ncol = 1), 
                  groupboot, sum)/nC
                dataLavg2B <- matrix(dataLavg2B, nrow = 1)
                dataRavg2B <- by(matrix(dataR2.i, ncol = 1), 
                  groupboot, sum)/nC
                dataRavg2B <- matrix(dataRavg2B, nrow = 1)
                if (population.size) {
                  P4.boot = Matrix::crossprod(dataLavg2B, dataRavg2B)
                }
                else {
                  P4.boot = matrix(1, nrow = numCluster, ncol = numCluster)
                }
                Pboot = P1.boot * P2.boot * P3.boot * P4.boot
                return(as.vector(Pboot))
            })
            Pboot <- matrix(unlist(Pboot), nrow = length(Pnull), 
                ncol = nboot, byrow = FALSE)
            nReject <- rowSums(Pboot - Pnull >= 0)
            p = nReject/nboot
            Pval[, , i] <- matrix(p, nrow = numCluster, ncol = numCluster, 
                byrow = FALSE)
        }
    }
    Pval[Prob == 0] <- 1
    dimnames(Prob) <- list(levels(group), levels(group), rownames(pairLRsig))
    dimnames(Pval) <- dimnames(Prob)
    net <- list(prob = Prob, pval = Pval)
    execution.time = Sys.time() - ptm
    object@options$run.time <- as.numeric(execution.time, units = "secs")
    object@net <- net
    return(object)
}
