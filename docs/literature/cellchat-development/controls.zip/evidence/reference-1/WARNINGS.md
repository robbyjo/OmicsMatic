# PASS_SIX_UNCHANGED_CELLCHAT_RNA_FUNCTION_REFERENCES_ONLY

Unchanged original S4/modeling definitions ran on prepared RNA input in R4.6.1; no CellChat package installation, full workflow or historical paper runtime is established.

Required action: when a named runtime or dependency is unavailable or forbidden, skip dependent analysis. Where permitted install it in a NEW private library and rerun to NEW output paths. Preserve this attempt. Do not substitute another source edition or report prepared-input checks as a paper reproduction.
