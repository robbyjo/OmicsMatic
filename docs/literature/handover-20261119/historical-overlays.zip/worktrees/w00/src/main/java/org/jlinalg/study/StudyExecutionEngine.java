/*
 * Copyright (C) 2026 JLinAlg contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
package org.jlinalg.study;

import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Approved-plan execution with verified resume, content caching, and manifests. */
public final class StudyExecutionEngine {
    private StudyExecutionEngine() { }

    public record RunResult(String runId, String state,
            int completed, int reused, int waiting, int failed, int skipped) { }

    public static RunResult run(Path project, StudyProject.Actor initiator,
            StudyOperationExecutor executor, boolean resume) throws IOException {
        return run(project, initiator, executor, resume, false);
    }

    public static RunResult run(Path project, StudyProject.Actor initiator,
            StudyOperationExecutor executor, boolean resume, boolean offline)
            throws IOException {
        Path root = project.toAbsolutePath().normalize();
        return StudyProjectLock.with(root, () -> runLocked(root, initiator, executor, resume, offline));
    }

    private static RunResult runLocked(Path root, StudyProject.Actor initiator,
            StudyOperationExecutor executor, boolean resume, boolean offline)
            throws IOException {
        StudyProject.verify(root);
        StudyPlan plan = StudyPlanner.loadApproved(root);
        Set<String> unavailable = StudyCleanup.unavailable(root);
        List<Path> priorManifests = new ArrayList<>();
        if (Files.isDirectory(root.resolve("runs"))) try (var paths = Files.walk(root.resolve("runs"))) {
            priorManifests.addAll(paths.filter(path -> path.getFileName().toString().equals("manifest.yaml")
                    && !path.getParent().getFileName().toString().startsWith(".operation-"))
                .sorted((left, right) -> {
                    try { return Files.getLastModifiedTime(right).compareTo(Files.getLastModifiedTime(left)); }
                    catch (IOException failure) { throw new java.io.UncheckedIOException(failure); }
                }).toList());
        }
        Map<String, Object> planDocument = plan.document();
        Map<String, Object> study = StudyProject.resolved(root).document();
        Map<String, Object> software = softwareIdentity();
        StudyDataDictionary.verify(root, study);
        if (offline) {
            Map<String, Object> resources = StudyIO.optionalMap(study.get("resources"), "resources");
            resources.put("network", "offline");
            study.put("resources", resources);
        }
        String baseRunId = "run-" + plan.id();
        String runId = baseRunId;
        for (int attempt = 2; Files.exists(root.resolve("runs").resolve(runId)); attempt++)
            runId = baseRunId + "-attempt-" + String.format("%04d", attempt);
        Path run = root.resolve("runs").resolve(runId);
        Path operationsRoot = run.resolve("operations");
        Files.createDirectories(operationsRoot);
        Path availability = run.resolve("input-availability.yaml");
        StudyIO.writeYaml(availability, StudyStageInputs.availability(root, study));

        Map<String, Object> started = new LinkedHashMap<>();
        started.put("run_id", runId);
        started.put("plan_id", plan.id());
        started.put("plan_hash", plan.hash());
        started.put("state", "running");
        started.put("execution_mode", resume ? "resume" : "rerun");
        started.put("offline", offline);
        started.put("input_availability_sha256", StudyIO.hash(availability));
        started.put("phase", "execution");
        started.put("summary", "Started approved plan " + plan.id());
        StudyProject.append(root, "run_started", initiator, started);

        Map<String, String> states = new LinkedHashMap<>();
        Map<String, Path> directories = new LinkedHashMap<>();
        int completed = 0, reused = 0, waiting = 0, failed = 0, skipped = 0;
        List<Object> operations = StudyIO.list(
            planDocument.get("operations"), "plan.operations");
        for (Object value : operations) {
            Map<String, Object> operation = StudyIO.map(value, "operation");
            String id = StudyIO.requireString(operation, "id", "operation");
            String type = StudyIO.requireString(operation, "type", "operation");
            Path destination = operationsRoot.resolve(id);
            List<String> dependencies = strings(
                operation.get("depends_on"), "operation.depends_on");
            boolean toleratesIncomplete = Boolean.TRUE.equals(
                operation.get("allow_incomplete_dependencies"));
            boolean blocked = !toleratesIncomplete
                && dependencies.stream().anyMatch(dependency ->
                !"complete".equals(states.get(dependency))
                    && !"reused".equals(states.get(dependency)));
            Map<String, Path> dependencyDirectories = new LinkedHashMap<>();
            dependencies.forEach(dependency -> {
                Path directory = directories.get(dependency);
                if (directory != null) dependencyDirectories.put(dependency, directory);
            });
            StudyCacheScope.Scope scope = executor.usesNativeStageInputContracts()
                ? StudyCacheScope.resolve(study, operation)
                : new StudyCacheScope.Scope("full_study", study);
            String contextHash = StudyIO.hash(scope.context());
            Map<String, String> inputs = inputHashes(
                root, study, operation, dependencyDirectories, scope);
            Map<String, Object> cacheIdentity = new LinkedHashMap<>();
            cacheIdentity.put("operation", operation);
            cacheIdentity.put("context_hash", contextHash);
            cacheIdentity.put("input_scope", scope.mode());
            cacheIdentity.put("input_sha256", inputs);
            cacheIdentity.put("implementation", 86);
            if (Set.of("report", "manuscript_draft", "impact_assessment").contains(operation.get("type")))
                cacheIdentity.put("manuscript_template", StudyManuscriptPolicy.identity());
            cacheIdentity.put("software", software);
            String cacheKey = StudyIO.hash(cacheIdentity);
            List<StudyNeed> needs = StudyQuestionRules.prerequisites(study, operation);
            Path reusable = null;
            if (resume && !blocked && needs.isEmpty()) for (Path prior : priorManifests) {
                String priorId = prior.getParent().getParent().getParent().getFileName()
                    + "/" + prior.getParent().getFileName();
                if (unavailable.contains(priorId)) continue;
                if (verified(prior.getParent(), cacheKey)) {
                    reusable = prior.getParent();
                    break;
                }
            }

            if (Files.exists(destination))
                throw new IOException("Unverified operation output already exists: "
                    + destination);
            if (reusable != null) {
                copyDirectory(reusable, destination);
                Map<String, Object> manifest = StudyIO.loadArtifact(
                    destination.resolve("manifest.yaml"));
                manifest.put("run_id", runId);
                manifest.put("current_resolved_study_hash", planDocument.get("resolved_study_hash"));
                manifest.put("reused_from_cache", true);
                manifest.put("reused_from", root.relativize(reusable).toString().replace('\\', '/'));
                StudyIO.writeYaml(destination.resolve("manifest.yaml"), manifest);
                states.put(id, "reused");
                directories.put(id, destination);
                reused++;
                event(root, "operation_reused", runId, operation, cacheKey,
                    "Reused verified prior operation with identical inputs", destination);
                continue;
            }

            Files.createDirectories(operationsRoot);
            Path staging = Files.createTempDirectory(operationsRoot, ".operation-");
            StudyOperationExecutor.Result result;
            try {
                if (!needs.isEmpty()) {
                    result = StudyOperationExecutor.Result.waiting(
                        "Scientific prerequisites require scientist input; see QUESTIONS.md", Map.of(), needs);
                } else if (blocked) {
                    result = StudyOperationExecutor.Result.waiting(
                        "A prerequisite operation is incomplete",
                        Map.of("dependencies", dependencies));
                } else if (!"full_study".equals(scope.mode()) && inputs.entrySet().stream().anyMatch(e -> e.getKey().startsWith("dataset:") && "missing".equals(e.getValue()))) {
                    result = StudyOperationExecutor.Result.waiting(
                        "Declared cohort preparation input is absent",
                        Map.of("missing_inputs", inputs.entrySet().stream().filter(e -> e.getKey().startsWith("dataset:") && "missing".equals(e.getValue())).map(Map.Entry::getKey).toList()));
                } else {
                    result = executor.execute(new StudyOperationExecutor.Context(
                        root, staging, operation, study, planDocument,
                        dependencyDirectories, resume));
                }
                Map<String, Object> manifest = manifest(runId, operation,
                    cacheKey, inputs, result, staging);
                manifest.put("software", software);
                provenance(manifest, scope, contextHash, planDocument);
                StudyIO.writeYaml(staging.resolve("manifest.yaml"), manifest);
                publish(staging, destination);
                directories.put(id, destination);
                if (result.state() == StudyOperationExecutor.State.COMPLETE) {
                    states.put(id, "complete");
                    completed++;
                    event(root, "operation_completed", runId, operation,
                        cacheKey, result.summary(), destination);
                } else if (result.state() == StudyOperationExecutor.State.NOT_APPLICABLE) {
                    states.put(id, "not_applicable");
                    skipped++;
                    event(root, "operation_skipped", runId, operation,
                        cacheKey, result.summary(), destination);
                } else if (result.state() == StudyOperationExecutor.State.FAILED) {
                    states.put(id, "failed");
                    failed++;
                    event(root, "operation_failed", runId, operation,
                        cacheKey, result.summary(), destination);
                } else {
                    states.put(id, "waiting");
                    waiting++;
                    event(root, "operation_waiting", runId, operation,
                        cacheKey, result.summary(), destination);
                }
            } catch (Exception failure) {
                failed++;
                states.put(id, "failed");
                Map<String, Object> details = new LinkedHashMap<>();
                details.put("exception", failure.getClass().getName());
                details.put("message", String.valueOf(failure.getMessage()));
                result = new StudyOperationExecutor.Result(
                    StudyOperationExecutor.State.FAILED,
                    "Operation failed: " + failure.getMessage(), List.of(), details);
                Map<String, Object> manifest = manifest(runId, operation,
                    cacheKey, inputs, result, staging);
                manifest.put("software", software);
                provenance(manifest, scope, contextHash, planDocument);
                StudyIO.writeYaml(staging.resolve("manifest.yaml"), manifest);
                if (Files.exists(destination)) throw failure instanceof IOException io
                    ? io : new IOException("Could not finalize published operation", failure);
                publish(staging, destination);
                directories.put(id, destination);
                event(root, "operation_failed", runId, operation,
                    cacheKey, result.summary(), destination);
            } finally {
                if (Files.exists(staging)) deleteTree(staging);
            }
        }

        String state = failed > 0 ? "failed"
            : waiting > 0 ? "waiting_for_input" : "completed";
        Map<String, Object> runManifest = new LinkedHashMap<>();
        runManifest.put("schema_version", 1);
        runManifest.put("run_id", runId);
        runManifest.put("plan_id", plan.id());
        runManifest.put("plan_hash", plan.hash());
        runManifest.put("state", state);
        runManifest.put("execution_mode", resume ? "resume" : "rerun");
        runManifest.put("offline", offline);
        runManifest.put("completed", completed);
        runManifest.put("reused", reused);
        runManifest.put("waiting", waiting);
        runManifest.put("failed", failed);
        runManifest.put("skipped", skipped);
        runManifest.put("operation_states", states);
        runManifest.put("input_availability", "input-availability.yaml");
        runManifest.put("input_availability_sha256", StudyIO.hash(availability));
        StudyIO.writeYaml(run.resolve("run-manifest.yaml"), runManifest);
        Map<String, Object> finished = new LinkedHashMap<>(runManifest);
        finished.put("phase", state.equals("completed") ? "reporting" : "execution");
        finished.put("summary", "Finished run " + runId + " with state " + state);
        StudyProject.append(root, state.equals("failed")
            ? "run_failed" : "run_completed", initiator, finished);
        StudyQuestions.reconcile(root, plan, runId);
        int indexed = StudyEvidenceIndex.rebuild(root);
        runManifest.put("indexed_results", indexed);
        StudyIO.writeYaml(run.resolve("run-manifest.yaml"), runManifest);
        return new RunResult(runId, state, completed, reused, waiting, failed, skipped);
    }

    private static Map<String, Object> softwareIdentity() throws IOException {
        try {
            Path source = Path.of(StudyExecutionEngine.class.getProtectionDomain().getCodeSource().getLocation().toURI());
            String hash;
            if (Files.isRegularFile(source)) hash = StudyIO.hash(source);
            else {
                Map<String, String> classes = new LinkedHashMap<>();
                try (var paths = Files.walk(source)) {
                    for (Path path : paths.filter(Files::isRegularFile).filter(path -> path.toString().endsWith(".class")).sorted().toList())
                        classes.put(source.relativize(path).toString().replace('\\', '/'), StudyIO.hash(path));
                }
                hash = StudyIO.hash(classes);
            }
            return Map.of("implementation_sha256", hash, "java_version", System.getProperty("java.version"),
                "identity_scope", Files.isRegularFile(source) ? "executable_jar" : "compiled_main_classes");
        } catch (java.net.URISyntaxException invalid) {
            throw new IOException("Cannot identify running JLinAlg implementation", invalid);
        }
    }

    private static Map<String, Object> manifest(String runId,
            Map<String, Object> operation, String cacheKey,
            Map<String, String> inputs, StudyOperationExecutor.Result result,
            Path staging) throws IOException {
        Map<String, Object> manifest = new LinkedHashMap<>();
        manifest.put("schema_version", 1);
        manifest.put("run_id", runId);
        manifest.put("operation_id", operation.get("id"));
        manifest.put("operation_type", operation.get("type"));
        manifest.put("hypothesis", operation.get("hypothesis"));
        manifest.put("state", result.state().value());
        manifest.put("summary", result.summary());
        manifest.put("cache_key", cacheKey);
        manifest.put("input_sha256", inputs);
        manifest.put("declared_outputs", result.outputs());
        manifest.put("details", result.details());
        Map<String, String> outputs = new LinkedHashMap<>();
        try (var paths = Files.walk(staging)) {
            for (Path path : paths.filter(Files::isRegularFile)
                    .sorted().toList()) {
                String relative = staging.relativize(path).toString()
                    .replace('\\', '/');
                if (!relative.equals("manifest.yaml"))
                    outputs.put(relative, StudyIO.hash(path));
            }
        }
        for (String output : result.outputs()) {
            Path expected = staging.resolve(output).normalize();
            if (!expected.startsWith(staging) || !Files.isRegularFile(expected))
                throw new IOException("Declared operation output is absent or unsafe: "
                    + output);
        }
        manifest.put("output_sha256", outputs);
        return manifest;
    }

    private static void provenance(Map<String,Object> manifest, StudyCacheScope.Scope scope,
            String contextHash, Map<String,Object> plan) {
        manifest.put("input_scope", scope.mode());
        manifest.put("context_hash", contextHash);
        manifest.put("execution_resolved_study_hash", plan.get("resolved_study_hash"));
        manifest.put("current_resolved_study_hash", plan.get("resolved_study_hash"));
    }

    private static Map<String, String> inputHashes(Path project,
            Map<String, Object> study, Map<String, Object> operation,
            Map<String, Path> dependencies, StudyCacheScope.Scope scope) throws IOException {
        Map<String, String> result = new LinkedHashMap<>();
        result.putAll(org.jlinalg.cli.StudyAssayQcResources.inputHashes(project,study,operation));
        result.putAll(org.jlinalg.cli.StudyNetworkResources.inputHashes(project,study,operation));
        result.putAll(org.jlinalg.cli.StudyRareOmnibusResources.inputHashes(project,study,operation));
        result.putAll(org.jlinalg.cli.StudyGseaResources.inputHashes(project,study,operation));
        result.putAll(org.jlinalg.cli.StudyRareFollowupResources.inputHashes(project,study,operation));
        result.putAll(org.jlinalg.cli.StudyRareFrequencyResources.inputHashes(project,study,operation));
        result.putAll(org.jlinalg.cli.StudyGwasEnrichmentResources.inputHashes(project,study,operation));
        result.putAll(org.jlinalg.cli.StudyRiskScoreResources.inputHashes(project,study,operation));
        result.putAll(org.jlinalg.cli.StudyProteinResources.inputHashes(project,study,operation));
        result.putAll(org.jlinalg.cli.StudyPublicLiteratureContext.inputHashes(project,study,operation));
        result.putAll(org.jlinalg.cli.StudyVariantTools.inputHashes(project,study,operation));
        if (operation.containsKey("supplied_result_id")) {
            var supplied = StudySuppliedResultPolicy.definition(study, String.valueOf(operation.get("hypothesis")),
                String.valueOf(operation.get("supplied_result_id")));
            for (var file : StudyIO.map(supplied.get("files"), "supplied result.files").entrySet()) {
                Path path = project.resolve(String.valueOf(file.getValue())).normalize();
                result.put("supplied:" + supplied.get("id") + ":" + file.getKey(), Files.isRegularFile(path) ? StudyIO.hash(path) : "missing");
            }
        }
        if (Set.of("advisor_review", "literature_support", "manuscript_draft", "impact_assessment").contains(operation.get("type"))) {
            Map<String, Object> assistance = StudyIO.optionalMap(study.get("assistance"), "assistance");
            for (Object raw : StudyIO.optionalList(assistance.get("response_files"), "assistance.response_files")) {
                Path receipt = project.resolve(String.valueOf(raw)).normalize();
                // Hash the receipt and all fixed-format companions before cache reuse, not only during execution.
                for (String name : List.of("receipt.yaml", "packet.yaml", "prompt.txt", "response.yaml", "index.html", "SESSION_HISTORY.md")) {
                    Path file = receipt.getParent().resolve(name);
                    result.put("browser_response:" + raw + ":" + name, Files.isRegularFile(file) ? StudyIO.hash(file) : "missing");
                }
            }
        }
        result.putAll(org.jlinalg.cli.StudyFindingGroupingResources.inputHashes(project,study,operation));
        Map<String, Map<String, Object>> datasets = new LinkedHashMap<>();
        for (Object value : StudyIO.list(study.get("datasets"), "datasets")) {
            Map<String, Object> dataset = StudyIO.map(value, "dataset");
            datasets.put(String.valueOf(dataset.get("id")), dataset);
        }
        for (String id : strings(operation.get("datasets"), "operation.datasets")) {
            Map<String, Object> dataset = datasets.get(id);
            if (dataset == null) continue;
            Map<String, Object> files = "full_study".equals(scope.mode())
                ? StudyIO.map(dataset.get("files"), "dataset.files")
                : StudyStageInputs.files(operation, dataset);
            for (Map.Entry<String, Object> file : files.entrySet()) {
                Path path = project.resolve(String.valueOf(file.getValue())).normalize();
                result.put("dataset:" + id + ":" + file.getKey(),
                    Files.isRegularFile(path) ? StudyIO.hash(path) : "missing");
                if (Set.of("scores", "covariance").contains(file.getKey()) && Files.isRegularFile(Path.of(path + ".tbi")))
                    result.put("dataset:" + id + ":" + file.getKey() + ":tabix", StudyIO.hash(Path.of(path + ".tbi")));
            }
        }
        for (Map.Entry<String, Path> dependency : dependencies.entrySet()) {
            Path manifest = dependency.getValue().resolve("manifest.yaml");
            if (Files.isRegularFile(manifest)) {
                Map<String, Object> source = StudyIO.loadArtifact(manifest);
                // Run IDs, reuse flags and timestamps do not change scientific inputs.
                Map<String, Object> identity = new LinkedHashMap<>();
                for (String key : List.of("state", "cache_key", "output_sha256", "details"))
                    identity.put(key, source.get(key));
                result.put("operation:" + dependency.getKey(),
                    StudyIO.hash(identity));
            }
        }
        if (Set.of("variant_annotation", "variant_scoring").contains(operation.get("type"))) {
            for (Object raw : StudyIO.list(study.get("hypotheses"), "hypotheses")) {
                var hypothesis = StudyIO.map(raw, "hypothesis");
                if (!hypothesis.get("id").equals(operation.get("hypothesis"))) continue;
                var followup = StudyIO.optionalMap(StudyIO.map(hypothesis.get("analysis"), "analysis").get("variant_followup"), "variant_followup");
                var paths = new LinkedHashMap<String, Object>();
                if (followup.containsKey("reference_fasta")) paths.put("reference_fasta", followup.get("reference_fasta"));
                for (String provider : List.of("consequences", "alphagenome")) {
                    var settings = StudyIO.optionalMap(followup.get(provider), provider);
                    for (String field : List.of("annotations", "scores", "executable", "python", "perl", "database", "cache", "fasta"))
                        if (settings.containsKey(field)) paths.put(provider + ":" + field, settings.get(field));
                }
                for (var entry : paths.entrySet()) {
                    Path path = project.resolve(String.valueOf(entry.getValue())).normalize();
                    String key = "variant_followup:" + entry.getKey();
                    if (Files.isDirectory(path)) {
                        try (var children = Files.walk(path)) {
                            for (Path file : children.filter(Files::isRegularFile).sorted().toList()) result.put(key + ":" + path.relativize(file).toString().replace('\\', '/'), StudyIO.hash(file));
                        }
                    } else result.put(key, Files.isRegularFile(path) ? StudyIO.hash(path) : "unresolved_path_or_command");
                    Path fai = Path.of(path + ".fai"); if (Files.isRegularFile(fai)) result.put(key + ":fai", StudyIO.hash(fai));
                }
            }
        }
        if (Set.of("meta_analysis", "discovery_meta_analysis", "discovery_replication", "sensitivity_analysis", "rare_variant_analysis").contains(operation.get("type"))) {
            for (Object raw : StudyIO.list(study.get("hypotheses"), "hypotheses")) {
                var hypothesis = StudyIO.map(raw, "hypothesis"); if (!hypothesis.get("id").equals(operation.get("hypothesis"))) continue;
                var analysis = StudyIO.map(hypothesis.get("analysis"), "analysis");
                var dependence = StudyIO.optionalMap(StudyPoolingPolicy.resolve(StudyIO.optionalMap(analysis.get("pooling"), "pooling")).get("dependence"), "dependence");
                if (dependence.containsKey("matrix")) { Path path = project.resolve(String.valueOf(dependence.get("matrix"))).normalize(); result.put("pooling:sampling_matrix", Files.isRegularFile(path) ? StudyIO.hash(path) : "missing"); }
            }
        }
        if (Set.of("fine_mapping", "colocalization", "mendelian_randomization").contains(operation.get("type"))) {
            Map<String, Object> resources = StudyIO.optionalMap(study.get("resources"), "resources");
            Map<String, Object> ld = StudyIO.optionalMap(resources.get("ld"), "resources.ld");
            Path resourceRoot = project.resolve(String.valueOf(resources.getOrDefault("directory", "resources"))).normalize();
            Path reference = ld.containsKey("location") ? project.resolve(String.valueOf(ld.get("location"))).normalize()
                : resourceRoot.resolve("ld").resolve(String.valueOf(ld.getOrDefault("database", "1000g-phase3")));
            Set<String> populations = new java.util.LinkedHashSet<>();
            for (Object raw : StudyIO.list(study.get("hypotheses"), "hypotheses")) {
                Map<String, Object> hypothesis = StudyIO.map(raw, "hypothesis");
                if (!hypothesis.get("id").equals(operation.get("hypothesis"))) continue;
                Map<String, Object> bio = StudyIO.optionalMap(StudyIO.map(hypothesis.get("analysis"), "analysis").get("bioinformatics"), "bioinformatics");
                for (Object pair : StudyIO.optionalList(bio.get("genetic_pairs"), "genetic_pairs")) {
                    Map<String, Object> panel = StudyIO.optionalMap(StudyIO.map(pair, "pair").get("ld"), "ld");
                    if (!panel.containsKey("file_role") && !panel.containsKey("url")) populations.add(String.valueOf(panel.getOrDefault("population", ld.getOrDefault("population", "auto"))));
                }
            }
            for (String population : populations) if (population.matches("[A-Za-z0-9_-]+")) {
                Path prefix = reference.resolve("panels").resolve(population).resolve("genotypes");
                for (String suffix : List.of(".bed", ".bim", ".fam")) {
                    Path source = Path.of(prefix + suffix);
                    if (Files.isRegularFile(source)) result.put("ld:" + population + suffix, StudyIO.hash(source));
                }
            }
        }
        return result;
    }

    private static boolean verified(Path directory, String cacheKey)
            throws IOException {
        Path manifestPath = directory.resolve("manifest.yaml");
        if (!Files.isRegularFile(manifestPath)) return false;
        Map<String, Object> manifest = StudyIO.loadArtifact(manifestPath);
        if (!"complete".equals(manifest.get("state"))
                || !cacheKey.equals(manifest.get("cache_key"))
                || Boolean.TRUE.equals(StudyIO.optionalMap(manifest.get("details"),
                    "details").get("retryable"))) return false;
        Map<String, Object> outputs = StudyIO.map(
            manifest.get("output_sha256"), "output_sha256");
        for (Map.Entry<String, Object> output : outputs.entrySet()) {
            Path path = directory.resolve(output.getKey()).normalize();
            if (!path.startsWith(directory) || !Files.isRegularFile(path)
                    || !String.valueOf(output.getValue()).equals(StudyIO.hash(path)))
                return false;
        }
        return true;
    }

    private static void event(Path project, String type, String runId,
            Map<String, Object> operation, String cacheKey, String summary,
            Path operationDirectory)
            throws IOException {
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("run_id", runId);
        payload.put("operation_id", operation.get("id"));
        payload.put("operation_type", operation.get("type"));
        payload.put("hypothesis", operation.get("hypothesis"));
        payload.put("cache_key", cacheKey);
        payload.put("manifest_sha256", StudyIO.hash(
            operationDirectory.resolve("manifest.yaml")));
        payload.put("summary", summary);
        StudyProject.append(project, type,
            new StudyProject.Actor("jlinalg", "study-executor", null), payload);
        Map<String, Object> details = StudyIO.optionalMap(StudyIO.loadArtifact(
            operationDirectory.resolve("manifest.yaml")).get("details"), "details");
        if (!type.equals("operation_reused") && "human_attested_not_observed".equals(details.get("browser_submission"))) {
            Map<String, Object> interaction = new LinkedHashMap<>(payload);
            interaction.put("summary", "Imported human-attested browser response from " + details.get("attested_provider")
                + " / " + details.get("llm_model") + "; JLinAlg did not observe external submission. " + summary);
            interaction.put("receipt", project.relativize(operationDirectory.resolve("browser-response/receipt.yaml")).toString().replace('\\', '/'));
            Map<String, Object> actor = StudyIO.map(details.get("browser_actor"), "browser_actor");
            StudyProject.append(project, "browser_handoff_response_recorded", StudyProject.Actor.human(String.valueOf(actor.get("id"))), interaction);
        }
        if (!type.equals("operation_reused") && Boolean.TRUE.equals(details.get("request_attempted"))) {
            Map<String, Object> interaction = new LinkedHashMap<>(payload);
            interaction.put("summary", "Recorded " + details.get("llm_provider") + " / "
                + details.get("llm_model") + " interaction and JLinAlg disposition: " + summary);
            interaction.put("interaction_directory", project.relativize(operationDirectory.resolve("llm/interaction-001")).toString().replace('\\', '/'));
            StudyProject.append(project, "llm_interaction_recorded", new StudyProject.Actor(
                "llm", String.valueOf(details.get("llm_provider")), String.valueOf(details.get("llm_model"))), interaction);
        }
    }

    private static List<String> strings(Object value, String name) {
        List<String> result = new ArrayList<>();
        for (Object item : StudyIO.optionalList(value, name))
            result.add(String.valueOf(item));
        return result;
    }

    private static void publish(Path staging, Path destination)
            throws IOException {
        try {
            Files.move(staging, destination, StandardCopyOption.ATOMIC_MOVE);
        } catch (AtomicMoveNotSupportedException unsupported) {
            Files.move(staging, destination);
        }
    }

    private static void copyDirectory(Path source, Path destination)
            throws IOException {
        if (Files.exists(destination))
            throw new IOException("Destination already exists: " + destination);
        try (var paths = Files.walk(source)) {
            for (Path path : paths.sorted().toList()) {
                Path target = destination.resolve(source.relativize(path));
                if (Files.isDirectory(path)) Files.createDirectories(target);
                else Files.copy(path, target, StandardCopyOption.COPY_ATTRIBUTES);
            }
        }
    }

    private static void deleteTree(Path directory) throws IOException {
        try (var paths = Files.walk(directory)) {
            for (Path path : paths.sorted(Comparator.reverseOrder()).toList())
                Files.deleteIfExists(path);
        }
    }
}
