# Tomtom inputs only; no runtime or analysis admitted

INPUT_COMPONENT_ONLY: no runtime, process, complete output family or user analysis has been admitted. Preserve raw files and verify independent execution/output gates.

ZERO_OR_MISSING_SITES: original metadata remains zero; pseudocounts use twenty, while source PSSM conversion uses a separate hundred-site fallback. No nsites XML attribute is printed for zero metadata.

REQUIRED ACTION: these are captured inputs only. Exact permitted original runtime admission, typed supervised execution and complete requested output audit are separate gates. Missing/forbidden dependencies require a prominent named skip and instructions to supply them on a permitted host; analysis never installs.

SOURCE POPULATIONS: every declared record remains in raw files and motif-ledger.jsonl. No source exclusions are silently applied. Do not infer unreported values or recompute q-values from best-match rows.

PATH MAPPING: safe staged filenames are command carriers; original paths remain literal producer metadata. Raw files are byte-identical. Display/database paths in newly generated output will refer to the staged carriers.
