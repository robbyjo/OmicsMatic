# Tomtom inputs only; no runtime or analysis admitted

STREME_XML_5_5_9_SOURCE_MAPPING: original Tomtom's reader consumes train_pos_count + test_pos_count as sites and the held-out log10 P (training log10 P without held-out counts) as its E metadata. It does not consume test_evalue or total_sites. Its new-schema background callback leaves the reader background unset, selecting uniform DNA instead of the declared XML background. Raw attributes/background remain in the unchanged input; text/XML exports therefore need not produce identical comparisons.

INPUT_COMPONENT_ONLY: no runtime, process, complete output family or user analysis has been admitted. Preserve raw files and verify independent execution/output gates.

REQUIRED ACTION: these are captured inputs only. Exact permitted original runtime admission, typed supervised execution and complete requested output audit are separate gates. Missing/forbidden dependencies require a prominent named skip and instructions to supply them on a permitted host; analysis never installs.

SOURCE POPULATIONS: every declared record remains in raw files and motif-ledger.jsonl. No source exclusions are silently applied. Do not infer unreported values or recompute q-values from best-match rows.

PATH MAPPING: safe staged filenames are command carriers; original paths remain literal producer metadata. Raw files are byte-identical. Display/database paths in newly generated output will refer to the staged carriers.
