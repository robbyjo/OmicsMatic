import java.io.*;
import java.nio.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import org.jlinalg.genetics.GctaHardcallGrm;
public class NativeGctaGrmProbe {
 static String string(DataInputStream in) throws Exception {int n=in.readInt();if(n<0||n>1000000)throw new IOException("invalid fixture string");return new String(in.readNBytes(n),StandardCharsets.UTF_8);}
 public static void main(String[] args) throws Exception {
  Path input=Path.of(args[0]),out=Path.of(args[1]);Files.createDirectory(out);
  try(DataInputStream in=new DataInputStream(Files.newInputStream(input))){
   if(in.readInt()!=0x47434731)throw new IOException("wrong fixture magic");int n=in.readInt(),m=in.readInt(),alg=in.readInt();
   List<GctaHardcallGrm.SampleId> ids=new ArrayList<>();for(int i=0;i<n;i++)ids.add(new GctaHardcallGrm.SampleId(string(in),string(in)));
   List<String> markers=new ArrayList<>();double[][] g=new double[m][n];for(int v=0;v<m;v++){markers.add(string(in));for(int i=0;i<n;i++){int b=in.readUnsignedByte();if(b>3)throw new IOException("invalid hard call");g[v][i]=b==3?Double.NaN:b;}}
   if(in.read()!=-1)throw new IOException("trailing fixture bytes");
   var result=GctaHardcallGrm.compute(ids,markers,g,alg==0?GctaHardcallGrm.Algorithm.SOURCE_0:GctaHardcallGrm.Algorithm.SOURCE_1,GctaHardcallGrm.Limits.defaults());
   float[] values=result.lowerTriangle();int[] counts=result.pairCounts();ByteBuffer a=ByteBuffer.allocate(values.length*4).order(ByteOrder.LITTLE_ENDIAN),b=ByteBuffer.allocate(counts.length*4).order(ByteOrder.LITTLE_ENDIAN);
   for(float value:values)a.putFloat(value);for(int value:counts)b.putFloat((float)value);Files.write(out.resolve("result.grm.bin"),a.array());Files.write(out.resolve("result.grm.N.bin"),b.array());
   StringBuilder text=new StringBuilder();for(var id:ids)text.append(id.familyId()).append("\t").append(id.individualId()).append("\n");Files.writeString(out.resolve("result.grm.id"),text,StandardCharsets.UTF_8);
   System.out.println("included="+result.includedMarkers()+" weight="+result.sourceOutputWeight()+" floatWeightBits="+Integer.toHexString(Float.floatToRawIntBits(result.sourceOutputWeight())));
  }
 }
}
