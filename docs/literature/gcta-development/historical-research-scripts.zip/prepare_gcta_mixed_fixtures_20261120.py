from pathlib import Path
import hashlib,json,shutil
import numpy as np
R=Path('D:/projects/JLinAlg');B=R/'build/gc-1/build/gcta-high-impact-1';F=B/'original-fixtures-2';O=B/'mixed-fixtures-1';O.mkdir(exist_ok=False);n=192;rng=np.random.Generator(np.random.PCG64(20261121))
def matrix(path):
    values=np.frombuffer(path.read_bytes(),dtype='<f4').astype(float);assert len(values)==n*(n+1)//2;a=np.zeros((n,n));k=0
    for i in range(n):a[i,:i+1]=values[k:k+i+1];a[:i+1,i]=values[k:k+i+1];k+=i+1
    return a
for label,case in [('full','grm-complete'),('A','grm-bin-A'),('B','grm-bin-B')]:
    for suffix in ['.grm.bin','.grm.N.bin','.grm.id']:shutil.copyfile(B/'original-core-2/windows'/case/('result'+suffix),O/(label+suffix))
K=matrix(O/'full.grm.bin');A=matrix(O/'A.grm.bin');C=matrix(O/'B.grm.bin');I=np.eye(n)
covariances={'positive':.7*K+.3*I,'multi':.35*A+.35*C+.30*I,'unconstrained':I-.25*K}
ids=[line.split()[:2] for line in (F/'complete.fam').read_text().splitlines()];age=np.array([float(line.split()[2]) for line in (F/'continuous.covar').read_text().splitlines()]);sex=np.array([float(line.split()[2])-1 for line in (F/'categorical.covar').read_text().splitlines()])
diagnostics={}
for label,V in covariances.items():
    eigen=np.linalg.eigvalsh(V);assert eigen.min()>0;y=np.linalg.cholesky(V)@rng.normal(size=n)+1.2+.025*(age-age.mean())+.15*sex
    (O/(label+'.pheno')).write_text(''.join(fid+'\t'+iid+'\t'+format(float(value),'.17g')+'\n' for (fid,iid),value in zip(ids,y)),encoding='utf-8',newline='\n');diagnostics[label]=dict(minimum_covariance_eigenvalue=float(eigen.min()),mean=float(y.mean()),sample_variance=float(y.var(ddof=1)))
pins={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in O.iterdir() if p.is_file()}
(O/'FIXTURE.json').write_text(json.dumps(dict(status='SYNTHETIC_MIXED_MODEL_INPUTS_NOT_AUTHOR_DATA',samples=n,generator='NumPy PCG64',seed=20261121,design='intercept plus supplied age and sex covariates',source_GRMs='Exact original Windows 1.94.1 outputs; identical scientific binary values to the Linux originals',covariance_definitions={'positive':'.7 K + .3 I','multi':'.35 A + .35 B + .30 I','unconstrained':'I - .25 K, verified positive definite; synthetic negative variance-component exploration only'},diagnostics=diagnostics,inputs=pins,new_catalog_credit=0),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Prepared fixed mixed-model inputs; covariance minima',json.dumps({k:v['minimum_covariance_eigenvalue'] for k,v in diagnostics.items()}),flush=True)
