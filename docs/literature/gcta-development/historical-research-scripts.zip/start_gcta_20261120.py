from pathlib import Path
import importlib.util,json,subprocess
R=Path('D:/projects/JLinAlg');P=R/'build/git-publish/20261120-gsea-catalog-66';T=R/'build/gc-1';O=R/'build/gcta-start-20261120-1';O.mkdir(exist_ok=False);BASE='bdf1c3e8067896131d31cbca3e7de9191aa93a0d'
def git(root,*args):return subprocess.check_output(['git','--no-replace-objects',*args],cwd=root)
def save(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
spec=importlib.util.spec_from_file_location('inventory',P.parent/'20261115-all-main-3/inventory.py');inv=importlib.util.module_from_spec(spec);spec.loader.exec_module(inv)
assert json.loads((P/'PUBLISHED.json').read_bytes())['head']==BASE and git(R,'ls-remote','origin','refs/heads/main').decode().split()[0]==BASE
previous=json.loads((P/'WORKTREES-EXPECTED.json').read_bytes());assert len(previous)==22
roots={Path(b.splitlines()[0][9:]).resolve() for b in git(R,'worktree','list','--porcelain').decode().strip().split('\n\n')};assert roots=={Path(row['root']).resolve() for row in previous}
for row in previous:assert inv.snapshot(Path(row['root']))==row,row['root']
save('WORKTREES-BEFORE.json',previous);assert not T.exists()
p=subprocess.run(['git','worktree','add','-b','codex/gcta-high-impact-20261120',str(T),BASE],cwd=R,capture_output=True);(O/'worktree.stdout').write_bytes(p.stdout);(O/'worktree.stderr').write_bytes(p.stderr);assert p.returncode==0
assert git(T,'rev-parse','HEAD').decode().strip()==BASE and not git(T,'status','--porcelain=v1','-z','--untracked-files=all')
(T/'build/gcta-high-impact-1').mkdir(parents=True);save('COMPLETED.json',dict(status='PASS_22_PRIOR_WORKTREES_AND_NEW_GCTA_CHECKOUT',base=BASE,worktrees=23,root=str(T)))
print('PASS 22 preserved worktrees; new isolated GCTA checkout',T,flush=True)
