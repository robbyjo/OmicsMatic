from pathlib import Path
import json
R=Path('D:/projects/JLinAlg');B=R/'build/gc-1/build/gcta-high-impact-1';O=B/'fixture-setup-correction-1';O.mkdir(exist_ok=False)
(O/'REASON.json').write_text(json.dumps(dict(cause='The first synthetic-fixture script stopped before creating any input because scipy was unavailable; the ungated exploratory driver then produced 18 missing-input failures, all retained in original-core-1.',correction='Use standard-library math.erfc for the identical mathematical two-sided normal-tail definition; no SciPy dependency is needed. Require a complete checksummed fixture before any new upstream process.',source_or_author_data_changed=False,old_attempts_retained=True,new_output='original-fixtures-2'),indent=2)+'\n',encoding='utf-8',newline='\n')
s=(R/'build/prepare_gcta_original_fixtures_20261120.py').read_text();s=s.replace('from scipy.stats import norm\n','').replace('original-fixtures-1','original-fixtures-2');assert 'float(2*norm.sf(abs(beta/se)))' in s;s=s.replace('float(2*norm.sf(abs(beta/se)))','math.erfc(abs(beta/se)/math.sqrt(2))')
exec(compile(s,str(Path(__file__)),'exec'))
