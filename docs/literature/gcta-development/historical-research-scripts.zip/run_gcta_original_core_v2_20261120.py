from pathlib import Path
import hashlib,json
R=Path('D:/projects/JLinAlg');F=R/'build/gc-1/build/gcta-high-impact-1/original-fixtures-2';fixture=json.loads((F/'FIXTURE.json').read_bytes())
assert fixture['samples']==192 and fixture['variants']==768
for n,w in fixture['inputs'].items():
    raw=(F/n).read_bytes();assert dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())==w,n
s=(R/'build/run_gcta_original_core_20261120.py').read_text();s=s.replace('original-fixtures-1','original-fixtures-2').replace('original-core-1','original-core-2')
s=s.replace("env=dict(os.environ,OMP_NUM_THREADS='1')","env=dict(os.environ,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')")
exec(compile(s,str(Path(__file__)),'exec'))
