from pathlib import Path,PurePosixPath
import concurrent.futures,hashlib,json,tarfile,traceback,urllib.request
R=Path('D:/projects/JLinAlg');B=R/'build/gc-1/build/gcta-high-impact-1';O=B/'upstream-1.94.1-intake-1';O.mkdir(exist_ok=False)
releases=json.loads((B/'release-metadata-1/releases.json').read_bytes());release=next(r for r in releases if r['tag_name']=='v1.94.1');tags=json.loads((B/'release-metadata-1/tags.json').read_bytes());commit=next(r['commit']['sha'] for r in tags if r['name']=='v1.94.1');assert commit=='6da64e9d8be838d01c34efb974e69c72e861f4c2'
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
specs=[]
for platform,name,maximum in [('windows','gcta-1.94.1-win-x86_64.tar.gz',32_000_000),('linux','gcta-1.94.1-linux-x86_64-static',64_000_000)]:
    asset=next(a for a in release['assets'] if a['name']==name);specs.append(dict(name=platform,url=asset['browser_download_url'],expected_bytes=asset['size'],maximum=maximum,archive=platform=='windows'))
specs.append(dict(name='source',url='https://api.github.com/repos/jianyangqt/gcta/tarball/'+commit,expected_bytes=None,maximum=64_000_000,archive=True))
def task(spec):
    root=O/spec['name'];root.mkdir();path=root/'download';count=0;digest=hashlib.sha256()
    try:
        request=urllib.request.Request(spec['url'],headers={'User-Agent':'OmicsMatic-exact-GCTA-source-runtime-intake/1.0'})
        with urllib.request.urlopen(request,timeout=45) as response,path.open('xb') as f:
            while True:
                data=response.read(1024*1024)
                if not data:break
                f.write(data);digest.update(data);count+=len(data);assert count<=spec['maximum'],'Bounded upstream download exceeded; preserve partial and do not parse'
                if count%(10*1024*1024)==0:print('Downloading',spec['name'],count,'bytes',flush=True)
            receipt=dict(requested_url=spec['url'],resolved_url=response.url,status=response.status,bytes=count,sha256=digest.hexdigest(),source_commit=commit,upstream_tag='v1.94.1',expected_publisher_bytes=spec['expected_bytes'],publisher_digest_not_supplied=True,complete=True)
            save(root/'HTTP.json',receipt)
        if spec['expected_bytes'] is not None:assert count==spec['expected_bytes'],'Publisher asset length mismatch'
        if spec['archive']:
            destination=root/'files';destination.mkdir();members=[]
            with tarfile.open(path,'r:gz') as z:
                entries=z.getmembers();assert len(entries)<=8000 and sum(max(0,i.size) for i in entries)<=512_000_000
                for item in entries:
                    name=item.name;parts=PurePosixPath(name).parts;assert name and not name.startswith('/') and '..' not in parts and '\\' not in name and ':' not in name
                    target=destination.joinpath(*parts);assert target.resolve().is_relative_to(destination.resolve())
                    if item.isdir():target.mkdir(parents=True,exist_ok=True);continue
                    assert item.isfile() and item.size<=96_000_000,'Refuse links/special/oversize archive members'
                    target.parent.mkdir(parents=True,exist_ok=True)
                    with z.extractfile(item) as stream:raw=stream.read(item.size+1)
                    assert len(raw)==item.size
                    with target.open('xb') as stream:stream.write(raw)
                    members.append(dict(name=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),upstream_mode=item.mode))
            save(root/'MEMBERS.json',members);print('Saved exact upstream',spec['name'],count,'download bytes;',len(members),'regular members',flush=True)
        else:
            assert path.read_bytes()[:4]==b'\x7fELF','Not the expected Linux ELF asset';print('Saved exact upstream Linux runtime',count,'bytes',flush=True)
        return dict(name=spec['name'],status='DOWNLOADED_AND_INVENTORIED',receipt=receipt)
    except Exception as error:
        failure=dict(name=spec['name'],error=repr(error),detail=traceback.format_exc(),received_bytes=count,source_commit=commit,analysis_executed=False);save(root/'FAILURE.json',failure);print('Exact upstream intake unavailable',spec['name'],repr(error),flush=True);return failure
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(task,specs))
save(O/'RESULTS.json',dict(status='UPSTREAM_GCTA_1_94_1_INTAKE_RUNTIME_HEALTH_NOT_YET_TESTED',source_commit=commit,upstream_license='GPL-3.0 with file-specific LGPL portions as upstream README states',results=results,software_registered_globally=False,analysis_executed=False))
