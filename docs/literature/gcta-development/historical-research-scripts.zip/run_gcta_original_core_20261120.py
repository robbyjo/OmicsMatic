from pathlib import Path
import concurrent.futures,hashlib,json,os,subprocess,time,traceback
R=Path('D:/projects/JLinAlg');T=R/'build/gc-1';B=T/'build/gcta-high-impact-1';F=B/'original-fixtures-1';I=B/'upstream-1.94.1-intake-1';O=B/'original-core-1';O.mkdir(exist_ok=False)
win=I/'windows/files/gcta-1.94.1-win-x86_64/gcta-win-1.94.1.exe';lin=I/'linux/download'
def linux(p):return '/mnt/d/'+Path(p).relative_to(Path('D:/')).as_posix()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
cases=[('grm-complete',['--bfile',F/'complete','--make-grm','--make-grm-alg','0']),('grm-missing',['--bfile',F/'missing','--make-grm','--make-grm-alg','0']),('grm-alg1',['--bfile',F/'complete','--make-grm','--make-grm-alg','1']),('grm-bin-A',['--bfile',F/'complete','--extract',F/'bin-A.snps','--make-grm','--make-grm-alg','0']),('grm-bin-B',['--bfile',F/'complete','--extract',F/'bin-B.snps','--make-grm','--make-grm-alg','0']),('cojo-select',['--bfile',F/'complete','--cojo-file',F/'quantitative.ma','--cojo-slct','--cojo-p','5e-8','--cojo-wind','10000','--cojo-collinear','0.9','--diff-freq','0.2']),('cojo-joint',['--bfile',F/'complete','--cojo-file',F/'quantitative.ma','--extract',F/'joint.snps','--cojo-joint','--cojo-collinear','0.9','--diff-freq','0.2']),('cojo-condition',['--bfile',F/'complete','--cojo-file',F/'quantitative.ma','--cojo-cond',F/'condition.snps','--cojo-collinear','0.9','--diff-freq','0.2']),('cojo-reversed',['--bfile',F/'complete','--cojo-file',F/'reversed-coherent.ma','--cojo-slct','--cojo-p','5e-8','--cojo-wind','10000','--cojo-collinear','0.9','--diff-freq','0.2'])]
def hosttask(host):
    root=O/host;root.mkdir();convert=str if host=='windows' else linux;binary=win if host=='windows' else lin;results=[]
    for name,args in cases:
        out=root/name;out.mkdir();argv=[convert(a) if isinstance(a,Path) else a for a in args]+['--thread-num','1','--out',convert(out/'result')]
        command=[str(binary),*argv] if host=='windows' else ['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','--cd',linux(out),'--exec',linux(binary),*argv]
        started=time.monotonic()
        try:
            with (out/'stdout').open('xb') as stdout,(out/'stderr').open('xb') as stderr:p=subprocess.run(command,cwd=out,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=180,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0) if host=='windows' else 0,env=dict(os.environ,OMP_NUM_THREADS='1'))
            files={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in out.iterdir() if p.is_file()}
            row=dict(name=name,host=host,command=command,exit_code=p.returncode,elapsed_seconds=time.monotonic()-started,files=files,scientific_validation_complete=False)
            save(out/'PROCESS.json',row);results.append(row);print('Original GCTA',host,name,'exit',p.returncode,'files',','.join(files),flush=True)
        except Exception as error:
            row=dict(name=name,host=host,command=command,error=repr(error),detail=traceback.format_exc(),scientific_validation_complete=False);save(out/'FAILURE.json',row);results.append(row);print('Original GCTA exploration failed',host,name,repr(error),flush=True)
    save(root/'RESULTS.json',results);return host,results
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=dict(pool.map(hosttask,['windows','linux']))
save(O/'COMPLETED.json',dict(status='ORIGINAL_GCTA_CORE_EXPLORATION_NOT_YET_JAVA_QUALIFICATION',results=results,new_catalog_credit=0,author_data_used=False))
