from pathlib import Path
import concurrent.futures,hashlib,json,os,shutil,subprocess,time,traceback
R=Path('D:/projects/JLinAlg');B=R/'build/gc-1/build/gcta-high-impact-1';F=B/'original-fixtures-2';M=B/'mixed-fixtures-1';O=B/'original-advanced-1';O.mkdir(exist_ok=False);I=B/'upstream-1.94.1-intake-1'
win=I/'windows/files/gcta-1.94.1-win-x86_64/gcta-win-1.94.1.exe';lin=I/'linux/download'
def linux(p):return '/mnt/d/'+Path(p).relative_to(Path('D:/')).as_posix()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
for folder in [F,M]:
    fixture=json.loads((folder/'FIXTURE.json').read_bytes())
    for name,wanted in fixture['inputs'].items():
        raw=(folder/name).read_bytes();assert dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())==wanted,name
def task(host):
    root=O/host;root.mkdir();convert=str if host=='windows' else linux;binary=win if host=='windows' else lin;rows=[]
    common=['--qcovar',F/'continuous.covar','--covar',F/'categorical.covar']
    cases=[('pca',['--grm',M/'full','--pca','10']),('reml-positive',['--grm',M/'full','--pheno',M/'positive.pheno','--reml','--reml-maxit','1000','--reml-est-fix','--reml-pred-rand',*common]),('reml-unconstrained',['--grm',M/'full','--pheno',M/'unconstrained.pheno','--reml','--reml-no-constrain','--reml-maxit','1000','--reml-est-fix','--reml-pred-rand',*common]),('reml-multi',None),('ld-score',['--bfile',F/'complete','--ld-score','--ld-wind','1000','--ld-rsq-cutoff','0']),('ld-score-adjusted',['--bfile',F/'complete','--ld-score','--ld-score-adj','--ld-wind','1000','--ld-rsq-cutoff','0']),('ld-score-region',['--bfile',F/'complete','--ld-score-region','200','--ld-wind','1000','--ld-rsq-cutoff','0']),('sparse-grm',['--grm',M/'full','--make-bK-sparse','0.05']),('fastGWA-binary',['--bfile',F/'complete','--grm-sparse',root/'sparse-grm/result','--pheno',F/'binary.pheno','--fastGWA-mlm-binary','--seed','2026','--num-vec','10',*common])]
    for name,args in cases:
        out=root/name;out.mkdir()
        if name=='reml-multi':
            inputs=out/'inputs';inputs.mkdir()
            for label in ['A','B']:
                for suffix in ['.grm.bin','.grm.N.bin','.grm.id']:shutil.copyfile(M/(label+suffix),inputs/(label+suffix))
            listing=inputs/'mgrm.list';listing.write_bytes(b'inputs/A\ninputs/B\n');args=['--mgrm',listing,'--pheno',M/'multi.pheno','--reml','--reml-maxit','1000','--reml-est-fix','--reml-pred-rand',*common]
        argv=[convert(a) if isinstance(a,Path) else a for a in args]+['--thread-num','1','--out',convert(out/'result')]
        command=[str(binary),*argv] if host=='windows' else ['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','--cd',linux(out),'--exec',linux(binary),*argv];started=time.monotonic()
        try:
            with (out/'stdout').open('xb') as stdout,(out/'stderr').open('xb') as stderr:p=subprocess.run(command,cwd=out,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=180,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0) if host=='windows' else 0,env=dict(os.environ,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'))
            files={p.relative_to(out).as_posix():dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in out.rglob('*') if p.is_file()};row=dict(name=name,host=host,command=command,exit_code=p.returncode,elapsed_seconds=time.monotonic()-started,files=files,scientific_validation_complete=False);save(out/'PROCESS.json',row);rows.append(row);print('Original advanced GCTA',host,name,'exit',p.returncode,'files',','.join(files),flush=True)
        except Exception as error:
            row=dict(name=name,host=host,command=command,error=repr(error),detail=traceback.format_exc(),scientific_validation_complete=False);save(out/'FAILURE.json',row);rows.append(row);print('Original advanced GCTA unavailable',host,name,repr(error),flush=True)
    save(root/'RESULTS.json',rows);return host,rows
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=dict(pool.map(task,['windows','linux']))
save(O/'COMPLETED.json',dict(status='ORIGINAL_GCTA_ADVANCED_EXPLORATION_NOT_YET_JAVA_QUALIFICATION',results=results,new_catalog_credit=0,author_data_used=False))
