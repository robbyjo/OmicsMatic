from pathlib import Path
import hashlib,json
import numpy as np
R=Path('D:/projects/JLinAlg');T=R/'build/gc-1';B=T/'build/gcta-high-impact-1';F=B/'original-fixtures-2';C=B/'original-core-2';O=B/'core-output-inspection-1';O.mkdir(exist_ok=False)
records=json.loads((F/'dosages.json').read_bytes());g=np.asarray(records['dosages'],dtype=float);missing=np.asarray(records['missing_dosages'],dtype=float);n=g.shape[1];rows=[]
def matrix(path):
    a=np.frombuffer(path.read_bytes(),dtype='<f4').astype(float);assert len(a)==n*(n+1)//2;result=np.zeros((n,n));k=0
    for i in range(n):
        result[i,:i+1]=a[k:k+i+1];result[:i+1,i]=a[k:k+i+1];k+=i+1
    return result
for mode in ['grm-complete','grm-missing','grm-alg1','grm-bin-A','grm-bin-B']:
    source=missing if mode=='grm-missing' else g[:384] if mode=='grm-bin-A' else g[384:] if mode=='grm-bin-B' else g
    mask=source>=0;called=mask.sum(axis=1);mean=np.where(mask,source,0).sum(axis=1)/called;variance=2*(mean/2)*(1-mean/2);centered=np.where(mask,source-mean[:,None],0)
    standardized=centered/np.sqrt(variance[:,None]);counts=mask.astype(float).T@mask.astype(float)
    expected=(standardized.T@standardized)/counts
    weighted=(centered.T@centered)/variance.sum()
    for host in ['windows','linux']:
        root=C/host/mode;process=json.loads((root/'PROCESS.json').read_bytes());assert process['exit_code']==0
        actual=matrix(root/'result.grm.bin');actualN=matrix(root/'result.grm.N.bin')
        row=dict(host=host,mode=mode,samples=n,markers=len(source),pairwise_counts_exact=bool(np.array_equal(actualN,counts)),max_absolute_error_standardized_pairwise=float(np.max(np.abs(actual-expected))),max_absolute_error_weighted_common_variance=float(np.max(np.abs(actual-weighted))),symmetry_error=float(np.max(np.abs(actual-actual.T))),minimum_eigenvalue=float(np.linalg.eigvalsh(actual).min()))
        rows.append(row);print(json.dumps(row),flush=True)
compared=[]
for mode in ['grm-complete','grm-missing','grm-alg1','grm-bin-A','grm-bin-B','cojo-select','cojo-joint','cojo-condition','cojo-reversed']:
    win=C/'windows'/mode;lin=C/'linux'/mode
    for p in sorted(win.glob('result.*')):
        if p.suffix=='.log':continue
        other=lin/p.name;assert other.is_file();a=p.read_bytes();b=other.read_bytes();row=dict(mode=mode,name=p.name,raw_bytes_equal=a==b,windows_bytes=len(a),linux_bytes=len(b))
        if p.suffix=='.bin':
            aa=np.frombuffer(a,dtype='<f4').astype(float);bb=np.frombuffer(b,dtype='<f4').astype(float);assert aa.shape==bb.shape;row['max_absolute_float32_difference']=float(np.max(np.abs(aa-bb)));row['different_float32_cells']=int(np.count_nonzero(aa!=bb))
        else:row['whitespace_token_fields_equal']=a.split()==b.split()
        compared.append(row)
print('CROSS PLATFORM SCIENTIFIC OUTPUTS',json.dumps(compared,indent=2),flush=True)
for name in ['cojo-select','cojo-joint','cojo-condition','cojo-reversed']:
    root=C/'windows'/name;print('\n'+name,flush=True)
    for p in sorted(root.glob('result.*cojo')):
        text=p.read_text(errors='replace');print(p.name+'\n'+'\n'.join(text.splitlines()[:5]),flush=True)
(O/'INSPECTION.json').write_text(json.dumps(dict(status='EXPLORATORY_ORIGINAL_OUTPUT_INSPECTION_NOT_JAVA_QUALIFICATION',GRM_comparisons=rows,cross_platform_scientific_outputs=compared,new_catalog_credit=0),indent=2)+'\n',encoding='utf-8',newline='\n')
