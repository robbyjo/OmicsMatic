from pathlib import Path
import concurrent.futures,hashlib,json,traceback,urllib.request
R=Path('D:/projects/JLinAlg');O=R/'build/gc-1/build/gcta-high-impact-1/release-metadata-1';O.mkdir(exist_ok=False)
def task(name):
    paths={'releases':'releases?per_page=100','tags':'tags?per_page=100','head':'commits/master'};url='https://api.github.com/repos/jianyangqt/gcta/'+paths[name]
    try:
        request=urllib.request.Request(url,headers={'User-Agent':'OmicsMatic-GCTA-source-intake/1.0','Accept':'application/vnd.github+json'})
        with urllib.request.urlopen(request,timeout=45) as response:
            raw=response.read(4_000_001);assert len(raw)<=4_000_000;(O/(name+'.json')).write_bytes(raw)
            (O/(name+'.HTTP.json')).write_text(json.dumps(dict(url=url,resolved_url=response.url,status=response.status,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()),indent=2)+'\n',encoding='utf-8',newline='\n')
        data=json.loads(raw)
        if name=='releases':print('RELEASES',json.dumps([dict(tag=r['tag_name'],published=r['published_at'],draft=r['draft'],prerelease=r['prerelease'],assets=[dict(name=a['name'],bytes=a['size'],download=a['browser_download_url'],digest=a.get('digest')) for a in r['assets']]) for r in data],indent=2),flush=True)
        elif name=='tags':print('TAGS',json.dumps([dict(name=r['name'],sha=r['commit']['sha']) for r in data],indent=2),flush=True)
        else:print('CURRENT SOURCE HEAD',data['sha'],data['commit']['committer']['date'],flush=True)
    except Exception as error:(O/(name+'.FAILURE.json')).write_text(json.dumps(dict(error=repr(error),detail=traceback.format_exc(),url=url),indent=2)+'\n',encoding='utf-8',newline='\n');print('Metadata intake unavailable',name,repr(error),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(task,['releases','tags','head']))
