from pathlib import Path
import concurrent.futures,json,os,struct,subprocess
R=Path('D:/projects/JLinAlg');T=R/'build/gc-1';B=T/'build/gcta-high-impact-1';F=B/'original-fixtures-2';O=B/'native-grm-initial-1';O.mkdir(exist_ok=False)
fixture=json.loads((F/'dosages.json').read_bytes());source=T/'src/main/java/org/jlinalg/genetics/GctaHardcallGrm.java';JDK=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin');J25=Path('C:/Program Files/Java/jdk-25/bin/java.exe')
probe=O/'NativeGctaGrmProbe.java';probe.write_text('''import java.io.*;
import java.nio.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import org.jlinalg.genetics.GctaHardcallGrm;
public class NativeGctaGrmProbe {
 static String string(DataInputStream in) throws Exception {int n=in.readInt();if(n<0||n>1000000)throw new IOException("invalid fixture string");return new String(in.readNBytes(n),StandardCharsets.UTF_8);}
 public static void main(String[] args) throws Exception {
  Path input=Path.of(args[0]),out=Path.of(args[1]);Files.createDirectory(out);
  try(DataInputStream in=new DataInputStream(Files.newInputStream(input))){
   if(in.readInt()!=0x47434731)throw new IOException("wrong fixture magic");int n=in.readInt(),m=in.readInt(),alg=in.readInt();
   List<GctaHardcallGrm.SampleId> ids=new ArrayList<>();for(int i=0;i<n;i++)ids.add(new GctaHardcallGrm.SampleId(string(in),string(in)));
   List<String> markers=new ArrayList<>();double[][] g=new double[m][n];for(int v=0;v<m;v++){markers.add(string(in));for(int i=0;i<n;i++){int b=in.readUnsignedByte();if(b>3)throw new IOException("invalid hard call");g[v][i]=b==3?Double.NaN:b;}}
   if(in.read()!=-1)throw new IOException("trailing fixture bytes");
   var result=GctaHardcallGrm.compute(ids,markers,g,alg==0?GctaHardcallGrm.Algorithm.SOURCE_0:GctaHardcallGrm.Algorithm.SOURCE_1,GctaHardcallGrm.Limits.defaults());
   float[] values=result.lowerTriangle();int[] counts=result.pairCounts();ByteBuffer a=ByteBuffer.allocate(values.length*4).order(ByteOrder.LITTLE_ENDIAN),b=ByteBuffer.allocate(counts.length*4).order(ByteOrder.LITTLE_ENDIAN);
   for(float value:values)a.putFloat(value);for(int value:counts)b.putFloat((float)value);Files.write(out.resolve("result.grm.bin"),a.array());Files.write(out.resolve("result.grm.N.bin"),b.array());
   StringBuilder text=new StringBuilder();for(var id:ids)text.append(id.familyId()).append("\\t").append(id.individualId()).append("\\n");Files.writeString(out.resolve("result.grm.id"),text,StandardCharsets.UTF_8);
   System.out.println("included="+result.includedMarkers()+" weight="+result.sourceOutputWeight()+" floatWeightBits="+Integer.toHexString(Float.floatToRawIntBits(result.sourceOutputWeight())));
  }
 }
}
''',encoding='utf-8',newline='\n')
classes=O/'classes';classes.mkdir();command=[str(JDK/'javac.exe'),'-encoding','UTF-8','-d',str(classes),str(source),str(probe)];p=subprocess.run(command,capture_output=True,timeout=90);(O/'javac.stdout').write_bytes(p.stdout);(O/'javac.stderr').write_bytes(p.stderr);assert p.returncode==0
cases={}
for name,key,start,end,algorithm in [('grm-complete','dosages',0,768,0),('grm-missing','missing_dosages',0,768,0),('grm-alg1','dosages',0,768,1),('grm-bin-A','dosages',0,384,0),('grm-bin-B','dosages',384,768,0)]:
    data=bytearray(struct.pack('>4I',0x47434731,192,end-start,algorithm))
    def string(s):
        raw=s.encode('utf-8');data.extend(struct.pack('>I',len(raw)));data.extend(raw)
    for sample in fixture['sample_ids']:string(sample['FID']);string(sample['IID'])
    for variant,row in zip(fixture['variants'][start:end],fixture[key][start:end]):string(variant['id']);data.extend(bytes(3 if x==-1 else x for x in row))
    path=O/(name+'.input.bin');path.write_bytes(data);cases[name]=path
def linux(p):return '/mnt/d/'+Path(p).relative_to(Path('D:/')).as_posix()
def task(host):
    root=O/host;root.mkdir();rows=[]
    for name,input in cases.items():
        out=root/name
        if host=='linux-java21':command=['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','--exec','/usr/bin/java','-cp',linux(classes),'NativeGctaGrmProbe',linux(input),linux(out)]
        else:command=[str(JDK/'java.exe' if host=='windows-java21' else J25),'-cp',str(classes),'NativeGctaGrmProbe',str(input),str(out)]
        p=subprocess.run(command,cwd=root,stdin=subprocess.DEVNULL,capture_output=True,timeout=120);(root/(name+'.stdout')).write_bytes(p.stdout);(root/(name+'.stderr')).write_bytes(p.stderr);assert p.returncode==0,(host,name,p.stderr.decode(errors='replace'))
        reference=B/'original-core-2/windows'/name;differences={}
        for file in ['result.grm.bin','result.grm.N.bin']:
            a=(out/file).read_bytes();b=(reference/file).read_bytes();assert len(a)==len(b);different=[i//4 for i in range(0,len(a),4) if a[i:i+4]!=b[i:i+4]]
            differences[file]=dict(fields=len(a)//4,different_fields=len(different),first_differing_fields=different[:8])
        assert (out/'result.grm.id').read_bytes().split()==(reference/'result.grm.id').read_bytes().split()
        row=dict(name=name,host=host,command=command,exit_code=0,differences=differences,scientific_qualification_not_yet_complete=True);rows.append(row);print('Native initial GRM',host,name,json.dumps(differences),p.stdout.decode(errors='replace').strip(),flush=True)
    (root/'RESULTS.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n');return host,rows
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=dict(pool.map(task,['windows-java21','windows-java25','linux-java21']))
(O/'RESULTS.json').write_text(json.dumps(dict(status='INITIAL_NATIVE_GCTA_GRM_SOURCE_COUNTERPART_CHECKS',results=results,new_catalog_credit=0),indent=2)+'\n',encoding='utf-8',newline='\n')
