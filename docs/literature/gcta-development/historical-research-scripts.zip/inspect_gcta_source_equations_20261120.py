from pathlib import Path
import gzip,json,sys,xml.etree.ElementTree as ET
R=Path('D:/projects/JLinAlg');T=R/'build/gc-1';papers=json.loads((T/'docs/literature/omics-2023-2026/papers.json').read_bytes());p=next(p for p in papers if p['paper_id']=='P248')
with gzip.open(R/'build/literature-review/xml'/(p['pmcid']+'.xml.gz'),'rb') as f:root=ET.fromstring(f.read())
O=T/'build/gcta-high-impact-1/P248-formula-audit-1';O.mkdir(exist_ok=False)
for i,node in enumerate(root.iter('p')):
    text=''.join(node.itertext())
    if 'rare variants were defined' in text:
        raw=ET.tostring(node,encoding='utf-8');(O/'primary-formula-context.xml').write_bytes(raw)
        for math in node.iter():
            if math.tag.endswith('math'):print(ET.tostring(math,encoding='unicode'),flush=True)
        print('SOURCE PARAGRAPH',text,flush=True)
