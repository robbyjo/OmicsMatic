from pathlib import Path
import concurrent.futures,hashlib,json,re,traceback,urllib.request
R=Path('D:/projects/JLinAlg');O=R/'build/gcta-primary-http-intake-20261120-1';O.mkdir(exist_ok=False)
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
def task(spec):
    name,url,maximum=spec;root=O/name;root.mkdir()
    try:
        request=urllib.request.Request(url,headers={'User-Agent':'OmicsMatic-GCTA-source-audit/1.0','Accept':'application/vnd.github+json' if 'api.github.com' in url else '*/*'})
        with urllib.request.urlopen(request,timeout=45) as response:
            raw=response.read(maximum+1);(root/'body').write_bytes(raw);receipt=dict(requested_url=url,resolved_url=response.url,status=response.status,content_type=response.headers.get('Content-Type'),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),maximum_bytes=maximum)
            save(root/'HTTP.json',receipt);assert len(raw)<=maximum,'Bounded intake exceeded; preserve partial and do not parse'
        text=raw.decode('utf-8',errors='replace');links=[]
        if name=='official':
            links=list(dict.fromkeys(re.findall(r'(?:href|src)=[\"\']([^\"\']+)[\"\']',text,re.I)));save(root/'LINKS.json',links)
        if name=='repository':
            data=json.loads(raw);print('GCTA repository',json.dumps({k:data.get(k) for k in ['full_name','default_branch','html_url','homepage','license','archived','pushed_at']}),flush=True)
        elif name=='license':print('GCTA source license',text[:650],flush=True)
        elif name=='readme':print('GCTA source README',text[:2200],flush=True)
        else:
            selected=[u for u in links if any(s in u.lower() for s in ['gcta','github','license','download'])];print('Official source links',json.dumps(selected[:65],indent=2),flush=True)
        return dict(name=name,http=receipt)
    except Exception as error:
        failure=dict(name=name,error=repr(error),detail=traceback.format_exc(),url=url);save(root/'FAILURE.json',failure);print('GCTA source intake unavailable',name,repr(error),flush=True);return failure
specs=[('official','https://yanglab.westlake.edu.cn/software/gcta/',8_000_000),('repository','https://api.github.com/repos/jianyangqt/gcta',1_000_000),('readme','https://raw.githubusercontent.com/jianyangqt/gcta/master/README.md',1_000_000),('license','https://raw.githubusercontent.com/jianyangqt/gcta/master/LICENSE',1_000_000)]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(task,specs))
save(O/'RESULTS.json',dict(primary_HTTP_intake=True,browsing_tool_temporarily_unavailable=True,results=results,software_installed=False,analysis_executed=False))
