from pathlib import Path
import hashlib,json,math,struct
import numpy as np
from scipy.stats import norm
R=Path('D:/projects/JLinAlg');T=R/'build/gc-1';O=T/'build/gcta-high-impact-1/original-fixtures-1';O.mkdir(exist_ok=False)
n=192;m=768;seed=20261120;rng=np.random.Generator(np.random.PCG64(seed));frequencies=.12+.04*(np.arange(m)%9)
g=np.vstack([rng.binomial(2,p,size=n) for p in frequencies]).astype(np.int8)
# Deliberately correlated, distinct predictors test source collinearity handling.
g[1]=g[0];change=rng.choice(n,size=18,replace=False);g[1,change]=rng.binomial(2,.25,size=len(change))
ids=[('F%04d'%(i//2+1),'I%04d'%(i+1)) for i in range(n)]
variants=[dict(id='rs%05d'%(j+1),chromosome=j//192+1,position=(j%192+1)*10000,A1='A' if j%2==0 else 'C',A2='G' if j%2==0 else 'T') for j in range(m)]
fam=''.join('%s %s 0 0 %d -9\n'%(fid,iid,1+i%2) for i,(fid,iid) in enumerate(ids))
bim=''.join('%d\t%s\t0\t%d\t%s\t%s\n'%(v['chromosome'],v['id'],v['position'],v['A1'],v['A2']) for v in variants)
def bed(matrix):
    # PLINK SNP-major: 00=A1/A1, 10=A1/A2, 11=A2/A2, 01=missing.
    result=bytearray([0x6c,0x1b,1]);codes={0:3,1:2,2:0,-1:1}
    for row in matrix:
        for start in range(0,n,4):
            byte=0
            for shift,value in enumerate(row[start:start+4]):byte|=codes[int(value)]<<(2*shift)
            result.append(byte)
    return bytes(result)
missing=g.copy();missing[rng.random(g.shape)<.05]=-1
for name,matrix in [('complete',g),('missing',missing)]:
    (O/(name+'.fam')).write_text(fam,encoding='utf-8',newline='\n');(O/(name+'.bim')).write_text(bim,encoding='utf-8',newline='\n');(O/(name+'.bed')).write_bytes(bed(matrix))
age=rng.uniform(20,75,n);sex=np.arange(n)%2
y=2.0*g[0]+1.4*g[149]+.9*g[399]+.01*(age-age.mean())+.3*sex+rng.normal(0,.7,n);y=(y-y.mean())/y.std(ddof=1)
latent=.9*(g[0]-g[0].mean())+.6*(g[149]-g[149].mean())+rng.normal(0,1.5,n);binary=(latent>np.quantile(latent,.62)).astype(int)
for name,values in [('quantitative.pheno',y),('binary.pheno',binary)]:
    (O/name).write_text(''.join(fid+'\t'+iid+'\t'+format(float(value),'.17g')+'\n' for (fid,iid),value in zip(ids,values)),encoding='utf-8',newline='\n')
(O/'continuous.covar').write_text(''.join(fid+'\t'+iid+'\t'+format(float(value),'.17g')+'\n' for (fid,iid),value in zip(ids,age)),encoding='utf-8',newline='\n')
(O/'categorical.covar').write_text(''.join(fid+'\t'+iid+'\t'+str(1+int(value))+'\n' for (fid,iid),value in zip(ids,sex)),encoding='utf-8',newline='\n')
summary=['SNP\tA1\tA2\tfreq\tb\tse\tp\tN'];reverse=[summary[0]];rows=[]
for j,v in enumerate(variants):
    x=g[j].astype(float);frequency=float(x.mean()/2);centered=x-x.mean();sxx=float(centered@centered);beta=float(centered@y/sxx);residual=y-beta*centered;variance=float(residual@residual/(n-2));se=math.sqrt(variance/sxx);p=float(2*norm.sf(abs(beta/se)))
    assert 0<frequency<1 and 0<p<=1 and se>0
    row=[v['id'],v['A1'],v['A2'],format(frequency,'.17g'),format(beta,'.17g'),format(se,'.17g'),format(p,'.17g'),str(n)];summary.append('\t'.join(row))
    if j%7==0:row=[v['id'],v['A2'],v['A1'],format(1-frequency,'.17g'),format(-beta,'.17g'),format(se,'.17g'),format(p,'.17g'),str(n)]
    reverse.append('\t'.join(row));rows.append(dict(variant=v['id'],effect=beta,SE=se,P=p,frequency_A1=frequency,N=n))
(O/'quantitative.ma').write_text('\n'.join(summary)+'\n',encoding='utf-8',newline='\n');(O/'reversed-coherent.ma').write_text('\n'.join(reverse)+'\n',encoding='utf-8',newline='\n')
for name,selected in [('bin-A.snps',variants[:384]),('bin-B.snps',variants[384:]),('condition.snps',[variants[0]]),('joint.snps',[variants[0],variants[149],variants[399]])]:
    (O/name).write_text(''.join(v['id']+'\n' for v in selected),encoding='utf-8',newline='\n')
(O/'dosages.json').write_text(json.dumps(dict(sample_ids=[dict(FID=f,IID=i) for f,i in ids],variants=variants,dosages=g.tolist(),missing_dosages=missing.tolist()),separators=(',',':'))+'\n',encoding='utf-8',newline='\n')
pins={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in O.iterdir() if p.is_file()}
(O/'FIXTURE.json').write_text(json.dumps(dict(schema_version=1,status='SYNTHETIC_EXPLICIT_GCTA_FIXTURES_NOT_AUTHOR_DATA',generator='NumPy PCG64',seed=seed,numpy=np.__version__,samples=n,variants=m,genotype_encoding='A1 hard-call count; explicit PLINK SNP-major byte map',GWAS_summary='single-marker ordinary linear effects/estimated SE and two-sided asymptotic Wald-normal P; no original GWAS pipeline claim',case_code=1,control_code=0,binary_cases=int(binary.sum()),purpose='Independent original-runtime exploration; no model qualified merely by fixture creation',inputs=pins),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Prepared synthetic original inputs:',n,'samples,',m,'variants,',int(binary.sum()),'cases; no analysis or catalog credit',flush=True)
