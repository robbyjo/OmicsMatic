from pathlib import Path
import concurrent.futures,hashlib,json,os,subprocess,traceback
R=Path('D:/projects/JLinAlg');T=R/'build/gc-1';B=T/'build/gcta-high-impact-1';I=B/'upstream-1.94.1-intake-1';O=B/'runtime-launch-1';O.mkdir(exist_ok=False)
win=I/'windows/files/gcta-1.94.1-win-x86_64/gcta-win-1.94.1.exe';lin=I/'linux/download'
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
def linux(p):return '/mnt/d/'+Path(p).relative_to(Path('D:/')).as_posix()
def task(host):
    out=O/host;out.mkdir();binary=win if host=='windows' else lin;raw=binary.read_bytes();producer=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
    if host=='windows':command=[str(binary)];flags=getattr(subprocess,'CREATE_NO_WINDOW',0)
    else:
        chmod=subprocess.run(['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','--exec','/usr/bin/chmod','u+x',linux(binary)],capture_output=True,timeout=30);(out/'chmod.stdout').write_bytes(chmod.stdout);(out/'chmod.stderr').write_bytes(chmod.stderr);assert chmod.returncode==0
        command=['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','--cd',linux(out),'--exec',linux(binary)];flags=0
    # Source src/main.cpp explicitly returns 1 with this diagnostic for argc==1.
    try:
        p=subprocess.run(command,cwd=out,stdin=subprocess.DEVNULL,capture_output=True,timeout=30,creationflags=flags,env=dict(os.environ,OMP_NUM_THREADS='1'))
        (out/'stdout').write_bytes(p.stdout);(out/'stderr').write_bytes(p.stderr);text=(p.stdout+p.stderr).decode('utf-8',errors='replace')
        healthy=p.returncode==1 and '* version v1.94.1' in text and 'Error: no analysis has been launched by the option(s)' in text
        result=dict(host=host,command=command,producer=producer,exit_code=p.returncode,expected_no_analysis_exit=1,launch_health_verified=healthy,analysis_executed=False,complete_analysis_result=False)
        if not healthy:result['required_action']='SKIP3 for dependent analysis until this exact permitted runtime and required platform libraries are available; inspect launch stdout/stderr. Do not substitute an edition.'
        save(out/'PROCESS.json',result);print(host,json.dumps(result,indent=2),text[:950],flush=True);return host,result
    except Exception as error:
        result=dict(host=host,command=command,producer=producer,error=repr(error),detail=traceback.format_exc(),launch_health_verified=False,analysis_executed=False);save(out/'FAILURE.json',result);print(host,repr(error),flush=True);return host,result
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=dict(pool.map(task,['windows','linux']))
save(O/'COMPLETED.json',dict(status='GCTA_1_94_1_RUNTIME_LAUNCH_PROBES_ONLY',results=results,analysis_executed=False,new_catalog_credit=0))
