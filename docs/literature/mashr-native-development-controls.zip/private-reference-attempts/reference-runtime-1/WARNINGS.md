# mashr SKIP3_DEPENDENCY_UNAVAILABLE

Required official CRAN binary unavailable: https://cran.r-project.org/bin/windows/contrib/4.6/rmeta_3.0.zip;<urlopen error [WinError 10054] An existing connection was forcibly closed by the remote host>

Preserve all partial downloads,packages and logs. If installation/download or the required exact binary/dependency is unavailable,keep dependent analysis skipped. Use a supported permitted R4.6.1 Windows x64 host or resolve the named requirement;retry to NEW paths. This reference setup and tiny synthetic health check do not admit study results or reproduce a paper.
