from pathlib import Path
import gzip,hashlib,json,sys,zipfile,xml.etree.ElementTree as ET
from datetime import datetime,timezone
ROOT=Path('D:/projects/JLinAlg');BASE=ROOT/'build/literature-review/mashr-runtime';OUT=BASE/'native-development-1';DOC=ROOT/'docs/literature'
sys.path.insert(0,str(ROOT/'tools/literature'))
from collect_omics_review import paragraphs
def pin(path):
 h=hashlib.sha256();size=0
 with path.open('rb') as stream:
  for block in iter(lambda:stream.read(1048576),b''):h.update(block);size+=len(block)
 return dict(bytes=size,sha256=h.hexdigest())
def write(path,value):
 assert not path.exists(),path
 path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
models={
 'P019':([51],None,'Class-level S-snTWAS uses Z proxies as Bhat with SE1 and explicitly supplies zero/SE1e10 for missing cells. Learn data-driven covariances; retain the stated LFSR<=0.05 cell-count specificity definition and the excluded EUR Endo/mural population. Z proxies are not original effect magnitudes.'),
 'P021':([94,95,97,101],'0.2.79','Adapted dreamlet run_mash applies multivariate shrinkage across neuronal/glial cell classes. Posterior means, variances and false-sign rates support sharing tests. Products of marginal sign-concordance probabilities are paper-specific composites, not certified joint posterior probabilities.'),
 'P024':([84],None,'MASH integrates gene/cell-type effects across disease contrasts, followed by paper-specific composite sharing tests. Retain the literal stated posterior-probability>=0.05 threshold; do not silently replace it with 0.95. The separate formal test and exact contrast construction still require review.'),
 'P073':([42],'0.2.79','Learn correlations from a random 20,000-test population and data-driven covariances from strong top cis-sQTL tests, then apply the model to the strong set. The paragraph describes nominal P-value input without a complete signed-effect/SE conversion. Do not invent directions or fit mixture proportions only on strong hits.'),
 'P092':([55,56,57],None,'Multivariate caQTL shrinkage across cell types is delegated to a Supplementary Note that remains unaudited. Subsequent motif disruption/Spearman/BH analysis is separate. Pairwise effect correlations select QTLs significant in either mashR cell type and use RASQUAL effects, filling downstream missing effects with zero; that does not establish the mashR input policy.'),
 'P104':([47],'0.2.79','Estimate the prior effect distribution using genes expressed across all cell types and empirical correlation using 600,000 random variant-trait pairings. Targets use minimum-P variants for genes significant in at least one cell type and coefficient/SE inputs. Unanalyzed gene/cell-type coefficients are zero with SE1e6; preserve this explicit policy separately from SE1e10.'),
 'P201':([15,27],None,'Indonesian/GTEx/BLUEPRINT sQTL sharing uses QTLTools effects/SEs, a random 40% test set for null correlation and prior fitting, and strong minimum-P SNP/intron-cluster sets for data-driven covariance learning and posterior targets. Sharing requires matching sign and magnitudes within the stated factor0.5, with LFSR<0.05 significance. Retain MAF-driven untested variants and denominator uncertainty.'),
 'P213':([12],None,'Cell-type meta-analysis uses Z scores derived from log2FC, canonical covariances and residual measurement-correlation EM. Untested log2FC values are zero, but a complete Z/SE conversion is unreported. LFSR<0.05 and cell-type |log2FC|>0.1 are separate thresholds on distinct scales. Seurat/MAST are upstream steps.')}
papers={r['paper_id']:r for r in json.loads((DOC/'omics-2023-2026/papers.json').read_text())}
roles=[]
for paper_id,(indices,version,role) in models.items():
 paper=papers[paper_id];xml=ROOT/'build/literature-review/xml'/(paper['pmcid']+'.xml.gz');paras={p['paragraph_index']:p for p in paragraphs(ET.fromstring(gzip.decompress(xml.read_bytes())))}
 evidence=[dict(paragraph_index=i,section=paras[i]['section'],text_sha256=hashlib.sha256(paras[i]['text'].encode()).hexdigest()) for i in indices]
 roles.append(dict(paper_id=paper_id,doi=paper['doi'],pmcid=paper['pmcid'],title=paper['title'],source_xml_pin=pin(xml),evidence=evidence,reported_version=version,role_paraphrase=role,status='draft-not-curated-for-catalog',paper_reproduction_claimed=False))
draft=dict(schema_version=1,status='draft-eight-paper-mashr-role-audit-incomplete',native_foundation_covers='supplied common-residual Gaussian mixtures, canonical bases and fixed-likelihood proportions only',supplement_review_open=['P092'],roles=roles,tool_inventory_status_unchanged='missing',unreported_settings_inferred=False)
draft_path=DOC/'MASHR_PAPER_ROLE_DRAFT.json';write(draft_path,draft)
matrix_path=OUT/'packaged-tests-1/COMPLETED.json';matrix=json.loads(matrix_path.read_text());assert matrix['status']=='passed-native-mashr-foundation-actual-JAR-matrix'
assert matrix['tests_per_JVM']==181 and len(matrix['runs'])==3
for name,expected in matrix['source_and_dependency_pins'].items():assert pin(ROOT/name)==expected,name
for p in sorted((ROOT/'build/test-results/test').glob('TEST-*shrinkage*.xml')):
 r=ET.parse(p).getroot();assert all(int(r.attrib[k])==0 for k in ['failures','errors','skipped'])
assert sum(int(ET.parse(p).getroot().attrib['tests']) for p in (ROOT/'build/test-results/test').glob('TEST-*shrinkage*.xml'))==181
example=(OUT/'example-1.log').read_text();assert len([r for r in example.splitlines() if r and r[0].isdigit()])==8 and 'SYNTHETIC native' in example
jar=ROOT/matrix['artifact']['path'];assert pin(jar)=={k:matrix['artifact'][k] for k in ['bytes','sha256']}
canonical=ROOT/'build/cli/omicsmatic-0.3.7.jar';assert pin(canonical)==matrix['canonical_artifact_unchanged']
assert pin(canonical)['sha256']=='bd1a3b2448d7016ae4ded3f30a6c5ae92e05a0078ae688f4b93d046cc355eeb2'
dependency=ROOT/'build/dependencies/jdistlib-all-0.10.2.jar'
assert pin(dependency)['sha256']=='8b50aaa11d2cbd512525e0d74f8e609f40db9f4fc179ccb7a885a82257e0ac81'
with zipfile.ZipFile(jar) as candidate,zipfile.ZipFile(dependency) as original:
 jnames=[n for n in original.namelist() if n.startswith('jdistlib/') and not n.endswith('/')]
 assert all(candidate.read(n)==original.read(n) for n in jnames)
 dependency_binding=dict(dependency=pin(dependency),unchanged_jdistlib_members=len(jnames))
paths=[ROOT/'.gitattributes',draft_path,DOC/'MASHR_NATIVE_DEVELOPMENT.md',ROOT/'examples/mashr-native/MashGaussianExample.java',ROOT/'src/main/resources/org/jlinalg/omics/mashr-BSD-NOTICE.txt',dependency]
for name in ('mashr_intake.py','install_mashr_reference.py','collect_mashr_gaussian_controls.py','mashr-original-controls.R','freeze_mashr_gaussian_controls.py','collect_mashr_weight_controls.py','mashr-original-weight-controls.R','mashr-development.init.gradle','validate_mashr_native.py'):paths.append(ROOT/'tools/literature'/name)
paths+=sorted((ROOT/'src/main/java/org/jlinalg/shrinkage').glob('*.java'))+sorted((ROOT/'src/test/java/org/jlinalg/shrinkage').glob('*.java'))+sorted((ROOT/'src/test/resources/org/jlinalg/shrinkage/mashr-original').glob('*.zip'))
source_pins={p.relative_to(ROOT).as_posix():pin(p) for p in paths}
evidence={}
for p in paths:
 if p!=dependency:evidence['source/'+p.relative_to(ROOT).as_posix()]=p.read_bytes()
for prefix,folder in [('matrix',OUT/'packaged-tests-1'),('gradle',ROOT/'build/test-results/test')]:
 for p in sorted(folder.rglob('*')):
  if p.is_file() and (prefix!='gradle' or 'shrinkage' in p.name):evidence[prefix+'/'+p.relative_to(folder).as_posix()]=p.read_bytes()
for name in ['build-1.log','compile-test-1.log','test-1.log','test-2.log','test-3.log','test-4.log','test-5.log','test-6.log','package-2.log','packaged-tests-1.log','example-1.log','finalize.py']:
 evidence['private-validation/'+name]=(OUT/name).read_bytes()
for folder in ['failed-test-1','failed-test-2','failed-test-3','pre-notice-reference-1']:
 for p in sorted((OUT/folder).rglob('*')):
  if p.is_file() and (p.suffix in ['.java','.xml']):evidence['retained-earlier-native-attempts/'+folder+'/'+p.relative_to(OUT/folder).as_posix()]=p.read_bytes()
for folder in ['source-intake-1','reference-runtime-1','reference-runtime-2','optimizer-source-intake-1','original-gaussian-controls-1','original-gaussian-controls-2','original-gaussian-controls-3','original-weight-controls-1']:
 for name in ['intake.json','FAILURE.json','WARNINGS.md','COMPLETED.json','receipt.json','record.json','process.stderr','process.stdout','command.json','install.R','health.R','health.tsv','session-info.txt']:
  p=BASE/folder/name
  if p.is_file():evidence['private-reference-attempts/'+folder+'/'+name]=p.read_bytes()
 for p in (BASE/folder).glob('*/*/error.txt'):evidence['private-reference-attempts/'+folder+'/'+p.relative_to(BASE/folder).as_posix()]=p.read_bytes()
mafft=ROOT/'build/literature-review/mafft-runtime/approved-metadata-recheck-20261102.log';evidence['mafft-approved-metadata-recheck.log']=mafft.read_bytes()
with zipfile.ZipFile(jar) as candidate:
 for name,expected in matrix['packaged_native_classes'].items():
  raw=candidate.read(name);assert len(raw)==expected['bytes'] and hashlib.sha256(raw).hexdigest()==expected['sha256'];evidence['packaged-native-classes/'+name]=raw
evidence['README.txt']=b'Complete native mashr foundation evidence. See MASHR_NATIVE_DEVELOPMENT.md for scope, explicit source departures and required recovery actions. No public mashr workflow, covariance-learning integration, whole-paper reproduction or source-to-binary rebuild is certified.\n'
inventory={n:dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()) for n,raw in sorted(evidence.items())}
evidence['inventory.json']=(json.dumps(inventory,indent=2)+'\n').encode()
archive=DOC/'mashr-native-development-controls.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,raw in sorted(evidence.items()):
  item=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));item.create_system=3;item.external_attr=0o100644<<16;item.compress_type=zipfile.ZIP_DEFLATED;z.writestr(item,raw)
proof=dict(schema_version=1,status='passed-native-mashr-foundation-with-explicit-source-boundaries',recorded_utc=datetime.now(timezone.utc).isoformat(),
 scope='Native supplied Gaussian covariance mixtures and fixed-likelihood weight fitting; no public mashr workflow or learned-covariance integration.',
 artifact=matrix['artifact'],source_pins=source_pins,dependency_binding=dependency_binding,evidence_archive=dict(path=archive.relative_to(ROOT).as_posix(),**pin(archive)),
 tests=dict(focused_Gradle=181,actual_JAR_per_JVM=181,JVMs=['Windows Java21','Windows Java25','Linux Java21'],failures=0,skips=0,heap_mib=128,full_project_suite_rerun=False),
 original_gaussian=dict(models=43,feature_rows=346,completed_original_calls=83,retained_R_failures=3,native_original_row_comparisons=686,explicit_component_likelihood_boundary_comparisons=4),
 original_weight_fits=dict(problems=26,completed_original_calls=52,optimizers=['ashr mixEM through mashr optimize_pi','ashr mixSQP through mashr optimize_pi'],native_plain_EM_compared_by='concave objective and independent floating-point simplex dual gaps; no iteration or nonidentified-weight identity'),
 warnings=[dict(code='ORIGINAL_R_SINGULAR',action='Preserve three original R failures for explicit SE1e10; do not claim R-algorithm parity. Successful Rcpp outputs are retained.'),dict(code='COMPONENT_LIKELIHOOD_BOUNDARY',action='Preserve the small-SE source discrepancy and independent 80-digit oracle. Component-level equality is not certified; inspect numericalNotes.'),dict(code='NATIVE_FOUNDATION_ONLY',action='Complete covariance learning, residual-correlation EM, managed runtime admission, typed CLI, full bundles and eight-paper curation before counting mashr as integrated.')],
 source_to_upstream_binary_rebuild_verified=False,whole_mashr_integrated=False,public_user_analysis_admitted=False,whole_paper_reproduced=False,released_or_deployed=False,
 canonical_artifact_unchanged=matrix['canonical_artifact_unchanged'],mafft_approved_metadata_recheck='passed-no-additional-refresh-needed',
 catalog_counts_unchanged=dict(new_scoped_integrations=61,native=13,upstream=48,missing_named_tools=259,mashr_status='missing'))
write(DOC/'MASHR_NATIVE_DEVELOPMENT_VALIDATION.json',proof)
checkpoint=dict(status=proof['status'],proof_path='docs/literature/MASHR_NATIVE_DEVELOPMENT_VALIDATION.json',proof_pin=pin(DOC/'MASHR_NATIVE_DEVELOPMENT_VALIDATION.json'),artifact=proof['artifact'],source_pins=source_pins,goal_achieved=False,next_work=proof['warnings'][2]['action'],catalog_counts_unchanged=proof['catalog_counts_unchanged'])
write(BASE/'current-checkpoint.json',checkpoint)
print(json.dumps(dict(status=proof['status'],source_files=len(source_pins),archive=proof['evidence_archive'],tests=proof['tests'],dependency_binding=dependency_binding),indent=2))
