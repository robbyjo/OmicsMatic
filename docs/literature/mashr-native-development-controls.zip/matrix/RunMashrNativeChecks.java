import java.io.PrintWriter;
import java.io.File;
import org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder;
import org.junit.platform.launcher.core.LauncherFactory;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;
public final class RunMashrNativeChecks {
 private RunMashrNativeChecks() { }
 public static void main(String[] args) throws Exception {
  for(String name:new String[]{"org.jlinalg.shrinkage.MashGaussian","org.jlinalg.shrinkage.MashMixtureWeights","jdistlib.accelerator.CpuComputeBackend"})
   if(!Class.forName(name).getProtectionDomain().getCodeSource().getLocation().toURI().equals(new File(args[0]).toURI()))throw new AssertionError("Wrong JAR loaded: "+name);
  var request=LauncherDiscoveryRequestBuilder.request().selectors(selectClass("org.jlinalg.shrinkage.MashGaussianTest"),selectClass("org.jlinalg.shrinkage.MashGaussianOriginalTest"),selectClass("org.jlinalg.shrinkage.MashMixtureWeightsTest"),selectClass("org.jlinalg.shrinkage.MashMixtureWeightsOriginalTest")).build();
  var listener=new SummaryGeneratingListener();LauncherFactory.create().execute(request,listener);var summary=listener.getSummary();
  summary.printTo(new PrintWriter(System.out));summary.printFailuresTo(new PrintWriter(System.out));
  if(summary.getTestsFoundCount()!=181||summary.getTestsSucceededCount()!=181||summary.getTestsSkippedCount()!=0||summary.getTestsAbortedCount()!=0||summary.getTestsFailedCount()!=0||summary.getContainersFailedCount()!=0)throw new AssertionError("Incomplete native mashr validation");
 }
}
