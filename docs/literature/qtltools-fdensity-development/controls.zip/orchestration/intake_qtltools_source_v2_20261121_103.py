from pathlib import Path
import hashlib,json,tarfile,urllib.request
R=Path('D:/projects/JLinAlg');O=R/'build/literature-review/qtltools-runtime/source-intake-2';COMMIT='a9606ee736d8489e3ec54c8b8c92c32fecad3bd0'
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
if __name__=='__main__':
    O.mkdir(parents=True,exist_ok=False);url='https://codeload.github.com/qtltools/qtltools/tar.gz/'+COMMIT;request=urllib.request.Request(url,headers={'User-Agent':'OmicsMatic-QTLtools-source-audit'})
    with urllib.request.urlopen(request,timeout=120) as response:raw=response.read(256*1024*1024+1)
    assert len(raw)<=256*1024*1024;(O/'qtltools-1.3.1.tar.gz').write_bytes(raw)
    source=O/'source';source.mkdir()
    with tarfile.open(O/'qtltools-1.3.1.tar.gz','r:gz') as tar:
        members=tar.getmembers();assert len(members)<10000 and sum(member.size for member in members)<1024*1024*1024
        for member in members:
            relative=Path(*Path(member.name).parts[1:]);target=(source/relative).resolve();assert target.is_relative_to(source.resolve()) and not member.issym() and not member.islnk() and (member.isfile() or member.isdir())
            if not relative.parts:continue
            if member.isdir():target.mkdir(parents=True,exist_ok=True)
            else:
                target.parent.mkdir(parents=True,exist_ok=True)
                with tar.extractfile(member) as stream:target.write_bytes(stream.read())
    assert b'GNU GENERAL PUBLIC LICENSE' in (source/'LICENSE').read_bytes();files={p.relative_to(source).as_posix():pin(p.read_bytes()) for p in source.rglob('*') if p.is_file()}
    receipt=dict(status='PINNED_OFFICIAL_QTLTOOLS_1_3_1_SOURCE_ONLY',tag='1.3.1',peeled_commit=COMMIT,tag_object='ad5e34ad40cb5c64b0eb5ceb5e42039ae2c1a1de',archive=dict(url=url,**pin(raw)),files=files,source_modified=False,compiled=False,runtime_qualified=False,new_catalog_credit=0)
    (O/'RESULT.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n');print('PINNED',len(files),'unchanged official source files',flush=True)
