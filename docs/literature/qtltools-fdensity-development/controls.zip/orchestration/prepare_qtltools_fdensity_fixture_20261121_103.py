from pathlib import Path
import hashlib,json,shutil
R=Path('D:/projects/JLinAlg');T=R/'build/qt-1';B=T/'build/qtltools-fdensity-1';S=B/'original-controls-1';D=T/'src/test/resources/org/jlinalg/genetics/qtltools-fdensity'
if __name__=='__main__':
    result=json.loads((S/'RESULT.json').read_bytes());assert (result['cases'],result['successful_cases'],result['retained_original_errors'],result['output_bins'])==(472,465,7,2223);source=S/'original-controls.tsv.gz';raw=source.read_bytes();assert dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())==result['fixture']
    D.mkdir(parents=True,exist_ok=False);shutil.copyfile(source,D/source.name);print('Copied actual original472-case fixture',flush=True)
