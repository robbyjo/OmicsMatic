from pathlib import Path
import gzip,hashlib,json,os,random,subprocess
R=Path(__file__).resolve().parents[1];T=R/'build/qt-1';B=T/'build/qtltools-fdensity-1';P=B/'original-controls-2';O=B/'original-controls-3';PROFILE=json.loads((R/'build/literature-review/qtltools-runtime/ubuntu-private-1/verification-2/RESULT.json').read_bytes())
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
if __name__=='__main__':
    O.mkdir(exist_ok=False);parent=json.loads((P/'RESULT.json').read_bytes());initial=json.loads((B/'original-controls-1/RESULT.json').read_bytes());byid={row['id']:row for row in parent['records']}
    for row in initial['records']:assert byid[row['id']]==row
    executable=Path(PROFILE['executable']['path']);assert pin(executable.read_bytes())=={key:PROFILE['executable'][key] for key in ['bytes','sha256']};env=dict(os.environ);env.update(PROFILE['environment']);rng=random.Random(20261122);lines=[gzip.decompress((P/'original-controls.tsv.gz').read_bytes()).decode()];records=[];bins=parent['output_bins']
    for i in range(100):
        name='larger-tree-'+str(i);out=O/name;out.mkdir();qtls=[];annotations=[]
        for j in range(rng.randint(5,20)):
            start=rng.randint(0,10000);qtls.append(['1' if j==0 else rng.choice(['1','2','chr1']),start,start+rng.randint(1,50),str(j%3),'gene',rng.choice(['+','-','.'])])
        for j in range(rng.randint(250,600)):
            start=rng.randint(0,12000);annotations.append([rng.choice(['1','2','chr1']),start,start+rng.randint(1,4000)])
        qtl=out/'qtl.bed';bed=out/'annotation.bed';qtl.write_text(''.join('\t'.join(map(str,row))+'\n' for row in qtls),encoding='utf-8');bed.write_text(''.join('\t'.join(map(str,row))+'\n' for row in annotations),encoding='utf-8');window=rng.randint(1,3000);width=rng.randint(1,5000);density=out/'density.txt'
        command=[str(executable),'fdensity','--qtl',str(qtl),'--bed',str(bed),'--window',str(window),'--bin',str(width),'--out',str(density)];(out/'STARTED.json').write_text(json.dumps(dict(command=command),indent=2)+'\n',encoding='utf-8')
        with (out/'stdout').open('xb') as stdout,(out/'stderr').open('xb') as stderr:p=subprocess.run(command,cwd=out,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=30)
        (out/'PROCESS.json').write_text(json.dumps(dict(exit_code=p.returncode))+'\n',encoding='utf-8');assert p.returncode==0 and density.is_file();output=density.read_text().splitlines();bins+=len(output)
        lines.append('\t'.join(['C',name,str(window),str(width),'OK'])+'\n');lines.extend('Q\t'+'\t'.join(map(str,row))+'\n' for row in qtls);lines.extend('A\t'+'\t'.join(map(str,row))+'\n' for row in annotations);lines.extend('B\t'+'\t'.join(row.split())+'\n' for row in output);lines.append('E\n');records.append(dict(id=name,capture_owner='original-controls-3',exit_code=0,status='OK',qtl=pin(qtl.read_bytes()),annotations=pin(bed.read_bytes()),output=pin(density.read_bytes())))
    fixture=gzip.compress(''.join(lines).encode(),mtime=0);(O/'original-controls.tsv.gz').write_bytes(fixture);oldrecords=[dict(row,capture_owner='original-controls-2') for row in parent['records']];result=dict(status='PASS_MEASURED_QTLTOOLS_FDENSITY_576_ORIGINAL_CASES',reference_distribution_build=PROFILE['distribution_build'],reference_executable=PROFILE['executable'],environment=PROFILE['environment'],parent=dict(path='original-controls-2/RESULT.json',**pin((P/'RESULT.json').read_bytes())),initial472_scientific_records_preserved_exact=True,cases=576,successful_cases=569,retained_original_errors=7,output_bins=bins,fixture=pin(fixture),records=oldrecords+records,large_tree_seed=20261122,source_or_runtime_modified=False,whole_tool_qualified=False,new_catalog_credit=0)
    (O/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print('PASS:576 original cases,569 completed,7 retained errors,',bins,'bins;all initial472 scientific records exact',flush=True)
