from pathlib import Path
R=Path('D:/projects/JLinAlg')
if __name__=='__main__':
    source=(R/'build/reference_qtltools_fdensity_20261121_103.py').read_text().replace("original-controls-1'","original-controls-2'")
    marker='    rng=random.Random(20261121)'
    addition="""    for count,reverse in [(2,False),(2,True),(63,False),(64,False)]:
        anns=[a('1',1000,1001),a('1',100,101)]+[a('1',1100+j*10,1101+j*10) for j in range(count-2)]
        if reverse:anns.reverse()
        cases.append(dict(id='leaf-order-'+str(count)+'-'+str(reverse),window=20,bin=10,qtls=[q('1',100,101)],annotations=anns))
"""
    assert marker in source;source=source.replace(marker,addition+marker);(R/'build/reference_qtltools_fdensity_v2_20261121_103.py').write_text(source,encoding='utf-8',newline='\n');print('Prepared four additional unmodified-original order/threshold controls',flush=True)
