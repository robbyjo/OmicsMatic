from pathlib import Path
import hashlib,json,shutil
R=Path('D:/projects/JLinAlg');T=R/'build/qt-1';S=T/'build/qtltools-fdensity-1/original-controls-3';D=T/'src/test/resources/org/jlinalg/genetics/qtltools-fdensity'
if __name__=='__main__':
    value=json.loads((S/'RESULT.json').read_bytes());assert (value['cases'],value['successful_cases'],value['retained_original_errors'],value['output_bins'])==(576,569,7,2838);raw=(S/'original-controls.tsv.gz').read_bytes();assert dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())==value['fixture']
    shutil.copyfile(S/'original-controls.tsv.gz',D/'original-controls.tsv.gz');(D/'PROVENANCE.json').write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n');print('Prepared576-case actual original fixture;569 completed,7 retained errors,2838 bins',flush=True)
