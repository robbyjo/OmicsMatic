from pathlib import Path
import concurrent.futures,hashlib,json,subprocess
R=Path('D:/projects/JLinAlg');T=R/'build/qt-1';B=T/'build/qtltools-fdensity-1';O=B/'example-1';JAR=B/'normal-gradle-2/project-build/cli/omicsmatic-0.4.0.jar';SOURCE=T/'examples/qtltools-fdensity/QtltoolsFdensityExample.java'
def pin(path):
    raw=path.read_bytes();return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
def mount(path):return '/mnt/'+path.drive[0].lower()+'/'+path.relative_to(Path(path.drive+'/')).as_posix()
def run(label,command):
    folder=O/label;folder.mkdir();save(folder/'STARTED.json',dict(command=command))
    with (folder/'stdout').open('xb') as stdout,(folder/'stderr').open('xb') as stderr:p=subprocess.run(command,cwd=T,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=90)
    save(folder/'PROCESS.json',dict(exit_code=p.returncode));assert p.returncode==0,(folder/'stderr').read_text();return folder
if __name__=='__main__':
    O.mkdir(exist_ok=False);classes=O/'classes';classes.mkdir();run('compile',['C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/javac.exe','--release','17','-Xlint:all','-Werror','-cp',str(JAR),'-d',str(classes),str(SOURCE)])
    expected=['-20 -11 0','-10 -1 0','0 9 2','10 19 0']
    def host(label):
        if label=='linux21':command=['wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','-u','root','--','java','-cp',':'.join(map(mount,[JAR,classes])),'QtltoolsFdensityExample']
        else:
            java='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe' if label=='windows21' else 'C:/Program Files/Java/jdk-25/bin/java.exe';command=[java,'-cp',';'.join(map(str,[JAR,classes])),'QtltoolsFdensityExample']
        folder=run(label,command);assert (folder/'stdout').read_text().splitlines()==expected;return label,dict(exit_code=0,stdout=pin(folder/'stdout'),rows_match_original_smoke=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:hosts=dict(pool.map(host,['windows21','windows25','linux21']))
    folder=run('source-launch-windows21',['C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe','-cp',str(JAR),str(SOURCE)]);assert (folder/'stdout').read_text().splitlines()==expected
    save(O/'RESULT.json',dict(status='PASS_PUBLIC_NATIVE_FDENSITY_EXAMPLE_THREE_JVMS_AND_DOCUMENTED_SOURCE_LAUNCH',producer=pin(JAR),source=pin(SOURCE),hosts=hosts,documented_source_launch_windows21=True,original_scientific_rows=expected,upstream_processes_invoked_by_example=0,new_catalog_credit=0));print('PASS:four original scientific rows match on3 JVMs;documented source launch passes',flush=True)
