from pathlib import Path
import hashlib,json,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/qt-1';B=T/'build/qtltools-fdensity-1';D=T/'docs/literature/qtltools-fdensity-development';O=R/'build/git-publish/20261121-qtltools-103'
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
def write(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as f:f.write(value)
if __name__=='__main__':
    normal=json.loads((B/'normal-gradle-2/RESULT.json').read_bytes());packaged=json.loads((B/'packaged-1/RESULT.json').read_bytes());assert normal['tests']==packaged['tests_each_host']==588 and all(row['exit_code']==0 for row in packaged['hosts'].values())
    current=T/'docs/literature/HANDOVER_CURRENT.md';old=current.read_bytes();heading=b'# Current toolbox handover\n\n';assert old.startswith(heading)
    intro='''**Current: [native QTLtools fdensity API and exact next work](QTLTOOLS_FDENSITY.md).**
Native Java now implements the selected1.3.1 fdensity counting operation on
declared valid BED intervals. All588 focused tests pass per normal build and
packaged Windows21/25/Linux21 JVM. The576 actual reference cases retain569
completed outputs,seven original errors and2838 complete bins. The original
small-tree input-order guard is preserved;the initial313-failure build is
retained and unadmitted. All22,425 preceding JAR payloads stay byte-identical,
with four new native classes. The public example passes on three JVMs.
This is a library API;the full QTLtools workflow/global CLI is pending. **Counts
stay145 scoped families,1630 reviewed/1092 pending uses;zero new family credit.**
A fresh all250 source scan finds nine QTLtools-positive papers/19 pointers,
covering reported1.1,1.2 and1.3.1 roles. P190's executable binding remains
unresolved. **Next: exact-edition cis/trans,conditional,MBV andquan adapters,
historical-edition verification,then cumulative source review/admission and
remaining high-impact GWAS/omics gaps.** Preserve59 preceding owners. Native use
needs Java only;upstream controls have separate private dependencies. **Transfer
ignored JARs,runtimes,full text,author source and full private/failed evidence
separately before retiring this machine.** Both reports stay off Pages;no release
or full-goal completion is claimed. Lower entries retain historical checkpoints.

'''.encode();current.write_bytes(heading+intro+old[len(heading):]);save(O/'HANDOVER-PREPEND.json',dict(previous=pin(old),current=pin(current.read_bytes()),previous_body_retained_exact=True))
    failure=dict(status='UNADMITTED_INITIAL_NATIVE_SORTED_INDEX_BEHAVIOR',normal_build='normal-gradle-1',tests=483,failed_tests=313,cause='Initial Java code did not preserve the upstream small-tree input-order query guard',old_source_JAR_and_errors_preserved=True,expected_original_outputs_modified=False,new_catalog_credit=0)
    failed=B/'first-build';failed.mkdir();save(failed/'FAILURE-SCOPE.json',failure)
    files={}
    for owner in ['original-controls-2','original-controls-3','example-1']:
        for path in (B/owner).rglob('*'):
            if path.is_file() and path.suffix!='.class':files[path.relative_to(B).as_posix()]=path.read_bytes()
    files['original-controls-1/RESULT.json']=(B/'original-controls-1/RESULT.json').read_bytes();files['first-build/FAILURE-SCOPE.json']=(failed/'FAILURE-SCOPE.json').read_bytes()
    for owner in ['normal-gradle-1','normal-gradle-2']:
        for name in ['STARTED.json','PROCESS.json','RESULT.json','stdout','stderr','CLASSPATH.txt']:
            path=B/owner/name
            if path.is_file():files[owner+'/'+name]=path.read_bytes()
        for path in (B/owner/'project-build/test-results/test').glob('TEST-*.xml'):files[owner+'/test-results/'+path.name]=path.read_bytes()
        for path in (B/owner/'source').rglob('*'):
            if path.is_file():files[owner+'/source/'+path.relative_to(B/owner/'source').as_posix()]=path.read_bytes()
    for path in (B/'packaged-1').rglob('*'):
        if path.is_file() and 'test-classes' not in path.parts:files[path.relative_to(B).as_posix()]=path.read_bytes()
    runtime=R/'build/literature-review/qtltools-runtime/ubuntu-private-1'
    for path in runtime.glob('*'):
        if path.is_file() and path.suffix in {'.json','.txt'} or path.is_file() and path.name in ['stdout','stderr']:files['runtime-intake/'+path.name]=path.read_bytes()
    for path in (runtime/'verification-2').iterdir():
        if path.is_file():files['runtime-verified/'+path.name]=path.read_bytes()
    files['source-intake-1/FAILURE.json']=(runtime.parent/'source-intake-1/FAILURE.json').read_bytes();files['source-intake-2/RESULT.json']=(runtime.parent/'source-intake-2/RESULT.json').read_bytes()
    for path in sorted((R/'build').glob('*qtltools*20261121_103.py')):files['orchestration/'+path.name]=path.read_bytes()
    with zipfile.ZipFile(D/'controls.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,raw in sorted(files.items()):
            info=zipfile.ZipInfo(name,(2026,11,21,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,raw)
    save(D/'INDEX.json',{name:pin(raw) for name,raw in files.items()})
    transfer=dict(status='PRIVATE_ARTIFACTS_REQUIRE_SEPARATE_CHECKSUMMED_TRANSFER',machine_backup_complete=False,current_owner=str(T),current_evidence=str(B),all59_preceding_owners_and_current_owner_must_be_preserved=True,source_and_private_runtime_root=str(runtime.parent),qualified_JAR=dict(path=str(B/'normal-gradle-2/project-build/cli/omicsmatic-0.4.0.jar'),**normal['producer']),unadmitted_failed_JAR=str(B/'normal-gradle-1/project-build/cli/omicsmatic-0.4.0.jar'),primary_fulltext=str(R/'build/literature-review/xml'),private_primary_context=str(R/'build/mo-9/build/qtltools-discovery-1/private-context'),preserve_all_ignored_private_author_raw_failed_null_invalidated_superseded_data=True,source_archive_contains_upstream_example_datasets_that_are_not_republished=True,verify_destination_checksums_before_retiring_machine=True,prior_transfer_records=['docs/literature/monocle-admission-checkpoint/PRIVATE-TRANSFER.json','docs/literature/handover-2026-11-21-monocle-catalog/PRIVATE-TRANSFER.json']);save(D/'PRIVATE-TRANSFER.json',transfer)
    write(D/'README.md','''# Native QTLtools fdensity API evidence

Read [the guide](../QTLTOOLS_FDENSITY.md) and [nine-paper assessment](../QTLTOOLS_SOURCE_ASSESSMENT.md).
This is the selected valid-BED integer-count component,not a complete QTLtools
workflow/global CLI. The source-order guard is preserved. Family credit stays0.
The full implementation goal remains active and unfinished.

SOURCE.json pins seven unchanged GPL source/license files. QTLTOOLS-CENSUS.json
records9 positive papers/19 paragraph pointers from all250 source identities.
PROFILE.json pins source/fixture/canonical/packet bytes;INDEX.json lists controls.zip.
The reader checks all576 actual original case inputs,parameters and complete
outputs/errors against the fixture,plus retained build/three-JVM/example receipts.
It executes no Java/C++ or other model. --restore writes copies into NEW only.
SHA256 supplies integrity,not authentication. Original input order is scientific
state here;do not sort silently. Failed and corrected attempts are both retained.

Run `python -B tools/literature/qtltools_fdensity/verify.py --out build/NEW-check`.
Read PRIVATE-TRANSFER.json before machine retirement. Normal/failed JARs,runtimes,
full text and full private evidence need separate transfer. No release or Pages
publication is made. Older readers stay frozen;use their unchanged owners/commits.
''')
    source_paths=[T/'src/main/java/org/jlinalg/genetics/QtltoolsFunctionalDensity.java',T/'src/main/java/org/jlinalg/genetics/GenomicIntervals.java',T/'src/test/java/org/jlinalg/genetics/QtltoolsFunctionalDensityTest.java',T/'src/test/java/org/jlinalg/genetics/GenomicIntervalsTest.java',T/'src/test/resources/org/jlinalg/genetics/qtltools-fdensity/original-controls.tsv.gz',T/'src/test/resources/org/jlinalg/genetics/qtltools-fdensity/PROVENANCE.json',T/'docs/literature/QTLTOOLS_FDENSITY.md',T/'docs/literature/QTLTOOLS_SOURCE_ASSESSMENT.md',current]
    source_paths += [path for folder in [T/'tools/literature/qtltools_fdensity',T/'examples/qtltools-fdensity',D/'upstream-source'] for path in folder.rglob('*') if path.is_file()]
    canonical=json.loads((R/'build/git-publish/20261121-handover-catalog-101/CANONICAL-UNCHANGED.json').read_bytes())
    for name in ['monocle-source-role-coverage.json','monocle-components-admission-validation.json','monocle-admission-reviews-shared-source-compatibility.json']:canonical['docs/literature/omics-2023-2026/'+name]=None
    canonical={name:pin((T/name).read_bytes()) for name in canonical}
    fixture='src/test/resources/org/jlinalg/genetics/qtltools-fdensity/original-controls.tsv.gz';provenance=fixture.rsplit('/',1)[0]+'/PROVENANCE.json'
    profile=dict(status='PASS_NATIVE_QTLTOOLS_FDENSITY_API',parent_commit='3408fdcf476fb9c39b83eb30d00bda97262d873b',API_only=True,CLI_implemented=False,source_order_guard_preserved=True,new_catalog_credit=0,whole_tool_qualified=False,whole_goal_complete=False,cases=576,successful_cases=569,retained_original_errors=7,output_bins=2838,tests_each_JVM=588,producer=normal['producer'],fixture=fixture,fixture_provenance=provenance,source_inputs={path.relative_to(T).as_posix():pin(path.read_bytes()) for path in source_paths},canonical_unchanged=canonical,files={path.name:pin(path.read_bytes()) for path in D.iterdir() if path.is_file()},control_members=len(files),preceding_owners=59)
    save(D/'PROFILE.json',profile);print('SEALED nativeAPI source/reference packet:',len(files),'control members;576 original cases;588 tests/JVM;canonical33 pinned',flush=True)
