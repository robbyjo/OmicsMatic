from pathlib import Path
import hashlib,json,os,subprocess
R=Path(__file__).resolve().parents[1];BASE=R/'build/literature-review/qtltools-runtime/ubuntu-private-1';ROOT=BASE/'root';O=BASE/'verification-2'
def pin(path):
    raw=path.read_bytes();return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def run(name,command,env):
    (O/(name+'.STARTED.json')).write_text(json.dumps(dict(command=command),indent=2)+'\n',encoding='utf-8')
    with (O/(name+'.stdout')).open('xb') as stdout,(O/(name+'.stderr')).open('xb') as stderr:p=subprocess.run(command,cwd=O,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,env=env,timeout=120)
    (O/(name+'.PROCESS.json')).write_text(json.dumps(dict(exit_code=p.returncode))+'\n',encoding='utf-8');return p.returncode
if __name__=='__main__':
    O.mkdir(exist_ok=False);executable=ROOT/'usr/bin/QTLtools';paths=[ROOT/'usr/lib',ROOT/'usr/lib/x86_64-linux-gnu',ROOT/'usr/lib/x86_64-linux-gnu/blas'];env=dict(os.environ);env['LD_LIBRARY_PATH']=':'.join(map(str,paths))
    assert run('ldd',['ldd',str(executable)],env)==0 and 'not found' not in (O/'ldd.stdout').read_text()
    assert run('help',[str(executable),'--help'],env)==0 and run('fdensity-help',[str(executable),'fdensity','--help'],env)==0
    (O/'qtl.bed').write_text('1\t100\t101\trs1\tgene1\t+\n1\t200\t201\trs2\tgene2\t-\n',encoding='utf-8');(O/'annotation.bed').write_text('1\t100\t105\ta\n1\t101\t103\tb\n1\t195\t200\tc\n',encoding='utf-8')
    command=[str(executable),'fdensity','--qtl',str(O/'qtl.bed'),'--bed',str(O/'annotation.bed'),'--window','20','--bin','10','--out',str(O/'density.txt')];assert run('fdensity-smoke',command,env)==0
    expected='-20 -11 0\n-10 -1 0\n0 9 2\n10 19 0\n';assert (O/'density.txt').read_text()==expected
    libraries=[]
    for line in (O/'ldd.stdout').read_text().splitlines():
        words=line.split()
        if len(words)>=3 and words[1]=='=>' and words[2].startswith('/'):
            path=Path(words[2]).resolve();libraries.append(dict(path=str(path),**pin(path)))
    packages=[]
    for path in sorted(BASE.glob('*.deb')):
        package=subprocess.check_output(['dpkg-deb','--field',str(path),'Package'],text=True).strip();version=subprocess.check_output(['dpkg-deb','--field',str(path),'Version'],text=True).strip();metadata=(BASE/(package+'.apt-metadata.txt')).read_text();expected=[line.split(': ',1)[1] for line in metadata.splitlines() if line.startswith('SHA256: ')];assert len(expected)==1 and pin(path)['sha256']==expected[0];packages.append(dict(package=package,version=version,file=path.name,**pin(path)))
    receipt=dict(status='PASS_PRIVATE_UBUNTU_QTLTOOLS_1_3_1_LOAD_HELP_AND_FDENSITY_SMOKE_ONLY',upstream_version='1.3.1',distribution_build='1.3.1+dfsg-4build3',executable=dict(path=str(executable),**pin(executable)),packages=packages,libraries=libraries,system_packages_installed=False,prior_shared_runtimes_modified=False,environment=dict(LD_LIBRARY_PATH=env['LD_LIBRARY_PATH']),fdensity_smoke=dict(output=pin(O/'density.txt'),bins=4,QTL_rows=2,overlapping_annotation_rows_at_first_QTL=2,nonzero_bin_count=2),initial_missing_BLAS_path_retained=True,whole_tool_qualified=False,adapter_implemented=False,new_catalog_credit=0)
    (O/'RESULT.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8');print('PASS:private original executable loads;four smoke bins agree;two QTL presences despite three annotation overlaps',flush=True)
