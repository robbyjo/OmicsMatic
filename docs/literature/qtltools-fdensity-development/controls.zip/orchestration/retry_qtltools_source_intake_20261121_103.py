from pathlib import Path
import json
R=Path('D:/projects/JLinAlg');O=R/'build/literature-review/qtltools-runtime/source-intake-1'
if __name__=='__main__':
    (O/'FAILURE.json').write_text(json.dumps(dict(status='SOURCE_DOWNLOAD_CAPACITY_REFUSAL_BEFORE_ARCHIVE_WRITE',limit_bytes=32*1024*1024,observed_at_least=32*1024*1024+1,archive_written=False,source_extracted=False,analysis_run=False,action='Retain this refusal and retry a new owner with bounded256MiB download and1GiB extraction capacity'),indent=2)+'\n',encoding='utf-8',newline='\n')
    source=(R/'build/intake_qtltools_source_20261121_103.py').read_text().replace('source-intake-1','source-intake-2').replace('32*1024*1024','256*1024*1024').replace('len(members)<2000','len(members)<10000').replace('128*1024*1024','1024*1024*1024')
    (R/'build/intake_qtltools_source_v2_20261121_103.py').write_text(source,encoding='utf-8',newline='\n');print('Prepared new bounded source intake;initial capacity refusal retained',flush=True)
