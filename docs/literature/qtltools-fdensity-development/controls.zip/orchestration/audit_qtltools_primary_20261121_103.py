from pathlib import Path
import gzip,hashlib,json,re,sys,xml.etree.ElementTree as ET
R=Path('D:/projects/JLinAlg');T=R/'build/mo-9';O=T/'build/qtltools-discovery-1';sys.path.insert(0,str(T/'tools/literature'))
from collect_omics_review import paragraphs
from gsea_catalog.primary import identities,EXTRACTOR_SHA
from monocle_catalog.model import registry
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
if __name__=='__main__':
    O.mkdir(exist_ok=False);private=O/'private-context';private.mkdir();assert pin((T/'tools/literature/collect_omics_review.py').read_bytes())['sha256']==EXTRACTOR_SHA
    definition=next(row for row in registry() if row['id']=='qtltools');pattern=re.compile(definition['pattern'],re.I);positive=[]
    papers={row['paper_id']:row for row in json.loads((T/'docs/literature/omics-2023-2026/papers.json').read_bytes())}
    for identity in identities():
        raw=gzip.decompress((R/'build/literature-review/xml'/(identity['pmcid']+'.xml.gz')).read_bytes());assert pin(raw)['sha256']==identity['xml_sha256'];tree=ET.fromstring(raw);dois=[el.text for el in tree.findall('front/article-meta/article-id') if el.get('pub-id-type')=='doi'];assert len(dois)==1 and dois[0].lower()==identity['doi'].lower();blocks=paragraphs(tree);hits=[b for b in blocks if pattern.search(b.get('match_text',b['text']))]
        if hits:
            pid=identity['paper_id'];(private/(pid+'.json')).write_text(json.dumps(dict(identity=identity,hits=hits),indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n');use=next((row for row in papers[pid]['tools'] if row['tool_id']=='qtltools'),None)
            if use:anchor=next(b for b in blocks if b['paragraph_index']==use['evidence_paragraph_index']);assert pin(anchor['text'].encode())['sha256']==use['evidence_paragraph_sha256']
            positive.append(dict(identity=identity,paragraphs=[dict(paragraph_index=b['paragraph_index'],section=b['section'],text_sha256=pin(b['text'].encode())['sha256']) for b in hits],existing_catalog_use=use is not None))
            print(pid,identity['doi'],'paragraphs',[b['paragraph_index'] for b in hits],flush=True)
            for b in hits:print('CONTEXT',b['paragraph_index'],b['text'][:6500],flush=True)
    result=dict(status='PASS_FRESH250_QTLTOOLS_PRIMARY_CANDIDATE_SCAN',papers_scanned=250,positive_papers=len(positive),candidates=positive,canonical_metadata_modified=False,new_catalog_credit=0,new_review_records=0,private_context_excluded_from_publication=True,whole_goal_complete=False)
    (O/'CENSUS.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n');print('TOTAL',len(positive),'positive papers',flush=True)
