from pathlib import Path
import importlib.util,json,subprocess
R=Path('D:/projects/JLinAlg');T=R/'build/qt-1';O=R/'build/git-publish/20261121-qtltools-103';BASE='3408fdcf476fb9c39b83eb30d00bda97262d873b'
def save(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
def git(root,*args):return subprocess.check_output(['git','--no-replace-objects',*args],cwd=root)
if __name__=='__main__':
    O.mkdir(parents=True,exist_ok=False);spec=importlib.util.spec_from_file_location('inventory',O.parent/'20261115-all-main-3/inventory.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
    states=[v.snapshot(Path(block.splitlines()[0][9:])) for block in git(R,'worktree','list','--porcelain').decode().strip().split('\n\n')];assert len(states)==59;save(O/'WORKTREES-BEFORE.json',states)
    assert git(R,'ls-remote','origin','refs/heads/main').decode().split()[0]==BASE
    command=['git','worktree','add','-b','codex/qtltools-high-impact-20261121',str(T),BASE];save(O/'WORKTREE-STARTED.json',dict(command=command))
    with (O/'worktree.stdout').open('xb') as stdout,(O/'worktree.stderr').open('xb') as stderr:p=subprocess.run(command,cwd=R,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=240)
    save(O/'WORKTREE-PROCESS.json',dict(exit_code=p.returncode));assert p.returncode==0;print('PASS:59 owners preserved;60th isolated QTLtools owner created on verified main',flush=True)
