from pathlib import Path
import json,subprocess
R=Path('D:/projects/JLinAlg');O=R/'build/literature-review/qtltools-runtime/ubuntu-private-1';DIST='JLinAlg-Omics-PyMOL-20261026'
if __name__=='__main__':
    O.mkdir(parents=True,exist_ok=False);packages=['qtltools=1.3.1+dfsg-4build3','libboost-iostreams1.83.0','libboost-program-options1.83.0','libgsl27','libgslcblas0','libhts3t64','libhtscodecs2','r-mathlib','libblas3']
    command=['wsl.exe','-d',DIST,'-u','root','--cd','/mnt/d/projects/JLinAlg/build/literature-review/qtltools-runtime/ubuntu-private-1','--','apt-get','download',*packages]
    (O/'STARTED.json').write_text(json.dumps(dict(command=command,system_install=False,private_extraction_only=True),indent=2)+'\n',encoding='utf-8')
    with (O/'stdout').open('xb') as stdout,(O/'stderr').open('xb') as stderr:p=subprocess.run(command,cwd=R,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=300)
    (O/'PROCESS.json').write_text(json.dumps(dict(exit_code=p.returncode))+'\n',encoding='utf-8');print('Private Debian downloads exit',p.returncode,flush=True)
    if p.returncode:print((O/'stderr').read_text(errors='replace')[-2500:])
    raise SystemExit(p.returncode)
