from pathlib import Path
import gzip,hashlib,json,os,random,subprocess
R=Path(__file__).resolve().parents[1];T=R/'build/qt-1';O=T/'build/qtltools-fdensity-1/original-controls-1';BASE=R/'build/literature-review/qtltools-runtime/ubuntu-private-1';PROFILE=json.loads((BASE/'verification-2/RESULT.json').read_bytes())
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def q(chrom,start,end,strand='+',name='q'):return [chrom,start,end,name,'gene',strand]
def a(chrom,start,end):return [chrom,start,end]
if __name__=='__main__':
    O.mkdir(parents=True,exist_ok=False);exe=Path(PROFILE['executable']['path']);assert pin(exe.read_bytes())=={key:PROFILE['executable'][key] for key in ['bytes','sha256']};env=dict(os.environ);env.update(PROFILE['environment'])
    cases=[dict(id='smoke',window=20,bin=10,qtls=[q('1',100,101),q('1',200,201,'-')],annotations=[a('1',100,105),a('1',101,103),a('1',195,200)])]
    for strand in ['+','-','.']:
        for window,width in [(10,5),(10,6),(3,50),(7,1),(1,1)]:
            cases.append(dict(id='edges-'+strand.replace('+','plus').replace('-','minus').replace('.','dot')+'-'+str(window)+'-'+str(width),window=window,bin=width,qtls=[q('1',100,109,strand),q('1',100,101,strand)],annotations=[a('1',100-window-1,100-window),a('1',100-window,101-window),a('1',100,101),a('1',100+window,101+window),a('1',101+window,110+window),a('other',0,1000)]))
    cases += [dict(id='chromosome-start',window=10,bin=3,qtls=[q('1',0,1,'-'),q('1',0,20,'.')],annotations=[a('1',0,1),a('1',10,11)]),dict(id='all-distant',window=5,bin=2,qtls=[q('1',100,101)],annotations=[a('1',1000,2000)]),dict(id='no-shared-chromosome',window=5,bin=2,qtls=[q('chr1',100,101)],annotations=[a('1',100,101)]),dict(id='empty-annotations',window=5,bin=2,qtls=[q('1',100,101)],annotations=[]),dict(id='empty-qtls',window=5,bin=2,qtls=[],annotations=[a('1',100,101)]),dict(id='near-int-limit',window=20,bin=7,qtls=[q('1',2147483626,2147483627,'-')],annotations=[a('1',2147483600,2147483647)])]
    rng=random.Random(20261121)
    for index in range(450):
        nq=rng.randint(1,12);na=rng.randint(1,60);qtls=[];anns=[]
        for j in range(nq):
            start=rng.randint(0,10000);qtls.append(q(rng.choice(['1','2','chr1']),start,start+rng.randint(1,50),rng.choice(['+','-','.']),str(j%3)))
        for j in range(na):
            start=rng.randint(0,12000);anns.append(a(rng.choice(['1','2','chr1','X']),start,start+rng.randint(1,3500)))
        if index%5==0:anns.append(anns[0].copy())
        if index%7==0:qtls.append(qtls[0].copy())
        cases.append(dict(id='seeded-'+str(index),window=rng.randint(1,3000),bin=rng.randint(1,5000),qtls=qtls,annotations=anns))
    records=[];fixture=[];success=errors=bins=0
    for case in cases:
        directory=O/case['id'];directory.mkdir();qtl=directory/'qtl.bed';bed=directory/'annotation.bed';qtl.write_text(''.join('\t'.join(map(str,row))+'\n' for row in case['qtls']),encoding='utf-8');bed.write_text(''.join('\t'.join(map(str,row))+'\n' for row in case['annotations']),encoding='utf-8');out=directory/'density.txt'
        command=[str(exe),'fdensity','--qtl',str(qtl),'--bed',str(bed),'--window',str(case['window']),'--bin',str(case['bin']),'--out',str(out)];(directory/'STARTED.json').write_text(json.dumps(dict(command=command),indent=2)+'\n',encoding='utf-8')
        with (directory/'stdout').open('xb') as stdout,(directory/'stderr').open('xb') as stderr:p=subprocess.run(command,cwd=directory,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,env=env,timeout=30)
        (directory/'PROCESS.json').write_text(json.dumps(dict(exit_code=p.returncode))+'\n',encoding='utf-8')
        failed=not case['qtls'] or not case['annotations'] or not ({row[0] for row in case['qtls']} & {row[0] for row in case['annotations']})
        if failed:assert p.returncode!=0 and not out.exists();errors+=1
        else:assert p.returncode==0 and out.is_file();success+=1;bins+=len(out.read_text().splitlines())
        fixture.append('\t'.join(['C',case['id'],str(case['window']),str(case['bin']),'ERROR' if failed else 'OK'])+'\n')
        fixture.extend('Q\t'+'\t'.join(map(str,row))+'\n' for row in case['qtls']);fixture.extend('A\t'+'\t'.join(map(str,row))+'\n' for row in case['annotations'])
        if not failed:fixture.extend('B\t'+'\t'.join(line.split())+'\n' for line in out.read_text().splitlines())
        fixture.append('E\n');records.append(dict(id=case['id'],exit_code=p.returncode,status='ORIGINAL_ERROR' if failed else 'OK',qtl=pin(qtl.read_bytes()),annotations=pin(bed.read_bytes()),output=None if failed else pin(out.read_bytes())))
    value=''.join(fixture).encode();(O/'original-controls.tsv.gz').write_bytes(gzip.compress(value,mtime=0));record=dict(status='PASS_MEASURED_QTLTOOLS_1_3_1_FDENSITY_ORIGINAL_CONTROLS',reference_distribution_build=PROFILE['distribution_build'],reference_executable=PROFILE['executable'],environment=PROFILE['environment'],seed=20261121,cases=len(cases),successful_cases=success,retained_original_errors=errors,output_bins=bins,fixture=pin((O/'original-controls.tsv.gz').read_bytes()),records=records,source_or_runtime_modified=False,whole_tool_qualified=False,new_catalog_credit=0)
    (O/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8');print('PASS original controls:',len(cases),'cases,',success,'completed,',errors,'retained errors,',bins,'bins',flush=True)
