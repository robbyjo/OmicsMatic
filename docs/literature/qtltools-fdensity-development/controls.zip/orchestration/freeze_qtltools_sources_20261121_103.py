from pathlib import Path
import hashlib,json,shutil
R=Path('D:/projects/JLinAlg');T=R/'build/qt-1';D=T/'docs/literature/qtltools-fdensity-development';SRC=R/'build/literature-review/qtltools-runtime/source-intake-2'
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
if __name__=='__main__':
    D.mkdir(exist_ok=False);(D/'.gitattributes').write_text('* -text whitespace=cr-at-eol\n',encoding='utf-8');census=R/'build/mo-9/build/qtltools-discovery-1/CENSUS.json';value=json.loads(census.read_bytes());assert value['papers_scanned']==250 and value['positive_papers']==9 and sum(len(row['paragraphs']) for row in value['candidates'])==19;shutil.copyfile(census,D/'QTLTOOLS-CENSUS.json')
    intake=json.loads((SRC/'RESULT.json').read_bytes());selected=['LICENSE','src/mode_fdensity/fdensity_data.h','src/mode_fdensity/fdensity_main.cpp','src/mode_fdensity/fdensity_process.cpp','src/mode_fdensity/fdensity_read_annotation.cpp','src/mode_fdensity/fdensity_read_qtl.cpp','lib/OTools/interval_tree.h'];members={}
    for name in selected:
        raw=(SRC/'source'/name).read_bytes();assert pin(raw)==intake['files'][name];target=D/'upstream-source'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);members[name]=pin(raw)
    record=dict(status='PINNED_UNCHANGED_OFFICIAL_QTLTOOLS_1_3_1_FDENSITY_SOURCE',tag=intake['tag'],peeled_commit=intake['peeled_commit'],archive=intake['archive'],selected_source=members,license='GPL-3.0-or-later;original file notices retained',example_BAM_VCF_and_expression_datasets_published=False,source_modified=False,whole_tool_qualified=False,new_catalog_credit=0)
    (D/'SOURCE.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n');print('FROZEN9 primary roles/19 pointers and7 unchanged GPL source/license files;no full text or example human datasets',flush=True)
