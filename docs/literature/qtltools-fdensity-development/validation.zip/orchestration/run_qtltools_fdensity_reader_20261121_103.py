from pathlib import Path
import argparse,json,subprocess
R=Path('D:/projects/JLinAlg');T=R/'build/qt-1';B=T/'build/qtltools-fdensity-1';O=R/'build/git-publish/20261121-qtltools-103'
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('host',choices=['windows','linux']);args=p.parse_args();host=args.host;out=B/('reader-'+host+'-1')
    if host=='windows':command=['C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe','-X','utf8','-B',str(T/'tools/literature/qtltools_fdensity/verify.py'),'--out',str(out),'--restore','--jar',str(B/'normal-gradle-2/project-build/cli/omicsmatic-0.4.0.jar')]
    else:command=['wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','-u','root','--','python3','-B','/mnt/d/projects/JLinAlg/build/qt-1/tools/literature/qtltools_fdensity/verify.py','--out','/mnt/d/projects/JLinAlg/build/qt-1/build/qtltools-fdensity-1/reader-linux-1']
    with (O/('reader-'+host+'.STARTED.json')).open('x',encoding='utf-8') as f:json.dump(dict(command=command),f,indent=2)
    with (O/('reader-'+host+'.stdout')).open('xb') as stdout,(O/('reader-'+host+'.stderr')).open('xb') as stderr:p=subprocess.run(command,cwd=T,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=180)
    with (O/('reader-'+host+'.PROCESS.json')).open('x',encoding='utf-8') as f:json.dump(dict(exit_code=p.returncode),f)
    print(host,'reader exit',p.returncode,flush=True)
    if p.returncode:print((O/('reader-'+host+'.stderr')).read_text(errors='replace')[-3000:])
    else:print((out/'RESULT.json').read_text())
    raise SystemExit(p.returncode)
