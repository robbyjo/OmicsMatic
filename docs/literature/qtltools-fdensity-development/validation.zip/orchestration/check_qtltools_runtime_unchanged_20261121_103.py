from pathlib import Path
import hashlib,json,subprocess
R=Path(__file__).resolve().parents[1];P=R/'build/literature-review/qtltools-runtime/ubuntu-private-1/verification-2/RESULT.json';O=R/'build/qt-1/build/qtltools-fdensity-1/runtime-unchanged-1.json'
if __name__=='__main__':
    record=json.loads(P.read_bytes());rows=[record['executable'],*record['libraries']]
    for row in rows:
        path=Path(row['path']);raw=path.read_bytes();assert dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())=={key:row[key] for key in ['bytes','sha256']},str(path)
    p=subprocess.run(['dpkg-query','-W','qtltools'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True);assert p.returncode==1 and not p.stdout
    result=dict(status='PASS_PRIVATE_REFERENCE_EXECUTABLE_AND_LOADED_LIBRARIES_UNCHANGED',files=len(rows),system_qtltools_package_installed=False,system_install_performed=False,shared_library_hashes_unchanged=True)
    with O.open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.write('\n')
    print('PASS:private executable and',len(rows)-1,'loaded libraries unchanged;system QTLtools remains uninstalled',flush=True)
