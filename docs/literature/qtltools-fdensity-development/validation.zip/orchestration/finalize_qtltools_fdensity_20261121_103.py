from pathlib import Path
import ast,copy,hashlib,importlib.util,json,re,subprocess,sys,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/qt-1';B=T/'build/qtltools-fdensity-1';D=T/'docs/literature/qtltools-fdensity-development';O=R/'build/git-publish/20261121-qtltools-103';BASE='3408fdcf476fb9c39b83eb30d00bda97262d873b'
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
def git(*args):return subprocess.check_output(['git','--no-replace-objects',*args],cwd=T)
if __name__=='__main__':
    for host in ['windows','linux']:assert json.loads((O/('reader-'+host+'.PROCESS.json')).read_bytes())['exit_code']==0
    a=json.loads((B/'reader-windows-1/RESULT.json').read_bytes());b=json.loads((B/'reader-linux-1/RESULT.json').read_bytes());assert a.pop('restored') is True and b.pop('restored') is False;assert a.pop('qualified_JAR_bytes_verified') is True and b.pop('qualified_JAR_bytes_verified') is False and a==b
    index=json.loads((D/'INDEX.json').read_bytes())
    for name,wanted in index.items():assert pin((B/'reader-windows-1/captured'/name).read_bytes())==wanted,name
    spec=importlib.util.spec_from_file_location('fdensity_reader',T/'tools/literature/qtltools_fdensity/verify.py');reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader);profile=json.loads((D/'PROFILE.json').read_bytes());refusals={}
    for label,mutate in [('whole-tool',lambda row:row.update(whole_tool_qualified=True)),('CLI',lambda row:row.update(CLI_implemented=True)),('drop-source-guard',lambda row:row.update(source_order_guard_preserved=False)),('extra-family-credit',lambda row:row.update(new_catalog_credit=1))]:
        changed=copy.deepcopy(profile);mutate(changed)
        try:reader.scope(changed)
        except ValueError as error:refusals[label]=dict(refused=True,error=str(error))
        else:raise AssertionError('False component scope admitted: '+label)
    links=0
    for path in [T/'docs/literature/QTLTOOLS_FDENSITY.md',T/'docs/literature/QTLTOOLS_SOURCE_ASSESSMENT.md',T/'examples/qtltools-fdensity/README.md',D/'README.md']:
        for name in re.findall(r'\]\(([^)]+)\)',path.read_text(encoding='utf-8')):
            if ':' in name or name.startswith('#'):continue
            assert (path.parent/name.split('#',1)[0]).resolve().exists(),(str(path),name);links+=1
    for path in (T/'tools/literature/qtltools_fdensity').glob('*.py'):ast.parse(path.read_text(encoding='utf-8'),filename=str(path))
    for name,wanted in profile['canonical_unchanged'].items():assert pin((T/name).read_bytes())==wanted==pin(git('show',BASE+':'+name)),name
    assert not git('diff',BASE,'--name-only','--','src/main/java/org/jlinalg/genetics/GenomicIntervals.java','site','.github','tools/literature/reviewed-uses.json','docs/literature/omics-2023-2026','build.gradle','settings.gradle','gradle.properties')
    for name,wanted in json.loads((B/'normal-gradle-2/STARTED.json').read_bytes())['source_inputs'].items():assert pin((T/name).read_bytes())==wanted,name
    old=git('show',BASE+':docs/literature/HANDOVER_CURRENT.md');assert (T/'docs/literature/HANDOVER_CURRENT.md').read_bytes().endswith(old[len(b'# Current toolbox handover\n\n'):])
    spec=importlib.util.spec_from_file_location('inventory',O.parent/'20261115-all-main-3/inventory.py');inventory=importlib.util.module_from_spec(spec);spec.loader.exec_module(inventory)
    for state in json.loads((O/'WORKTREES-BEFORE.json').read_bytes()):assert inventory.snapshot(Path(state['root']))==state,state['root']
    runtime=json.loads((B/'runtime-unchanged-1.json').read_bytes());assert runtime['shared_library_hashes_unchanged'] is True and runtime['system_qtltools_package_installed'] is False
    sources={}
    for name in ['run_qtltools_fdensity_reader_20261121_103.py','check_qtltools_runtime_unchanged_20261121_103.py','finalize_qtltools_fdensity_20261121_103.py']:sources['orchestration/'+name]=R/'build'/name
    for host in ['windows','linux']:
        for suffix in ['STARTED.json','PROCESS.json','stdout','stderr']:sources['reader-'+host+'/'+suffix]=O/('reader-'+host+'.'+suffix)
        sources['reader-'+host+'/RESULT.json']=B/('reader-'+host+'-1')/'RESULT.json'
    sources['runtime/UNCHANGED.json']=B/'runtime-unchanged-1.json';saved={}
    with zipfile.ZipFile(D/'validation.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,path in sorted(sources.items()):
            raw=path.read_bytes();info=zipfile.ZipInfo(name,(2026,11,21,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,raw);saved[name]=pin(raw)
    value=dict(status='PASS_NATIVE_QTLTOOLS_FDENSITY_API_CHECKPOINT',API_only=True,CLI_implemented=False,original_cases=576,original_successes=569,retained_original_errors=7,complete_original_bins=2838,tests_each_normal_and_packaged_JVM=588,packaged_JVMs=['Windows21','Windows25','Linux21'],preceding_JAR_payloads_byte_identical=22425,added_native_class_payloads=4,initial_failed_build_retained=dict(tests=483,failures=313,admitted=False),control_files_restored_exact=len(index),scope_refusals=refusals,relative_document_links_checked=links,canonical_files_unchanged=33,preceding_owners_preserved=59,private_runtime_and_shared_library_hashes_unchanged=runtime,profile=pin((D/'PROFILE.json').read_bytes()),validation_archive=pin((D/'validation.zip').read_bytes()),validation_members=saved,new_catalog_credit=0,catalog=dict(scoped_families=145,reviewed_uses=1630,pending_uses=1092),whole_tool_qualified=False,whole_goal_complete=False)
    save(D/'VALIDATION.json',value);save(O/'VALIDATION.json',value);print('PASS:588 tests/JVM;576 original cases;4171 restored controls;33 canonical files and59 preceding owners preserved;API only',flush=True)
