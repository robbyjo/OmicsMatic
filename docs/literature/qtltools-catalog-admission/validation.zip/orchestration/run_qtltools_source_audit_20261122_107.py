import json,subprocess,sys
from prepare_qtltools_catalog_20261122_107 import R,T,O
from prepare_handover_qtltools_20261121_105 import pin,save
host=sys.argv[1];assert host in ['windows','linux'];B=T/'build/qtltools-catalog-1';D=B/('fresh-source-'+host+'-1');D.mkdir();script=T/'tools/literature/audit_qtltools_source_roles.py';pdf=B/'auxiliary-intake-1/P190-mmc1.pdf';cache=R/'build/literature-review/xml';out=D/'result'
def mount(path):return '/mnt/d/'+path.relative_to(R.anchor).as_posix()
if host=='windows':command=['C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe','-X','utf8','-B',str(script),'--primary-cache',str(cache),'--supplement-pdf',str(pdf),'--out',str(out)]
else:command=['wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','-u','root','--','env','PYTHONPATH='+mount(B/'pdf-reader-dependency-1/python'),'python3','-B',mount(script),'--primary-cache',mount(cache),'--supplement-pdf',mount(pdf),'--out',mount(out)]
save(D/'STARTED.json',dict(command=command,source_inputs={p.relative_to(T).as_posix():pin(p.read_bytes()) for p in [*sorted((T/'tools/literature/qtltools_catalog').glob('*.py')),script]}))
with (D/'stdout').open('xb') as stdout,(D/'stderr').open('xb') as stderr:p=subprocess.run(command,cwd=T,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=300)
save(D/'PROCESS.json',dict(exit_code=p.returncode));print(host,p.returncode,flush=True)
print((D/'stdout').read_text() if p.returncode==0 else (D/'stderr').read_text()[-3000:]);raise SystemExit(p.returncode)
