import json,subprocess,sys
from prepare_qtltools_catalog_20261122_107 import R,T,O
from prepare_handover_qtltools_20261121_105 import save
phase=sys.argv[1];assert phase in ['plan','inspect','apply','verify'];B=T/'build/qtltools-catalog-1';D=B/(phase+'-1');D.mkdir();out=D/'result';command=['C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe','-X','utf8','-B',str(T/'tools/literature/close_qtltools_catalog.py'),'--'+phase,'--primary-cache',str(R/'build/literature-review/xml'),'--supplement-pdf',str(B/'auxiliary-intake-1/P190-mmc1.pdf'),'--checks-root',str(B),'--out',str(out)]
if phase in ['inspect','apply']:command+=['--plan-dir',str(B/'plan-1/result')]
if phase=='apply':
    before=json.loads((B/'preview-ui-2/browser/COMPLETED.json').read_bytes());assert before['integrations']==146 and before['reviewed']==1639 and len(before['paper_roles_checked'])==9
    assert json.loads((B/'preview-ui-2/PROCESS.json').read_bytes())['exit_code']==0
save(D/'STARTED.json',dict(command=command))
with (D/'stdout').open('xb') as stdout,(D/'stderr').open('xb') as stderr:process=subprocess.run(command,cwd=T,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=600)
save(D/'PROCESS.json',dict(exit_code=process.returncode));print(phase,process.returncode,flush=True);print((D/'stdout').read_text()[-2000:] if process.returncode==0 else (D/'stderr').read_text()[-4000:]);raise SystemExit(process.returncode)
