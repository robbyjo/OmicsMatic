import json,os,re,subprocess,sys
from prepare_qtltools_catalog_20261122_107 import R,T,O
from prepare_handover_qtltools_20261121_105 import pin,save
host=sys.argv[1];assert host in ['windows','linux'];B=T/'build/qtltools-catalog-1';D=B/('catalog-controls-'+host+'-1');D.mkdir();PY='C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
def mount(path):return '/mnt/d/'+path.relative_to(R.anchor).as_posix()
def run(label,arguments,expected):
    folder=D/label;folder.mkdir();env=os.environ.copy();env['PYTHONPATH']=str(T/'tools/literature')+os.pathsep+str(B/'pdf-reader-dependency-1/python')
    if host=='windows':command=[PY,'-X','utf8','-B',*arguments]
    else:command=['wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','-u','root','--','env','PYTHONPATH='+mount(T/'tools/literature')+':'+mount(B/'pdf-reader-dependency-1/python'),'python3','-B',*arguments]
    save(folder/'STARTED.json',dict(command=command,expected_exit_code=expected))
    with (folder/'stdout').open('xb') as stdout,(folder/'stderr').open('xb') as stderr:process=subprocess.run(command,cwd=T,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=300)
    save(folder/'PROCESS.json',dict(exit_code=process.returncode));assert process.returncode==expected,(label,process.returncode,(folder/'stderr').read_text()[-4000:]);return folder
if __name__=='__main__':
    unit=run('model-transaction',['-m','unittest','-v','qtltools_catalog.test_model','qtltools_catalog.test_transaction'],0);log=(unit/'stderr').read_text();match=re.search(r'Ran (\d+) tests',log);assert match and '\nOK\n' in log;count=int(match[1]);assert count>=31
    script=T/'tools/literature/audit_qtltools_source_roles.py';pdf=B/'auxiliary-intake-1/P190-mmc1.pdf';cache=R/'build/literature-review/xml';bad=B/'source-refusal-inputs';records={}
    for label,c,p,expected,reason in [('missing-xml',bad/'missing-cache',pdf,3,'SKIP3'),('changed-xml',bad/'changed-cache',pdf,2,'Primary XML identity differs'),('missing-pdf',cache,bad/'missing.pdf',3,'SKIP3'),('changed-pdf',cache,bad/'wrong.pdf',2,'Changed P190 publisher supplement')]:
        folder=D/label;out=folder/'result';path=(lambda p:mount(p)) if host=='linux' else str
        run(label,[path(script),'--primary-cache',path(c),'--supplement-pdf',path(p),'--out',path(out)],expected)
        failure=json.loads((out/'FAILURE.json').read_bytes());assert reason in (failure['status']+' '+failure['error']),(label,failure);records[label]=dict(exit_code=expected,status=failure['status'],refused=True,error=failure['error'])
    save(D/'RESULT.json',dict(status='PASS_QTLTOOLS_CATALOG_MODEL_TRANSACTION_AND_SOURCE_REFUSALS',model_transaction_tests=count,source_refusals=4,all_source_refusals_passed=True,source_refusal_results=records,canonical_metadata_changed=False,scientific_models_executed=False))
    print(host,'PASS',count,'model/transaction tests;four actual source-audit refusals hit intended causes',flush=True)
