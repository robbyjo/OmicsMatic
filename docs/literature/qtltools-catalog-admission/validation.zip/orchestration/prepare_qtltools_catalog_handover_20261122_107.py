from pathlib import Path
import json
from prepare_qtltools_catalog_20261122_107 import R,T,O
from prepare_handover_qtltools_20261121_105 import pin,save,git
B=T/'build/qtltools-catalog-1';Q=T/'docs/literature/qtltools-catalog-admission'
if __name__=='__main__':
    assert json.loads((B/'apply-1/result/COMPLETED.json').read_bytes())['result']['integrations']==146
    current=T/'docs/literature/HANDOVER_CURRENT.md';old=current.read_bytes();assert old==git(T,'show','HEAD:docs/literature/HANDOVER_CURRENT.md');heading=b'# Current toolbox handover\n\n';assert old.startswith(heading)
    intro='''**Current: [QTLtools admitted, exact remaining work and private transfer](QTLTOOLS_CATALOG_CHECKPOINT_2026-11-22.md).**
QTLtools now has one scoped upstream family and nine primary-bound reviews.
Counts are **146 scoped families (26 native +120 upstream),1639 reviewed uses and
1083 pending**;250 papers,446 labels,485 definitions and2722 observations remain
intact. All1630 older reviews,2713 unrelated observations,445 inventory rows and
484 definitions are preserved. Both Windows/Linux source and installed audits pass
with the complete844-member manifest.32 model/transaction tests and4 actual source
refusals pass per host. Styled preview/installed desktop/mobile checks cover all
nine rows,warnings and counts. Scientific code/JAR is unchanged from qualified
qt-3;no model refit or extra native family is claimed. P190 supplement now resolves
the execution use while its edition/adaptive wording stays explicit. Preserve
the other paper-specific grouping,mode,radius,match,quan/mapping and citation27
distinctions. All63 preceding owners are preserved(current owner64). **Transfer
ignored JARs,runtimes,private XML/PDF/renders,reader dependency and complete failed
evidence separately before machine retirement.** Resume high-impact SKAT/SKAT-O
and ACAT gap inspection,then remaining methods and1083 individual use reviews.
Cell Ranger stays excluded;unfinished reports remain off Pages. The full250-paper
objective remains active and unfinished. Lower entries retain historical counts.

'''.encode()
    current.write_bytes(heading+intro+old[len(heading):]);save(O/'HANDOVER-PREPEND.json',dict(previous=pin(old),current=pin(current.read_bytes()),previous_body_retained_exact=True))
    A=B/'auxiliary-intake-1';private=dict(status='PRIVATE_ARTIFACTS_REQUIRE_SEPARATE_CHECKSUMMED_TRANSFER',private_transfer_performed=False,retain_all63_preceding_owners_and_current_owner64=True,current_private_evidence_root=str(B),private_primary_xml_root=str(R/'build/literature-review/xml'),private_auxiliary_pdf_and_renders={str(path):pin(path.read_bytes()) for path in [A/'P190-mmc1.pdf',A/'P190-page21.png',A/'P190-page25.png']},private_pdf_reader_dependency_root=str(B/'pdf-reader-dependency-1'),private_changed_XML_refusal_copy=str(B/'source-refusal-inputs/changed-cache'),earlier_transfer_records=['docs/literature/qtltools-workflow-development/PRIVATE-TRANSFER.json','docs/literature/handover-2026-11-21-qtltools/PRIVATE-TRANSFER.json','docs/literature/monocle-admission-checkpoint/PRIVATE-TRANSFER.json'],required_action='Preserve the original machine,all owners and full private/failed evidence. Arrange authorized separate private transfer before retirement and compare SHA256 manifests. The Git repository contains source/paraphrases/hashes and selected control metadata,not the publisher supplement/renders,full XML text,dependencies,scientific binaries/JARs or complete ignored evidence.')
    save(Q/'PRIVATE-TRANSFER.json',private);print('Saved current handover;all previous content retained;private artifacts explicitly inventoried',flush=True)
