from pathlib import Path
import json,subprocess,sys
from prepare_qtltools_catalog_20261122_107 import R,T,O
from prepare_handover_qtltools_20261121_105 import pin,save
sys.path.insert(0,str(T/'tools/literature'))
from qtltools_catalog import primary as p
B=T/'build/qtltools-catalog-1';A=B/'auxiliary-intake-1';Q=T/p.FOLDER
if __name__=='__main__':
    C=B/'source-freeze-1';C.mkdir();Q.mkdir();(Q/'.gitattributes').write_bytes(b'* -text whitespace=cr-at-eol\n')
    aux=dict(schema_version=1,url=p.PDF_URL,pdf=p.PDF_PIN,pages_total=55,extractor='pypdf',extractor_version='6.21.4',manual_visual_pages=[21,25],pages={str(n):dict(section=s,extracted_text=pin((A/f'P190-page-{n:02d}.txt').read_bytes()),private_render=pin((A/f'P190-page{n}.png').read_bytes())) for n,s in p.PDF_PAGES.items()},public_source_text_or_images_included=False,interpretation='Note S1.7 explicitly reports QTLtools execution and grouping/permutation settings,while no QTLtools edition is stated. Preserve its adaptive-wording/fixed-count discrepancy and its S1.4 covariate cross-reference;the confounder heading is S1.5. No GTEx or author pipeline has been executed.')
    save(Q/'AUXILIARY.json',aux)
    source=p.audit(R/'build/literature-review/xml',A/'P190-mmc1.pdf');save(Q/'CENSUS.json',source)
    save(Q/'CENSUS-PIN.json',dict(census=pin((Q/'CENSUS.json').read_bytes()),source_inputs={path.relative_to(T).as_posix():pin(path.read_bytes()) for path in [*sorted((T/'tools/literature/qtltools_catalog').glob('*.py')),T/'tools/literature/audit_qtltools_source_roles.py']},auxiliary=pin((Q/'AUXILIARY.json').read_bytes()),scope='Nine individual source-role reviews are prepared;canonical metadata,review ledger and family credit remain unchanged.'))
    save(C/'RESULT.json',dict(status='PASS_PRIMARY_BOUND_QTLTOOLS9_REVIEWS_PREPARED',papers=source['papers_scanned'],roles=len(source['roles']),XML_pointers=source['reviewed_XML_pointers'],PDF_pages=source['reviewed_PDF_pages'],frozen_census=pin((Q/'CENSUS.json').read_bytes()),canonical_metadata_modified=False))
    print('PASS:250 XML/DOI identities;9 individual source reviews;19 XML pointers;2 exact publisher supplement pages;canonical state unchanged',flush=True)
