import json,sys
from prepare_qtltools_catalog_20261122_107 import R,T,O
sys.path.insert(0,str(T/'tools/literature'))
from qtltools_catalog import evidence as e,primary as p
fixture=T/e.CONTROLS/'FIXTURE.json';value=json.loads(fixture.read_bytes());value['source_code']=e.sources();value['initial_guard_failure_retained']='build/qtltools-catalog-1/failed-control-sources-1';fixture.write_bytes(p.encoded(value))
old=R/'build/run_qtltools_catalog_controls_20261122_107.py';new=R/'build/run_qtltools_catalog_controls_v2_20261122_107.py';text=old.read_text();find="'catalog-controls-'+host+'-1'";assert text.count(find)==1
with new.open('x',encoding='utf-8',newline='\n') as stream:stream.write(text.replace(find,"'catalog-controls-'+host+'-2'"))
print('Prepared NEW retry;initial failed31-test runs and their complete owner source retained',flush=True)
