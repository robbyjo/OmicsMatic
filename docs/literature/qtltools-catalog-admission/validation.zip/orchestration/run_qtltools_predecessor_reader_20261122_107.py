import subprocess,sys
from prepare_qtltools_catalog_20261122_107 import R,T,O
from prepare_handover_qtltools_20261121_105 import pin,save,git
label=sys.argv[1];assert label in ['workflow','catalog'];B=T/'build/qtltools-catalog-1';D=B/'predecessor-readers'/label;D.mkdir(parents=True)
old=R/('build/qt-3' if label=='workflow' else 'build/mo-9');out=old/'build/qtltools-admission-predecessor-107'
py='C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
if label=='workflow':command=[py,'-X','utf8','-B',str(old/'tools/literature/qtltools_workflow/verify.py'),'--out',str(out),'--jar',str(old/'build/qtltools-workflow-1/normal-gradle-5/project-build/cli/omicsmatic-0.4.0.jar')]
else:command=[py,'-X','utf8','-B',str(old/'tools/literature/close_monocle_catalog.py'),'--verify','--primary-cache',str(R/'build/literature-review/xml'),'--out',str(out)]
assert not git(old,'status','--porcelain=v1','-z','--untracked-files=all')
save(D/'STARTED.json',dict(command=command,actual_owner=str(old),head=git(old,'rev-parse','HEAD').decode().strip(),out=str(out),scope='Actual unchanged qualified/catalog predecessor reader;no scientific refitting or canonical update.'))
with (D/'stdout').open('xb') as stdout,(D/'stderr').open('xb') as stderr:p=subprocess.run(command,cwd=old,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=600)
save(D/'PROCESS.json',dict(exit_code=p.returncode));assert not git(old,'status','--porcelain=v1','-z','--untracked-files=all')
if p.returncode==0:
    result=out/('RESULT.json' if label=='workflow' else 'COMPLETED.json');(D/'RESULT.json').write_bytes(result.read_bytes())
print(label,'reader',p.returncode,flush=True);print((D/'stdout').read_text()[-1400:] if p.returncode==0 else (D/'stderr').read_text()[-3000:]);raise SystemExit(p.returncode)
