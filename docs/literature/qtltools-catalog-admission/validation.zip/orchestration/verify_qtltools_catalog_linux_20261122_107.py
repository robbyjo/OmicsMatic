import os,subprocess
from prepare_qtltools_catalog_20261122_107 import R,T,O
from prepare_handover_qtltools_20261121_105 import save,pin
B=T/'build/qtltools-catalog-1';D=B/'verify-linux-1';D.mkdir();bridge=D/'git-bridge';bridge.mkdir();wrapper=bridge/'git';wrapper.write_bytes(b'#!/bin/sh\nexec "/mnt/c/Program Files/Git/cmd/git.exe" "$@"\n');wrapper.chmod(0o755)
def mount(path):return '/mnt/d/'+path.relative_to(R.anchor).as_posix()
command=['wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','-u','root','--','env','PATH='+mount(bridge)+':/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin','PYTHONPATH='+mount(B/'pdf-reader-dependency-1/python'),'python3','-B',mount(T/'tools/literature/close_qtltools_catalog.py'),'--verify','--primary-cache',mount(R/'build/literature-review/xml'),'--supplement-pdf',mount(B/'auxiliary-intake-1/P190-mmc1.pdf'),'--out',mount(D/'result')]
save(D/'STARTED.json',dict(command=command,git_bridge=pin(wrapper.read_bytes()),scope='Unchanged Linux Python catalog verifier and fresh XML/PDF audit;Windows Git bridge reads this Windows-owned worktree metadata. No scientific model refit or current-owner source/metadata mutation. Actual preceding owner checks already executed on their original host.'))
with (D/'stdout').open('xb') as stdout,(D/'stderr').open('xb') as stderr:process=subprocess.run(command,cwd=T,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=600)
save(D/'PROCESS.json',dict(exit_code=process.returncode));print('Linux installed verify',process.returncode,flush=True);print((D/'stdout').read_text()[-2000:] if process.returncode==0 else (D/'stderr').read_text()[-4000:]);raise SystemExit(process.returncode)
