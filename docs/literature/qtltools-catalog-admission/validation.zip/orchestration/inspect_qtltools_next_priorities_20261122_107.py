from collections import Counter
import json
from prepare_qtltools_catalog_20261122_107 import R,T,O
from prepare_handover_qtltools_20261121_105 import save
data=T/'docs/literature/omics-2023-2026';rows=json.loads((data/'tool-inventory.json').read_bytes());papers=json.loads((data/'papers.json').read_bytes());reviewed={(r['pmcid'],r['tool_id']) for r in json.loads((T/'tools/literature/reviewed-uses.json').read_bytes())['reviews']};pending=Counter(u['tool_id'] for paper in papers for u in paper['tools'] if (paper['pmcid'],u['tool_id']) not in reviewed)
gaps=[dict(id=r['id'],name=r['name'],papers=r['paper_count'],status=r['implementation_status'],pending_source_uses=pending[r['id']]) for r in rows if r['implementation_status'] in ['missing','method-overlap']];gaps.sort(key=lambda r:(-r['papers'],r['id']))
save(T/'build/qtltools-catalog-1/NEXT-PRIORITIES.json',dict(status='CURRENT_FREQUENCY_QUEUE_FOR_HIGH_IMPACT_GAP_SELECTION',candidates=gaps,remaining_pending_source_uses=sum(pending.values()),source='Canonical inventory plus exact review-identity set;frequency is one impact signal,not proof of feasibility or method equivalence. Inspect existing native/adapters,original licenses,source roles and runtime requirements before choosing implementation.'))
print(json.dumps(gaps[:20],indent=2));print('Pending',sum(pending.values()))
