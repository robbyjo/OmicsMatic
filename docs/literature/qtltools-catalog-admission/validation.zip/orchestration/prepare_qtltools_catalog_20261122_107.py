from pathlib import Path
import json,subprocess
from prepare_handover_qtltools_20261121_105 import R,pin,save,git,inventory
T=R/'build/qt-4';O=R/'build/git-publish/20261122-qtltools-catalog-107';BASE='3ae29f5d622e523039288e54b98d73785e302c06'
if __name__=='__main__':
    O.mkdir(parents=True)
    inv=inventory();states=[inv.snapshot(Path(block.splitlines()[0][9:])) for block in git(R,'worktree','list','--porcelain').decode().strip().split('\n\n')]
    assert len(states)==63;save(O/'WORKTREES-BEFORE.json',states)
    lookup={s['root']:s for s in states}
    for s in json.loads((O.parent/'20261121-qtltools-workflow-106/WORKTREES-BEFORE.json').read_bytes()):assert lookup[s['root']]==s,s['root']
    assert lookup[str(R/'build/qt-3')]['head']==BASE and not lookup[str(R/'build/qt-3')]['files']
    assert git(R,'ls-remote','origin','refs/heads/main').decode().split()[0]==BASE
    command=['git','worktree','add','-b','codex/qtltools-catalog-20261122',str(T),BASE];save(O/'WORKTREE-STARTED.json',dict(command=command))
    with (O/'worktree.stdout').open('xb') as stdout,(O/'worktree.stderr').open('xb') as stderr:p=subprocess.run(command,cwd=R,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=240)
    save(O/'WORKTREE-PROCESS.json',dict(exit_code=p.returncode));assert p.returncode==0
    print('PASS:new owner64;all63 preceding owners preserved',flush=True)
