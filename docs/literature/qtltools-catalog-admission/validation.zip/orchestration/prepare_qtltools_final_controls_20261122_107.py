import json,sys
from prepare_qtltools_catalog_20261122_107 import R,T,O
sys.path.insert(0,str(T/'tools/literature'))
from qtltools_catalog import evidence as e,primary as p
from qtltools_catalog.catalog import zipped
B=T/'build/qtltools-catalog-1';D=B/'controls2-source-snapshot';D.mkdir()
(D/'owner-source.zip').write_bytes(zipped({n:(T/n).read_bytes() for n in e.OWN}));(D/'FIXTURE.json').write_bytes((T/e.CONTROLS/'FIXTURE.json').read_bytes())
print('Preserved exact source for the preceding32-test successful controls before tightening archive transcript readback',flush=True)
