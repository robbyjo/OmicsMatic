from pathlib import Path
import concurrent.futures,hashlib,importlib.util,json,subprocess,urllib.request
from prepare_qtltools_catalog_20261122_107 import R,T,O
from prepare_handover_qtltools_20261121_105 import pin,save
B=T/'build/qtltools-catalog-1';A=B/'auxiliary-intake-1'

def fetch(url,cap=16*1024*1024):
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'OmicsMatic-source-audit'}),timeout=90) as response:
        raw=response.read(cap+1);assert len(raw)<=cap,'Source capacity exceeded';return raw

def intake(label,url):
    try:
        raw=fetch(url);(A/label).write_bytes(raw);return label,dict(status='DOWNLOADED_FOR_PRIVATE_SOURCE_INSPECTION',url=url,**pin(raw))
    except Exception as e:return label,dict(status='SKIP3_AUXILIARY_SOURCE_UNAVAILABLE',url=url,error=repr(e),required_action='Supply the exact permitted publisher supplement or author source to resolve the stated binding;retain unknown edition/execution where not established. Primary XML source review can continue.')

if __name__=='__main__':
    A.mkdir(parents=True)
    tasks=[('P190-mmc1.pdf','https://ars.els-cdn.com/content/image/1-s2.0-S0002929725004033-mmc1.pdf'),('P190-bitbucket-master.json','https://api.bitbucket.org/2.0/repositories/majiqtl/majiqtl/refs/branches/master'),('P203-repository.json','https://api.github.com/repos/liusihan/population-compare-pipeline')]
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=dict(pool.map(lambda pair:intake(*pair),tasks))
    save(A/'RESULT.json',dict(records=results,published_primary_fulltext=False,models_executed=False))
    print(json.dumps(results,indent=2),flush=True)
    if results['P190-mmc1.pdf']['status'].startswith('DOWNLOADED'):
        raw=(A/'P190-mmc1.pdf').read_bytes();assert raw.startswith(b'%PDF-')
        import pypdf
        reader=pypdf.PdfReader(A/'P190-mmc1.pdf');records=[]
        for n,page in enumerate(reader.pages):
            txt=page.extract_text();(A/f'P190-page-{n+1:02d}.txt').write_text(txt,encoding='utf-8')
            if any(w in txt.lower() for w in ['qtltools','s3.1','s5.1','s1.7']):records.append(dict(page=n+1,text=txt))
        save(A/'P190-PRIVATE-matched-pages.json',dict(pages=len(reader.pages),matches=records,pdf=pin(raw)))
        print('PDF',len(reader.pages),'pages;relevant pages',[r['page'] for r in records],flush=True)
    print('Available renderers',[(name,str(importlib.util.find_spec(name))) for name in ['pypdf','fitz']],flush=True)
