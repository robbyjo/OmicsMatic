from prepare_qtltools_catalog_20261122_107 import R,T,O
from prepare_handover_qtltools_20261121_105 import save,pin
B=T/'build/qtltools-catalog-1'
old=R/'build/run_qtltools_catalog_ui_20261122_107.py';text=old.read_text();find="D=B/(mode+'-ui-1')";assert text.count(find)==1;text=text.replace(find,"D=B/(mode+'-ui-2')")
anchor='class Handler(http.server.SimpleHTTPRequestHandler):\n';assert text.count(anchor)==1
text=text.replace(anchor,anchor+'''    def translate_path(self,path):
        candidate=Path(super().translate_path(path))
        if candidate.is_file():return str(candidate)
        relative=candidate.resolve().relative_to(site.resolve());fallback=(T/'site'/relative).resolve()
        assert fallback.is_relative_to((T/'site').resolve())
        return str(fallback)
''')
target=R/'build/run_qtltools_catalog_ui_v2_20261122_107.py'
with target.open('x',encoding='utf-8',newline='\n') as stream:stream.write(text)
save(B/'preview-ui-1/VISUAL-SCOPE.json',dict(status='INITIAL_PREVIEW_DOM_CHECKS_PASSED_BUT_VISUAL_QUALIFICATION_NOT_ADMITTED',reason='The sparse preview HTTP root lacked unchanged assets/styles.css and assets/app.js;their404 responses are retained. A NEW preview serves the same exact planned HTML with unchanged site assets.',unchanged_ui_test_source=pin((T/'tools/literature/check_qtltools_catalog_ui.cjs').read_bytes()),production_source_changed=False))
old=R/'build/run_qtltools_catalog_phase_20261122_107.py';text=old.read_text();text=text.replace('preview-ui-1/','preview-ui-2/');target=R/'build/run_qtltools_catalog_phase_v2_20261122_107.py'
with target.open('x',encoding='utf-8',newline='\n') as stream:stream.write(text)
print('Prepared NEW preview with exact planned HTML and unchanged site assets;earlier sparse preview retained',flush=True)
