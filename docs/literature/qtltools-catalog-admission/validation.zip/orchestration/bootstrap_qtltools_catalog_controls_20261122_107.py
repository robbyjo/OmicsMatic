import gzip,json,sys
from prepare_qtltools_catalog_20261122_107 import R,T,O
from prepare_handover_qtltools_20261121_105 import pin,save
sys.path.insert(0,str(T/'tools/literature'))
from qtltools_catalog import primary as p,model as m,evidence as e
from qtltools_catalog.catalog import zipped,baseline
B=T/'build/qtltools-catalog-1';Q=T/e.CONTROLS
if __name__=='__main__':
    D=B/'control-bootstrap-1';D.mkdir();Q.mkdir();(Q/'.gitattributes').write_bytes(b'* -text whitespace=cr-at-eol\n')
    before={name:(T/name).read_bytes() for name in m.META};baseline(before);qualified=e.component_qualification(B)
    (Q/'metadata-before.zip').write_bytes(zipped(before));save(Q/'QUALIFICATION-BASE.json',qualified)
    save(Q/'FIXTURE.json',dict(status='EXACT_PREDECESSOR_AND_ACTUAL_COMPONENT_QUALIFICATION_FOR_ADMISSION_CONTROLS',base=e.BASE,before={n:pin(raw) for n,raw in before.items()},qualification=pin((Q/'QUALIFICATION-BASE.json').read_bytes()),source_code=e.sources(),canonical_modified=False))
    bad=B/'source-refusal-inputs';bad.mkdir();(bad/'missing-cache').mkdir();(bad/'changed-cache').mkdir();(bad/'wrong.pdf').write_bytes(b'%PDF-1.7\nintentionally not the exact publisher supplement\n')
    first=p.identities()[0];original=R/'build/literature-review/xml'/(first['pmcid']+'.xml.gz');raw=gzip.decompress(original.read_bytes());(bad/'changed-cache'/original.name).write_bytes(gzip.compress(raw+b'\n<!-- deliberate source-integrity refusal control -->\n',mtime=0))
    save(bad/'INPUT-PINS.json',dict(original_xml=pin(original.read_bytes()),changed_xml=pin((bad/'changed-cache'/original.name).read_bytes()),wrong_pdf=pin((bad/'wrong.pdf').read_bytes()),private_primary_copy_excluded_from_public_archive=True))
    save(D/'RESULT.json',dict(status='PASS_EXACT_CONTROL_FIXTURE_PREPARED',qualification=qualified['result'],before_metadata_files=8,canonical_modified=False))
    print('PASS:exact8-file fixture;actual immutable component and fresh source evidence;current provider source ready for controls',flush=True)
