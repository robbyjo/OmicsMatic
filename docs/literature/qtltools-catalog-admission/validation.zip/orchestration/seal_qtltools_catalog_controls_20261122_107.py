import json,sys
from prepare_qtltools_catalog_20261122_107 import R,T,O
from prepare_handover_qtltools_20261121_105 import pin,save
sys.path.insert(0,str(T/'tools/literature'))
from qtltools_catalog import primary as p,model as m,evidence as e
from qtltools_catalog.catalog import zipped,read_control_archive
B=T/'build/qtltools-catalog-1';Q=T/e.CONTROLS
if __name__=='__main__':
    members={};tests=[]
    for host in ['windows','linux']:
        directory=B/('catalog-controls-'+host+'-3');result=json.loads((directory/'RESULT.json').read_bytes());assert result['all_source_refusals_passed'];tests.append(result['model_transaction_tests'])
        for path in directory.rglob('*'):
            if path.is_file():members[host+'/'+path.relative_to(directory).as_posix()]=path.read_bytes()
    assert tests==[32,32]
    for host in ['windows','linux']:
        for attempt in [1,2]:
            directory=B/('catalog-controls-'+host+'-'+str(attempt))
            for path in directory.rglob('*'):
                if path.is_file():members[f'historical/controls-{attempt}/{host}/'+path.relative_to(directory).as_posix()]=path.read_bytes()
    for label in ['source-freeze-1','source-freeze-2','failed-control-sources-1','controls2-source-snapshot']:
        for path in (B/label).rglob('*'):
            if path.is_file():members['historical/'+label+'/'+path.relative_to(B/label).as_posix()]=path.read_bytes()
    for name in ['bootstrap_qtltools_catalog_controls_20261122_107.py','run_qtltools_catalog_controls_20261122_107.py','run_qtltools_catalog_controls_v2_20261122_107.py','run_qtltools_catalog_controls_v3_20261122_107.py','prepare_qtltools_controls_retry_20261122_107.py','prepare_qtltools_final_controls_20261122_107.py','start_qtltools_final_controls_20261122_107.py',__file__.replace('\\','/').rsplit('/',1)[-1]]:members['orchestration/'+name]=(R/'build'/name).read_bytes()
    archive=zipped(members);(Q/'checks.zip').write_bytes(archive)
    record=dict(schema_version=1,status='PASS_QTLTOOLS_CATALOG_MODEL_TRANSACTION_AND_SOURCE_REFUSALS',tests_each_host=32,source_refusals_each_host=4,source_code=e.sources(),members={n:pin(raw) for n,raw in members.items()},archive=pin(archive),current_roots=['windows','linux'],historical_roots_unadmitted_or_superseded=True,private_primary_XML_PDF_text_images_and_dependencies_published=False,canonical_metadata_modified=False)
    save(Q/'CONTROL-CHECKS.json',record);assert read_control_archive(Q/'checks.zip',record['members'])==members
    result=e.control_evidence();save(B/'CONTROLS-SEALED.json',result)
    print('PASS:current32 model/transaction tests and4 actual source refusals per host;complete process/transcript readback;old failures retained;',len(members),'members',flush=True)
