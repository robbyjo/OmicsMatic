import hashlib,json,zipfile,urllib.request
from pathlib import PurePosixPath
from prepare_qtltools_catalog_20261122_107 import R,T,O
from prepare_handover_qtltools_20261121_105 import pin,save
B=T/'build/qtltools-catalog-1';D=B/'pdf-reader-dependency-1'
def get(url,cap):
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'OmicsMatic-source-audit'}),timeout=90) as response:raw=response.read(cap+1)
    assert len(raw)<=cap;return raw
if __name__=='__main__':
    D.mkdir();url='https://pypi.org/pypi/pypdf/6.21.4/json';raw=get(url,2*1024*1024);(D/'pypi.json').write_bytes(raw);data=json.loads(raw);wheel=next(r for r in data['urls'] if r['filename']=='pypdf-6.21.4-py3-none-any.whl');raw=get(wheel['url'],16*1024*1024)
    assert pin(raw)==dict(bytes=wheel['size'],sha256=wheel['digests']['sha256']);path=D/wheel['filename'];path.write_bytes(raw);target=D/'python';target.mkdir();files={}
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None and len(archive.namelist())==len(set(archive.namelist()))
        for info in archive.infolist():
            name=PurePosixPath(info.filename);assert not name.is_absolute() and '..' not in name.parts and name.parts[0] in ['pypdf','pypdf-6.21.4.dist-info']
            assert (info.external_attr>>16)&0o170000!=0o120000
            if info.is_dir():continue
            content=archive.read(info);dest=target/str(name);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(content);files[str(name)]=pin(content)
    save(D/'RESULT.json',dict(status='PASS_PRIVATE_PURE_PYTHON_READER_INSTALLED_WITHOUT_SYSTEM_MUTATION',metadata_url=url,metadata=pin((D/'pypi.json').read_bytes()),wheel_url=wheel['url'],wheel=pin(raw),installation=str(target),files=files,scientific_runtime_changed=False,system_python_changed=False))
    print('PASS:private pypdf6.21.4 wheel verified against PyPI SHA256;',len(files),'files;no system/runtime change',flush=True)
