import gzip,json,re,sys,xml.etree.ElementTree as ET
from prepare_qtltools_catalog_20261122_107 import R,T,O
sys.path.insert(0,str(T/'tools/literature'))
from collect_omics_review import paragraphs,words
from monocle_catalog.model import META
from monocle_catalog.model import registry as current_registry
ps=json.loads((T/META[0]).read_bytes());inv=json.loads((T/META[1]).read_bytes());summary=json.loads((T/META[2]).read_bytes())
print('META',META);print('SUMMARY',json.dumps(summary,ensure_ascii=False)[:3800]);print('INVENTORY',json.dumps(next(r for r in inv if r['id']=='qtltools'),ensure_ascii=False));print('REGISTRY',json.dumps(next(r for r in current_registry() if r['id']=='qtltools'),ensure_ascii=False))
ids=['P073','P074','P104','P108','P190','P201','P203','P219','P227']
for paper in ps:
    if paper['paper_id'] not in ids:continue
    pid=paper['paper_id'];tree=ET.fromstring(gzip.decompress((R/'build/literature-review/xml'/(paper['pmcid']+'.xml.gz')).read_bytes()));blocks=paragraphs(tree)
    print('\n'+pid,'EXISTING',json.dumps(next(r for r in paper['tools'] if r['tool_id']=='qtltools'),ensure_ascii=False)[:1700])
    tables=[dict(id=e.get('id'),text=words(e)) for e in tree.iter('table-wrap') if re.search('qtltools',words(e),re.I)]
    print('QTL-TABLES',json.dumps(tables,ensure_ascii=False))
    if pid in ['P190','P201','P203','P219']:
        print('LINKS',json.dumps(list(dict.fromkeys(e.get('{http://www.w3.org/1999/xlink}href','') for e in tree.iter('ext-link') if re.search('github|zenodo|figshare',e.get('{http://www.w3.org/1999/xlink}href',''),re.I)))))
    if pid=='P190':
        for e in tree.iter('supplementary-material'):print('SUPPLEMENT',ET.tostring(e,encoding='unicode')[:1800])
    if pid=='P219':
        for b in blocks:
            if 26<=b['paragraph_index']<=31:print('CONTEXT',b['paragraph_index'],b['text'])
