from pathlib import Path
import functools,http.server,json,subprocess,sys,threading
from prepare_qtltools_catalog_20261122_107 import R,T,O
from prepare_handover_qtltools_20261121_105 import save,pin
mode=sys.argv[1];assert mode in ['preview','installed'];B=T/'build/qtltools-catalog-1';D=B/(mode+'-ui-2');D.mkdir();browser=D/'browser';browser.mkdir();site=B/'plan-1/result/preview/site' if mode=='preview' else T/'site';log=(D/'server.log').open('x',encoding='utf-8')
class Handler(http.server.SimpleHTTPRequestHandler):
    def translate_path(self,path):
        candidate=Path(super().translate_path(path))
        if candidate.is_file():return str(candidate)
        relative=candidate.resolve().relative_to(site.resolve());fallback=(T/'site'/relative).resolve()
        assert fallback.is_relative_to((T/'site').resolve())
        return str(fallback)
    def log_message(self,format,*args):log.write(format%args+'\n');log.flush()
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(site)));thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();node=Path('C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/node');command=[str(node/'bin/node.exe'),str(T/'tools/literature/check_qtltools_catalog_ui.cjs'),str(node/'node_modules/playwright'),str(browser),'http://127.0.0.1:'+str(server.server_port)]
save(D/'STARTED.json',dict(command=command,mode=mode,source=pin((T/'tools/literature/check_qtltools_catalog_ui.cjs').read_bytes()),html={n:pin((site/n).read_bytes()) for n in ['literature-review.html','literature-warnings.html']},website_published=False))
try:
    with (D/'stdout').open('xb') as stdout,(D/'stderr').open('xb') as stderr:process=subprocess.run(command,cwd=T,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=150)
    save(D/'PROCESS.json',dict(exit_code=process.returncode));print(mode,'UI',process.returncode,flush=True);print((D/'stdout').read_text(),(D/'stderr').read_text()[-3500:]);assert process.returncode==0,'Inspect retained browser evidence'
finally:
    server.shutdown();server.server_close();thread.join(timeout=10);log.close();save(D/'SERVER-CLOSED.json',dict(owned_helper_stopped=not thread.is_alive()))
