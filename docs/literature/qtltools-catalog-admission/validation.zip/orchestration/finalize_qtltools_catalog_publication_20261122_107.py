from pathlib import Path
import ast,json,re,sys,zipfile
from prepare_qtltools_catalog_20261122_107 import R,T,O,BASE
from prepare_handover_qtltools_20261121_105 import pin,save,git,inventory
sys.path.insert(0,str(T/'tools/literature'))
from qtltools_catalog import primary as p,model as m,evidence as e
from qtltools_catalog.catalog import read_before,zipped
from seurat_catalog.catalog import clean_manifest
B=T/'build/qtltools-catalog-1';Q=T/e.FOLDER

def load(path):return json.loads(path.read_bytes())

if __name__=='__main__':
    for label in ['plan-1','inspect-1','apply-1','verify-1','verify-linux-1','preview-ui-2','installed-ui-2']:
        assert load(B/label/'PROCESS.json')['exit_code']==0,label
    for label in ['preview-ui-2','installed-ui-2']:
        assert load(B/label/'SERVER-CLOSED.json')['owned_helper_stopped']
        result=load(B/label/'browser/COMPLETED.json');assert (result['integrations'],result['reviewed'],result['pending'])==(146,1639,1083) and len(result['paper_roles_checked'])==9
        log=(B/label/'server.log').read_text();assert '"GET /assets/styles.css HTTP/1.1" 200' in log and '"GET /assets/app.js HTTP/1.1" 200' in log,label
        start=load(B/label/'STARTED.json');assert start['source']==pin((T/'tools/literature/check_qtltools_catalog_ui.cjs').read_bytes())
        for name,wanted in start['html'].items():assert pin((T/'site'/name).read_bytes())==wanted,(label,name)
    win=load(B/'verify-1/result/COMPLETED.json');linux=load(B/'verify-linux-1/result/COMPLETED.json');assert win['result']==linux['result'] and win['current_manifest']==linux['current_manifest'] and win['actual_owners_rechecked'] and not linux['actual_owners_rechecked'] and win['fresh_primary_audit'] and linux['fresh_primary_audit']
    proof=load(T/e.PROOF);before=read_before(Q/'metadata-before.zip');after={name:(T/name).read_bytes() for name in m.META};qualified=load(Q/'QUALIFICATION.json')
    result=m.check(before,after,p.frozen(),qualified['component']['result']);assert result==proof['result']==win['result']
    assert e.control_evidence()==qualified['controls'];controls=load(T/e.CONTROLS/'CONTROL-CHECKS.json');assert controls['source_code']==load(T/e.CONTROLS/'FIXTURE.json')['source_code']==e.sources()
    # The original ledger records retain their exact serialized prefix; only the
    # final array/document delimiters are replaced to append the nine records.
    raw=before[m.META[5]];newline=b'\r\n' if b'\r\n' in raw else b'\n';closing=raw.rfind(newline+b'  ]');assert closing>0 and after[m.META[5]].startswith(raw[:closing])
    ledger_lineage=dict(status='PASS_ALL1630_PRIOR_LEDGER_RECORD_BYTES_PRESERVED_AS_PREFIX',unchanged_prefix_bytes=closing,before=pin(raw),after=pin(after[m.META[5]]),nine_records_appended=True)
    save(O/'LEDGER-LINEAGE.json',ledger_lineage)
    manifest=clean_manifest();assert manifest['entries']==844
    assert not git(T,'diff',BASE,'--','src/main','src/test','build.gradle','settings.gradle','gradle.properties','.github/workflows','site/assets')
    for name in ['src/main/java/org/jlinalg/cli/JLinAlgCli.java','.github/workflows/pages.yml','site/assets/styles.css','site/assets/app.js']:
        assert (T/name).read_bytes()==git(T,'show',BASE+':'+name),name
    pages=(T/'.github/workflows/pages.yml').read_text();assert 'ignore_patterns("literature-review.html", "literature-warnings.html")' in pages
    current=(T/'docs/literature/HANDOVER_CURRENT.md').read_bytes();old=git(T,'show',BASE+':docs/literature/HANDOVER_CURRENT.md');heading=b'# Current toolbox handover\n\n';assert current.startswith(heading) and current.endswith(old[len(heading):]) and pin(current)==load(O/'HANDOVER-PREPEND.json')['current']
    links=[]
    for path in [T/m.GUIDE,T/'docs/literature/QTLTOOLS_CATALOG_CHECKPOINT_2026-11-22.md',T/'tools/literature/qtltools_catalog/ADMISSION.md',T/p.FOLDER/'README.md']:
        for target in re.findall(r'\]\(([^)\s]+)\)',path.read_text(encoding='utf-8')):
            if target.startswith(('https:','http:','#')):continue
            assert (path.parent/target.split('#')[0]).resolve().is_file(),(str(path),target);links.append(dict(source=path.relative_to(T).as_posix(),target=target))
    for path in (T/'tools/literature/qtltools_catalog').glob('*.py'):ast.parse(path.read_text(encoding='utf-8'),filename=str(path))
    assert load(B/'NEXT-PRIORITIES.json')['remaining_pending_source_uses']==1083
    jar=T.parent/'qt-3/build/qtltools-workflow-1/normal-gradle-5/project-build/cli/omicsmatic-0.4.0.jar';assert pin(jar.read_bytes())==qualified['component']['result']['producer']
    import subprocess
    process=subprocess.run(['git','diff','--check'],cwd=T,capture_output=True);assert process.returncode==0,process.stdout+process.stderr
    inv=inventory();states=load(O/'WORKTREES-BEFORE.json');assert len(states)==63
    for n,state in enumerate(states,1):
        assert inv.snapshot(Path(state['root']))==state,state['root']
        if n%20==0:print('Prior owners unchanged',n,'/63',flush=True)
    save(O/'PRESERVATION-FINAL.json',dict(status='PASS_ALL63_PRIOR_OWNERS_EXACT',owners=63,current_owner=64,qualified_source_and_JAR_unchanged=True,canonical_manifest=manifest))
    receipts={}
    for label in ['plan-1','inspect-1','apply-1','verify-1','verify-linux-1','preview-ui-1','preview-ui-2','installed-ui-2']:
        directory=B/label
        names=['STARTED.json','PROCESS.json','stdout','stderr']
        if 'ui-' in label:names+=['SERVER-CLOSED.json','server.log','browser/COMPLETED.json','browser/desktop.png','browser/mobile.png']
        if label=='preview-ui-1':names+=['VISUAL-SCOPE.json']
        if label in ['inspect-1','apply-1','verify-1','verify-linux-1']:names+=['result/COMPLETED.json']
        for name in names:receipts[label+'/'+name]=(directory/name).read_bytes()
    for relative in ['source-refusal-inputs/INPUT-PINS.json','auxiliary-intake-1/RESULT.json','pdf-reader-dependency-1/RESULT.json','NEXT-PRIORITIES.json','CONTROLS-SEALED.json']:
        receipts[relative]=(B/relative).read_bytes()
    for name in ['LEDGER-LINEAGE.json','PRESERVATION-FINAL.json','HANDOVER-PREPEND.json']:receipts['publication/'+name]=(O/name).read_bytes()
    scripts=[path for path in (R/'build').glob('*qtltools*107.py') if path.is_file()]
    for path in scripts:receipts['orchestration/'+path.name]=path.read_bytes()
    (Q/'validation.zip').write_bytes(zipped(receipts))
    checks=dict(status='PASS_QTLTOOLS_CATALOG_INSTALLED_READBACK_AND_PUBLIC_HANDOVER',baseline=BASE,result=result,model_transaction_tests_each_host=32,actual_source_refusals_each_host=4,full_manifest=manifest,Windows_installed_verify=win,Linux_installed_verify=linux,styled_preview_and_installed_UI=True,unchanged_site_assets_served=True,initial_sparse_preview_visual_scope_unadmitted=True,private_primary_PDF_XML_images_dependencies_and_binaries_excluded=True,private_transfer_completed=False,all63_prior_owners_preserved=True,current_owner=64,ledger_lineage=ledger_lineage,qualified_scientific_source_changed=False,original_models_refit_by_catalog=False,relative_doc_links=links,validation_archive=pin((Q/'validation.zip').read_bytes()),validation_members={n:pin(raw) for n,raw in receipts.items()},whole_goal_complete=False)
    save(Q/'VALIDATION.json',checks);save(O/'VALIDATION.json',checks)
    # Enumerate every visible change in this isolated owner. Publish only the
    # bounded code/docs/catalog surfaces; all ignored private evidence stays local.
    fields=git(T,'status','--porcelain=v1','-z','--untracked-files=all').split(b'\0');files={}
    allowed=set(m.META)|{m.DATA+'/SHA256SUMS',e.PROOF,e.COMPAT,m.COVERAGE,m.GUIDE,'docs/literature/QTLTOOLS_CATALOG_CHECKPOINT_2026-11-22.md','docs/literature/HANDOVER_CURRENT.md','tools/literature/audit_qtltools_source_roles.py','tools/literature/close_qtltools_catalog.py','tools/literature/check_qtltools_catalog_ui.cjs'}
    prefixes=['tools/literature/qtltools_catalog/',p.FOLDER+'/',e.FOLDER+'/',e.CONTROLS+'/']
    for field in fields:
        if not field:continue
        assert field[:2] in [b' M',b'??'],field
        name=field[3:].decode();assert name in allowed or any(name.startswith(prefix) for prefix in prefixes),name
        assert not name.endswith(('.pdf','.bam','.vcf','.xml','.whl','.exe','.jar','.class','.pyc')) and '__pycache__' not in name,name
        files[name]=pin((T/name).read_bytes())
    assert not any(name.startswith(('src/','.github/','build/')) for name in files)
    save(O/'PUBLICATION-FILES.json',dict(sorted(files.items())));(O/'PUBLICATION-PATHS.nul').write_bytes(b'\0'.join(n.encode() for n in sorted(files))+b'\0')
    print('PASS:publication ready;',len(files),'explicit source/catalog/doc/evidence files;all63 prior owners preserved;146 families/1639 reviewed/1083 pending;goal unfinished',flush=True)
