# Warnings and required actions

Use the exact permitted CRAN 1.12.2 archive and a working original bigsnpr 1.12.2 R environment; alternatively retain these supplied references for offline Java tests. Install only where permitted. Missing/forbidden reference prerequisites require SKIP3; no dependent regeneration is accepted. Other failures require FAIL2, retained consoles and NEW output paths. Native analysis does not require R. This does not qualify LDpred2-auto or the complete paper workflows.
