from pathlib import Path
R=Path('D:/projects/JLinAlg');s=(R/'build/test_gsea_catalog_owner_20261120.py').read_text();s=s.replace('owner-controls-1','owner-controls-2');exec(compile(s,str(Path(__file__)),'exec'))
