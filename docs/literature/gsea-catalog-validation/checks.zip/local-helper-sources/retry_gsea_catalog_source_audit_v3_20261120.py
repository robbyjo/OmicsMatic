from pathlib import Path
R=Path('D:/projects/JLinAlg');s=(R/'build/run_gsea_catalog_source_audit_20261120.py').read_text();s=s.replace('source-audit-1','source-audit-3');exec(compile(s,str(Path(__file__)),'exec'))
