from pathlib import Path
import concurrent.futures,hashlib,json,re,traceback,urllib.request
R=Path('D:/projects/JLinAlg');O=R/'build/gsea-p096-author-code-20261120-1';O.mkdir(exist_ok=False);record=json.loads((R/'build/gs-5/build/gsea-admission-1/author-sources-1/P096-zenodo-record.json').read_bytes())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
def fetch(item):
    name=item['key'];assert Path(name).name==name
    try:
        request=urllib.request.Request(item['links']['self'],headers={'User-Agent':'OmicsMatic-read-only-source-audit/1.0'})
        with urllib.request.urlopen(request,timeout=45) as response:
            body=response.read(1_000_001);assert len(body)<=1_000_000 and item['checksum']=='md5:'+hashlib.md5(body).hexdigest()
            (O/name).write_bytes(body);row=dict(name=name,bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),published_checksum=item['checksum'],published_MD5_verified=True,url=response.url,status=response.status,code_executed=False)
        save(O/(name+'.HTTP.json'),row)
        lines=body.decode('utf-8-sig').splitlines();hits=[]
        for i,line in enumerate(lines):
            if re.search(r'GSEA|\.rnk|logP|log2FoldChange.{0,60}padj|padj.{0,60}log2FoldChange',line,re.I):hits.append(dict(line=i+1,context=lines[max(0,i-2):min(len(lines),i+3)]))
        return dict(identity=row,hits=hits)
    except Exception as error:
        row=dict(name=name,error=repr(error),detail=traceback.format_exc());save(O/(name+'.FAILURE.json'),row);return dict(failure=row)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(fetch,record['files']))
save(O/'AUDIT.json',dict(zenodo_record=13321265,license=record['metadata']['license'],code_executed=False,results=results))
print('Author script intake',len(results),'files; failures',sum('failure' in r for r in results),flush=True)
for row in results:
    if row.get('hits'):print(json.dumps(dict(name=row['identity']['name'],hits=row['hits']),indent=2),flush=True)
