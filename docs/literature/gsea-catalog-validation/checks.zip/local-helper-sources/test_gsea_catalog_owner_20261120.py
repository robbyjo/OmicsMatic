from pathlib import Path
import concurrent.futures,json,os,subprocess,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/gs-6';O=T/'build/gsea-catalog-1/owner-controls-1';O.mkdir(exist_ok=False)
python='C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
META=['docs/literature/omics-2023-2026/'+n for n in ['papers.json','tool-inventory.json','summary.json','README.md','WARNINGS.md']]+['tools/literature/reviewed-uses.json','site/literature-review.html','site/literature-warnings.html']
with zipfile.ZipFile(O/'exact-before.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
    for n in META:z.writestr(n,subprocess.check_output(['git','--no-replace-objects','show','b89c57376177b964205aa219fe5efd378dfa6a9e:'+n],cwd=T))
modules=['gsea_catalog.test_source','gsea_catalog.test_model','gsea_catalog.test_admission']
def linux(p):return '/mnt/d/'+Path(p).relative_to(Path('D:/')).as_posix()
def task(host):
    root=O/host;root.mkdir()
    if host=='windows':
        command=[python,'-B','-m','unittest','-v',*modules];env=dict(os.environ,PYTHONPATH=str(T/'tools/literature'),OMICSMATIC_GSEA_MODEL_BEFORE=str(O/'exact-before.zip'),OMICSMATIC_GSEA_CATALOG_TEST_ROOT=str(root/'retained-tests'))
    else:
        command=['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','--exec','/usr/bin/env','PYTHONPATH='+linux(T/'tools/literature'),'OMICSMATIC_GSEA_MODEL_BEFORE='+linux(O/'exact-before.zip'),'OMICSMATIC_GSEA_CATALOG_TEST_ROOT='+linux(root/'retained-tests'),'/usr/bin/python3','-B','-m','unittest','-v',*modules];env=os.environ.copy()
    with (root/'stdout').open('xb') as stdout,(root/'stderr').open('xb') as stderr:p=subprocess.run(command,cwd=T,stdin=subprocess.DEVNULL,env=env,stdout=stdout,stderr=stderr,timeout=240)
    (root/'PROCESS.json').write_text(json.dumps(dict(command=command,exit_code=p.returncode),indent=2)+'\n',encoding='utf-8',newline='\n')
    text=(root/'stderr').read_text(errors='replace');print(host,'exit',p.returncode,text[-450:],flush=True);return host,p.returncode
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=dict(pool.map(task,['windows','linux']))
(O/'RESULTS.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8',newline='\n');assert all(v==0 for v in results.values())
(O/'COMPLETED.json').write_text(json.dumps(dict(status='PASS_GSEA_SOURCE_MODEL_TRANSACTION_CONTROLS_WINDOWS_LINUX',hosts=2,tests_per_host=28,results=results,scientific_models_run=False),indent=2)+'\n',encoding='utf-8',newline='\n')
