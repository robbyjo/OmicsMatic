from pathlib import Path
import gzip,hashlib,json,re,sys,xml.etree.ElementTree as ET
R=Path('D:/projects/JLinAlg');T=R/'build/gs-6';O=T/'build/gsea-catalog-1/expanded-census-intake-1';O.mkdir(exist_ok=False);sys.path.insert(0,str(T/'tools/literature'))
from collect_omics_review import paragraphs
papers=json.loads((T/'docs/literature/omics-2023-2026/papers.json').read_bytes());known={c['paper_id'] for c in json.loads((R/'build/gs-1/build/gsea-high-impact-1/source-census-intake-1/CANDIDATES.json').read_bytes())['candidates']}
pattern=re.compile(r'(?<![A-Za-z0-9_])(?:preranked[- ]?GSEA|GSEA|fgsea|GSEApy|GSEAPreranked|ssGSEA|gseGO|gseKEGG|gsePathway)(?![A-Za-z0-9_])|gene[- ]sets? enrichment',re.I)
identities=[];candidates=[]
for p in papers:
    with gzip.open(R/'build/literature-review/xml'/(p['pmcid']+'.xml.gz'),'rb') as f:raw=f.read(64*1024*1024+1)
    assert len(raw)<=64*1024*1024 and hashlib.sha256(raw).hexdigest()==p['xml_sha256']
    root=ET.fromstring(raw);identities.append({k:p[k] for k in ['paper_id','pmcid','doi','xml_sha256']});blocks=paragraphs(root);matches=[]
    for b in blocks:
        hits=list(pattern.finditer(b['text']))
        if hits:matches.append(dict(paragraph_index=b['paragraph_index'],section=b['section'],paragraph_sha256=hashlib.sha256(b['text'].encode()).hexdigest(),matches=[dict(literal=m.group(),start=m.start(),end=m.end()) for m in hits],text=b['text']))
    if matches:candidates.append(dict(paper_id=p['paper_id'],pmcid=p['pmcid'],doi=p['doi'],existing_observation=any(t['tool_id']=='gsea' for t in p['tools']),prior_lexical_candidate=p['paper_id'] in known,anchors=matches))
result=dict(schema_version=1,pattern=pattern.pattern,papers_scanned=250,source_identities=identities,candidates=candidates)
(O/'CANDIDATES.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
extra=[p for p in candidates if not p['prior_lexical_candidate']]
print('Expanded candidates',len(candidates),'additional',len(extra),flush=True)
for p in extra:
    print('\n'+p['paper_id']+' '+p['doi'],flush=True)
    for b in p['anchors']:print(str(b['paragraph_index'])+' '+b['section']+'\n'+b['text'],flush=True)
