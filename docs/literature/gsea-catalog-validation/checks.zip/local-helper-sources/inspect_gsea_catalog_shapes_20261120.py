from pathlib import Path
import gzip,json,re,sys,xml.etree.ElementTree as ET
R=Path('D:/projects/JLinAlg');T=R/'build/gs-6';sys.path.insert(0,str(T/'tools/literature'))
from edger_catalog.model import registry,META
from collect_omics_review import paragraphs
papers=json.loads((T/META[0]).read_bytes());inventory=json.loads((T/META[1]).read_bytes());reviews=json.loads((T/META[5]).read_bytes())
print('META',json.dumps(META));print('REGISTRY',json.dumps([r for r in registry() if r['id'] in ['gsea','fgsea','gseapy','clusterprofiler']],indent=2))
print('GSEA INVENTORY',json.dumps(next(r for r in inventory if r['id']=='gsea'),indent=2))
for pid in ['P018','P042','P096','P098','P220']:
    p=next(p for p in papers if p['paper_id']==pid);print('PAPER',pid,json.dumps({k:v for k,v in p.items() if k!='tools'},indent=2));print('USE',json.dumps([t for t in p['tools'] if t['tool_id']=='gsea'],indent=2))
print('REVIEW EXAMPLE',json.dumps(next(r for r in reviews['reviews'] if r['tool_id']=='edger'),indent=2))
original=json.loads((R/'build/gs-1/build/gsea-high-impact-1/source-census-intake-1/CANDIDATES.json').read_bytes());known={c['paper_id'] for c in original['candidates']}
pattern=re.compile(r'(?<![A-Za-z0-9_])(?:fgsea|GSEApy|GSEAPreranked|ssGSEA)(?![A-Za-z0-9_])',re.I)
extra=[]
for p in papers:
    with gzip.open(R/'build/literature-review/xml'/(p['pmcid']+'.xml.gz'),'rb') as f:raw=f.read()
    assert __import__('hashlib').sha256(raw).hexdigest()==p['xml_sha256']
    if p['paper_id'] in known:continue
    matches=[dict(index=b['paragraph_index'],section=b['section'],names=[m.group(0) for m in pattern.finditer(b['text'])],text=b['text']) for b in paragraphs(ET.fromstring(raw)) if pattern.search(b['text'])]
    if matches:extra.append(dict(paper_id=p['paper_id'],pmcid=p['pmcid'],doi=p['doi'],matches=matches))
out=T/'build/gsea-catalog-1/provider-extra-census-1';out.mkdir(exist_ok=False);(out/'CANDIDATES.json').write_text(json.dumps(extra,indent=2)+'\n',encoding='utf-8',newline='\n')
print('EXTRA PROVIDER CANDIDATES',json.dumps([dict(paper_id=p['paper_id'],matches=[{k:v for k,v in b.items() if k!='text'} for b in p['matches']]) for p in extra],indent=2))
