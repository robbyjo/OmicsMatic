from pathlib import Path
import hashlib,importlib.util,json,re,sys,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/gs-6';B=T/'build/gsea-catalog-1/owner-controls-2';Q=T/'docs/literature/gsea-catalog-controls';Q.mkdir(exist_ok=False);sys.path.insert(0,str(T/'tools/literature'))
from gsea_catalog import evidence as e
def pin(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def enc(v):return (json.dumps(v,indent=2)+'\n').encode()
assert json.loads((B/'COMPLETED.json').read_bytes())['status']=='PASS_GSEA_SOURCE_MODEL_TRANSACTION_CONTROLS_WINDOWS_LINUX'
files={};results={}
for host in ['windows','linux']:
    root=B/host;process=json.loads((root/'PROCESS.json').read_bytes());text=(root/'stderr').read_text();assert process['exit_code']==0 and re.search(r'Ran 28 tests in ',text) and text.rstrip().endswith('OK')
    results[host]=dict(exit_code=0,tests=28)
    for p in sorted(root.rglob('*')):
        if p.is_file() and not p.is_symlink():files[host+'/'+p.relative_to(root).as_posix()]=p.read_bytes()
for n in ['test_gsea_catalog_owner_20261120.py','retest_gsea_catalog_owner_20261120.py']:files['local-harness/'+n]=(R/'build'/n).read_bytes()
with zipfile.ZipFile(Q/'checks.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,raw in sorted(files.items()):
        i=zipfile.ZipInfo(n,(2026,11,20,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16;z.writestr(i,raw)
record=dict(schema_version=1,status='PASS_GSEA_CATALOG_SOURCE_MODEL_AND_TRANSACTION_CONTROLS_TWO_HOSTS',source_code=e.sources(),tests_per_host=28,results=results,archive=pin((Q/'checks.zip').read_bytes()),files={n:pin(raw) for n,raw in sorted(files.items())},scientific_models_executed=False,original_sources_or_hashes_refreshed=False)
(Q/'CONTROLS.json').write_bytes(enc(record));(Q/'.gitattributes').write_bytes(b'*.json -text\n*.zip -text\n')
(Q/'README.md').write_text('# GSEA catalog admission controls\n\nTwenty-eight controls pass on Windows/Linux Python. They exercise provider/edition\nattribution, ambiguous and distinct source roles, old-review and unrelated-use\npreservation, bad qualification/double-transition refusals, exact before archives,\nowned writes/rollback, concurrent-edit preservation, output limits and the ban on\nscientific-source compatibility inverses. The exact portable metadata fixture is\nchecked against the admitted predecessor; no scientific model or author script\nis executed. checks.zip retains host logs, receipts and failed-write/foreign-edit\nfixtures. CONTROLS.json binds the tested owner/source snapshots and every member.\n',encoding='utf-8',newline='\n')
result=e.qualification();assert result['admission_controls']==record
print('PASS current owner qualification: exact native global proof plus 28 controls on each of two hosts',flush=True)
