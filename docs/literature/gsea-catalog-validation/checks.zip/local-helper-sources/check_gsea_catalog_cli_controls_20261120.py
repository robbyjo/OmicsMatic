from pathlib import Path
import hashlib,json,subprocess
R=Path('D:/projects/JLinAlg');T=R/'build/gs-6';B=T/'build/gsea-catalog-1';O=B/'cli-controls-1';O.mkdir(exist_ok=False)
python='C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe';cli=T/'tools/literature/close_gsea_catalog.py';cache=R/'build/literature-review/xml';pdf=R/'build/gsea-author-followup-20261120-1/P077-EPMC-supplements/P077-supplement.pdf'
names=list(json.loads((R/'build/git-publish/20261120-gsea-global-handover-65/CANONICAL-AFTER.json').read_bytes()))+['docs/literature/omics-2023-2026/'+n for n in ['gsea-source-role-coverage.json','gsea-catalog-validation.json','gsea-catalog-shared-source-compatibility.json']]
def snapshot():return {n:dict(bytes=(T/n).stat().st_size,sha256=hashlib.sha256((T/n).read_bytes()).hexdigest(),mtime_ns=(T/n).stat().st_mtime_ns) for n in names}
before=snapshot();cases=[
 ('double-apply',['--apply','--plan-dir',str(B/'plan-1'),'--primary-cache',str(cache),'--p077-supplement',str(pdf)],2),
 ('stale-inspect',['--inspect','--plan-dir',str(B/'plan-1')],2),
 ('missing-XML',['--verify','--primary-cache',str(B/'missing-source-cache-not-created'),'--p077-supplement',str(pdf)],3),
 ('missing-exact-PDF',['--verify','--primary-cache',str(cache),'--p077-supplement',str(B/'missing-exact-PDF-not-created.pdf')],3),
 ('incomplete-source-arguments',['--verify','--primary-cache',str(cache)],2)]
rows=[]
for name,args,expected in cases:
    root=O/name;root.mkdir();out=root/'out';command=[python,'-B',str(cli),*args,'--out',str(out)]
    p=subprocess.run(command,cwd=T,stdin=subprocess.DEVNULL,capture_output=True,timeout=120);(root/'stdout').write_bytes(p.stdout);(root/'stderr').write_bytes(p.stderr)
    failure=json.loads((out/'FAILURE.json').read_bytes());assert p.returncode==expected and failure['complete_result'] is False and failure['status']==('SKIP3' if expected==3 else 'FAIL2'),name
    assert snapshot()==before,name+' changed canonical bytes/timestamps';rows.append(dict(name=name,exit_code=p.returncode,expected_exit=expected,error=failure['error'],canonical_bytes_and_timestamps_preserved=True));print('PASS CLI refusal',name,expected,flush=True)
sentinel=O/'existing-out';sentinel.mkdir();(sentinel/'sentinel').write_bytes(b'preserve');command=[python,'-B',str(cli),'--verify','--out',str(sentinel)];p=subprocess.run(command,cwd=T,capture_output=True,stdin=subprocess.DEVNULL,timeout=60)
assert p.returncode==2 and (sentinel/'sentinel').read_bytes()==b'preserve' and sorted(x.name for x in sentinel.iterdir())==['sentinel'] and snapshot()==before
rows.append(dict(name='existing-output',exit_code=2,expected_exit=2,canonical_bytes_and_timestamps_preserved=True))
(O/'COMPLETED.json').write_text(json.dumps(dict(status='PASS_SIX_GSEA_CATALOG_CLI_REFUSALS_WITH_CANONICAL_BYTES_TIMESTAMPS_PRESERVED',controls=rows,before=before,after=snapshot(),scientific_models_executed=False),indent=2)+'\n',encoding='utf-8',newline='\n')
