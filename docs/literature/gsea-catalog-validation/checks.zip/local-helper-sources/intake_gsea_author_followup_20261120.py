from pathlib import Path
import concurrent.futures,hashlib,json,traceback,urllib.error,urllib.request,zipfile
R=Path('D:/projects/JLinAlg');O=R/'build/gsea-author-followup-20261120-1';O.mkdir(exist_ok=False)
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
def fetch(label,url,maximum):
    folder=O/label;folder.mkdir(exist_ok=False)
    try:
        request=urllib.request.Request(url,headers={'User-Agent':'OmicsMatic-source-role-audit/1.0'})
        with urllib.request.urlopen(request,timeout=45) as response:
            body=response.read(maximum+1);(folder/'body').write_bytes(body)
            receipt=dict(requested_url=url,resolved_url=response.url,status=response.status,content_type=response.headers.get('Content-Type'),bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),maximum_bytes=maximum)
            save(folder/'HTTP.json',receipt);assert len(body)<=maximum,'Bounded source limit exceeded; preserve partial and do not parse'
        return label,folder,body
    except Exception as error:
        save(folder/'FAILURE.json',dict(error=repr(error),detail=traceback.format_exc(),requested_url=url));print('Source intake unavailable:',label,repr(error),flush=True);return label,folder,None
record=json.loads((R/'build/gs-5/build/gsea-admission-1/author-sources-1/P096-zenodo-record.json').read_bytes());item=next(f for f in record['files'] if f['key']=='Script_18.R')
tasks=[('P096-Script18',item['links']['self'],1_000_000),('P077-EPMC-supplements','https://www.ebi.ac.uk/europepmc/webservices/rest/PMC12807864/supplementaryFiles',64_000_000)]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(lambda args:fetch(*args),tasks))
for label,folder,body in results:
    if body is None:continue
    if label=='P096-Script18':
        assert item['checksum']=='md5:'+hashlib.md5(body).hexdigest();(folder/'Script_18.R').write_bytes(body);save(folder/'IDENTITY.json',dict(published_MD5_verified=True,published_checksum=item['checksum'],code_executed=False,license=record['metadata']['license']))
        print('P096 Script18 verified. Relevant ranking/export lines:',flush=True)
        for i,line in enumerate(body.decode('utf-8-sig').splitlines(),1):
            if any(term in line.lower() for term in ['rank','log2','gsea','padj','write.table','pvalue','infinite','inf','is.finite']):print(str(i)+': '+line,flush=True)
    else:
        import io
        if not zipfile.is_zipfile(io.BytesIO(body)):save(folder/'NOT-ZIP.json',dict(status='UNAVAILABLE_EXPECTED_SUPPLEMENT_ZIP',prefix=body[:200].decode(errors='replace')));continue
        with zipfile.ZipFile(io.BytesIO(body)) as z:
            entries=[dict(name=i.filename,bytes=i.file_size,compressed=i.compress_size) for i in z.infolist()];save(folder/'MEMBERS.json',entries)
            selected=[i for i in z.infolist() if Path(i.filename).name=='41588_2025_2397_MOESM1_ESM.pdf'];assert len(selected)==1
            i=selected[0];assert i.file_size<=40_000_000 and not i.is_dir();raw=z.read(i);assert raw.startswith(b'%PDF-');(folder/'P077-supplement.pdf').write_bytes(raw);save(folder/'PDF-IDENTITY.json',dict(member=i.filename,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()));print('P077 exact supplementary PDF saved',len(raw),'bytes',flush=True)
