from pathlib import Path
import functools,http.server,json,subprocess,threading,traceback
R=Path('D:/projects/JLinAlg');T=R/'build/gs-6';B=T/'build/gsea-catalog-1';O=B/'preview-ui-1';O.mkdir(exist_ok=False);browser=O/'browser';browser.mkdir()
assert json.loads((B/'plan-1/COMPLETED.json').read_bytes())['status']=='PASS_PREPARED_GSEA_PLAN_WITHOUT_CANONICAL_MUTATION'
cache=Path('C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/node');bundle=Path('C:/Program Files/WindowsApps/OpenAI.CodexPrimaryRuntime.v26-1119-907-0_26.1119.907.0_x64__3k8sg7r9htsxt/dependencies/node')
node=next(p/'bin/node.exe' for p in [bundle,cache] if (p/'bin/node.exe').is_file());playwright=next(p/'node_modules/playwright' for p in [bundle,cache] if (p/'node_modules/playwright').is_dir())
log=(O/'server.log').open('x',encoding='utf-8')
class Handler(http.server.SimpleHTTPRequestHandler):
    def log_message(self,format,*args):log.write(format%args+'\n');log.flush()
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(B/'plan-1/preview/site')));thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
command=[str(node),str(T/'tools/literature/check_gsea_catalog_ui.cjs'),str(playwright),str(browser),'http://127.0.0.1:'+str(server.server_port)]
try:
    with (O/'stdout').open('xb') as stdout,(O/'stderr').open('xb') as stderr:p=subprocess.run(command,cwd=T,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=240)
    (O/'PROCESS.json').write_text(json.dumps(dict(command=command,exit_code=p.returncode),indent=2)+'\n',encoding='utf-8',newline='\n')
    print((O/'stdout').read_text(errors='replace'),(O/'stderr').read_text(errors='replace')[-4500:],flush=True);assert p.returncode==0,'Inspect retained preview browser logs'
finally:server.shutdown();server.server_close();thread.join(timeout=10);log.close()
