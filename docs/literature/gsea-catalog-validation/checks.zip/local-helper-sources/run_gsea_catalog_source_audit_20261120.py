from pathlib import Path
import json,sys,traceback
R=Path('D:/projects/JLinAlg');T=R/'build/gs-6';O=T/'build/gsea-catalog-1/source-audit-1';O.mkdir(exist_ok=False);sys.path.insert(0,str(T/'tools/literature'))
from gsea_catalog.primary import audit,encoded
try:
    result=audit(R/'build/literature-review/xml',R/'build/gsea-author-followup-20261120-1/P077-EPMC-supplements/P077-supplement.pdf')
    path=T/'docs/literature/gsea-catalog-sources/CENSUS.json'
    with path.open('xb') as f:f.write(encoded(result))
    (O/'COMPLETED.json').write_bytes(encoded(dict(status=result['status'],primary_sources=result['papers_scanned'],roles=result['positive_roles'],proposed_additions=result['proposed_additions'],canonical_metadata_modified=False)))
    print('PASS',result['status'],flush=True)
except Exception as error:(O/'FAILURE.json').write_bytes(encoded(dict(error=repr(error),detail=traceback.format_exc())));raise
