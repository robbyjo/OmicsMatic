from pathlib import Path
import hashlib,json,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/gs-6';B=T/'build/gsea-catalog-1';Q=T/'docs/literature/gsea-catalog-validation';Q.mkdir(exist_ok=False)
def pin(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def enc(v):return (json.dumps(v,indent=2)+'\n').encode()
identity={}
for p in sorted((B/'plan-1/preview').rglob('*')):
    if p.is_file():
        n=p.relative_to(B/'plan-1/preview').as_posix();raw=p.read_bytes();assert (T/n).read_bytes()==raw,n;identity[n]=pin(raw)
assert len(identity)==9
files={};stages={}
for stage in ['plan-1','inspect-1','apply-1','fresh-verify-1']:
    raw=(B/stage/'COMPLETED.json').read_bytes();stages[stage]=json.loads(raw);files['stages/'+stage+'/COMPLETED.json']=raw
assert stages['apply-1']['current_manifest']['entries']==stages['fresh-verify-1']['current_manifest']['entries']==826
assert stages['fresh-verify-1']['result']['integrations']==140 and stages['fresh-verify-1']['fresh_source_audit_performed']
cli=json.loads((B/'cli-controls-1/COMPLETED.json').read_bytes());assert len(cli['controls'])==6 and all(r['exit_code']==r['expected_exit'] and r['canonical_bytes_and_timestamps_preserved'] for r in cli['controls'])
for p in sorted((B/'cli-controls-1').rglob('*')):
    if p.is_file():files['cli/'+p.relative_to(B/'cli-controls-1').as_posix()]=p.read_bytes()
ui=B/'preview-ui-1';uiresult=json.loads((ui/'browser/COMPLETED.json').read_bytes());assert uiresult['integrations']==140 and len(uiresult['paper_roles_checked'])==11 and not uiresult['page_errors']
for p in sorted(ui.rglob('*')):
    if p.is_file():files['ui/'+p.relative_to(ui).as_posix()]=p.read_bytes()
files['ui/APPLIED-PREVIEW-IDENTITY.json']=enc(identity)
for folder in ['source-drafts-1','source-audit-1','source-audit-2','source-audit-3']:
    for p in sorted((B/folder).rglob('*')):
        if p.is_file():files['retained-development/'+folder+'/'+p.relative_to(B/folder).as_posix()]=p.read_bytes()
for n in ['start_gsea_catalog_20261120.py','intake_gsea_author_followup_20261120.py','intake_gsea_p096_all_scripts_20261120.py','read_gsea_p077_supplement_20261120.py','render_gsea_p077_methods_20261120.py','inspect_gsea_catalog_shapes_20261120.py','inspect_gsea_expanded_census_20261120.py','prepare_gsea_catalog_sources_20261120.py','run_gsea_catalog_source_audit_20261120.py','retry_gsea_catalog_source_audit_20261120.py','retry_gsea_catalog_source_audit_v3_20261120.py','test_gsea_catalog_owner_20261120.py','retest_gsea_catalog_owner_20261120.py','package_gsea_catalog_controls_20261120.py','check_gsea_catalog_preview_ui_20261120.py','check_gsea_catalog_cli_controls_20261120.py','package_gsea_catalog_validation_20261120.py']:files['local-helper-sources/'+n]=(R/'build'/n).read_bytes()
with zipfile.ZipFile(Q/'checks.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,raw in sorted(files.items()):
        i=zipfile.ZipInfo(n,(2026,11,20,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16;z.writestr(i,raw)
record=dict(schema_version=1,status='PASS_GSEA_ADMISSION_PLAN_INSPECT_APPLY_FRESH_VERIFY_SIX_CLI_REFUSALS_AND_BYTE_EXACT_PREVIEW_UI',
    result=stages['fresh-verify-1']['result'],manifest_entries=826,unit_controls_per_host=28,unit_control_hosts=2,CLI_refusals=6,
    source_audit_papers=250,source_audit_candidates=56,source_roles_reviewed=28,old_reviews_preserved=1520,missed_observations_added=9,
    preview_byte_exact_to_applied_files=identity,desktop_mobile_visually_reviewed=True,UI_provider_roles_checked=11,
    archive=pin((Q/'checks.zip').read_bytes()),files={n:pin(raw) for n,raw in sorted(files.items())},scientific_source_changed=False,
    fresh_original_scientific_model_execution=False,original_sources_or_hashes_refreshed=False,website_published=False,whole_goal_complete=False)
(Q/'VALIDATION.json').write_bytes(enc(record));(Q/'.gitattributes').write_bytes(b'*.json -text\n*.zip -text\n')
(Q/'README.md').write_text('# Native GSEA catalog validation\n\nPlan, inspect, apply and fresh all-250 XML/PDF verification pass. All 1,520 old\nreviews and unrelated tool uses remain exact. The admitted family is native\nBroad prepared-data GSEA; alternate providers and complete author workflows\nremain unqualified. The canonical manifest has 826 clean entries.\n\nTwenty-eight current-source unit controls pass on Windows/Linux; see the\nseparate gsea-catalog-controls packet. Six actual CLI refusals preserve canonical\nbytes/timestamps: double apply, stale inspect, missing XML, missing exact PDF,\nincomplete source arguments and existing output. Desktop/mobile checks inspect\n11 provider-sensitive roles and prominent warnings; all nine preview files are\nbyte exact to the applied catalog. Screenshots were visually reviewed.\n\nchecks.zip retains stage/CLI/UI receipts, source-audit draft/failure history and\nlocal harness sources. It does not contain the full private XML/PDF caches or\nproducer JARs. No scientific model/author script was executed in these catalog\nchecks. Run close_gsea_catalog.py --verify for canonical verification; supply\nboth exact source arguments for a fresh XML/PDF audit. This packet records\nlocal validation; publication and Pages receipts are separate.\n',encoding='utf-8',newline='\n')
print('PASS packaged actual GSEA admission, six CLI refusals, byte-identical UI and retained source-audit history',flush=True)
