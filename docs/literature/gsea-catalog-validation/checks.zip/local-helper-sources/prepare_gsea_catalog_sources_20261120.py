from pathlib import Path
import hashlib,json,zipfile
import pypdf
R=Path('D:/projects/JLinAlg');T=R/'build/gs-6';Q=T/'docs/literature/gsea-catalog-sources';Q.mkdir(exist_ok=False)
def pin(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def enc(v):return (json.dumps(v,indent=2,ensure_ascii=False)+'\n').encode()
papers=json.loads((T/'docs/literature/omics-2023-2026/papers.json').read_bytes())
identities=[{k:p[k] for k in ['paper_id','pmcid','doi','xml_sha256','first_publication_date','journal']} for p in papers]
(Q/'IDENTITIES.json').write_bytes(enc(identities));(Q/'.gitattributes').write_bytes(b'*.json -text\n*.zip -text\n')
record=(R/'build/gs-5/build/gsea-admission-1/author-sources-1/P096-zenodo-record.json').read_bytes();metadata=json.loads(record);source=R/'build/gsea-p096-author-code-20261120-1'
assert metadata['id']==13321265 and metadata['metadata']['license']=={'id':'cc-by-4.0'}
members={'record.json':record,'ATTRIBUTION.txt':b'Original unmodified source scripts by Dorit Hockman, Code associated with the data analysis for Steyn et al. 2024, version v1, 14 August 2024. https://doi.org/10.5281/zenodo.13321265 . Licensed CC BY 4.0: https://creativecommons.org/licenses/by/4.0/ . Reproduced unchanged for read-only source audit; never executed by this catalog. No endorsement is implied.\n'}
for item in metadata['files']:
    name=item['key'];raw=(source/name).read_bytes();assert Path(name).name==name and item['checksum']=='md5:'+hashlib.md5(raw).hexdigest();members['scripts/'+name]=raw
assert len(members)==31
with zipfile.ZipFile(Q/'P096-author-code.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,raw in sorted(members.items()):
        i=zipfile.ZipInfo(n,(2026,11,20,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16;z.writestr(i,raw)
pdf=R/'build/gsea-author-followup-20261120-1/P077-EPMC-supplements/P077-supplement.pdf';pages=R/'build/gs-6/build/gsea-catalog-1/P077-supplement-audit-1';renders=R/'build/gs-6/build/gsea-catalog-1/P077-methods-renders-1'
aux=dict(schema_version=1,p096=dict(record_id=13321265,source_url='https://zenodo.org/records/13321265',license='CC-BY-4.0',archive=pin((Q/'P096-author-code.zip').read_bytes()),members={n:pin(raw) for n,raw in sorted(members.items())},scripts=29,code_executed=False,ranking_file_export_identified=False,script20_options={'-collapse':'No_Collapse','-norm':'meandiv','-nperm':'1000','-scoring_scheme':'classic','-rnd_seed':'timestamp','-set_max':'200','-set_min':'15'},executable_edition_unresolved=True),p077=dict(source_url='https://www.ebi.ac.uk/europepmc/webservices/rest/PMC12807864/supplementaryFiles',zip_member='41588_2025_2397_MOESM1_ESM.pdf',pdf=pin(pdf.read_bytes()),pages=57,extractor='pypdf',extractor_version=pypdf.__version__,audited_pages=[dict(page=n,text=pin((pages/('page-%03d.txt'%n)).read_bytes()),render=pin((renders/('page-%03d.png'%n)).read_bytes())) for n in [14,15]],visually_reviewed=True,no_GSEA_keywords_in_extracted_document=True,GSEA_execution_options_resolved=False,collateral_followups=[dict(tool='edgeR',page=14,functions=['edgeR::DGEList','edgeR::calcNormFactors'],role='GTEx ingestion/normalization before selected gene-set preparation',edition_unresolved=True,canonical_observation_added=False),dict(tool='voom/limma',page=14,source_literal='voom::eBayes',caution='Retain the source namespace wording; do not silently repair it or attribute fitting to edgeR.')]))
(Q/'AUXILIARY.json').write_bytes(enc(aux))
(Q/'README.md').write_text('# GSEA source audit inputs\n\nIDENTITIES.json freezes the 250 original primary-source identities and dates.\nP096-author-code.zip contains all 29 unmodified published scripts, their official\nZenodo metadata and CC BY 4.0 attribution. These scripts are read only; never\nexecute or submit them as part of catalog verification.\n\nAUXILIARY.json identifies the exact P077 supplementary PDF and visually reviewed\nPDF pages 14-15, plus P096 source options and unresolved author prerequisites.\nThe complete P077 PDF remains private and can be retrieved from the recorded\nEurope PMC supplemental-file endpoint; select the named exact member and verify\nits bytes/hash. The related MAGMA preparation does not supply GSEA options.\nPotential additional edgeR/voom roles are retained as follow-up findings, with no\ncanonical credit in this GSEA-only transition.\n',encoding='utf-8',newline='\n')
print('Prepared 250 identities, all 29 licensed author scripts and exact supplementary-source records',flush=True)
