from pathlib import Path
import hashlib,json,re,shutil,subprocess
from pypdf import PdfReader
R=Path('D:/projects/JLinAlg');PDF=R/'build/gsea-author-followup-20261120-1/P077-EPMC-supplements/P077-supplement.pdf';O=R/'build/gs-6/build/gsea-catalog-1/P077-supplement-audit-1';O.mkdir(exist_ok=False)
reader=PdfReader(PDF);hits=[]
for i,page in enumerate(reader.pages):
    text=page.extract_text();(O/('page-%03d.txt'%(i+1))).write_text(text,encoding='utf-8',newline='\n')
    matches=list(re.finditer(r'GSEA|gene[- ]set enrichment',text,re.I))
    if matches:
        excerpts=[text[max(0,m.start()-450):min(len(text),m.end()+900)] for m in matches]
        hits.append(dict(page=i+1,text_sha256=hashlib.sha256(text.encode()).hexdigest(),excerpts=excerpts));print('PDF PAGE',i+1,flush=True)
        for excerpt in excerpts[:5]:print(excerpt,flush=True)
pdftoppm=shutil.which('pdftoppm');renders=[]
for row in hits:
    i=row['page'];image=O/('page-%03d.png'%i)
    if pdftoppm:
        p=subprocess.run([pdftoppm,'-f',str(i),'-l',str(i),'-r','120','-singlefile','-png',str(PDF),str(image.with_suffix(''))],capture_output=True,timeout=90);assert p.returncode==0
    else:
        import fitz
        with fitz.open(PDF) as doc:doc[i-1].get_pixmap(matrix=fitz.Matrix(1.5,1.5)).save(image)
    renders.append(str(image))
(O/'AUDIT.json').write_text(json.dumps(dict(pdf=str(PDF),pdf_bytes=PDF.stat().st_size,pdf_sha256=hashlib.sha256(PDF.read_bytes()).hexdigest(),pages=len(reader.pages),hits=hits,renders=renders,renderer='Poppler' if pdftoppm else 'PyMuPDF',visual_review_pending=True),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Saved matching page renders',json.dumps(renders),flush=True)
