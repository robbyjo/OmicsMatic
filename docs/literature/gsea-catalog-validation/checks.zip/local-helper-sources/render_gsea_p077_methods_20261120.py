from pathlib import Path
import json,shutil,subprocess
R=Path('D:/projects/JLinAlg');PDF=R/'build/gsea-author-followup-20261120-1/P077-EPMC-supplements/P077-supplement.pdf';O=R/'build/gs-6/build/gsea-catalog-1/P077-methods-renders-1';O.mkdir(exist_ok=False)
exe=shutil.which('pdftoppm');assert exe
for page in [14,15]:
    command=[exe,'-f',str(page),'-l',str(page),'-r','120','-singlefile','-png',str(PDF),str(O/('page-%03d'%page))]
    p=subprocess.run(command,capture_output=True,timeout=90);(O/('page-%03d.stdout'%page)).write_bytes(p.stdout);(O/('page-%03d.stderr'%page)).write_bytes(p.stderr);assert p.returncode==0
print(str(O/'page-014.png'),str(O/'page-015.png'),flush=True)
