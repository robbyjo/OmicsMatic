from pathlib import Path
import hashlib,json,subprocess,time,urllib.request
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).parent
def save(name,value):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
def linux(path):
    path=Path(path).resolve();return '/mnt/'+path.as_posix()[0].lower()+path.as_posix()[2:]
base='https://repo.maven.apache.org/maven2/org/junit/platform/junit-platform-console-standalone/1.13.4/'
name='junit-platform-console-standalone-1.13.4.jar';jar=OUT/name
with urllib.request.urlopen(base+name,timeout=60) as response:raw=response.read()
with urllib.request.urlopen(base+name+'.sha512',timeout=60) as response:checksum=response.read()
assert hashlib.sha512(raw).hexdigest()==checksum.decode().strip().split()[0]
with jar.open('xb') as f:f.write(raw)
with (OUT/(name+'.sha512')).open('xb') as f:f.write(checksum)
save('DOWNLOAD.json',dict(official_url=base+name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),sha512_verified=True,version_matches_project_junit_bom='5.13.4 -> platform1.13.4',system_packages_installed=False))
app=ROOT/'build/cli/omicsmatic-0.4.0.jar';classes=ROOT/'build/classes/java/test'
command=['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/java','-Xmx512m','-jar',linux(jar),'execute','--class-path',linux(app)+':'+linux(classes),'--select-class','org.jlinalg.cli.NextflowCaptureWorkspaceTest','--reports-dir',linux(OUT/'reports'),'--details','summary','--fail-if-no-tests']
start=time.monotonic()
with (OUT/'junit.stdout').open('xb') as so,(OUT/'junit.stderr').open('xb') as se:
    result=subprocess.run(command,cwd=ROOT,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=180)
save('PROCESS.json',dict(command=command,exit_code=result.returncode,seconds=round(time.monotonic()-start,2)))
print((OUT/'junit.stdout').read_text(errors='replace')[-6000:]);print((OUT/'junit.stderr').read_text(errors='replace')[-3000:]);assert result.returncode==0
import xml.etree.ElementTree as ET
suites=[ET.fromstring(path.read_bytes()) for path in (OUT/'reports').glob('*.xml')];totals={key:sum(int(suite.attrib[key]) for suite in suites) for key in ['tests','failures','errors','skipped']}
assert totals==dict(tests=6,failures=0,errors=0,skipped=0),totals
save('COMPLETED.json',dict(status='PASS_LINUX_WORKSPACE_CONTRACTS_INCLUDING_ALL_FOUR_WINDOWS_SKIPS',tests=totals,workspace_is_real_linux_filesystem=True,Nextflow_runtime_not_required_for_these_workspace_tests=True))
print(json.dumps(dict(status='PASS_LINUX_WORKSPACE_CONTRACTS_INCLUDING_ALL_FOUR_WINDOWS_SKIPS',tests=totals)),flush=True)
