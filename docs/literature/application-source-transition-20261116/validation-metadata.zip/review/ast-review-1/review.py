from pathlib import Path
import base64,hashlib,json,subprocess
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).parent
PARENT='1a9ff82adbf53e7b36fad065a9b45b1ab1c018f6';TARGET='a97510234fa2fb992341d5d6ad9bf2741204a639'
OLD=Path('D:/projects/JLinAlg/build/git-publish/20261115-all-main-1/checkout');JDK=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot')
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def save(name,value):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
assert git('rev-parse','HEAD').decode().strip()==TARGET
changes=[line.split('\t') for line in git('diff','--name-status',PARENT,TARGET,'--','src/main/java').decode().splitlines()]
assert len(changes)==17 and sum(row[0]=='A' for row in changes)==16 and [row[1] for row in changes if row[0]=='M']==['src/main/java/org/jlinalg/cli/JLinAlgCli.java']
parser=ROOT/'tools/literature/catalog_source_transition/SourceMembers.java';classes=OUT/'parser-classes';classes.mkdir()
with (OUT/'javac.stdout').open('xb') as so,(OUT/'javac.stderr').open('xb') as se:result=subprocess.run([str(JDK/'bin/javac.exe'),'--release','21','-d',str(classes),str(parser)],stdout=so,stderr=se,check=True)
inputs=[('before','src/main/java/org/jlinalg/cli/JLinAlgCli.java',OLD/'src/main/java/org/jlinalg/cli/JLinAlgCli.java')]+[('after',name,ROOT/name) for _,name in changes]
command=[str(JDK/'bin/java.exe'),'-cp',str(classes),'SourceMembers',*[str(path) for _,_,path in inputs]]
with (OUT/'members.tsv').open('xb') as so,(OUT/'parser.stderr').open('xb') as se:result=subprocess.run(command,stdout=so,stderr=se,check=True)
lookup={path.resolve().as_uri():(label,name) for label,name,path in inputs};members={}
for line in (OUT/'members.tsv').read_text(encoding='utf-8').splitlines():
    uri,kind,key,canonical=line.split('\t');label,name=lookup[uri];key=base64.b64decode(key).decode();canonical=base64.b64decode(canonical).decode()
    member=members.setdefault((name,kind,key),{});assert label not in member;member[label]=canonical
delta=[dict(path=name,kind=kind,key=key,**values) for (name,kind,key),values in sorted(members.items()) if values.get('before')!=values.get('after')]
existing=[row for row in delta if 'before' in row and row['kind']!='COMPLETE_UNIT']
assert {(row['kind'],row['key']) for row in existing}=={('METHOD','org.jlinalg.cli/JLinAlgCli/run(String[],PrintStream,PrintStream)'),('METHOD','org.jlinalg.cli/JLinAlgCli/help()')}
patch=git('diff',PARENT,TARGET,'--','src/main/java/org/jlinalg/cli/JLinAlgCli.java').decode()
added=[line[1:].strip() for line in patch.splitlines() if line.startswith('+') and not line.startswith('+++')];removed=[line for line in patch.splitlines() if line.startswith('-') and not line.startswith('---')]
assert not removed and added==['if (arguments.length > 0 && arguments[0].equals("sambamba-tools"))','return SambambaStreamingWorkflowCli.run(Arrays.copyOfRange(arguments, 1, arguments.length), output, errorOutput);','java -jar omicsmatic-<version>.jar sambamba-tools --help']
save('JAVA-MEMBER-DELTA.json',dict(status='EXACT_JAVAC_SYNTAX_DELTA_NOT_GENERAL_SEMANTIC_EQUIVALENCE',parent=PARENT,target=TARGET,members=delta))
save('COMPLETED.json',dict(status='PASS_COMPLETE_PRODUCTION_JAVA_SYNTAX_SCOPE_REVIEW',main_files_added=16,main_files_modified=1,modified_existing_members=[dict(kind=row['kind'],key=row['key']) for row in existing],new_dispatcher_lines=added,old_dispatcher_lines_removed=0,new_native_and_original_method_credit_added=0,parser=dict(bytes=parser.stat().st_size,sha256=hashlib.sha256(parser.read_bytes()).hexdigest()),command=command))
print(json.dumps(dict(status='PASS_COMPLETE_PRODUCTION_JAVA_SYNTAX_SCOPE_REVIEW',added=16,modified=1,changed_existing_members=[row['key'] for row in existing])),flush=True)
