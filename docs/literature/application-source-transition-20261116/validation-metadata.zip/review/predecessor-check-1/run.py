from pathlib import Path
import hashlib,json,subprocess,sys,time
OUT=Path(__file__).parent
OLD=Path('D:/projects/JLinAlg/build/git-publish/20261115-all-main-1/checkout')
BASE=Path('D:/projects/JLinAlg/build/catalog-source-transition/20261115-review-1/baseline-checkout')
TARGET=OLD/'build/source-transition-v2-parent-20261116-1'
def save(name,value):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
for root,head in [(OLD,'1a9ff82adbf53e7b36fad065a9b45b1ab1c018f6'),(BASE,'357c9301be726b3b6dc2a4e92cf71ff05ed053d2')]:
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()==head
    assert not subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=root)
assert not TARGET.exists()
command=[sys.executable,'-X','utf8','-B','tools/literature/catalog_source_transition/bridge.py','--verify','--baseline-checkout',str(BASE),'--rescan-sources','--out',str(TARGET)]
start=time.monotonic()
with (OUT/'parent.stdout').open('xb') as so,(OUT/'parent.stderr').open('xb') as se:
    process=subprocess.run(command,cwd=OLD,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=3600)
save('PROCESS.json',dict(command=command,cwd=str(OLD),exit_code=process.returncode,seconds=round(time.monotonic()-start,2),output=str(TARGET)))
print((OUT/'parent.stdout').read_text(errors='replace')[-6000:]);print((OUT/'parent.stderr').read_text(errors='replace')[-3000:]);assert process.returncode==0
result=json.loads((TARGET/'COMPLETED.json').read_bytes());assert result['status']=='PASS_REVIEWED_APPLICATION_SOURCE_TRANSITION_AND_UNCHANGED_PREDECESSOR_CATALOG'
save('COMPLETED.json',dict(status='PASS_UNMODIFIED_PARENT_IN_EXACT_CLEAN_HISTORICAL_CHECKOUT',parent=result,parent_output=str(TARGET),old_sources_overlaid=False,old_verifier_or_Git_monkeypatched=False,primary_sources_rescanned=True))
print('PASS_UNMODIFIED_PARENT_IN_EXACT_CLEAN_HISTORICAL_CHECKOUT',flush=True)
