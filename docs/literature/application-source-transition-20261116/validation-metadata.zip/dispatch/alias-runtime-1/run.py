from pathlib import Path
import hashlib,json,shutil,subprocess,time
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).parent
def save(name,value):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
def pin(path):
    raw=path.read_bytes();return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def linux(path):
    path=Path(path).resolve();return '/mnt/'+path.as_posix()[0].lower()+path.as_posix()[2:]
jar=OUT/'candidate.jar';source=ROOT/'build/cli/omicsmatic-0.4.0.jar';identity=pin(source);shutil.copy2(source,jar);assert identity==pin(jar)==pin(source)
cwd=OUT/'bad-project-configuration';cwd.mkdir();(cwd/'jlinalg.yaml').write_bytes(b'schema_version: [\n')
JAVA='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe'
native=[JAVA,'-Xmx64m','-jar',jar]
prefix=['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/timeout','--signal=TERM','--kill-after=5','150','/usr/bin/env','--chdir='+linux(cwd),'/usr/bin/java','-Xmx64m','-jar',linux(jar)]
checks=[]
def run(label,command,expected):
    command=list(map(str,command));start=time.monotonic()
    with (OUT/(label+'.stdout')).open('xb') as so,(OUT/(label+'.stderr')).open('xb') as se:
        result=subprocess.run(command,cwd=cwd,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=180)
    row=dict(label=label,command=command,exit_code=result.returncode,expected_exit_code=expected,seconds=round(time.monotonic()-start,2));save(label+'.process.json',row);checks.append(row);print(json.dumps(row),flush=True)
    if result.returncode!=expected:raise RuntimeError(label+' failed; inspect retained consoles')
run('windows-bad-config-is-really-invalid',[*native,'--help'],2)
run('windows-profile-help-bypasses-config',[*native,'sambamba-tools','--help'],0)
run('linux-bad-config-is-really-invalid',[*prefix,'--help'],2)
run('linux-profile-help-bypasses-config',[*prefix,'sambamba-tools','--help'],0)
binary_base=Path('D:/projects/JLinAlg/build/git-publish/20261115-all-main-3/checkout/build/sambamba-runtime/download-validation-2')
requests={}
for edition in ['0.6.6','0.8.2']:
    request=OUT/(edition+'.properties')
    values=dict(bam=linux(ROOT/'build/sambamba-streaming/workflow-cases-2/reference/paired_quality/input.bam'),sambamba=linux(binary_base/edition/'bin/sambamba'),edition=edition,action='remove',threads='1',compression='6',hash_table_size='1024',overflow_list_size='64',sort_buffer_mb='16',io_buffer_mb='1',wall_ms='60000',address_space_mb='1024',work_mb='256',max_files='128',audit_compressed_bytes='1099511627776',audit_decoded_bytes='8796093022208',audit_records='1099511627776',audit_record_bytes='16777216',audit_header_bytes='4194304',audit_dictionary_bytes='4194304')
    request.write_bytes(('\n'.join(key+'='+value for key,value in values.items())+'\n').encode());requests[edition]=values
    run(edition+'-mark-remove-alias',[*prefix,'sambamba-tools','--request',linux(request),'--out',linux(OUT/(edition+'-analysis'))],0)
    run(edition+'-genuine-replay-alias',[*prefix,'sambamba-tools','--verify',linux(OUT/(edition+'-analysis')),'--out',linux(OUT/(edition+'-verification'))],0)
    assert (OUT/(edition+'-analysis')/'COMPLETED.properties').exists() and (OUT/(edition+'-verification')/'COMPLETED.properties').exists()
run('windows-host-skip-alias',[*native,'sambamba-tools','--request',OUT/'0.8.2.properties','--out',OUT/'windows-skipped'],3)
assert not (OUT/'windows-skipped/COMPLETED.properties').exists() and 'SKIP3' in (OUT/'windows-skipped/FAILURE.txt').read_text()
values=dict(requests['0.6.6']);values['bam']=linux(ROOT/'build/bai-audit/wide-fixtures-1/cross_bgzf_members/input.bam');request=OUT/'score-overflow.properties';request.write_bytes(('\n'.join(k+'='+v for k,v in values.items())+'\n').encode())
run('original-066-score-overflow-is-unaccepted',[*prefix,'sambamba-tools','--request',linux(request),'--out',linux(OUT/'score-overflow')],2)
assert not (OUT/'score-overflow/COMPLETED.properties').exists() and 'FAIL2' in (OUT/'score-overflow/FAILURE.txt').read_text()
assert any('Conversion positive overflow' in path.read_text(errors='replace') for path in (OUT/'score-overflow').rglob('*.stderr'))
assert identity==pin(jar)
save('COMPLETED.json',dict(status='PASS_NORMAL_ALIAS_ORIGINAL_EXECUTION_REPLAY_CONFIGURATION_ISOLATION_AND_FAILURES',candidate=identity,checks=checks,editions=['0.6.6','0.8.2'],fresh_original_phase_executions=8,existing_workflow_implementation_changed=False,no_accepted_windows_or_score_overflow_analysis=True,new_catalog_credit=0,whole_goal_complete=False))
print('PASS_NORMAL_ALIAS_ORIGINAL_EXECUTION_REPLAY_CONFIGURATION_ISOLATION_AND_FAILURES',flush=True)
