from pathlib import Path
import hashlib,json,os,shutil,subprocess,time,zipfile,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).parent
def pin(path):
    digest=hashlib.sha256();size=0
    with path.open('rb') as stream:
        for raw in iter(lambda:stream.read(1<<20),b''):digest.update(raw);size+=len(raw)
    return dict(bytes=size,sha256=digest.hexdigest())
def save(name,value):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
jar=ROOT/'build/cli/omicsmatic-0.4.0.jar';before=pin(jar);shutil.copy2(jar,OUT/'before-dispatch.jar');assert pin(OUT/'before-dispatch.jar')==before
with zipfile.ZipFile(OUT/'before-test-reports.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
    for folder in ['build/test-results/test','build/reports/tests/test']:
        for path in (ROOT/folder).rglob('*'):
            if path.is_file():z.write(path,path.relative_to(ROOT).as_posix())
sources=['src/main/java/org/jlinalg/cli/JLinAlgCli.java','src/test/java/org/jlinalg/cli/SambambaCommandTest.java','docs/literature/SAMBAMBA_TOOLS.md']
save('SOURCE-PINS.json',{name:pin(ROOT/name) for name in sources})
tests=['org.jlinalg.alignment.BamBai*Test','org.jlinalg.alignment.Sambamba*Test','org.jlinalg.expression.GeNormTest','org.jlinalg.cli.GeNormCliTest','org.jlinalg.cli.Sambamba*Test','org.jlinalg.cli.JLinAlgCliTest','org.jlinalg.cli.ProjectConfiguration*Test','org.jlinalg.cli.Nextflow*Test','org.jlinalg.cli.StudyPipelineCliTest']
command=[str(ROOT/'gradlew.bat'),':test']
for test in tests:command.extend(['--tests',test])
command.extend([':jar',':executableJar','checkWebsite','--no-daemon','--no-build-cache','--max-workers=2','--console=plain'])
env=os.environ.copy();env['JAVA_HOME']='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot';env['PATH']=env['JAVA_HOME']+'/bin;'+env['PATH'];start=time.monotonic()
with (OUT/'gradle.stdout').open('xb') as so,(OUT/'gradle.stderr').open('xb') as se:
    result=subprocess.run(command,cwd=ROOT,env=env,stdin=subprocess.DEVNULL,stdout=so,stderr=se)
save('PROCESS.json',dict(command=command,exit_code=result.returncode,seconds=round(time.monotonic()-start,2),JAVA_HOME=env['JAVA_HOME']))
print((OUT/'gradle.stdout').read_text(errors='replace')[-6000:]);print((OUT/'gradle.stderr').read_text(errors='replace')[-4000:]);assert result.returncode==0
suites=[];totals=dict(tests=0,failures=0,errors=0,skipped=0)
for path in sorted((ROOT/'build/test-results/test').glob('TEST-*.xml')):
    suite=ET.fromstring(path.read_bytes());row=dict(name=suite.attrib['name'],**{key:int(suite.attrib[key]) for key in totals});suites.append(row)
    for key in totals:totals[key]+=row[key]
assert totals['failures']==totals['errors']==0
with zipfile.ZipFile(OUT/'reports.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
    for folder in ['build/test-results/test','build/reports/tests/test']:
        for path in (ROOT/folder).rglob('*'):
            if path.is_file():z.write(path,path.relative_to(ROOT).as_posix())
with zipfile.ZipFile(OUT/'before-dispatch.jar') as old,zipfile.ZipFile(jar) as new:
    before_classes={name:hashlib.sha256(old.read(name)).hexdigest() for name in old.namelist() if name.endswith('.class')}
    current_classes={name:hashlib.sha256(new.read(name)).hexdigest() for name in new.namelist() if name.endswith('.class')}
    assert before_classes.keys()==current_classes.keys()
    changed=[name for name in before_classes if before_classes[name]!=current_classes[name]]
    assert changed==['org/jlinalg/cli/JLinAlgCli.class'],changed
save('VALIDATION.json',dict(status='PASS_NORMAL_SAMBAMBA_COMMAND_FOCUSED_INTEGRATION',tests=totals,suites=suites,before_candidate=before,candidate=pin(jar),changed_class_entries=changed,other_class_entries_identical=len(before_classes)-1,scientific_algorithms_changed=False,whole_current_tree_catalog_qualified=False))
print(json.dumps(dict(status='PASS_NORMAL_SAMBAMBA_COMMAND_FOCUSED_INTEGRATION',tests=totals,unchanged_class_entries=len(before_classes)-1)),flush=True)
