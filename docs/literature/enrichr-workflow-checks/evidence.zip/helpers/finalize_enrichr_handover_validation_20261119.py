from pathlib import Path
import subprocess,shutil,json,hashlib,xml.etree.ElementTree as ET
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');B=A/'build/enrichr-high-impact-1';P=B/'workflow-handover-validation-1';O=B/'workflow-handover-validation-2';O.mkdir(exist_ok=False)
for name in ['reports-windows21','reports-windows25']:shutil.copytree(P/name,O/name)
for name in ['junit-windows21.stdout','junit-windows21.stderr','junit-windows25.stdout','junit-windows25.stderr','normal-help.stdout','normal-help.stderr','COMPATIBILITY.json']:
 (O/name).write_bytes((P/name).read_bytes())
p=subprocess.run(['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/python3','/mnt/d/projects/JLinAlg/build/enrichr_handover_native_capture_20261119.py'],capture_output=True)
(O/'native-capture.stdout').write_bytes(p.stdout);(O/'native-capture.stderr').write_bytes(p.stderr);print(p.stdout.decode(errors='replace'),p.stderr.decode(errors='replace'),flush=True);assert p.returncode==0
tests={}
for label in ['windows21','windows25','linux21']:
 totals={k:0 for k in ['tests','failures','errors','skipped']}
 for path in (O/('reports-'+label)).glob('TEST-*.xml'):
  node=ET.parse(path).getroot()
  for k in totals:totals[k]+=int(node.get(k,'0'))
 assert totals==dict(tests=42,failures=0,errors=0,skipped=0),(label,totals)
 tests[label]=totals
def pin(path):return dict(bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
proof=json.loads((B/'workflow-gradle-validation-1/BUILD.json').read_bytes());jar=B/'workflow-gradle-2/project-build/cli/omicsmatic-0.4.0.jar'
for n,w in proof['sources'].items():assert pin(A/n)==w,n
assert pin(jar)==proof['candidate']
result=dict(status='PASS_NORMAL_STRICT_GRADLE_ENRICHR_HANDOVER_TESTS',candidate=pin(jar),sources=proof['sources'],tests=tests,strict_lint_preserved=True,compatibility=json.loads((O/'COMPATIBILITY.json').read_bytes()),normal_jar_new_live_probe=False,composed_reference_live_probes='workflow-qualification-1/COMPLETED.json',historical_source_readers_refuse_as_expected=True,native_linux_cases_archived=True,earlier_native_tmp_not_available_on_later_invocation=True,earlier_archival_attempt='workflow-handover-validation-1/FAILURE.json',earlier_jvm_test_failures=0,catalog_admitted=False,whole_goal_complete=False)
(O/'COMPLETED.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(status=result['status'],tests=tests)),flush=True)
