from pathlib import Path
import subprocess,json,hashlib,xml.etree.ElementTree as ET,sys
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');B=A/'build/enrichr-high-impact-1';O=B/'workflow-handover-validation-1';O.mkdir(exist_ok=False)
V=B/'workflow-gradle-validation-1';proof=json.loads((V/'BUILD.json').read_bytes());jar=B/'workflow-gradle-2/project-build/cli/omicsmatic-0.4.0.jar'
def pin(p): return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(name,value): (O/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
assert pin(jar)==proof['candidate']
for n,w in proof['sources'].items(): assert pin(A/n)==w,n
junit=A/'build/nfcore-atacseq121-1/linux-test-runtime-1/junit-platform-console-standalone-1.13.4.jar'
java='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe';java25='C:/Program Files/Java/jdk-25/bin/java.exe'
wsl=['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--']
def linux(p):return '/mnt/d/'+str(p).replace('\\','/').split('D:/',1)[1]
def run(label,args,expected=0):
 p=subprocess.run([str(x) for x in args],cwd=A,capture_output=True);(O/(label+'.stdout')).write_bytes(p.stdout);(O/(label+'.stderr')).write_bytes(p.stderr)
 print(label,p.returncode,flush=True)
 if p.returncode!=expected:
  save('FAILURE.json',dict(case=label,exit_code=p.returncode,expected=expected));print(p.stderr.decode(errors='replace')[-2000:]);raise RuntimeError(label)
 return p
tests={};native='/tmp/omicsmatic-enrichr-workflow-20261119-normal-handover'
for label,prefix,jpath,classpath,root,reports in [
 ('windows21',[java],junit,str(jar)+';'+str(V/'test-only'),str(O/'retained-windows21'),O/'reports-windows21'),
 ('windows25',[java25],junit,str(jar)+';'+str(V/'test-only'),str(O/'retained-windows25'),O/'reports-windows25'),
 ('linux21',wsl+['/usr/bin/java'],linux(junit),linux(jar)+':'+linux(V/'test-only'),native,linux(O/'reports-linux21'))]:
 run('junit-'+label,prefix+['-Domicsmatic.enrichr.workflow.test_root='+root,'-jar',jpath,'execute','--class-path',classpath,'--select-class','org.jlinalg.cli.EnrichrWorkflowTest','--select-class','org.jlinalg.enrichr.EnrichrClientTest','--details','summary','--disable-ansi-colors','--reports-dir',reports])
 totals={k:0 for k in ['tests','failures','errors','skipped']}
 for p in (O/('reports-'+label)).glob('TEST-*.xml'):
  node=ET.parse(p).getroot()
  for k in totals: totals[k]+=int(node.get(k,'0'))
 assert totals==dict(tests=42,failures=0,errors=0,skipped=0),(label,totals)
 tests[label]=totals
run('normal-help',[java,'-jar',jar,'enrichr-tools','--help'])
sys.path.insert(0,str(A/'tools/literature'));import enrichr_workflow_transition as transition
before=(B/'workflow-dispatch-before-1/JLinAlgCli.java').read_bytes()
compat=dict(dispatch=transition.dispatcher(before,(A/transition.DISPATCH).read_bytes()),annotations=transition.annotations(),previous_abf=transition.previous_abf(before),previous_api=transition.previous_enrichr_api())
save('COMPATIBILITY.json',compat)
for name in ['verify_coloc_abf_workflow.py','verify_enrichr_component.py']:
 p=run('historical-reader-'+name,[sys.executable,'-B',A/'tools/literature'/name,'--out',O/('historical-'+name.replace('.py',''))],2)
for label,q in [('reference',B/'workflow-qualification-1'),('normal',O)]:
 root=(q/'NATIVE-LINUX-ROOT.txt').read_text().strip() if label=='reference' else native
 run('archive-linux-'+label,wsl+['/usr/bin/python3','/mnt/d/projects/JLinAlg/build/archive_enrichr_linux_cases_20261119.py',root,linux(O/('native-linux-'+label+'.zip'))])
for n,w in proof['sources'].items(): assert pin(A/n)==w,n
assert pin(jar)==proof['candidate']
save('COMPLETED.json',dict(status='PASS_NORMAL_STRICT_GRADLE_ENRICHR_HANDOVER_TESTS',candidate=pin(jar),sources=proof['sources'],tests=tests,strict_lint_preserved=True,compatibility=compat,normal_jar_new_live_probe=False,composed_reference_live_probes='workflow-qualification-1/COMPLETED.json',historical_source_readers_refuse_as_expected=True,native_linux_test_root=native,catalog_admitted=False,whole_goal_complete=False))
print('PASS HANDOVER VALIDATION',json.dumps(tests),flush=True)
