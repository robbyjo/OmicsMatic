from pathlib import Path
import subprocess,json,hashlib,zipfile,difflib
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');B=A/'build/enrichr-high-impact-1';O=B/'workflow-build-2'
O.mkdir(exist_ok=False);classes=O/'classes';classes.mkdir()
base=A/'build/coloc-high-impact-1/susie-fixes-build-1/omicsmatic-0.4.0.jar';api=B/'component-qualification-3/omicsmatic-enrichr-component-development.jar'
junit=A/'build/nfcore-atacseq121-1/linux-test-runtime-1/junit-platform-console-standalone-1.13.4.jar';javac=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/javac.exe');java=javac.with_name('java.exe')
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
old=(B/'workflow-dispatch-before-1/JLinAlgCli.java').read_bytes();new=(A/'src/main/java/org/jlinalg/cli/JLinAlgCli.java').read_bytes()
first=b'            if (arguments.length > 0 && arguments[0].equals("gseapy-native"))\n'
second=b'              java -jar omicsmatic-<version>.jar enrichment-tools --help\n'
assert old.count(first)==old.count(second)==1
wanted=old.replace(first,b'            if (arguments.length > 0 && arguments[0].equals("enrichr-tools"))\n                return EnrichrWorkflowCli.run(Arrays.copyOfRange(arguments, 1, arguments.length), output, errorOutput);\n'+first).replace(second,b'              java -jar omicsmatic-<version>.jar enrichr-tools --help\n'+second)
assert new==wanted
changes=list(difflib.unified_diff(old.decode().splitlines(),new.decode().splitlines()))
assert len([line for line in changes if line.startswith('+') and not line.startswith('+++')])==3
assert not any(line.startswith('-') and not line.startswith('---') for line in changes)
(O/'DISPATCH-REVIEW.json').write_text(json.dumps(dict(status='PASS_EXACT_THREE_ADDITIVE_DISPATCH_AND_HELP_LINES',base_commit='383c677d81924d09c2f2f8140dfc44eab99393d5',path='src/main/java/org/jlinalg/cli/JLinAlgCli.java',before=pin(old),after=pin(new),new_command='enrichr-tools',removed_old_lines=0,added_lines=3,scientific_source_replaced=False,old_verifier_hashes_refreshed=False,whole_program_semantic_equivalence_claimed=False,diff=changes),indent=2)+'\n',encoding='utf-8')
sources=sorted((A/'src/main/java/org/jlinalg/cli').glob('EnrichrWorkflow*.java'))+[A/'src/main/java/org/jlinalg/cli/JLinAlgCli.java',A/'src/test/java/org/jlinalg/cli/EnrichrWorkflowTest.java']
def run(label,args):
 p=subprocess.run([str(x) for x in args],cwd=A,capture_output=True)
 (O/(label+'.stdout')).write_bytes(p.stdout);(O/(label+'.stderr')).write_bytes(p.stderr)
 if p.returncode:
  print(p.stdout.decode(errors='replace')[-4500:]);print(p.stderr.decode(errors='replace')[-3000:]);raise SystemExit(p.returncode)
run('compile',[javac,'--release','17','-encoding','UTF-8','-cp',str(base)+';'+str(api)+';'+str(junit),'-d',classes,*sources])
additions={}
with zipfile.ZipFile(api) as z:
 for n in z.namelist():
  if n.endswith('.class'):additions[n]=z.read(n)
for p in sorted(classes.rglob('*.class')):
 n=p.relative_to(classes).as_posix()
 if not p.name.startswith('EnrichrWorkflowTest'):additions[n]=p.read_bytes()
candidate=O/'omicsmatic-0.4.0.jar'
with zipfile.ZipFile(base) as original,zipfile.ZipFile(candidate,'x') as target:
 original_names=original.namelist();assert len(original_names)==len(set(original_names))
 for entry in original.infolist():
  raw=additions.pop(entry.filename,None)
  target.writestr(entry,original.read(entry.filename) if raw is None else raw)
 for n,raw in sorted(additions.items()):target.writestr(n,raw,compress_type=zipfile.ZIP_DEFLATED)
with zipfile.ZipFile(base) as original,zipfile.ZipFile(candidate) as target:
 existing=set(original.namelist());all_names=set(target.namelist());changed=[]
 for n in sorted(existing):
  if original.read(n)!=target.read(n):changed.append(n)
 assert changed==['org/jlinalg/cli/JLinAlgCli.class'],changed
 added=sorted(all_names-existing);assert all(n.startswith(('org/jlinalg/enrichr/','org/jlinalg/cli/EnrichrWorkflow')) and n.endswith('.class') for n in added)
 assert target.testzip() is None
 with zipfile.ZipFile(api) as current_api:
  for n in current_api.namelist():
   if n.endswith('.class'):assert current_api.read(n)==target.read(n),n
 preserved=len(existing)-1
testonly=O/'test-only/org/jlinalg/cli';testonly.mkdir(parents=True)
for p in (classes/'org/jlinalg/cli').glob('EnrichrWorkflowTest*.class'):(testonly/p.name).write_bytes(p.read_bytes())
run('packaged-junit-windows21',[java,'-Domicsmatic.enrichr.workflow.test_root='+str(O/'retained-windows21'),'-jar',junit,'execute','--class-path',str(candidate)+';'+str(O/'test-only'),'--select-class','org.jlinalg.cli.EnrichrWorkflowTest','--details','summary','--disable-ansi-colors','--reports-dir',O/'reports-windows21'])
run('packaged-main-help',[java,'-jar',candidate,'enrichr-tools','--help'])
(O/'COMPLETED.json').write_text(json.dumps(dict(status='PASS_ENRICHR_CANDIDATE_BUILD_AND_PACKAGED_WINDOWS_TESTS',candidate=pin(candidate.read_bytes()),parent=pin(base.read_bytes()),frozen_api=pin(api.read_bytes()),sources={p.relative_to(A).as_posix():pin(p.read_bytes()) for p in sources},changed_existing_entries=changed,preserved_existing_entries=preserved,new_class_entries=added,old_api_class_payloads_preserved=True,new_family_credit=0,whole_goal_complete=False),indent=2)+'\n',encoding='utf-8')
print((O/'packaged-junit-windows21.stdout').read_text(),flush=True)
print(json.dumps(dict(status='PASS candidate',candidate=pin(candidate.read_bytes()),preserved_entries=preserved,new_class_entries=len(added))),flush=True)
