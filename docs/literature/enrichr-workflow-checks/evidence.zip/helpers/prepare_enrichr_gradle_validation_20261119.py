from pathlib import Path
import json,hashlib,zipfile,subprocess,shutil
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');B=A/'build/enrichr-high-impact-1';O=B/'workflow-gradle-validation-1';O.mkdir(exist_ok=False)
jar=B/'workflow-gradle-2/project-build/cli/omicsmatic-0.4.0.jar';assert jar.is_file()
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
testonly=O/'test-only'
for p in (B/'workflow-build-2/test-only').rglob('*.class'):
 target=testonly/p.relative_to(B/'workflow-build-2/test-only');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
for p in (B/'component-build-3/classes/org/jlinalg/enrichr').glob('EnrichrClientTest*.class'):
 target=testonly/'org/jlinalg/enrichr'/p.name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
fixture=testonly/'org/jlinalg/enrichr/api-reference-20261119.zip';fixture.write_bytes((A/'src/test/resources/org/jlinalg/enrichr/api-reference-20261119.zip').read_bytes())
with zipfile.ZipFile(jar) as z:
 for p in (B/'workflow-build-2/classes').rglob('*.class'):
  if not p.name.startswith('EnrichrWorkflowTest'):assert p.relative_to(B/'workflow-build-2/classes').as_posix() in z.namelist()
sources=sorted((A/'src/main/java/org/jlinalg/cli').glob('EnrichrWorkflow*.java'))+[A/'src/main/java/org/jlinalg/cli/JLinAlgCli.java',A/'src/main/java/org/jlinalg/cli/ColocAbfFiles.java',*sorted((A/'src/main/java/org/jlinalg/enrichr').glob('*.java')),A/'src/test/java/org/jlinalg/cli/EnrichrWorkflowTest.java',A/'src/test/java/org/jlinalg/enrichr/EnrichrClientTest.java']
(O/'BUILD.json').write_text(json.dumps(dict(status='NORMAL_STRICT_GRADLE_EXECUTABLE_BUILD_PREPARED',candidate=pin(jar),sources={p.relative_to(A).as_posix():pin(p) for p in sources},build_log='../workflow-gradle-2/gradle.stdout',strict_lint_preserved=True,isolated_test_only_classpath=str(testonly)),indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(candidate=pin(jar),source_files=len(sources))),flush=True)
