from pathlib import Path
import subprocess,zipfile,json,hashlib
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');B=A/'build/enrichr-high-impact-1';O=B/'workflow-serial-identity-1';O.mkdir(exist_ok=False)
classes=O/'classes';classes.mkdir();base=A/'build/coloc-high-impact-1/susie-fixes-build-1/omicsmatic-0.4.0.jar';api=B/'component-qualification-3/omicsmatic-enrichr-component-development.jar'
sources=[A/'src/main/java/org/jlinalg/cli/ColocAbfFiles.java',*sorted((A/'src/main/java/org/jlinalg/enrichr').glob('*.java'))]
javac=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/javac.exe')
p=subprocess.run([str(x) for x in [javac,'--release','17','-encoding','UTF-8','-Xlint:all','-Werror','-cp',str(base)+';'+str(api),'-d',classes,*sources]],cwd=A,capture_output=True)
(O/'compile.stdout').write_bytes(p.stdout);(O/'compile.stderr').write_bytes(p.stderr);assert p.returncode==0,(p.returncode,p.stderr.decode(errors='replace'))
checked={}
with zipfile.ZipFile(base) as old,zipfile.ZipFile(api) as a:
 for file in sorted(classes.rglob('*.class')):
  n=file.relative_to(classes).as_posix();raw=file.read_bytes();expected=a.read(n) if n.startswith('org/jlinalg/enrichr/') else old.read(n)
  assert raw==expected,n
  checked[n]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
(O/'COMPLETED.json').write_text(json.dumps(dict(status='PASS_SOURCE_ONLY_SERIAL_ANNOTATIONS_IDENTICAL_CLASS_PAYLOADS',class_payloads=checked,strict_lint_compilation=True,scientific_bytecode_changed=False,old_fingerprints_refreshed=False),indent=2)+'\n',encoding='utf-8')
print('PASS strict lint and',len(checked),'identical old class payloads',flush=True)
