from pathlib import Path
import subprocess,os,json,hashlib,urllib.request
R=Path('D:/projects/JLinAlg');A=R/'build/high-impact-stats-1';B=A/'build/enrichr-high-impact-1';O=B/'workflow-gradle-1'
O.mkdir(exist_ok=False);dest=O/'project-build';dest.mkdir()
init=O/'isolated-build.gradle'
init.write_text("gradle.beforeProject { p -> p.layout.buildDirectory.set(new File('"+dest.as_posix()+"')) }\n",encoding='utf-8')
jdist=dest/'dependencies/jdistlib-all-0.10.2.jar';jdist.parent.mkdir()
wanted='8b50aaa11d2cbd512525e0d74f8e609f40db9f4fc179ccb7a885a82257e0ac81'
old_candidates=[A/'build/dependencies/jdistlib-all-0.10.2.jar',R/'build/dependencies/jdistlib-all-0.10.2.jar']
for p in old_candidates:
 if p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==wanted:
  jdist.write_bytes(p.read_bytes());break
if not jdist.is_file():
 url='https://github.com/robbyjo/JDistlib/releases/download/v0.10.2/jdistlib-all-0.10.2.jar'
 req=urllib.request.Request(url,headers={'User-Agent':'OmicsMatic-pinned-build-dependency'})
 with urllib.request.urlopen(req,timeout=60) as stream:raw=stream.read(100000001)
 downloaded=O/'downloaded-jdistlib-0.10.2.jar';downloaded.write_bytes(raw)
 assert len(raw)<=100000000 and hashlib.sha256(raw).hexdigest()==wanted,'Retained dependency failed its pinned identity'
 jdist.write_bytes(raw)
gradle=next(Path('C:/Users/User/.gradle/wrapper/dists').glob('gradle-9.7.1-bin/*/gradle-9.7.1/bin/gradle.bat'))
command=[str(gradle),'--no-daemon','--console=plain','--max-workers=2','--offline','--project-cache-dir',str(O/'project-cache'),'--init-script',str(init),'executableJar']
env=dict(os.environ,JAVA_HOME='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot')
(O/'COMMAND.json').write_text(json.dumps(dict(command=command,cwd=str(A),java_home=env['JAVA_HOME'],isolated_build_directory=str(dest),dependency_sha256=wanted),indent=2)+'\n',encoding='utf-8')
with (O/'gradle.stdout').open('xb') as out,(O/'gradle.stderr').open('xb') as err:
 p=subprocess.Popen(command,cwd=A,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err)
 (O/'PROCESS.json').write_text(json.dumps(dict(pid=p.pid,command=command),indent=2)+'\n',encoding='utf-8')
 code=p.wait()
(O/'PROCESS-EXIT.json').write_text(json.dumps(dict(exit_code=code),indent=2)+'\n',encoding='utf-8')
print((O/'gradle.stdout').read_text(errors='replace')[-4500:]);print((O/'gradle.stderr').read_text(errors='replace')[-5500:]);print('GRADLE_EXIT',code,flush=True)
raise SystemExit(code)
