from pathlib import Path
p=Path('D:/projects/JLinAlg/build/gradle_enrichr_workflow_20261119.py');code=p.read_text().replace('workflow-gradle-1','workflow-gradle-2')
exec(compile(code,str(p)+'-V2','exec'))
