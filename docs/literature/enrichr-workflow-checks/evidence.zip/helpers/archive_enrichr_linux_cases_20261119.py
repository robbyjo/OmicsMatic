from pathlib import Path
import os,sys,json,hashlib,zipfile
root=Path(sys.argv[1]).resolve();out=Path(sys.argv[2])
assert str(root).startswith('/tmp/omicsmatic-enrichr-workflow-20261119-') and root.is_dir()
assert not out.exists()
files={};links=[];total=0
with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for parent,dirs,names in os.walk(root,followlinks=False):
  for name in list(dirs)+names:
   path=Path(parent)/name;relative=path.relative_to(root).as_posix()
   if path.is_symlink():links.append(dict(path=relative,target=os.readlink(path)));continue
   if not path.is_file():continue
   raw=path.read_bytes();total+=len(raw);assert total<=100_000_000 and len(files)<20000
   files[relative]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
   info=zipfile.ZipInfo('cases/'+relative,date_time=(2026,11,19,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,raw)
 z.writestr('TOPOLOGY.json',(json.dumps(dict(source_root=str(root),symlinks=links,symlinks_restored=False,regular_files=files),indent=2)+'\n').encode())
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 for name,wanted in files.items():
  raw=z.read('cases/'+name);assert dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())==wanted
print(json.dumps(dict(status='PASS_NATIVE_LINUX_TEST_CASE_ARCHIVE',source_root=str(root),files=len(files),symlinks=len(links),uncompressed_bytes=total,archive=dict(bytes=out.stat().st_size,sha256=hashlib.sha256(out.read_bytes()).hexdigest()))))
