from pathlib import Path
import subprocess,sys,uuid,runpy,json
A=Path('/mnt/d/projects/JLinAlg/build/high-impact-stats-1');B=A/'build/enrichr-high-impact-1';O=B/'workflow-handover-validation-2'
root='/tmp/omicsmatic-enrichr-workflow-20261119-'+uuid.uuid4().hex
args=['/usr/bin/java','-Domicsmatic.enrichr.workflow.test_root='+root,'-jar',str(A/'build/nfcore-atacseq121-1/linux-test-runtime-1/junit-platform-console-standalone-1.13.4.jar'),'execute','--class-path',str(B/'workflow-gradle-2/project-build/cli/omicsmatic-0.4.0.jar')+':'+str(B/'workflow-gradle-validation-1/test-only'),'--select-class','org.jlinalg.cli.EnrichrWorkflowTest','--select-class','org.jlinalg.enrichr.EnrichrClientTest','--details','summary','--disable-ansi-colors','--reports-dir',str(O/'reports-linux21')]
p=subprocess.run(args,cwd=A,capture_output=True);(O/'junit-linux21.stdout').write_bytes(p.stdout);(O/'junit-linux21.stderr').write_bytes(p.stderr);assert p.returncode==0,p.stderr
sys.argv=['archive',root,str(O/'native-linux-normal.zip')]
runpy.run_path('/mnt/d/projects/JLinAlg/build/archive_enrichr_linux_cases_20261119.py',run_name='__main__')
(O/'NATIVE-LINUX-ROOT.txt').write_text(root+'\n');print('PASS linux test and archive in one process',flush=True)
