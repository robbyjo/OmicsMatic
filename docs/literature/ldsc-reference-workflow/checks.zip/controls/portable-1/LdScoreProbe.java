package org.jlinalg.genetics;
import java.nio.file.*;import java.util.*;import java.nio.charset.StandardCharsets;
public final class LdScoreProbe {
 public static void main(String[] args)throws Exception {
  var test=new LdscLdScoresTest();test.temp=Path.of(args[0]);Files.createDirectory(test.temp);Path dest=Path.of(args[1]);Files.createDirectory(dest);
  for(var model:test.models(LdscLdScoresTest.fixtures())){var result=model.compute();var flat=new TreeMap<String,Object>();LdscLdScoresTest.flatten("",result,flat);var rows=new StringBuilder("field\tvalue\n");for(var e:flat.entrySet())rows.append(e.getKey()).append('\t').append(e.getValue()==null?"NA":e.getValue()).append('\n');Files.writeString(dest.resolve(model.id()+".tsv"),rows.toString(),StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW);}
 }
}
