import runpy,sys,types
from pathlib import Path
p=Path(sys.argv[1]);args=sys.argv[2:];package=types.ModuleType('ldscore');package.__path__=[str(p/'ldscore')];sys.modules['ldscore']=package;sys.argv=[str(p/'ldsc.py'),*args];runpy.run_path(str(p/'ldsc.py'),run_name='__main__')
