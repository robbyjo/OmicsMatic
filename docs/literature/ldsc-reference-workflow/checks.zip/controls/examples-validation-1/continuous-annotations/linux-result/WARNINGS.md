# Reference LD scores: scope and required actions

Native Java reference LD scores from a declared diploid hard-call BED/BIM/FAM population, one selected chromosome, explicit FID/IID selection, reference-table order, annotation mode, coordinate units, source chunk size and strict MAF threshold. Selected CBIIT 3.0.2 source-chunked estimator; negative unbiased r2 contributions/scores and source MAF boundary/fallback behavior are retained. No ancestry, unrelatedness, assembly, map interpolation, allele/identifier repair, annotation construction, GWAS munging, liability conversion or whole-paper reproduction is inferred. Analysis needs the complete current source-build JAR and Java 17+, with no Python/R/bitarray runtime or installation.

**REQUIRED ACTIONS:** Require exit 0, COMPLETED.json and analysis.json result_admitted=true. SKIP3 means dependent analysis skipped: supply the named permitted input or complete current runtime, or choose a separately qualified method/scope. FAIL2 means no complete result admitted: retain exact inputs, partials and the failed attempt; read FAILURE.txt/WARNINGS.md, correct the named input, population, map, model, numerical, storage/heap or capacity issue and retry NEW output. Do not repair IDs, round dosages/continuous annotations, force positive scores, replace missing diagnostics or drop failed SNPs/samples/pairs to obtain success. A preflight/filtering record is not the requested completed LD-score analysis. Review source chunk expansion, count populations and every observed warning before interpretation.

The preflight pass establishes the selected/filtered population before requested pair accumulation. Only a final checked completion admits the requested preparation. Full/common counts and overlaps describe distinct reference populations. No later trait model or outer testing family is inferred.

## Observed source/model warnings

Reference hard calls use observed-mean imputation, population-SD normalization and unbiased r2 with the complete declared sample N. Negative contributions/scores are retained, not clipped. Filtering uses strict MAF>threshold and excludes all-heterozygous/missing variants, with every decision retained.

MAF and strict MAF>.05 counts follow the stored second-allele coding, including floating-point boundary behavior. Reference/sample ancestry, unrelatedness, map/annotation identity and genome assembly remain caller declarations. Genotype fingerprints are integrity checks, not authenticity signatures.

Selected upstream chunk semantics include 143 pairs beyond the nominal window. Chunk size is part of this estimator; it is not silently replaced by an exact-distance graph.

Selected source rounded the initial clique beyond the variant count and reset effective chunk size to 1 with the entire retained population as its initial clique. This source fallback is retained explicitly.

Continuous/signed annotations are retained. Binary overlap matrices are absent; annotation counts/sums must be interpreted under the declared annotation model.

Print selection affects score rows only. Counts, overlaps and contributions still describe the complete retained reference; inspect print-selection.tsv.
