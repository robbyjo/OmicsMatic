from pathlib import Path
import json,hashlib,zipfile,subprocess,traceback,re
r=Path(__file__).resolve().parents[2];b=Path(__file__).resolve().parent;out=b/'closure-1';out.mkdir();public=r/'docs/literature/ldsc-reference-workflow'
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def filepin(p):
 with p.open('rb') as f:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
def read(p):return json.loads(p.read_bytes())
def save(p,v):p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
try:
 native=read(b/'build-2/COMPLETED.json');portable=read(b/'portable-1/COMPLETED.json');main=read(b/'main-controls-1/COMPLETED.json');late=read(b/'late-controls-1/COMPLETED.json');examples=read(b/'examples-validation-1/COMPLETED.json');original=read(b/'original-followup-1/COMPLETED.json')
 assert native['junit']==dict(tests=20,errors=0,failures=0,skipped=0);assert portable['junit']['windows']==portable['junit']['linux']==native['junit'];assert portable['byte_identical_complete_model_payloads']==37 and portable['old_numerics_and_graphs_unchanged'];assert main['successful_main_processes']==14 and main['total_byte_identical_payloads']==182;assert len(main['negative_main_processes'])==7 and len(late['cases'])==4 and examples['actual_main_processes']==6;assert len(original['successful_full_cli_cases'])==5 and len(original['full_cli_failed_cases'])==2
 for n,v in portable['source_guards'].items():assert filepin(r/n)==v,n
 artifact=b/'build-2/jar/omicsmatic-0.4.0.jar';assert filepin(artifact)==portable['artifact']==main['artifact']
 source=r/'build/ldsc-high-impact-1/upstream-1/cbiit';runtime=r/'build/ldsc-scores-1/reference-runtime-1/python'
 for n,v in read(b/'original-controls-1/SOURCE-GUARDS.json').items():assert filepin(source/n)==v,n
 installed=read(b/'original-controls-1/RUNTIME-GUARDS.json');assert len(installed)==4441
 for n,v in installed.items():assert filepin(runtime/n)==v,n
 old=read(r/'docs/literature/ldsc-scores-development/VALIDATION.json');oldarchive=r/'docs/literature/ldsc-scores-development/checks.zip';assert filepin(oldarchive)==old['archive']
 changed=['src/main/java/org/jlinalg/genetics/LdscLdScores.java','src/test/java/org/jlinalg/genetics/LdscLdScoresTest.java'];historical={}
 for n,v in old['source_guards'].items():
  raw=subprocess.check_output(['git','--no-replace-objects','show','a39ac83c4720be26cf94a06f0e069770af7d3ff9:'+n],cwd=r);assert pin(raw)==v,n
  if n in changed:historical['historical-source/'+n]=raw
  else:assert filepin(r/n)==v,n
 names=set(portable['source_guards'])|{'build.gradle','src/main/java/org/jlinalg/genetics/PlinkBedDataset.java','src/main/java/org/jlinalg/cli/LdscToolsCli.java','src/main/java/org/jlinalg/cli/NextflowFiles.java','src/main/java/org/jlinalg/cli/NextflowJson.java','src/main/java/org/jlinalg/cli/NextflowParameters.java','docs/vignettes/ldsc-reference-preparation.md','tools/literature/ldsc_reference/verify.py','docs/literature/ldsc-reference-workflow/README.md','docs/literature/ldsc-reference-workflow/WARNINGS.md','docs/literature/ldsc-reference-workflow/.gitattributes','docs/literature/ldsc-scores-development/VALIDATION.json','docs/literature/ldsc-stratified-workflow/VALIDATION.json'}
 for folder in ['examples/ldsc-reference','src/test/resources/org/jlinalg/genetics/ldsc-scores']:names.update(p.relative_to(r).as_posix() for p in (r/folder).rglob('*') if p.is_file())
 guards={n:filepin(r/n) for n in sorted(names)};payload={**historical}
 for n in names:payload['current-source/'+n]=(r/n).read_bytes()
 folders=['build-1','build-2','test-1','portable-1','original-controls-1','original-followup-1','main-controls-1','late-controls-1','examples-validation-1']
 for folder in folders:
  for p in (b/folder).rglob('*'):
   if not p.is_file():continue
   rel=p.relative_to(b).as_posix()
   if p.suffix=='.jar' and rel!='main-controls-1/missing-backend.jar':continue
   if p.suffix=='.class' and rel!='late-controls-1/runtime-code/runtime/org/jlinalg/genetics/LdscLdScores.class':continue
   if '/runtime/' in rel and rel!='late-controls-1/runtime-code/runtime/org/jlinalg/genetics/LdscLdScores.class':continue
   if '/binary/' in rel or '/test-report/' in rel:continue
   payload['controls/'+rel]=p.read_bytes()
 for p in b.glob('*.py'):payload['controllers/'+p.name]=p.read_bytes()
 for name in ['ORIGINAL-DRAFT.java','LdscReferenceCliTest.java','INITIAL-FIXES.json']:payload['development/'+name]=(b/name).read_bytes()
 index={n:pin(raw) for n,raw in sorted(payload.items())};archive=public/'checks.zip'
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for n,raw in sorted(payload.items()):z.writestr(n,raw)
  z.writestr('ENTRY-MANIFEST.json',json.dumps(dict(payloads=index),indent=2)+'\n')
 with zipfile.ZipFile(archive) as z:
  assert set(z.namelist())==set(index)|{'ENTRY-MANIFEST.json'}
  for n,v in index.items():assert pin(z.read(n))==v,n
 result=dict(status='PASS_NATIVE_REFERENCE_LDSCORE_WORKFLOW',profile='native-ldsc-reference-preparation-cbiit302-v1',original_models_each_boundary=37,reference_fields_each_boundary=75226,windows_junit=native['junit'],linux_same_junit=portable['junit']['linux'],actual_native_main_counts=dict(total=31,success=20,skip3=4,fail2=7),byte_identical_api_payloads=37,byte_identical_workflow_payloads=182,additional_example_byte_identical_payloads=sum(c['byte_identical_payloads'] for c in examples['examples']),successful_original_cli_cases=5,retained_failed_original_cli_cases=2,source_package='CBIIT 3.0.2',source_root_cli_banner_version='3.0.1',original_source_commit='6c673952cee74bd5c57aef1555a03b1c015399a0',original_runtime_files_unchanged=4441,upstream_comparisons=main['unchanged_original_cli_comparisons'],upstream_subset_failure=original['required_action'],historical_source_commit='a39ac83c4720be26cf94a06f0e069770af7d3ff9',historical_changed_sources=changed,historical_api_archive=old['archive'],historical_fingerprints_refreshed=False,only_expected_old_diagnostic_change=portable['only_expected_old_diagnostic_change'],source_guards=guards,artifact=portable['artifact'],indexed_payloads=len(index),archive=filepin(archive),all_archive_payloads_read_back=True,new_family_credit=0,new_integrations=128,native_integrations=24,upstream_integrations=104,whole_tool_qualified=False,whole_goal_complete=False,website_deployed=False,released=False)
 save(public/'VALIDATION.json',result);save(out/'COMPLETED.json',dict(status=result['status'],archive=result['archive'],indexed_payloads=len(index),source_guards=guards));print(json.dumps(dict(status=result['status'],archive=result['archive'],payloads=len(index)),indent=2),flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),detail=traceback.format_exc()));raise
