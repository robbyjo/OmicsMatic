from pathlib import Path
import subprocess,json,hashlib,shutil,time
r=Path(__file__).resolve().parents[2];b=Path(__file__).resolve().parent;out=b/'examples-validation-1';out.mkdir();jar=b/'build-2/jar/omicsmatic-0.4.0.jar';java='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe'
def save(p,v):p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
def pin(p):
 with p.open('rb') as f:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
def linux(p):p=p.resolve();return '/mnt/'+p.drive[0].lower()+'/'+p.as_posix()[3:]
results=[]
for name in ['unpartitioned-snps','binary-annotations','continuous-annotations']:
 original=r/'examples/ldsc-reference'/name;pins={p.name:pin(p) for p in original.iterdir() if p.is_file()};case=out/name;shutil.copytree(original,case)
 for platform in ['windows','linux']:
  cmd=[java,'-cp',str(jar),'org.jlinalg.cli.LdscReferenceCli','--request',str(case/'request.json')] if platform=='windows' else ['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','java','-cp',linux(jar),'org.jlinalg.cli.LdscReferenceCli','--request',linux(case/'request.json')];save(case/(platform+'-command.json'),cmd);start=time.monotonic()
  with (case/(platform+'.stdout')).open('xb') as so,(case/(platform+'.stderr')).open('xb') as se:p=subprocess.run(cmd,cwd=r,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=300)
  save(case/(platform+'-PROCESS.json'),dict(exit_code=p.returncode,seconds=time.monotonic()-start));assert p.returncode==0,(name,platform);dest=case/'result';manifest=json.loads((dest/'manifest.json').read_bytes());complete=json.loads((dest/'COMPLETED.json').read_bytes());assert complete['manifest']==pin(dest/'manifest.json');assert json.loads((dest/'analysis.json').read_bytes())['result_admitted'] is True
  for n,v in manifest.items():assert pin(dest/n)==v,n
  assert dest.resolve().is_relative_to(out.resolve());dest.rename(case/(platform+'-result'));print('PASS_PUBLIC_EXAMPLE',name,platform,flush=True)
 left=case/'windows-result';right=case/'linux-result';payload=[p.relative_to(left) for p in left.rglob('*') if p.is_file()]
 for n in payload:assert (left/n).read_bytes()==(right/n).read_bytes(),(name,n)
 assert pins=={p.name:pin(p) for p in original.iterdir() if p.is_file()};save(case/'INPUT-PINS.json',pins);results.append(dict(example=name,successful_platforms=['windows','linux'],byte_identical_payloads=len(payload)))
save(out/'COMPLETED.json',dict(status='PASS_ALL_THREE_COMPLETE_PUBLIC_EXAMPLES_WINDOWS_LINUX',actual_main_processes=6,examples=results));print('PASS_ALL_PUBLIC_EXAMPLES',flush=True)
