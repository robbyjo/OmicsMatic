from pathlib import Path
import subprocess,json,os,zipfile,hashlib,time,xml.etree.ElementTree as ET
r=Path(__file__).resolve().parents[2];b=Path(__file__).resolve().parent;out=b/'portable-1';out.mkdir();jdk=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin');jar=b/'build-2/jar/omicsmatic-0.4.0.jar';old=r/'build/ldsc-scores-1/portable-1/jar/omicsmatic-0.4.0.jar';junit=r/'build/nfcore-atacseq121-1/linux-test-runtime-1/junit-platform-console-standalone-1.13.4.jar'
def save(p,v):p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
def pin(p):
 with p.open('rb') as f:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
def linux(p):p=p.resolve();return '/mnt/'+p.drive[0].lower()+'/'+p.as_posix()[3:]
def run(tag,args):
 start=time.monotonic();save(out/(tag+'-command.json'),args)
 with (out/(tag+'.stdout')).open('xb') as so,(out/(tag+'.stderr')).open('xb') as se:x=subprocess.run(args,cwd=r,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=900)
 save(out/(tag+'-PROCESS.json'),dict(exit_code=x.returncode,seconds=time.monotonic()-start));assert x.returncode==0,(tag,x.returncode);print('PASS',tag,flush=True)
guards=json.loads((b/'build-2/SOURCES.json').read_bytes());assert all(pin(r/n)==v for n,v in guards.items());save(out/'SOURCES.json',guards)
with zipfile.ZipFile(old) as before,zipfile.ZipFile(jar) as current:
 assert set(before.namelist())<=set(current.namelist());changed=[n for n in before.namelist() if before.read(n)!=current.read(n)];new=sorted(set(current.namelist())-set(before.namelist()));assert changed and all(n.startswith('org/jlinalg/genetics/LdscLdScores') for n in changed),changed;assert all(n.startswith(('org/jlinalg/genetics/LdscLdScores','org/jlinalg/cli/LdscReferenceCli')) for n in new),new
save(out/'JAR-TRANSITION.json',dict(status='PASS_ONLY_LDSCORE_ENGINE_CHANGED_AND_REFERENCE_COMMAND_ADDED',baseline=pin(old),artifact=pin(jar),changed_members=changed,new_members=new))
classes=out/'classes';classes.mkdir();tests=[r/'src/test/java/org/jlinalg/genetics/LdscLdScoresTest.java',r/'src/test/java/org/jlinalg/cli/LdscReferenceCliTest.java'];run('compile-tests',[str(jdk/'javac.exe'),'--release','17','-cp',os.pathsep.join(map(str,[jar,junit])),'-d',str(classes),*map(str,tests)])
counts={}
for platform in ['windows','linux']:
 report=out/(platform+'-junit');paths=[jar,classes,r/'src/test/resources'];cp=os.pathsep.join(map(str,paths)) if platform=='windows' else ':'.join(linux(p) for p in paths);args=['-Xmx2g','-jar',str(junit) if platform=='windows' else linux(junit),'execute','--class-path',cp,'--select-class','org.jlinalg.genetics.LdscLdScoresTest','--select-class','org.jlinalg.cli.LdscReferenceCliTest','--reports-dir',str(report) if platform=='windows' else linux(report),'--details','summary','--disable-ansi-colors'];cmd=[str(jdk/'java.exe'),*args] if platform=='windows' else ['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','java',*args];run(platform+'-junit',cmd)
 trees=[ET.parse(p).getroot() for p in report.glob('TEST-*.xml')];c={k:sum(int(t.attrib.get(k,0)) for t in trees) for k in ['tests','errors','failures','skipped']};assert c==dict(tests=20,errors=0,failures=0,skipped=0),c;counts[platform]=c
probe=out/'LdScoreProbe.java';probe.write_bytes((r/'build/ldsc-scores-1/portable-1/LdScoreProbe.java').read_bytes());run('compile-probe',[str(jdk/'javac.exe'),'--release','17','-cp',os.pathsep.join(map(str,[jar,junit,classes,r/'src/test/resources'])),'-d',str(classes),str(probe)])
for platform in ['windows','linux']:
 paths=[jar,junit,classes,r/'src/test/resources'];cp=os.pathsep.join(map(str,paths)) if platform=='windows' else ':'.join(linux(p) for p in paths);args=['-cp',cp,'org.jlinalg.genetics.LdScoreProbe',str(out/(platform+'-inputs')) if platform=='windows' else linux(out/(platform+'-inputs')),str(out/(platform+'-payloads')) if platform=='windows' else linux(out/(platform+'-payloads'))];cmd=[str(jdk/'java.exe'),*args] if platform=='windows' else ['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','java',*args];run(platform+'-probe',cmd)
changed_diagnostic=[]
for p in (out/'windows-payloads').glob('*.tsv'):
 assert p.read_bytes()==(out/'linux-payloads'/p.name).read_bytes(),p.name
 before=(r/'build/ldsc-scores-1/portable-1/windows-payloads'/p.name).read_text().splitlines();after=p.read_text().splitlines();oldrow=next(x for x in before if x.startswith('estimatedRetainedBytes\t'));newrow=next(x for x in after if x.startswith('estimatedRetainedBytes\t'));assert [x for x in before if not x.startswith('estimatedRetainedBytes\t')]==[x for x in after if not x.startswith('estimatedRetainedBytes\t')],p.name;assert int(newrow.split('\t')[1])>int(oldrow.split('\t')[1]);changed_diagnostic.append(dict(case=p.stem,old_estimated_bytes=int(oldrow.split('\t')[1]),new_estimated_bytes=int(newrow.split('\t')[1])))
assert len(changed_diagnostic)==37;assert all(pin(r/n)==v for n,v in guards.items());save(out/'COMPLETED.json',dict(status='PASS_PACKAGED_REFERENCE_API_AND_CLI_WINDOWS_LINUX',junit=counts,original_models_each_boundary=37,original_fields_each_boundary=75226,byte_identical_complete_model_payloads=37,old_numerics_and_graphs_unchanged=True,only_expected_old_diagnostic_change=changed_diagnostic,source_guards=guards,artifact=pin(jar)));print('PASS_ALL_PORTABLE_CONTROLS',flush=True)
