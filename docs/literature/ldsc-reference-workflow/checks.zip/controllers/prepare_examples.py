from pathlib import Path
import shutil,json
r=Path(__file__).resolve().parents[2];b=Path(__file__).resolve().parent;dest=r/'examples/ldsc-reference';dest.mkdir()
(dest/'.gitattributes').write_bytes(b'*.bed -text\n*.bim -text\n*.fam -text\n')
for name,source in [('unpartitioned-snps','snp-unpartitioned'),('binary-annotations','snp-binary'),('continuous-annotations','cm-continuous')]:
 d=dest/name;d.mkdir();s=b/'original-controls-1'/source
 for n in ['reference.bed','reference.bim','reference.fam','reference.tsv']:shutil.copyfile(s/n,d/n)
 m=json.loads((s/'request.json').read_bytes());m['out']='result';(d/'request.json').write_bytes((json.dumps(m,indent=2)+'\n').encode())
print('Prepared three complete synthetic reference examples; no analysis outputs included.')
