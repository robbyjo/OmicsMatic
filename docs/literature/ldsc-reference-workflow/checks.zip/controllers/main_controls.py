from pathlib import Path
import subprocess,json,os,hashlib,time,csv,gzip,shutil,zipfile
r=Path(__file__).resolve().parents[2];b=Path(__file__).resolve().parent;out=b/'main-controls-1';out.mkdir();jar=b/'build-2/jar/omicsmatic-0.4.0.jar';java='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe';distro='JLinAlg-Omics-SAIGE-20261026'
def save(p,v):p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
def pin(p):
 with p.open('rb') as f:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
def linux(p):p=p.resolve();return '/mnt/'+p.drive[0].lower()+'/'+p.as_posix()[3:]
def launch(platform,req,tag,expected=0,cp=None):
 cp=cp or jar;cmd=[java,'-Xmx2g','-cp',str(cp),'org.jlinalg.cli.LdscReferenceCli','--request',str(req)] if platform=='windows' else ['wsl.exe','-d',distro,'--','java','-Xmx2g','-cp',linux(cp),'org.jlinalg.cli.LdscReferenceCli','--request',linux(req)]
 save(out/(tag+'-command.json'),cmd);start=time.monotonic()
 with (out/(tag+'.stdout')).open('xb') as so,(out/(tag+'.stderr')).open('xb') as se:p=subprocess.run(cmd,cwd=r,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=300)
 save(out/(tag+'-PROCESS.json'),dict(exit_code=p.returncode,expected_exit_code=expected,seconds=time.monotonic()-start));assert p.returncode==expected,(tag,p.returncode,expected,(out/(tag+'.stderr')).read_text()[-1000:]);print('PASS_MAIN',tag,p.returncode,flush=True);return p.returncode
def verify(dest):
 completed=json.loads((dest/'COMPLETED.json').read_bytes());manifest=json.loads((dest/'manifest.json').read_bytes());assert completed['manifest']==pin(dest/'manifest.json');names={p.relative_to(dest).as_posix() for p in dest.rglob('*') if p.is_file()}-{'manifest.json','COMPLETED.json'};assert names==set(manifest)
 for n,v in manifest.items():assert pin(dest/n)==v,n
 assert json.loads((dest/'analysis.json').read_bytes())['result_admitted'] is True
def readgz(p):
 with gzip.open(p,'rt',encoding='utf-8',newline='') as f:return list(csv.reader(f,delimiter='\t'))
cases=[b/'original-controls-1'/n for n in ['snp-unpartitioned','bp-unpartitioned','snp-binary','cm-continuous','print-membership','snp-bim-subset']]+[b/'original-followup-1/snp-sample-subset'];comparisons=[];identical={}
for case in cases:
 for platform in ['windows','linux']:
  result=case/'native-result';assert not result.exists();launch(platform,case/'request.json',case.name+'-'+platform);verify(result);dest=out/(case.name+'-'+platform);assert not dest.exists();assert result.resolve().is_relative_to(b.resolve());result.rename(dest)
 win=out/(case.name+'-windows');other=out/(case.name+'-linux');payload={p.relative_to(win).as_posix() for p in win.rglob('*') if p.is_file()};assert payload=={p.relative_to(other).as_posix() for p in other.rglob('*') if p.is_file()}
 for n in payload:assert (win/n).read_bytes()==(other/n).read_bytes(),(case.name,n)
 identical[case.name]=len(payload)
 if (case/'original.l2.ldscore.gz').exists():
  original=readgz(case/'original.l2.ldscore.gz');native=readgz(win/'reference.l2.ldscore.gz');assert len(original)==len(native) and original[0]==native[0],(case.name,original[0],native[0]);maximum=0
  for wanted,actual in zip(original[1:],native[1:]):
   assert wanted[:3]==actual[:3] and len(wanted)==len(actual)
   for x,y in zip(wanted[3:],actual[3:]):difference=abs(float(x)-float(y));maximum=max(maximum,difference);assert difference<=.000500001,(case.name,x,y)
  for suffix in ['.M','.M_5_50']:assert list(map(float,(case/('original.l2'+suffix)).read_text().split()))==list(map(float,(win/('reference.l2'+suffix)).read_text().split())),case.name
  comparisons.append(dict(case=case.name,rows=len(native)-1,annotation_columns=len(native[0])-3,maximum_absolute_three_decimal_printing_difference=maximum))
assert len(comparisons)==5
negative=[]
base=cases[0]
for name,expected,alter in [('whole-reference',3,dict(chunk_size=1000,allow_whole_reference=False)),('unsupported',3,dict(analysis='not-supported')),('missing',3,dict(reference_table='absent.tsv')),('strict-print',2,dict(print_variants='print.tsv',print_policy='require-retained')),('binary-annotation',2,dict(annotation_mode='binary',annotations=['A0'])),('pair-capacity',2,{})]:
 dest=out/name;dest.mkdir()
 for n in ['reference.bed','reference.bim','reference.fam','reference.tsv']:shutil.copyfile(base/n,dest/n)
 request=json.loads((base/'request.json').read_bytes());request.update(alter);request['out']='result'
 if name=='strict-print':(dest/'print.tsv').write_bytes(b'variant\nabsent-literal-id\n')
 if name=='binary-annotation':
  text=(dest/'reference.tsv').read_text().splitlines();(dest/'reference.tsv').write_bytes(('variant\tcoordinate\tA0\n'+'\n'.join(l+'\t.2' for l in text[1:])+'\n').encode())
 if name=='pair-capacity':
  limits=subprocess.check_output([java,'-cp',str(jar),'org.jlinalg.cli.LdscReferenceCli','--default-limits'],cwd=r);request['limits']=json.loads(limits);request['limits']['numeric']['maximum_pairs']=1
 save(dest/'request.json',request);launch('windows',dest/'request.json',name,expected);assert not (dest/'result/COMPLETED.json').exists()
 if (dest/'result').exists():assert json.loads((dest/'result/analysis.json').read_bytes())['result_admitted'] is False;assert 'REQUIRED ACTIONS' in (dest/'result/FAILURE.txt').read_text()
 negative.append(dict(case=name,exit_code=expected))
# A deliberately incomplete runtime must produce a visible SKIP3, without an invented result.
thin=out/'missing-backend.jar'
with zipfile.ZipFile(jar) as z,zipfile.ZipFile(thin,'x',compression=zipfile.ZIP_DEFLATED) as target:
 for n in z.namelist():
  if n.startswith('org/jlinalg/cli/LdscReferenceCli'):target.writestr(n,z.read(n))
dest=out/'missing-backend';dest.mkdir();request=json.loads((base/'request.json').read_bytes());request['out']='result';save(dest/'request.json',request);launch('windows',dest/'request.json','missing-backend',3,thin);assert not (dest/'result/COMPLETED.json').exists();assert 'SKIP3' in (out/'missing-backend.stderr').read_text();negative.append(dict(case='missing-backend',exit_code=3))
record=dict(status='PASS_ACTUAL_MAIN_WINDOWS_LINUX_AND_ORIGINAL_CLI_COMPARISONS',successful_main_processes=14,negative_main_processes=negative,byte_identical_payloads_by_case=identical,total_byte_identical_payloads=sum(identical.values()),unchanged_original_cli_comparisons=comparisons,original_subset_cli_failures_not_admitted=True,artifact=pin(jar));save(out/'COMPLETED.json',record);print(json.dumps(record,indent=2),flush=True)
