from pathlib import Path
import subprocess,json,os,zipfile,hashlib,time,traceback
r=Path(__file__).resolve().parents[2];b=Path(__file__).resolve().parent;out=b/'original-controls-1';out.mkdir();source=r/'build/ldsc-high-impact-1/upstream-1/cbiit';runtime=r/'build/ldsc-scores-1/reference-runtime-1/python';python=runtime/'python.exe'
def pin(p):
 with p.open('rb') as f:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
def save(p,v):p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
def run(tag,args,cwd):
 start=time.monotonic();save(cwd/(tag+'-command.json'),args)
 with (cwd/(tag+'.stdout')).open('xb') as so,(cwd/(tag+'.stderr')).open('xb') as se:p=subprocess.run(args,cwd=cwd,env=env,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=300)
 save(cwd/(tag+'-PROCESS.json'),dict(exit_code=p.returncode,seconds=time.monotonic()-start));assert p.returncode==0,(tag,cwd,p.returncode);print('PASS_ORIGINAL',cwd.name,flush=True)
try:
 expected=json.loads((r/'build/ldsc-scores-1/reference-runtime-1/INSTALLED-FILES.json').read_bytes());assert len(expected)==4441
 for n,v in expected.items():assert pin(runtime/n)==v,n
 guards=json.loads((r/'build/ldsc-scores-1/reference-1/result/reference.json').read_bytes())['source_guards']
 for n,v in guards.items():assert pin(source/n)==v,n
 save(out/'SOURCE-GUARDS.json',guards);save(out/'RUNTIME-GUARDS.json',expected)
 bootstrap=out/'launch.py';bootstrap.write_bytes(b"import runpy,sys,types\nfrom pathlib import Path\np=Path(sys.argv[1]);args=sys.argv[2:];package=types.ModuleType('ldscore');package.__path__=[str(p/'ldscore')];sys.modules['ldscore']=package;sys.argv=[str(p/'ldsc.py'),*args];runpy.run_path(str(p/'ldsc.py'),run_name='__main__')\n")
 gzip=Path('C:/Program Files/Git/usr/bin/gzip.exe');assert gzip.is_file();save(out/'GZIP.json',dict(path=str(gzip),pin=pin(gzip)))
 env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1');env['PATH']=str(gzip.parent)+os.pathsep+env.get('PATH','')
 cases=[('snp-unpartitioned','L018','retained-snp-index',5,7,'unpartitioned',False,False),('bp-unpartitioned','L018','bp',30,3,'unpartitioned',False,False),('snp-binary','L002','retained-snp-index',5,3,'binary',False,False),('cm-continuous','L004','cm',5,50,'continuous',False,False),('print-membership','L018','cm',5,7,'unpartitioned',True,False),('snp-bim-subset','L001','retained-snp-index',5,2,'unpartitioned',False,False),('snp-sample-subset','L018','retained-snp-index',5,3,'unpartitioned',False,True)]
 rows=[]
 with zipfile.ZipFile(r/'src/test/resources/org/jlinalg/genetics/ldsc-scores/reference-fixtures.zip') as z:
  configs={c.split('\t')[0]:c.split('\t') for c in z.read('cases.tsv').decode().splitlines()[1:]}
  for name,fixture,units,window,chunk,mode,printing,subset in cases:
   dest=out/name;dest.mkdir();c=configs[fixture]
   for ext in ['.bed','.bim','.fam']:(dest/('reference'+ext)).write_bytes(z.read(fixture+'/reference'+ext))
   bim=[x.split() for x in z.read(fixture+'/reference.bim').decode().splitlines() if x.strip()];ids=set(c[9].split(','));selected=[v for v in bim if v[1] in ids];allbim=len(selected)==len(bim)
   ann=[x.split('\t') for x in z.read(fixture+'/annotations.tsv').decode().splitlines()[1:]];assert len(ann)==len(selected);k=int(c[3]);labels=['base'] if mode=='unpartitioned' else ['A'+str(i) for i in range(k)]
   table=['variant\tcoordinate'+('' if mode=='unpartitioned' else '\t'+'\t'.join(labels))]
   for variant,a in zip(selected,ann):
    coordinate='retained-index' if units=='retained-snp-index' else variant[3] if units=='bp' else a[0];table.append(variant[1]+'\t'+coordinate+('' if mode=='unpartitioned' else '\t'+'\t'.join(a[1:])))
   (dest/'reference.tsv').write_bytes(('\n'.join(table)+'\n').encode())
   native=dict(schema_version=1,analysis='ld-scores',bed_prefix='reference',reference_table='reference.tsv',sample_table=None,print_variants=None,print_policy='all-retained',annotation_mode=mode,annotations=labels,coordinate_units=units,window=window,chunk_size=chunk,minimum_maf=0,allow_whole_reference=True,limits='standard',out='native-result',data_provenance='Synthetic unchanged-original full CLI comparison '+fixture,sample_provenance='All synthetic FAM samples unless explicit selected pairs',coordinate_provenance='Explicit synthetic '+units+' map, source-filtered SNP indices where requested',annotation_provenance='Unpartitioned or original generated columns; no biological claim')
   args=[str(python),'-B',str(bootstrap),str(source),'--l2','--bfile',str(dest/'reference'),'--chunk-size',str(chunk),'--maf','0','--yes-really','--out',str(dest/'original')]
   args+=['--ld-wind-snps',str(window)] if units=='retained-snp-index' else ['--ld-wind-kb',str(window/1000)] if units=='bp' else ['--ld-wind-cm',str(window)]
   if mode!='unpartitioned':
    assert allbim;(dest/'thin.annot').write_bytes(('\t'.join(labels)+'\n'+'\n'.join('\t'.join(a[1:]) for a in ann)+'\n').encode());args+=['--annot',str(dest/'thin.annot'),'--thin-annot']
   elif not allbim:
    (dest/'extract.txt').write_bytes(('\n'.join(v[1] for v in selected)+'\n').encode());args+=['--extract',str(dest/'extract.txt')]
   if printing:
    expectedfields=dict(x.split('\t') for x in z.read(fixture+'/expected.tsv').decode().splitlines()[1:]);first=[selected[int(expectedfields['retainedInputIndices.'+str(i)])][1] for i in range(2)];printids=[*reversed(first),selected[0][1],'absent-literal-id'];(dest/'print.txt').write_bytes(('\n'.join(printids)+'\n').encode());(dest/'print.tsv').write_bytes(('variant\n'+'\n'.join(printids)+'\n').encode());args+=['--print-snps',str(dest/'print.txt')];native.update(print_variants='print.tsv',print_policy='source-membership')
   if subset:
    fam=[x.split() for x in z.read(fixture+'/reference.fam').decode().splitlines() if x.strip()];sel=fam[::2];assert len(sel)>2;(dest/'keep.txt').write_bytes(('\n'.join(v[1] for v in sel)+'\n').encode());(dest/'samples.tsv').write_bytes(('FID\tIID\n'+'\n'.join(v[0]+'\t'+v[1] for v in reversed(sel))+'\n').encode());args+=['--keep',str(dest/'keep.txt')];native['sample_table']='samples.tsv';native['sample_provenance']='Exact reversed FID/IID subset; original CLI uses matching unique IID membership'
   save(dest/'request.json',native);run('original',args,dest)
   outputs={p.name:pin(p) for p in dest.glob('original.l2*')};assert len(outputs)==3,outputs;rows.append(dict(id=name,fixture=fixture,coordinate_units=units,annotation_mode=mode,printing=printing,sample_subset=subset,outputs=outputs))
 for n,v in guards.items():assert pin(source/n)==v,n
 for n,v in expected.items():assert pin(runtime/n)==v,n
 save(out/'COMPLETED.json',dict(status='PASS_SEVEN_UNCHANGED_ORIGINAL_LDSC_REFERENCE_CLI_CONTROLS',cases=rows,source_initializer_bypassed=True,original_functions_replaced=False,runtime_files_unchanged=4441,source_guards=guards));print('PASS_ALL_SEVEN_ORIGINAL_CONTROLS',flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),detail=traceback.format_exc()));raise
