from pathlib import Path
import subprocess,json,os,hashlib,time,shutil
r=Path(__file__).resolve().parents[2];b=Path(__file__).resolve().parent;prior=b/'original-controls-1';out=b/'original-followup-1';out.mkdir();source=r/'build/ldsc-high-impact-1/upstream-1/cbiit';runtime=r/'build/ldsc-scores-1/reference-runtime-1/python'
def pin(p):
 with p.open('rb') as f:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
def save(p,v):p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
guards=json.loads((prior/'SOURCE-GUARDS.json').read_bytes());expected=json.loads((prior/'RUNTIME-GUARDS.json').read_bytes())
for n,v in guards.items():assert pin(source/n)==v,n
for n,v in expected.items():assert pin(runtime/n)==v,n
dest=out/'snp-sample-subset';dest.mkdir();base=prior/'snp-unpartitioned'
for n in ['reference.bed','reference.bim','reference.fam','reference.tsv']:shutil.copyfile(base/n,dest/n)
fam=[x.split() for x in (dest/'reference.fam').read_text().splitlines() if x.strip()];selected=fam[::2];(dest/'keep.txt').write_bytes(('\n'.join(v[1] for v in selected)+'\n').encode());(dest/'samples.tsv').write_bytes(('FID\tIID\n'+'\n'.join(v[0]+'\t'+v[1] for v in reversed(selected))+'\n').encode());native=json.loads((base/'request.json').read_bytes());native['chunk_size']=3;native['sample_table']='samples.tsv';native['sample_provenance']='Exact reversed FID/IID subset; original full CLI uses corresponding unique-IID membership';save(dest/'request.json',native)
cmd=[str(runtime/'python.exe'),'-B',str(prior/'launch.py'),str(source),'--l2','--bfile',str(dest/'reference'),'--chunk-size','3','--maf','0','--yes-really','--ld-wind-snps','5','--keep',str(dest/'keep.txt'),'--out',str(dest/'original')];save(dest/'command.json',cmd);env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1');env['PATH']='C:/Program Files/Git/usr/bin'+os.pathsep+env.get('PATH','');start=time.monotonic()
with (dest/'stdout').open('xb') as so,(dest/'stderr').open('xb') as se:p=subprocess.run(cmd,cwd=dest,env=env,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=300)
save(dest/'PROCESS.json',dict(exit_code=p.returncode,seconds=time.monotonic()-start));assert p.returncode==1;assert 'np.nonzero(ii)' in (dest/'stderr').read_text() and 'Length of values (1) does not match length of index' in (dest/'stderr').read_text();assert not list(dest.glob('original.l2*'))
for n,v in guards.items():assert pin(source/n)==v,n
for n,v in expected.items():assert pin(runtime/n)==v,n
record=dict(status='SOURCE_CONTROLS_CLOSED_WITH_FIVE_SUCCESSES_AND_TWO_RETAINED_FAILURES',successful_full_cli_cases=['snp-unpartitioned','bp-unpartitioned','snp-binary','cm-continuous','print-membership'],full_cli_failed_cases=['snp-bim-subset','snp-sample-subset'],failed_cli_admitted=False,source_root_cli_reported_version='3.0.1',selected_source_package='CBIIT 3.0.2',source_functions_replaced=False,runtime_files_verified_unchanged=4441,required_action='The unchanged root CLI fails in parse.py PlinkFile.loj np.nonzero(pd.Series) with the declared NumPy/pandas runtime before subset estimation. Retain these failures; do not patch or monkeypatch the source to claim full CLI parity. Native subset math and file transport remain separately checked by all original-core fixture controls. No original full-CLI subset result is admitted.')
save(out/'COMPLETED.json',record);print(json.dumps(record,indent=2),flush=True)
