from pathlib import Path
import subprocess,json,zipfile,shutil,time,os,hashlib
r=Path(__file__).resolve().parents[2];b=Path(__file__).resolve().parent;out=b/'late-controls-1';out.mkdir();java='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe';jar=b/'build-2/jar/omicsmatic-0.4.0.jar';results=[]
def save(p,v):p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
def pin(p):
 with p.open('rb') as f:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
with zipfile.ZipFile(r/'src/test/resources/org/jlinalg/genetics/ldsc-scores/reference-fixtures.zip') as z:
 c=next(x.split('\t') for x in z.read('cases.tsv').decode().splitlines()[1:] if x.startswith('L036\t'));selected=set(c[9].split(','));bim=[x.split() for x in z.read('L036/reference.bim').decode().splitlines() if x.strip()];bim=[x for x in bim if x[1] in selected];ann=z.read('L036/annotations.tsv').decode().splitlines()[1:];names=['A'+str(i) for i in range(int(c[3]))];ref='variant\tcoordinate\t'+'\t'.join(names)+'\n'+'\n'.join(v[1]+'\t'+a for v,a in zip(bim,ann))+'\n'
 for kind in ['original-input','captured-input','runtime-code','closed-console']:
  dest=out/kind;dest.mkdir()
  for ext in ['.bed','.bim','.fam']:(dest/('reference'+ext)).write_bytes(z.read('L036/reference'+ext))
  (dest/'reference.tsv').write_bytes(ref.encode());request=dict(schema_version=1,analysis='ld-scores',bed_prefix='reference',reference_table='reference.tsv',sample_table=None,print_variants=None,print_policy='all-retained',annotation_mode=c[4],annotations=names,coordinate_units='cm',window=0,chunk_size=10000,minimum_maf=0,allow_whole_reference=True,limits='standard',out='result',data_provenance='Synthetic late-failure original core control L036',sample_provenance='All synthetic FAM samples',coordinate_provenance='Explicit generated sorted coordinates; no biological claim',annotation_provenance='Original generated fixture columns')
  if kind=='closed-console':request['chunk_size']=1
  save(dest/'request.json',request);cp=jar
  if kind=='runtime-code':
   cp=dest/'runtime';shutil.copytree(r/'build/classes/java/main',cp);assert (cp/'org/jlinalg/cli/LdscReferenceCli.class').is_file()
   with zipfile.ZipFile(jar) as baseline:
    for p in cp.rglob('*.class'):
     n=p.relative_to(cp).as_posix()
     if n.startswith(('org/jlinalg/cli/LdscReferenceCli','org/jlinalg/genetics/LdscLdScores','org/jlinalg/genetics/PlinkBedDataset','org/jlinalg/cli/NextflowFiles','org/jlinalg/cli/NextflowJson','org/jlinalg/cli/NextflowParameters','org/jlinalg/cli/LdscToolsCli')):assert p.read_bytes()==baseline.read(n),n
  cmd=[java,'-Xmx2g','-cp',str(cp),'org.jlinalg.cli.LdscReferenceCli','--request',str(dest/'request.json')];save(dest/'command.json',cmd);start=time.monotonic();observed=False
  with (dest/'stderr').open('xb') as err,(dest/'stdout').open('xb') as stdout:
   p=subprocess.Popen(cmd,cwd=r,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE if kind=='closed-console' else stdout,stderr=err)
   save(dest/'LIVE-PROCESS.json',dict(pid=p.pid,started=time.time()))
   if kind=='closed-console':p.stdout.close();observed=True
   else:
    while p.poll() is None and time.monotonic()-start<90:
     if (dest/'result/preflight.json').is_file():observed=True;break
     time.sleep(.005)
    assert observed,(kind,p.poll(),'No observed live preflight; do not claim integrity control')
    target=dest/'reference.fam' if kind=='original-input' else dest/'result/source-reference.tsv' if kind=='captured-input' else cp/'org/jlinalg/genetics/LdscLdScores.class';before=pin(target)
    with target.open('ab') as change:change.write(b'\n' if kind!='runtime-code' else b'\0')
    save(dest/'MUTATION.json',dict(target=target.relative_to(dest).as_posix(),before=before,after=pin(target),observed_live_preflight=True))
   code=p.wait(timeout=300)
  save(dest/'PROCESS.json',dict(exit_code=code,seconds=time.monotonic()-start,observed_live_preflight_or_closed_pipe=observed));assert code==2,(kind,code,(dest/'stderr').read_text()[-1000:]);assert not (dest/'result/COMPLETED.json').exists();report=json.loads((dest/'result/analysis.json').read_bytes());assert report['result_admitted'] is False;error=(dest/'stderr').read_text();message={'original-input':'Original source changed','captured-input':'Captured source changed','runtime-code':'Program code artifact changed','closed-console':'Console recording failed'}[kind];assert message in error,(kind,error[-1000:]);assert 'REQUIRED ACTIONS' in error;results.append(dict(case=kind,exit_code=code,expected_message=message));print('PASS_LATE_CONTROL',kind,flush=True)
save(out/'COMPLETED.json',dict(status='PASS_ACTUAL_MAIN_LATE_INTEGRITY_AND_CONSOLE_FAILURES',cases=results,original_shared_sources_and_jar_unchanged=True));print('PASS_ALL_LATE_CONTROLS',flush=True)
