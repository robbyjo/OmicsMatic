from pathlib import Path
import sys,json
r=Path('/mnt/d/projects/JLinAlg');b=r/'build/literature-review/monocle-runtime';o=b/'doubletfinder206-runtime-change-audit-1';sys.path.insert(0,str(r/'tools/literature/doubletfinder206'));from Runtime import inventory
ready=json.loads((b/'doubletfinder206-provider-2/READY.json').read_bytes());expected=json.loads((b/'doubletfinder206-provider-2/r_prefix-files.json').read_bytes());actual=inventory(Path(ready['r_prefix']))
result=dict(status='ACTUAL_RUNTIME_DIFFERENCES_RETAINED_NO_HASH_REFRESH',expected_files=len(expected),current_files=len(actual),added={n:actual[n] for n in actual.keys()-expected.keys()},removed={n:expected[n] for n in expected.keys()-actual.keys()},changed={n:dict(before=expected[n],after=actual[n]) for n in actual.keys()&expected.keys() if actual[n]!=expected[n]})
(o/'DIFFERENCES.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
