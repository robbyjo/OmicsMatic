from pathlib import Path
import os,subprocess,time,json
r=Path('/mnt/d/projects/JLinAlg');o=r/'build/literature-review/monocle-runtime/doubletfinder206-workflow-reference-run-1'
c=['/opt/omicsmatic-doubletfinder206-r453-20261114-1/.pixi/envs/default/bin/Rscript','--vanilla',str(r/'tools/literature/doubletfinder206/GenerateWorkflowReferences.R'),'/opt/omicsmatic-doubletfinder206-r453-20261114-1/library',str(r/'build/literature-review/monocle-runtime/doubletfinder206-full-object-probe-1/preprocessed-input.rds'),str(r/'build/literature-review/monocle-runtime/doubletfinder206-workflow-references-1')]
e=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',R_ENVIRON_USER='/dev/null',R_PROFILE_USER='/dev/null')
with (o/'original.stdout').open('xb') as so,(o/'original.stderr').open('xb') as se:
 p=subprocess.Popen(c,cwd=o,env=e,stdin=subprocess.DEVNULL,stdout=so,stderr=se);(o/'LIVE.json').write_text(json.dumps(dict(pid=p.pid,command=c)))
 while True:
  try:code=p.wait(timeout=20);break
  except subprocess.TimeoutExpired:print('SAME_DIRECT_ORIGINAL_WORKFLOW_REFERENCE_GENERATOR_RUNNING',p.pid,flush=True)
(o/'PROCESS.json').write_text(json.dumps(dict(command=c,exit_code=code),indent=2)+'\n');print('DIRECT_ORIGINAL_WORKFLOW_REFERENCE_EXIT',code,flush=True);raise SystemExit(code)
