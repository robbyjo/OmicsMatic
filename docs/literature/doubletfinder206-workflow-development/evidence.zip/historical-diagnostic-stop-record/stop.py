from pathlib import Path
import json,os,signal,time
r=Path('/mnt/d/projects/JLinAlg');o=r/'build/literature-review/monocle-runtime/doubletfinder206-SCT-diagnostic-stop-1';a=r/'build/literature-review/monocle-runtime/doubletfinder206-workflow-comparisons-2/SCTransform/analysis';live=json.loads((a/'LIVE.json').read_bytes());pid=live['pid'];proc=Path('/proc')/str(pid)
if not proc.exists():
 (o/'NO_SIGNAL.json').write_text(json.dumps(dict(status='OWN_ORIGINAL_CHILD_ALREADY_TERMINAL_NO_SIGNAL_SENT',pid=pid)));print('OWN_CHILD_ALREADY_TERMINAL',flush=True);raise SystemExit(0)
cmd=(proc/'cmdline').read_bytes().replace(bytes([0]),b' ').decode();expected=str(a/'control.json');assert expected in cmd and '/doubletfinder206/Worker.R' in cmd;assert os.getpgid(pid)==pid
fds=[os.readlink(p) for p in (proc/'fd').iterdir()];assert str(a/'original/complete-conditions.rds') in fds
snapshot=dict(status='SIGTERM_ONLY_OWN_CONFIRMED_ANALYSIS_PROCESS_GROUP_FOR_DIAGNOSTIC_RECORDING_FAULT',pid=pid,pgid=os.getpgid(pid),command=cmd,available_full_result_bytes=(a/'original/complete-result.rds').stat().st_size,partial_diagnostic_bytes=(a/'original/complete-conditions.rds').stat().st_size,reason='Model calculation completed; injected per-message full call stacks make the diagnostic RDS grow excessively. Preserve all files, stop this owned child only, fix recorder and requalify NEW paths.',files_deleted=False,original_source_or_inputs_modified=False)
(o/'BEFORE-SIGNAL.json').write_text(json.dumps(snapshot,indent=2)+'\n');os.killpg(pid,signal.SIGTERM);(o/'SIGNAL-SENT.json').write_text(json.dumps(dict(pid=pid,signal='SIGTERM',files_deleted=False))+'\n');print('SIGTERM_SENT_TO_OWN_CONFIRMED_GROUP',pid,flush=True)
