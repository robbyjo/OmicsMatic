# PASS_ORIGINAL_DOUBLET_FINDER206_COMPLETE_R_OBJECT

**REVIEW REQUIRED. Original R handler totals: {'warning': 3706, 'message': 17, 'error': 0}. Recognized iteration-limit warnings: 12. Numerical convergence is not qualified.**

Complete original R object admitted: True. Raw diagnostic totals are unavailable, never zero.

**Original message x 1**

    `vst.flavor` is set to 'v2' but could not find glmGamPoi installed.
    Please install the glmGamPoi package for much faster estimation.
    --------------------------------------------
    install.packages('BiocManager')
    BiocManager::install('glmGamPoi')
    --------------------------------------------
    Falling back to native (slower) implementation.
    

**Original warning x 211**

    non-integer x = 6.500000

**Original warning x 813**

    non-integer x = 2.500000

**Original warning x 386**

    non-integer x = 4.500000

**Original warning x 105**

    non-integer x = 7.500000

**Original warning x 524**

    non-integer x = 3.500000

**Original warning x 49**

    non-integer x = 8.500000

**Original warning x 330**

    non-integer x = 5.500000

**Original warning x 890**

    non-integer x = 1.500000

**Original warning x 355**

    non-integer x = 0.500000

**Original warning x 17**

    non-integer x = 9.500000

**Original warning x 2**

    non-integer x = 12.500000

**Original warning x 5**

    non-integer x = 11.500000

**Original warning x 7**

    non-integer x = 10.500000

**Original warning x 12**

    iteration limit reached

**Do not treat this output as a converged SCT analysis.** Preserve the original objects. Review the original estimator and data with the complete conditions. Any changed estimator or permitted dependency profile needs independent original controls and a NEW runtime/output; do not round artificial counts, suppress warnings or change prior evidence to obtain a pass.

Review every raw console and complete original R condition; raw/native diagnostic totals are unavailable, never zero. Use the unchanged original DoubletFinder 2.0.6 source and the declared private Linux/WSL R 4.5.3 dependency profile. Installation/download must be permitted separately; analysis never installs software. Missing or forbidden requirements SKIP3 skip dependent analysis. FAIL2 admits no complete result. Resolve the named cause and retry NEW writable output paths, retaining all original inputs, complete RDS objects, logs and available partial files. RDS requests must be trusted. Full-object verification requires the exact R runtime and strict CompareOriginal.R; Seurat closures are not flattened into portable numeric summaries. Do not repair cells, identifiers, NA/NaN/Inf, substitute an author edition, change old hashes or waive output differences. The selected profile is not an author environment. The modified scrattch.hicat method and the reported DoubletFinder 3.0 edition remain separate unresolved source audits. No whole-package, biological, paper-reproduction or full-250-paper completion claim is made.
