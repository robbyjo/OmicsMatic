from pathlib import Path
import concurrent.futures,hashlib,json,os,subprocess,threading,time,traceback
R=Path('/mnt/d/projects/JLinAlg');B=R/'build/literature-review/monocle-runtime';OUT=B/'doubletfinder206-workflow-comparisons-4';REF=B/'doubletfinder206-workflow-references-1';HERE=R/'tools/literature/doubletfinder206';PROVIDER=B/'doubletfinder206-provider-5';READY=json.loads((PROVIDER/'READY.json').read_bytes());LIB=READY['library'];RSCRIPT=str(Path(READY['r_prefix'])/'bin/Rscript');live={};lock=threading.Lock()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def pin(p):
 raw=p.read_bytes();return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def run_child(folder,label,command):
 with (folder/(label+'.stdout')).open('xb') as so,(folder/(label+'.stderr')).open('xb') as se:
  child=subprocess.Popen(list(map(str,command)),cwd=folder,env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',R_ENVIRON_USER='/dev/null',R_PROFILE_USER='/dev/null'),stdin=subprocess.DEVNULL,stdout=so,stderr=se)
  with lock:live[(folder.name,label)]=child
  save(folder/(label+'-PROCESS.json'),dict(pid=child.pid,command=list(map(str,command)),running=True));code=child.wait()
  with lock:del live[(folder.name,label)]
  save(folder/(label+'-PROCESS-COMPLETED.json'),dict(pid=child.pid,command=list(map(str,command)),exit_code=code));return code

def one(case):
 name=case['name'];folder=OUT/name;folder.mkdir();actual=folder/'analysis';reference=REF/name
 try:
  code=run_child(folder,'adapter',['/usr/bin/python3','-B',HERE/'run.py','--runtime',PROVIDER,'--request',reference/'request.rds','--out',actual,'--wall-seconds','900'])
  status=json.loads((actual/'analysis-status.json').read_bytes());assert code==(0 if case['original_complete'] else 2),(name,code,status)
  manifest=json.loads((actual/'MANIFEST.json').read_bytes())['files']
  for relative,record in manifest.items():
   path=actual/relative
   if record['kind']=='file':assert pin(path)=={k:record[k] for k in ['bytes','sha256']},relative
   elif record['kind']=='link':assert os.readlink(path)==record['target']
   else:raise ValueError('Unsupported output manifest type')
  assert pin(reference/'request.rds')==pin(actual/'request.rds')
  if case['original_complete']:
   assert status['result_admitted'];
   if name=='SCTransform':
    warning=(actual/'WARNINGS.md').read_text();assert status['R_handler_counts']['warning']==3706 and status['recognized_iteration_limit_warnings']==12 and not status['convergence_qualified'];assert '3706' in warning and 'Do not treat this output as a converged SCT analysis' in warning and 'glmGamPoi' in warning
   code=run_child(folder,'strict-comparison',[RSCRIPT,'--vanilla',OUT/'CompareAll.R',LIB,reference,actual/'original',folder/'COMPLETE-R-COMPARISON.json']);assert code==0,(name,'complete original objects differ')
   original_images={p.name:pin(p) for p in reference.glob('original-plot-*.png')};actual_images={p.name:pin(p) for p in (actual/'original').glob('original-plot-*.png')};assert original_images==actual_images,(name,'complete original PNG differs')
   result=dict(status='PASS_COMPLETE_ORIGINAL_RETURN_RNG_AND_PNG',name=name,complete_R_objects_compared=2,whole_PNG_files=len(original_images),native_RDS_closure_fields_omitted=False,manifest_entries=len(manifest))
  else:
   assert not status['result_admitted'] and not (actual/'original/complete-result.rds').exists()
   r=json.loads((actual/'original/R-status.json').read_bytes());expected_class=case['error_class'];actual_class=r['error']['class'];assert expected_class==actual_class and case['error_message']==r['error']['message'],(name,'original error class/message differs')
   result=dict(status='PASS_ORIGINAL_ERROR_CLASS_AND_MESSAGE_FAIL2_RETAINED',name=name,result_admitted=False,manifest_entries=len(manifest))
  save(folder/'COMPLETED.json',result);print(result['status'],name,flush=True);return result
 except BaseException as e:save(folder/'FAILURE.json',dict(cause=repr(e),traceback=traceback.format_exc()));raise

try:
 cases=json.loads((REF/'COMPLETED.json').read_bytes())['cases'];results=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  pending={pool.submit(one,c) for c in cases}
  while pending:
   done,pending=concurrent.futures.wait(pending,timeout=20,return_when=concurrent.futures.FIRST_COMPLETED)
   for f in done:results.append(f.result())
   if pending:
    with lock:snapshot=[dict(case=k[0],phase=k[1],pid=v.pid) for k,v in live.items() if v.poll() is None]
    print('SAME_LIVE_ORIGINAL_ADAPTER_COMPARISONS',json.dumps(snapshot),flush=True)
 result=dict(status='PASS_ALL_TWELVE_ORIGINAL_WORKFLOW_CASES',complete_original_returns=sum(x.get('complete_R_objects_compared',0)//2 for x in results),complete_original_R_objects_compared=sum(x.get('complete_R_objects_compared',0) for x in results),complete_PNG_files_compared=sum(x.get('whole_PNG_files',0) for x in results),matching_original_errors=sum(not c['original_complete'] for c in cases),cases=results,parameters_or_editions_inferred=False,field_or_cell_waivers=0,whole_tool_qualified=False,new_family_credit=0,whole_goal_complete=False);save(OUT/'COMPLETED.json',result);print(json.dumps(result),flush=True)
except BaseException as e:save(OUT/'FAILURE.json',dict(cause=repr(e),traceback=traceback.format_exc()));raise
