a<-commandArgs(TRUE);stopifnot(length(a)==4L);.libPaths(c(a[[1]],.libPaths()));loadNamespace('DoubletFinder');loadNamespace('Seurat')
ref<-a[[2]];actual<-a[[3]];out<-a[[4]];if(file.exists(out))stop('Use NEW full comparison output')
paths<-c(result='complete-original-return.rds',rng='complete-rng-before-after.rds');actual.paths<-c(result='complete-result.rds',rng='complete-rng-before-after.rds');checks<-list()
for(name in names(paths)){
 x<-readRDS(file.path(ref,paths[[name]]));y<-readRDS(file.path(actual,actual.paths[[name]]));same<-identical(x,y,num.eq=FALSE,single.NA=FALSE,attrib.as.set=FALSE,ignore.bytecode=FALSE,ignore.environment=FALSE,ignore.srcref=FALSE,extptr.as.ref=TRUE);checks[[name]]<-list(complete_object_equal=same,class=class(x));if(!same)checks[[name]]$diagnostic_only<-capture.output(all.equal(x,y,check.environment=TRUE))
}
pass<-all(vapply(checks,function(x)x$complete_object_equal,logical(1)));jsonlite::write_json(list(status=if(pass)'PASS_COMPLETE_ORIGINAL_OBJECT_AND_RNG_STRICT'else'FAIL2_COMPLETE_ORIGINAL_OBJECT_OR_RNG_DIFFERS',checks=checks,fields_or_cells_omitted=FALSE,numeric_bits_and_NA_payloads_compared=TRUE,closure_environments_ignored=FALSE),out,pretty=TRUE,auto_unbox=TRUE);cat(if(pass)'PASS_COMPLETE_ORIGINAL_OBJECT_AND_RNG_STRICT'else'FAIL2_COMPLETE_ORIGINAL_OBJECT_OR_RNG_DIFFERS','\n');if(!pass)quit(save='no',status=2L,runLast=FALSE)
