from pathlib import Path
import json,os,subprocess,time,traceback
r=Path('/mnt/d/projects/JLinAlg');b=r/'build/literature-review/monocle-runtime';o=b/'doubletfinder206-public-end-to-end-1';here=r/'tools/literature/doubletfinder206';private=Path('/opt/omicsmatic-doubletfinder206-public-install-20261114-3');calls=[]
def save(n,v):(o/n).write_text(json.dumps(v,indent=2)+'\n')
def run(label,command):
 command=list(map(str,command));start=time.monotonic()
 with (o/(label+'.stdout')).open('xb') as so,(o/(label+'.stderr')).open('xb') as se:
  child=subprocess.Popen(command,cwd=o,env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',R_ENVIRON_USER='/dev/null',R_PROFILE_USER='/dev/null'),stdin=subprocess.DEVNULL,stdout=so,stderr=se);save('LIVE.json',dict(pid=child.pid,label=label,command=command))
  while True:
   try:code=child.wait(timeout=20);break
   except subprocess.TimeoutExpired:print('SAME_CURRENT_PUBLIC_END_TO_END_CHILD_RUNNING',label,child.pid,flush=True)
 calls.append(dict(label=label,command=command,exit_code=code,elapsed_seconds=time.monotonic()-start));save('PROCESSES.json',calls);assert code==0,(label,code)
try:
 run('install-current-original-private-runtime',['/usr/bin/python3','-B',here/'install_runtime.py','--manager',r/'build/literature-review/saige-runtime/pixi-bootstrap-1/pixi','--out',private,'--source-archive',b/'doubletfinder-source-intake-1/DoubletFinder-original.tar.gz','--cache-dir','/opt/omicsmatic-doubletfinder206-r453-20261114-1/pixi-cache','--allow-install','--allow-download'])
 run('run-current-original-Seurat-fit',['/usr/bin/python3','-B',here/'run.py','--runtime',private/'provider','--request',b/'doubletfinder206-workflow-references-1/lognorm-default-pN/request.rds','--out',o/'analysis'])
 run('strict-complete-original-comparison',[private/'runtime/.pixi/envs/default/bin/Rscript','--vanilla',b/'doubletfinder206-workflow-comparisons-4/CompareAll.R',private/'runtime/library',b/'doubletfinder206-workflow-references-1/lognorm-default-pN',o/'analysis/original',o/'COMPLETE-COMPARISON.json'])
 save('COMPLETED.json',dict(status='PASS_CURRENT_PUBLIC_INSTALL_ANALYSIS_AND_COMPLETE_OBJECT_RNG_PARITY',calls=calls,private_install=str(private),analysis_status=json.loads((o/'analysis/analysis-status.json').read_bytes()),complete_original_R_objects_compared=2,whole_tool_qualified=False,new_family_credit=0,whole_goal_complete=False));print('PASS_CURRENT_PUBLIC_END_TO_END_INSTALL_ANALYSIS_AND_PARITY',flush=True)
except BaseException as e:save('FAILURE.json',dict(cause=repr(e),traceback=traceback.format_exc(),calls=calls));raise
