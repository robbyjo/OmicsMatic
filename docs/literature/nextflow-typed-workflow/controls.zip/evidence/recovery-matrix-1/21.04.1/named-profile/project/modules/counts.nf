process COUNTS {
    tag { sample }
    input:
    tuple val(sample),path(sequence)
    output:
    tuple val(sample),path("${sample}.tsv")
    script:
    """
    awk 'BEGIN{n=0;gc=0} !/^>/{s=toupper(\$0);n+=length(s);gsub(/[^GC]/,"",s);gc+=length(s)} END{printf "%s\\t%d\\t%d\\n","$sample",n,gc}' "$sequence" > "${sample}.tsv"
    """
}

