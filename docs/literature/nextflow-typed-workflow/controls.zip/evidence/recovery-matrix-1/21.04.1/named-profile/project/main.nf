
nextflow.enable.dsl=2
params.inputs=null
params.outdir=null
params.fail=false
params.ignore=false
params.empty=false

include { COUNTS } from './modules/counts'

process GATHER {
    publishDir params.outdir,mode:'copy'
    errorStrategy { params.ignore ? 'ignore' : 'terminate' }
    input:
    path(tables)
    output:
    path 'counts.tsv'
    script:
    if(params.fail) 'exit 7'
    else 'cat *.tsv | LC_ALL=C sort > counts.tsv'
}

workflow {
    if(params.profile_marker != 'named-local-profile') error('named profile not active')
    if(!params.empty){
        samples=Channel.of(tuple('a',file(params.inputs+'/a.fa',checkIfExists:true)),tuple('b',file(params.inputs+'/b.fa',checkIfExists:true)),tuple('c',file(params.inputs+'/c.fa',checkIfExists:true)))
        COUNTS(samples)
        GATHER(COUNTS.out.map{sample,table -> table}.collect())
    }
}
