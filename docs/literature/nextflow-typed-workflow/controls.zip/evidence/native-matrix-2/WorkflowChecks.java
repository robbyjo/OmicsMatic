import java.io.File;
import java.io.PrintWriter;
import org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder;
import org.junit.platform.launcher.core.LauncherFactory;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;
public class WorkflowChecks {
 public static void main(String[] args)throws Exception {
  System.out.println(System.getProperty("os.name")+" Java "+System.getProperty("java.version"));
  for(String name:new String[]{"org.jlinalg.cli.NextflowCapture","org.jlinalg.cli.NextflowProcess","org.jlinalg.cli.NextflowBundle"})if(!Class.forName(name).getProtectionDomain().getCodeSource().getLocation().toURI().equals(new File(args[0]).toURI()))throw new AssertionError("Wrong actual JAR");
  var listener=new SummaryGeneratingListener();LauncherFactory.create().execute(LauncherDiscoveryRequestBuilder.request().selectors(selectClass("org.jlinalg.cli.NextflowCaptureTest"),selectClass("org.jlinalg.cli.NextflowCaptureWorkspaceTest"),selectClass("org.jlinalg.cli.NextflowFilesTest"),selectClass("org.jlinalg.cli.NextflowOriginalProcessTest"),selectClass("org.jlinalg.cli.NextflowParametersTest"),selectClass("org.jlinalg.cli.NextflowProcessTest"),selectClass("org.jlinalg.cli.NextflowRecipeTest"),selectClass("org.jlinalg.cli.NextflowRecordedBindingsTest"),selectClass("org.jlinalg.cli.NextflowRuntimeTest"),selectClass("org.jlinalg.cli.NextflowSessionPointerTest"),selectClass("org.jlinalg.cli.NextflowSessionProcessTest"),selectClass("org.jlinalg.cli.NextflowSetupTest"),selectClass("org.jlinalg.cli.NextflowStandaloneBundleTest"),selectClass("org.jlinalg.workflow.NextflowTraceAuditTest"),selectClass("org.jlinalg.workflow.NextflowCompletionAuditTest")).build(),listener);
  var s=listener.getSummary();s.printTo(new PrintWriter(System.out));s.printFailuresTo(new PrintWriter(System.out));int aborted=System.getProperty("os.name").equals("Linux")?0:4;
  if(s.getTestsFoundCount()!=166||s.getTestsSucceededCount()!=166-aborted||s.getTestsSkippedCount()!=0||s.getTestsAbortedCount()!=aborted||s.getTestsFailedCount()!=0||s.getContainersFailedCount()!=0)throw new AssertionError("Incomplete native workflow checks");
 }
}
