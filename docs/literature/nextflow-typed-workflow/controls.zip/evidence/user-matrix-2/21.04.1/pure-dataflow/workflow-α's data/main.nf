nextflow.enable.dsl=2
params.outdir=null
workflow { new File(params.outdir,'pure.txt').text='pure\n' }
