/* Copyright (C) 2026 JLinAlg contributors; SPDX-License-Identifier: GPL-3.0-or-later */
package org.jlinalg.cli;
import static org.junit.jupiter.api.Assertions.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class NextflowSessionPointerTest {
    @TempDir Path temp;
    private Path root(String id,String status)throws Exception {
        Path root=temp.toRealPath();Files.createDirectory(root.resolve("attempts"));Files.createDirectory(root.resolve("attempts").resolve(id));NextflowFiles.writeJson(root.resolve("latest.json"),Map.of("attempt",id,"status",status));return root;
    }
    @Test void latestPointerNamesTheNewestRetainedAttempt()throws Exception {Path root=root("000001","COMPLETED");assertEquals("000001",NextflowWorkflow.readLatest(root).get("attempt"));}
    @Test void anOlderSuccessCannotHideANewerAttempt()throws Exception {Path root=root("000001","COMPLETED");Files.createDirectory(root.resolve("attempts/000002"));assertThrows(IOException.class,()->NextflowWorkflow.readLatest(root));assertThrows(IOException.class,()->NextflowBundle.verify(root,()->{}));}
    @Test void unknownAttemptMembersAreRejected()throws Exception {Path root=root("000001","COMPLETED");Files.createDirectory(root.resolve("attempts/unrecorded"));assertThrows(IOException.class,()->NextflowWorkflow.readLatest(root));}
    @Test void noncompletedLatestStateNeverFallsBackToSuccess()throws Exception {Path root=root("000002","SKIP3");Files.createDirectory(root.resolve("attempts/000001"));assertEquals("SKIP3",NextflowWorkflow.readLatest(root).get("status"));assertThrows(IOException.class,()->NextflowBundle.verify(root,()->{}));}
}
