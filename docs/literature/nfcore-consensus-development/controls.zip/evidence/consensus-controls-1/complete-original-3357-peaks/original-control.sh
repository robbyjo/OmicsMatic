set -euo pipefail
export LC_ALL=C.UTF-8
cd /mnt/d/projects/JLinAlg/build/literature-review/nfcore-runtime/consensus-controls-1/complete-original-3357-peaks
sort -T . -k1,1 -k2,2n SPT5_T0_R1_peaks.broadPeak SPT5_T0_R2_peaks.broadPeak SPT5_T15_R1_peaks.broadPeak SPT5_T15_R2_peaks.broadPeak | mergeBed -c 2,3,4,5,6,7,8,9 -o collapse,collapse,collapse,collapse,collapse,collapse,collapse,collapse > original.merged.txt
python /mnt/d/projects/JLinAlg/build/literature-review/nfcore-runtime/consensus-controls-1/original/macs2_merged_expand.py original.merged.txt SPT5_T0_R1,SPT5_T0_R2,SPT5_T15_R1,SPT5_T15_R2 original.boolean.txt --min_replicates 1
awk -v FS='	' -v OFS='	' 'FNR > 1 {print $1,$2,$3,$4,"0","+"}' original.boolean.txt > original.bed
printf 'GeneID\tChr\tStart\tEnd\tStrand\n' > original.saf
awk -v FS='	' -v OFS='	' 'FNR > 1 {print $4,$1,$2,$3,"+"}' original.boolean.txt >> original.saf
