set -euo pipefail
export LC_ALL=C.UTF-8
cd /mnt/d/projects/JLinAlg/build/literature-review/nfcore-runtime/consensus-controls-1/narrow-raw-relative-summits
sort -T . -k1,1 -k2,2n A_R1_peaks.narrowPeak A_R2_peaks.narrowPeak | mergeBed -c 2,3,4,5,6,7,8,9,10 -o collapse,collapse,collapse,collapse,collapse,collapse,collapse,collapse,collapse > original.merged.txt
python /mnt/d/projects/JLinAlg/build/literature-review/nfcore-runtime/consensus-controls-1/original/macs2_merged_expand.py original.merged.txt A_R1,A_R2 original.boolean.txt --min_replicates 1 --is_narrow_peak
awk -v FS='	' -v OFS='	' 'FNR > 1 {print $1,$2,$3,$4,"0","+"}' original.boolean.txt > original.bed
printf 'GeneID\tChr\tStart\tEnd\tStrand\n' > original.saf
awk -v FS='	' -v OFS='	' 'FNR > 1 {print $4,$1,$2,$3,"+"}' original.boolean.txt >> original.saf
