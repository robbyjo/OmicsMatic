# FAIL2 NO CONSENSUS COMPONENT RESULT

java.io.IOException: Required complete original output is missing or inconsistent: bwa/mergedLibrary/macs/narrowPeak/SPT5_T0_R1_peaks.narrowPeak (Expected Nextflow JSON object). Required action: confirm the exact peak kind, active original consensus branch and selected complete attempt; preserve existing outputs.

WARNING: Original ChIP-seq1.2.1 writes BED's zero-based Start directly to SAF. The native audit preserves this source convention and does not increment Start. Standard one-based SAF interpretation therefore differs by one base. Do not relabel or silently repair it; a coordinate conversion requires a separate declared analysis with original outputs retained.

Required action: this is a source-specific consensus component audit, with zero nf-core tool credit and no whole-pipeline scientific or biological admission. Preserve all original peaks, tokens, failures and coordinate conventions. FAIL2 means no consensus component result is admitted: correct the named cause and use a new audit path. Complete the original runtime/image and remaining scientific contracts before downstream claims. Hashes establish integrity, not execution authenticity. Cell Ranger remains excluded.
