import java.io.*;
import org.junit.platform.launcher.core.*;import org.junit.platform.launcher.listeners.*;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;
public class MemeOutputContractChecks {
 public static void main(String[] args)throws Exception {
  for(String name:new String[]{"org.jlinalg.sequence.MemeXml","org.jlinalg.sequence.TomtomResults","org.jlinalg.sequence.MemeDnaMotifs"})
   if(!Class.forName(name).getProtectionDomain().getCodeSource().getLocation().toURI().equals(new File(args[0]).toURI()))throw new AssertionError("Wrong actual JAR: "+name);
  var listener=new SummaryGeneratingListener();LauncherFactory.create().execute(LauncherDiscoveryRequestBuilder.request().selectors(selectClass("org.jlinalg.cli.MemeXmlTest"),selectClass("org.jlinalg.cli.TomtomResultsTest")).build(),listener);
  var summary=listener.getSummary();summary.printTo(new PrintWriter(System.out));summary.printFailuresTo(new PrintWriter(System.out));
  if(summary.getTestsFoundCount()!=73||summary.getTestsSucceededCount()!=73||summary.getTestsSkippedCount()!=0||summary.getTestsAbortedCount()!=0||summary.getTestsFailedCount()!=0||summary.getContainersFailedCount()!=0)throw new AssertionError("Incomplete native output contracts");
  System.out.println("COMPLETE_MEME_OUTPUT_CONTRACTS 73 NO_SKIPS NO_RUNTIME_ADMISSION");
 }
}
