from pathlib import Path
import urllib.request,urllib.parse,json,hashlib,time,datetime,traceback
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');O=A/'build/enrichr-high-impact-1/api-reference-4'
O.mkdir(exist_ok=False);events=[]
def pin(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def call(label,url,data=None,content_type=None):
    time.sleep(1)
    method='POST' if data is not None else 'GET'
    request=dict(label=label,method=method,url=url,body=pin(data or b''),content_type=content_type)
    if data is not None:(O/(label+'.request')).write_bytes(data)
    headers={'User-Agent':'OmicsMatic-Enrichr-synthetic-reference/1','Accept':'application/json, text/plain, */*'}
    if content_type:headers['Content-Type']=content_type
    try:
        with urllib.request.urlopen(urllib.request.Request(url,data=data,headers=headers,method=method),timeout=45) as r:
            raw=r.read(4194305);assert len(raw)<=4194304
            response=dict(status=r.status,final_url=r.geturl(),headers=dict(r.headers),**pin(raw))
        (O/(label+'.response')).write_bytes(raw);events.append(dict(request=request,response=response));return raw
    except Exception as e:
        if hasattr(e,'read'):
            raw=e.read(4194304);(O/(label+'.failure-response')).write_bytes(raw)
        events.append(dict(request=request,error=repr(e)));raise
def form(values):return urllib.parse.urlencode(values).encode()
def multipart(values):
    boundary='OmicsMaticEnrichrSyntheticReference20261119'
    parts=[]
    for key,value in values.items():parts.append(('--'+boundary+'\r\nContent-Disposition: form-data; name="'+key+'"\r\n\r\n'+value+'\r\n').encode())
    return b''.join(parts)+('--'+boundary+'--\r\n').encode(),'multipart/form-data; boundary='+boundary
try:
    library='MSigDB_Hallmark_2020';query=['TP53','BRCA1','BRCA2','ATM','ATR','CHEK1','CHEK2','RAD51']
    (O/'query.json').write_text(json.dumps(query,indent=2)+'\n',encoding='utf-8')
    gmt=call('library','https://maayanlab.cloud/Enrichr/geneSetLibrary?mode=text&libraryName='+library)
    sets={r[0]:r[2:] for r in [line.split('\t') for line in gmt.decode().splitlines()]}
    # Deliberately constructed synthetic background, not author preparation.
    selected_terms=[term for term in sets if term.upper() in ['DNA REPAIR','P53 PATHWAY']]
    assert len(selected_terms)==2,selected_terms
    background=sorted(set(query)|set(g for term in selected_terms for g in sets[term] if g))
    assert set(query)<=set(background) and len(background)>100
    (O/'background.json').write_text(json.dumps(background,indent=2)+'\n',encoding='utf-8')
    body,ctype=multipart(dict(list='\n'.join(query),description='OmicsMatic synthetic protocol qualification; no participant data'))
    user=json.loads(call('standard-add-list','https://maayanlab.cloud/Enrichr/addList',body,ctype))
    standard=json.loads(call('standard-enrich','https://maayanlab.cloud/Enrichr/enrich?'+urllib.parse.urlencode(dict(userListId=user['userListId'],backgroundType=library))))
    view=json.loads(call('standard-view','https://maayanlab.cloud/Enrichr/view?userListId='+str(user['userListId'])))
    speed=json.loads(call('background-add-list','https://maayanlab.cloud/speedrichr/api/addList',body,ctype))
    bg=json.loads(call('background-add-background','https://maayanlab.cloud/speedrichr/api/addbackground',form(dict(background='\n'.join(background))),'application/x-www-form-urlencoded'))
    params=dict(userListId=speed['userListId'],backgroundid=bg['backgroundid'],backgroundType=library)
    custom=json.loads(call('background-enrich-post','https://maayanlab.cloud/speedrichr/api/backgroundenrich',form(params),'application/x-www-form-urlencoded'))
    custom_get=json.loads(call('background-enrich-get','https://maayanlab.cloud/speedrichr/api/backgroundenrich?'+urllib.parse.urlencode(params)))
    assert custom_get.get('error')=='api endpoint not supported' and 'endpoint:' in custom_get
    assert len(standard[library])>0 and len(custom[library])>0
    assert all(len(row)==9 for row in standard[library]+custom[library])
    summary=dict(status='PASS_SYNTHETIC_LIVE_ENRICHR_STANDARD_POST_CUSTOM_AND_LIBRARY_PROTOCOL_CAPTURE',captured_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),library=library,query_size=len(query),background_size=len(background),background_definition='Union of the two explicitly selected downloaded terms plus the eight literal query IDs; synthetic construction',selected_terms=selected_terms,standard_rows=len(standard[library]),standard_row_widths=sorted(set(map(len,standard[library]))),background_rows=len(custom[library]),background_row_widths=sorted(set(map(len,custom[library]))),background_get_post_equal=False,documented_get_supported=False,documented_get_error=custom_get,verified_custom_route='POST as used by the pinned enrichR/backr sources; official smartAPI GET discrepancy retained',server_view=view,scientific_model_reimplemented=False,historical_author_execution=False,events=events)
    (O/'COMPLETED.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in summary.items() if k not in ['events','server_view']},indent=2),flush=True)
except Exception as e:
    code=3 if isinstance(e,(urllib.error.URLError,TimeoutError)) else 2
    (O/'FAILURE.json').write_text(json.dumps(dict(status='SKIP3_SERVICE_UNAVAILABLE' if code==3 else 'FAIL2_NO_REFERENCE_ADMITTED',error=repr(e),detail=traceback.format_exc(),events=events),indent=2)+'\n',encoding='utf-8')
    raise
