from pathlib import Path
p=Path('D:/projects/JLinAlg/build/rebuild_enrichr_component_20261119.py')
code=p.read_text().replace('component-build-2','component-build-3')
exec(compile(code,str(p)+'-V3','exec'))
