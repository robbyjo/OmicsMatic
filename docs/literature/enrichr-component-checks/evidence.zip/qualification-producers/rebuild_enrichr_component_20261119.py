from pathlib import Path
import subprocess,json,hashlib
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');B=A/'build/enrichr-high-impact-1';O=B/'component-build-2'
O.mkdir(exist_ok=False)
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
classes=O/'classes';classes.mkdir();junit=A/'build/nfcore-atacseq121-1/linux-test-runtime-1/junit-platform-console-standalone-1.13.4.jar'
javac=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/javac.exe');java=javac.with_name('java.exe')
sources=sorted((A/'src/main/java/org/jlinalg/enrichr').glob('*.java'))+sorted((A/'src/test/java/org/jlinalg/enrichr').glob('*.java'))
def run(label,args):
 p=subprocess.run([str(x) for x in args],capture_output=True,cwd=A)
 (O/(label+'.stdout')).write_bytes(p.stdout);(O/(label+'.stderr')).write_bytes(p.stderr)
 assert p.returncode==0,(label,p.returncode,p.stdout.decode(errors='replace')[-3000:],p.stderr.decode(errors='replace')[-3000:])
run('compile',[javac,'--release','17','-encoding','UTF-8','-cp',junit,'-d',classes,*sources])
dest=classes/'org/jlinalg/enrichr/api-reference-20261119.zip';dest.write_bytes((A/'src/test/resources/org/jlinalg/enrichr/api-reference-20261119.zip').read_bytes())
run('junit-windows21',[java,'-jar',junit,'execute','--class-path',classes,'--select-class','org.jlinalg.enrichr.EnrichrClientTest','--details','summary','--disable-ansi-colors','--reports-dir',O/'reports-windows21'])
print((O/'junit-windows21.stdout').read_text(),flush=True)
(O/'COMPLETED.json').write_text(json.dumps(dict(status='PASS_ENRICHR_STRUCTURED_FAILURE_COMPONENT_WINDOWS21',sources={p.relative_to(A).as_posix():pin(p) for p in sources},fixture=pin(dest),workflow_qualified=False,new_family_credit=0),indent=2)+'\n',encoding='utf-8')
