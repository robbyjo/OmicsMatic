from pathlib import Path
p=Path('D:/projects/JLinAlg/build/close_enrichr_component_20261119.py');code=p.read_text()
for old,new in [('component-closure-1','component-closure-3'),('component-qualification-1','component-qualification-3'),('component-build-1','component-build-3'),("('tests',15)","('tests',16)"),('packaged_windows21_tests=15','packaged_windows21_tests=16')]:
 assert old in code,old
 code=code.replace(old,new)
exec(compile(code,str(p)+'-V3','exec'))
