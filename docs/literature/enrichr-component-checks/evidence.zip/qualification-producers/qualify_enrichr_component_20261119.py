from pathlib import Path
import subprocess,json,hashlib,os,xml.etree.ElementTree as ET,zipfile
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');B=A/'build/enrichr-high-impact-1';O=B/'component-qualification-1'
O.mkdir(exist_ok=False);classes=B/'component-build-1/classes'
junit=A/'build/nfcore-atacseq121-1/linux-test-runtime-1/junit-platform-console-standalone-1.13.4.jar'
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def encoded(v):return (json.dumps(v,indent=2)+'\n').encode()
def run(label,args,env=None):
 p=subprocess.run([str(a) for a in args],cwd=A,capture_output=True,env=env)
 (O/(label+'.stdout')).write_bytes(p.stdout);(O/(label+'.stderr')).write_bytes(p.stderr)
 if p.returncode:
  print(p.stdout.decode(errors='replace')[-2200:]);print(p.stderr.decode(errors='replace')[-2200:]);raise RuntimeError((label,p.returncode))
 print('PASS',label,flush=True)
 return p
java25=Path('C:/Program Files/Java/jdk-25/bin/java.exe')
run('junit-windows25',[java25,'-jar',junit,'execute','--class-path',classes,'--select-class','org.jlinalg.enrichr.EnrichrClientTest','--details','summary','--disable-ansi-colors','--reports-dir',O/'reports-windows25'])
def linux(p):return '/mnt/d/'+str(p).replace('\\','/').split('D:/',1)[1]
wsl=['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--']
run('junit-linux21',wsl+['/usr/bin/java','-jar',linux(junit),'execute','--class-path',linux(classes),'--select-class','org.jlinalg.enrichr.EnrichrClientTest','--details','summary','--disable-ansi-colors','--reports-dir',linux(O/'reports-linux21')])
run('source-census-linux',wsl+['/usr/bin/env','GIT_DIR=/mnt/d/projects/JLinAlg/.git','GIT_WORK_TREE='+linux(A),'/usr/bin/python3','-B',linux(A/'tools/literature/enrichr_source_roles.py'),'--cache','/mnt/d/projects/JLinAlg/build/literature-review/xml','--out',linux(O/'source-census-linux')])
assert (O/'source-census-linux/CENSUS.json').read_bytes()==(B/'source-census-3/CENSUS.json').read_bytes()
example=A/'examples/enrichr-api/EnrichrApiExample.java';exampleclasses=O/'example-classes';exampleclasses.mkdir()
javac=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/javac.exe')
java=javac.with_name('java.exe')
run('example-compile',[javac,'--release','17','-encoding','UTF-8','-cp',classes,'-d',exampleclasses,example])
run('live-java-example',[java,'-cp',str(classes)+';'+str(exampleclasses),'EnrichrApiExample',O/'live-java-example','--allow-synthetic-upload'])
run('junit-summary', [java25,'-version'])
tests={}
for label,folder in [('windows21',B/'component-build-1/reports-windows21'),('windows25',O/'reports-windows25'),('linux21',O/'reports-linux21')]:
 totals=dict(tests=0,failures=0,errors=0,skipped=0)
 for p in folder.glob('TEST-*.xml'):
  tree=ET.parse(p).getroot()
  for key in totals:totals[key]+=int(tree.get(key,'0'))
 assert totals==dict(tests=15,failures=0,errors=0,skipped=0),(label,totals)
 tests[label]=totals
jar=O/'omicsmatic-enrichr-component-development.jar'
with zipfile.ZipFile(jar,'x',compression=zipfile.ZIP_DEFLATED) as z:
 z.writestr('META-INF/MANIFEST.MF','Manifest-Version: 1.0\r\nImplementation-Title: OmicsMatic Enrichr API component\r\nImplementation-Version: development-unadmitted\r\n\r\n')
 for p in sorted((classes/'org/jlinalg/enrichr').glob('*.class')):
  if not p.name.startswith('EnrichrClientTest'):z.write(p,p.relative_to(classes).as_posix())
sourcepins={p.relative_to(A).as_posix():pin(p) for p in sorted((A/'src/main/java/org/jlinalg/enrichr').glob('*.java'))+[example]}
(O/'COMPLETED.json').write_bytes(encoded(dict(status='PASS_ENRICHR_API_COMPONENT_45_TESTS_THREE_JVMS_AND_LIVE_JAVA',tests=tests,source_census_cross_host_identical=True,sources=sourcepins,component_jar=pin(jar),full_cli_workflow_qualified=False,catalog_changed=False,new_family_credit=0,whole_goal_complete=False)))
print((O/'COMPLETED.json').read_text(),flush=True)
