from pathlib import Path
import subprocess,json,gzip,hashlib,os,xml.etree.ElementTree as ET,zipfile
R=Path('D:/projects/JLinAlg');A=R/'build/high-impact-stats-1';B=A/'build/enrichr-high-impact-1';O=B/'component-closure-1'
O.mkdir(exist_ok=False)
def encoded(v):return (json.dumps(v,indent=2)+'\n').encode()
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def run(label,args,expected=0):
 p=subprocess.run([str(x) for x in args],cwd=A,capture_output=True)
 (O/(label+'.stdout')).write_bytes(p.stdout);(O/(label+'.stderr')).write_bytes(p.stderr)
 assert p.returncode==expected,(label,p.returncode,p.stdout.decode(errors='replace')[-1000:],p.stderr.decode(errors='replace')[-1000:])
 print('PASS',label,p.returncode,flush=True)
 return p
py=Path('C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')
source=A/'tools/literature/enrichr_source_roles.py'
canonical=json.loads((R/'build/git-publish/20261119-coloc-catalog-39/CANONICAL-AFTER.json').read_bytes())
assert all(pin(A/n)==w for n,w in canonical.items())
papers=json.loads((A/'docs/literature/omics-2023-2026/papers.json').read_bytes());first=papers[0]
original=R/'build/literature-review/xml'/(first['pmcid']+'.xml.gz');original_pin=pin(original)
missing=O/'missing-cache';missing.mkdir()
changed=O/'changed-cache';changed.mkdir();bad=changed/original.name
bad.write_bytes(gzip.compress(gzip.decompress(original.read_bytes())+b'\n'))
run('source-missing',[py,'-B',source,'--cache',missing,'--out',O/'source-missing'],3)
run('source-changed',[py,'-B',source,'--cache',changed,'--out',O/'source-changed'],2)
existing=O/'existing-output';existing.mkdir();(existing/'KEEP.txt').write_text('Preserve this existing output exactly.\n',encoding='utf-8');keep=pin(existing/'KEEP.txt')
run('source-output-collision',[py,'-B',source,'--cache',R/'build/literature-review/xml','--out',existing],2)
assert pin(existing/'KEEP.txt')==keep and set(p.name for p in existing.iterdir())=={'KEEP.txt'}
assert pin(original)==original_pin and all(pin(A/n)==w for n,w in canonical.items())
jar=B/'component-qualification-1/omicsmatic-enrichr-component-development.jar'
testdir=O/'test-only/org/jlinalg/enrichr';testdir.mkdir(parents=True)
classes=B/'component-build-1/classes/org/jlinalg/enrichr'
for name in ['EnrichrClientTest.class','api-reference-20261119.zip']:(testdir/name).write_bytes((classes/name).read_bytes())
with zipfile.ZipFile(jar) as z:
 for n in z.namelist():
  if n.endswith('.class'):assert z.read(n)==(B/'component-build-1/classes'/n).read_bytes()
 assert not any('Test' in n or n.endswith('.zip') for n in z.namelist())
junit=A/'build/nfcore-atacseq121-1/linux-test-runtime-1/junit-platform-console-standalone-1.13.4.jar'
java=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe')
run('packaged-junit-windows21',[java,'-jar',junit,'execute','--class-path',str(jar)+';'+str(O/'test-only'),'--select-class','org.jlinalg.enrichr.EnrichrClientTest','--details','summary','--disable-ansi-colors','--reports-dir',O/'reports-packaged-windows21'])
def linux(p):return '/mnt/d/'+str(p).replace('\\','/').split('D:/',1)[1]
wsl=['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--']
run('live-packaged-linux',wsl+['/usr/bin/java','-cp',linux(jar)+':'+linux(B/'component-qualification-1/example-classes'),'EnrichrApiExample',linux(O/'live-packaged-linux'),'--allow-synthetic-upload'])
for label,exe in [('windows21',java),('windows25',Path('C:/Program Files/Java/jdk-25/bin/java.exe'))]:run('java-version-'+label,[exe,'-version'])
run('java-version-linux21',wsl+['/usr/bin/java','-version'])
reference=B/'api-reference-4'
comparisons=[]
for folder in [B/'component-qualification-1/live-java-example',O/'live-packaged-linux']:
 assert (folder/'COMPONENT-PROBE-COMPLETED.properties').is_file()
 for seq,old in [('002','library.response'),('004','standard-enrich.response'),('008','background-enrich-post.response')]:
  a=(folder/(seq+'.response')).read_bytes();b=(reference/old).read_bytes()
  if old.endswith('enrich.response') or old=='background-enrich-post.response':assert json.loads(a)==json.loads(b),(str(folder),old)
  else:assert a==b
  comparisons.append(dict(folder=folder.name,capture=seq+'.response',reference=old,comparison='exact_bytes' if a==b else 'exact_parsed_json_values',current=pin(folder/(seq+'.response')),original=pin(reference/old)))
 assert set((folder/'query.txt').read_text().splitlines())==set((folder/'server-prepared-genes.txt').read_text().splitlines())
tree=ET.parse(O/'reports-packaged-windows21/TEST-junit-jupiter.xml').getroot()
assert all(int(tree.get(k,'0'))==n for k,n in [('tests',15),('failures',0),('errors',0),('skipped',0)])
(O/'COMPLETED.json').write_bytes(encoded(dict(status='PASS_ENRICHR_PACKAGED_COMPONENT_LINUX_LIVE_SOURCE_CONTROLS',source_controls=dict(missing=3,changed=2,existing_output=2),source_original_preserved=True,canonical_catalog_preserved=True,packaged_windows21_tests=15,live_packaged_linux=True,comparisons=comparisons,component_jar=pin(jar),full_cli_workflow_qualified=False,new_family_credit=0)))
print('PASS closure: exact independent source-result comparisons, input preservation, real packaged API',flush=True)
