from pathlib import Path
import json,hashlib
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1')
pins=json.loads((A/'build/enrichr-high-impact-1/component-build-3/COMPLETED.json').read_bytes())['sources']
def check():
 for n,w in pins.items():
  raw=(A/n).read_bytes();assert dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())==w,n
check()
p=Path('D:/projects/JLinAlg/build/qualify_enrichr_component_20261119.py');code=p.read_text()
for old,new in [('component-qualification-1','component-qualification-3'),('component-build-1','component-build-3'),('tests=15','tests=16'),('45_TESTS','48_TESTS')]:
 assert old in code,old
 code=code.replace(old,new)
exec(compile(code,str(p)+'-V3','exec'))
check()
