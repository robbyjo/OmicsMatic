import hashlib,json,shutil,tarfile,traceback,zipfile
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];out=b/'public-controls-1';out.mkdir();public=r/'docs/literature/native-dunn-development';built=b/'build-3'
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 return dict(bytes=p.stat().st_size,sha256=h.hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def copy(source,member):
 p=out/member;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists(),member;shutil.copyfile(source,p)
try:
 validation=json.loads((b/'validation-1/COMPLETED.json').read_bytes());assert validation['windows_junit']==validation['linux_junit']==dict(tests=20,errors=0,failures=0,skipped=0)
 guards=json.loads((built/'SOURCES.json').read_bytes());assert all(pin(r/n)==v for n,v in guards.items())
 for name in guards:copy(r/name,'current-source/'+name)
 intake=json.loads((b/'upstream-1/INTAKE.json').read_bytes());archive=b/'upstream-1/dunn.test_1.4.2.tar.gz';assert pin(archive)=={k:intake[k] for k in ['bytes','sha256']}
 with tarfile.open(archive,'r:gz') as t:
  for member,identity in intake['files'].items():
   p=b/'upstream-1/original'/member;assert pin(p)==identity and p.read_bytes()==t.extractfile(member).read(),member
 for p in b.glob('*.py'):copy(p,'drivers/'+p.name)
 for folder in ['upstream-1','r-probe-1','reference-1','reference-2','reference-3','reference-4','reference-audit-1','source-review-1','validation-1','build-1','build-2','build-3']:
  for p in (b/folder).rglob('*'):
   if not p.is_file() or any(x in p.relative_to(b/folder).parts for x in ['jar','test-report','test-classes']):continue
   copy(p,folder+'/'+p.relative_to(b/folder).as_posix())
 for name in ['SOURCE_REVIEW.json','REFERENCE_AUDIT.json']:
  source=b/'source-review-1/SOURCE_REVIEW.json' if name=='SOURCE_REVIEW.json' else b/'reference-audit-1/AUDIT.json';assert not (public/name).exists();shutil.copyfile(source,public/name)
 for name,source in [('LICENSE-GPL-2.txt',Path('C:/Program Files/R/R-4.6.1/share/licenses/GPL-2')),('LICENSE-GPL-3.txt',r/'docs/literature/fcs-reader-development/LICENSE-GPL-3.txt')]:
  assert not (public/name).exists();shutil.copyfile(source,public/name);copy(source,name)
 for p in public.iterdir():
  if p.is_file() and p.suffix=='.md':copy(p,'documentation/'+p.name)
 for name in ['docs/vignettes/dunn-comparisons.md','docs/vignettes/posthoc-comparisons.md','docs/literature/IMPLEMENTATION_PRIORITY.md']:copy(r/name,'documentation/'+Path(name).name)
 contents={p.relative_to(out).as_posix():pin(p) for p in sorted(out.rglob('*')) if p.is_file()};save(out/'INDEX.json',dict(schema_version=1,payload_files=contents))
 target=public/'controls.zip';assert not target.exists()
 with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in sorted(out.rglob('*')):
   if p.is_file():z.write(p,p.relative_to(out).as_posix())
 with zipfile.ZipFile(target) as z:
  assert len(z.namelist())==len(set(z.namelist()))==len(contents)+1;assert json.loads(z.read('INDEX.json'))['payload_files']==contents
  for name,identity in contents.items():
   raw=z.read(name);assert identity==dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()),name
 report=dict(validation,controls_zip=pin(target),indexed_payload_files=len(contents),all_zip_members_readback_verified=True,original_cran_archive=pin(archive),original_source_files_match_archive=True,reference_fixture_provenance=json.loads((r/'src/test/resources/org/jlinalg/stats/dunn/PROVENANCE.json').read_bytes()),reference_audit=pin(public/'REFERENCE_AUDIT.json'),source_review=pin(public/'SOURCE_REVIEW.json'),artifact_relative_private_path='build/common-stats-1/build-3/jar/omicsmatic-0.4.0.jar')
 save(public/'VALIDATION.json',report);(public/'SHA256SUMS').write_text(''.join(pin(p)['sha256']+'  '+p.name+'\n' for p in sorted(public.iterdir()) if p.is_file() and p.name!='SHA256SUMS'),encoding='utf8',newline='\n')
 assert all(pin(r/n)==v for n,v in guards.items());save(b/'EVIDENCE_CLOSED.json',dict(status='PASS_NATIVE_DUNN_EVIDENCE_CLOSED',controls=pin(target),payload_files=len(contents),validation=pin(public/'VALIDATION.json')));print('PASS indexed readback',pin(target),'payload files',len(contents),flush=True)
except Exception as e:save(b/'EVIDENCE_CLOSURE_FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc()));print(repr(e),flush=True);raise
