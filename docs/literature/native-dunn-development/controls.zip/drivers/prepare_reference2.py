import shutil
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];worker=r/'tools/literature/common_statistics/dunn_reference.R';saved=b/'reference-1/worker.R';assert not saved.exists();shutil.copyfile(worker,saved)
text=worker.read_text();assert text.count('method=tolower(method))')==1;worker.write_text(text.replace('method=tolower(method))','method=if(method %in% c("BH","BY"))method else tolower(method))'),newline='\n')
p=b/'run_reference2.py';assert not p.exists();p.write_text((b/'run_reference.py').read_text().replace("out=b/'reference-1'","out=b/'reference-2'"),newline='\n')
