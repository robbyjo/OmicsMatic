import csv,hashlib,json,math,shutil,subprocess,time,traceback,xml.etree.ElementTree as ET,zipfile
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];out=b/'validation-1';out.mkdir();built=b/'build-3';jar=built/'jar/omicsmatic-0.4.0.jar';jdk=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin')
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 return dict(bytes=p.stat().st_size,sha256=h.hexdigest())
def lp(p):return '/mnt/d/projects/JLinAlg/build/high-impact-stats-1/'+p.relative_to(r).as_posix()
def run(label,command):
 command=list(map(str,command));save(out/(label+'.command.json'),command);began=time.monotonic()
 with (out/(label+'.stdout')).open('xb') as so,(out/(label+'.stderr')).open('xb') as se:p=subprocess.run(command,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=300)
 save(out/(label+'.PROCESS.json'),dict(exit_code=p.returncode,seconds=time.monotonic()-began));assert p.returncode==0,label;print('PASS',label,flush=True)
def tsv(p):
 with p.open(encoding='utf8',newline='') as f:return list(csv.DictReader(f,delimiter='\t'))
def manifest(folder):
 marker=json.loads((folder/'COMPLETED.json').read_bytes());assert marker['manifest']==pin(folder/'manifest.json');report=json.loads((folder/'analysis.json').read_bytes());assert report['result_admitted'] is True
 entries=json.loads((folder/'manifest.json').read_bytes());actual={p.relative_to(folder).as_posix() for p in folder.rglob('*') if p.is_file()}-{'manifest.json','COMPLETED.json'};assert set(entries)==actual
 for name,identity in entries.items():assert pin(folder/name)==identity,name
try:
 counts=dict(tests=20,errors=0,failures=0,skipped=0);assert json.loads((built/'COMPLETED.json').read_bytes())['junit']==counts
 guards=json.loads((built/'SOURCES.json').read_bytes());assert all(pin(r/n)==v for n,v in guards.items())
 predecessor=r/'build/cytometry-methods-1/build-4/jar/omicsmatic-0.4.0.jar'
 with zipfile.ZipFile(predecessor) as a,zipfile.ZipFile(jar) as z:
  assert set(a.namelist()).issubset(z.namelist());changed=[n for n in a.namelist() if a.read(n)!=z.read(n)];assert changed==['org/jlinalg/cli/JLinAlgCli.class'],changed
  added=sorted(set(z.namelist())-set(a.namelist()));assert all(n.startswith(('org/jlinalg/stats/DunnComparisons','org/jlinalg/cli/DunnComparisonsCli','org/jlinalg/cli/PosthocToolsCli')) and n.endswith('.class') for n in added),added
 for cls in ['DunnComparisonsTest']:
  for p in (r/'build/classes/java/test/org/jlinalg/stats').glob(cls+'*.class'):
   target=out/'test-classes/org/jlinalg/stats'/p.name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
 for cls in ['DunnComparisonsCliTest','TukeyKramerCliTest']:
  for p in (r/'build/classes/java/test/org/jlinalg/cli').glob(cls+'*.class'):
   target=out/'test-classes/org/jlinalg/cli'/p.name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
 shutil.copytree(r/'build/resources/test/org/jlinalg/stats/dunn',out/'test-resources/org/jlinalg/stats/dunn')
 junit=r/'build/nfcore-atacseq121-1/linux-test-runtime-1/junit-platform-console-standalone-1.13.4.jar';prefix=['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--exec','/usr/bin/java','-Xmx2048m'];cp=lp(jar)+':'+lp(out/'test-classes')+':'+lp(out/'test-resources');cmd=prefix+['-jar',lp(junit),'execute','--class-path',cp]
 for cls in ['org.jlinalg.stats.DunnComparisonsTest','org.jlinalg.cli.DunnComparisonsCliTest','org.jlinalg.cli.TukeyKramerCliTest']:cmd+=['--select-class',cls]
 cmd+=['--reports-dir',lp(out/'linux-junit-reports'),'--disable-ansi-colors'];run('linux-junit',cmd)
 trees=[ET.parse(p).getroot() for p in (out/'linux-junit-reports').glob('TEST-*.xml')];linux={k:sum(int(t.attrib.get(k,0)) for t in trees) for k in counts};assert linux==counts,linux
 reference=b/'reference-4/reference';inputs={}
 for row in tsv(reference/'inputs.tsv'):inputs.setdefault(row['case'],[]).append(row['values'].split(','))
 expected=tsv(reference/'expected.tsv');models=[('balanced','all','HOLM'),('tied_unbalanced','control_first','BONFERRONI'),('tied_unbalanced','selected','BH'),('subnormal_three_groups','all','SIDAK')];proof=[]
 for index,(case,family,method) in enumerate(models):
  stem=out/('case-'+str(index));stem.mkdir();input=stem/'input.tsv';input.write_text('group\tvalue\n'+''.join('G'+str(g)+'\t'+x+'\n' for g,values in enumerate(inputs[case]) for x in values),encoding='utf8',newline='\n')
  selected=[row for row in expected if row['case']==case and row['family']==family and row['method']==method]
  request=dict(schema_version=1,input=str(input),out=str(stem/'windows-result'),design='independent',adjustment=method,family='all' if family=='all' else 'control' if family=='control_first' else 'specified',rank_population_declaration='Complete independent reference population for '+case,data_provenance='Independent baseR4.6.1 fixture; original observations and intended contrast family retained')
  if family=='control_first':request['control']='G0'
  if family=='selected':
   pairs=stem/'pairs.tsv';pairs.write_text('first_group\tsecond_group\n'+''.join('G'+x['first']+'\tG'+x['second']+'\n' for x in selected),encoding='utf8',newline='\n');request['comparisons']=str(pairs)
  save(stem/'windows-request.json',request);run('windows-case-'+str(index),[jdk/'java.exe','-Xmx2048m','-jar',jar,'posthoc-tools','dunn','--request',stem/'windows-request.json']);manifest(stem/'windows-result');actual=tsv(stem/'windows-result/comparisons.tsv');assert len(actual)==len(selected)
  mapping={('G'+x['first'],'G'+x['second']):x for x in selected}
  for row in actual:
   e=mapping[(row['first_group'],row['second_group'])]
   for observed,key in [('mean_rank_difference_second_minus_first','difference'),('standard_error','standard_error'),('z','z'),('log_p','log_p'),('log_adjusted_p','log_adjusted_p')]:assert math.isclose(float(row[observed]),float(e[key]),rel_tol=3e-11,abs_tol=3e-10),(case,observed,row,e)
  request['input']=lp(input);request['out']=lp(stem/'linux-result')
  if family=='selected':request['comparisons']=lp(pairs)
  save(stem/'linux-request.json',request);run('linux-case-'+str(index),prefix+['-jar',lp(jar),'posthoc-tools','dunn','--request',lp(stem/'linux-request.json')]);manifest(stem/'linux-result')
  for name in ['groups.tsv','comparisons.tsv']:assert pin(stem/'windows-result'/name)==pin(stem/'linux-result'/name),name
  proof.append(dict(case=case,family=family,adjustment=method,comparisons=len(selected),windows_linux_tables_byte_identical=True))
 assert all(pin(r/n)==v for n,v in guards.items())
 save(out/'COMPLETED.json',dict(status='PASS_NATIVE_DUNN_TWO_PLATFORM_PACKAGED_VALIDATION',artifact=pin(jar),predecessor=pin(predecessor),changed_predecessor_entries=changed,added_entries=added,all_unrelated_predecessor_members_byte_identical=True,windows_junit=counts,linux_junit=linux,overlapping_same_tests=True,independent_comparison_rows=4557,independent_models=36,analytic_nearly_all_tied_capacity_control_observations=2000000,packaged_cli_cases_each_platform=proof,all_manifests_and_captured_files_checked=True,new_catalog_integrations=0,whole_goal_complete=False));print('PASS packaged native Dunn validation',flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc()));print(repr(e),flush=True);raise
