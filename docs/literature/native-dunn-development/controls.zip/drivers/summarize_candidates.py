import json,re
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];rows=json.loads((b/'PRIMARY_STATISTICS_INTAKE.json').read_bytes())['matching_paragraphs']
for name in ['dunn','dunnett','sidak']:
 print('\nMETHOD',name)
 for row in rows:
  if name not in row['matches']:continue
  pattern=r'\b'+name+r'(?:[\u2019\u0027]s)?\b' if name!='sidak' else r'\b(?:Sidak|Šídák|Šidák|Šidak)\b'
  spans=[row['text'][max(0,m.start()-170):min(len(row['text']),m.end()+270)] for m in re.finditer(pattern,row['text'],re.I)]
  print(row['paper_id'],row['paragraph_index'],' | '.join(spans)[:950])
inv=json.loads((r/'docs/literature/omics-2023-2026/tool-inventory.json').read_bytes());print('INVENTORY_KEYS',list(inv[0]) if isinstance(inv[0],dict) else type(inv[0]).__name__)
print('PRISM_ROWS',[(x.get('tool_id'),x.get('name'),x.get('tool'),x.get('paper_count')) for x in inv if isinstance(x,dict) and re.search('graphpad|prism',str({k:v for k,v in x.items() if k in ['id','tool_id','name','tool']}),re.I)])
