import shutil
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];worker=r/'tools/literature/common_statistics/dunn_reference.R';shutil.copyfile(worker,b/'reference-2/worker.R');text=worker.read_text()
text=text.replace('raw_original <- list();raw_adjustment <- list();','raw_original <- list();original_failures <- list();raw_adjustment <- list();')
old='    o <- namespace$dunn.test(x=values,g=axis,method=method,kw=FALSE,label=TRUE,table=FALSE,list=FALSE,rmc=TRUE,altp=TRUE,interpret=FALSE)';assert text.count(old)==1
new='''    o <- tryCatch(namespace$dunn.test(x=values,g=axis,method=method,kw=FALSE,label=TRUE,table=FALSE,list=FALSE,rmc=TRUE,altp=TRUE,interpret=FALSE),error=function(e)e)
    if(inherits(o,"error")) {
      stopifnot(k==2L,method %in% c("holm","bh","by","hs"),grepl("incorrect number of dimensions",conditionMessage(o),fixed=TRUE))
      original_failures[[length(original_failures)+1L]] <- data.frame(case=id,method=method,status="ORIGINAL_ERROR_NO_RESULT",cause=conditionMessage(o))
      next
    }'''
text=text.replace(old,new);text=text.replace('write_table(raw_original,"original-dunn-test.tsv")','write_table(raw_original,"original-dunn-test.tsv");write_table(original_failures,"original-errors.tsv")');worker.write_text(text,newline='\n')
text=(b/'run_reference2.py').read_text().replace("out=b/'reference-2'","out=b/'reference-3'").replace('import hashlib,json,os,subprocess,time,traceback','import hashlib,json,os,shutil,subprocess,time,traceback');needle="original=b/'upstream-1/original/dunn.test';";assert text.count(needle)==1;text=text.replace(needle,needle+"shutil.copyfile(worker,out/'worker.R');")
p=b/'run_reference3.py';assert not p.exists();p.write_text(text,newline='\n')
