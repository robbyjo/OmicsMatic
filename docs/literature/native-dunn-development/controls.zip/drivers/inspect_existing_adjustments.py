from pathlib import Path
import json
r=Path(__file__).resolve().parents[2]
text=(r/'src/main/java/org/jlinalg/enrichment/FumaGeneSetEnrichment.java').read_text().splitlines();print('\n'.join(text[212:277]))
data=json.loads((r/'docs/literature/omics-2023-2026/tool-inventory.json').read_bytes());p=[t for t in data if 'prism' in t.get('name','').lower()];print('PRISM',[(x['id'],x['paper_count']) for x in p]);raw=json.loads((r/'build/common-stats-1/PRIMARY_STATISTICS_INTAKE.json').read_bytes());ids={x['paper_id'] for x in raw['matching_paragraphs'] if 'prism' in x['matches']};expected=set(p[0]['papers']);print('EXTRA',sorted(ids-expected),'MISSING',sorted(expected-ids))
for row in raw['matching_paragraphs']:
 if row['paper_id'] in ids-expected and 'prism' in row['matches']:print('EXTRA_CONTEXT',row['paper_id'],row['paragraph_index'],row['text'][:1500])
