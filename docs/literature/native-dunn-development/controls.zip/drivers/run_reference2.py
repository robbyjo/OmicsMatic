import hashlib,json,os,subprocess,time,traceback
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];out=b/'reference-2';out.mkdir()
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
try:
 runtime=Path('C:/Program Files/R/R-4.6.1/bin/Rscript.exe');worker=r/'tools/literature/common_statistics/dunn_reference.R';original=b/'upstream-1/original/dunn.test';guards={str(p):pin(p) for p in original.rglob('*') if p.is_file()};save(out/'SOURCES.json',dict(worker=pin(worker),original=guards,rscript=pin(runtime)))
 cmd=[str(runtime),'--vanilla',str(worker),str(original),str(out/'reference')];save(out/'command.json',cmd);env={k:v for k,v in os.environ.items() if not k.startswith('LC_')};env.update(LANG='C',LANGUAGE='C',LC_ALL='C');began=time.monotonic()
 with (out/'stdout').open('xb') as so,(out/'stderr').open('xb') as se:p=subprocess.run(cmd,env=env,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=300)
 save(out/'PROCESS.json',dict(exit_code=p.returncode,seconds=time.monotonic()-began));assert p.returncode==0
 marker=(out/'reference/COMPLETED.txt').read_text();assert marker.startswith('PASS_INDEPENDENT_DUNN_REFERENCE');assert all(pin(Path(n))==v for n,v in guards.items())
 save(out/'COMPLETED.json',dict(status='PASS_ORIGINAL_R_DUNN_RANKS_AND_STANDARD_ADJUSTMENT_REFERENCES',marker=marker,files={p.name:pin(p) for p in (out/'reference').iterdir() if p.is_file()},original_source_unchanged=True,locale='C',end_user_runtime='Java only; R/rlang are development oracles'))
 print(marker,flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc()));print(repr(e),flush=True);raise
