from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1]
for name in ['docs/vignettes/dunn-comparisons.md','docs/literature/native-dunn-development/README.md','docs/literature/native-dunn-development/WARNINGS.md','docs/literature/IMPLEMENTATION_PRIORITY.md','src/main/java/org/jlinalg/cli/DunnComparisonsCli.java']:
 p=r/name;text=p.read_text();replacements={'full250':'full 250','All250':'All 250','all250':'all 250','contains4557':'contains 4,557','across36':'across 36','R4.6.1':'R 4.6.1','dunn.test1.4.2':'dunn.test 1.4.2','size16790':'size 16,790','says1.4.2':'says 1.4.2','says1.4.1':'says 1.4.1','There are47':'There are 47','versus46':'versus 46','exit0':'exit 0','exceeds256':'exceeds 256','across36':'across 36','contains4557':'contains 4,557','eight\nstatistical':'eight\nstatistical','contain the\nname Dunn':'contain the\nname Dunn'}
 for x,y in replacements.items():text=text.replace(x,y)
 p.write_text(text,encoding='utf8',newline='\n')
p=b/'build_dunn_final.py';assert not p.exists();p.write_text((b/'build_dunn2.py').read_text().replace("out=b/'build-2'","out=b/'build-3'").replace('dict(tests=19,','dict(tests=20,'),newline='\n')
license=Path('C:/Program Files/R/R-4.6.1/share/licenses/GPL-2');print('GPL2',license.exists(),str(license));print('EXTRA_LICENSES',[p.name for p in license.parent.iterdir()] if license.parent.exists() else [])
