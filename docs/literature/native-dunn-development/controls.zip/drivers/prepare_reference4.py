from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];worker=r/'tools/literature/common_statistics/dunn_reference.R';text=worker.read_text()
assert 'subnormal_two_groups' not in text;text=text.replace('  underflow=list(rep(0,800),rep(1,800),rep(2,800)),','  underflow=list(rep(0,800),rep(1,800),rep(2,800)),\n  subnormal_two_groups=list(rep(0,730),rep(1,730)),\n  subnormal_three_groups=list(rep(0,488),rep(1,488),rep(2,488)),')
old='    result[p==0] <- lp[p==0]+log(n[p==0]);result[lp==0] <- 0';assert text.count(old)==1;text=text.replace(old,'    tiny <- lp < log(.Machine$double.xmin);result[tiny] <- lp[tiny]+log(n[tiny]);result[n==1] <- lp[n==1];result[lp==0] <- 0');worker.write_text(text,newline='\n')
p=b/'run_reference4.py';assert not p.exists();p.write_text((b/'run_reference3.py').read_text().replace("out=b/'reference-3'","out=b/'reference-4'"),newline='\n')
