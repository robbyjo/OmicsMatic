import collections,csv,json
from pathlib import Path
b=Path(__file__).resolve().parent;reference=b/'reference-4/reference';out=b/'reference-audit-1';out.mkdir()
def rows(name):
 with (reference/name).open(newline='') as f:return list(csv.DictReader(f,delimiter='\t'))
expected={}
for row in rows('expected.tsv'):
 if row['family']=='all':expected[(row['case'],row['method'],str(int(row['second'])+1)+' - '+str(int(row['first'])+1))]=row
records=[];summary=collections.Counter()
for row in rows('original-dunn-test.tsv'):
 method='HOLM_SIDAK' if row['method']=='hs' else row['method'].upper();e=expected[(row['case'],method,row['comparison'])];a=float(row['original_adjusted']);p=float(e['adjusted_p']);difference=abs(a-p)
 if difference>2e-13 or a==0 and p>0:
  kind='ORIGINAL_SIDAK_CANCELLATION_TO_ZERO' if a==0 and p>0 else 'ORIGINAL_NONCUMULATIVE_STEPWISE_ADJUSTMENT_DIFFERENCE';summary[kind]+=1;records.append(dict(original=row,standard=e,classification=kind))
assert records and all(r['original']['method'] in ['holm','bh','by','hs','sidak'] for r in records)
errors=rows('original-errors.tsv');assert errors and all(x['status']=='ORIGINAL_ERROR_NO_RESULT' and x['method'] in ['holm','bh','by','hs'] for x in errors)
report=dict(status='RETAINED_ORIGINAL_DUNN_TEST_DIFFERENCES_AND_ERRORS',original_package='dunn.test1.4.2',source_file_header='1.4.1 (literal unchanged header)',differences=dict(summary),complete_differences=records,original_two_group_errors=errors,base_R_standard_adjustments_authoritative_for_native_profile=True,original_source_modified=False,whole_package_parity_claimed=False)
(out/'AUDIT.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8');print('AUDIT',dict(summary),'original errors',len(errors))
