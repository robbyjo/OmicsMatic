from pathlib import Path
b=Path(__file__).resolve().parent;p=b/'build_dunn2.py';assert not p.exists();p.write_text((b/'build_dunn.py').read_text().replace("out=b/'build-1'","out=b/'build-2'"),newline='\n')
