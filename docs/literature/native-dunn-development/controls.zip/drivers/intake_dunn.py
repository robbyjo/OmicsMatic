import hashlib,json,tarfile,traceback,urllib.request
from pathlib import Path,PurePosixPath
b=Path(__file__).resolve().parent;out=b/'upstream-1';out.mkdir()
def save(name,value):(out/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf8')
try:
 url='https://cran.r-project.org/src/contrib/dunn.test_1.4.2.tar.gz'
 with urllib.request.urlopen(url,timeout=120) as response:raw=response.read(4194305);assert len(raw)<=4194304
 archive=out/'dunn.test_1.4.2.tar.gz';archive.write_bytes(raw);records={}
 with tarfile.open(archive,'r:gz') as t:
  for m in t:
   path=PurePosixPath(m.name);assert not path.is_absolute() and '..' not in path.parts;target=out/'original'/Path(*path.parts)
   if m.isdir():target.mkdir(parents=True,exist_ok=True)
   else:
    assert m.isfile();target.parent.mkdir(parents=True,exist_ok=True);data=t.extractfile(m).read();target.write_bytes(data);records[m.name]=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
 save('INTAKE.json',dict(status='PASS_ORIGINAL_CRAN_DUNN_SOURCE_INTAKE_ONLY',url=url,version='1.4.2',bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),files=records,scientific_analysis_executed=False))
 print('PASS original CRAN source',len(raw),hashlib.sha256(raw).hexdigest());print((out/'original/dunn.test/DESCRIPTION').read_text());print('RFILES',[p.name for p in (out/'original/dunn.test/R').iterdir()])
except Exception as e:save('FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc()));raise
