from pathlib import Path
import copy,hashlib,json,os,shutil,subprocess,sys,time
T=Path('/mnt/d/projects/JLinAlg/build/fu-1');B=T/'build/cytometry-intensity-629';D=Path('/tmp/jlinalg-cytometry-intensity-629-linux-2');D.mkdir();J=B/'normal-build-3/project-build/cli/omicsmatic-0.4.0.jar'
def save(p,x):p.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def mapped(s):return Path('/mnt/'+s[0].lower()+s[2:].replace('\\','/'))
def pin(p):
    h=hashlib.sha256()
    with p.open('rb') as stream:
        for block in iter(lambda:stream.read(1048576),b''):h.update(block)
    return dict(bytes=p.stat().st_size,sha256=h.hexdigest())
assert pin(J)['sha256']==json.loads((B/'normal-build-3/RESULT.json').read_bytes())['producer']['sha256']
def run(sub,label,args,expected=0):
    args=['/usr/bin/java','-Xmx2g','-jar',str(J),'flowjo-tools','SUMMARIZE',*map(str,args)];start=time.monotonic()
    with (sub/(label+'.stdout')).open('xb') as out,(sub/(label+'.stderr')).open('xb') as err:
        p=subprocess.Popen(args,cwd=D,stdin=subprocess.DEVNULL,stdout=out,stderr=err);save(sub/(label+'.PROCESS.json'),dict(pid=p.pid,arguments=args));code=p.wait()
    r=dict(exit_code=code,expected=expected,seconds=time.monotonic()-start,arguments=args);save(sub/(label+'.RESULT.json'),r);assert code==expected,(sub,label,code,expected);return r
results=[]
for win in json.loads((B/'packaged-windows-1/SUMMARY.json').read_bytes())['cases']:
    name=win['sample'].replace('/','-');sub=D/name;sub.mkdir();spec=json.loads((B/'packaged-windows-1'/name/'request.json').read_bytes());parent=mapped(spec['parent']);shutil.copytree(parent,sub/'source-parent');spec.update(parent=str(sub/'source-parent'),out=str(sub/'run'));save(sub/'request.json',spec)
    q=run(sub,'run',['--request',sub/'request.json']);v=run(sub,'verify',['VERIFY','--run',sub/'run']);r=run(sub,'replay',['REPLAY','--run',sub/'run','--out',sub/'replay']);rv=run(sub,'replay-verify',['VERIFY','--run',sub/'replay'])
    for member in ('statistics.tsv','selected-measurements.tsv'):
        assert pin(sub/'run'/member)==pin(sub/'replay'/member)==pin(B/'packaged-windows-1'/name/'run'/member),(name,member)
    a=json.loads((sub/'run/analysis.json').read_bytes());assert a==json.loads((sub/'replay/analysis.json').read_bytes())==json.loads((B/'packaged-windows-1'/name/'run/analysis.json').read_bytes());results.append(dict(sample=win['sample'],pass_all=True,run=q,verify=v,replay=r,replay_verify=rv,event_gate_pairs=win['event_gate_pairs'],complete_measurements=win['measurements'],all_exported_values_and_statistics_binary64_identical_to_windows=True));print(json.dumps(dict(sample=win['sample'],linux_pass=True)),flush=True)
control=D/'controls';control.mkdir();base=json.loads((D/'12-sample-1/request.json').read_bytes());checks=[]
for name,changes,expected in [('unknown-binning',dict(binning='VENDOR'),3),('other-quantile',dict(quantile_method='R_TYPE_8'),3),('value-capacity',dict(maximum_value_bytes=0),2),('missing-compensation',None,3),('strict-counts',dict(parent_count_policy='REQUIRE_SAVED_COUNTS_AGREE'),0)]:
    spec=copy.deepcopy(base);spec.update(out=str(control/name));spec.update(changes or {});
    if changes is None:spec['definitions'][0]['domain']='WSP_COMPENSATED_MEASUREMENT'
    request=control/(name+'.json');save(request,spec);q=run(control,name,['--request',request],expected);assert expected==0 or not (control/name/'COMPLETED.json').exists();checks.append(dict(name=name,**q))
save(D/'SUMMARY.json',dict(status='PASS_ALL_23_LINUX_SUMMARIZE_VERIFY_REPLAY_AND_FIVE_CONTROLS',cases=results,controls=checks,producer=pin(J),event_gate_pairs_per_pass=sum(r['event_gate_pairs'] for r in results),private_stage=str(D),whole_goal_complete=False))
inventory={p.relative_to(D).as_posix():pin(p) for p in sorted(D.rglob('*')) if p.is_file()};save(D/'EXPORT-INVENTORY.json',inventory);print(json.dumps(dict(status='READY_FOR_COMPLETE_BYTE_EXPORT',files=len(inventory)+1)),flush=True)

