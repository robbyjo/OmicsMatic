from pathlib import Path
import csv,json,math,os,subprocess
from handover_inventory_20261122_111 import save,pin
T=Path('D:/projects/JLinAlg/build/fu-1');B=T/'build/cytometry-intensity-629';D=B/'native-values-R-reference-1';D.mkdir();script=(B/'packaged-independent-reference-2/statistics.R').read_text().replace('read.delim(gzfile(args[1])','read.delim(args[1]');r=D/'statistics.R';r.write_text(script,encoding='utf-8');results=[]
def rows(p):
    with p.open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f,delimiter='\t'))
for case in json.loads((B/'packaged-windows-1/SUMMARY.json').read_bytes())['cases']:
    name=case['sample'].replace('/','-');native=B/'packaged-windows-1'/name;sub=D/name;sub.mkdir();spec=json.loads((native/'request.json').read_bytes());definitions=sub/'definitions.txt';definitions.write_text(''.join(d['id']+'\n' for d in spec['definitions']),encoding='utf-8');args=['C:/Program Files/R/R-4.6.1/bin/Rscript.exe','--vanilla',str(r),str(native/'run/selected-measurements.tsv'),str(definitions),str(sub/'R-statistics.tsv')]
    with (sub/'stdout').open('xb') as out,(sub/'stderr').open('xb') as err:p=subprocess.run(args,cwd=T,env=dict(os.environ,LC_ALL='C',LANG='C'),stdin=subprocess.DEVNULL,stdout=out,stderr=err)
    assert p.returncode==0;expected={(v['definition_id'],v['statistic']):v for v in rows(sub/'R-statistics.tsv')};compared=[]
    for actual in rows(native/'run/statistics.tsv'):
        e=expected[(actual['definition_id'],actual['statistic'])];assert all(actual[k]==e[k] for k in ('count','nonpositive_count','status')),(name,actual,e)
        if actual['status']=='DEFINED':
            a,v=float(actual['value']),float(e['value']);tol=max(64*math.ulp(v),3e-12*abs(v));assert abs(a-v)<=tol,(name,actual,e,tol);compared.append(dict(id=actual['definition_id'],statistic=actual['statistic'],native=a,R=v,tolerance=tol))
        else:assert actual['value']=='UNDEFINED'
    row=dict(status='PASS_R_FORMULAS_ON_EXACT_NATIVE_VALUES',sample=case['sample'],statistics=len(expected),count_nonpositive_count_and_status_exact=True,comparisons=compared,native_measurements=pin(native/'run/selected-measurements.tsv'),R_reference=pin(sub/'R-statistics.tsv'));save(sub/'RESULT.json',row);results.append(row);print(json.dumps(dict(sample=case['sample'],R_math_pass=True)),flush=True)
save(D/'SUMMARY.json',dict(status='PASS_ALL_23_R_FORMULA_CHECKS_ON_EXACT_NATIVE_VALUES',cases=results,statistics=sum(r['statistics'] for r in results),no_reference_functions_overridden=True,whole_goal_complete=False))
