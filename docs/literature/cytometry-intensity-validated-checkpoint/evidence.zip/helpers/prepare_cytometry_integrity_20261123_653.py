from pathlib import Path
R=Path('D:/projects/JLinAlg');B=R/'build'
source=(B/'control_cytometry_intensity_20261123_642.py').read_text(encoding='utf-8-sig').replace("D=B/'controls-windows-2'","D=B/'controls-windows-3'").replace("J=B/'normal-build-2/","J=B/'normal-build-3/")
extra='''
for name,field in [('forged-saved-count-flag','saved_count_agreement'),('forged-saved-count-annotation','saved_workspace_count')]:
    original=json.loads((B/'packaged-windows-1/01-sample-1/request.json').read_bytes());bad=D/name;shutil.copytree(original['parent'],bad);a=json.loads((bad/'analysis.json').read_bytes());assert a['saved_count_agreement'] is False
    if field=='saved_count_agreement':a.update(saved_count_agreement=True,saved_count_differences=[])
    else:a['gates'][0]['saved_workspace_count']='0'
    save(bad/'analysis.json',a);seal(bad);invoke(name+'-byte-verify',['VERIFY','--run',bad],0,profile=False)
    request(name+'-fresh-refusal',lambda s:s.update(parent=str(bad),parent_manifest_pin=pin(bad/'manifest.json'),parent_count_policy='REQUIRE_SAVED_COUNTS_AGREE' if field=='saved_count_agreement' else 'ALLOW_DECLARED_NATIVE_POPULATION'),2)
invoke('wrong-intensity-producer-refused',['REPLAY','--run',D/'strict-valid-parent/run','--out',D/'wrong-producer-replay'],2,jar=B/'normal-build-2/project-build/cli/omicsmatic-0.4.0.jar')
'''
source=source.replace("save(D/'SUMMARY.json'",extra+"\nsave(D/'SUMMARY.json'")
(B/'control_cytometry_intensity_20261123_654.py').write_text(source,encoding='utf-8',newline='\n')
linux=(B/'run_cytometry_linux_20261123_641.py').read_text().replace('jlinalg-cytometry-intensity-629-linux-1','jlinalg-cytometry-intensity-629-linux-2').replace("J=B/'normal-build-2/","J=B/'normal-build-3/").replace("assert pin(J)['sha256']=='1cfaacc1d8f07a77c0ef1b8a1cf12098c02737c55a35ca67d5e9a4813078ad5f'","assert pin(J)['sha256']==json.loads((B/'normal-build-3/RESULT.json').read_bytes())['producer']['sha256']").replace("B/'packaged-windows-1/","B/'packaged-windows-2/")
(B/'run_cytometry_linux_20261123_655.py').write_text(linux,encoding='utf-8',newline='\n')
driver=(B/'qualify_cytometry_linux_20261123_643.py').read_text().replace("D=B/'packaged-linux-1'","D=B/'packaged-linux-2'").replace('jlinalg-cytometry-intensity-629-linux-1','jlinalg-cytometry-intensity-629-linux-2').replace('run_cytometry_linux_20261123_641.py','run_cytometry_linux_20261123_655.py')
(B/'qualify_cytometry_linux_20261123_656.py').write_text(driver,encoding='utf-8',newline='\n')
print('Prepared separate final-producer qualifications; original attempts preserved.')
