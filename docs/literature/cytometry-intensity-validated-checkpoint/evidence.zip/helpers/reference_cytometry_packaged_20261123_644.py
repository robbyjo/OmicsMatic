from pathlib import Path
import csv,gzip,hashlib,importlib.metadata as M,json,os,subprocess,time
import numpy as np
import pandas as pd
import flowkit as fk
T=Path('D:/projects/JLinAlg/build/fu-1');B=T/'build/cytometry-intensity-629';P=T/'build/flowjo-595';D=B/'packaged-independent-reference-2';D.mkdir();S=P/'reference-source-1'
def save(p,x):p.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def pin(p):
    h=hashlib.sha256()
    with p.open('rb') as s:
        for b in iter(lambda:s.read(1048576),b''):h.update(b)
    return dict(bytes=p.stat().st_size,sha256=h.hexdigest())
assert M.version('flowkit')=='1.3.2';site=Path(fk.__file__).parent;files=[]
for p in (S/'src/flowkit').rglob('*.py'):assert p.read_bytes()==(site/p.relative_to(S/'src/flowkit')).read_bytes();files.append(p.relative_to(S/'src/flowkit').as_posix())
save(D/'ENVIRONMENT.json',dict(packages={x:M.version(x) for x in ['flowkit','flowio','flowutils','numpy','pandas','scipy']},all_35_installed_source_files_unchanged=len(files)==35,source_files=files,no_reference_functions_overridden=True))
R=D/'statistics.R';R.write_text(r'''args <- commandArgs(trailingOnly=TRUE)
options(warn=1, digits=17)
table <- read.delim(gzfile(args[1]), stringsAsFactors=FALSE, check.names=FALSE)
declared <- readLines(args[2])
out <- file(args[3], open="wt", encoding="UTF-8")
writeLines("definition_id\tstatistic\tcount\tnonpositive_count\tvalue\tstatus",out)
fmt <- function(x) if(is.finite(x)) trimws(formatC(x,digits=17,format="g")) else "UNDEFINED"
for(id in declared) {
  x <- table$value[table$definition_id==id]; n<-length(x); np<-sum(x<=0); stopifnot(all(is.finite(x)))
  mu<-mean(x); md<-median(x); st<-sd(x); q<-quantile(x,c(.1587,.8413),type=7,names=FALSE); h<-q[2]/2-q[1]/2; a<-mad(x,center=md,constant=1)
  v<-c(MEAN=mu,MEDIAN=md,SAMPLE_SD=st,CV_PERCENT=100*st/mu,CENTRAL_68_26_HALF_WIDTH=h,CENTRAL_68_26_CV_PERCENT=100*h/md,MAD=a,MAD_PERCENT=100*a/md,GEOMETRIC_MEAN=if(n>0&&np==0)exp(mean(log(x))) else NA_real_)
  for(metric in names(v)) {
    status<-if(n==0)"EMPTY_POPULATION" else if(metric %in% c("SAMPLE_SD","CV_PERCENT")&&n<2)"INSUFFICIENT_COUNT" else if(metric=="GEOMETRIC_MEAN"&&np>0)"NONPOSITIVE_VALUES" else if((metric=="CV_PERCENT"&&mu==0)||(metric %in% c("CENTRAL_68_26_CV_PERCENT","MAD_PERCENT")&&md==0))"ZERO_DENOMINATOR" else if(!is.finite(v[[metric]]))"NUMERIC_OVERFLOW" else "DEFINED"
    writeLines(paste(id,metric,n,np,fmt(v[[metric]]),status,sep="\t"),out)
  }
}
close(out)
''',encoding='utf-8')
summary=B/'packaged-windows-1/SUMMARY.json'
assert summary.is_file(),'Wait for all native cases; this driver creates a NEW evidence directory.'
results=[];cache={}
for row in json.loads(summary.read_bytes())['cases']:
    native=B/'packaged-windows-1'/row['sample'].replace('/','-');sub=D/row['sample'].replace('/','-');sub.mkdir();spec=json.loads((native/'request.json').read_bytes());parent=Path(spec['parent']);gr=json.loads((parent/'replay-request.json').read_bytes());meta=json.loads((P/'reference-analysis-1'/row['sample']/'REFERENCE.json').read_bytes());wsp=parent/'inputs/workspace.wsp';fcs=parent/'inputs/source.fcs';assert pin(fcs)==meta['source_pin']
    sample=fk.Sample(str(fcs),sample_id=meta['sample_name'],use_flowjo_labels=True,subsample=0);ws=fk.Workspace(str(wsp),fcs_samples=[sample],load_missing_file_data=True,find_fcs_files_from_wsp=False);raw=sample.get_events(source='raw');matrix=ws.get_comp_matrix(meta['sample_name']);comp=matrix.apply(sample) if matrix is not None else None
    with gzip.open(P/'reference-analysis-1'/row['sample']/'membership.u8.gz','rb') as z:membership=np.frombuffer(z.read(),dtype=np.uint8).reshape(meta['events'],len(meta['gates']))
    actual=pd.read_csv(native/'run/selected-measurements.tsv',sep='\t',float_precision='round_trip');checks=[];expected_file=sub/'independent-measurements.tsv.gz'
    with gzip.open(expected_file,'wt',encoding='utf-8',newline='') as stream:
        writer=csv.writer(stream,delimiter='\t',lineterminator='\n');writer.writerow(['definition_id','event_index','value'])
        for d in spec['definitions']:
            mask=np.ones(meta['events'],dtype=bool) if not d['gate_path'] else membership[:,next(i for i,g in enumerate(meta['gates']) if g['path']==d['gate_path'])].astype(bool);indices=np.flatnonzero(mask)+1;values=(raw if d['domain']=='AMPLIFIER_MEASUREMENT' else comp)[mask,sample.pnn_labels.index(d['parameter'])];a=actual[actual.definition_id==d['id']];assert np.array_equal(a.event_index.to_numpy(),indices);got=a.value.to_numpy();error=np.abs(got-values);tol=np.zeros_like(values) if d['domain']=='AMPLIFIER_MEASUREMENT' else 1e-9+2e-12*np.abs(values);assert np.all(error<=tol),(row['sample'],d['id'],float(error.max()));checks.append(dict(id=d['id'],count=len(values),domain=d['domain'],max_absolute_error=float(error.max()) if len(values) else 0.0,tolerance='exact binary64' if d['domain']=='AMPLIFIER_MEASUREMENT' else '1e-9 + 2e-12*abs(independent FlowKit compensated value)',all_event_indices_exact=True,native_nonpositive_count=int(np.sum(got<=0)),independent_nonpositive_count=int(np.sum(values<=0)),zero_boundary_differences=[dict(event_index=int(indices[k]),native=float(got[k]),independent=float(values[k])) for k in np.flatnonzero((got<=0)!=(values<=0))]))
            writer.writerows((d['id'],int(i),format(float(v),'.17g')) for i,v in zip(indices,values))
    (sub/'definitions.txt').write_text(''.join(d['id']+'\n' for d in spec['definitions']),encoding='utf-8');env=dict(os.environ,LC_ALL='C',LANG='C');args=['C:/Program Files/R/R-4.6.1/bin/Rscript.exe','--vanilla',str(R),str(expected_file),str(sub/'definitions.txt'),str(sub/'R-statistics.tsv')]
    with (sub/'R.stdout').open('xb') as out,(sub/'R.stderr').open('xb') as err:p=subprocess.run(args,cwd=T,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err)
    assert p.returncode==0,(row['sample'],p.returncode)
    def rows(p):
        with p.open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f,delimiter='\t'))
    expected={(r['definition_id'],r['statistic']):r for r in rows(sub/'R-statistics.tsv')};comparisons=[]
    for r in rows(native/'run/statistics.tsv'):
        e=expected[(r['definition_id'],r['statistic'])];assert all(r[k]==e[k] for k in ('count','status')),(row['sample'],r,e)
        if r['status']=='DEFINED':
            a,v=float(r['value']),float(e['value']);tol=1e-9+2e-10*abs(v);assert abs(a-v)<=tol,(row['sample'],r,e);comparisons.append(dict(id=r['definition_id'],statistic=r['statistic'],native=a,R_on_independent_values=v,absolute_error=abs(a-v),tolerance=tol))
        else:assert r['value']=='UNDEFINED'
    result=dict(status='PASS_ALL_SELECTED_VALUES_AND_INDEPENDENT_R_STATISTICS',sample=row['sample'],checks=checks,statistics=len(expected),defined_comparisons=comparisons,reference=pin(expected_file),raw_R_warnings_retained=True);save(sub/'RESULT.json',result);results.append(result);print(json.dumps(dict(sample=row['sample'],pass_independent=True,values=sum(c['count'] for c in checks))),flush=True)
save(D/'SUMMARY.json',dict(status='PASS_ALL_23_INDEPENDENT_PREPROCESS_COMPENSATION_POPULATIONS_AND_R_SUMMARIES',cases=results,independent_statistics=sum(r['statistics'] for r in results),vendor_runtime_executed=False,no_source_or_reference_function_changes=True,whole_goal_complete=False))

