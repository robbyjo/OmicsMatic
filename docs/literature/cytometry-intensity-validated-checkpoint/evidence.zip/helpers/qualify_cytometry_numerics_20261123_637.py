from pathlib import Path
import csv,json,math,subprocess,time
from handover_inventory_20261122_111 import save,pin
T=Path('D:/projects/JLinAlg/build/fu-1');B=T/'build/cytometry-intensity-629';D=B/'numerical-probe-2';D.mkdir()
J=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin');producer=json.loads((B/'normal-build-2/RESULT.json').read_text())['producer'];jar=Path(producer['path']);assert pin(jar)=={k:producer[k] for k in ('bytes','sha256')}
classes=D/'classes';classes.mkdir();source=B/'SummaryNumericalProbe.java'
def call(args,label):
    start=time.monotonic()
    with (D/(label+'.stdout')).open('xb') as out,(D/(label+'.stderr')).open('xb') as err:r=subprocess.run([str(a) for a in args],cwd=T,stdin=subprocess.DEVNULL,stdout=out,stderr=err)
    assert r.returncode==0,(label,r.returncode)
    return dict(exit_code=r.returncode,seconds=time.monotonic()-start,arguments=[str(a) for a in args])
compile=call([J/'javac.exe','-cp',jar,'-d',classes,source],'compile')
run=call([J/'java.exe','-cp',str(classes)+';'+str(jar),'org.jlinalg.cli.SummaryNumericalProbe',B/'numerical-reference-1/vectors.tsv',D/'java.tsv'],'run')
def rows(path):
    with path.open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f,delimiter='\t'))
raw={(r['case'],r['metric']):r for r in rows(B/'numerical-reference-1/R-reference.tsv') if r['metric']!='RAW_R_GEOMETRIC_MEAN'}
actual=rows(D/'java.tsv');assert len(raw)==len(actual)==910
differences=[];compared=[]
for r in actual:
    key=(r['case'],r['metric']);ref=raw[key];assert all(r[k]==ref[k] for k in ('count','nonpositive_count','status')),(r,ref)
    if r['status']!='DEFINED':assert r['value']=='UNDEFINED';continue
    a,e=float(r['value']),float(ref['value']);tol=max(64*math.ulp(e),3e-12*abs(e));entry=dict(case=key[0],metric=key[1],java=a,R=e,tolerance=tol,absolute_difference=abs(a-e),equal_within_tolerance=abs(a-e)<=tol);compared.append(entry)
    if abs(a-e)>tol:differences.append(entry)
assert {(r['case'],r['metric']) for r in differences}=={('scaled--200','SAMPLE_SD'),('scaled--200','CV_PERCENT')},differences
scaled={r['case']:r for r in rows(B/'scale-reference-1/R-scale-reference.tsv')};scale_checks=[]
for r in differences:
    e=float(scaled[r['case']]['rescaled_R_sd' if r['metric']=='SAMPLE_SD' else 'rescaled_R_cv']);tol=max(64*math.ulp(e),3e-12*abs(e));assert abs(r['java']-e)<=tol;scale_checks.append(dict(**r,separate_scaled_R=e,separate_scaled_tolerance=tol,separate_scaled_agreement=True,interpretation='Unscaled R sample variance underflows to zero; native scaled SD is retained as a documented numerical difference, not raw R parity.'))
save(D/'RAW-R-COMPARISON.json',dict(status='PASS_WITH_TWO_EXPLICIT_RAW_R_UNDERFLOW_DIFFERENCES',rows=910,raw_R_equal_rows=908,raw_R_differences=differences,defined_comparisons=compared,undefined_statuses_exact=True,no_absolute_tolerance_floor=True))
save(D/'SCALED-R-COMPARISON.json',dict(status='PASS_SEPARATE_SCALED_REFERENCE',checks=scale_checks,original_R_reference_modified=False))
save(D/'RESULT.json',dict(status='PASS_SCOPED_NUMERICAL_QUALIFICATION',compile=compile,run=run,producer=producer,source=pin(source),raw_reference=pin(B/'numerical-reference-1/R-reference.tsv'),scale_reference=pin(B/'scale-reference-1/R-scale-reference.tsv'),rows=910,raw_R_matching_rows=908,explicit_raw_R_differences=2,scaled_confirmation_rows=2,whole_vendor_tool_qualified=False));print(json.dumps(json.loads((D/'RESULT.json').read_text())),flush=True)
