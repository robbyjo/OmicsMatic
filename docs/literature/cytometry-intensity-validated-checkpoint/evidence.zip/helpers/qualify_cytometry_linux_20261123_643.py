from pathlib import Path
import hashlib,json,subprocess,tarfile,time
from handover_inventory_20261122_111 import save,pin
T=Path('D:/projects/JLinAlg/build/fu-1');B=T/'build/cytometry-intensity-629';D=B/'packaged-linux-1';D.mkdir();distro='JLinAlg-Omics-SAIGE-20261026';stage='/tmp/jlinalg-cytometry-intensity-629-linux-1'
def wsl(*args):return ['wsl','-d',distro,'--',*args]
args=wsl('/usr/bin/python3','-B','/mnt/d/projects/JLinAlg/build/run_cytometry_linux_20261123_641.py');start=time.monotonic()
with (D/'driver.stdout').open('xb') as out,(D/'driver.stderr').open('xb') as err:
    p=subprocess.Popen(args,cwd=T,stdin=subprocess.DEVNULL,stdout=out,stderr=err);save(D/'PROCESS.json',dict(pid=p.pid,arguments=args));code=p.wait()
save(D/'DRIVER-RESULT.json',dict(exit_code=code,seconds=time.monotonic()-start));assert code==0
archive=D/'linux-transfer.tar'
with archive.open('xb') as out,(D/'transfer.stderr').open('xb') as err:p=subprocess.run(wsl('/bin/tar','-C',stage,'-cf','-','.'),cwd=T,stdin=subprocess.DEVNULL,stdout=out,stderr=err)
assert p.returncode==0;target=D/'retained';target.mkdir();files={}
with tarfile.open(archive) as tf:
    for m in tf:
        name=Path(m.name);assert not name.is_absolute() and '..' not in name.parts and not m.issym() and not m.islnk();dest=target/name;assert dest.resolve().is_relative_to(target.resolve())
        if m.isdir():dest.mkdir(parents=True,exist_ok=True);continue
        assert m.isfile();dest.parent.mkdir(parents=True,exist_ok=True)
        with tf.extractfile(m) as inp,dest.open('xb') as out:
            for b in iter(lambda:inp.read(1048576),b''):out.write(b)
        files[name.as_posix()]=pin(dest)
inventory=json.loads((target/'EXPORT-INVENTORY.json').read_bytes());assert {k:v for k,v in files.items() if k!='EXPORT-INVENTORY.json'}==inventory
save(D/'EXPORT.json',dict(status='PASS_COMPLETE_LINUX_RESULT_BYTE_EXPORT',temporary_stage=stage,retained_export=str(target),files=files,transport=pin(archive),original_stage_retained=True));print(json.dumps(dict(status='PASS_LINUX_23_CASES_AND_FULL_EXPORT',files=len(files))),flush=True)
