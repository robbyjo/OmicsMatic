from pathlib import Path
R=Path('D:/projects/JLinAlg');p=R/'build/freeze_cytometry_intensity_20261123_648.py';s=p.read_text(encoding='utf-8-sig')
s=s.replace('F.mkdir();','F.mkdir(exist_ok=True);').replace("normal-build-2/RESULT.json","normal-build-3/RESULT.json").replace("normal-build-2/SOURCE-INPUTS.json","normal-build-3/SOURCE-INPUTS.json").replace('packaged-windows-1','packaged-windows-2').replace('packaged-linux-1','packaged-linux-2').replace('controls-windows-2','controls-windows-4').replace('for v in (1,2):','for v in (1,2,3):').replace("B/'CROSS-HOST.json'","B/'CROSS-HOST-2.json'").replace("'CROSS-HOST.json'","'CROSS-HOST-2.json'").replace("B/'CLAIM-LIMITS.json'","B/'CLAIM-LIMITS-2.json'").replace("'CLAIM-LIMITS.json'","'CLAIM-LIMITS-2.json'").replace("B/'ATTEMPTS.json'","B/'ATTEMPTS-2.json'").replace("'ATTEMPTS.json'","'ATTEMPTS-2.json'")
extra='''
with zipfile.ZipFile(B/'normal-build-2/project-build/cli/omicsmatic-0.4.0.jar') as old,zipfile.ZipFile(B/'normal-build-3/project-build/cli/omicsmatic-0.4.0.jar') as new:
    old_names={n for n in old.namelist() if not n.endswith('/')};new_names={n for n in new.namelist() if not n.endswith('/')};assert old_names==new_names;modified=[n for n in sorted(old_names) if old.read(n)!=new.read(n)];assert modified and all(n.startswith('org/jlinalg/cli/CytometryIntensityCli') for n in modified),modified
for row in windows['cases']:
    name=row['sample'].replace('/','-')
    for member in ('statistics.tsv','selected-measurements.tsv'):assert pin(B/'packaged-windows-2'/name/'run'/member)==pin(B/'packaged-windows-1'/name/'run'/member)
save(B/'INTEGRITY-EXTENSION.json',dict(status='PASS_SAVED_COUNT_METADATA_INTEGRITY_EXTENSION',modified_class_payloads=modified,mathematical_and_gate_class_payloads_unchanged=True,all_final_exports_equal_independently_qualified_exports=True,prior_exact_producer=pin(B/'normal-build-2/project-build/cli/omicsmatic-0.4.0.jar'),current_exact_producer=pin(B/'normal-build-3/project-build/cli/omicsmatic-0.4.0.jar'),old_context='intensity-predecessor-context-1/source',old_source_or_hashes_refreshed=False,source_flag_and_annotation_forgeries_refused=True))
'''
s=s.replace("sources=['src/main",extra+"\nsources=['src/main")
s=s.replace("for n in ['PRIMARY-CENSUS.json'","for n in ['INTEGRITY-EXTENSION.json','intensity-predecessor-context-1/COMPLETED.json','PRIMARY-CENSUS.json'")
s=s.replace("for n in helpers:add", "helpers+=['freeze_cytometry_intensity_20261123_648.py','control_cytometry_reader_20261123_649.py','build_cytometry_intensity_20261123_651.py','qualify_cytometry_packaged_20261123_652.py','prepare_cytometry_integrity_20261123_653.py','control_cytometry_intensity_20261123_654.py','run_cytometry_linux_20261123_655.py','qualify_cytometry_linux_20261123_656.py','control_cytometry_intensity_20261123_657.py','prepare_cytometry_freeze_20261123_658.py']\nfor n in helpers:add")
s=s.replace("for row in status:\n", "for row in status:\n")
(R/'build/freeze_cytometry_intensity_20261123_659.py').write_text(s,encoding='utf-8',newline='\n');compile(s,'freeze-final','exec');print('Prepared final checkpoint; original saved evidence is not overwritten.')
