from pathlib import Path
import copy,json,shutil,subprocess,time
from handover_inventory_20261122_111 import save,pin
T=Path('D:/projects/JLinAlg/build/fu-1');B=T/'build/cytometry-intensity-629';D=B/'controls-windows-4';D.mkdir();J=B/'normal-build-3/project-build/cli/omicsmatic-0.4.0.jar';old=T/'build/flowjo-595/normal-build-2/project-build/cli/omicsmatic-0.4.0.jar';base=json.loads((B/'packaged-windows-1/12-sample-1/request.json').read_bytes());cases=[];JAVA='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe'
def invoke(name,args,expected,jar=J,profile=True):
    args=[JAVA,'-Xmx2g','-jar',str(jar),'flowjo-tools',*(['SUMMARIZE'] if profile else []),*map(str,args)];start=time.monotonic()
    with (D/(name+'.stdout')).open('xb') as out,(D/(name+'.stderr')).open('xb') as err:r=subprocess.run(args,cwd=T,stdin=subprocess.DEVNULL,stdout=out,stderr=err)
    row=dict(name=name,exit_code=r.returncode,expected=expected,seconds=time.monotonic()-start,arguments=args);cases.append(row);assert r.returncode==expected,(name,r.returncode,expected);return row
def request(name,change,expected):
    s=copy.deepcopy(base);s['out']=str(D/name/'run');change(s);p=D/(name+'.request.json');save(p,s);row=invoke(name,['--request',p],expected);row['complete_marker']=(Path(s['out'])/'COMPLETED.json').exists();assert expected==0 or not row['complete_marker'] or name=='existing-output'
def seal(root):
    p=root/'manifest.json';m={x.relative_to(root).as_posix():pin(x) for x in sorted(root.rglob('*')) if x.is_file() and x.name not in ('manifest.json','COMPLETED.json')};save(p,m);done=json.loads((root/'COMPLETED.json').read_bytes());done['manifest']=pin(p);save(root/'COMPLETED.json',done)
request('missing-parent',lambda s:s.update(parent=str(D/'absent')),3)
request('unknown-binning',lambda s:s.update(binning='FLOWJO_VENDOR_DEFAULT'),3)
request('other-quantile',lambda s:s.update(quantile_method='R_TYPE_8'),3)
request('wrong-parent-pin',lambda s:s['parent_manifest_pin'].update(sha256='0'*64),2)
request('value-capacity',lambda s:s.update(maximum_value_bytes=0),2)
request('event-capacity',lambda s:s.update(maximum_events=99),2)
request('pair-capacity',lambda s:s.update(maximum_event_gate_pairs=0),2)
request('output-capacity',lambda s:s.update(maximum_output_bytes=1024),2)
request('parent-capacity',lambda s:s.update(maximum_parent_bytes=1024),2)
request('unknown-channel',lambda s:s['definitions'][0].update(parameter='missing literal'),2)
request('unknown-gate',lambda s:s['definitions'][0].update(gate_path=['missing gate']),2)
request('missing-compensation',lambda s:s['definitions'][0].update(domain='WSP_COMPENSATED_MEASUREMENT'),3)
request('existing-output',lambda s:s.update(out=base['out']),2)
request('duplicate-definition',lambda s:s['definitions'].append(copy.deepcopy(s['definitions'][0])),2)
request('strict-valid-parent',lambda s:s.update(parent_count_policy='REQUIRE_SAVED_COUNTS_AGREE'),0)
bad=D/'forged-parent';shutil.copytree(base['parent'],bad);m=(bad/'memberships.tsv').read_text();lines=m.splitlines();cells=lines[1].split('\t');assert cells[1]=='0';cells[1]='1';lines[1]='\t'.join(cells);(bad/'memberships.tsv').write_text('\n'.join(lines)+'\n',encoding='utf-8');a=json.loads((bad/'analysis.json').read_bytes());a['gates'][0]['count']=1;save(bad/'analysis.json',a);c=(bad/'counts.tsv').read_text().splitlines();c[1]='g0\t1\t100\t100\t1.0\t1.0\t-1';(bad/'counts.tsv').write_text('\n'.join(c)+'\n',encoding='utf-8');seal(bad)
invoke('forged-parent-byte-verify',['VERIFY','--run',bad],0,profile=False)
request('forged-parent-fresh-gate-refusal',lambda s:s.update(parent=str(bad),parent_manifest_pin=pin(bad/'manifest.json')),2)
tampered=D/'tampered-intensity';shutil.copytree(B/'packaged-windows-2/12-sample-1/run',tampered);p=tampered/'statistics.tsv';p.write_bytes(p.read_bytes()+b'changed\n');invoke('changed-intensity-refused',['VERIFY','--run',tampered],2)
relocated=D/'relocated-intensity';shutil.copytree(B/'packaged-windows-2/12-sample-1/run',relocated);invoke('relocated-intensity-verify',['VERIFY','--run',relocated],0);invoke('relocated-intensity-replay',['REPLAY','--run',relocated,'--out',D/'relocated-replay'],0);assert pin(relocated/'statistics.tsv')==pin(D/'relocated-replay/statistics.tsv')

for name,field in [('forged-saved-count-flag','saved_count_agreement'),('forged-saved-count-annotation','saved_workspace_count')]:
    original=json.loads((B/'packaged-windows-1/01-sample-1/request.json').read_bytes());bad=D/name;shutil.copytree(original['parent'],bad);a=json.loads((bad/'analysis.json').read_bytes());assert a['saved_count_agreement'] is False
    if field=='saved_count_agreement':a.update(saved_count_agreement=True,saved_count_differences=[])
    else:a['gates'][0]['saved_workspace_count']='0'
    save(bad/'analysis.json',a);seal(bad);invoke(name+'-byte-verify',['VERIFY','--run',bad],0,profile=False)
    request(name+'-fresh-refusal',lambda s:s.update(parent=str(bad),parent_manifest_pin=pin(bad/'manifest.json'),parent_count_policy='REQUIRE_SAVED_COUNTS_AGREE' if field=='saved_count_agreement' else 'ALLOW_DECLARED_NATIVE_POPULATION'),2)
invoke('wrong-intensity-producer-refused',['REPLAY','--run',D/'strict-valid-parent/run','--out',D/'wrong-producer-replay'],2,jar=B/'normal-build-2/project-build/cli/omicsmatic-0.4.0.jar')

save(D/'SUMMARY.json',dict(status='PASS_ACTUAL_PACKAGED_BOUNDARY_AND_RELOCATION_CONTROLS',cases=cases,forged_parent_metadata_verification_passed=True,forged_parent_fresh_scientific_evaluation_refused=True,exact_original_inputs_changed=False,whole_goal_complete=False));print(json.dumps(dict(passed=len(cases))),flush=True)


