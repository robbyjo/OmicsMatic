from pathlib import Path
import importlib.util,json,shutil
from handover_inventory_20261122_111 import save,pin
T=Path('D:/projects/JLinAlg/build/fu-1');B=T/'build/cytometry-intensity-629';D=B/'reader-controls-1';D.mkdir();F=T/'docs/literature/cytometry-intensity-checkpoint';S=D/'source';S.mkdir();state=json.loads((F/'STATUS.json').read_bytes());names=set(state['source_code'])|{p.relative_to(T).as_posix() for p in F.iterdir() if p.is_file()}
for n in names:
    target=S/n;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(T/n,target);assert pin(target)==pin(T/n)
spec=importlib.util.spec_from_file_location('reader',T/'tools/literature/verify_cytometry_intensity_checkpoint.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);cases=[]
def attempt(name,expected,jar=None):
    try:r=m.verify(S,jar);assert expected=='PASS',(name,'unexpected pass');cases.append(dict(name=name,status='PASS'))
    except ValueError as e:assert expected=='REFUSE',(name,e);cases.append(dict(name=name,status='REFUSE',cause=str(e)))
attempt('complete-public-packet','PASS');attempt('wrong-producer','REFUSE',T/'build/cytometry-intensity-629/normal-build-1/project-build/cli/omicsmatic-0.4.0.jar')
p=S/'docs/literature/cytometry-intensity-checkpoint/evidence.zip';original=p.read_bytes();p.write_bytes(original+b'changed');attempt('changed-archive','REFUSE');p.write_bytes(original)
p=S/'src/main/java/org/jlinalg/cytometry/CytometryIntensitySummary.java';original=p.read_bytes();p.write_bytes(original+b'// changed\n');attempt('changed-scientific-source','REFUSE');p.write_bytes(original)
p=S/'docs/literature/cytometry-intensity-checkpoint/STATUS.json';original=p.read_bytes();s=json.loads(original);s['vendor_statistics_qualified']=True;save(p,s);attempt('expanded-vendor-claim','REFUSE');p.write_bytes(original);s=json.loads(original);s['catalog_admitted']=True;save(p,s);attempt('unadmitted-catalog-credit','REFUSE');p.write_bytes(original);attempt('restored-original-snapshot','PASS')
save(D/'SNAPSHOT-FILES.json',{n:pin(S/n) for n in sorted(names)});save(D/'RESULT.json',dict(status='PASS_PUBLIC_READER_AND_FIVE_REFUSALS',cases=cases,original_public_sources_unchanged=all(pin(T/n)==pin(S/n) for n in names),scientific_fits_reexecuted=False));print(json.dumps(dict(checks=len(cases))),flush=True)
