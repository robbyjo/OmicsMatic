from pathlib import Path
import csv,json,subprocess,time,xml.etree.ElementTree as E
from handover_inventory_20261122_111 import save,pin
T=Path('D:/projects/JLinAlg/build/fu-1');B=T/'build/cytometry-intensity-629';P=T/'build/flowjo-595';D=B/'packaged-windows-2';D.mkdir();J=B/'normal-build-3/project-build/cli/omicsmatic-0.4.0.jar';producer=pin(J);assert producer['sha256']==json.loads((B/'normal-build-3/RESULT.json').read_bytes())['producer']['sha256']
JAVA='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe'
statistics=['MEAN','MEDIAN','SAMPLE_SD','CV_PERCENT','CENTRAL_68_26_HALF_WIDTH','CENTRAL_68_26_CV_PERCENT','MAD','MAD_PERCENT','GEOMETRIC_MEAN']
def run(sub,name,args):
    started=time.monotonic();args=[JAVA,'-Xmx2g','-jar',str(J),'flowjo-tools','SUMMARIZE',*map(str,args)]
    with (sub/(name+'.stdout')).open('xb') as out,(sub/(name+'.stderr')).open('xb') as err:
        p=subprocess.Popen(args,cwd=T,stdin=subprocess.DEVNULL,stdout=out,stderr=err);save(sub/(name+'.PROCESS.json'),dict(pid=p.pid,arguments=args));code=p.wait()
    row=dict(exit_code=code,seconds=time.monotonic()-started,arguments=args);save(sub/(name+'.RESULT.json'),row);assert code==0,(str(sub),name,code);return row
results=[]
cases=json.loads((P/'packaged-windows-3/SUMMARY.json').read_bytes())['cases']
for case in sorted(cases,key=lambda c:(c['case']!=12,c['case']!=7,c['case'],c['sample'])):
    sub=D/case['sample'].replace('/','-');sub.mkdir();parent=Path(case['retained_evidence_directory'])/'run';meta=json.loads((parent/'analysis.json').read_bytes());gate=json.loads((parent/'replay-request.json').read_bytes());defs=[]
    def add(id,path,param,domain):defs.append(dict(id=id,gate_path=path,parameter=param,domain=domain,statistics=statistics))
    add('all-raw',[],meta['mapped_channels'][0],'AMPLIFIER_MEASUREMENT')
    root=E.parse(parent/'inputs/workspace.wsp').getroot();sample=next(s for s in root.find('SampleList') if s.find('SampleNode').attrib['sampleID']==gate['sample_id']);spectrum=next((x for x in sample.iter() if x.tag.rsplit('}',1)[-1]=='spilloverMatrix'),None)
    channels=[]
    if spectrum is not None:
        params=next((x for x in spectrum if x.tag.rsplit('}',1)[-1]=='parameters'),None)
        if params is not None:channels=[next(v for k,v in x.attrib.items() if k.rsplit('}',1)[-1]=='name') for x in params]
    channels=[x.replace('/','_') for x in channels];channels=[x for x in channels if x in meta['mapped_channels']]
    param=channels[case['case']%len(channels)] if channels else meta['mapped_channels'][-1];domain='WSP_COMPENSATED_MEASUREMENT' if channels else 'AMPLIFIER_MEASUREMENT'
    if channels:add('all-compensated',[],param,domain)
    for i,g in enumerate(meta['gates']):
        if i in (0,len(meta['gates'])//2,len(meta['gates'])-1):add('gate-'+str(i),g['path'],param,domain)
    spec=dict(schema=1,profile='native-cytometry-intensity-unbinned-v1',parent=str(parent),parent_manifest_pin=pin(parent/'manifest.json'),out=str(sub/'run'),binning='NONE',quantile_method='R_TYPE_7',parent_count_policy='ALLOW_DECLARED_NATIVE_POPULATION',definitions=defs,measurement_units='Amplifier preprocessing from exact captured parent; compensated channels use only its sample-local WSP spectrum; no display transform.',statistics_provenance='Explicit complete unweighted artificial/public-fixture profile; R type 7; not vendor-binned statistics or paper-level replication.',export_measurements=True,maximum_output_bytes=1073741824)
    save(sub/'request.json',spec);q=run(sub,'run',['--request',sub/'request.json']);v=run(sub,'verify',['VERIFY','--run',sub/'run']);rp=run(sub,'replay',['REPLAY','--run',sub/'run','--out',sub/'replay']);rv=run(sub,'replay-verify',['VERIFY','--run',sub/'replay'])
    assert pin(sub/'run/statistics.tsv')==pin(B/'packaged-windows-1'/sub.name/'run/statistics.tsv');assert pin(sub/'run/selected-measurements.tsv')==pin(B/'packaged-windows-1'/sub.name/'run/selected-measurements.tsv');a=json.loads((sub/'run/analysis.json').read_bytes());ra=json.loads((sub/'replay/analysis.json').read_bytes());assert a==ra;assert a['fresh_parent_memberships_and_counts_equal'] and a['vendor_statistics_qualified'] is False
    for name in ('statistics.tsv','selected-measurements.tsv'):assert pin(sub/'run'/name)==pin(sub/'replay'/name)
    row=dict(case=case['case'],sample=case['sample'],pass_all=True,run=q,verify=v,replay=rp,replay_verify=rv,definitions=len(defs),measurements=a['complete_selected_values'],events=a['complete_source_events'],event_gate_pairs=meta['event_gate_pairs'],undefined=a['undefined_requested_statistics'],compensated_channels_selected=channels and [param] or [],parent_saved_count_agreement=a['parent_saved_count_agreement'],statistics_pin=pin(sub/'run/statistics.tsv'),measurements_pin=pin(sub/'run/selected-measurements.tsv'));save(sub/'QUALIFICATION.json',row);results.append(row);print(json.dumps(dict(sample=case['sample'],pass_all=True,definitions=len(defs),events=row['events'])),flush=True)
assert len(results)==23;save(D/'SUMMARY.json',dict(status='PASS_ALL_23_PACKAGED_SUMMARIZE_VERIFY_REPLAY_CASES',cases=results,producer=producer,events_per_pass=sum(r['events'] for r in results),event_gate_pairs_per_pass=sum(r['event_gate_pairs'] for r in results),measurements_per_pass=sum(r['measurements'] for r in results),new_family_credit=0,new_reviews=0,whole_goal_complete=False))

