from pathlib import Path
import hashlib,json,os,subprocess,sys
import numpy as np
from handover_inventory_20261122_111 import save,pin
T=Path('D:/projects/JLinAlg/build/fu-1');B=T/'build/cytometry-intensity-629';D=B/'numerical-reference-1';D.mkdir();rscript=Path('C:/Program Files/R/R-4.6.1/bin/Rscript.exe');assert rscript.is_file();rng=np.random.default_rng(84131587)
vectors={'empty':[],'single-positive':[7.0],'single-zero':[0.0],'odd-signed':[-2,0,2],'even-positive':[1,2,3,4],'all-negative':[-9,-4,-2,-1],'all-zero':[0.0]*11,'ties':[1,1,1,1,2,2,2,19],'signed-zero':[-0.0,0.0]}
for n in (2,3,4,5,10,31,100,257,1024):
    for kind in ('normal','lognormal','uniform','integers'):
        x=rng.normal(-.25,3,n) if kind=='normal' else rng.lognormal(1,2,n) if kind=='lognormal' else rng.uniform(-1000,1000,n) if kind=='uniform' else rng.integers(-4,5,n).astype(float);vectors[kind+'-'+str(n)]=x.tolist()
for exponent in (-200,-100,-10,10,100,150):vectors['scaled-'+str(exponent)]=(rng.normal(2,1,99)*10.0**exponent).tolist()
for magnitude in (1e12,1e100,1e150):
    step=np.spacing(magnitude);vectors['offset-'+str(magnitude)]=[magnitude+i*step for i in (-4,-2,-1,0,1,2,4)]
data=D/'vectors.tsv'
with data.open('x',encoding='utf-8',newline='\n') as stream:
    for name,x in vectors.items():stream.write(name+'\t'+','.join(format(float(v),'.17g') for v in x)+'\n')
save(D/'INPUTS.json',dict(seed=84131587,cases=len(vectors),vectors=vectors,source='Artificial independent numerical controls; no cohort data',reference_quantile='R stats::quantile type=7, na.rm=FALSE, names=FALSE',native_geometric_domain='strictly positive values only; raw R geometric mean also retained separately'))
program=r'''args <- commandArgs(trailingOnly=TRUE)
options(warn=1, digits=17)
lines <- readLines(args[1], warn=TRUE)
out <- file(args[2], open="wt", encoding="UTF-8")
writeLines("case\tmetric\tcount\tnonpositive_count\tvalue\tstatus", out)
fmt <- function(x) {if(is.nan(x)) "NaN" else if(is.na(x)) "NA" else if(is.infinite(x)) if(x>0) "Inf" else "-Inf" else trimws(formatC(x, digits=17, format="g"))}
ps <- c(0,.01,.1587,.25,.5,.8413,.99,1)
pl <- c("0","0.01","0.1587","0.25","0.5","0.8413","0.99","1")
for(line in lines) {
  split <- strsplit(line,"\t",fixed=TRUE)[[1]]
  id <- split[1]; x <- if(length(split)<2 || split[2]=="") numeric(0) else scan(text=split[2],sep=",",quiet=TRUE)
  stopifnot(all(is.finite(x)))
  n <- length(x); np <- sum(x<=0)
  mu <- mean(x); md <- median(x); st <- sd(x)
  qs <- quantile(x,probs=c(.1587,.8413),type=7,names=FALSE,na.rm=FALSE)
  half <- qs[2]/2-qs[1]/2
  mad0 <- mad(x, center=md, constant=1, na.rm=FALSE)
  raw.geo <- exp(mean(log(x)))
  values <- c(MEAN=mu, MEDIAN=md, SAMPLE_SD=st, CV_PERCENT=100*st/mu,
    CENTRAL_68_26_HALF_WIDTH=half, CENTRAL_68_26_CV_PERCENT=100*half/md,
    MAD=mad0, MAD_PERCENT=100*mad0/md, GEOMETRIC_MEAN=if(n>0 && np==0) raw.geo else NA_real_)
  for(metric in names(values)) {
    v <- values[[metric]]
    status <- if(n==0) "EMPTY_POPULATION" else if(metric %in% c("SAMPLE_SD","CV_PERCENT") && n<2) "INSUFFICIENT_COUNT" else if(metric=="GEOMETRIC_MEAN" && np>0) "NONPOSITIVE_VALUES" else if((metric=="CV_PERCENT" && mu==0)||(metric %in% c("CENTRAL_68_26_CV_PERCENT","MAD_PERCENT") && md==0)) "ZERO_DENOMINATOR" else if(!is.finite(v)) "NUMERIC_OVERFLOW" else "DEFINED"
    writeLines(paste(id,metric,n,np,fmt(v),status,sep="\t"),out)
  }
  writeLines(paste(id,"RAW_R_GEOMETRIC_MEAN",n,np,fmt(raw.geo),"RAW_REFERENCE_NOT_REPLACED",sep="\t"),out)
  if(n>0) {
    q <- quantile(x,probs=ps,type=7,names=FALSE,na.rm=FALSE)
    for(j in seq_along(q))writeLines(paste(id,paste0("QUANTILE_",pl[j]),n,np,fmt(q[j]),"DEFINED",sep="\t"),out)
  }
}
close(out)
writeLines(c(capture.output(sessionInfo()),capture.output(R.version)),args[3])
saveRDS(list(mean=base::mean,median=stats::median,sd=stats::sd,quantile=stats::quantile,mad=stats::mad),args[4],version=3)
'''
(D/'reference.R').write_text(program,encoding='utf-8');env=dict(os.environ,TMPDIR=str(D/'tmp'));(D/'tmp').mkdir();args=[str(rscript),'--vanilla',str(D/'reference.R'),str(data),str(D/'R-reference.tsv'),str(D/'R-session.txt'),str(D/'R-functions.rds')]
with (D/'stdout').open('xb') as out,(D/'stderr').open('xb') as err:p=subprocess.run(args,cwd=T,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err)
result=dict(status='PASS_INDEPENDENT_R_REFERENCE' if p.returncode==0 else 'REFERENCE_FAILED',exit_code=p.returncode,arguments=args,rscript=pin(rscript),cases=len(vectors),reference_functions_overridden=False,raw_warnings_retained=True)
if p.returncode==0:result.update(reference=pin(D/'R-reference.tsv'),session=pin(D/'R-session.txt'),functions_snapshot=pin(D/'R-functions.rds'))
save(D/'RESULT.json',result);print(json.dumps(result),flush=True);raise SystemExit(p.returncode)
