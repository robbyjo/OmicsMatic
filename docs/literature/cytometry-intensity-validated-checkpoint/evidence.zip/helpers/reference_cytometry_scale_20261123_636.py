from pathlib import Path
import json,os,subprocess
from handover_inventory_20261122_111 import save,pin
T=Path('D:/projects/JLinAlg/build/fu-1');B=T/'build/cytometry-intensity-629';D=B/'scale-reference-1';D.mkdir();r=Path('C:/Program Files/R/R-4.6.1/bin/Rscript.exe')
code=r'''args<-commandArgs(trailingOnly=TRUE)
options(warn=1,digits=17)
out<-file(args[2],open="wt",encoding="UTF-8")
writeLines("case\tscale\traw_R_sd\traw_R_cv\trescaled_R_sd\trescaled_R_cv",out)
fmt<-function(x) trimws(formatC(x,digits=17,format="g"))
for(line in readLines(args[1])) {
 f<-strsplit(line,"\t",fixed=TRUE)[[1]]
 if(!startsWith(f[1],"scaled-"))next
 x<-scan(text=f[2],sep=",",quiet=TRUE);scale<-max(abs(x));z<-x/scale
 writeLines(paste(f[1],fmt(scale),fmt(sd(x)),fmt(100*sd(x)/mean(x)),fmt(sd(z)*scale),fmt(100*sd(z)/mean(z)),sep="\t"),out)
}
close(out)
saveRDS(getS3method("quantile","default"),args[3],version=3)
writeLines(deparse(body(getS3method("quantile","default"))),args[4])
'''
(D/'scale-reference.R').write_text(code,encoding='utf-8');args=[str(r),'--vanilla',str(D/'scale-reference.R'),str(B/'numerical-reference-1/vectors.tsv'),str(D/'R-scale-reference.tsv'),str(D/'R-quantile-default.rds'),str(D/'R-quantile-default-source.txt')];env=dict(os.environ,LC_ALL='C',LANG='C')
with (D/'stdout').open('xb') as out,(D/'stderr').open('xb') as err:p=subprocess.run(args,cwd=T,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err)
assert p.returncode==0;(D/'RESULT.json').write_text(json.dumps(dict(status='PASS_SEPARATE_SCALE_EQUIVARIANCE_REFERENCE',exit_code=0,arguments=args,original_R_sd_and_warnings_preserved=True,original_reference_modified=False,reference=pin(D/'R-scale-reference.tsv'),rscript=pin(r)),indent=2)+'\n',encoding='utf-8');print('PASS separate R scale-equivariance reference; original raw R outputs unchanged',flush=True)
