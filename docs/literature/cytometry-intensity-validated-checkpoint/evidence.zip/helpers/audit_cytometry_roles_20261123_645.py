from pathlib import Path
import json,re
from handover_inventory_20261122_111 import save,pin
T=Path('D:/projects/JLinAlg/build/fu-1');B=T/'build/cytometry-intensity-629';P=T/'docs/literature/omics-2023-2026/papers.json';papers={p['paper_id']:p for p in json.loads(P.read_bytes())};anchors=json.loads((B/'PRIVATE-ANCHORS.json').read_bytes())
# Individually read source roles; summaries intentionally retain distinct operations and missing settings.
flowjo={
'P005':('unreported','Population gating and quantification for lipid-droplet measurements in primary microglia after CCN1 treatment.','Original gate definitions and acquisition inputs are required; no Sony acquisition replacement.'),
'P010':('10','Postacquisition flow-cytometry analysis with gating and threshold schemes shown in supplementary figures.','Figures alone do not supply an executable workspace or exact thresholds.'),
'P011':('10.10.1','Fucci4 cell-cycle population gating using G1 and S/G2/M controls after Aurora acquisition.','Control-based gates are distinct from fitted cell-cycle models.'),
'P012':('10.9; 10','Erythrocyte binding analysis uses scatter/singlet gates and AF488-positive fractions; parasite assays use sequential gates and infected-cell fractions.','Separate binding and parasitemia workflows; GraphPad comparisons and plots are separate.'),
'P020':('10','Immune-population gating using CD45, myeloid and antigen-presentation markers.','Aurora acquisition is separate; marker descriptions do not define exact gate boundaries.'),
'P027':('10.7.1','Flow-cytometry figures after CytExpert collection, with a supplementary gating scheme.','Vendor figures and exact gates are not reproduced by counts alone.'),
'P031':('10.8.0','Analysis and display jointly assigned to FlowJo and FACSDiva, with sequential gating in a supplementary figure.','The source does not allocate each analysis/display step to one package.'),
'P032':('10.8.1','Lymphocyte/singlet/live/CD4 gating and median IL2Ralpha/CTLA4 intensities; suppression analysis uses proliferating Teff counts and donor replicate summaries.','Vendor-binned medians, suppression denominator/control definitions and donor aggregation need separate qualification.'),
'P040':('10.0','Analysis of stimulated T-cell populations from tumor-draining lymph nodes.','Original workspace, population controls and source FCS are unavailable here.'),
'P044':('10','Flow analysis of HSPC cell-cycle, DNA incorporation, Ki67 and RNA-labeling assays.','No particular fitted cell-cycle model is inferred; assay populations/settings remain required.'),
'P048':('10.10.0','Postacquisition cytometry data analysis following FACSDiva collection.','Acquisition and FACSAria sorting remain separate operations.'),
'P049':('10.9','Immune-cell cytometry analysis with dead-cell exclusion using Zombie Green.','FACSDiva sorting of neuronal nuclei is a separate source role.'),
'P051':('10','Neutrophil analysis includes FlowSOM, ClusterExplorer and UMAP plugins; segmented image-derived events are imported, thresholded and visualized.','Plugins, image-event import and plots are not supplied by the native gate/statistics operations.'),
'P052':('10','Analysis of mRNA-transfer fluorescence in living single cells, jointly assigned with FACSDiva.','The source does not specify the exact division of analysis steps.'),
'P063':('unreported','Phenotypic and peptide-HLA tetramer flow-cytometry analysis following FACSDiva acquisition.','No exact FlowJo version or executable gate workspace is given in the paragraph.'),
'P080':('10.10.0','Erythroid differentiation marker analysis following Attune NxT collection.','Attune acquisition and biological differentiation are separate from analysis.'),
'P082':('10.5.3','Flow-cytometry data analysis; the code-availability section also lists this software.','R statistical analysis is separately described; the declaration is not an executable workspace.'),
'P084':('10.8','Gated blood-cell counts/percentages plus median, robust SD and robust CV measurements of scatter, fluorescence and cell properties.','Transform-dependent vendor binning, off-scale rules and percentile convention are unresolved; unbinned summaries do not close them.'),
'P119':('10','Postacquisition analysis is described as FlowJo 10 or FCS Express 7.','The alternative is retained; both packages are not presumed to process the same cells.'),
'P121':('9','Flow-cytometry analysis after FACSCalibur/CellQuest Pro collection.','Version 9 is outside the native FlowJo 10 workspace profile.'),
'P122':('10','Dean-Jett-Fox cell-cycle fitting without constraints to propidium-iodide intensity data.','A fitted model is required; gate membership/counts or unbinned moments do not reproduce it.'),
'P124':('10.8.1','Input and tumor-infiltrating CAR T-cell flow analysis using sham and fluorescence-minus-one controls for gating/compensation.','Original gate workspace, compensation matrix and controls remain required.'),
'P163':('unreported; 10.6.1','GFP quantification within scatter-gated DAPI-negative cells; separate marker analysis after LSRII acquisition includes log10 plots.','Plot scale does not establish the statistics measurement domain or MFI definition.'),
'P215':('10.10','Flow-cytometry analysis of BD Celesta measurements.','The paragraph does not provide an executable gate workspace or more specific operation.'),
'P226':('unreported','Analysis of Zombie Violet cell-death cytometry; percent summaries/ANOVA are separately attributed to GraphPad.','Do not assign the separate GraphPad analysis to FlowJo.'),
'P228':('unreported','Watson Pragmatic cell-cycle modeling in neural progenitor/organoid experiments with EdU measurements.','The fitted model and experiment structure are not gate-count replacements.'),
'P232':('unreported','Fluorescence histograms and conservative APC-high/low selection, excluding an intermediate range.','The source selection rule is explicit; native event preservation does not erase that biological gate. Vendor histograms are not qualified.')}
facs={
'P012':('9.0','LSRFortessa acquisition associated with erythrocyte/singlet/infection gates for parasite-growth assays.','FlowJo analysis and GraphPad tests are separately described.'),
'P021':('8.0.2','Collection during fluorescence-activated sorting of frozen-brain nuclei for downstream profiling.','Instrument operation and sample collection are not offline FCS analysis.'),
'P024':('8.0.2','FANS collection of frozen-brain nuclei for downstream profiling.','No downstream statistical computation is attributed to this acquisition step.'),
'P031':('8.0.1','Analysis and display jointly assigned with FlowJo in organoid flow-cytometry experiments.','Do not infer a package-specific division of the jointly assigned operations.'),
'P038':('unreported','FACSAria II fluorescence-based selection of astrocyte/PDX stable cell lines.','Instrument sorting/selection is outside offline native computation.'),
'P040':('9','FACSymphony A5 cytometry acquisition after staining thawed tumor-draining lymph-node cells.','The source spells the software name FACS Diva; the spaced-name anchor is retained.'),
'P044':('8.0.3','FACSAria III collection/sorting of human Lin-negative CD34-positive and mouse stem/progenitor populations.','Separate FlowJo downstream assays are not reassigned to acquisition software.'),
'P048':('unreported','LSRFortessa X50 acquisition and FACSAria Fusion purification.','FlowJo 10.10.0 is explicitly assigned postacquisition data analysis.'),
'P049':('9.0.1','FACSAria III sorting of NeuN/RBPMS-positive nuclei for RNA sequencing.','Separate immune-cell FlowJo analysis is a distinct role.'),
'P052':('6.1.3','Living-single-cell fluorescence analysis jointly assigned with FlowJo after FACSAria III measurements.','The source does not resolve the division of analysis between these tools.'),
'P059':('8','FACSAria II live-cell/neuron single-cell sorting with a 130-micrometer nozzle.','Physical sorting is not replaced by an offline data adapter.'),
'P063':('9.2','FACSymphony A5 acquisition for phenotypic and peptide-HLA tetramer cytometry.','FlowJo downstream analysis is separately attributed.'),
'P064':('8.02','Sorting NEUN/CHX10-positive nuclei for downstream profiling.','The literal reported version 8.02 is preserved rather than normalized to 8.0.2.'),
'P082':('unreported','Named in the code-availability software list; no local FACSDiva analysis step is specified there.','A software declaration does not justify inferring acquisition or analysis settings.'),
'P089':('unreported','SORP FACSAria instrument-associated live/singlet fluorescence analysis in overexpression experiments.','Original acquisition/gating settings and data remain required.'),
'P119':('9','FACSDiva acquisition followed by FlowJo 10 or FCS Express 7 analysis.','Preserve the downstream alternative instead of assigning both analysis packages to every sample.'),
'P163':('8','BD LSRII cytometry acquisition before FlowJo marker analysis.','Log10 plots and downstream FlowJo processing are distinct.')}
records=[]
for tool,mapping,pattern in [('flowjo',flowjo,re.compile(r'flow[\s_-]*jo',re.I)),('facsdiva',facs,re.compile(r'facs[\s_-]*diva',re.I))]:
    observed={a['paper_id'] for a in anchors if any(pattern.fullmatch(x) for x in a['matches'])};assert observed==set(mapping),(tool,observed^set(mapping))
    for pid,(version,role,gap) in mapping.items():
        aa=[{k:a[k] for k in ('paragraph_index','section','paragraph_sha256')} for a in anchors if a['paper_id']==pid and any(pattern.fullmatch(x) for x in a['matches'])];p=papers[pid];records.append(dict(paper_id=pid,tool_id=tool,doi=p['doi'],pmcid=p['pmcid'],xml_sha256=p['xml_sha256'],reported_version=version,use_summary=role,remaining_scope=gap,primary_anchors=aa,semantic_role_read=True,catalog_admitted=False,paper_reproduced=False))
assert len(records)==44 and len({(r['paper_id'],r['tool_id']) for r in records})==44
target=T/'docs/literature/cytometry-source-roles-2026-11-23.json';save(target,dict(status='PRIMARY_SOURCE_ROLES_PREPARED_NOT_CANONICALLY_ADMITTED',papers_screened=250,matched_papers=33,matched_paragraphs=48,paper_tool_pairs=44,flowjo_pairs=27,facsdiva_pairs=17,records=sorted(records,key=lambda r:(r['paper_id'],r['tool_id'])),new_reviews=0,new_family_credit=0,whole_goal_complete=False));save(B/'SOURCE-ROLE-RECEIPT.json',dict(status='PASS_44_UNIQUE_SOURCE_ROLE_RECORDS',public_file=pin(target),all_250_xml_and_doi_checked_in='PRIMARY-CENSUS.json',private_full_paragraphs_retained=True,canonical_catalog_unchanged=True,semantic_role_admission_next_step=True));print(json.dumps(dict(pairs=len(records))),flush=True)
