from pathlib import Path
import json,re,subprocess,xml.etree.ElementTree as E
from handover_inventory_20261122_111 import save,pin
T=Path('D:/projects/JLinAlg/build/fu-1');B=T/'build/cytometry-intensity-629/normal-build-1';old=T/'build/flowjo-595/normal-build-2/project-build/cli/omicsmatic-0.4.0.jar';new=B/'project-build/cli/omicsmatic-0.4.0.jar';assert 'BUILD SUCCESSFUL' in (B/'stdout').read_text(errors='replace');counts=dict(tests=0,failures=0,errors=0,skipped=0)
for p in (B/'project-build/test-results/test').glob('TEST-*.xml'):
    root=E.parse(p).getroot()
    for k in counts:counts[k]+=int(root.get(k,'0'))
assert counts==dict(tests=1910,failures=0,errors=0,skipped=0),counts
for name,identity in json.loads((B/'SOURCE-INPUTS.json').read_bytes()).items():assert pin(T/name)==identity,name
payload=json.loads((B/'PAYLOADS.json').read_bytes());expected=['org/jlinalg/cli/FlowJoToolsCli.class','org/jlinalg/cytometry/FlowJoWorkspace$2.class','org/jlinalg/cytometry/FlowJoWorkspace$Program.class','org/jlinalg/cytometry/FlowJoWorkspace.class'];assert payload['modified']==expected and all(n.startswith(('org/jlinalg/cli/CytometryIntensity','org/jlinalg/cytometry/CytometryIntensitySummary')) for n in payload['added'])
javap='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/javap.exe';proof={}
def disasm(jar,name,label):
    p=subprocess.run([javap,'-p','-c','-classpath',str(jar),name],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert p.returncode==0;pname=name.rsplit('.',1)[-1];(B/(label+'-'+pname+'.javap')).write_bytes(p.stdout);return re.sub(r'#\d+','#CP',p.stdout.decode()).replace('\r\n','\n')
for name in ('org.jlinalg.cytometry.FlowJoWorkspace','org.jlinalg.cytometry.FlowJoWorkspace$2'):
    a=disasm(old,name,'old');b=disasm(new,name,'new');assert a==b,('Instructions changed',name);proof[name]='All instructions/signatures identical; byte changes are debug line metadata'
def methods(s):
    result={};current=None;lines=[]
    for line in s.splitlines():
        if re.match(r'  \S.*\([^)]*\).*;$',line):
            if current is not None:result[current]='\n'.join(lines).rstrip()
            current=line.strip();lines=[]
        elif current is not None:lines.append(line)
    if current is not None:result[current]='\n'.join(lines).rstrip().rstrip('}').rstrip()
    return result
name='org.jlinalg.cytometry.FlowJoWorkspace$Program';a=methods(disasm(old,name,'old'));b=methods(disasm(new,name,'new'));assert a and all(k in b and ' '.join(a[k].split())==' '.join(b[k].split()) for k in a);added=set(b)-set(a);assert len(added)==2 and any('hasCompensationChannel' in k for k in added) and any('compensatedMeasurements' in k for k in added);proof[name]=dict(existing_methods_identical=len(a),added_measurement_accessors=sorted(added))
save(B/'INSTRUCTION-CONTINUITY.json',dict(status='EXISTING_GATE_SCIENCE_INSTRUCTIONS_UNCHANGED',classes=proof,initial_allowlist_failure='Initial post-build harness expected two changed classes and omitted two debug-line-only class changes; original harness and actual payload list retained',historical_source_or_hashes_refreshed=False))
result=dict(exit_code=0,source_unchanged=True,normal_tests=counts,producer=dict(path=str(new),**pin(new)),original_build_driver_postcondition_exit=1,build_and_tests_actually_passed=True,postcondition_refined_by_actual_instruction_comparison=True,new_family_credit=0,new_reviews=0,whole_goal_complete=False);save(B/'RESULT.json',result);print(json.dumps(result,indent=2),flush=True)
