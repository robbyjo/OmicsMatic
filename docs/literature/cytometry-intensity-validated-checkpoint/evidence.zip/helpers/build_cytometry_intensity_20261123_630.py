from pathlib import Path
import json,os,shutil,subprocess,time,zipfile,xml.etree.ElementTree as ET
from handover_inventory_20261122_111 import pin,save
R=Path('D:/projects/JLinAlg');T=R/'build/fu-1';B=T/'build/cytometry-intensity-629/normal-build-1';B.mkdir()
sources={p.relative_to(T).as_posix():pin(p) for base in ('src','build.gradle','settings.gradle','gradle.properties') for p in ([T/base] if (T/base).is_file() else (T/base).rglob('*')) if p.is_file()};save(B/'SOURCE-INPUTS.json',sources)
for name in sources:
    if name=='src/main/java/org/jlinalg/cli/JLinAlgCli.java' or '/FlowJo' in name or '/CytometryIntensity' in name:
        dest=B/'source-context'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(T/name,dest)
build=B/'project-build';dep=build/'dependencies/jdistlib-all-0.10.2.jar';dep.parent.mkdir(parents=True);shutil.copyfile(R/'build/gp-1/build/dependencies/jdistlib-all-0.10.2.jar',dep);assert pin(dep)['sha256']=='8b50aaa11d2cbd512525e0d74f8e609f40db9f4fc179ccb7a885a82257e0ac81'
init=B/'init.gradle';init.write_text("allprojects { layout.buildDirectory.set(file('"+build.as_posix()+"')) }\n",encoding='utf-8')
gradle='C:/Users/User/.gradle/wrapper/dists/gradle-9.7.1-bin/1w1c7tv4s851m17nbqdsro2tv/gradle-9.7.1/bin/gradle.bat';args=[gradle,'--offline','--no-daemon','--console=plain','--init-script',str(init),'-Dorg.gradle.jvmargs=-Xmx2g -XX:MaxMetaspaceSize=512m','test']
for pattern in ('org.jlinalg.genetics.*','org.jlinalg.cli.Impute*','org.jlinalg.cli.OwnedProcessesTest','org.jlinalg.cytometry.*','org.jlinalg.cli.CytometryGateCliTest','org.jlinalg.cli.FlowJo*','org.jlinalg.cli.CytometryIntensity*'):args+=['--tests',pattern]
args+=['executableJar'];env=dict(os.environ,JAVA_HOME='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot',JLINALG_PLINK_HOME=str(R/'build/omics-plink-official'),JLINALG_LIFTOVER_REFERENCE=str(R/'build/literature-review/liftover-runtime'));save(B/'COMMAND.json',dict(arguments=args,environment={k:env[k] for k in ('JAVA_HOME','JLINALG_PLINK_HOME','JLINALG_LIFTOVER_REFERENCE')}));start=time.monotonic()
with (B/'stdout').open('xb') as out,(B/'stderr').open('xb') as err:
    process=subprocess.Popen(args,cwd=T,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err);save(B/'PROCESS.json',dict(pid=process.pid,arguments=args));code=process.wait()
assert all(pin(T/n)==p for n,p in sources.items()),'Normal build source changed while running'
counts=dict(tests=0,failures=0,errors=0,skipped=0)
for path in (build/'test-results/test').glob('TEST-*.xml'):
    root=ET.parse(path).getroot()
    for key in counts:counts[key]+=int(root.get(key,'0'))
result=dict(exit_code=code,seconds=time.monotonic()-start,source_unchanged=True,normal_tests=counts,new_family_credit=0,new_reviews=0,whole_goal_complete=False)
if code==0:
    assert counts['tests']>1000 and counts['failures']==counts['errors']==counts['skipped']==0
    jar=build/'cli/omicsmatic-0.4.0.jar';result['producer']=dict(path=str(jar),**pin(jar));prior=T/'build/flowjo-595/normal-build-2/project-build/cli/omicsmatic-0.4.0.jar'
    with zipfile.ZipFile(prior) as a,zipfile.ZipFile(jar) as b:
        old=[n for n in a.namelist() if not n.endswith('/')];new=[n for n in b.namelist() if not n.endswith('/')];modified=[n for n in old if n not in new or a.read(n)!=b.read(n)];added=[n for n in new if n not in old];save(B/'PAYLOADS.json',dict(previous_payloads=len(old),modified=modified,added=added));assert set(modified)=={'org/jlinalg/cli/FlowJoToolsCli.class','org/jlinalg/cytometry/FlowJoWorkspace$Program.class'},modified;assert added and all(n.startswith(('org/jlinalg/cli/CytometryIntensity','org/jlinalg/cytometry/CytometryIntensitySummary')) for n in added),added
save(B/'RESULT.json',result);print(json.dumps(result,indent=2),flush=True)
if code:print((B/'stderr').read_text(errors='replace')[-4000:]);print((B/'stdout').read_text(errors='replace')[-3000:])
raise SystemExit(code)
