# Read before using intensity results

Complete unweighted, unbinned measurement statistics with explicit R_TYPE_7 quantiles. Fresh gating must match every captured parent membership and count. Measurement space is explicitly AMPLIFIER_MEASUREMENT or WSP_COMPENSATED_MEASUREMENT. No display-transform binning, imported Statistic-node result, FlowJo vendor-statistics equivalence, cell-cycle fit, clustering plugin, inferred MFI definition or whole-paper reproduction.

Require exit 0, COMPLETED.json and result_admitted=true. SKIP3: supply the named permitted input/capability or use the supported explicit method; vendor binning/settings are unavailable and are never inferred. FAIL2: no complete result; preserve inputs and partial output, correct the named integrity, membership, numerical or capacity problem, then retry NEW output. Undefined statistic values remain null with explicit reason/counts; no clipping, dropped event, pseudocount or nonfinite-value replacement. MFI must be defined as mean, median or geometric mean on a declared measurement scale. VERIFY checks bytes only; REPLAY freshly gates and recomputes statistics using the exact producer JAR.

Statistics use explicit unbinned measurements. FlowJo's transform-dependent binned statistics and off-scale rules are not reproduced. Central 68.26% half-width is not claimed to reproduce vendor Robust SD. Percent ratios retain the sign of their declared denominator.

**Native unbinned statistics; vendor-binned FlowJo statistics are not qualified. Undefined requested results=2. Parent saved-count agreement=false.**
