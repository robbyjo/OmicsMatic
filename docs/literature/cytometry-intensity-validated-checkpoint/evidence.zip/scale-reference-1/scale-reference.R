args<-commandArgs(trailingOnly=TRUE)
options(warn=1,digits=17)
out<-file(args[2],open="wt",encoding="UTF-8")
writeLines("case\tscale\traw_R_sd\traw_R_cv\trescaled_R_sd\trescaled_R_cv",out)
fmt<-function(x) trimws(formatC(x,digits=17,format="g"))
for(line in readLines(args[1])) {
 f<-strsplit(line,"\t",fixed=TRUE)[[1]]
 if(!startsWith(f[1],"scaled-"))next
 x<-scan(text=f[2],sep=",",quiet=TRUE);scale<-max(abs(x));z<-x/scale
 writeLines(paste(f[1],fmt(scale),fmt(sd(x)),fmt(100*sd(x)/mean(x)),fmt(sd(z)*scale),fmt(100*sd(z)/mean(z)),sep="\t"),out)
}
close(out)
saveRDS(getS3method("quantile","default"),args[3],version=3)
writeLines(deparse(body(getS3method("quantile","default"))),args[4])
