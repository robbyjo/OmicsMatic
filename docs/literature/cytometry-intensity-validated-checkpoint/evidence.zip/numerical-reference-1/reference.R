args <- commandArgs(trailingOnly=TRUE)
options(warn=1, digits=17)
lines <- readLines(args[1], warn=TRUE)
out <- file(args[2], open="wt", encoding="UTF-8")
writeLines("case\tmetric\tcount\tnonpositive_count\tvalue\tstatus", out)
fmt <- function(x) {if(is.nan(x)) "NaN" else if(is.na(x)) "NA" else if(is.infinite(x)) if(x>0) "Inf" else "-Inf" else trimws(formatC(x, digits=17, format="g"))}
ps <- c(0,.01,.1587,.25,.5,.8413,.99,1)
pl <- c("0","0.01","0.1587","0.25","0.5","0.8413","0.99","1")
for(line in lines) {
  split <- strsplit(line,"\t",fixed=TRUE)[[1]]
  id <- split[1]; x <- if(length(split)<2 || split[2]=="") numeric(0) else scan(text=split[2],sep=",",quiet=TRUE)
  stopifnot(all(is.finite(x)))
  n <- length(x); np <- sum(x<=0)
  mu <- mean(x); md <- median(x); st <- sd(x)
  qs <- quantile(x,probs=c(.1587,.8413),type=7,names=FALSE,na.rm=FALSE)
  half <- qs[2]/2-qs[1]/2
  mad0 <- mad(x, center=md, constant=1, na.rm=FALSE)
  raw.geo <- exp(mean(log(x)))
  values <- c(MEAN=mu, MEDIAN=md, SAMPLE_SD=st, CV_PERCENT=100*st/mu,
    CENTRAL_68_26_HALF_WIDTH=half, CENTRAL_68_26_CV_PERCENT=100*half/md,
    MAD=mad0, MAD_PERCENT=100*mad0/md, GEOMETRIC_MEAN=if(n>0 && np==0) raw.geo else NA_real_)
  for(metric in names(values)) {
    v <- values[[metric]]
    status <- if(n==0) "EMPTY_POPULATION" else if(metric %in% c("SAMPLE_SD","CV_PERCENT") && n<2) "INSUFFICIENT_COUNT" else if(metric=="GEOMETRIC_MEAN" && np>0) "NONPOSITIVE_VALUES" else if((metric=="CV_PERCENT" && mu==0)||(metric %in% c("CENTRAL_68_26_CV_PERCENT","MAD_PERCENT") && md==0)) "ZERO_DENOMINATOR" else if(!is.finite(v)) "NUMERIC_OVERFLOW" else "DEFINED"
    writeLines(paste(id,metric,n,np,fmt(v),status,sep="\t"),out)
  }
  writeLines(paste(id,"RAW_R_GEOMETRIC_MEAN",n,np,fmt(raw.geo),"RAW_REFERENCE_NOT_REPLACED",sep="\t"),out)
  if(n>0) {
    q <- quantile(x,probs=ps,type=7,names=FALSE,na.rm=FALSE)
    for(j in seq_along(q))writeLines(paste(id,paste0("QUANTILE_",pl[j]),n,np,fmt(q[j]),"DEFINED",sep="\t"),out)
  }
}
close(out)
writeLines(c(capture.output(sessionInfo()),capture.output(R.version)),args[3])
saveRDS(list(mean=base::mean,median=stats::median,sd=stats::sd,quantile=stats::quantile,mad=stats::mad),args[4],version=3)
