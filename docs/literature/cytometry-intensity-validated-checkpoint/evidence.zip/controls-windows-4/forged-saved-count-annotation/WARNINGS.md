# Read before using these results

Native complete sample-local FlowJo 10.x / WSP20.0 gate memberships/counts, using the declared FlowKit1.3.2 interpretation. Square WSP compensation, linear/log/logicle/fasinh and explicit supplied biex tables; rectangles, polygons, 128-vertex ellipse approximations and hierarchical And/Or/Not. No gate learning, vendor runtime, FACSDiva acquisition/import, spectral WSP matrices or descriptive intensity statistics. No whole-tool, whole-paper or whole-goal equivalence claim.

Require exit 0, COMPLETED.json and analysis.json result_admitted=true. SKIP3 means the complete dependent sample analysis was skipped: supply the named permitted input, supported export or exact biex calibration, then use NEW output. FAIL2 means no complete result is admitted: retain inputs and partial output, correct the named integrity, numerical, capacity or saved-count disagreement and retry NEW output. Never alter gates, drop events, repair identifiers, replace nonfinite values or substitute logicle for biex to force agreement. VERIFY checks captured bytes only; REPLAY requires the exact original producer JAR. Saved FlowJo counts and FlowKit reference outputs can disagree; neither is silently used to fit gates.

Saved-count policy: REPORT_DIFFERENCES. Saved statistics are not computed by this membership/count operation.

- Explicit numeric policy permits outer ASCII spaces in recognized numeric metadata tokens. Original keyword values and parameter names remain unchanged; tabs, other whitespace and malformed values are not repaired.

- Stored channels only: no gain, antilog, time, compensation, calibration, display transform or gate is inferred. Floating negative/over-range/nonfinite values remain visible. This profile does not validate a CRC or claim complete FCS conformance.

- Explicit time policy: Time multiplied by source $TIMESTEP=0.01; its PnG=1.0 is not applied, following the selected FlowIO-compatible interpretation. Other channels use their declared scale/gain.

- Label policy FLOWJO_SLASH_TO_UNDERSCORE is explicit; original FCS names remain in captured metadata. No labels are guessed from antibodies or aliases.

- Only the sample-local WSP spectrum supplies compensation; FCS compensation keywords are retained as metadata and are not applied in addition. No off-scale/negative-event filtering or subsampling.

- FlowKit-1.3.2 WSP linear interpretation for FSC-A: maxRange/minRange define Gating-ML T/A; saved display gain=1 is retained, not applied. This does not replace or ignore FCS PnG preprocessing.

- FlowKit-1.3.2 WSP linear interpretation for FSC-H: maxRange/minRange define Gating-ML T/A; saved display gain=1 is retained, not applied. This does not replace or ignore FCS PnG preprocessing.

- FlowKit-1.3.2 WSP linear interpretation for FSC-W: maxRange/minRange define Gating-ML T/A; saved display gain=1 is retained, not applied. This does not replace or ignore FCS PnG preprocessing.

- FlowKit-1.3.2 WSP linear interpretation for SSC-A: maxRange/minRange define Gating-ML T/A; saved display gain=1 is retained, not applied. This does not replace or ignore FCS PnG preprocessing.

- FlowKit-1.3.2 WSP linear interpretation for SSC-H: maxRange/minRange define Gating-ML T/A; saved display gain=1 is retained, not applied. This does not replace or ignore FCS PnG preprocessing.

- FlowKit-1.3.2 WSP linear interpretation for SSC-W: maxRange/minRange define Gating-ML T/A; saved display gain=1 is retained, not applied. This does not replace or ignore FCS PnG preprocessing.

- FlowKit-1.3.2 WSP linear interpretation for Time: maxRange/minRange define Gating-ML T/A; saved display gain=0.0100853049 is retained, not applied. This does not replace or ignore FCS PnG preprocessing.

- NOT COMPUTED: saved Statistic metadata at  (Count). This profile returns complete memberships/counts only. Use a separately qualified statistic procedure on the declared compensated/measurement scale; saved statistics are not imported as new results.

- All sample-local gates are compiled; group template gates are not substituted. Saved counts are annotations, not fitting targets. Rectangle [min,max); polygon boundary included; Booleans intersect their parent population. Every source event is retained.

**WARNING: 13 saved FlowJo count disagreements. Native FlowKit-profile results do not reproduce those saved counts. Read saved_count_differences in analysis.json, verify the exact workspace/FCS pairing and obtain independent current vendor results before claiming workspace reproduction. No gates or events were changed to force agreement.**
