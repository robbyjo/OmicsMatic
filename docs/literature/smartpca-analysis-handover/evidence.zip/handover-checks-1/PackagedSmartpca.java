import java.nio.file.Path;
public final class PackagedSmartpca {
 public static void main(String[] args)throws Exception {
  Path jar=Path.of(args[0]).toRealPath();
  for(String name:new String[]{"org.jlinalg.genetics.SmartpcaPrepared","org.jlinalg.genetics.SmartpcaOutliers","org.jlinalg.genetics.SmartpcaShrinkage","org.jlinalg.genetics.SmartpcaAnalysis","org.jlinalg.cli.SmartpcaWorkflowContracts","org.jlinalg.cli.SmartpcaWorkflowData","org.jlinalg.cli.SmartpcaWorkflowFiles","org.jlinalg.cli.SmartpcaWorkflowSource","org.jlinalg.cli.SmartpcaWorkflowEvaluation","org.jlinalg.cli.SmartpcaWorkflowTables"}) {
   if(!Path.of(Class.forName(name).getProtectionDomain().getCodeSource().getLocation().toURI()).toRealPath().equals(jar))throw new AssertionError("Wrong producer: "+name);
  }
  for(String name:new String[]{"org.jlinalg.genetics.SmartpcaExtensionsTest","org.jlinalg.genetics.SmartpcaAnalysisReferenceTest"}) {
   var method=Class.forName(name).getDeclaredMethod("main",String[].class);method.setAccessible(true);method.invoke(null,(Object)new String[0]);
  }
  System.out.println("PASS exact packaged producer; five extension methods plus sixteen finite/two refused original program cases");
 }
}
