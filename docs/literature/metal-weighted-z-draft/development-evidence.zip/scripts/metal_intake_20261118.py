from pathlib import Path
import subprocess,urllib.request,json,hashlib,zipfile,io,time,sys,gzip,re,xml.etree.ElementTree as ET
r=Path(r'D:/projects/JLinAlg/build/high-impact-stats-1');b=r/'build/metal-1';b.mkdir();source=b/'upstream-1';source.mkdir();sys.dont_write_bytecode=True;sys.path.insert(0,str(r/'tools/literature'));from collect_omics_review import paragraphs
def save(p,v):p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def fetch(url,name,limit=50_000_000):
 req=urllib.request.Request(url,headers={'User-Agent':'OmicsMatic-METAL-private-source-intake'});start=time.monotonic()
 with urllib.request.urlopen(req,timeout=45) as response:raw=response.read(limit+1);final=response.geturl();assert len(raw)<=limit
 p=source/name;p.write_bytes(raw);save(source/(name+'.receipt.json'),dict(url=url,final_url=final,seconds=time.monotonic()-start,**pin(raw)));print('FETCHED',name,len(raw),flush=True);return raw
assert subprocess.check_output(['git','status','--porcelain=v1'],cwd=r)==b''
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()=='91549561599bba8b1d5f069033a2273bb1c5d8ad';subprocess.run(['git','switch','-c','codex/metal-workflows-20261118'],cwd=r,check=True)
release=json.loads(fetch('https://api.github.com/repos/statgen/METAL/releases/latest','latest-release.json',2_000_000));assert release['tag_name']=='2020-05-05';commit=json.loads(fetch('https://api.github.com/repos/statgen/METAL/commits/'+release['tag_name'],'selected-commit.json',2_000_000))['sha'];assert len(commit)==40
raw=fetch('https://codeload.github.com/statgen/METAL/zip/'+commit,'metal-'+commit+'.zip');dest=source/'source';dest.mkdir();pins={}
with zipfile.ZipFile(io.BytesIO(raw)) as z:
 tops={name.split('/')[0] for name in z.namelist()};assert len(tops)==1
 for info in z.infolist():
  if info.is_dir():continue
  parts=Path(info.filename).parts[1:];assert parts and '..' not in parts and info.file_size<20_000_000;path=dest.joinpath(*parts);assert path.resolve().is_relative_to(dest.resolve());data=z.read(info);path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data);pins[path.relative_to(dest).as_posix()]=pin(data)
save(source/'SOURCE-FILES.json',pins);save(source/'INTAKE.json',dict(status='PASS_PINNED_OFFICIAL_METAL_RELEASE_SOURCE_INTAKE',release=release['tag_name'],commit=commit,archive=pin(raw),source_files=len(pins),private_source_only=True,source_redistribution_permitted=False,compiled=False,whole_tool_qualified=False));print('PINNED_METAL_SOURCE',commit,len(pins),flush=True)
cmake=json.loads(fetch('https://pypi.org/pypi/cmake/3.31.10/json','cmake-pypi.json',5_000_000));choices=[x for x in cmake['urls'] if x['filename'].endswith('manylinux2014_x86_64.whl') or x['filename'].endswith('manylinux_2_17_x86_64.manylinux2014_x86_64.whl')];print('CMAKE_WHEELS',[x['filename'] for x in cmake['urls']],flush=True)
save(source/'CMAKE-CANDIDATES.json',choices)
papers=json.loads((r/'docs/literature/omics-2023-2026/papers.json').read_bytes());rows=[];allhits=[];identities=[]
for paper in papers:
 raw=gzip.decompress((Path('D:/projects/JLinAlg/build/literature-review/xml')/(paper['pmcid']+'.xml.gz')).read_bytes());assert hashlib.sha256(raw).hexdigest()==paper['xml_sha256'];identities.append(dict(paper_id=paper['paper_id'],pmcid=paper['pmcid'],doi=paper['doi'],xml_sha256=paper['xml_sha256']));body=paragraphs(ET.fromstring(raw));hits=[p for p in body if re.search(r'(?<![A-Za-z0-9_])METAL(?![A-Za-z0-9_])',p['match_text'])]
 if hits:allhits.append(dict(paper_id=paper['paper_id'],paragraphs=[p['paragraph_index'] for p in hits]))
 observations=[t for t in paper['tools'] if t['tool_id']=='metal']
 if observations:
  assert len(observations)==1;obs=observations[0];anchor=next(p for p in body if p['paragraph_index']==obs['evidence_paragraph_index']);assert hashlib.sha256(anchor['text'].encode()).hexdigest()==obs['evidence_paragraph_sha256'];indices={p['paragraph_index'] for p in hits}|{anchor['paragraph_index']};rows.append(dict(paper_id=paper['paper_id'],pmcid=paper['pmcid'],doi=paper['doi'],fulltext_url=paper['fulltext_url'],xml_sha256=paper['xml_sha256'],current_observation=obs,source_paragraphs=[dict(paragraph_index=p['paragraph_index'],section=p['section'],paragraph_sha256=hashlib.sha256(p['text'].encode()).hexdigest(),text=p['text']) for p in body if p['paragraph_index'] in indices]))
assert len(rows)==24;save(b/'PRIMARY-ROLES.private.json',dict(status='INTAKE_ONLY_NOT_SEMANTIC_REVIEW',primary_identities=identities,existing_roles=rows,all_named_hits=allhits,catalog_modified=False,new_integration_credit=0));print('PASS_250_PRIMARY_IDENTITIES_24_METAL_CANDIDATES',flush=True)
