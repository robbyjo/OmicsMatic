from pathlib import Path
b=Path(r'D:/projects/JLinAlg/build/high-impact-stats-1/build/metal-1');s=(b/'generate_weighted_z_reference.py').read_text(encoding='utf-8');s=s.replace("out=b/'weighted-z-reference-1'","out=b/'weighted-z-reference-2'")
old="lines=['id\\tmode\\tvalues\\tdirections\\tweights']";assert s.count(old)==1;s=s.replace(old,"lines=['id\\tmode\\tvalues\\tdirections\\tweights\\texpected']")
old="','.join(map(repr,c['weights']))]))";assert s.count(old)==1;s=s.replace(old,"','.join(map(repr,c['weights'])), 'refuse-unrepresentable' if c['id']=='tiny-weight' else 'finite']))")
old='  stopifnot(all(is.finite(a)))';assert s.count(old)==1;s=s.replace(old,'  if(x$expected[row]=="finite") stopifnot(all(is.finite(a)))')
old="import random,json,subprocess,hashlib,zipfile,time";s=s.replace(old,old+',os')
old='cwd=r,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=300';assert s.count(old)==1;s=s.replace(old,'cwd=r,env=dict(os.environ,LC_ALL="C",LANG="C"),stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=300')
old="models=len(cases),fields=fields,";assert s.count(old)==1;s=s.replace(old,"models=len(cases),finite_result_models=69,declared_unrepresentable_models=1,raw_unrepresentable_R_diagnostics_retained=True,fields=fields,")
(b/'generate_weighted_z_reference2.py').write_bytes(s.encode());print('Prepared new reference attempt retaining the unrepresentable case and raw R Inf diagnostics; it must produce no admitted Java result.')
