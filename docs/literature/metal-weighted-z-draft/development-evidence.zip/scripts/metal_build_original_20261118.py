from pathlib import Path
import json,urllib.request,hashlib,zipfile,io,subprocess,time,os,traceback
r=Path(r'D:/projects/JLinAlg/build/high-impact-stats-1');b=r/'build/metal-1';out=b/'build-original-1';out.mkdir();up=b/'upstream-1';source=up/'source';distro='JLinAlg-Omics-SAIGE-20261026'
def save(p,v):p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
def pin(p):
 with p.open('rb') as f:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
def linux(p):p=p.resolve();return '/mnt/'+p.drive[0].lower()+'/'+p.as_posix()[3:]
def run(name,args,cwd=None):
 cmd=['wsl.exe','-d',distro,'--','env','PATH=/usr/bin:/bin','GIT_CEILING_DIRECTORIES='+linux(up),*args];save(out/(name+'-command.json'),cmd);start=time.monotonic()
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:p=subprocess.run(cmd,cwd=cwd or r,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=600)
 record=dict(exit_code=p.returncode,seconds=time.monotonic()-start);save(out/(name+'-PROCESS.json'),record);print('BUILD_STEP',name,p.returncode,flush=True);assert p.returncode==0,(name,(out/(name+'.stderr')).read_text(errors='replace')[-1800:]);return record
try:
 choices=json.loads((up/'CMAKE-CANDIDATES.json').read_bytes());assert len(choices)==1;wheel=choices[0];req=urllib.request.Request(wheel['url'],headers={'User-Agent':'OmicsMatic-private-METAL-build'})
 with urllib.request.urlopen(req,timeout=45) as response:raw=response.read(60_000_001);assert len(raw)==wheel['size']<60_000_000
 assert hashlib.sha256(raw).hexdigest()==wheel['digests']['sha256'];wheelpath=out/wheel['filename'];wheelpath.write_bytes(raw);cmakeRoot=out/'cmake-runtime';cmakeRoot.mkdir();pins={}
 with zipfile.ZipFile(io.BytesIO(raw)) as z:
  for info in z.infolist():
   if info.is_dir():continue
   p=cmakeRoot/info.filename;assert p.resolve().is_relative_to(cmakeRoot.resolve()) and info.file_size<100_000_000;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(info));pins[info.filename]=pin(p)
 save(out/'CMAKE-INSTALLED-FILES.json',pins);save(out/'CMAKE-INTAKE.json',dict(filename=wheel['filename'],url=wheel['url'],wheel=pin(wheelpath),official_pypi_sha256=wheel['digests']['sha256'],files=len(pins),installation='Workspace-only unpacked Linux x86_64 CMake; no system package/environment modified'))
 cmake=cmakeRoot/'cmake/data/bin/cmake';ctest=cmakeRoot/'cmake/data/bin/ctest';run('chmod-cmake',['/usr/bin/chmod','0755',linux(cmake),linux(ctest),linux(cmakeRoot/'cmake/data/bin/cpack')]);run('cmake-version',[linux(cmake),'--version']);build=out/'native-build';build.mkdir();run('configure',[linux(cmake),'-S',linux(source),'-B',linux(build),'-DCMAKE_BUILD_TYPE=Release','-DCMAKE_C_COMPILER=/usr/bin/gcc','-DCMAKE_CXX_COMPILER=/usr/bin/g++','-DCMAKE_MAKE_PROGRAM=/usr/bin/make']);run('compile',[linux(cmake),'--build',linux(build),'--parallel','4']);run('official-tests',[linux(ctest),'--test-dir',linux(build),'--output-on-failure']);run('install',[linux(cmake),'--install',linux(build)]);binary=build/'bin/metal';assert binary.is_file();run('linked-libraries',['/usr/bin/ldd',linux(binary)])
 expected=json.loads((up/'SOURCE-FILES.json').read_bytes())
 for name,value in expected.items():assert pin(source/name)==value,name
 for name,value in pins.items():assert pin(cmakeRoot/name)==value,name
 save(out/'COMPLETED.json',dict(status='PASS_UNMODIFIED_ORIGINAL_METAL_RELEASE_BUILD_AND_OFFICIAL_TESTS',release='2020-05-05',commit=json.loads((up/'INTAKE.json').read_bytes())['commit'],binary=pin(binary),source_files_unchanged=len(expected),cmake_files_unchanged=len(pins),source_functions_patched=False,system_installation=False,redistribution_permitted=False,project_adapter_qualified=False,whole_goal_complete=False));print('PASS_ORIGINAL_METAL_BUILD_AND_TESTS',flush=True)
except Exception as e:save(out/'FAILURE.json',dict(status='FAIL2_NO_COMPLETE_ORIGINAL_BUILD',error=repr(e),detail=traceback.format_exc(),required_action='Retain source and build logs; correct permitted missing build prerequisites, then retry a new build output. If installation is unavailable or forbidden, SKIP3 the dependent METAL analysis. No source patch, runtime redistribution or project integration credit is implied.'));raise
