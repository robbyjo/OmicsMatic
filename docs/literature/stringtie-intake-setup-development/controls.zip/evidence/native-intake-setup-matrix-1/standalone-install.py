
import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
source,base,out=map(Path,sys.argv[1:]);assert base.parent==Path('/var/tmp') and base.name.startswith('omicsmatic-stringtie-setup-')
kit=base/'standalone-exported-kit-1';home=base/'standalone-home-1';report=base/'standalone-report-1';cache=base/'standalone-cache-1';work=base/'standalone-work-1'
assert all(not p.exists() for p in [kit,home,report,cache,work]);shutil.copytree(source,kit);work.mkdir(mode=0o700)
def pin(p):
 with p.open('rb') as f:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
export=json.loads((kit/'export.json').read_bytes());assert export['status']=='EXPORTED_KIT_NOT_EXECUTED' and not export['installation_performed']
assert all(pin(kit/n)==v for n,v in export['files'].items())
command=['/usr/bin/python3','-I','-B',str(kit/'install_stringtie.py'),'--kit',str(kit),'--profile','linux-x86_64-stringtie-3.0.3','--home',str(home),'--report',str(report),'--cache',str(cache),'--archive-dir',str(base/'download-cache'),'--allow-install']
with (out/'standalone-installer.stdout').open('xb') as stdout,(out/'standalone-installer.stderr').open('xb') as stderr:
 r=subprocess.run(command,cwd=work,env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','HOME':str(work),'TMPDIR':str(work)},stdout=stdout,stderr=stderr,timeout=90,check=False)
assert r.returncode==0
completion=json.loads((report/'COMPLETED.json').read_bytes());assert completion['status']=='COMPLETE_SETUP_ONLY_NOT_ADMISSION' and completion['manifest']==pin(report/'manifest.json') and not(report/'INCOMPLETE.json').exists()
manifest=json.loads((report/'manifest.json').read_bytes());assert not manifest['scientific_runtime_admitted'] and not manifest['user_analysis_admitted']
assert all(pin(home/n)==v for n,v in manifest['payload']['files'].items()) and all(pin(report/n)==v for n,v in manifest['files'].items())
assert all(pin(kit/n)==v for n,v in export['files'].items());shutil.copytree(report,out/'standalone-report')
(out/'STANDALONE.json').write_text(json.dumps(dict(status='passed-actual-JAR-exported-kit-standalone-offline-private-install',command=command,exit_code=r.returncode,working_directory=str(work),kit=str(kit),home=str(home),report=str(report),exported_files=export['files'],scientific_runtime_admitted=False,user_analysis_admitted=False,repository_code_imports_required=False),indent=2)+'\n')
