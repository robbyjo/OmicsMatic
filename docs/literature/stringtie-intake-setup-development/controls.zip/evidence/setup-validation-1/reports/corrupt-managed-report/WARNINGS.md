# FAIL2_NO_SETUP_OR_ANALYSIS_ADMITTED

Stage: existing-managed-payload-recheck

Complete setup input size exceeds its exact/metadata capacity: /var/tmp/omicsmatic-stringtie-setup-20261103-1/corrupt-managed-home/bin/stringtie

Required action: Read the named stage/error and every retained original archive/report. Skip dependent analysis while any required permitted dependency is unavailable. Use a compatible permitted Linux x86_64 Python environment and private native Linux filesystem. Select the exact profile; do not substitute editions. Supply the two exact official archives via --archive-dir for offline setup, or use --allow-install and --allow-download only where permitted. Preserve failed/partial paths, correct the cause and retry with NEW --home/--report paths. Existing valid managed homes may be rechecked into a NEW report without installation permission. Require setup COMPLETED.json and no INCOMPLETE.json, then separate native runtime health/admission and typed fit validation. Setup alone admits no runtime or user analysis.
