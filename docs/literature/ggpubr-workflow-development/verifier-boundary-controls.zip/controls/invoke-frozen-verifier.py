from pathlib import Path
import importlib.util,sys
s=importlib.util.spec_from_file_location("frozen_ggpubr_verifier",'/mnt/d/projects/JLinAlg/tools/literature/ggpubr_workflow/verify.py')
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
m.DATA=Path(sys.argv[1]);sys.argv=["verify.py","--out",sys.argv[2]]
raise SystemExit(m.main())
