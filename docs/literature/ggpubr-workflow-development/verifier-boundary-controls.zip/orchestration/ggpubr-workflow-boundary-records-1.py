from pathlib import Path
import base64,hashlib,importlib.util,io,json,os,shutil,zipfile
ROOT=Path('/mnt/d/projects/JLinAlg');BASE=ROOT/'build/literature-review/monocle-runtime';OUT=BASE/'ggpubr-workflow-boundary-records-1';OUT.mkdir(exist_ok=False)
DATA=ROOT/'docs/literature/ggpubr-workflow-development';TEST=BASE/'ggpubr-workflow-verifier-boundaries-1'
def rawpin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def pin(p):return rawpin(p.read_bytes())
def save(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf8',newline='\n')
v=json.loads((TEST/'COMPLETED.json').read_bytes());proof=json.loads((DATA/'VALIDATION.json').read_bytes())
assert v['status']=='PASS_FOUR_FROZEN_GGPUBR_VERIFIER_REFUSALS_WITHOUT_SCIENTIFIC_SOURCE_CHANGES' and v['refusal_controls']==4
assert v['base_validation']==pin(DATA/'VALIDATION.json') and v['base_scientific_archive']==proof['archive']
spec=importlib.util.spec_from_file_location('unchanged_ggpubr_verifier',ROOT/'tools/literature/ggpubr_workflow/verify.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
raw=module.archive_bytes(DATA,proof)
def local_blocks(payload):
 with zipfile.ZipFile(io.BytesIO(payload)) as z:
  infos=sorted(z.infolist(),key=lambda i:i.header_offset);start=z.start_dir
 return [(info.filename,info.header_offset,infos[i+1].header_offset if i+1<len(infos) else start) for i,info in enumerate(infos)],start
base_blocks,base_tail=local_blocks(raw);base_by={name:(start,end) for name,start,end in base_blocks}
excluded={};deltas={}
for case in ['missing-original-plot','forged-failed-layer-admission']:
 path=TEST/case;target_proof=json.loads((path/'VALIDATION.json').read_bytes());target=module.archive_bytes(path,target_proof);blocks,tail=local_blocks(target);ops=[];reused=literal=0
 def copy(start,length):
  nonlocal_dummy=None
  if ops and 'copy' in ops[-1] and sum(ops[-1]['copy'])==start:ops[-1]['copy'][1]+=length
  else:ops.append(dict(copy=[start,length]))
 def insert(payload):
  if payload:ops.append(dict(literal_base64=base64.b64encode(payload).decode('ascii')))
 if blocks and blocks[0][1]:insert(target[:blocks[0][1]]);literal+=blocks[0][1]
 for name,start,end in blocks:
  original=base_by.get(name)
  if original is not None and raw[original[0]:original[1]]==target[start:end]:copy(original[0],original[1]-original[0]);reused+=end-start
  else:insert(target[start:end]);literal+=end-start
 insert(target[tail:]);literal+=len(target)-tail
 recipe=dict(format='exact-byte-base-slices-and-literals-v1',base_archive=proof['archive'],target_archive=target_proof['archive'],
  operations=ops,target_archive_parts=target_proof.get('archive_parts',{}),reused_base_bytes=reused,literal_bytes=literal,
  note='Lossless representation of the complete actually tested negative ZIP. Copy slices and literal bytes reconstruct its exact bytes without rerendering, recompressing, changing scientific source or depending on a zlib version.')
 recovered=[]
 for op in ops:
  if 'copy' in op:
   start,length=op['copy'];assert 0<=start<=len(raw) and 0<=length<=len(raw)-start;recovered.append(raw[start:start+length])
  else:recovered.append(base64.b64decode(op['literal_base64'],validate=True))
 restored=b''.join(recovered);assert restored==target and rawpin(restored)==target_proof['archive'];del recovered,restored
 delta=OUT/(case+'-archive-delta.json');save(delta,recipe)
 deltas[case]=dict(archive_member='negative-archive-deltas/'+delta.name,delta=pin(delta),target_archive=target_proof['archive'],target_archive_parts=target_proof.get('archive_parts',{}),
  reconstructed_exact_bytes_verified=True,reused_base_bytes=reused,literal_bytes=literal)
 files=target_proof.get('archive_parts') or {'controls.zip':target_proof['archive']}
 for name,wanted in files.items():
  p=path/name;assert pin(p)==wanted;excluded[p]=dict(path=p.relative_to(TEST).as_posix(),file=wanted,represented_losslessly_by=deltas[case]['archive_member'])
 print(case,'full negative bytes',len(target),'reused',reused,'literal',literal,flush=True)
 del target,recipe,ops
members={}
def add(path,name):assert path.is_file() and not path.is_symlink() and name not in members;members[name]=path
pending=[TEST]
while pending:
 directory=pending.pop()
 for entry in os.scandir(directory):
  path=Path(entry.path)
  if entry.is_symlink():raise ValueError('Unexpected physical link in verifier test evidence')
  if entry.is_dir(follow_symlinks=False):pending.append(path)
  elif entry.is_file(follow_symlinks=False) and path not in excluded:add(path,'controls/'+path.relative_to(TEST).as_posix())
for case,row in deltas.items():add(OUT/Path(row['archive_member']).name,row['archive_member'])
save(OUT/'NEGATIVE_ARCHIVE_REPRESENTATIONS.json',dict(status='EXACT_TESTED_NEGATIVE_ARCHIVES_RETAINED_LOSSLESSLY_WITH_SHARED_BASE_AND_DELTAS',base_scientific_archive=proof['archive'],negative_archives=deltas,
 materialized_private_archive_parts=[excluded[p] for p in sorted(excluded)],private_materialized_archives_deleted=False,scientific_input_or_result_bytes_omitted=False))
add(OUT/'NEGATIVE_ARCHIVE_REPRESENTATIONS.json','NEGATIVE_ARCHIVE_REPRESENTATIONS.json');add(Path(__file__),'orchestration/'+Path(__file__).name)
archive=OUT/'verifier-boundary-controls-complete.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(members.items()):
  info=zipfile.ZipInfo(name,(2026,11,14,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,p.read_bytes())
parts={}
if archive.stat().st_size<=90000000:shutil.copyfile(archive,DATA/'verifier-boundary-controls.zip')
else:
 with archive.open('rb') as f:
  index=1
  while True:
   piece=f.read(90000000)
   if not piece:break
   name='verifier-boundary-controls.zip.part'+str(index).zfill(3);(DATA/name).write_bytes(piece);parts[name]=rawpin(piece);index+=1
layout=dict(status='COMPLETE_FROZEN_VERIFIER_CONTROL_RECORDS_AND_LOSSLESS_NEGATIVE_ARCHIVE_INPUTS',files={name:pin(p) for name,p in sorted(members.items())},negative_archive_deltas=deltas,
 base_scientific_archive=proof['archive'],private_materialized_archive_parts_retained=[excluded[p] for p in sorted(excluded)],scientific_input_or_result_bytes_omitted=False)
save(DATA/'VERIFIER_BOUNDARIES_LAYOUT.json',layout)
record=dict(status=v['status'],controls=4,baseline_controls=1,calls=v['calls'],base_validation=pin(DATA/'VALIDATION.json'),base_scientific_archive=proof['archive'],
 additional_archive=pin(archive),additional_archive_parts=parts,additional_layout=pin(DATA/'VERIFIER_BOUNDARIES_LAYOUT.json'),additional_members=len(members),negative_archive_deltas=deltas,
 scientific_sources_changed=False,scientific_sources_overridden=False,verifier_source_changed=False,source_or_result_hashes_refreshed_in_original_checkpoint=False,
 negative_evidence_copies_explicitly_labelled=True,materialized_private_inputs_deleted=False,new_tool_credit=0,whole_goal_complete=False)
save(DATA/'VERIFIER_BOUNDARIES.json',record)
(DATA/'SHA256SUMS').write_text(''.join(pin(p)['sha256']+'  '+p.name+'\n' for p in sorted(DATA.iterdir()) if p.is_file() and p.name not in ['SHA256SUMS','.gitattributes']),encoding='ascii',newline='\n')
assert pin(DATA/'VALIDATION.json')==v['base_validation'] and module.archive_bytes(DATA,proof)==raw
save(OUT/'COMPLETED.json',dict(status='PASS_ADDITIONAL_FROZEN_GGPUBR_VERIFIER_REFUSALS_AND_LOSSLESS_ARCHIVE_RETENTION',controls=4,archive=record['additional_archive'],parts=len(parts),members=len(members),original_scientific_checkpoint_changed=False))
print(json.dumps(dict(status=record['status'],additional_archive=record['additional_archive'],parts=len(parts),members=len(members))),flush=True)
