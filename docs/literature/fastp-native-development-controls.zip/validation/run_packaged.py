from pathlib import Path
import concurrent.futures,hashlib,json,os,re,subprocess
R=Path('D:/projects/JLinAlg');B=R/'build/literature-review/fastp-runtime/native-development-1';O=B/'packaged-tests-1';O.mkdir()
jar=B/'package-2/omicsmatic-0.3.7-fastp-development.jar';assert jar.is_file()
libs=sorted((R/'build/literature-review/shapeit-runtime/owned-common-native-matrix-4/lib').glob('*.jar'));assert len(libs)==9
runner=O/'RunFastpReadFilter.java'
runner.write_text('''import java.io.PrintWriter;
import org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder;
import org.junit.platform.launcher.core.LauncherFactory;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;
public final class RunFastpReadFilter {
 private RunFastpReadFilter() { }
 public static void main(String[] args) {
  var request=LauncherDiscoveryRequestBuilder.request().selectors(selectClass("org.jlinalg.sequence.FastpReadFilterTest")).build();
  var listener=new SummaryGeneratingListener();LauncherFactory.create().execute(request,listener);
  listener.getSummary().printTo(new PrintWriter(System.out));listener.getSummary().printFailuresTo(new PrintWriter(System.out));
  if(listener.getSummary().getTestsFailedCount()>0||listener.getSummary().getTestsFoundCount()!=133)System.exit(1);
 }
}
''')
classes=O/'classes';classes.mkdir();j='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin'
subprocess.run([j+'/javac.exe','--release','17','-Xlint:all','-Werror','-cp',os.pathsep.join(map(str,libs)),'-d',str(classes),str(runner)],cwd=R,check=True)
subprocess.run([j+'/javac.exe','--release','17','-Xlint:all','-Werror','-cp',os.pathsep.join(map(str,[jar,*libs])),'-d',str(classes),str(R/'src/test/java/org/jlinalg/sequence/FastpReadFilterTest.java')],cwd=R,check=True)
entries=[classes,jar,R/'src/test/resources',*libs]
linux=lambda p:'/mnt/d/'+p.relative_to(Path('D:/')).as_posix()
runs=[('windows-java21',[j+'/java.exe','-Xmx128m','-XX:ActiveProcessorCount=2','-cp',os.pathsep.join(map(str,entries)),'RunFastpReadFilter']),
 ('windows-java25',['C:/Program Files/Common Files/Oracle/Java/javapath/java.exe','-Xmx128m','-XX:ActiveProcessorCount=2','-cp',os.pathsep.join(map(str,entries)),'RunFastpReadFilter']),
 ('linux-java21',['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/java','-Xmx128m','-XX:ActiveProcessorCount=2','-cp',':'.join(map(linux,entries)),'RunFastpReadFilter'])]
def execute(row):
 name,cmd=row
 with (O/(name+'.stdout')).open('xb') as out,(O/(name+'.stderr')).open('xb') as err:p=subprocess.run(cmd,cwd=R,stdout=out,stderr=err,timeout=1200)
 record=dict(name=name,command=cmd,exit_code=p.returncode,tests=133)
 (O/(name+'.observed.json')).write_text(json.dumps(record,indent=2)+'\n');text=(O/(name+'.stdout')).read_text(errors='replace');print(name,p.returncode,text[-5000:] if p.returncode else text[-650:],flush=True)
 assert p.returncode==0
 for count,label in [(133,'tests found'),(133,'tests successful'),(0,'tests failed'),(0,'tests aborted')]:assert re.search(r'\[\s*'+str(count)+' '+label+r'\s*\]',text),(name,label)
 return record
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:observed=list(pool.map(execute,runs))
record=dict(status='passed-133-actual-JAR-tests-per-JVM',tests_per_JVM=133,runs=observed,artifact=jar.relative_to(R).as_posix(),artifact_sha256=hashlib.sha256(jar.read_bytes()).hexdigest(),heap_mib=128,strict_Java_release=17)
(O/'summary.json').write_text(json.dumps(record,indent=2)+'\n');print(record['status'])
