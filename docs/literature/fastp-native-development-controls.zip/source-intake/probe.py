from pathlib import Path
import hashlib,json,os,platform,resource,shutil,subprocess,time
S=Path('/mnt/d/projects/JLinAlg/build/literature-review/fastp-runtime/source-intake-1'); O=Path('/opt/omicsmatic-fastp-source-audit-1'); O.mkdir()
rows=json.loads((S/'intake.json').read_bytes()); output=[]
def bounded():
 resource.setrlimit(resource.RLIMIT_AS,(3*1024**3,3*1024**3));resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_FSIZE,(32*1024**2,32*1024**2));os.setsid()
for row in rows:
 v=row['version']; home=O/v; home.mkdir(); source=S/row['binary']['path']; raw=source.read_bytes(); assert hashlib.sha256(raw).hexdigest()==row['binary']['sha256']; (home/'fastp').write_bytes(raw); (home/'fastp').chmod(0o755)
 record=dict(version=v,home=str(home),binary_sha256=row['binary']['sha256'],commands=[])
 for label,args in [('version',['--version']),('help',['--help'])]:
  command=[str(home/'fastp'),*args]; started=time.monotonic(); process=subprocess.run(command,cwd=home,capture_output=True,timeout=90,preexec_fn=bounded)
  (home/(label+'.stdout')).write_bytes(process.stdout);(home/(label+'.stderr')).write_bytes(process.stderr);record['commands'].append(dict(label=label,command=command,exit_code=process.returncode,seconds=time.monotonic()-started))
  if label=='version':assert process.returncode==0 and (process.stdout+process.stderr).strip()==('fastp '+v).encode()
 process=subprocess.run(['/usr/bin/ldd',str(home/'fastp')],capture_output=True,timeout=30);(home/'ldd.stdout').write_bytes(process.stdout);(home/'ldd.stderr').write_bytes(process.stderr)
 seq='ACGCTAGCATCGACTGATCGACTAGCATAGCTACGATCGATGCTAGCTAGCATGCATCGATGCTAGCATCGATGCATCGATGCTAGCATCGATGCATCGATG'
 (home/'reads.fq').write_text(''.join('@fixture:'+str(i)+'\n'+seq+'\n+\n'+'I'*len(seq)+'\n' for i in range(1,33)))
 command=[str(home/'fastp'),'--in1','reads.fq','--out1','processed.fq','--json','fastp.json','--html','fastp.html','--thread','1','--dont_overwrite'];started=time.monotonic();process=subprocess.run(command,cwd=home,capture_output=True,timeout=90,preexec_fn=bounded)
 (home/'health.stdout').write_bytes(process.stdout);(home/'health.stderr').write_bytes(process.stderr);record['commands'].append(dict(label='health',command=command,exit_code=process.returncode,seconds=time.monotonic()-started))
 record['status']='passed-original-version-and-small-health-only' if process.returncode==0 else 'health-failed-preserved'
 if process.returncode==0:
  report=json.loads((home/'fastp.json').read_bytes());record['reported_before']=report['summary']['before_filtering'];record['reported_after']=report['summary']['after_filtering'];assert report['summary']['before_filtering']['total_reads']==32
 (home/'probe.json').write_text(json.dumps(record,indent=2)+'\n');output.append(record);(S/'probe.json').write_text(json.dumps(output,indent=2)+'\n');print(v,record['status'],flush=True)
print('All owned probes terminal. Original outputs retained in persistent /opt homes.')
