from pathlib import Path
import hashlib,json,shutil
R=Path('D:/projects/JLinAlg');O=R/'build/literature-review/fastp-runtime/source-intake-1';sha=lambda raw:hashlib.sha256(raw).hexdigest()
rows=json.loads((O/'intake.json').read_bytes());pin=json.loads((O/'original-native-controls.json').read_bytes());source=O/pin['path'];assert sha(source.read_bytes())==pin['sha256']
dest=R/'src/test/resources/org/jlinalg/sequence/fastp-original';dest.mkdir(parents=True,exist_ok=False);shutil.copy2(source,dest/'native-controls.zip')
licenses=[next(iter(row['licenses'].values())) for row in rows];assert len(set(licenses))==1
notice=R/'src/main/resources/org/jlinalg/omics/fastp-MIT-NOTICE.txt';assert not notice.exists();notice.write_text(licenses[0],encoding='utf-8',newline='\n')
lock=dict(schema_version=1,status='original-download-pins-and-small-health-only',upstream='https://github.com/OpenGene/fastp',source_to_binary_reproduction_verified=False,runtime_analysis_admitted=False,license=dict(path='src/main/resources/org/jlinalg/omics/fastp-MIT-NOTICE.txt',sha256=sha(notice.read_bytes())),profiles=[])
for row in rows:
 v=row['version'];lock['profiles'].append(dict(profile='linux-x86_64-fastp-'+v,version=v,binary={k:row['binary'][k] for k in ['url','bytes','sha256']},source={k:row['source'][k] for k in ['url','bytes','sha256']},filter_source_sha256=sha((O/('source-'+v)/'src/filter.cpp').read_bytes())))
target=R/'tools/literature/fastp-runtime-lock.json';assert not target.exists();target.write_text(json.dumps(lock,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Lock SHA256',sha(target.read_bytes()),'fixture',pin['sha256'])
