from pathlib import Path
import hashlib,json,zipfile
O=Path('/opt/omicsmatic-fastp-download-1/report');S=Path('/mnt/d/projects/JLinAlg/build/literature-review/fastp-runtime/source-intake-1');sha=lambda raw:hashlib.sha256(raw).hexdigest()
manifest=json.loads((O/'manifest.json').read_bytes());assert (O/'COMPLETED.json').exists();assert set(p.name for p in O.iterdir())==set(manifest['files'])|{'manifest.json','COMPLETED.json'}
for name,pin in manifest['files'].items():raw=(O/name).read_bytes();assert len(raw)==pin['bytes'] and sha(raw)==pin['sha256']
record=dict(status='passed-complete-setup-report-census',publicly_omitted_runtime_payload='download.part',payload_retained_privately=str(O/'download.part'),payload_pin=manifest['files']['download.part'],reason='Original executable bytes remain private and are separately pinned and downloadable; all synthetic inputs/results and execution receipts are captured.',all_scientific_data_captured=True)
target=S/'download-setup-controls.zip';assert not target.exists()
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(O.iterdir()):
  if p.name!='download.part':z.write(p,p.name)
 z.writestr('capture.json',json.dumps(record,indent=2)+'\n')
print('Verified full original report census; captured all report data except the explicitly pinned private runtime binary.')
