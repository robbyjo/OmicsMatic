from pathlib import Path
import hashlib,json,tarfile,time,urllib.request,io
O=Path('D:/projects/JLinAlg/build/literature-review/fastp-runtime/source-intake-1')
VERSIONS=['0.22.0','0.23.2','0.25.0','1.0.1']
def digest(b):return hashlib.sha256(b).hexdigest()
def fetch(url,target,limit):
 assert not target.exists()
 request=urllib.request.Request(url,headers={'User-Agent':'OmicsMatic-scientific-runtime-source-audit/1'})
 with urllib.request.urlopen(request,timeout=60) as response,target.open('xb') as out:
  size=0
  while True:
   chunk=response.read(1024*1024)
   if not chunk:break
   size+=len(chunk);assert size<=limit,'Download capacity exceeded';out.write(chunk)
 raw=target.read_bytes();return dict(url=url,path=target.name,bytes=len(raw),sha256=digest(raw))
rows=[]
for version in VERSIONS:
 row=dict(version=version,status='source-intake-in-progress')
 try:
  row['source']=fetch('https://github.com/OpenGene/fastp/archive/refs/tags/v'+version+'.tar.gz',O/('fastp-'+version+'.tar.gz'),50_000_000)
  with tarfile.open(fileobj=io.BytesIO((O/row['source']['path']).read_bytes()),mode='r:gz') as archive:
   paths=archive.getnames();row['source_members']=len(paths)
   licenses=[p for p in paths if p.rsplit('/',1)[-1].lower() in ['license','license.txt','license.md','copying']]
   row['licenses']={p:archive.extractfile(p).read().decode() for p in licenses}
   for name in ['README.md','Makefile','src/duplicate.cpp','src/duplicate.h','src/options.cpp','src/main.cpp','src/version.h']:
    p='fastp-'+version+'/'+name
    if p in paths:
     raw=archive.extractfile(p).read();target=O/('source-'+version)/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
  row['binary']=fetch('https://opengene.org/fastp/fastp.'+version,O/('fastp.'+version),100_000_000)
  assert (O/row['binary']['path']).read_bytes()[:4]==b'\x7fELF'
  row['status']='downloaded-original-source-and-linux-binary-not-yet-executed'
 except Exception as failure:row.update(status='intake-failed-preserved',error=repr(failure))
 rows.append(row);(O/'intake.json').write_text(json.dumps(rows,indent=2)+'\n');print(version,row['status'],row.get('error',''),flush=True)
print('All intake attempts terminal; raw licenses and hashes retained. No runtime has been executed.')
