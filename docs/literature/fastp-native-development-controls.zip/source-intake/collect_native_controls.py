from pathlib import Path
import hashlib,json,os,random,resource,subprocess,time,zipfile
S=Path('/mnt/d/projects/JLinAlg/build/literature-review/fastp-runtime/source-intake-1'); O=Path('/opt/omicsmatic-fastp-native-controls-1'); O.mkdir()
VERSIONS=['0.22.0','0.23.2','0.25.0','1.0.1']; sha=lambda b:hashlib.sha256(b).hexdigest()
base=dict(front=0,tail=0,front_on=False,front_window=4,front_quality=20,right_on=False,right_window=4,right_quality=20,tail_on=False,tail_window=4,tail_quality=20,max_length=0,quality_on=True,qualified=15,unqualified_percent=40,average=0,maximum_n=5,length_on=True,minimum_length=15,filter_max_length=0,complexity_on=False,complexity_percent=30)
configs=[('default',{}),('quality-disabled',dict(quality_on=False)),('length-disabled',dict(length_on=False)),('all-disabled',dict(quality_on=False,length_on=False)),('zero-qualified',dict(qualified=0)),('all-poor',dict(qualified=93)),('none-poor-allowed',dict(unqualified_percent=0)),('all-poor-allowed',dict(unqualified_percent=100,maximum_n=50)),('average30',dict(average=30)),('no-uppercase-n',dict(maximum_n=0)),('minimum45',dict(minimum_length=45)),('maximum50',dict(filter_max_length=50)),('max-trim100',dict(max_length=100)),('max-trim4',dict(max_length=4,minimum_length=0)),('complexity0',dict(complexity_on=True,complexity_percent=0,minimum_length=0)),('complexity30',dict(complexity_on=True)),('complexity100',dict(complexity_on=True,complexity_percent=100,minimum_length=0)),('front1',dict(front=1,minimum_length=0)),('tail1',dict(tail=1,minimum_length=0)),('global30-100',dict(front=30,tail=100,minimum_length=0)),('cut-front1',dict(front_on=True,front_window=1,minimum_length=0)),('cut-front4',dict(front_on=True,minimum_length=0)),('cut-front20',dict(front_on=True,front_window=20,minimum_length=0)),('cut-tail1',dict(tail_on=True,tail_window=1,minimum_length=0)),('cut-tail4',dict(tail_on=True,minimum_length=0)),('cut-right1',dict(right_on=True,right_window=1,minimum_length=0)),('cut-right4',dict(right_on=True,minimum_length=0)),('cut-front-right-tail',dict(front_on=True,right_on=True,tail_on=True,minimum_length=0)),('global-with-all-cutting',dict(front=3,tail=2,front_on=True,right_on=True,tail_on=True,minimum_length=0)),('cut-boundary-low-tail',dict(right_on=True,right_window=4,right_quality=30,minimum_length=0)),('percent-at40',dict(quality_on=True,unqualified_percent=40,minimum_length=0))]
rng=random.Random(20261102); reads=[]
for n in [1,2,3,4,5,6,7,8,9,10,14,15,16,20,21,22,30,31,32,44,45,46,49,50,51,99,100,101,130,131,150]:
 for mode in range(8):
  seq=''.join(rng.choice('ACGT') for _ in range(n)); qs=[40]*n
  if mode==1:qs=[0]*n
  if mode==2:qs=[14 if i%5<2 else 15 for i in range(n)]
  if mode==3:qs=[30 if i%2 else 29 for i in range(n)]
  if mode==4:qs=[40 if i<n-4 else 0 for i in range(n)]
  if mode==5:qs=[40 if i>=4 else 0 for i in range(n)];seq='N'*min(3,n)+seq[min(3,n):]
  if mode==6:seq=('AC'*((n+1)//2))[:n]
  if mode==7:seq=('N'*6+'A'*n)[:n]
  reads.append(('@fixture:'+str(len(reads)+1),seq,''.join(chr(q+33) for q in qs)))
# Individual source corner cases: the final window, source's own cut example,
# literal lowercase N and simultaneous quality/length/complexity failures.
for seq,qual in [('ACGTA','III!!'),('ACGTA','IIII!'),('ACGT','!!!!'),('AAAAA','IIIII'),('ANnNA','IIIII'),('ACGTA','//000'),('ACGTA','/0000'),('TTTTAACCCCCCCCCCCCCCCCCCCCCCCCCCCCAATTTT','/////CCCCCCCCCCCC////CCCCCCCCCCCCCC////E')]:
 assert len(seq)==len(qual);reads.append(('@fixture:'+str(len(reads)+1),seq,qual))
input_bytes=''.join(h+'\n'+s+'\n+\n'+q+'\n' for h,s,q in reads).encode();summary=dict(versions=VERSIONS,configurations=len(configs),reads_per_protocol=len(reads),protocols=[],scientific_scope='Isolated native filter/cutting stage;adapter/poly-G/duplication disabled explicitly,not full original pipeline parity.')
def bounded():
 resource.setrlimit(resource.RLIMIT_AS,(3*1024**3,3*1024**3));resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_FSIZE,(32*1024**2,32*1024**2));os.setsid()
def args(c):
 a=[]
 for key,flag in [('front','trim_front1'),('tail','trim_tail1'),('max_length','max_len1'),('qualified','qualified_quality_phred'),('unqualified_percent','unqualified_percent_limit'),('average','average_qual'),('maximum_n','n_base_limit'),('minimum_length','length_required'),('filter_max_length','length_limit'),('complexity_percent','complexity_threshold')]:a+=['--'+flag,str(c[key])]
 for key,flag in [('front_on','cut_front'),('right_on','cut_right'),('tail_on','cut_tail'),('complexity_on','low_complexity_filter')]:
  if c[key]:a+=['--'+flag]
 if not c['quality_on']:a+=['--disable_quality_filtering']
 if not c['length_on']:a+=['--disable_length_filtering']
 for mode in ['front','right','tail']:a+=['--cut_'+mode+'_window_size',str(c[mode+'_window']),'--cut_'+mode+'_mean_quality',str(c[mode+'_quality'])]
 return a
for v in VERSIONS:
 version=O/v;version.mkdir()
 for name,override in configs:
  c={**base,**override}; case=version/name;case.mkdir();(case/'input.fq').write_bytes(input_bytes)
  (case/'options.tsv').write_text('\t'.join(c)+'\n'+'\t'.join(str(x).lower() if isinstance(x,bool) else str(x) for x in c.values())+'\n')
  binary=Path('/opt/omicsmatic-fastp-source-audit-1')/v/'fastp'; intake=next(row for row in json.loads((S/'intake.json').read_bytes()) if row['version']==v);assert sha(binary.read_bytes())==intake['binary']['sha256']
  command=[str(binary),'--in1','input.fq','--out1','output.fq','--failed_out','failed.fq','--json','fastp.json','--html','fastp.html','--thread','1','--disable_adapter_trimming','--disable_trim_poly_g','--dont_eval_duplication','--dont_overwrite',*args(c)]
  start=time.monotonic();p=subprocess.run(command,cwd=case,capture_output=True,timeout=90,preexec_fn=bounded);(case/'stdout').write_bytes(p.stdout);(case/'stderr').write_bytes(p.stderr)
  record=dict(version=v,case=name,command=command,exit_code=p.returncode,seconds=time.monotonic()-start,binary_sha256=intake['binary']['sha256']);(case/'observed.json').write_text(json.dumps(record,indent=2)+'\n');summary['protocols'].append(record);(O/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
  assert p.returncode==0,(v,name,p.returncode,p.stderr[-500:])
 print(v,'completed',len(configs),'original native-stage controls',flush=True)
archive=S/'original-native-controls.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for path in sorted(O.rglob('*')):
  if path.is_file():z.write(path,path.relative_to(O).as_posix())
pin=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),protocols=len(summary['protocols']),reads_per_protocol=len(reads),all_owned_processes_terminal=True)
(S/'original-native-controls.json').write_text(json.dumps(pin,indent=2)+'\n');print(json.dumps(pin))
