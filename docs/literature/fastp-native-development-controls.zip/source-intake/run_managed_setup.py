from pathlib import Path
import hashlib,json,shutil,subprocess,sys,zipfile
R=Path('/mnt/d/projects/JLinAlg'); S=R/'build/literature-review/fastp-runtime/source-intake-1'; O=Path('/opt/omicsmatic-fastp-managed-1'); O.mkdir();(O/'cache').mkdir()
rows=json.loads((S/'intake.json').read_bytes()); results=[]
for row in rows:
 v=row['version'];source=S/row['binary']['path'];assert hashlib.sha256(source.read_bytes()).hexdigest()==row['binary']['sha256'];shutil.copy2(source,O/'cache'/source.name)
 command=[sys.executable,str(R/'tools/literature/install_fastp.py'),'--profile','linux-x86_64-fastp-'+v,'--home',str(O/'homes'/v),'--report',str(O/'reports'/v),'--cache',str(O/'cache'),'--allow-install']
 process=subprocess.run(command,capture_output=True,timeout=300);(O/('setup-'+v+'.stdout')).write_bytes(process.stdout);(O/('setup-'+v+'.stderr')).write_bytes(process.stderr);record=dict(version=v,command=command,exit_code=process.returncode);results.append(record);(S/'managed-setup.json').write_text(json.dumps(results,indent=2)+'\n');print(v,'setup exit',process.returncode,flush=True)
 assert process.returncode==0,(v,process.stderr[-1000:],process.stdout[-1000:])
archive=S/'managed-setup-controls.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for path in sorted(O.rglob('*')):
  if path.is_file() and ('reports' in path.relative_to(O).parts or path.name.startswith('setup-')):z.write(path,path.relative_to(O).as_posix())
print('All four managed setup/health protocols terminal; binaries stay private.')
