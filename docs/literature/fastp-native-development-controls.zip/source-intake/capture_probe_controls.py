from pathlib import Path
import json,zipfile
O=Path('/opt/omicsmatic-fastp-source-audit-1');S=Path('/mnt/d/projects/JLinAlg/build/literature-review/fastp-runtime/source-intake-1');target=S/'original-probe-controls.zip';assert not target.exists()
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(O.rglob('*')):
  if p.is_file() and p.name!='fastp':z.write(p,p.relative_to(O).as_posix())
print('Captured all original setup/probe raw files except private executable binaries.')
