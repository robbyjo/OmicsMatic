from pathlib import Path
import json,subprocess,sys,zipfile
R=Path('/mnt/d/projects/JLinAlg');S=R/'build/literature-review/fastp-runtime/source-intake-1';O=Path('/opt/omicsmatic-fastp-setup-recovery-1');O.mkdir();rows=[]
for name,extra,expected in [('install-forbidden',[],3),('download-forbidden',['--allow-install'],3),('corrupt-cache',['--allow-install'],2),('unmanaged-home',[],2),('verified-reuse',[],0)]:
 case=O/name;case.mkdir();home=case/'home';cache=case/'cache';report=case/'report'
 if name=='corrupt-cache':cache.mkdir();(cache/'fastp.0.23.2').write_bytes(b'corrupt-binary-preserve')
 if name=='unmanaged-home':home.mkdir();(home/'keep-user-file').write_bytes(b'keep')
 if name=='verified-reuse':home=Path('/opt/omicsmatic-fastp-managed-1/homes/0.23.2')
 cmd=[sys.executable,str(R/'tools/literature/install_fastp.py'),'--profile','linux-x86_64-fastp-0.23.2','--home',str(home),'--report',str(report),'--cache',str(cache),*extra];p=subprocess.run(cmd,capture_output=True,timeout=300);(case/'stdout').write_bytes(p.stdout);(case/'stderr').write_bytes(p.stderr);row=dict(case=name,command=cmd,expected_exit_code=expected,exit_code=p.returncode);rows.append(row);(O/'summary.json').write_text(json.dumps(rows,indent=2)+'\n');assert p.returncode==expected,(name,p.returncode,p.stdout[-800:],p.stderr[-800:]);print(name,p.returncode,flush=True)
 if name=='corrupt-cache':assert (cache/'fastp.0.23.2').read_bytes()==b'corrupt-binary-preserve'
 if name=='unmanaged-home':assert (home/'keep-user-file').read_bytes()==b'keep'
 if expected:assert not (report/'COMPLETED.json').exists()
archive=S/'setup-recovery-controls.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(O.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(O).as_posix())
print('Every owned recovery/skip protocol is terminal; unchanged managed runtime reuse passed.')
