package org.jlinalg.fusion;
public final class FusionComponentSelfTest {
 public static void main(String[] args)throws Exception {
  var test=new FusionAssociationTest();
  test.all6561OriginalAlleleLogicalCasesIncludingUnknownAndMissingValues();
  test.all136OriginalPreparedAssociationsRetain118CompleteAnd18NoResultCases();
  test.missingZeroWeightMarkerStillPropagatesOriginalNaNInsteadOfBeingDropped();
  test.callerInputsAndReturnedArraysAreNotMutableAliases();
  test.invalidMatricesCapacitiesAndInfiniteInputsFailExplicitly();
  System.out.println("PASS: actual packaged FUSION component;6561 original allele cases;136 original prepared associations (118 complete,18 no-result);three additional admission/ownership/numeric tests");
 }
}
