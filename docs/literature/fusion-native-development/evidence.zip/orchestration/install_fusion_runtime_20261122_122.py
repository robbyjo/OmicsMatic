from pathlib import Path
import json,os,subprocess,time
T=Path('D:/projects/JLinAlg/build/gp-1');B=T/'build/fusion-1/runtime-install-1';B.mkdir();lib=B/'library';lib.mkdir();downloads=B/'downloads';downloads.mkdir();tmp=B/'tmp';tmp.mkdir()
script=B/'install.R';script.write_text('''args <- commandArgs(TRUE)
lib <- normalizePath(args[1],winslash="/",mustWork=TRUE)
.libPaths(c(lib,.Library))
options(repos=c(CRAN="https://cloud.r-project.org"),timeout=60)
packages <- c("here","optparse","glmnet","coloc","susieR")
install.packages(packages,lib=lib,type="binary",dependencies=c("Depends","Imports","LinkingTo"),destdir=args[2])
installed <- installed.packages(lib.loc=lib)
write.table(installed[,c("Package","Version","License"),drop=FALSE],file=args[3],sep="\\t",quote=FALSE,row.names=FALSE)
for (p in packages) if(!requireNamespace(p,quietly=TRUE)) stop(paste("SKIP3: private installation unavailable:",p))
print(sessionInfo())
''',encoding='utf-8',newline='\n')
args=['C:/Program Files/R/R-4.6.1/bin/Rscript.exe','--vanilla',str(script),str(lib),str(downloads),str(B/'PACKAGES.tsv')];env=dict(os.environ,R_LIBS_USER=str(lib),R_LIBS_SITE='',TMPDIR=str(tmp));(B/'COMMAND.json').write_text(json.dumps({'arguments':args,'private_library_only':str(lib),'excluded_global_user_libraries':True},indent=2)+'\n',encoding='utf-8')
with (B/'stdout').open('xb') as out,(B/'stderr').open('xb') as err:
 p=subprocess.Popen(args,cwd=T,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err);(B/'PROCESS.json').write_text(json.dumps({'pid':p.pid,'started_unix':time.time()})+'\n');code=p.wait()
(B/'RESULT.json').write_text(json.dumps({'exit_code':code,'private_library':str(lib),'required_packages':['here','optparse','glmnet','coloc','susieR'],'global_installation_requested':False},indent=2)+'\n');print(json.dumps({'exit_code':code,'evidence':str(B)}))
