from pathlib import Path
import hashlib,json,os,subprocess,xml.etree.ElementTree as ET,zipfile
T=Path('D:/projects/JLinAlg/build/gp-1');B=T/'build/fusion-1/packaged-reference-1';B.mkdir();normal=T/'build/fusion-1/normal-build-1';jar=normal/'project-build/cli/omicsmatic-0.4.0.jar';cache=Path('C:/Users/User/.gradle/caches/modules-2/files-2.1')
libs=[]
for pattern in ['org.junit.jupiter/junit-jupiter-api/5.13.4/*/*.jar','org.opentest4j/opentest4j/1.3.0/*/*.jar','org.apiguardian/apiguardian-api/1.1.2/*/*.jar']:
 found=list(cache.glob(pattern));assert len(found)==1,(pattern,found);libs+=found
src=B/'FusionComponentSelfTest.java';src.write_text('''package org.jlinalg.fusion;
public final class FusionComponentSelfTest {
 public static void main(String[] args)throws Exception {
  var test=new FusionAssociationTest();
  test.all6561OriginalAlleleLogicalCasesIncludingUnknownAndMissingValues();
  test.all136OriginalPreparedAssociationsRetain118CompleteAnd18NoResultCases();
  test.missingZeroWeightMarkerStillPropagatesOriginalNaNInsteadOfBeingDropped();
  test.callerInputsAndReturnedArraysAreNotMutableAliases();
  test.invalidMatricesCapacitiesAndInfiniteInputsFailExplicitly();
  System.out.println("PASS: actual packaged FUSION component;6561 original allele cases;136 original prepared associations (118 complete,18 no-result);three additional admission/ownership/numeric tests");
 }
}
''',encoding='utf-8',newline='\n');classes=B/'classes';classes.mkdir();paths=[jar,normal/'project-build/classes/java/test',normal/'project-build/resources/test',*libs];compiler='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/javac.exe';compile=subprocess.run([compiler,'--release','17','-cp',';'.join(map(str,paths)),'-d',str(classes),str(src)],cwd=T,capture_output=True);(B/'compile.stdout').write_bytes(compile.stdout);(B/'compile.stderr').write_bytes(compile.stderr);assert compile.returncode==0,compile.stderr
runs=[]
for name,java in [('windows21','C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe'),('windows25','C:/Program Files/Java/jdk-25/bin/java.exe'),('linux21',None)]:
 if java:args=[java,'-Xmx1g','-cp',';'.join(map(str,[classes,*paths])),'org.jlinalg.fusion.FusionComponentSelfTest']
 else:
  def linux(p):s=str(p).replace('\\','/');return '/mnt/'+s[0].lower()+s[2:]
  args=['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','java','-Xmx1g','-cp',':'.join(map(linux,[classes,*paths])),'org.jlinalg.fusion.FusionComponentSelfTest']
 with (B/(name+'.stdout')).open('xb') as out,(B/(name+'.stderr')).open('xb') as err:process=subprocess.Popen(args,cwd=T,stdin=subprocess.DEVNULL,stdout=out,stderr=err);code=process.wait()
 runs.append({'platform':name,'exit_code':code,'arguments':args});assert code==0,(name,(B/(name+'.stderr')).read_text(errors='replace'))
reports=[ET.parse(p).getroot() for p in (normal/'project-build/test-results/test').glob('TEST-*.xml')];counts={k:sum(int(r.attrib[k]) for r in reports) for k in ['tests','failures','errors','skipped']};assert counts['failures']==counts['errors']==counts['skipped']==0
old=T/'build/gprofiler-workflow-1/normal-build-2/project-build/cli/omicsmatic-0.4.0.jar'
with zipfile.ZipFile(old) as a,zipfile.ZipFile(jar) as b:
 ai={n:hashlib.sha256(a.read(n)).hexdigest() for n in a.namelist() if not n.endswith('/')};bi={n:hashlib.sha256(b.read(n)).hexdigest() for n in b.namelist() if not n.endswith('/')};changed=[n for n in ai if ai[n]!=bi.get(n)];added=sorted(set(bi)-set(ai));assert not changed,changed
result={'status':'PASS_ACTUAL_PACKAGED_FUSION_COMPONENT_THREE_JVMS_AND_PREVIOUS_PAYLOAD_PRESERVATION','normal_tests':counts,'original_allele_cases':6561,'original_association_cases':136,'original_complete':118,'original_no_result':18,'platforms':runs,'previous_payloads_identical':len(ai),'changed_previous_payloads':changed,'new_payloads':added,'producer':{'bytes':jar.stat().st_size,'sha256':hashlib.sha256(jar.read_bytes()).hexdigest()},'new_family_credit':0,'whole_tool_qualified':False,'whole_goal_complete':False}
(B/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in result.items() if k!='platforms'}))
