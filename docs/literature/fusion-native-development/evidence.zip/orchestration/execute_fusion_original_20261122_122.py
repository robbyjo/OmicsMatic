from pathlib import Path
import hashlib,json,math,os,random,shutil,subprocess,time
T=Path('D:/projects/JLinAlg/build/gp-1');B=T/'build/fusion-1/original-association-1';B.mkdir();source=B/'source';source.mkdir();(source/'utils').mkdir();original=T/'build/fusion-1/upstream-intake-1/source'
for name in ['FUSION.assoc_test.R','utils/plink_utils.R','LICENSE']:shutil.copyfile(original/name,source/name)
(source/'.here').write_bytes(b'');data=B/'data';data.mkdir();weights=data/'weights';weights.mkdir();rng=random.Random(9346);n=64;p=12
rows=[]
for i in range(n):
 latent=rng.choices([0,1,2],[.3,.4,.3])[0];rows.append([latent if rng.random()<.8 else rng.randrange(3) for j in range(p)])
(data/'ref.1.fam').write_text(''.join(f'ART{i:03d} ART{i:03d} 0 0 0 {i%11+0.125}\n' for i in range(n)),encoding='ascii',newline='\n')
(data/'ref.1.bim').write_text(''.join(f'1 synth{i:03d} 0 {100000+i*1000} A C\n' for i in range(p)),encoding='ascii',newline='\n')
raw=bytearray([0x6c,0x1b,1]);enc={0:3,1:2,2:0}
for j in range(p):
 for start in range(0,n,4):raw.append(sum(enc[rows[i][j]]<<(2*(i-start)) for i in range(start,min(start+4,n))))
(data/'ref.1.bed').write_bytes(raw)
for name,missing,beta in [('complete',False,False),('missing',True,False),('beta-se',False,True)]:
 text='SNP A1 A2 Z'+(' BETA SE' if beta else '')+'\n'
 for j in range(p):
  if missing and j in [2,4,7,10]:continue
  z=5+math.sin(j);text+=f'synth{j:03d} A C {z:.17g}'+(f' {z/100:.17g} 0.01' if beta else '')+'\n'
 (data/(name+'.sumstats')).write_text(text,encoding='ascii',newline='\n')
fixture=B/'make_weights.R';fixture.write_text('''args<-commandArgs(TRUE)
snps<-read.table(paste0(args[1],"/ref.1.bim"),stringsAsFactors=FALSE)
set.seed(9346)
for(i in 1:3){
 wgt.matrix<-cbind(enet=sin(seq_len(nrow(snps))+i)/5,top1=seq_len(nrow(snps))/2,blup=cos(seq_len(nrow(snps)))/5)
 rownames(wgt.matrix)<-snps[,2]
 cv.performance<-matrix(c(.2,.0001,.1,.01,.15,.001),nrow=2,dimnames=list(c("rsq","pval"),c("enet","top1","blup")))
 hsq<-.4;hsq.pv<-.001;N.tot<-64
 save(wgt.matrix,snps,cv.performance,hsq,hsq.pv,N.tot,file=paste0(args[1],"/weights/g",i,".wgt.RDat"))
}
write.table(data.frame(WGT=paste0("g",1:3,".wgt.RDat"),ID=paste0("SYNTH_GENE_",1:3),CHR=1,P0=100000,P1=111000,N=64),file=paste0(args[1],"/weights.pos"),sep="\\t",quote=FALSE,row.names=FALSE)
''',encoding='utf-8',newline='\n')
R='C:/Program Files/R/R-4.6.1/bin/Rscript.exe';lib=T/'build/fusion-1/runtime-install-1/library';env=dict(os.environ,R_LIBS_USER=str(lib),R_LIBS_SITE='')
def run(name,args,cwd=source):
 with (B/(name+'.stdout')).open('xb') as out,(B/(name+'.stderr')).open('xb') as err:
  process=subprocess.Popen(args,cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err);code=process.wait()
 (B/(name+'.PROCESS.json')).write_text(json.dumps({'arguments':args,'exit_code':code,'cwd':str(cwd)},indent=2)+'\n');return code
assert run('make-weights',[R,'--vanilla',str(fixture),str(data)])==0
records=[]
for name,extra in [('complete',[]),('missing',[]),('beta-se',['--coloc_P','1']),('coloc',['--coloc_P','1','--GWASN','10000']),('forced-top1',['--force_model','top1'])]:
 stats='missing' if name=='missing' else 'beta-se' if name=='beta-se' else 'complete';destination=B/(name+'.out.tsv');args=[R,'--vanilla',str(source/'FUSION.assoc_test.R'),'--sumstats',str(data/(stats+'.sumstats')),'--weights',str(data/'weights.pos'),'--weights_dir',str(weights),'--ref_ld_chr',str(data/'ref.'),'--chr','1','--out',str(destination),*extra]
 code=run(name,args);record={'case':name,'exit_code':code,'original_output_present':destination.is_file()};records.append(record);(B/'PROGRESS.json').write_text(json.dumps(records,indent=2)+'\n');assert code==0,(name,(B/(name+'.stderr')).read_text(errors='replace'))
 assert destination.is_file(),(name,'Original exited without required output')
result={'status':'ORIGINAL_FUSION_ASSOCIATION_INTAKE_FIVE_CASES_EXECUTED','cases':records,'upstream_commit':'9346c1222bffbb34499fa7a8e23c1b701b55cb05','adapter_implemented':False,'whole_tool_qualified':False,'new_family_credit':0,'synthetic_inputs_only':True}
(B/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
