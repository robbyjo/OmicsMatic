from pathlib import Path
import copy,hashlib,json,shutil,subprocess,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/handover-98';O=R/'build/git-publish/20261121-handover-responses-98';B=T/'build/handover-98-checks/controls';Q='docs/literature/handover-2026-11-21-responses'
PY='C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def put(path,value):path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
def rebuild(root,logical,edit):
    folder=root/Q;inventory=json.loads((folder/'INVENTORY.json').read_bytes())
    with zipfile.ZipFile(folder/'evidence.zip') as z:blobs={name:z.read(name) for name in z.namelist()}
    row=inventory[logical];value=json.loads(blobs['blobs/'+row['sha256']]);edit(value);raw=(json.dumps(value,indent=2)+'\n').encode();inventory[logical]=pin(raw);blobs['blobs/'+pin(raw)['sha256']]=raw
    needed={'blobs/'+v['sha256'] for v in inventory.values()}
    with zipfile.ZipFile(folder/'evidence.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
        for name in sorted(needed):z.writestr(name,blobs[name])
    put(folder/'INVENTORY.json',inventory)
    profile=json.loads((folder/'PROFILE.json').read_bytes())
    for name in ['INVENTORY.json','evidence.zip']:profile['packet_files'][name]=pin((folder/name).read_bytes())
    put(folder/'PROFILE.json',profile)

if __name__=='__main__':
    B.mkdir(parents=True,exist_ok=False);profile=json.loads((T/Q/'PROFILE.json').read_bytes())
    sources=set(profile['source_inputs'])|set(profile['canonical_unchanged'])|{Q+'/'+name for name in profile['packet_files']}|{Q+'/PROFILE.json'}
    results={}
    for label,expected in [('source-tamper','Changed source/canonical bytes'),('promoted-partial-run','Unadmitted original attempt was promoted'),('forged-source-equality','Different retained source-identity diagnosis')]:
        root=B/label/'checkout';root.mkdir(parents=True)
        for name in sources:
            target=root/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(T/name,target)
        if label=='source-tamper':
            target=root/'tools/literature/monocle_responses/development/files/src/main/java/org/jlinalg/singlecell/MonocleResponsePreparation.java';target.write_bytes(target.read_bytes()+b'\n// changed control\n')
        elif label=='promoted-partial-run':rebuild(root,'current/response-reference-3/PROCESS.json',lambda value:value.update(exit_code=0))
        else:rebuild(root,'current/guard-diagnosis-1/RESULT.json',lambda value:value['after'].update(source_body_identical=False))
        command=[PY,'-X','utf8','-B',str(root/'tools/literature/monocle_responses/verify_handover.py'),'--out',str(B/label/'result')]
        put(B/label/'STARTED.json',dict(command=command,expected_exit=2,expected_message=expected,owned_negative_control=True))
        with (B/label/'stdout').open('xb') as stdout,(B/label/'stderr').open('xb') as stderr:p=subprocess.run(command,cwd=root,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=120)
        put(B/label/'PROCESS.json',dict(exit_code=p.returncode));error=(B/label/'stderr').read_text(encoding='utf-8');assert p.returncode==2 and expected in error,(label,p.returncode,error)
        results[label]=dict(exit_code=p.returncode,expected_exit=2,expected_message=expected,refused=True)
        print('PASS refusal',label,flush=True)
    result=dict(status='PASS3_OWNED_HANDOVER_TAMPER_AND_FALSE_ADMISSION_REFUSALS',controls=results,scientific_analyses_run=0,original_sources_and_packets_modified=False)
    put(B/'RESULT.json',result);put(O/'NEGATIVE-CONTROLS.json',result)
