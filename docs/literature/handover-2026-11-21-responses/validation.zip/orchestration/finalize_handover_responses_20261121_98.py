from pathlib import Path
import ast,hashlib,importlib.util,json,re,subprocess,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/handover-98';D=R/'build/mo-6';O=R/'build/git-publish/20261121-handover-responses-98';Q=T/'docs/literature/handover-2026-11-21-responses';B=T/'build/handover-98-checks';BASE='a4e025527bc8e5b3580002397056fcc33e1d6918'
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
def git(root,*args):return subprocess.check_output(['git','--no-replace-objects',*args],cwd=root)
if __name__=='__main__':
    for host in ['windows','linux']:assert json.loads((O/('reader-'+host+'.PROCESS.json')).read_bytes())['exit_code']==0
    a=json.loads((B/'windows/RESULT.json').read_bytes());b=json.loads((B/'linux/RESULT.json').read_bytes());assert a.pop('restored') is True and b.pop('restored') is False and a==b
    assert a['historical_worktrees']==54 and a['git_visible_files']==2201 and a['logical_evidence_files']==107
    states=json.loads((Q/'WORKTREES.json').read_bytes());restored_files=patches=0
    with zipfile.ZipFile(Q/'deltas.zip') as z:
        for index,state in enumerate(states):
            root=B/'windows/worktrees'/f'{index:02d}';assert json.loads((root/'STATE.json').read_bytes())==state
            assert (root/'INDEX.patch').read_bytes()==z.read(state['index_patch']['member']);patches+=1
            for name,wanted in state['files'].items():
                path=root/'files'/name
                if wanted is None:assert not path.exists();continue
                assert pin(path.read_bytes())=={k:wanted[k] for k in ['bytes','sha256']},name;restored_files+=1
    inventory=json.loads((Q/'INVENTORY.json').read_bytes())
    for name,wanted in inventory.items():assert pin((B/'windows/evidence'/name).read_bytes())==wanted,name
    mapping=json.loads((T/'tools/literature/monocle_responses/development/RESTORE.json').read_bytes());assert len(mapping)==4
    for name,row in mapping.items():assert (D/name).read_bytes()==(T/row['draft']).read_bytes(),name
    old=git(T,'show',BASE+':docs/literature/HANDOVER_CURRENT.md');new=(T/'docs/literature/HANDOVER_CURRENT.md').read_bytes();heading=b'# Current toolbox handover\n\n';assert old.startswith(heading) and new.startswith(heading) and new.endswith(old[len(heading):])
    # Validate relative document links without fetching external references.
    linked=0
    for path in [T/'docs/literature/HANDOVER_2026-11-21_RESPONSES.md',T/'tools/literature/monocle_responses/development/README.md',Q/'README.md']:
        for name in re.findall(r'\]\(([^)]+)\)',path.read_text(encoding='utf-8')):
            if ':' in name or name.startswith('#'):continue
            assert (path.parent/name.split('#',1)[0]).resolve().exists(),(str(path),name);linked+=1
    prior=json.loads((R/'build/mo-5/build/handover-98-frozen-graph-check-1/RESULT.json').read_bytes());assert prior['tests_per_JVM']==824 and prior['R_Java_XML_or_scientific_models_executed'] is False
    catalog=json.loads((T/'build/handover-98-catalog-check-1/RESULT.json').read_bytes());assert (catalog['papers'],catalog['integration_families'],catalog['reviewed'],catalog['pending'],catalog['manifest_entries'])==(250,144,1630,1092,838)
    controls=json.loads((O/'NEGATIVE-CONTROLS.json').read_bytes());assert len(controls['controls'])==3 and all(row['refused'] and row['exit_code']==2 for row in controls['controls'].values())
    profile=json.loads((Q/'PROFILE.json').read_bytes())
    for name,wanted in profile['canonical_unchanged'].items():assert pin((T/name).read_bytes())==wanted,name
    spec=importlib.util.spec_from_file_location('inventory',O.parent/'20261115-all-main-3/inventory.py');inv=importlib.util.module_from_spec(spec);spec.loader.exec_module(inv)
    originals=json.loads((O/'WORKTREES-BEFORE.json').read_bytes())
    for state in originals:assert inv.snapshot(Path(state['root']))==state,state['root']
    sources={}
    for name in ['run_handover_responses_checks_20261121_98.py','control_handover_responses_20261121_98.py','finalize_handover_responses_20261121_98.py']:
        sources['orchestration/'+name]=R/'build'/name
    for host in ['windows','linux']:
        for suffix in ['STARTED.json','PROCESS.json','stdout','stderr']:sources['reader-'+host+'/'+suffix]=O/('reader-'+host+'.'+suffix)
        sources['reader-'+host+'/RESULT.json']=B/host/'RESULT.json'
    for label in controls['controls']:
        for name in ['STARTED.json','PROCESS.json','stdout','stderr','result/FAILURE.txt']:sources['controls/'+label+'/'+name]=B/'controls'/label/name
    sources['controls/RESULT.json']=B/'controls/RESULT.json';sources['preceding/P96-RESULT.json']=R/'build/mo-5/build/handover-98-frozen-graph-check-1/RESULT.json';sources['catalog/RESULT.json']=T/'build/handover-98-catalog-check-1/RESULT.json'
    saved={}
    with zipfile.ZipFile(Q/'validation.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,path in sorted(sources.items()):
            raw=path.read_bytes();info=zipfile.ZipInfo(name,(2026,11,21,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,raw);saved[name]=pin(raw)
    result=dict(status='PASS_RESPONSE_HANDOVER_TRANSPORT_AND_SCOPE_CHECKS_ONLY',baseline=BASE,original_worktrees_preserved=54,git_visible_files_restored_exact=restored_files,staged_patches_restored_exact=patches,evidence_files_restored_exact=len(inventory),draft_files_saved_exact=4,windows_restore_and_linux_verify_pass=True,negative_controls=controls['controls'],relative_document_links_checked=linked,prior_handover_bytes_retained_exact=True,production_source_build_site_changed=False,canonical_files_unchanged=len(profile['canonical_unchanged']),current_catalog=dict(papers=250,scoped_families=144,native=26,upstream=118,reviewed=1630,pending=1092,manifest_entries=838),latest_draft_syntax=json.loads((Q/'SYNTAX-VALIDATION.json').read_bytes()),profile=pin((Q/'PROFILE.json').read_bytes()),validation_archive=pin((Q/'validation.zip').read_bytes()),validation_members=saved,scientific_analyses_run=0,draft_fixture_missing=True,draft_api_or_cli_test_suite_run=False,new_catalog_credit=0,whole_goal_complete=False)
    save(Q/'VALIDATION.json',result);save(O/'VALIDATION.json',result)
    assert not git(T,'diff',BASE,'--name-only','--','src','site','.github','build.gradle','settings.gradle','gradle.properties')
    print('PASS54 owners preserved;2201 file variants/54 staged patches/107 evidence members restored exactly;3 forged-scope refusals;draft remains unqualified',flush=True)
