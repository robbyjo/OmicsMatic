from pathlib import Path
import argparse,json,subprocess
R=Path('D:/projects/JLinAlg');T=R/'build/handover-98';O=R/'build/git-publish/20261121-handover-responses-98';B=T/'build/handover-98-checks'
P='C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
def save(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('label',choices=['windows','linux']);args=p.parse_args();label=args.label;out=B/label
    if label=='windows':command=[P,'-X','utf8','-B',str(T/'tools/literature/monocle_responses/verify_handover.py'),'--out',str(out),'--restore']
    else:command=['wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','--user','root','--exec','/usr/bin/python3','-B','/mnt/d/projects/JLinAlg/build/handover-98/tools/literature/monocle_responses/verify_handover.py','--out','/mnt/d/projects/JLinAlg/build/handover-98/build/handover-98-checks/linux','--git','/mnt/c/Program Files/Git/cmd/git.exe']
    save(O/('reader-'+label+'.STARTED.json'),dict(command=command))
    with (O/('reader-'+label+'.stdout')).open('xb') as stdout,(O/('reader-'+label+'.stderr')).open('xb') as stderr:proc=subprocess.run(command,cwd=T,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=600)
    save(O/('reader-'+label+'.PROCESS.json'),dict(exit_code=proc.returncode));print(label,'reader exit',proc.returncode,flush=True)
    if proc.returncode:print((O/('reader-'+label+'.stderr')).read_text()[-3000:])
    else:print((out/'RESULT.json').read_text())
    raise SystemExit(proc.returncode)
