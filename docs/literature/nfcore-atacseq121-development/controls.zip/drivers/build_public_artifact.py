import hashlib,json,os,subprocess,time,traceback,zipfile
from pathlib import Path
base=Path(__file__).resolve().parent;root=base.parents[1];out=base/'build-7';out.mkdir()
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return dict(bytes=p.stat().st_size,sha256=h.hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
try:
 init=out/'private.gradle';relative=out.relative_to(root).as_posix()
 init.write_text("gradle.projectsEvaluated {\n rootProject.tasks.named('executableJar') { destinationDirectory.set(rootProject.layout.projectDirectory.dir('"+relative+"/jar')) }\n}\n",encoding='utf8',newline='\n')
 source_paths=[p for folder in ['src/main/java/org/jlinalg/cli','src/main/java/org/jlinalg/workflow'] for p in (root/folder).glob('NfcoreAtacseq121*.java')]
 source_paths += [root/'src/main/java/org/jlinalg/cli'/n for n in ['NfcoreToolsCli.java','NfcoreContainerSet.java','NfcoreScientificFiles.java','JLinAlgCli.java']]
 source_paths += list((root/'src/main/resources/org/jlinalg/omics/nfcore-atacseq121').glob('*'))
 sources={p.relative_to(root).as_posix():pin(p) for p in source_paths};save(out/'SOURCES.json',sources)
 command=[str(root/'gradlew.bat'),'--no-daemon','--console=plain','-I',str(init),':executableJar',':checkWebsite'];save(out/'command.json',command)
 env=dict(os.environ,JAVA_HOME='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot');began=time.monotonic()
 with (out/'stdout').open('xb') as so,(out/'stderr').open('xb') as se:
  child=subprocess.Popen(command,cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=so,stderr=se);save(out/'RUNNING.json',dict(pid=child.pid));child.wait(timeout=900)
 save(out/'PROCESS.json',dict(exit_code=child.returncode,seconds=time.monotonic()-began));assert child.returncode==0
 assert all(pin(root/n)==p for n,p in sources.items())
 old=base/'build-6/jar/omicsmatic-0.4.0.jar';new=out/'jar/omicsmatic-0.4.0.jar';changed=[];added=[]
 with zipfile.ZipFile(old) as a,zipfile.ZipFile(new) as b:
  assert len(a.namelist())==len(set(a.namelist())) and len(b.namelist())==len(set(b.namelist()))
  assert set(a.namelist())==set(b.namelist())
  for name in a.namelist():
   if a.read(name)!=b.read(name):changed.append(name)
 assert changed==['org/jlinalg/omics/nfcore-atacseq121/image-oci.json'],changed
 save(out/'COMPLETED.json',dict(status='PASS_SOURCE_BUILD_WEBSITE_AND_METADATA_ONLY_ARTIFACT_DELTA',artifact=pin(new),qualified_predecessor=pin(old),changed_members=changed,all_executable_classes_and_other_members_byte_identical=True,whole_goal_complete=False))
 print('PASS public-metadata artifact; every executable class unchanged',flush=True)
except Exception as error:
 save(out/'FAILURE.json',dict(status='FAIL2_PUBLIC_BUILD_NO_RESULT',error=repr(error),traceback=traceback.format_exc()));print(str(error),flush=True);raise
