import json,subprocess
from pathlib import Path
base=Path(__file__).resolve().parent
code=r'''
import hashlib,json,os,stat,tarfile,time,traceback
from pathlib import Path
out=Path('/mnt/d/projects/JLinAlg/build/high-impact-stats-1/build/nfcore-atacseq121-1/retained-native-attempts-1');out.mkdir()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return dict(bytes=p.stat().st_size,sha256=h.hexdigest())
try:
 records=[]
 for number in [2,3,4]:
  root=Path('/var/tmp/omicsmatic-atacseq121-run-'+str(number));inventory={};paths=[root]
  for d,ds,fs in os.walk(root,followlinks=False):paths.extend(Path(d)/n for n in ds+fs)
  for p in sorted(paths):
   s=p.lstat();row=dict(mode=stat.S_IMODE(s.st_mode))
   if stat.S_ISREG(s.st_mode):row.update(kind='file',**pin(p))
   elif stat.S_ISDIR(s.st_mode):row.update(kind='directory')
   elif stat.S_ISLNK(s.st_mode):row.update(kind='symlink',target=os.readlink(p))
   elif stat.S_ISFIFO(s.st_mode):row.update(kind='fifo')
   else:raise ValueError('Unexpected special member; no unsafe opening: '+str(p))
   inventory[str(p.relative_to(root.parent))]=row
  archive=out/('failed-run-'+str(number)+'.tar.gz')
  with tarfile.open(archive,'x:gz',compresslevel=1,dereference=False) as tf:
   for p in sorted(paths):tf.add(p,arcname=str(p.relative_to(root.parent)),recursive=False)
  with tarfile.open(archive,'r:gz') as tf:
   members=tf.getmembers();assert len(members)==len(inventory)
   assert {m.name for m in members}==set(inventory)
   for m in members:
    row=inventory[m.name];assert m.mode==row['mode']
    if row['kind']=='file':
     h=hashlib.sha256();count=0
     with tf.extractfile(m) as f:
      for b in iter(lambda:f.read(1048576),b''):h.update(b);count+=len(b)
     assert dict(bytes=count,sha256=h.hexdigest())=={k:row[k] for k in ['bytes','sha256']}
    elif row['kind']=='symlink':assert m.issym() and m.linkname==row['target']
    elif row['kind']=='directory':assert m.isdir()
    else:assert m.isfifo()
  for p in paths:
   row=inventory[str(p.relative_to(root.parent))]
   if row['kind']=='file':assert pin(p)=={k:row[k] for k in ['bytes','sha256']}
  save(out/('failed-run-'+str(number)+'.inventory.json'),inventory)
  record=dict(attempt=number,source=str(root),archive=archive.name,pin=pin(archive),members=len(inventory),full_member_readback=True,original_regular_bytes_unchanged=True,failed_wrapper_remains_failed=True)
  records.append(record);save(out/('failed-run-'+str(number)+'.receipt.json'),record);print('PASS retained failed native attempt',number,flush=True)
 save(out/'COMPLETED.json',dict(status='PASS_FULL_FAILED_NATIVE_ATTEMPTS_RETAINED',attempts=records,originals_deleted=False,links_followed=False,scientific_execution_performed=False))
except Exception as e:
 save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc()));raise
'''
command=['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--exec','/usr/bin/python3','-c',code]
raise SystemExit(subprocess.call(command))
