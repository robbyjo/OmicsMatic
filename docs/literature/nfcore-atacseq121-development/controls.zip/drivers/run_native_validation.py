import json,subprocess,time,traceback
from pathlib import Path
base=Path(__file__).resolve().parent;out=base/'original-run-5-launch';out.mkdir()
prefix='/mnt/d/projects/JLinAlg/build/high-impact-stats-1/'
native='/var/tmp/omicsmatic-atacseq121-native-engine-1'
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def run(label,command,timeout=9000):
 command=list(map(str,command));save(out/(label+'.command.json'),command);began=time.monotonic()
 with (out/(label+'.stdout')).open('xb') as so,(out/(label+'.stderr')).open('xb') as se:
  child=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=so,stderr=se)
  save(out/'RUNNING.json',dict(stage=label,pid=child.pid,command=command));child.wait(timeout=timeout)
 record=dict(exit_code=child.returncode,seconds=time.monotonic()-began);save(out/(label+'.PROCESS.json'),record)
 if child.returncode:raise RuntimeError(label+' failed; inspect exact retained logs')
 print('PASS',label,flush=True)
def wsl(*args):return ['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--exec',*args]
try:
 data=prefix+'build/nfcore-atacseq121-1/complete-intake-1/test-data';control=prefix+'build/nfcore-atacseq121-1/'
 run('prepare',wsl('/usr/bin/python3',prefix+'tools/literature/nfcore_atacseq121/prepare.py','--workflow',prefix+'build/nfcore-atacseq121-1/complete-intake-1/source','--data-root',data,'--design',data+'/design.csv','--fasta',data+'/reference/genome.fa','--gtf',data+'/reference/genes.gtf','--container-home','/var/tmp/omicsmatic-nfcore-apptainer-1','--images',control+'image-qualification-2/images.json','--out','/var/tmp/omicsmatic-atacseq121-prepared-5','--run-root','/var/tmp/omicsmatic-atacseq121-run-5','--macs-genome-size','1.2e7','--executor-cpus','4','--executor-memory-bytes','25769803776','--max-memory','6.GB','--max-time','2.h','--parameters',control+'test-configuration-1/parameters.json','--uri-map',control+'test-configuration-1/uri-map.json','--limits',control+'test-configuration-2/limits.json'))
 run('workflow',wsl('/usr/bin/java','-Xmx4096m','-jar',native+'/adapter.jar','nfcore-tools','ATACSEQ-1.2.1','--request','/var/tmp/omicsmatic-atacseq121-prepared-5/request.json','--home',native+'/home-21','--setup-report',native+'/health-report-1','--out','/var/tmp/omicsmatic-atacseq121-run-5'))
 run('linux-verify',wsl('/usr/bin/java','-Xmx2048m','-jar',native+'/adapter.jar','nfcore-tools','ATACSEQ-1.2.1','--verify','/var/tmp/omicsmatic-atacseq121-run-5'))
 portable=control+'portable-result-1'
 run('portable-export',wsl('/usr/bin/java','-Xmx2048m','-jar',native+'/adapter.jar','nfcore-tools','ATACSEQ-1.2.1','--export-result','/var/tmp/omicsmatic-atacseq121-run-5','--out',portable))
 run('windows-verify',['C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe','-Xmx2048m','-jar',base/'build-6/jar/omicsmatic-0.4.0.jar','nfcore-tools','ATACSEQ-1.2.1','--verify',base/'portable-result-1'])
 run('linux-portable-verify',wsl('/usr/bin/java','-Xmx2048m','-jar',native+'/adapter.jar','nfcore-tools','ATACSEQ-1.2.1','--verify',portable))
 save(out/'COMPLETED.json',dict(status='PASS_NATIVE_ORIGINAL_WORKFLOW_AND_TWO_PLATFORM_PORTABLE_VERIFICATION',native_run='/var/tmp/omicsmatic-atacseq121-run-5',portable_result=str(base/'portable-result-1'),new_catalog_credit=0))
except Exception as error:
 save(out/'FAILURE.json',dict(status='FAIL2_FINAL_VALIDATION_NO_ADMISSION',error=repr(error),traceback=traceback.format_exc()));print(str(error),flush=True);raise
