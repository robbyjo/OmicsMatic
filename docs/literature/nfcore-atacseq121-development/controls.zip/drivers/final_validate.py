import hashlib,json,subprocess,time,traceback,xml.etree.ElementTree as ET
from pathlib import Path
base=Path(__file__).resolve().parent;root=base.parents[1];out=base/'final-validation-2';out.mkdir()
jar=base/'build-7/jar/omicsmatic-0.4.0.jar';winjava='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe'
linux='/mnt/d/projects/JLinAlg/build/high-impact-stats-1/';records=[]
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return dict(bytes=p.stat().st_size,sha256=h.hexdigest())
def lp(p):return linux+p.relative_to(root).as_posix()
def wsl(*args):return ['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--exec',*map(str,args)]
def run(label,command,expected=0,fragment=None,timeout=1200):
 command=list(map(str,command));save(out/(label+'.command.json'),command);began=time.monotonic()
 with (out/(label+'.stdout')).open('xb') as so,(out/(label+'.stderr')).open('xb') as se:
  r=subprocess.run(command,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=timeout)
 record=dict(case=label,exit_code=r.returncode,expected_exit=expected,seconds=time.monotonic()-began);save(out/(label+'.PROCESS.json'),record);records.append(record)
 assert r.returncode==expected,(label,r.returncode,expected)
 if fragment:assert fragment in (out/(label+'.stdout')).read_text(encoding='utf8')+(out/(label+'.stderr')).read_text(encoding='utf8'),label
 print('PASS',label,flush=True)
def java(*args):return [winjava,'-Xmx2048m','-jar',str(jar),'nfcore-tools',*args]
def lj(*args):return wsl('/usr/bin/java','-Xmx2048m','-jar',lp(jar),'nfcore-tools',*args)
try:
 original=pin(jar)
 for label,args in [('root-help',['--help']),('atac-help',['ATACSEQ-1.2.1','--help']),('audit-help',['ATACSEQ-AUDIT-1.2.1','--help']),('engine-help',['ENGINE','--help']),('captured-help',['CAPTURED','--help'])]:run(label,java(*args),fragment='Required action:')
 run('unsupported-edition',java('ATACSEQ-99'),2,'not inferred or substituted')
 run('failed-wrapper-refused',java('ATACSEQ-1.2.1','--verify',base/'original-run-1'),2,'retained failure')
 run('component-not-whole-result',java('ATACSEQ-1.2.1','--verify',base/'windows-component-1'),2)
 portable=base/'portable-result-1'
 run('windows-qualified-result',java('ATACSEQ-1.2.1','--verify',portable),fragment='356 complete published files')
 run('existing-export-target-refused',java('ATACSEQ-1.2.1','--export-result',portable,'--out',portable),2,'disjoint NEW')
 broken=out/'changed-manifest';broken.mkdir()
 (broken/'COMPLETED.json').write_bytes((portable/'COMPLETED.json').read_bytes());(broken/'manifest.json').write_bytes((portable/'manifest.json').read_bytes()+b'\n')
 run('changed-manifest-refused',java('ATACSEQ-1.2.1','--verify',broken),2,'scope/manifest differs')
 run('linux-native-result',lj('ATACSEQ-1.2.1','--verify','/var/tmp/omicsmatic-atacseq121-run-5'),fragment='356 complete published files')
 run('linux-portable-result',lj('ATACSEQ-1.2.1','--verify',lp(portable)),fragment='356 complete published files')
 # Request-only missing prerequisites stop before an engine workspace is created.
 qcode="from pathlib import Path;print(Path('/var/tmp/omicsmatic-atacseq121-prepared-5/request.json').read_text())"
 request=json.loads(subprocess.check_output(wsl('/usr/bin/python3','-c',qcode),timeout=60))
 missing=dict(request);missing['container_home']=lp(out/'missing-container-home');save(out/'missing-runtime-request.json',missing)
 run('missing-runtime-skips-analysis',lj('ATACSEQ-1.2.1','--request',lp(out/'missing-runtime-request.json'),'--home','/var/tmp/omicsmatic-atacseq121-native-engine-1/home-21','--setup-report','/var/tmp/omicsmatic-atacseq121-native-engine-1/health-report-1','--out',lp(out/'missing-runtime-result')),3,'ANALYSIS SKIPPED')
 images=json.loads((base/'image-qualification-2/images.json').read_bytes());images['images']={key:lp(out/'missing-original-image.sif') for key in images['images']};save(out/'missing-images.json',images)
 missing=dict(request);missing['images']=lp(out/'missing-images.json');save(out/'missing-image-request.json',missing)
 run('missing-image-skips-analysis',lj('ATACSEQ-1.2.1','--request',lp(out/'missing-image-request.json'),'--home','/var/tmp/omicsmatic-atacseq121-native-engine-1/home-21','--setup-report','/var/tmp/omicsmatic-atacseq121-native-engine-1/health-report-1','--out',lp(out/'missing-image-result')),3,'ANALYSIS SKIPPED')
 for name in ['missing-runtime-result','missing-image-result']:
  assert not (out/name/'engine').exists();assert json.loads((out/name/'FAILURE.json').read_bytes())['status']=='SKIP3 ANALYSIS SKIPPED'
 # Preparation default equals the explicit limits used by the admitted execution.
 cmd=json.loads((base/'original-run-5-launch/prepare.command.json').read_bytes());i=cmd.index('--limits');del cmd[i:i+2]
 cmd[cmd.index('--out')+1]='/var/tmp/omicsmatic-atacseq121-default-prepared-1';cmd[cmd.index('--run-root')+1]='/var/tmp/omicsmatic-atacseq121-default-run-1'
 run('default-preparation',cmd)
 qcode="import json;from pathlib import Path;a=json.loads(Path('/var/tmp/omicsmatic-atacseq121-default-prepared-1/engine-recipe.json').read_bytes())['limits'];b=json.loads(Path('/var/tmp/omicsmatic-atacseq121-prepared-5/engine-recipe.json').read_bytes())['limits'];assert a==b;print(json.dumps(a,sort_keys=True))"
 run('default-limits-match-qualified-explicit-limits',wsl('/usr/bin/python3','-c',qcode),fragment='"poll_millis": 1000')
 classpath=lp(jar)+':'+linux+'build/classes/java/test:'+linux+'build/resources/test'
 run('linux-junit',wsl('/usr/bin/java','-Xmx2048m','-jar',lp(base/'linux-test-runtime-1/junit-platform-console-standalone-1.13.4.jar'),'execute','--class-path',classpath,'--select-class','org.jlinalg.cli.NfcoreAtacseq121Test','--select-class','org.jlinalg.cli.NextflowCaptureWorkspaceTest','--reports-dir',lp(out/'linux-junit-reports'),'--disable-ansi-colors'))
 reports=[ET.parse(p).getroot() for p in (out/'linux-junit-reports').glob('TEST-*.xml')];counts={k:sum(int(t.attrib.get(k,0)) for t in reports) for k in ['tests','failures','errors','skipped']}
 assert counts==dict(tests=12,failures=0,errors=0,skipped=0),counts
 assert pin(jar)==original
 save(out/'COMPLETED.json',dict(status='PASS_FINAL_PACKAGED_CONTROLS',artifact=original,cases=records,linux_junit=counts,missing_prerequisites_executed_no_analysis=True,default_limits_equal_qualified_explicit_limits=True,all_classes_identical_to_executed_predecessor=True,new_catalog_integrations=0,whole_goal_complete=False))
except Exception as error:
 save(out/'FAILURE.json',dict(status='FAIL2_FINAL_CONTROLS_NO_RESULT',error=repr(error),traceback=traceback.format_exc(),completed_cases=records));print(repr(error),flush=True);raise
