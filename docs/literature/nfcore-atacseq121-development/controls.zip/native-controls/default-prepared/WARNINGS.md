# PASS_ATAC_SOURCE_DATA_PREPARATION_ONLY

Complete source/input bytes and explicit path bindings retained.

Preparation only. Read WARNINGS.md and the path mapping. Run the exact original source through the typed adapter with a permitted managed Nextflow/private container runtime and current host report. Require completed execution and portable verification before downstream use. Missing/forbidden prerequisites skip the dependent analysis. Preserve originals and failed preparations; resolve the cause and use NEW paths.
