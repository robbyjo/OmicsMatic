# GCTA warnings and required actions

Status: SKIP3_DEPENDENT_ANALYSIS_SKIPPED

org.jlinalg.cli.GctaWorkflowRuntime$Unavailable: The exact declared edition GCTA-1.93.2 is not qualified. Supply its permitted original source/runtime and qualify it; do not substitute 1.94.1 or a beta/adjacent release

SKIP3: dependent analysis skipped; supply the named exact permitted runtime/input or retain the skip if installation is forbidden. FAIL2: NO COMPLETE RESULT; preserve inputs, complete available model/null objects, partials and logs, correct the stated source/data/numeric/convergence/integrity/capacity/process cause and retry NEW output. Never refresh an old hash, clamp a valid unconstrained estimate or silently replace an algorithm/edition/allele/identifier/population/threshold/nonfinite value. Read WARNINGS.md, analysis-status.json, manifest.json, model-objects.json and all worker logs. DEVELOPMENT_SCOPE: explicit source edition and native/original engine on prepared inputs. No automatic engine fallback, genotype/phenotype recoding, strand/ID repair, imputation or undeclared cohort filtering. Raw source model, null, partial and diagnostic exports are retained. Original-model VERIFY checks capture integrity, deterministic intake and declared export invariants; it does not refit or authenticate coordinated replacement. Native GRM is recomputed. Runtime flavor and source stochastic differences remain explicit. No whole-paper or whole-tool completion claim.

Original Windows/Linux runtime flavors can yield different stochastic calibration at the same seed. Cross-flavor replay requires explicit approval in the request, and all differences remain retained.

Source and native GRM zero/N=0 placeholders are not complete estimates. Valid converged unconstrained variance/heritability estimates are not clamped to 0..1.

COJO effective n is an original positive real, not a bounded integer; adjusted LD scores may be negative. Model internal state that the original program does not export is not invented.

Resources: input/output, metadata, entry and logical Java-work caps are explicit. External worker timeout/output monitoring is not an OS memory/file quota.

Inspect every original stdout/stderr/log and all available model/null/partial exports under worker/. Original warnings remain verbatim there. SHA256 provides integrity, not authentication.
