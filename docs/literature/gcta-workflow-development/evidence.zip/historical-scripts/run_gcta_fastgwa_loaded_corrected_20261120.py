from pathlib import Path
import concurrent.futures,hashlib,json,os,subprocess,time
R=Path('D:/projects/JLinAlg');T=R/'build/gc-3';B=T/'build/gcta-workflows-1';PRE=B/'fastgwa-large-original-1';F=PRE/'inputs';O=B/'fastgwa-loaded-corrected-2';O.mkdir(exist_ok=False)
I=R/'build/gc-1/build/gcta-high-impact-1/upstream-1.94.1-intake-1';win=I/'windows/files/gcta-1.94.1-win-x86_64/gcta-win-1.94.1.exe';lin=I/'linux/download'
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def linux(p):return '/mnt/d/'+p.relative_to(Path('D:/')).as_posix()
def task(host):
    root=O/host;root.mkdir();convert=str if host=='windows' else linux;model=PRE/host/'null-model/result.fastGWA'
    for suffix in ['.mdl.id','.mdl.bin2']:assert Path(str(model)+suffix).is_file()
    common=['--bfile',F/'input','--grm-sparse',PRE/host/'sparse/result','--pheno',F/'binary.pheno','--fastGWA-mlm-binary','--seed','2026','--num-vec','10','--qcovar',F/'age.covar','--covar',F/'sex.covar']
    rows=[]
    for name,args in [('loaded-association',['--bfile',F/'input','--load-model',model]),('direct-association',common)]:
        folder=root/name;folder.mkdir();argv=[convert(a) if isinstance(a,Path) else a for a in args]+['--thread-num','1','--out',convert(folder/'result')]
        command=[str(win),*argv] if host=='windows' else ['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','--cd',linux(folder),'--exec',linux(lin),*argv]
        with (folder/'stdout').open('xb') as stdout,(folder/'stderr').open('xb') as stderr:process=subprocess.run(command,cwd=folder,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=300,env=dict(os.environ,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'),creationflags=subprocess.CREATE_NO_WINDOW if host=='windows' else 0)
        row=dict(name=name,command=command,exit_code=process.returncode,files={p.name:pin(p) for p in folder.iterdir() if p.is_file()},scientific_qualification_complete=False);save(folder/'PROCESS.json',row);rows.append(row);print('Corrected original fastGWA',host,name,'exit',process.returncode,flush=True)
    return host,rows
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=dict(pool.map(task,['windows','linux']))
save(O/'COMPLETED.json',dict(status='CORRECTED_EXACT_SOURCE_FASTGWA_MODEL_PREFIX_USED',prefix_correction='Original GCTA appends .fastGWA before .mdl.id/.mdl.bin2; preserve the failed previous loaded attempts',results=results,scientific_qualification_complete=False))
