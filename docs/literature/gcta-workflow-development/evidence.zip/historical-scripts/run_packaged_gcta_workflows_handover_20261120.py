from pathlib import Path
import concurrent.futures,hashlib,json,shutil,subprocess
R=Path('D:/projects/JLinAlg');T=R/'build/gc-3';B=T/'build/gcta-workflows-1';G=B/'normal-gradle-3';O=B/'packaged-handover-tests-1';O.mkdir(exist_ok=False)
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
def pin(p):
    with p.open('rb') as f:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
record=json.loads((G/'COMPLETED.json').read_bytes());assert record['exit_code']==0 and sum(v['tests'] for v in record['reports'].values())==16
for n,w in record['inputs'].items():assert pin(T/n)==w,n
jar=G/'project-build/cli/omicsmatic-0.4.0.jar';assert pin(jar)==record['JARs']['cli/omicsmatic-0.4.0.jar']
deps=O/'junit';shutil.copytree(R/'build/gc-2/build/gcta-native-1/packaged-tests-1/junit',deps)
classes=O/'test-classes';classes.mkdir();testroot=G/'project-build/classes/java/test'
for folder,pattern in [('cli','GctaWorkflowCliTest*.class'),('genetics','GctaHardcallGrmTest*.class'),('genetics','GenomicRelationshipMatrixTest*.class')]:
    for p in (testroot/'org/jlinalg'/folder).glob(pattern):
        dest=classes/p.relative_to(testroot);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
res=O/'resources/org/jlinalg/genetics';res.mkdir(parents=True);shutil.copyfile(T/'src/test/resources/org/jlinalg/genetics/gcta1941-hardcall-originals.zip',res/'gcta1941-hardcall-originals.zip')
launcher=O/'launcher-classes';launcher.mkdir();J=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin')
command=[str(J/'javac.exe'),'-cp',str(deps/'*'),'-d',str(launcher),str(T/'tools/literature/gcta_workflows/PackagedWorkflowTests.java')]
p=subprocess.run(command,capture_output=True,timeout=60);(O/'javac.stdout').write_bytes(p.stdout);(O/'javac.stderr').write_bytes(p.stderr);assert p.returncode==0
def linux(p):return '/mnt/d/'+p.relative_to(Path('D:/')).as_posix()
elements=[jar,launcher,classes,O/'resources',deps/'*']
def task(host):
    command=['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','--exec','/usr/bin/java','-cp',':'.join(linux(p) for p in elements),'PackagedWorkflowTests'] if host=='linux21' else [str(J/'java.exe') if host=='windows21' else 'C:/Program Files/Java/jdk-25/bin/java.exe','-cp',';'.join(str(p) for p in elements),'PackagedWorkflowTests']
    with (O/(host+'.stdout')).open('xb') as stdout,(O/(host+'.stderr')).open('xb') as stderr:p=subprocess.run(command,cwd=O,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=300)
    row=dict(command=command,exit_code=p.returncode,stdout=pin(O/(host+'.stdout')),stderr=pin(O/(host+'.stderr')));save(O/(host+'.PROCESS.json'),row)
    assert p.returncode==0,(host,(O/(host+'.stdout')).read_text(errors='replace')[-2500:]);assert 'GCTA_WORKFLOW_PACKAGED_CHECKS_PASS tests=16' in (O/(host+'.stdout')).read_text();print('PASS packaged',host,'16 tests',flush=True);return host,row
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=dict(pool.map(task,['windows21','windows25','linux21']))
save(O/'COMPLETED.json',dict(status='PASS_16_PACKAGED_TESTS_PER_JVM',results=results,jar=pin(jar),normal_product_classes_loaded_from_JAR=True,source_compiler='Windows JDK21',independent_Linux_source_compilation='SKIP3: Linux javac absent',catalog_credit=0))
