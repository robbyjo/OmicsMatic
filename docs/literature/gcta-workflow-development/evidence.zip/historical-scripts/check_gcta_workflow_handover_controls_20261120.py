from pathlib import Path
import concurrent.futures,copy,hashlib,json,subprocess
R=Path('D:/projects/JLinAlg');T=R/'build/gc-3';B=T/'build/gcta-workflows-1';A=B/'normal-workflow-runs-1';O=B/'handover-controls-1';O.mkdir(exist_ok=False)
jar=B/'normal-gradle-3/project-build/cli/omicsmatic-0.4.0.jar';runtime=R/'build/gc-1/build/gcta-high-impact-1/upstream-1.94.1-intake-1/linux/download'
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
def pin(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inventory(p):return {v.relative_to(p).as_posix():pin(v) for v in sorted(p.rglob('*')) if v.is_file()}
def linux(p):return '/mnt/d/'+p.relative_to(Path('D:/')).as_posix()
def prefix(host):return ['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','--cd',linux(T),'--exec','/usr/bin/java','-cp',linux(jar),'org.jlinalg.cli.GctaWorkflowCli'] if host=='linux21' else ['C:/Program Files/Java/jdk-25/bin/java.exe','-cp',str(jar),'org.jlinalg.cli.GctaWorkflowCli']
def call(name,host,args,expected):
    command=prefix(host)+args
    with (O/(name+'.stdout')).open('xb') as stdout,(O/(name+'.stderr')).open('xb') as stderr:p=subprocess.run(command,cwd=T,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=300)
    row=dict(name=name,host=host,command=command,exit_code=p.returncode,expected_exit=expected);save(O/(name+'.PROCESS.json'),row);assert p.returncode==expected,(name,p.returncode);return row
def cross(host):
    source='windows21' if host=='linux21' else 'linux21';rows=json.loads((A/source/'RESULTS.json').read_bytes());results=[]
    for row in rows:
        if row['exit_code']==0:
            path=A/source/row['name'];results.append(call('cross-'+host+'-'+row['name'],host,['--verify',linux(path) if host=='linux21' else str(path)],0))
    assert len(results)==28;print('PASS cross-host verify',host,28,flush=True);return host,results
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:crossresults=dict(pool.map(cross,['linux21','windows25']))
parents=[A/'windows21/grm-native-0',A/'windows21/pca'];before={str(p):inventory(p) for p in parents};results=[]
for name,parent,settings,expected in [
    ('native-replay-linux',parents[0],{},0),
    ('original-cross-flavor-refused',parents[1],{'runtime':linux(runtime)},2),
    ('original-replay-linux',parents[1],{'runtime':linux(runtime),'allow_runtime_flavor_change':True},0)]:
    request=dict(schema_version=1,mode='REPLAY',analysis=linux(parent),out=linux(O/(name+'-bundle')),**settings);path=O/(name+'.json');save(path,request);results.append(call(name,'linux21',['--request',linux(path)],expected))
    if expected==0:results.append(call(name+'-verify','windows25',['--verify',str(O/(name+'-bundle'))],0))
assert {str(p):inventory(p) for p in parents}==before
save(O/'PARENTS-UNCHANGED.json',before)
save(O/'COMPLETED.json',dict(status='PASS_SAVED_CROSS_HOST_VERIFY_AND_TWO_ACTUAL_REPLAYS',cross_host_verifications=crossresults,replay_controls=results,parents_unchanged=True,qualification_scope='Bounded handover checks; full inverse/timeout/process/tamper qualification remains open',catalog_credit=0))
print('PASS actual native and original cross-host replay; missing explicit flavor-change declaration refused; parent bytes preserved',flush=True)
