from pathlib import Path
import hashlib,json,shutil
T=Path('D:/projects/JLinAlg/build/gc-3');O=T/'build/gcta-workflows-1/workflow-compile-2';receipt=json.loads((O/'PROCESS.json').read_bytes());D=O/'sources';D.mkdir(exist_ok=False)
for name,expected in receipt['sources'].items():
    source=T/'src/main/java/org/jlinalg/cli'/name;assert hashlib.sha256(source.read_bytes()).hexdigest()==expected,name;shutil.copyfile(source,D/name)
print('Preserved all five exact initial-execution source files with original hashes',flush=True)
