from pathlib import Path
import concurrent.futures,copy,hashlib,json,struct,subprocess,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/gc-3';B=T/'build/gcta-workflows-1';O=B/'normal-workflow-runs-1';O.mkdir(exist_ok=False)
G=B/'normal-gradle-3';build=json.loads((G/'COMPLETED.json').read_bytes());assert build['exit_code']==0 and sum(v['tests'] for v in build['reports'].values())==16 and not any(v['failures'] or v['errors'] or v['skipped'] for v in build['reports'].values())
jar=G/'project-build/cli/omicsmatic-0.4.0.jar';oldjar=R/'build/gc-2/build/gcta-native-1/gradle-qualified-2/project-build/cli/omicsmatic-0.4.0.jar'
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
def pin(p):
    with p.open('rb') as s:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(s,'sha256').hexdigest())
with zipfile.ZipFile(oldjar) as a,zipfile.ZipFile(jar) as b:
    assert len(a.namelist())==23530 and len(set(b.namelist()))==len(b.namelist())
    removed=set(a.namelist())-set(b.namelist());changed=[n for n in a.namelist() if n in b.namelist() and a.read(n)!=b.read(n)];added=sorted(set(b.namelist())-set(a.namelist()))
    assert not removed and not changed and len(added)==11 and all(n.startswith('org/jlinalg/cli/GctaWorkflow') for n in added),(removed,changed,added)
save(O/'PRODUCER.json',dict(jar=pin(jar),prior_payloads_unchanged=23530,added_classes=added));print('PASS normal producer preserves23530 payloads; adds11 closed-workflow classes',flush=True)
inputs=O/'control-inputs';inputs.mkdir();M=R/'build/gc-1/build/gcta-high-impact-1/mixed-fixtures-1'
for label,scale in [('tiny',1e-4),('large',1e4)]:
    path=inputs/(label+'.pheno');path.write_text(''.join('\t'.join(line.split()[:2])+'\t'+format(float(line.split()[2])*scale,'.17g')+'\n' for line in (M/'positive.pheno').read_text().splitlines()),encoding='utf-8',newline='\n')
matrix=inputs/'edge.grm.bin';matrix.write_bytes(struct.pack('<6f',struct.unpack('<f',struct.pack('<I',struct.unpack('<I',struct.pack('<f',.05))[0]-1))[0],.05,struct.unpack('<f',struct.pack('<I',struct.unpack('<I',struct.pack('<f',.05))[0]+1))[0],-.1,2,-0.0))
(inputs/'edge.grm.id').write_text('F1\tI1\nF2\tI2\nF3\tI3\n',encoding='utf-8',newline='\n')
requests={p.stem:json.loads(p.read_bytes()) for p in (B/'initial-workflow-runs-1/requests').glob('*.json')}
for label in ['tiny','large']:
    r=copy.deepcopy(requests['reml-positive']);r['phenotype']=str(inputs/(label+'.pheno'));requests['reml-'+label]=r
for engine in ['native','original']:
    for label,cutoff in [('tie',.05),('negative',-.1),('empty',3.)]:
        r=copy.deepcopy(requests['sparse-'+engine]);r['grms']=[dict(values=str(matrix),ids=str(inputs/'edge.grm.id'))];r['sparse_cutoff']=cutoff;requests['sparse-edge-'+engine+'-'+label]=r
for model in ['zero-joint-pair','all-missing','monomorphic-only']:
    r=copy.deepcopy(requests['grm-original-0']);prefix=R/'build/gc-2/build/gcta-native-1/edge-fixtures-1'/model/'input';r['genotypes']={s:str(prefix)+'.'+s for s in ['bed','bim','fam']};requests['refuse-original-'+model]=r
unknown=copy.deepcopy(requests['grm-native-0']);unknown['profile']='GCTA-1.93.2';requests['skip-unqualified-edition']=unknown
def linux_path(value):
    value=str(value).replace('\\','/');assert value.startswith('D:/'),value;return '/mnt/d/'+value[3:]
def transport(value):
    if isinstance(value,dict):return {k:transport(v) for k,v in value.items()}
    if isinstance(value,list):return [transport(v) for v in value]
    if isinstance(value,str) and (value.startswith('D:/') or value.startswith('D:\\')):return linux_path(value)
    return value
J=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe');runtime_root=R/'build/gc-1/build/gcta-high-impact-1/upstream-1.94.1-intake-1'
def task(host):
    base=O/host;base.mkdir();reqdir=base/'requests';reqdir.mkdir();rows=[]
    for name,original in requests.items():
        r=copy.deepcopy(original);r['out']=str(base/name)
        if r['engine']=='original':r['runtime']=str(runtime_root/('linux/download' if host=='linux21' else 'windows/files/gcta-1.94.1-win-x86_64/gcta-win-1.94.1.exe'))
        if host=='linux21':r=transport(r)
        file=reqdir/(name+'.json');save(file,r)
        prefix=[str(J),'-cp',str(jar),'org.jlinalg.cli.GctaWorkflowCli'] if host=='windows21' else ['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','--cd',linux_path(T),'--exec','/usr/bin/java','-cp',linux_path(jar),'org.jlinalg.cli.GctaWorkflowCli']
        command=prefix+['--request',str(file) if host=='windows21' else linux_path(file)]
        with (reqdir/(name+'.stdout')).open('xb') as stdout,(reqdir/(name+'.stderr')).open('xb') as stderr:p=subprocess.run(command,cwd=T,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=300)
        status=json.loads((base/name/'analysis-status.json').read_bytes()) if (base/name/'analysis-status.json').exists() else {}
        row=dict(name=name,host=host,command=command,exit_code=p.returncode,analysis_status=status)
        if p.returncode==0:
            verification=prefix+['--verify',str(base/name) if host=='windows21' else linux_path(base/name)]
            with (reqdir/(name+'.verify.stdout')).open('xb') as stdout,(reqdir/(name+'.verify.stderr')).open('xb') as stderr:v=subprocess.run(verification,cwd=T,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=300)
            row['separate_JVM_verify_exit']=v.returncode
        rows.append(row);save(base/'PROGRESS.json',rows);print('Normal GCTA workflow',host,name,'exit',p.returncode,status.get('error',''),flush=True)
    save(base/'RESULTS.json',rows);return host,rows
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=dict(pool.map(task,['windows21','linux21']))
save(O/'COMPLETED.json',dict(status='NORMAL_PRODUCER_COMPOSITIONS_COMPLETE_REVIEW_REQUIRED',results=results,original_case_count=len(requests),jar=pin(jar),new_catalog_credit=0));print('Normal workflow compositions complete',len(requests),'per host',flush=True)
