from pathlib import Path
R=Path('D:/projects/JLinAlg');B=R/'build/gc-1/build/gcta-high-impact-1';A=B/'original-advanced-1/windows';S=B/'upstream-1.94.1-intake-1/source/files/jianyangqt-gcta-6da64e9'
for case in ['pca','reml-positive','reml-unconstrained','reml-multi','ld-score','ld-score-adjusted','ld-score-region','sparse-grm']:
    files=sorted(p for p in (A/case).glob('result*') if p.suffix!='.log')
    print(case,[p.name for p in files])
    for p in files:
        if '.bin' not in p.name and p.stat().st_size<100000:
            print(p.name,p.read_text(errors='replace').splitlines()[:5])
print('SOURCE legacy model files',[(p.name,p.stat().st_size) for p in (S/'main').glob('*.cpp') if any(x in p.name for x in ['reml','ld','gcta','cojo'])])
