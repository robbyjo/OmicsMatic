from pathlib import Path
import hashlib,json,subprocess,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/gc-3';B=T/'build/gcta-workflows-1';Q=T/'docs/literature/gcta-workflow-development'
OLD=R/'build/gc-1/build/gcta-high-impact-1';G=B/'normal-gradle-3';jar=G/'project-build/cli/omicsmatic-0.4.0.jar'
def save(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as stream:json.dump(v,stream,indent=2);stream.write('\n')
def pin(p):
    with p.open('rb') as stream:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(stream,'sha256').hexdigest())
record=json.loads((G/'COMPLETED.json').read_bytes());assert record['exit_code']==0
for name,wanted in record['inputs'].items():assert pin(T/name)==wanted,name
for directory in ['packaged-handover-tests-1','handover-controls-1']:assert (B/directory/'COMPLETED.json').is_file()
members={}
def add(p,name):
    assert name not in members and p.is_file(),name;members[name]=p
for directory in sorted(B.iterdir()):
    if not directory.is_dir():continue
    if directory.name.startswith('normal-gradle-'):
        selected=[p for p in directory.iterdir() if p.is_file()]
        selected+=list((directory/'sources').rglob('*'))
        selected+=list((directory/'project-build/test-results/test').glob('TEST-*.xml'))
    else:
        selected=list(directory.rglob('*'))
    for p in selected:
        if p.is_file() and p.suffix.lower() not in ['.jar','.exe','.dll']:
            add(p,'current/'+p.relative_to(B).as_posix())
for name in ['original-core-2','original-advanced-1','original-fixtures-2','mixed-fixtures-1']:
    for p in sorted((OLD/name).rglob('*')):
        if p.is_file():add(p,'prior-originals/'+p.relative_to(OLD).as_posix())
scripts=['audit_gcta_original_models_20261120.py','compile_gcta_workflow_sources_20261120.py','read_gcta_model_outputs_20261120.py','read_gcta_source_methods_20261120.py','run_gcta_fastgwa_large_20261120.py','run_gcta_fastgwa_loaded_corrected_20261120.py','run_gcta_workflow_gradle_20261120.py','run_gcta_workflow_initial_20261120.py','qualify_gcta_workflow_runs_20261120.py','run_packaged_gcta_workflows_handover_20261120.py','check_gcta_workflow_handover_controls_20261120.py','start_gcta_workflows_20261120.py','preserve_gcta_initial_sources_20261120.py',Path(__file__).name]
for name in scripts:add(R/'build'/name,'historical-scripts/'+name)
inventory={name:pin(p) for name,p in sorted(members.items())}
with zipfile.ZipFile(Q/'evidence.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,p in sorted(members.items()):
        raw=p.read_bytes();assert dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())==inventory[name]
        info=zipfile.ZipInfo(name,(2026,11,20,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
        archive.writestr(info,raw,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
save(Q/'INVENTORY.json',inventory)
source_names=list(record['inputs'])+['src/main/java/org/jlinalg/genetics/GctaHardcallGrm.java','tools/literature/gcta_workflows/verify_checkpoint.py','tools/literature/gcta_workflows/PackagedWorkflowTests.java','examples/gcta-workflows/make_fixture.py','examples/gcta-workflows/README.md','docs/literature/gcta-workflow-development/README.md','docs/literature/HANDOVER_2026-11-20_GCTA_WORKFLOWS.md']
save(Q/'PROFILE.json',dict(schema_version=1,status='DEVELOPMENT_HANDOVER_QUALIFICATION_UNFINISHED',baseline='6f4e5591e997b16f4183333c5cc7d6ab66cec4d0',
    source_inputs={n:pin(T/n) for n in source_names},evidence_archive=pin(Q/'evidence.zip'),inventory=pin(Q/'INVENTORY.json'),archive_members=len(members),uncompressed_bytes=sum(v['bytes'] for v in inventory.values()),
    normal_producer=pin(jar),normal_producer_private_path=str(jar),source_profile='GCTA-1.94.1',source_commit='6da64e9d8be838d01c34efb974e69c72e861f4c2',
    normal_JAR_prior_payloads_unchanged=23530,normal_JAR_added_classes=11,saved_model_cases_per_host=33,saved_complete_cases_per_host=28,saved_expected_FAIL2_per_host=4,saved_expected_SKIP3_per_host=1,
    saved_separate_JVM_verifications=56,saved_cross_host_verifications=56,saved_actual_cross_host_replays=2,saved_flavor_change_refusal=1,saved_packaged_tests_per_JVM=16,saved_packaged_JVMs=['Windows21','Windows25','Linux21'],
    independent_Linux_source_compilation='SKIP3: Linux javac absent',original_model_VERIFY_scope='Input/inventory integrity, deterministic intake and declared export invariants; no independent refit or coordinated-replacement authentication',
    retained_failures=['serial UID normal build failure','initial original binary 1/2-coded model failure','wrong-prefix loaded fastGWA failure','expected-Fisher REML covariance interpretation mismatch','deliberate unsupported coding/undefined GRM/edition refusals'],
    unfinished=['complete model export comparisons and source-correct independent AI covariance follow-up','full inverse/timeout/process/capacity/tamper qualification','mtCOJO','paper-specific older editions and ambiguous preparation','global command registration and compatibility','source-role review and guarded catalog admission','1166 pending catalog observations'],
    scoped_integrations=140,reviewed_uses=1548,pending_uses=1166,new_catalog_credit=0,qualification_complete=False,whole_goal_complete=False,goal_status='paused_for_handover',private_transfer_required=True,worktrees_preserved=25,site_modified=False,released=False))
print('Saved handover evidence',len(members),'members,',pin(Q/'evidence.zip')['bytes'],'compressed bytes',flush=True)
