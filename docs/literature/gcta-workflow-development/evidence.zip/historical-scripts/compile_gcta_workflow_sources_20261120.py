from pathlib import Path
import hashlib,json,shutil,subprocess,sys
R=Path('D:/projects/JLinAlg');T=R/'build/gc-3';B=T/'build/gcta-workflows-1';O=B/('workflow-compile-'+(sys.argv[1] if len(sys.argv)>1 else '1'));O.mkdir(exist_ok=False)
jar=R/'build/gc-2/build/gcta-native-1/gradle-qualified-2/project-build/cli/omicsmatic-0.4.0.jar';jdk=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin');classes=O/'classes';classes.mkdir()
sources=sorted((T/'src/main/java/org/jlinalg/cli').glob('GctaWorkflow*.java'))
snapshot=O/'sources';snapshot.mkdir()
for source in sources:shutil.copyfile(source,snapshot/source.name)
command=[str(jdk/'javac.exe'),'-encoding','UTF-8','-cp',str(jar),'-d',str(classes),*[str(p) for p in sources]]
p=subprocess.run(command,cwd=T,capture_output=True,timeout=90);(O/'stdout').write_bytes(p.stdout);(O/'stderr').write_bytes(p.stderr)
(O/'PROCESS.json').write_text(json.dumps(dict(command=command,exit_code=p.returncode,sources={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Initial GCTA workflow compilation',p.returncode,p.stderr.decode(errors='replace')[:1500],flush=True)
