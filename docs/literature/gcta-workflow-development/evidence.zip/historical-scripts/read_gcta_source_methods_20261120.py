from pathlib import Path
import json,sys
R=Path('D:/projects/JLinAlg');T=R/'build/gc-1';records=json.loads((T/'build/gcta-high-impact-1/source-intake-1/CANDIDATES.json').read_bytes())['candidates']
if len(sys.argv)==1:
    for p in records:
        selected=[a for a in p['anchors'] if 'method' in a['section'].lower() or 'code availability' in a['section'].lower()];selected=selected or p['anchors']
        print(p['paper_id'],p['doi'],'existing='+','.join(t['tool_id'] for t in p['existing_observations']),'contexts='+','.join(str(a['paragraph_index'])+':'+str(len(a['text'])) for a in selected),flush=True)
else:
    for pid in sys.argv[1:]:
        p=next(p for p in records if p['paper_id']==pid);selected=[a for a in p['anchors'] if 'method' in a['section'].lower() or 'code availability' in a['section'].lower()];selected=selected or p['anchors']
        print('\n'+p['paper_id']+' '+p['title']+'\n'+p['doi'],flush=True)
        for a in selected:print('\nPARAGRAPH '+str(a['paragraph_index'])+' / '+a['section']+'\n'+a['text'],flush=True)
