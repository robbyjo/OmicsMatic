from pathlib import Path
import json,os,subprocess,sys
R=Path('D:/projects/JLinAlg');T=R/'build/gc-3';B=T/'build/gcta-workflows-1';O=B/'initial-workflow-runs-1';O.mkdir(exist_ok=False)
OLD=R/'build/gc-1/build/gcta-high-impact-1';F=OLD/'original-fixtures-2';M=OLD/'mixed-fixtures-1';L=B/'fastgwa-large-original-1';J=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe')
I=OLD/'upstream-1.94.1-intake-1';runtime=I/'windows/files/gcta-1.94.1-win-x86_64/gcta-win-1.94.1.exe'
classes=B/'workflow-compile-2/classes';jar=R/'build/gc-2/build/gcta-native-1/gradle-qualified-2/project-build/cli/omicsmatic-0.4.0.jar'
def bfile(prefix):return dict(bed=str(prefix)+'.bed',bim=str(prefix)+'.bim',fam=str(prefix)+'.fam')
def grm(prefix,counts=False):
    r=dict(values=str(prefix)+'.grm.bin',ids=str(prefix)+'.grm.id')
    if counts:r['counts']=str(prefix)+'.grm.N.bin'
    return r
cases=[]
def add(name,model,engine='original',**settings):
    request=dict(schema_version=1,mode='RUN',profile='GCTA-1.94.1',engine=engine,model=model,out=str(O/name),preparation_note='Explicit synthetic prepared diploid hard calls or source GRMs; no author participant data')
    if engine=='original':request['runtime']=str(runtime)
    request.update(settings);cases.append((name,request))
for engine in ['native','original']:
    for algorithm in [0,1]:add('grm-'+engine+'-'+str(algorithm),'GRM',engine,genotypes=bfile(F/('missing' if algorithm==1 else 'complete')),grm_algorithm=algorithm)
add('pca','PCA',grms=[grm(M/'full')],pca_components=10)
for name,model in [('cojo-select','COJO_SELECT'),('cojo-joint','COJO_JOINT'),('cojo-condition','COJO_CONDITION')]:
    options=dict(genotypes=bfile(F/'complete'),summary=str(F/'quantitative.ma'))
    if model=='COJO_JOINT':options['extract']=str(F/'joint.snps')
    if model=='COJO_CONDITION':options['condition']=str(F/'condition.snps')
    add(name,model,**options)
add('cojo-reverse','COJO_SELECT',genotypes=bfile(F/'complete'),summary=str(F/'reversed-coherent.ma'))
add('cojo-null','COJO_SELECT',genotypes=bfile(F/'complete'),summary=str(F/'quantitative.ma'),cojo_p=1e-100)
covs=dict(qcovar=str(F/'continuous.covar'),covar=str(F/'categorical.covar'))
add('reml-positive','REML',grms=[grm(M/'full')],phenotype=str(M/'positive.pheno'),**covs)
add('reml-unconstrained','REML',grms=[grm(M/'full',True)],phenotype=str(M/'unconstrained.pheno'),reml_unconstrained=True,**covs)
add('reml-multi','REML',grms=[grm(M/'A'),grm(M/'B')],phenotype=str(M/'multi.pheno'),**covs)
for region,adjusted in [(False,False),(False,True),(True,False),(True,True)]:
    add('ld-'+str(region)+'-'+str(adjusted),'LD_SCORE_REGION' if region else 'LD_SCORE',genotypes=bfile(F/'complete'),ld_adjusted=adjusted)
for engine in ['native','original']:add('sparse-'+engine,'SPARSE_GRM',engine,grms=[grm(M/'full')],sparse_cutoff=.05)
add('fastgwa-01','FASTGWA_BINARY',genotypes=bfile(L/'inputs/input'),sparse=dict(values=str(L/'windows/sparse/result.grm.sp'),ids=str(L/'windows/sparse/result.grm.id')),phenotype=str(L/'inputs/binary.pheno'),qcovar=str(L/'inputs/age.covar'),covar=str(L/'inputs/sex.covar'),binary_coding='0/1')
shift=O/'binary-12.pheno';shift.write_text(''.join('\t'.join(line.split()[:2])+f'\t{int(float(line.split()[2]))+1}\n' for line in (L/'inputs/binary.pheno').read_text().splitlines()),encoding='utf-8',newline='\n')
settings=dict(cases[-1][1]);settings.update(out=str(O/'fastgwa-12'),phenotype=str(shift),binary_coding='1/2');cases.append(('fastgwa-12',settings))
requests=O/'requests';requests.mkdir();rows=[]
for name,request in cases:
    file=requests/(name+'.json');file.write_text(json.dumps(request,indent=2)+'\n',encoding='utf-8',newline='\n')
    command=[str(J),'-cp',str(classes)+';'+str(jar),'org.jlinalg.cli.GctaWorkflowCli','--request',str(file)]
    p=subprocess.run(command,cwd=T,stdin=subprocess.DEVNULL,capture_output=True,timeout=300);(requests/(name+'.stdout')).write_bytes(p.stdout);(requests/(name+'.stderr')).write_bytes(p.stderr)
    status=json.loads((O/name/'analysis-status.json').read_bytes()) if (O/name/'analysis-status.json').exists() else {}
    rows.append(dict(name=name,command=command,exit_code=p.returncode,status=status));print('Initial GCTA workflow',name,'exit',p.returncode,status.get('error',''),flush=True)
(O/'COMPLETED.json').write_text(json.dumps(dict(status='INITIAL_UNQUALIFIED_GCTA_WORKFLOW_COMPOSITIONS',results=rows),indent=2)+'\n',encoding='utf-8',newline='\n')
