from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,xml.etree.ElementTree as ET
R=Path('D:/projects/JLinAlg');T=R/'build/gc-3';B=T/'build/gcta-workflows-1';attempt=sys.argv[1] if len(sys.argv)>1 else '1';O=B/('normal-gradle-'+attempt);O.mkdir(exist_ok=False)
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
def pin(p):
    with p.open('rb') as stream:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(stream,'sha256').hexdigest())
build=O/'project-build';(build/'dependencies').mkdir(parents=True);seed=R/'build/gc-2/build/gcta-native-1/gradle-qualified-2/project-build/dependencies/jdistlib-all-0.10.2.jar';assert pin(seed)['sha256']=='8b50aaa11d2cbd512525e0d74f8e609f40db9f4fc179ccb7a885a82257e0ac81';shutil.copyfile(seed,build/'dependencies'/seed.name)
init=O/'isolate.gradle';init.write_text("gradle.beforeProject { p -> p.layout.buildDirectory.set(new File('"+build.as_posix()+"')) }\n",encoding='utf-8',newline='\n')
cached=R/'build/gc-2/build/gcta-native-1/gradle-qualified-2/COMMAND.json';gradle=Path(json.loads(cached.read_bytes())['command'][0]);assert gradle.is_file()
jdk=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot')
command=[str(gradle),'--no-daemon','--offline','--console=plain','--max-workers=2','--project-cache-dir',str(O/'project-cache'),'--init-script',str(init),'executableJar',':test','--tests','org.jlinalg.cli.GctaWorkflowCliTest','--tests','org.jlinalg.genetics.GctaHardcallGrmTest','--tests','org.jlinalg.genetics.GenomicRelationshipMatrixTest']
names=[p.relative_to(T).as_posix() for p in sorted((T/'src/main/java/org/jlinalg/cli').glob('GctaWorkflow*.java'))]+['src/test/java/org/jlinalg/cli/GctaWorkflowCliTest.java','build.gradle']
sources=O/'sources';sources.mkdir()
for name in names:
    dest=sources/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(T/name,dest)
inputs={name:pin(T/name) for name in names};save(O/'COMMAND.json',dict(command=command,cwd=str(T),JAVA_HOME=str(jdk),inputs=inputs))
with (O/'stdout').open('xb') as stdout,(O/'stderr').open('xb') as stderr:
    child=subprocess.Popen(command,cwd=T,env=dict(os.environ,JAVA_HOME=str(jdk)),stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW);save(O/'PROCESS.json',dict(pid=child.pid));print('Started normal GCTA workflow build PID',child.pid,flush=True);exit_code=child.wait()
reports={}
for path in (build/'test-results/test').glob('TEST-*.xml'):
    root=ET.parse(path).getroot();reports[root.attrib['name']]=dict(tests=int(root.attrib['tests']),failures=int(root.attrib['failures']),errors=int(root.attrib['errors']),skipped=int(root.attrib['skipped']),failed_cases=[c.attrib['name'] for c in root.findall('testcase') if c.find('failure') is not None])
save(O/'COMPLETED.json',dict(exit_code=exit_code,reports=reports,inputs=inputs,JARs={p.relative_to(build).as_posix():pin(p) for p in build.rglob('omicsmatic-*.jar')}));print('GCTA workflow normal build finished',exit_code,json.dumps(reports),flush=True)
