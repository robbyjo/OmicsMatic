from pathlib import Path
import hashlib,json,math,struct
import numpy as np
R=Path('D:/projects/JLinAlg');T=R/'build/gc-3';B=T/'build/gcta-workflows-1';O=B/'independent-model-audit-1';O.mkdir(exist_ok=False)
OLD=R/'build/gc-1/build/gcta-high-impact-1';A=OLD/'original-advanced-1';M=OLD/'mixed-fixtures-1';F=OLD/'original-fixtures-2'
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
def grm(prefix):
    ids=[line.split() for line in Path(str(prefix)+'.grm.id').read_text().splitlines() if line.strip()];n=len(ids);v=np.frombuffer(Path(str(prefix)+'.grm.bin').read_bytes(),dtype='<f4').astype(float);assert len(v)==n*(n+1)//2
    a=np.zeros((n,n));i,j=np.tril_indices(n);a[i,j]=v;a[j,i]=v;return a,ids
def third(p):return np.array([float(line.split()[2]) for line in p.read_text().splitlines()])
K,ids=grm(M/'full');KA,_=grm(M/'A');KB,_=grm(M/'B');n=len(ids);X=np.column_stack([np.ones(n),third(F/'continuous.covar'),third(F/'categorical.covar')-1]);identity=np.eye(n)
results=[]
for name,phenotype,matrices,components in [('reml-positive','positive.pheno',[K,identity],['V(G)','V(e)']),('reml-unconstrained','unconstrained.pheno',[K,identity],['V(G)','V(e)']),('reml-multi','multi.pheno',[KA,KB,identity],['V(G1)','V(G2)','V(e)'])]:
    for host in ['windows','linux']:
        folder=A/host/name;raw=(folder/'result.hsq').read_text();lines=raw.splitlines();rows={line.split('\t')[0]:line.split('\t')[1:] for line in lines if line and '\t' in line};vc=np.array([float(rows[k][0]) for k in components]);y=third(M/phenotype)
        V=sum(v*a for v,a in zip(vc,matrices));L=np.linalg.cholesky(V);Vi=np.linalg.solve(V,identity);covbeta=np.linalg.inv(X.T@Vi@X);beta=covbeta@X.T@Vi@y;P=Vi-Vi@X@covbeta@X.T@Vi;Py=P@y
        sign,logdetXt=np.linalg.slogdet(X.T@Vi@X);assert sign>0
        logL=-.5*(2*np.log(np.diag(L)).sum()+logdetXt+y@Py)
        fitted_index=lines.index('Fix_eff\tSE')+1;fixed=np.array([[float(x) for x in line.split()] for line in lines[fitted_index:] if line.strip()])
        blup=np.array([[float(x) for x in line.split()[2:]] for line in (folder/'result.indi.blp').read_text().splitlines()])
        expected_blup=np.column_stack([v*value for v,a in zip(vc,matrices) for value in [Py,a@Py]])
        loglines=(folder/'result.log').read_text().splitlines();ci=next(i+1 for i,line in enumerate(loglines) if 'Sampling variance/covariance of the estimates of variance components:' in line)
        covariance=np.array([[float(x) for x in line.split()] for line in loglines[ci:ci+len(vc)]])
        PA=[P@a for a in matrices];information=.5*np.array([[np.trace(a@b) for b in PA] for a in PA]);independent_covariance=np.linalg.inv(information)
        row=dict(model=name,host=host,variance_components=vc.tolist(),covariance_minimum_eigenvalue=float(np.linalg.eigvalsh(V).min()),
            fixed_beta_max_abs_difference=float(abs(beta-fixed[:,0]).max()),fixed_SE_max_abs_difference=float(abs(np.sqrt(np.diag(covbeta))-fixed[:,1]).max()),
            source_logL=float(rows['logL'][0]),independent_logL=float(logL),logL_abs_difference=abs(float(rows['logL'][0])-float(logL)),
            BLUP_all_columns_max_abs_difference=float(abs(blup-expected_blup).max()),exported_variance_covariance=covariance.tolist(),
            variance_covariance_max_abs_difference=float(abs(covariance-independent_covariance).max()),
            covariance_diagonal_SE_max_abs_difference=max(abs(math.sqrt(covariance[i,i])-float(rows[k][1])) for i,k in enumerate(components)),
            h2_ratios_max_abs_difference=max(abs(vc[i]/vc.sum()-float(rows[('V(G)' if len(vc)==2 else 'V(G'+str(i+1)+')')+'/Vp'][0])) for i in range(len(vc)-1)),
            covariance_source='Full original log export; not only the .hsq diagonal SE',all_original_objects_retained=True)
        results.append(row);print(json.dumps(row),flush=True)
save(O/'REML.json',dict(status='INDEPENDENT_GAUSSIAN_REML_POINT_CHECKS_REVIEW_REQUIRED',formula='Cholesky/GLS restricted log likelihood without additive Gaussian constant; full expected information and all Py*variance/A*Py*variance BLP columns',source='Untouched original1.94.1 outputs; six-decimal reported variances used for the independent point checks',results=results))
# PCA checks use residuals and orthogonality, independent of eigenvector signs.
pca=[]
for host in ['windows','linux']:
    folder=A/host/'pca';eigenvalues=np.loadtxt(folder/'result.eigenval');vectors=np.array([[float(x) for x in line.split()[2:]] for line in (folder/'result.eigenvec').read_text().splitlines()]);k=vectors.shape[1]
    residual=K@vectors-vectors*eigenvalues[:k];row=dict(host=host,samples=n,components=k,finite=bool(np.isfinite(eigenvalues).all() and np.isfinite(vectors).all()),orthonormality_max_abs_difference=float(abs(vectors.T@vectors-np.eye(k)).max()),maximum_relative_residual=max(float(np.linalg.norm(residual[:,i])/max(np.linalg.norm(K@vectors[:,i]),abs(eigenvalues[i])*np.linalg.norm(vectors[:,i]),1e-30)) for i in range(k)),minimum_original_eigenvalue=float(eigenvalues.min()))
    pca.append(row);print('PCA',json.dumps(row),flush=True)
save(O/'PCA.json',dict(status='INDEPENDENT_GCTA_PCA_RESIDUALS_REVIEW_REQUIRED',results=pca))
# Inspect the complete original binary GLMM model export and loaded/direct identity.
fast=[];ROOT=B/'fastgwa-large-original-1';ASSOC=B/'fastgwa-loaded-corrected-2'
for host in ['windows','linux']:
    model=ROOT/host/'null-model/result.fastGWA.mdl.bin2';raw=model.read_bytes();magic=raw[:5];assert magic==b'fGLM\0';n,p=struct.unpack_from('<II',raw,5);precise=bool(raw[13]);tao,gamma=struct.unpack_from('<dd',raw,14);arrays=np.frombuffer(raw,dtype='<f8',offset=30);assert len(arrays)==2*n+2*n*p and np.isfinite(arrays).all()
    loaded=(ASSOC/host/'loaded-association/result.fastGWA').read_bytes();direct=(ASSOC/host/'direct-association/result.fastGWA').read_bytes();a=[line.split() for line in loaded.decode().splitlines()];b=[line.split() for line in direct.decode().splitlines()]
    row=dict(host=host,samples=n,covariate_columns=p,precise_covar=precise,tao=tao,gamma=gamma,model_export_bytes=len(raw),mu_min=float(arrays[:n].min()),mu_max=float(arrays[:n].max()),complete_finite_model_arrays=True,association_rows=len(a)-1,source_header=a[0],loaded_vs_direct_scientific_tokens_identical=a==b,all_SPA_converged=all(line[-1]=='1' for line in a[1:]))
    fast.append(row);print('FASTGWA',json.dumps(row),flush=True)
save(O/'FASTGWA.json',dict(status='ORIGINAL_BINARY_GLMM_MODEL_AND_ASSOCIATION_AUDIT_REVIEW_REQUIRED',results=fast))
