from pathlib import Path
import concurrent.futures,hashlib,json,math,os,struct,subprocess,time
import numpy as np
R=Path('D:/projects/JLinAlg');T=R/'build/gc-3';B=T/'build/gcta-workflows-1';O=B/'fastgwa-large-original-1';O.mkdir(exist_ok=False);F=O/'inputs';F.mkdir()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
def pin(p):
    with p.open('rb') as stream:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(stream,'sha256').hexdigest())
n=512;m=4096;rng=np.random.Generator(np.random.PCG64(20261122));p=.10+.35*rng.random(m);families=n//4
father=rng.binomial(1,p[:,None,None],size=(m,families,2));mother=rng.binomial(1,p[:,None,None],size=(m,families,2));g=np.empty((m,n),dtype=np.int8)
for child in range(4):
    fi=rng.integers(0,2,size=(m,families));mi=rng.integers(0,2,size=(m,families))
    g[:,child::4]=np.take_along_axis(father,fi[:,:,None],axis=2)[:,:,0]+np.take_along_axis(mother,mi[:,:,None],axis=2)[:,:,0]
ids=[('G%04d'%(i//4+1),'B%05d'%(i+1)) for i in range(n)]
age=rng.uniform(25,70,n);sex=np.arange(n)%2;family_effect=np.repeat(rng.normal(0,1.5,families),4)
eta=-.2+family_effect+.02*(age-45)+.2*sex+.12*(g[0]-g[0].mean());prob=1/(1+np.exp(-eta));binary=rng.binomial(1,prob)
bed=bytearray([0x6c,0x1b,1]);codes=np.array([3,2,0],dtype=np.uint8)
for row in g:
    coded=codes[row].reshape(-1,4);bed.extend(bytes(coded[:,0]+(coded[:,1]<<2)+(coded[:,2]<<4)+(coded[:,3]<<6)))
(F/'input.bed').write_bytes(bed)
(F/'input.bim').write_text(''.join(f'{j//1024+1}\tfv{j+1:05d}\t0\t{(j%1024+1)*10000}\tA\tG\n' for j in range(m)),encoding='utf-8',newline='\n')
(F/'input.fam').write_text(''.join(f'{fid}\t{iid}\t0\t0\t{1+int(s)}\t-9\n' for (fid,iid),s in zip(ids,sex)),encoding='utf-8',newline='\n')
for name,values in [('binary.pheno',binary),('age.covar',age),('sex.covar',1+sex)]:
    (F/name).write_text(''.join(f'{fid}\t{iid}\t{float(value):.17g}\n' for (fid,iid),value in zip(ids,values)),encoding='utf-8',newline='\n')
save(F/'FIXTURE.json',dict(status='SYNTHETIC_128_FAMILIES_FOUR_SIMULATED_SIBLINGS_PER_FAMILY',seed=20261122,numpy=np.__version__,samples=n,variants=m,cases=int(binary.sum()),controls=n-int(binary.sum()),generation='Independent paternal/maternal allele transmission; family random intercept and finite age/sex covariates; no actual participant data',inputs={p.name:pin(p) for p in F.iterdir() if p.is_file()}))
I=R/'build/gc-1/build/gcta-high-impact-1/upstream-1.94.1-intake-1';win=I/'windows/files/gcta-1.94.1-win-x86_64/gcta-win-1.94.1.exe';lin=I/'linux/download'
assert pin(win)['sha256']=='2529bccb2f685332f115726c3cb2bf8cab91f12ae3344a991e3a52d751bdb07e' and pin(lin)['sha256']=='dbb2b5e5d51e278328ff297a403d3dd8ee5f5280f0b6d3d8db74b3e7fead7b49'
def linux(p):return '/mnt/d/'+p.relative_to(Path('D:/')).as_posix()
def task(host):
    root=O/host;root.mkdir();convert=str if host=='windows' else linux
    common=['--bfile',F/'input','--grm-sparse',root/'sparse/result','--pheno',F/'binary.pheno','--fastGWA-mlm-binary','--seed','2026','--num-vec','10','--qcovar',F/'age.covar','--covar',F/'sex.covar']
    tasks=[('grm',['--bfile',F/'input','--make-grm','--make-grm-alg','0']),('sparse',['--grm',root/'grm/result','--make-bK-sparse','0.05']),('null-model',[*common,'--model-only']),('loaded-association',['--bfile',F/'input','--load-model',root/'null-model/result']),('direct-association',common)]
    rows=[]
    for name,args in tasks:
        folder=root/name;folder.mkdir();argv=[convert(a) if isinstance(a,Path) else a for a in args]+['--thread-num','1','--out',convert(folder/'result')]
        command=[str(win),*argv] if host=='windows' else ['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','--cd',linux(folder),'--exec',linux(lin),*argv]
        started=time.monotonic()
        with (folder/'stdout').open('xb') as stdout,(folder/'stderr').open('xb') as stderr:child=subprocess.Popen(command,cwd=folder,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,env=dict(os.environ,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'),creationflags=subprocess.CREATE_NO_WINDOW if host=='windows' else 0)
        save(folder/'OWNED-PROCESS.json',dict(pid=child.pid,command=command));exit_code=child.wait(timeout=300)
        row=dict(name=name,command=command,exit_code=exit_code,elapsed_seconds=time.monotonic()-started,files={p.name:pin(p) for p in folder.iterdir() if p.is_file()},scientific_qualification_complete=False);save(folder/'PROCESS.json',row);rows.append(row)
        print('Larger original fastGWA',host,name,'exit',exit_code,flush=True)
        if exit_code!=0:break
    save(root/'RESULTS.json',rows);return host,rows
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=dict(pool.map(task,['windows','linux']))
save(O/'COMPLETED.json',dict(status='ORIGINAL_LARGER_FASTGWA_EXPLORATION_REQUIRES_MODEL_AUDIT',results=results,scientific_qualification_complete=False))
