from pathlib import Path
import concurrent.futures,hashlib,json,subprocess
R=Path('D:/projects/JLinAlg');T=R/'build/gc-2';B=T/'build/gcta-native-1';O=B/'example-checks-1';O.mkdir(exist_ok=False)
J=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin');J25=Path('C:/Program Files/Java/jdk-25/bin/java.exe');jar=B/'gradle-qualified-2/project-build/cli/omicsmatic-0.4.0.jar';classes=O/'classes';classes.mkdir()
command=[str(J/'javac.exe'),'-encoding','UTF-8','-cp',str(jar),'-d',str(classes),str(T/'examples/gcta-native-grm/GctaGrmExample.java')]
p=subprocess.run(command,capture_output=True,timeout=60);(O/'javac.stdout').write_bytes(p.stdout);(O/'javac.stderr').write_bytes(p.stderr);assert p.returncode==0
def linux(p):return '/mnt/d/'+p.relative_to(Path('D:/')).as_posix()
def task(host):
    command=[str(J/'java.exe' if host=='windows21' else J25),'-cp',str(jar)+';'+str(classes),'GctaGrmExample'] if host!='linux21' else ['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','--exec','/usr/bin/java','-cp',linux(jar)+':'+linux(classes),'GctaGrmExample']
    p=subprocess.run(command,cwd=O,stdin=subprocess.DEVNULL,capture_output=True,timeout=120);(O/(host+'.stdout')).write_bytes(p.stdout);(O/(host+'.stderr')).write_bytes(p.stderr);assert p.returncode==0
    lines=p.stdout.decode().splitlines();assert len(lines)==12 and lines[0]=='included_markers=3' and lines[-1]=='allMissing\tNO_CALLED_ALLELES'
    assert lines[2]=='F1\tS1\tF1\tS1\t2.0\t2' and lines[5]=='F3\tS3\tF1\tS1\t-2.0\t2'
    return host,dict(command=command,exit_code=0,normalized_stdout=lines,raw_stdout_SHA256=hashlib.sha256(p.stdout).hexdigest())
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:rows=dict(pool.map(task,['windows21','windows25','linux21']))
assert rows['windows21']['normalized_stdout']==rows['windows25']['normalized_stdout']==rows['linux21']['normalized_stdout']
(O/'COMPLETED.json').write_text(json.dumps(dict(status='PASS_ACTUAL_NORMAL_JAR_EXAMPLE_ON_THREE_JVMS',results=rows),indent=2)+'\n',encoding='utf-8',newline='\n')
print('PASS actual Java example on Windows21/25 and Linux21',flush=True)
