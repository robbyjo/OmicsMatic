from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time,xml.etree.ElementTree as ET
R=Path('D:/projects/JLinAlg');T=R/'build/gc-2';B=T/'build/gcta-native-1';mode=sys.argv[1]
assert mode in ['before-cancellation-fix','qualified']
attempt=sys.argv[2] if len(sys.argv)>2 else '1';assert attempt.isdecimal() and int(attempt)>0
O=B/('gradle-'+mode+'-'+attempt);O.mkdir(exist_ok=False)
def pin(p):
    with p.open('rb') as f:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
seed=R/'build/gs-5/build/gsea-admission-1/global-gradle-1/project-build/dependencies/jdistlib-all-0.10.2.jar'
assert pin(seed)['sha256']=='8b50aaa11d2cbd512525e0d74f8e609f40db9f4fc179ccb7a885a82257e0ac81'
build=O/'project-build';(build/'dependencies').mkdir(parents=True);shutil.copyfile(seed,build/'dependencies'/seed.name)
init=O/'isolate.gradle';init.write_text("gradle.beforeProject { p -> p.layout.buildDirectory.set(new File('"+build.as_posix()+"')) }\n",encoding='utf-8',newline='\n')
if mode=='qualified':
    with init.open('a',encoding='utf-8',newline='\n') as stream:
        stream.write("gradle.projectsEvaluated { rootProject.tasks.register('gctaQualificationClasspath') { doLast { new File('"+(O/'test-runtime-classpath.txt').as_posix()+"').text = rootProject.configurations.testRuntimeClasspath.files.collect { it.absolutePath }.sort().join('\\n') + '\\n' } } }\n")
gradle=Path('C:/Users/User/.gradle/wrapper/dists/gradle-9.7.1-bin/1w1c7tv4s851m17nbqdsro2tv/gradle-9.7.1/bin/gradle.bat');jdk=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot')
command=[str(gradle),'--no-daemon','--offline','--console=plain','--max-workers=2','--project-cache-dir',str(O/'project-cache'),'--init-script',str(init)]
if mode=='qualified':command+=['--no-configuration-cache']
if mode=='qualified':command+=['gctaQualificationClasspath','executableJar']
command+=[':test','--tests','org.jlinalg.genetics.GctaHardcallGrmTest']
if mode=='qualified':command+=['--tests','org.jlinalg.genetics.GenomicRelationshipMatrixTest']
inputs={n:pin(T/n) for n in ['src/main/java/org/jlinalg/genetics/GctaHardcallGrm.java','src/test/java/org/jlinalg/genetics/GctaHardcallGrmTest.java','src/test/resources/org/jlinalg/genetics/gcta1941-hardcall-originals.zip','build.gradle']}
save(O/'COMMAND.json',dict(command=command,cwd=str(T),JAVA_HOME=str(jdk),inputs=inputs))
with (O/'stdout').open('xb') as stdout,(O/'stderr').open('xb') as stderr:
    process=subprocess.Popen(command,cwd=T,env=dict(os.environ,JAVA_HOME=str(jdk)),stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
    save(O/'PROCESS.json',dict(pid=process.pid));print('Started Gradle',mode,'PID',process.pid,flush=True);exit_code=process.wait()
reports={}
for path in sorted((build/'test-results/test').glob('TEST-*.xml')):
    root=ET.parse(path).getroot();reports[root.attrib['name']]=dict(tests=int(root.attrib['tests']),failures=int(root.attrib['failures']),errors=int(root.attrib['errors']),skipped=int(root.attrib['skipped']),failed_cases=[c.attrib['name'] for c in root.findall('testcase') if c.find('failure') is not None])
save(O/'COMPLETED.json',dict(exit_code=exit_code,reports=reports,source_inputs=inputs,JARs={str(p.relative_to(build)):pin(p) for p in build.rglob('omicsmatic-*.jar')}))
print('Gradle finished',mode,'exit',exit_code,json.dumps(reports),flush=True)
