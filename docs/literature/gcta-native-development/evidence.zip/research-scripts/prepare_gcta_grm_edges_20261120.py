from pathlib import Path
import hashlib,json,struct
R=Path('D:/projects/JLinAlg');T=R/'build/gc-2';B=T/'build/gcta-native-1';O=B/'edge-fixtures-1'
assert (R/'build/gcta-native-start-20261120-1/COMPLETED.json').exists()
O.mkdir(exist_ok=False)
def save(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
state=20261120
def random():
    global state
    state=(1664525*state+1013904223)&0xffffffff
    return state
def draws(m,n,missing=False):
    matrix=[]
    for v in range(m):
        row=[]
        for i in range(n):
            r=random();row.append(-1 if missing and r%11==0 else (r>>16)%3)
        # Ensure at least one retained marker is jointly called for every pair.
        if v==0:row=[i%3 for i in range(n)]
        matrix.append(row)
    return matrix
datasets={}
for m in [127,128,129]:
    datasets['complete-'+str(m)]=(draws(m,17), 'SUCCESS')
    datasets['missing-'+str(m)]=(draws(m,17,True), 'SUCCESS')
mixed=draws(259,17,True)
for j in range(1,len(mixed)):
    if j%29==0:mixed[j]=[0]*17
    elif j%31==0:mixed[j]=[-1]*17
    elif j%37==0:mixed[j]=[2]*17
datasets['dispositions-259']=(mixed,'SUCCESS')
datasets['major-minor-alleles']=([[0]*16+[1],[2]*16+[1],[0,2,1,0,2,1,0,2,1,0,2,1,0,2,1,0,2]],'SUCCESS')
datasets['constant-heterozygotes']=([[1]*7,[0,1,2,0,1,2,1]],'SUCCESS')
datasets['indefinite-pairwise']=([[0,2,-1],[-1,0,2],[2,-1,0]],'SUCCESS')
datasets['zero-joint-pair']=([[0,2,-1],[0,2,-1],[-1,-1,1]],'REFUSE_EMPTY_PAIR')
datasets['all-missing']=([[-1]*3 for _ in range(5)],'REFUSE_NO_POLYMORPHIC')
datasets['monomorphic-only']=([[0]*3,[2]*3,[0]*3],'REFUSE_NO_POLYMORPHIC')
datasets['one-sample-heterozygote']=([[0],[1],[2],[-1]],'SUCCESS')
boundary=[[0]*7 for _ in range(129)];boundary[127]=[0,1,2,0,1,2,1];boundary[128]=[2,1,0,2,1,0,1]
datasets['excluded-at-block-boundary']=(boundary,'SUCCESS')
rows=[]
for name,(matrix,status) in datasets.items():
    d=O/name;d.mkdir();m=len(matrix);n=len(matrix[0]);ids=[('家族' if i==0 else 'F'+str(i),'same' if i<2 else 'I'+str(i)) for i in range(n)]
    fam=''.join(f'{f}\t{i}\t0\t0\t1\t-9\n' for f,i in ids);bim=''.join(f'1\tv{j+1}\t0\t{10000*(j+1)}\tA\tG\n' for j in range(m))
    bed=bytearray([0x6c,0x1b,1]);codes={0:3,1:2,2:0,-1:1}
    for row in matrix:
        assert len(row)==n
        for start in range(0,n,4):bed.append(sum(codes[x]<<(2*k) for k,x in enumerate(row[start:start+4])))
    for suffix,content in [('fam',fam.encode()),('bim',bim.encode()),('bed',bytes(bed))]:(d/('input.'+suffix)).write_bytes(content)
    for algorithm in [0,1]:
        payload=bytearray(struct.pack('>4I',0x47434731,n,m,algorithm))
        def string(s):
            b=s.encode('utf-8');payload.extend(struct.pack('>I',len(b)));payload.extend(b)
        for fid,iid in ids:string(fid);string(iid)
        for j,row in enumerate(matrix):string('v'+str(j+1));payload.extend(bytes(3 if x==-1 else x for x in row))
        (d/('algorithm-'+str(algorithm)+'.input.bin')).write_bytes(payload)
    data=dict(name=name,samples=[dict(FID=f,IID=i) for f,i in ids],hardcalls=matrix,native_expected=status,
        source_dispositions_expected=[('NO_CALLED_ALLELES' if all(x==-1 for x in row) else 'MONOMORPHIC' if len(set(row)-{-1})==1 and next(iter(set(row)-{-1})) in [0,2] else 'INCLUDED') for row in matrix])
    save(d/'FIXTURE.json',data);rows.append(dict(name=name,samples=n,markers=m,native_expected=status,inputs={p.name:pin(p) for p in d.iterdir()}))
save(O/'FIXTURES.json',dict(schema_version=1,status='INDEPENDENT_SYNTHETIC_PREPARED_HARDCALL_SOURCE_CONTROLS',generator='Explicit rows and LCG32 a=1664525 c=1013904223 seed=20261120 in declared iteration order',cases=rows,author_data=False))
print('Prepared',len(rows),'datasets, two algorithms each; original behavior still to be observed',flush=True)
