from pathlib import Path
from fractions import Fraction
import concurrent.futures,hashlib,json,math,struct,subprocess
R=Path('D:/projects/JLinAlg');T=R/'build/gc-2';B=T/'build/gcta-native-1';F=B/'edge-fixtures-1';S=B/'edge-original-1';O=B/'edge-native-1';O.mkdir(exist_ok=False)
assert (S/'COMPLETED.json').exists()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
def floats(p):
    data=p.read_bytes();assert len(data)%4==0;return struct.unpack('<'+'f'*(len(data)//4),data)
def f32(x):return struct.unpack('<f',struct.pack('<f',x))[0]
fixtures=json.loads((F/'FIXTURES.json').read_bytes())['cases'];proof=[]
for fixture in fixtures:
    name=fixture['name'];data=json.loads((F/name/'FIXTURE.json').read_bytes());g=data['hardcalls'];n=fixture['samples'];markers=[]
    for row in g:
        called=[x for x in row if x!=-1]
        if not called:continue
        mean=Fraction(sum(called),len(called));variance=mean*(1-mean/2)
        if variance==0:continue
        markers.append((row,mean,variance))
    for algorithm in [0,1]:
        dirname=name+'-alg'+str(algorithm);a=S/'windows'/dirname;b=S/'linux'/dirname
        for suffix in ['.grm.bin','.grm.N.bin']:assert (a/('result'+suffix)).read_bytes()==(b/('result'+suffix)).read_bytes(),dirname+suffix
        assert (a/'result.grm.id').read_bytes().split()==(b/'result.grm.id').read_bytes().split()
        assert (a/'result.grm.id').read_bytes().decode('utf-8').split()==[field for sample in data['samples'] for field in [sample['FID'],sample['IID']]]
        got=floats(a/'result.grm.bin');counts=floats(a/'result.grm.N.bin');assert len(got)==n*(n+1)//2
        errors=[];expected_counts=[];empty=0;k=0
        # Independent exact rational centered products; no sqrt/dot/block code.
        source_float_weight=0.0
        for row,mean,variance in markers:source_float_weight=f32(source_float_weight+float(variance))
        weight=1.0 if algorithm==0 else f32(1.0/f32(source_float_weight/len(markers))) if markers else None
        for i in range(n):
            for j in range(i+1):
                called=[(row,mean,var) for row,mean,var in markers if row[i]!=-1 and row[j]!=-1]
                expected_counts.append(len(called));assert counts[k]==len(called),(dirname,i,j,counts[k],len(called))
                if called:
                    value=sum(((row[i]-mean)*(row[j]-mean)/(var if algorithm==0 else 1) for row,mean,var in called),Fraction(0))/len(called)
                    expected=f32(f32(float(value))*weight)
                    error=abs(got[k]-expected);errors.append(error)
                    assert error<=max(1e-12,abs(expected)*1.3e-7),(dirname,i,j,got[k],expected,error)
                else:empty+=1;assert got[k]==0,(dirname,i,j,got[k])
                k+=1
        proof.append(dict(case=name,algorithm=algorithm,exact_pair_counts=len(counts),included_markers=len(markers),empty_pairs=empty,
            independent_rational_max_abs_error=max(errors,default=0),cross_host_binary_exact=True,native_expected=fixture['native_expected'],
            original_all_outputs_zero=not any(got),original_all_pair_counts_zero=not any(counts)))
save(O/'INDEPENDENT.json',dict(status='PASS_EXACT_RATIONAL_AND_PAIR_COUNT_ORIGINAL_CHECKS',cases=proof))
J=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin');J25=Path('C:/Program Files/Java/jdk-25/bin/java.exe');C=O/'classes';C.mkdir()
probe=R/'build/gc-1/build/gcta-high-impact-1/native-grm-initial-1/NativeGctaGrmProbe.java'
command=[str(J/'javac.exe'),'-encoding','UTF-8','-d',str(C),str(T/'src/main/java/org/jlinalg/genetics/GctaHardcallGrm.java'),str(probe)]
p=subprocess.run(command,capture_output=True,timeout=90);(O/'javac.stdout').write_bytes(p.stdout);(O/'javac.stderr').write_bytes(p.stderr);assert p.returncode==0
def linux(p):return '/mnt/d/'+p.relative_to(Path('D:/')).as_posix()
def task(host):
    root=O/host;root.mkdir();rows=[]
    for fixture in fixtures:
        for algorithm in [0,1]:
            name=fixture['name']+'-alg'+str(algorithm);out=root/name;input=F/fixture['name']/('algorithm-'+str(algorithm)+'.input.bin')
            command=[str(J/'java.exe' if host=='windows21' else J25),'-cp',str(C),'NativeGctaGrmProbe',str(input),str(out)] if host!='linux21' else ['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','--exec','/usr/bin/java','-cp',linux(C),'NativeGctaGrmProbe',linux(input),linux(out)]
            p=subprocess.run(command,cwd=root,stdin=subprocess.DEVNULL,capture_output=True,timeout=90);(root/(name+'.stdout')).write_bytes(p.stdout);(root/(name+'.stderr')).write_bytes(p.stderr)
            row=dict(case=fixture['name'],algorithm=algorithm,exit_code=p.returncode,command=command)
            if fixture['native_expected']=='SUCCESS':
                assert p.returncode==0,(host,name,p.stderr.decode(errors='replace'))
                reference=S/'windows'/name
                diffs={}
                for file in ['result.grm.bin','result.grm.N.bin']:
                    actual=(out/file).read_bytes();expected=(reference/file).read_bytes();assert len(actual)==len(expected)
                    different=[i//4 for i in range(0,len(actual),4) if actual[i:i+4]!=expected[i:i+4]]
                    diffs[file]=dict(fields=len(actual)//4,different_fields=len(different),first_differences=different[:8])
                row['comparisons']=diffs
                assert (out/'result.grm.id').read_bytes().split()==(reference/'result.grm.id').read_bytes().split()
            else:
                assert p.returncode!=0 and b'IllegalArgumentException' in p.stderr,(host,name,p.returncode)
                message=b'no jointly called retained markers' if fixture['native_expected']=='REFUSE_EMPTY_PAIR' else b'no source-valid polymorphic markers'
                assert message in p.stderr,(host,name,p.stderr.decode(errors='replace'))
                assert not list(out.iterdir());row['expected_refusal']=fixture['native_expected']
            rows.append(row)
    save(root/'RESULTS.json',rows);print(host,'complete cases',len(rows),'different GRM fields',sum(r.get('comparisons',{}).get('result.grm.bin',{}).get('different_fields',0) for r in rows),flush=True)
    return host,rows
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=dict(pool.map(task,['windows21','windows25','linux21']))
save(O/'RESULTS.json',dict(status='NATIVE_EDGE_COMPARISONS_REQUIRE_DIFFERENCE_REVIEW',results=results,source_sha256=hashlib.sha256((T/'src/main/java/org/jlinalg/genetics/GctaHardcallGrm.java').read_bytes()).hexdigest()))
