from pathlib import Path
import concurrent.futures,hashlib,json,os,subprocess,time
R=Path('D:/projects/JLinAlg');T=R/'build/gc-2';B=T/'build/gcta-native-1';F=B/'edge-fixtures-1';O=B/'edge-original-1';I=R/'build/gc-1/build/gcta-high-impact-1/upstream-1.94.1-intake-1'
def pin(p):
    with p.open('rb') as f:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
win=I/'windows/files/gcta-1.94.1-win-x86_64/gcta-win-1.94.1.exe';lin=I/'linux/download'
assert pin(win)==dict(bytes=34016768,sha256='2529bccb2f685332f115726c3cb2bf8cab91f12ae3344a991e3a52d751bdb07e')
assert pin(lin)==dict(bytes=38686056,sha256='dbb2b5e5d51e278328ff297a403d3dd8ee5f5280f0b6d3d8db74b3e7fead7b49')
fixtures=json.loads((F/'FIXTURES.json').read_bytes())['cases']
for row in fixtures:
    for name,wanted in row['inputs'].items():assert pin(F/row['name']/name)==wanted
O.mkdir(exist_ok=False)
def linux(p):return '/mnt/d/'+p.relative_to(Path('D:/')).as_posix()
def task(host):
    results=[];root=O/host;root.mkdir()
    for fixture in fixtures:
        for algorithm in [0,1]:
            name=fixture['name']+'-alg'+str(algorithm);out=root/name;out.mkdir()
            convert=str if host=='windows' else linux
            argv=['--bfile',convert(F/fixture['name']/'input'),'--make-grm','--make-grm-alg',str(algorithm),'--thread-num','1','--out',convert(out/'result')]
            command=[str(win),*argv] if host=='windows' else ['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','--cd',linux(out),'--exec',linux(lin),*argv]
            start=time.monotonic()
            with (out/'stdout').open('xb') as stdout,(out/'stderr').open('xb') as stderr:p=subprocess.run(command,cwd=out,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=90,env=dict(os.environ,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1'),creationflags=subprocess.CREATE_NO_WINDOW if host=='windows' else 0)
            row=dict(case=fixture['name'],algorithm=algorithm,host=host,command=command,exit_code=p.returncode,elapsed_seconds=time.monotonic()-start,files={p.name:pin(p) for p in out.iterdir() if p.is_file()},semantic_qualification_complete=False)
            save(out/'PROCESS.json',row);results.append(row);print('Original GRM edge',host,name,'exit',p.returncode,flush=True)
    save(root/'RESULTS.json',results);return host,results
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=dict(pool.map(task,['windows','linux']))
save(O/'COMPLETED.json',dict(status='ORIGINAL_GRM_EDGES_CAPTURED_SEMANTIC_REVIEW_REQUIRED',results=results,source_commit='6da64e9d8be838d01c34efb974e69c72e861f4c2',native_credit=0))
