from pathlib import Path
import concurrent.futures,hashlib,json,os,shutil,subprocess,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/gc-2';B=T/'build/gcta-native-1';G=B/'gradle-qualified-2';O=B/'packaged-tests-1';O.mkdir(exist_ok=False)
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
def pin(p):
    with p.open('rb') as f:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
graduated=json.loads((G/'COMPLETED.json').read_bytes());assert graduated['exit_code']==0
assert sum(r['tests'] for r in graduated['reports'].values())==9 and not any(r['failures'] or r['errors'] or r['skipped'] for r in graduated['reports'].values())
jar=G/'project-build/cli/omicsmatic-0.4.0.jar';assert jar.is_file()
old=R/'build/gs-5/build/gsea-admission-1/global-gradle-1/project-build/cli/omicsmatic-0.4.0.jar';assert pin(old)==dict(bytes=195901211,sha256='bdc1e71bd7a53e0d727deb105c5c97baaaf8cc6627275bf14aee9584816c0dff')
with zipfile.ZipFile(old) as prior,zipfile.ZipFile(jar) as current:
    assert len(prior.namelist())==len(set(prior.namelist()))==23522
    assert len(current.namelist())==len(set(current.namelist()))
    additions=sorted(set(current.namelist())-set(prior.namelist()));removed=sorted(set(prior.namelist())-set(current.namelist()))
    changed=[n for n in prior.namelist() if n in current.namelist() and prior.read(n)!=current.read(n)]
    assert not removed and not changed,(removed,changed)
    assert len(additions)==8 and all(n.startswith('org/jlinalg/genetics/GctaHardcallGrm') and n.endswith('.class') for n in additions),additions
    payloads=dict(prior_payloads_unchanged=23522,added_native_classes=additions,removed=[],changed=[])
save(O/'JAR-PAYLOADS.json',payloads);print('Normal JAR verified: all 23522 predecessor payloads unchanged; 8 new native classes',flush=True)
deps=O/'junit';deps.mkdir();jars={}
for line in (G/'test-runtime-classpath.txt').read_text().splitlines():
    p=Path(line)
    if p.name.startswith(('junit-','opentest4j-','apiguardian-api-')) and p.suffix=='.jar':
        assert p.name not in jars;shutil.copyfile(p,deps/p.name);jars[p.name]=pin(p)
assert {'junit-platform-launcher-1.13.4.jar','junit-jupiter-engine-5.13.4.jar'}<=set(jars)
classes=O/'test-classes';classes.mkdir();testroot=G/'project-build/classes/java/test'
for pattern in ['GctaHardcallGrmTest*.class','GenomicRelationshipMatrixTest*.class']:
    for p in (testroot/'org/jlinalg/genetics').glob(pattern):
        dest=classes/p.relative_to(testroot);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
assert not (classes/'org/jlinalg/genetics/GctaHardcallGrm.class').exists()
res=O/'resources/org/jlinalg/genetics';res.mkdir(parents=True);shutil.copyfile(T/'src/test/resources/org/jlinalg/genetics/gcta1941-hardcall-originals.zip',res/'gcta1941-hardcall-originals.zip')
launcher=O/'launcher-classes';launcher.mkdir();J=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin');J25=Path('C:/Program Files/Java/jdk-25/bin/java.exe')
command=[str(J/'javac.exe'),'-cp',str(deps/'*'),'-d',str(launcher),str(T/'tools/literature/gcta_native/PackagedGrmTests.java')]
p=subprocess.run(command,capture_output=True,timeout=60);(O/'javac.stdout').write_bytes(p.stdout);(O/'javac.stderr').write_bytes(p.stderr);assert p.returncode==0
def linux(p):return '/mnt/d/'+p.relative_to(Path('D:/')).as_posix()
elements=[jar,launcher,classes,O/'resources',deps/'*']
def task(host):
    if host=='linux21':command=['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','--exec','/usr/bin/java','-cp',':'.join(linux(p) for p in elements),'PackagedGrmTests']
    else:command=[str(J/'java.exe' if host=='windows21' else J25),'-cp',';'.join(str(p) for p in elements),'PackagedGrmTests']
    with (O/(host+'.stdout')).open('xb') as stdout,(O/(host+'.stderr')).open('xb') as stderr:p=subprocess.run(command,cwd=O,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=180,creationflags=subprocess.CREATE_NO_WINDOW if host!='linux21' else 0)
    row=dict(host=host,command=command,exit_code=p.returncode,stdout=pin(O/(host+'.stdout')),stderr=pin(O/(host+'.stderr')))
    save(O/(host+'.PROCESS.json'),row);assert p.returncode==0,(host,(O/(host+'.stdout')).read_text(errors='replace')[-2000:])
    assert 'GCTA_PACKAGED_SOURCE_CHECKS_PASS tests=9 original_cases=35 float32_fields=190428 explicit_source_refusals=6' in (O/(host+'.stdout')).read_text()
    print('Packaged GCTA GRM',host,'PASS nine tests, 190428 original float fields, 6 captured-source refusals',flush=True);return host,row
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=dict(pool.map(task,['windows21','windows25','linux21']))
save(O/'COMPLETED.json',dict(status='PASS_NORMAL_JAR_NATIVE_GRM_AND_RELATED_REGRESSION_TESTS_ON_THREE_JVMS',jar=pin(jar),jar_path=str(jar),payloads=payloads,results=results,JUnit_dependencies=jars,
    copied_test_class_files={p.relative_to(classes).as_posix():pin(p) for p in classes.rglob('*') if p.is_file()},
    normal_product_classes_loaded_from_JAR=True,source_compiler='Windows JDK21',independent_Linux_source_compilation='SKIP3: Linux javac absent',GCTA_workflow_implemented=False,catalog_credit=0))
