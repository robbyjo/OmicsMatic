from pathlib import Path
import importlib.util,json,subprocess
R=Path('D:/projects/JLinAlg');P=R/'build/git-publish/20261120-gcta-handover-67';T=R/'build/gc-2';O=R/'build/gcta-native-start-20261120-1';O.mkdir(exist_ok=False);BASE='23f5b5008e4e9e716e69a5c2c260e7764293ce4b'
def git(root,*a):return subprocess.check_output(['git','--no-replace-objects',*a],cwd=root)
spec=importlib.util.spec_from_file_location('inventory',P.parent/'20261115-all-main-3/inventory.py');inv=importlib.util.module_from_spec(spec);spec.loader.exec_module(inv)
old=json.loads((P/'WORKTREES-EXPECTED.json').read_bytes());assert len(old)==23
assert json.loads((P/'PUBLISHED.json').read_bytes())['head']==BASE and git(R,'ls-remote','origin','refs/heads/main').decode().split()[0]==BASE
for row in old:assert inv.snapshot(Path(row['root']))==row,row['root']
roots={Path(b.splitlines()[0][9:]).resolve() for b in git(R,'worktree','list','--porcelain').decode().strip().split('\n\n')}
assert roots=={Path(row['root']).resolve() for row in old}
(O/'WORKTREES-BEFORE.json').write_text(json.dumps(old,indent=2)+'\n',encoding='utf-8',newline='\n')
p=subprocess.run(['git','worktree','add','-b','codex/gcta-native-grm-20261120',str(T),BASE],cwd=R,capture_output=True);(O/'worktree.stdout').write_bytes(p.stdout);(O/'worktree.stderr').write_bytes(p.stderr);assert p.returncode==0
(T/'build/gcta-native-1').mkdir(parents=True)
(O/'COMPLETED.json').write_text(json.dumps(dict(status='PASS_23_PRIOR_WORKTREES_AND_NEW_NATIVE_GCTA_CHECKOUT',base=BASE,worktrees=24,root=str(T)),indent=2)+'\n',encoding='utf-8',newline='\n')
print('PASS 23 predecessor worktrees preserved; new native GRM stage',T,flush=True)
