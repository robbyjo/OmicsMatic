from pathlib import Path
import hashlib,json,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/gc-2';B=T/'build/gcta-native-1';F=B/'edge-fixtures-1';S=B/'edge-original-1';N=B/'edge-native-1';OLD=R/'build/gc-1/build/gcta-high-impact-1'
assert (N/'RESULTS.json').exists()
result=json.loads((N/'RESULTS.json').read_bytes())
for rows in result['results'].values():
    assert len(rows)==30
    for row in rows:
        for comparison in row.get('comparisons',{}).values():assert comparison['different_fields']==0,row
members={};rows=[];independent=json.loads((N/'INDEPENDENT.json').read_bytes())['cases']
def add_case(name,input,reference,linux,status,dispositions):
    members[name+'/input.bin']=input.read_bytes()
    for suffix in ['grm.bin','grm.N.bin','grm.id']:
        members[name+'/result.'+suffix]=(reference/('result.'+suffix)).read_bytes()
        members[name+'/linux.'+suffix]=(linux/('result.'+suffix)).read_bytes()
    members[name+'/dispositions.txt']=('\n'.join(dispositions)+'\n').encode()
    rows.append((name,status,sum(x=='INCLUDED' for x in dispositions)))
for entry in independent:
    name=entry['case']+'-alg'+str(entry['algorithm']);f=F/entry['case'];fixture=json.loads((f/'FIXTURE.json').read_bytes())
    add_case(name,f/('algorithm-'+str(entry['algorithm'])+'.input.bin'),S/'windows'/name,S/'linux'/name,entry['native_expected'],fixture['source_dispositions_expected'])
for name in ['grm-complete','grm-missing','grm-alg1','grm-bin-A','grm-bin-B']:
    m=384 if name in ['grm-bin-A','grm-bin-B'] else 768
    add_case('initial-'+name,OLD/'native-grm-initial-1'/(name+'.input.bin'),OLD/'original-core-2/windows'/name,OLD/'original-core-2/linux'/name,'SUCCESS',['INCLUDED']*m)
members['CASES.tsv']=('case\tnative_expected\tincluded_markers\n'+''.join('\t'.join(map(str,row))+'\n' for row in rows)).encode()
members['PROVENANCE.json']=(json.dumps(dict(status='SYNTHETIC_GCTA_1_94_1_HARDCALL_SOURCE_CONTROLS',original_source_commit='6da64e9d8be838d01c34efb974e69c72e861f4c2',
    cases=len(rows),success_cases=29,explicit_native_refusals=6,originals='Original Windows/Linux executables; all fresh 30 edge runs per host exit0, plus five retained original cases',
    native_expected_refusals='Strict declared boundary for empty pairs/no usable polymorphic markers; original writes0/N0',author_genotypes=False,source_equations_checked_independently_with_exact_rational_arithmetic=True,
    original_Windows_SHA256='2529bccb2f685332f115726c3cb2bf8cab91f12ae3344a991e3a52d751bdb07e',
    original_Linux_SHA256='dbb2b5e5d51e278328ff297a403d3dd8ee5f5280f0b6d3d8db74b3e7fead7b49'),indent=2)+'\n').encode()
members['SHA256SUMS']=''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(members.items())).encode()
target=T/'src/test/resources/org/jlinalg/genetics/gcta1941-hardcall-originals.zip';target.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(members.items()):z.writestr(name,data)
expected_fields=sum(len(members[name+'/result.grm.bin'])//2 for name,status,_ in rows if status=='SUCCESS')
assert expected_fields==190428
print('Saved 35-case original corpus:',target.stat().st_size,'bytes;',expected_fields,'GRM/N fields, 6 explicit refusal cases',flush=True)
