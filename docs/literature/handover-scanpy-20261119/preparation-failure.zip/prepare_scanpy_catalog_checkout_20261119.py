from pathlib import Path
import importlib.util,json,subprocess

R=Path('D:/projects/JLinAlg');A=R/'build/high-impact-stats-1';O=A/'build/scanpy-catalog-admission-1'
P=R/'build/git-publish/20261119-scanpy-hvg-50';HEAD='d70b229489a7b16206060ca8827539011b6a896a'
STAGE='bd26330459c35c5ec6e5be904d349280bb353f6e'
O.mkdir(exist_ok=False)
def git(*args):return subprocess.check_output(['git','--no-replace-objects',*args],cwd=A)
assert git('rev-parse','HEAD').decode().strip()==HEAD
assert not git('status','--porcelain=v1','-z','--untracked-files=all')
expected=json.loads((P/'WORKTREES-EXPECTED.json').read_bytes());assert len(expected)==22
spec=importlib.util.spec_from_file_location('inv',P.parent/'20261115-all-main-3/inventory.py');inv=importlib.util.module_from_spec(spec);spec.loader.exec_module(inv)
for row in expected:assert inv.snapshot(Path(row['root']))==row,row['root']
(O/'WORKTREES-BEFORE.json').write_text(json.dumps(expected,indent=2)+'\n')
checkout=O/'enrichr-predecessor-checkout';assert not checkout.exists()
p=subprocess.run(['git','-c','core.autocrlf=false','worktree','add','--detach',str(checkout),STAGE],cwd=A,capture_output=True)
(O/'checkout.stdout').write_bytes(p.stdout);(O/'checkout.stderr').write_bytes(p.stderr);assert p.returncode==0,p.stderr
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=checkout).decode().strip()==STAGE
build=checkout/'build';build.mkdir(exist_ok=True);link=build/'literature-review';target=R/'build/literature-review'
assert not link.exists() and target.is_dir()
script="New-Item -ItemType Junction -Path '"+str(link)+"' -Target '"+str(target)+"' | Out-Null"
p=subprocess.run(['C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe','-NoProfile','-NonInteractive','-Command',script],cwd=A,capture_output=True)
(O/'cache-link.stdout').write_bytes(p.stdout);(O/'cache-link.stderr').write_bytes(p.stderr);assert p.returncode==0,p.stderr
assert link.resolve()==target.resolve()
assert not subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=checkout)
for row in expected:assert inv.snapshot(Path(row['root']))==row,row['root']
after=expected+[inv.snapshot(checkout)];assert len(after)==23
(O/'WORKTREES-EXPECTED.json').write_text(json.dumps(after,indent=2)+'\n')
(O/'CHECKOUT.json').write_text(json.dumps(dict(status='PASS_EXACT_CLEAN_ENRICHR_PREDECESSOR_CHECKOUT_CREATED',
    checkout=str(checkout),commit=STAGE,cache_link_target=str(target),original_worktrees_preserved=22,total_worktrees=23,
    source_overlay=False,scientific_programs_run=False),indent=2)+'\n')
print('Prepared exact Enrichr checkout; all 22 previous worktrees preserved',flush=True)
