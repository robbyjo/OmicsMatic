# 250-paper omics and GWAS toolbox catalog


## Original velociraptor R workflow: warnings and required actions

**Current catalog: 250 papers, 433 named software families, 2,672 observations and 1,168 individually reviewed uses; 1,504 uses await review.** The fixed71 Nature,104 Nature Genetics and75 AJHG papers remain unchanged. The existing P228 velociraptor reading retains its primary anchors, role, unknown author settings and uncertainties. Only implementation coverage changes; no paper, observation or review is added.

**112 scoped new integrations: 20 native Java subsets and 92 original upstream workflows; 115 including three existing adapters. 262 named families remain missing.** This adds one upstream velociraptor family credit and zero additional native Java credit. The full semantic review and implementation objective remains open.

Use python3 tools/literature/velociraptor120/run.py --request caller-request.json with an exact permitted original1.20.0 Linux/WSL provider and complete trusted R script. Original R preprocessing, all7 S4 signatures, conversion and declared scvelo0.3.3 backend remain original. Separate figures.py executes original R-only figure functions over supplied complete fits/projections without providing or initializing a Python fitting backend. These are source entry points, not bundled Java CLI commands. Install/download only where permitted with explicit flags and NEW paths; analysis installs nothing. Native Windows analysis and installation skip.

**Original R native stack diagnostics remain unresolved.** Review every raw console and original condition. R handler counts are not universal raw/native/Python diagnostic totals; unknown totals remain unavailable, never zero.13 complete numeric comparisons cover3,732 nodes/2,617 atomic payloads/2,457,351 bytes without equality waivers.4 complete SVG/PNG pairs and8 serialized-graph replays matched original bytes;2 original named-coordinate errors remain failed analyses.36 controls and6 complete public examples passed. These establish selected integration paths, not the entire package, biological validity, convergence or paper reproduction. Graph environment/pointer identity and opaque RDS byte identity are not claimed.

**P228 does not report wrapper/Python editions, velocity mode or exact calls.** The selected R4.5.3/Python3.12.10/NumPy2.2.6/Pandas2.2.3/SciPy1.16.3 profile is a project choice, not recovered author settings. Preserve the Velocyto name beside a velociraptor URL as a source/link discrepancy. The native Java grid component computes neither RNA velocity nor latent time and adds no second family credit. Original named-coordinate DFrame failures are not repaired by renaming axes; separate positive streamline controls use unchanged original PCA coordinates and matching vectors.

**SKIP3 skips dependent analysis** for missing/forbidden prerequisites, installation, download or execution. **FAIL2 admits no complete result**, including final recording failures. Do not infer success from a leftover RDS or figure. Read exit code, analysis-status.json, WARNINGS.md and MANIFEST.json. If status cannot be saved, the console ends with FAIL2 and FINALIZATION_ERROR.json records failure where writable. If all records are blocked, preserve the full console, resolve the named filesystem cause and retry a NEW writable directory. Never overwrite historical evidence, drop failed cases, repair identifiers/NA/NaN/Inf or change saved hashes. Retain full RDS/value trees, graphs, conditions/calls, raw logs, available caller state and native temporary copies; live IPC streams and terminated process memory are not reconstructed. Trusted scripts run with account permissions; this is not an OS sandbox or total CPU/RSS enclosure.

Other restrictions remain unchanged: Cell Ranger/ARC are excluded by user request; printed scVelo0.24 remains unresolved; four historical direct-Python SVGs remain irrecoverable and the wrapper does not recover them. Earlier dependency/profile failures, within-original SciPy1.18.1 pseudotime variability, the failed first example comparator and earlier source revisions remain retained. The first frozen dossier remains in place; a separate current dossier captures stronger complete-example replay without refreshing historical hashes.

Read [velociraptor commands, source role and recovery](../VELOCIRAPTOR120_CATALOG_INTEGRATION.md). Validate with `python tools/literature/velociraptor_catalog/verify.py --out build/literature-review/monocle-runtime/NEW-velociraptor-catalog-check --rescan-sources`. The full goal remains open.

<details><summary>Previous checkpoints (historical)</summary>

# 250-paper omics and GWAS toolbox catalog


## Original scVelo workflow: warnings and required actions

**Current catalog: 250 papers, 433 named software families, 2,672 observations and 1,168 individually reviewed uses; 1,504 uses await review.** The fixed71 Nature,104 Nature Genetics and75 AJHG papers remain unchanged. Five existing scVelo observations were individually reviewed. The separately named velociraptor R wrapper adds one missing family, one observation and one review; it has zero implementation credit. Seven family-specific anchors occupy six distinct primary paragraphs.

**111 scoped new integrations: 20 native Java subsets and 91 original upstream workflows; 114 including three existing adapters. 263 named families remain missing.** This adds one upstream scVelo family credit and zero native Java credit. The full semantic review and implementation goal remains open.

Use python3 tools/literature/scvelo024025/run.py --request caller-request.json with an exact matching original0.2.4 or0.2.5 Linux/WSL CPU provider and complete trusted Python script. This is a Python source entry point, not a standalone JAR or root dispatch route. Install only where permitted using install.py --version 0.2.4 or --version 0.2.5 with explicit --allow-install --allow-download and NEW paths. Analysis installs nothing. Native Windows original execution skips.

**P070 prints0.24; its dependent reported-edition analysis remains SKIP3.** The exact PyPI endpoint returnedHTTP404; do not relabel it0.2.4. **P228 uses the separate velociraptor R interface, which remains missing and unqualified here.** Its selected original1.20.0 source declares scvelo==0.3.3; direct Python0.2.x providers do not qualify that R preprocessing/conversion/environment path. Neither wrapper nor Python author edition/mode is inferred. Preserve the Velocyto name paired with a velociraptor URL as a source/link discrepancy. P051's exact count-threshold keyword is unreported; min_shared_counts=30 is an explicit caller choice in the larger control.

**Review original NaN loss-history padding and every delivered warning/error.** Complete synthetic original-versus-adapter checks cover54 stages,2,124 arrays,25,165,036 elements,2,272 result files and10 figures at tolerance zero. The stochastic/PAGA and dynamical/latent-time examples retain160 cells/12 genes; two larger stochastic controls retain96 cells and select2,000 HVGs from2,100 input genes with50 neighbors/30 PCs. These are integration controls, not author settings, convergence, independent statistical validity or paper reproduction. Original scVelo suppresses UserWarning during import; zero delivered warnings is not absence of numerical issues. Visible, ignored and promoted warning policies remain distinct.

**Four earlier SVGs were overwritten and cannot be recovered. Original temporary paths are not durable evidence.** At archival review168 original analysis temporary directories and one unit fixture were unavailable; all13 recorded regular temporary-file copies/268,435,479 bytes remain verified in saved analysis bundles. Use native-temporary copies and retained node identities, not historical /tmp paths. Historical original_root_retained flags record presence at controller retention time, not later availability. The original pack worker stopped during final read-only rechecking; separate full archive/source recovery is retained without rewriting its incomplete history.

**SKIP3 skips dependent analysis** for missing/forbidden exact prerequisites, installation/download or execution. Supply only permitted requirements and retry NEW paths. **FAIL2 admits no complete result.** Retain all available original objects, NaN/Inf, raw worker reports, complete process.stdout/process.stderr, diagnostics/conditions.json, WARNINGS.md, analysis-status.json, MANIFEST.json, native-temporary-inventory.json and every SUPERVISOR_ERROR.txt, WORKER_DIAGNOSTIC_ERROR.txt or NATIVE_TEMPORARY_ERROR.txt. Unknown totals are unavailable, never zero: condition_counts_complete false and warning_review_required true. If recording is blocked, retain the complete console and resolve the named filesystem requirement. Never drop failed cases or change saved hashes. Trusted scripts run with account permissions; owned process-group and capacity supervision is not an OS sandbox or total CPU/RSS enclosure.

Other restrictions remain explicit: Cell Ranger and Cell Ranger ARC are excluded by user request; cell2location's reported0.7a0 remains unqualified by0.1.3; rstatix retains revision2 recovery, ggpubr retains failed/empty layer eligibility limits, and other existing tool restrictions are unchanged.

Read [scVelo commands, current source roles and recovery](../SCVELO_CATALOG_INTEGRATION.md). Validate with `python tools/literature/scvelo_catalog/verify.py --out build/literature-review/monocle-runtime/NEW-scvelo-catalog-check --rescan-sources`. The full semantic review and implementation objective remain open.

<details><summary>Retained previous catalog checkpoints (historical)</summary>

# 250-paper omics and GWAS toolbox catalog


## Original cell2location workflow: warnings and required actions

**Current catalog: 250 papers, 432 named software families, 2,671 observations and 1,162 individually reviewed uses; 1,509 uses await review.** The fixed cohort remains 71 Nature, 104 Nature Genetics and 75 AJHG papers, 2023-10-23 through 2026-10-23. Six existing cell2location observations were enriched from all nine named primary paragraphs; no paper or observation was added.

**110 scoped new integrations: 20 native Java subsets and 90 original upstream workflows; 113 including 3 existing adapters. 263 named families remain missing.** This adds one upstream cell2location 0.1.3 family credit and zero native Java credit. The full semantic review and implementation goal remains open.

Use python3 tools/literature/cell2location013/run.py --request caller-request.json. This is an explicit Python source entry point with a separate qualified private Linux/WSL CPU Python 3.9.25/Torch 2.0.1+cpu/scvi-tools 0.20.3/Pyro 1.8.6 environment, not a standalone JAR or root dispatch route. Download/install only where permitted using the separate install.py with explicit --allow-install --allow-download and NEW paths. Setup creates no global Python executable links. Analysis installs nothing. Native Windows original execution skips.

**P096 reports 0.7a0, which is not qualified by 0.1.3; dependent historical-edition analysis remains SKIP3.** Preserve the paper's raw-reference wording and the author's log_normalised filename uncertainty; a filename does not prove matrix transformation. Preserve the reported NMF range 5 to 30 and the author code np.arange(5,30), which generates 5 through 29. Other unreported author editions/settings remain unknown. No edition, covariate argument, aggregation operator, input layer or mapping-score field is silently substituted.

**Review every warning/error before using results.** The complete synthetic example retains 17 original delivered warnings and 5 warning/error log records, including undefined NMF diagnostic divisions and explicit CPU/JAX and headless plotting messages. All 647 retained scientific arrays/65,212 elements and 17 independently recorded stages matched direct upstream execution at tolerance zero; 684 result files, all NMF models and both factor settings remain retained. This is not convergence or biological validation. The older shared-object graph limitation and failed recorder/setup/verifier attempts remain preserved with their original scope.

**SKIP3 skips dependent analysis** for missing/forbidden runtime, provider, input, original symbol/dependency, installation/download or execution. Supply only permitted exact prerequisites and retry NEW paths. **FAIL2 admits no complete result.** Retain all original objects, full process.stdout/process.stderr, diagnostics/conditions.json, raw worker-status.json, SUPERVISOR_ERROR.txt, WORKER_DIAGNOSTIC_ERROR.txt, WARNINGS.md, analysis-status.json and MANIFEST.json. Unknown totals are unavailable, not zero, with condition_counts_complete false and warning_review_required true. If the OS prevents recording, retain the complete console and resolve the named filesystem requirement. Never drop failed cases or relabel a partial population complete. Trusted scripts run with account permissions; owned worker supervision is not an OS sandbox or total CPU/RSS enclosure.

Other restrictions remain: Cell Ranger and Cell Ranger ARC are excluded by user request; rstatix uses the qualified revision2 recovery supervisor; ggpubr retains failed/empty statistical-layer eligibility limits; QuPath retains edition/image/model limits; reported AllelicSeries1.1.2 remains unresolved; ImageJ distributions/plugins and unspecified palette assignments stay separate. This admission changes none of those families or their source roles.

Read [cell2location commands, source roles and recovery](../CELL2LOCATION_CATALOG_INTEGRATION.md). Validate with `python tools/literature/cell2location_catalog/verify.py --out build/literature-review/monocle-runtime/NEW-cell2location-catalog-check --rescan-sources`. The full semantic review and implementation objective remain open.

<details><summary>Retained previous catalog checkpoints (historical)</summary>

# 250-paper omics and GWAS toolbox catalog


## Current rstatix revision2 routing: warnings and required actions

**Current catalog: 250 papers, 432 named software families, 2,671 observations and 1,156 individually reviewed uses; 1,515 uses await individual review.** This update changes the existing rstatix workflow route and recovery instructions only. All 250 paper identities, all 2,671 observations, all 1,156 reviews and all six rstatix source readings remain unchanged. The fixed cohort is 71 Nature, 104 Nature Genetics and 75 AJHG papers, 2023-10-23 through 2026-10-23. Full semantic review and implementation remain open.

**109 scoped new integrations remain available: 20 native Java subsets and 89 upstream workflows; 112 including 3 existing adapters. 264 named families remain missing.** Supervisor revision2 adds zero family, native-method or review credit. Use python3 tools/literature/rstatix072_workflow_v2/run.py with the same exact request schema and a NEW output path. It uses the unchanged original rstatix0.7.2 worker and a permitted private Linux/WSL R4.5.3 provider; it is not a standalone JAR. Native Java one-way Levene remains separate. Canonical executable and root dispatch remain unchanged. Read RSTATIX_REVISION2_CATALOG.md and RSTATIX072_WORKFLOW_REVISION2.md for commands and recovery.

**Interrupted-worker diagnostics require review.** The historical supervisor correctly refused a truncated worker report but could omit WARNINGS.md and MANIFEST.json. Revision2 retains the raw malformed report, partial results, warning/inventory records and WORKER_DIAGNOSTIC_ERROR.txt. Incomplete warning, message and error counts are unavailable, not zero: JSON null, condition_counts_complete false and warning_review_required true. SUPERVISOR_ERROR.txt retains controller tracebacks. No raw report is repaired. Inspect every original condition and full process.stdout/process.stderr, correct the named cause and retry NEW paths.

**Filesystem and monitoring failures admit no complete result.** A disappearing temporary child directory no longer aborts monitoring; missing owned roots, persistent capacity violations and forbidden links still fail. If the OS or a blocked path prevents a warning/status/inventory file, the controller attempts other records independently and prints the named recording failure and required action to its complete console log. Preserve that log and every available partial file; resolve the filesystem prerequisite and retry NEW paths. Unwritable diagnostics cannot be guaranteed. Never treat an incomplete inventory as complete.

**SKIP3 skips dependent analysis** when matching source, runtime, provider, input, literal export/package, permitted installation/download or execution is unavailable/forbidden. Install only where permitted, supply exact prerequisites and retry NEW paths. Windows original execution skips; use native Linux/WSL Python/R. Analysis installs nothing; a READY provider is not an analysis result. Explicit ALLOW execution/trusted-code policies and trusted caller code are required. Account permissions are not an OS sandbox or total CPU/RSS guarantee; same-group supervision excludes child-created separate sessions. Cell Ranger and Cell Ranger ARC remain excluded by user request.

**FAIL2 admits no complete result.** Preserve complete/partial original objects, input identities, warnings/errors, raw malformed diagnostics, logs, inventories and status. Correct the named cause and retry NEW paths. All original warnings remain visible; warn=2 still fails. Early zero exit, missing/extra/truncated results, changed inputs, forbidden links, malformed counts and capacity violations refuse admission. Do not drop cases, repair original algorithms or label partial populations complete. Files/markers and saved hashes do not prove arbitrary-code scientific validity, authenticity, author-runtime equivalence or biological truth.

**Paper roles and editions stay literal.** All six existing rstatix readings and 12 named primary paragraphs are preserved. Five papers report0.7.2; P241 reports no edition or exact test. P054 literally prints wilcoxon_test, while selected0.7.2 exports wilcox_test: the missing literal export skips analysis, with no spelling repair. Author comparisons, pairing, variance assumptions, direction and correction families remain inputs; P032's test/correction method remains unknown. Original p-value rounding, full RDS objects, formulas, grouping, conditions and RNG behavior remain original R behavior. Selected R4.5.3/car3.1-5 differs from historical author profiles. No paper is reproduced.

**Qualification retains the full population and every failed attempt.** All248 original calls,250 declared result files,444 rows and5,664 table cells match direct original R and the predecessor at tolerance zero. All31 earlier controls plus8 malformed-report and2 blocked-recording cases pass:41 Linux workflow controls, one Windows refusal, seven Windows/Linux monitor controls, the complete seven-operation public example and four frozen-verifier refusals. The main evidence has5,185 members, both link identities, blocked empty-directory identities and all failed attempts; an auxiliary control archive is retained. Original worker/statistical sources and earlier scientific verifiers remain unchanged. This catalog gate executes no new original analysis or installation.

**Other retained restrictions still apply.** ggpubr original Computation failed in warnings refuse admission despite rendered files/zero exit; silent empty layers require caller eligibility checks. ggpubr uses separate R4.3.3 providers for0.4.0/0.6.0, not rstatix's R4.5.3 profile. QuPath0.5.1 H-DAB controls do not qualify other editions, fluorescence/proximity, RNAscope, registration or custom StarDist models. P204's reported AllelicSeries1.1.2 remains missing; candidate0.1.1.2 earns no reported-edition credit. Unknown wesanderson palettes/counts/MFOD1 mapping and separate ImageJ distributions/plugins remain unresolved. Read the retained guides for all earlier limits.

Read [current rstatix commands, unchanged source roles and recovery](../RSTATIX_REVISION2_CATALOG.md). Validate with `python tools/literature/rstatix_revision2_catalog/verify.py --out build/literature-review/monocle-runtime/NEW-rstatix-revision2-catalog-check --rescan-sources`. Full semantic review and implementation remain open.

<details><summary>Retained previous catalog checkpoints (historical)</summary>

# 250-paper omics and GWAS toolbox catalog


## Current ggpubr coverage: warnings and required actions

**Current catalog: 250 papers, 432 named software families, 2,671 observations and 1,156 individually reviewed uses; 1,515 uses await individual review.** All 250 exact primary XMLs were searched for ggpubr: nine paper-family uses and 12 named paragraphs. Eight uses gain source reviews; P040's existing observation and review remain unchanged. P241's Web resources link is not another analysis execution. The fixed cohort remains 71 Nature, 104 Nature Genetics and 75 AJHG papers, 2023-10-23 through 2026-10-23; no time extension was needed. Full semantic review and implementation remain open.

**109 new scoped integrations are available: 20 native Java subsets and 89 upstream workflows; 112 including 3 existing adapters. 264 named families remain missing.** ggpubr gains one upstream family credit for two separate original editions, 0.4.0 and 0.6.0. The Python source entry point runs the complete installed original namespace through the matching private Linux/WSL R 4.3.3 provider, original ggplot2 3.4.3 and original rstatix 0.7.2. It is not a standalone JAR or a new native Java ggpubr implementation. Canonical executable and root dispatch remain unchanged. Read GGPUBR_CATALOG_INTEGRATION.md and GGPUBR_WORKFLOW_DEVELOPMENT.md for exact commands and limits; earlier component guides retain pre-admission snapshots.

**Paper roles, versions and grouping remain literal.** P040/P054 report 0.6.0; P098/P101/P195 report 0.4.0; P058/P087/P231/P241 editions are unreported. Never infer a specific ggpubr function, plot, correction or figure assignment from a generic package list. P098 establishes violin plots; its nearby Wilcoxon statement does not name the implementing package. P101 explicitly assigns tests to base R/agricolae, not automatically to ggpubr. P195's nearby Mann-Whitney test is not specifically assigned to ggpubr. The selected R/dependency profile does not establish historical author-runtime equivalence. Pairing order, variance assumptions, comparison families, directions, label positions and complete scientific populations remain caller decisions. Coloring scatter points alone does not establish a group mapping for stat_cor. No paper reproduction is claimed.

**SKIP3 skips dependent analysis** when required source, runtime, provider, input, literal export/package, permitted download, installation or execution is unavailable/forbidden. Install only where permitted, supply exact prerequisites and retry NEW paths. Use a persistent permitted Linux/WSL installation directory; temporary providers can disappear between invocations. Windows original execution skips. Select the literal edition and matching provider; unsupported request editions and provider contradictions refuse admission. A READY provider is not an analysis result. Trusted R scripts require explicit ALLOW execution/trusted-code policies and run with account permissions, not an OS sandbox or total CPU/RSS containment guarantee. Owned-group supervision excludes child-created separate sessions. Cell Ranger and Cell Ranger ARC remain excluded by user request.

**FAIL2 admits no complete result.** Preserve exact inputs, every complete/partial output, full original plot/built/grob objects, all layer rows/columns, tables, conditions/errors/warnings, logs, manifest and status. Correct the named cause and retry NEW paths. Original ggplot Computation failed in warnings refuse admission even when direct R renders files and exits zero. Silent empty layers still require caller eligibility and expected-row checks; do not invent a correlation or p-value. Ordinary warnings remain visible and require review; original warn=2 still fails. Unknown condition totals from interrupted or truncated worker diagnostics are unavailable, not zero; retain the raw record and recovery report. Missing/extra/truncated files, early quit, changed inputs, symlinks and capacity violations refuse admission. Do not drop failed cases, repair source algorithms or label partial populations complete. File/marker checks do not independently prove arbitrary R-code or biological validity.

**Qualification retains full original evidence.** Each edition matched 79 direct-original cases: 54 plots, 25 tables, 416 table cells, 171,084 layer cells and all 134 SVG/PNG/TSV files, with 294 complete result files. All 72 Linux workflow controls, 2 Windows skips, 16 Linux setup refusals, 2 Windows setup skips, two complete public examples and four frozen-verifier refusal tests are retained. Full original RDS objects and construction PDFs remain available; opaque environment-pointer/RDS-byte parity and PDF clock-metadata parity are not claimed. Exact negative-test ZIP bytes are retained losslessly using the unchanged base archive plus deltas. Hashes establish integrity, not authenticity or whole-paper validity. This catalog gate executes no new original analysis or installation.

**Other retained restrictions still apply.** rstatix 0.7.2 uses a separate Linux/WSL R 4.5.3 profile; P054's literal wilcoxon_test is not silently repaired to wilcox_test, and native one-way Levene does not supply the full R workflow. QuPath 0.5.1 H-DAB controls do not independently qualify other editions, fluorescence/proximity, RNAscope, registration or custom StarDist models. P204's reported AllelicSeries 1.1.2 remains unresolved; candidate 0.1.1.2 earns no paper-edition credit. P054's wesanderson palette/count/MFOD1 mapping remain unknown. ImageJ plugins/distributions remain separate, and histogram matching is not an intensity-quantification method. Consult retained tool guides for all earlier limitations.

Read [ggpubr source roles, original workflow commands and recovery](../GGPUBR_CATALOG_INTEGRATION.md). Validate with `python tools/literature/ggpubr_catalog/verify.py --out build/literature-review/monocle-runtime/NEW-ggpubr-catalog-check --rescan-sources`. The full semantic review and implementation objective remain open.

<details><summary>Retained previous catalog checkpoints (historical)</summary>

# 250-paper omics and GWAS toolbox catalog


## Current rstatix coverage: warnings and required actions

**Current catalog: 250 papers, 432 named software families, 2,671 observations and 1,148 individually reviewed uses; 1,523 uses await individual review.** All 250 exact primary XMLs were searched for rstatix: six paper-family uses and 12 named paragraphs. Five uses gain source reviews; P040's existing observation and review remain unchanged. P241's Web resources link is not another analysis execution. The fixed cohort remains 71 Nature, 104 Nature Genetics and 75 AJHG papers, 2023-10-23 through 2026-10-23; no time extension was needed. The full semantic review and implementation objective remain open.

**108 new scoped integrations are available: 20 native Java subsets and 88 upstream workflows; 111 including 3 existing adapters. 265 named families remain missing.** rstatix gains one upstream workflow credit. Its explicit Python source entry point executes the complete unchanged original rstatix 0.7.2 namespace through a permitted private Linux/WSL R 4.5.3 provider and trusted caller R script. It is not a standalone JAR. The separate native Java one-way Levene API/executable requires no R; it does not supply the other rstatix functions or earn a second family credit. Canonical executable and root dispatch remain unchanged. Read RSTATIX_CATALOG_INTEGRATION.md and RSTATIX072_WORKFLOW_DEVELOPMENT.md for commands, source roles and recovery. Earlier component guides retain their pre-admission snapshots.

**Original-runtime and paper settings remain explicit.** Five papers report rstatix 0.7.2; P241's edition/test/design are unreported. Selected R 4.5.3/car 3.1-5 does not prove equivalence to historical author runtimes, including P054's R 4.2.3 to 4.4.0. P054 literally prints wilcoxon_test; original 0.7.2 exports wilcox_test. Missing literal exports skip dependent analysis; no spelling repair is inferred. Unknown correction families, variance assumptions, pairing order, comparison groups, one-sided direction and group-versus-all dependence must be supplied or resolved. P032's test/correction method is unknown. Original p-value rounding, adjustment, conditions and full RDS objects are preserved; generic native tests are not substituted. Native Levene only covers prepared one-way mean/median-centered vectors, not arbitrary R formulas, grouped operations or custom center functions. No paper is reproduced by this admission.

**SKIP3 skips dependent analysis** when required source, Java/R runtime, provider, input, download, installation, literal export/package or execution is missing/forbidden. Install only where permitted, supply the named prerequisite and retry NEW paths. A READY provider or source entry point is not an analysis result. The original workflow requires explicit ALLOW execution/trusted-code policies. Trusted R scripts run with account permissions, not an OS sandbox or total CPU/RSS containment guarantee; same-group worker supervision does not cover child-created separate sessions. Windows original execution skips; use the qualified Linux/WSL provider. Cell Ranger and Cell Ranger ARC remain excluded by user request.

**FAIL2 admits no complete result.** Retain exact inputs, every complete/partial result, original R object/error/warning, full logs, conditions, manifest and status; correct the named cause and retry NEW paths. Review every original warning in WARNINGS.md, diagnostics/conditions.json, full condition RDS and process logs. Warnings are not muffled; warn=2 still fails. Exit zero after early quit, missing/extra/truncated results, input changes, symlinks and capacity violations refuse admission. Do not drop failed cases or label partial populations complete. Scripts must propagate scientific failures and check their own objects before declaring completion; file/marker checks cannot infer validity of arbitrary R objects, nonfinite values or designs. Native Levene refuses unresolved deviation variance, while retaining the original near-perfect-fit warning and huge statistic in control evidence. Hashes establish integrity, not authenticity, historical runtime equivalence or biological validity. This catalog audit executes no new original analysis or installation.

**Other retained limitations still apply.** QuPath 0.5.1 H-DAB controls do not independently qualify fluorescence/proximity, RNAscope, registration, other editions or custom StarDist models. P204's reported AllelicSeries 1.1.2 remains missing; candidate 0.1.1.2 earns zero credit, and native burden components do not supply full COAST/SKAT-O or binary/discrete calibration. P054's wesanderson palette/count/MFOD1 mapping remain unknown; viridisLite/R graphics are separate. ImageJ distributions/plugins are separate, and histogram matching must not be used for intensity quantification. Consult retained checkpoint guides for earlier tool-specific restrictions.

Read [rstatix source roles, original/native commands and recovery](../RSTATIX_CATALOG_INTEGRATION.md). Validate with `python tools/literature/rstatix_catalog/verify.py --out build/literature-review/monocle-runtime/NEW-rstatix-catalog-check --rescan-sources`. The full semantic review and implementation objective remain open.

<details><summary>Retained previous catalog checkpoints (historical)</summary>

# 250-paper omics and GWAS toolbox catalog


## Current QuPath coverage: warnings and required actions

**Current catalog: 250 papers, 432 named software families, 2,671 observations and 1,143 individually reviewed uses; 1,528 uses await individual review.** All 250 exact primary XMLs were searched for QuPath: 12 paper-family uses and 16 named paragraphs. Eleven uses gain source reviews; P040's existing review is preserved unchanged. An acknowledgement and a downstream output-table paragraph do not establish additional image-analysis executions. The fixed cohort remains 71 Nature, 104 Nature Genetics and 75 AJHG papers, 2023-10-23 through 2026-10-23; no time extension was needed. The full semantic review and implementation objective remain open.

**107 new scoped integrations are available: 20 native Java subsets and 87 upstream workflows; 110 including 3 existing adapters. 266 named families remain missing.** QuPath gains one upstream workflow credit. The explicit standalone Java controller invokes the complete unchanged original QuPath 0.5.1 headless Groovy engine and its embedded Java 21.0.2. It needs a permitted private Windows/Linux x86_64 original provider, a trusted caller script and complete declared inputs/outputs. The canonical executable and root dispatch are unchanged. Read QUPATH_CATALOG_INTEGRATION.md and QUPATH051_WORKFLOW_DEVELOPMENT.md for copyable setup, execution and recovery commands.

**P009 and P040 report QuPath 0.5.1; other reported editions remain separate.** P020 reports 0.6.0, P049 0.4.3, P058 0.4.1 and P158 literally v.0.2.3 to v.0.4.3. Six other papers do not report an edition. Do not substitute 0.5.1 silently. The scientific controls cover six synthetic H-DAB jobs, 72 detections and all 13 complete portable exports per controller on Windows Java 21/25 and Linux Java 21. They do not independently qualify fluorescence/proximity, RNAscope puncta, image registration, custom classifiers or author pipelines. P158's custom StarDist extension/model is not supplied by the stock provider. P040's numeric stain vectors and author ROIs remain unknown, and its printed area-unit wording is retained. No paper is reproduced by this admission; no native segmentation port or whole-tool qualification is claimed.

**SKIP3 skips dependent analysis** when required downloads, installation, original runtime, source, provider, extension/model, display or execution are missing/forbidden. Install only where permitted; supply the named prerequisites, verify the complete native-platform provider and retry NEW paths. A READY setup record is not an analysis result. Source-only checkouts and controller JARs do not contain the original runtime/JRE. Groovy runs with account permissions and requires explicit trusted-code and execution policies. Cell Ranger and Cell Ranger ARC remain excluded by user request.

**FAIL2 admits no complete result.** Retain every input, full image/hierarchy/table, original returned object, condition, status, process log and failed case; resolve the stated cause and retry NEW paths. Review every original warning using WARNINGS.md, ORIGINAL_CONDITIONS.tsv and full logs. The controller requires original exit zero, no selected-format ERROR headers, exactly one completion marker and the entire declared result population. Do not admit partial outputs, drop blank/failed images or relabel a zero-exit logged error successful. Hashes establish integrity, not authenticity, independent statistical validity or biological correctness. This catalog audit executes no new original analysis or installation.

**Other retained limits still apply.** P204's reported AllelicSeries 1.1.2 remains missing; the separate 0.1.1.2 candidate earns zero credit, and selected native burden components do not supply full COAST/SKAT-O or binary/discrete calibration. P054's wesanderson palette/count/MFOD1 mapping remain unknown; viridisLite and R graphics remain separate. ImageJ distributions/plugins are separate, and histogram matching must not be used for intensity quantification. Consult the retained checkpoint guides for all earlier tool-specific restrictions.

Read [QuPath source roles, commands and recovery](../QUPATH_CATALOG_INTEGRATION.md). Validate with `python tools/literature/qupath_catalog/verify.py --out build/literature-review/monocle-runtime/NEW-qupath-catalog-check --rescan-sources`. The full semantic review and implementation objective remain open.

<details><summary>Retained previous catalog checkpoints (historical)</summary>

# 250-paper omics and GWAS toolbox catalog


## Current palette and allelic-series coverage: warnings and required actions

**Current catalog: 250 papers, 432 named software families, 2,671 observations and 1,132 individually reviewed uses.** Two newly recorded paper-family uses cover all 27 named primary paragraphs in the exact 250-source census. All 430 previous families, 2,669 observations and 1,130 reviews remain unchanged. The fixed cohort is 71 Nature, 104 Nature Genetics and 75 AJHG papers, 2023-10-23 through 2026-10-23; no time extension was needed. The full semantic review and implementation objective remain open.

**106 new scoped integrations are available: 20 native Java subsets and 86 upstream workflows; 109 including 3 existing adapters. 267 named families remain missing.** Only wesanderson gains new implementation credit here. Its native scalar 0.3.7 palette engine and explicit standalone executable have complete original controls. The separate original R provider needs its documented permitted R 4.5.3 runtime. The canonical executable and root dispatch are unchanged. Component guides retain their pre-admission qualification snapshots; this catalog records the later admission.

**P054 reports wesanderson 0.3.7 for MFOD1 ontology colors, but no palette, color count, category mapping or discrete/continuous call.** Do not infer these choices. The paper's R 4.2.3 to R 4.4.0 differs from the original reference R 4.5.3. Native scalar colors do not supply R graphics or general R-language coercion. The separately named viridisLite 0.4.2 gradients are not covered by this admission. Read WESANDERSON037_WORKFLOW_DEVELOPMENT.md and PALETTE_ALLELIC_CATALOG.md for exact operations and explicit commands.

**P204 reports AllelicSeries 1.1.2; the separately tested 0.1.1.2 candidate is not proven equivalent. The reported edition remains missing and earns zero credit.** The candidate runs unchanged original R exports, including full COAST/COASTSS/SKAT-O, in single-call or batch workflows. Native Java supplies selected summary burden components, not full COAST/SKAT-O. Quantitative-trait derivation does not establish binary/discrete calibration or ancestry robustness. Supplied effects/SEs, MAF, LD and annotations must already align; no author preprocessing, missing-LD assumption, 20K-gene timing or paper reproduction is inferred. Read ALLELICSERIES0112_BATCH.md and its provider instructions; explicitly choose this candidate only when appropriate.

**SKIP3 skips dependent analysis** when required downloads, installation, source, compiler, runtime, provider, display or execution are missing/forbidden. Supply only permitted prerequisites using the linked guides and retry NEW paths. Native palette generation needs Java, not R. Original AllelicSeries execution needs the ready private Linux/WSL R 4.5.3 provider. Cell Ranger and Cell Ranger ARC remain excluded by user request.

**FAIL2 admits no complete result.** Retain inputs, original returned objects/errors, all conditions, complete indexes, status and warnings; resolve the named cause and retry NEW paths. Review every original warning and justify or correct the input/model choice. A low-level scalar zero returned before association computation, an ambiguous zero, an original error or a nonfinite return is retained but unadmitted. A genuinely computed probability zero with explicit positive SEs is preserved. Failed batches retain successful entries but admit no complete batch. Do not remove failed genes or relabel a partial batch as complete. ImageJ distributions/plugins remain separate; histogram matching must not be used for intensity quantification. Hashes establish integrity, not producer authentication or biological correctness. This catalog audit executes no new original analysis or installation.

Read [current source roles, executable commands and recovery](../PALETTE_ALLELIC_CATALOG.md). Validate with `python tools/literature/palette_allelic_catalog/verify.py --out build/literature-review/monocle-runtime/NEW-palette-allelic-check`; `--rescan-sources` checks all250 exact cached primary XMLs. Full semantic review and implementation remain open.

<details><summary>Retained previous catalog checkpoints (historical)</summary>

# 250-paper omics and GWAS toolbox catalog


## Current image-analysis coverage and required actions

**Current catalog: 250 papers, 430 named software families, 2,669 observations and 1,130 individually reviewed uses.** Fifty additional ImageJ uses and one newly recorded Bleach Corrector use have individual primary-source reviews. The previous P040 ImageJ review and all 1,079 previous reviews remain unchanged. Fifty earlier extraction records are enriched with their complete original records retained as history; the other 2,618 observations are unchanged. The full semantic review remains open.

**105 new scoped integrations are available: 19 native Java subsets and 86 upstream workflows; 108 including 3 existing adapters. 266 named families remain missing.** The two new admissions are complete original ImageJ 1.54t core and selected original CorrectBleach 2.1.0/ImageJ 1.53t. A separate native Java histogram engine is part of the CorrectBleach admission, not a second tool credit. These are standalone development workflows; the canonical executable is unchanged. A broader plugin/software name census is still under individual review and is not included in these totals.

**ImageJ 1.54t does not supply Fiji distributions, ImageJ2, external plugins or paper-specific custom scripts.** P040 reports the selected core edition; other reported editions and ambiguous literals remain explicit. Fifty-one reviewed family uses are not 51 reproduced workflows. TrakEM2, Cell Counter, StarDist, Fast4DReg and other named components need distinct qualification. The original component guides retain their pre-admission qualification snapshots; this catalog states current admission.

**Histogram matching must not be used for intensity quantification.** P026 reports XY drift correction followed by Bleach Corrector, but no plugin edition, correction method, baseline or fit settings. The explicit 2.1.0 workflow offers original simple ratio, exponential-with-offset fitting and histogram matching; no method is inferred. Failed/nonfinite original corrections remain unadmitted. Two-point optimizer success is preserved without claiming model adequacy.

**SKIP3 skips dependent analysis** when the permitted exact runtime, display, provider, source, plugin, download, installation or execution is absent/forbidden. Supply documented prerequisites only where permitted and retry NEW paths. ImageJ core macros require full AWT and a working display; the selected CorrectBleach API workflow was tested headlessly. **FAIL2 admits no result:** retain complete inputs/images/models, WARNINGS.md, status and original process logs, resolve the stated cause and retry NEW paths. Cell Ranger remains excluded. Source hashes establish integrity, not producer authentication or biological correctness. No original image analysis or installation occurs during this catalog audit.

Read [current ImageJ/CorrectBleach roles and recovery](../IMAGEJ_CATALOG_INTEGRATION.md). The fixed cohort is 71 Nature, 104 Nature Genetics and 75 AJHG papers, 2023-10-23 through 2026-10-23; no extension was needed. Validate with `python tools/literature/imagej_catalog/verify.py --out build/literature-review/monocle-runtime/NEW-imagej-check`; `--rescan-sources` reads all 250 exact cached primary XML sources. Full semantic review and the original implementation goal remain open.

<details><summary>Retained previous catalog checkpoints (historical)</summary>

# 250-paper omics and GWAS toolbox catalog

**Current checkpoint: 429 named software families,2,668 observations,1,079 reviewed uses.** The fixed 250-paper cohort contains 71 Nature, 104 Nature Genetics and 75 AJHG papers from 2023-10-23 through 2026-10-23; no time extension was needed. P040's Methods review identified 22 omitted names; a full 250-source census adds 186 paper-tool observations. Twenty-two P040 uses and two P082 author-inventory statements have individual reviews;162 other new summaries require individual review. Every prior 2,482 observation and 1,055 review is unchanged. The full semantic review remains open.

**103 new scoped integrations remain available:** 19 native Java subsets and 84 tested upstream adapters; 106 including 3 existing adapters. **267 named tools remain missing**, including the 22 newly recognized names. No badge is awarded by a name census or source review. Cell Ranger remains excluded at the user's request.

**Rphenograph 0.99.1 is separately available as a tested development candidate.** It includes complete original RANN/Jaccard/Louvain execution and native Java coefficients, complete model retention and prominent diagnostics. The paper reports0.1.1; that identity remains unresolved and missing. No automatic edition substitution, paper reproduction or manual annotation is claimed. Read [P040_SOFTWARE_REVIEW.md](../P040_SOFTWARE_REVIEW.md) for current source roles and candidate status. Component qualification guides and previous catalog checkpoints are retained versioned snapshots; current totals are stated on this page.

**SKIP3 skips only dependent analyses** if a required permitted runtime, license, download, installation or execution is unavailable or forbidden. Supply the documented exact provider on a permitted host. **FAIL2 admits no result:** retain complete inputs, WARNINGS.md, status, logs and unadmitted models; correct the named cause and retry NEW output. Acquisition-software roles require the corresponding instrument/vendor runtime; separately qualified downstream tools can use supplied data. No original analysis or software installation occurs during this catalog audit.

Current records: [inventory](tool-inventory.json), [papers](papers.json), [summary](summary.json), [warnings](WARNINGS.md). Validate with `python tools/literature/p040_catalog/verify.py --out build/literature-review/monocle-runtime/NEW-p040-check`; add `--rescan-sources` to read all 250 exact cached XML sources. Historical generators must not overwrite this cumulative catalog. The full 250-paper implementation objective remains active.

<details>
<summary>Retained previous catalog checkpoints (historical)</summary>

# 250 paper omics and GWAS toolbox catalog

**Current checkpoint: 103 new scoped integrations**: 19 native Java subsets and 84 tested upstream adapters; 106 including 3 existing adapters. **245 named tools remain missing.** Cell Ranger remains excluded at the user's request. The full goal is active.

**Batchelor / FastMNN now has two qualified selected workflows.** P040 has original 1.29.0 fastMNN on complete prepared protein/log-expression data, with native Java factor/reconstruction checks. P051 retains the selected Monocle 1.3.7/Batchelor 1.20 reducedMNN integration. Read [BATCHELOR129_INTEGRATION.md](../BATCHELOR129_INTEGRATION.md) and [the FastMNN workflow guide](../FASTMNN129_WORKFLOW_DEVELOPMENT.md) for exact source candidates, setup, explicit method choices and limitations. The paper patches/calls/settings remain unknown; this is one scoped upstream admission, not whole-package or paper reproduction.

**Rphenograph is newly recorded and remains missing.** P040 reports 0.1.1 with k = 40 after correction; all four inspected official source commits report 0.99.1. Preserve the reported literal and discrepancy. No Rphenograph code was executed or qualified. Adding this missing tool offsets the Batchelor admission, so missing stays 245. Current use records retain every previous 2481 observation and 1054 review unchanged, then append one Rphenograph observation/review.

The fixed cohort contains **250 papers**: 71 Nature, 104 Nature Genetics and 75 AJHG articles from **2023-10-23 through 2026-10-23**. No time extension was needed. There are **407 named tools, 2,482 paper-tool observations and 1,055 reviewed uses**, with 378 main-article supporting pointers, four supplementary supporting pointers and one separately typed supplementary primary observation. Paper-wide semantic completeness is unproven.

**SKIP3 — skip dependent analysis if the exact permitted runtime, download, installation or execution cannot be supplied.** Setup and analysis are separate; use the documented helper only where allowed. Analysis installs nothing. Windows supports saved-result audits; original analysis requires permitted Linux/WSL and Linux paths.

**FAIL2 — no result is admitted on input, source, numeric, timeout, capacity or process failure.** Keep complete inputs, status, WARNINGS.md, original logs and any unadmitted RDS. Correct the named cause and retry a NEW output. Original unnamed-weight errors are preserved; a named batch_weights dictionary is an explicit different request. FACTORS checks all lazy model factors and zero reconstructed entries; ALL_VALUES additionally checks the full streamed reconstruction. Hashes establish integrity, not producer authentication.

Current records: [inventory](tool-inventory.json),[papers](papers.json),[summary](summary.json),[warnings](WARNINGS.md),[current selected Batchelor coverage](batchelor129-role-coverage.json). Verify this amendment with `python tools/literature/batchelor129_catalog/verify.py --out build/literature-review/monocle-runtime/NEW-catalog-check`; add `--rescan-sources` to read all 250 exact cached XML sources. The generic historical generators below do not reproduce this cumulative admission and must not overwrite the current catalog.

<details>
<summary>Retained prior catalog checkpoints and notices (historical)</summary>

# 250 paper omics and GWAS toolbox catalog

**Current checkpoint: 102 new scoped integrations**: 19 native Java
subsets and 83 tested upstream adapters; 105 including
3 existing adapters. **245 named tools remain missing.**
Cell Ranger remains excluded at the user's request. The full goal is active.

**Batchelor / FastMNN: two omitted roles are now catalogued.** P051 has a
tested selected Batchelor1.20 reducedMNN integration through Monocle1.3.7.
P040 FastMNN on imaging-protein data remains missing, so no new integration
badge is awarded. Read [BATCHELOR_INTEGRATION.md](../BATCHELOR_INTEGRATION.md)
for the precise distinction, setup, warnings and recovery actions. All2,479
prior observations and1,052 prior reviews remain unchanged.

**MALT complete DNA index building and original0.5.2 BlastN screening are now
available** through an owned standalone workflow with an explicit native
accession-mapping alternative and complete index handoff checks. Read
[MALT052_INTEGRATION.md](../MALT052_INTEGRATION.md) for exact prerequisites,
method choices and prominent SKIP3/FAIL2 recovery. The main pipeline version
and historical reference/query populations are not recovered. Historical
source-component notices remain retained; no whole-tool or biological credit.

**HOPS original extraction and candidate assessment are now available** through
a scoped standalone me_po workflow with explicit stock/complete profiles. Read
[HOPS_INTEGRATION.md](../HOPS_INTEGRATION.md) for setup, method choices and
prominent SKIP3/FAIL2 recovery. Historical source-only notices remain retained;
the badge does not automate biological authentication, recover author settings
or qualify MALT alignment/index creation or the historical databases.

**MaltExtract target extraction and original summary/damage output are now available**
through a scoped original1.7 standalone workflow. Read
[MALTEXTRACT_INTEGRATION.md](../MALTEXTRACT_INTEGRATION.md). The authors'
version/settings/resources remain unknown; manual assessment and the separate
bacterial rescreen remain separate operations. Canonical/released executables
are unchanged. Earlier MALT-family source-only notices below are historical;
this scoped badge does not qualify the whole package, MALT or HOPS.

The fixed cohort contains 250 papers: 71 Nature, 104 Nature Genetics and 75
AJHG articles from 2023-10-23 through 2026-10-23. No extension was needed.
There are **406 named tools, 2,481 paper-tool observations and 1,054 reviewed
uses**, with 378 main-article supporting pointers, four supplementary supporting
pointers and one separately typed supplementary primary observation.

The three MALT-family additions retain all 2,476 prior observations and all
1,049 prior reviews. MALT and HOPS have main-article anchors; MaltExtract's
source is the P002 supplementary DOCX. Its Word paragraph index 246 is
zero-based and includes empty paragraphs. It is not a main-JATS pointer.
The custom MALT version is 0.5.2 followed by superscript citation 61.

These additions grant no new whole-tool or biological credit. Read
[MALT alignment](../MALT_ALIGNMENT.md) and
[distinct MALT/HOPS/MaltExtract roles](../MALT_HOPS_PAPER_ROLES.md).
The 0.4.1 controller and native components do not fulfill the separate 0.5.2
custom database-building/screening role. Full HOPS and MaltExtract operations
remain unfinished. Unreported versions, resources and settings remain unknown.

[scDRS](../SCDRS_INTEGRATION.md), [MTAG](../MTAG_INTEGRATION.md),
[GENESIS](../GENESIS_INTEGRATION.md) and [SNPRelate](../SNPRELATE_INTEGRATION.md)
retain their separately validated workflows and source-specific boundaries.
Coverage badges describe scoped integrations, not complete package, historical
environment, full-paper or biological reproduction.

**Warnings and required actions:** install or download only where permitted.
If an exact dependency cannot be supplied or installed, keep its dependent
analysis skipped with SKIP3. FAIL2 admits no result; retain complete inputs,
partial outputs, original logs and warnings, resolve the named cause, and retry
a NEW output directory. Do not repair identifiers, nonfinite values, clips or
settings to conceal a failure. Hashes establish integrity, not authorship;
saved replay does not independently refit or authenticate a producer.

Current records: [inventory](tool-inventory.json), [papers](papers.json),
[summary](summary.json), [warnings](WARNINGS.md), and
[typed MALT source coverage](malt-source-role-coverage.json).

<details>
<summary>Generated catalog reference and retained historical checkpoints</summary>

# 250 paper omics and GWAS toolbox catalog

**Current checkpoint: 95 new scoped integrations**: 19 native Java methods and
76 tested upstream adapters. There are **98 including three existing adapters**,
with **246 named tools still missing**. Cell Ranger remains excluded at the
user's request. The full toolbox goal remains active.

The fixed collection contains 250 papers: 71 Nature, 104 Nature Genetics and
75 AJHG articles from 2023-10-23 through 2026-10-23. No time extension was needed.
There are 400 observed tools from 438 definitions, 2,466 paper-tool observations,
1,029 source-bound reviewed roles and 367 supporting pointers. Paper-wide
semantic review and implementation remain incomplete.

Read [DIAMOND integration](../DIAMOND_INTEGRATION.md) for the self-contained Java
command, `diamond-tools` root route, explicit Linux source/runtime setup and
complete requests. Five reviewed roles add one scoped upstream adapter while
preserving all 1,024 prior reviews and 399 unrelated tool entries. Original
2.0.0/2.0.15/2.1.8 alignment controls cover 78 source cases: 72 successful
comparisons and six preserved original failures. Complete saved-bundle checks
and native audits do not independently refit alignments or reproduce papers.

**Warnings and required actions:** SKIP3 means skip the dependent analysis until
the exact permitted prerequisite is available. Download/install only where
allowed; if unavailable or forbidden, keep the analysis skipped. FAIL2 admits
no result, including earlier successful steps: preserve the attempt, inspect
the named cause and original logs, correct it explicitly and retry new paths.
Analysis installs nothing. Require exit 0, result_admitted=true and successful
complete verification, then read every warning and original output.

DIAMOND source crashes, tested paired-FASTQ failures, cutoff precedence,
rounded/zero E-values and duplicate-ID ambiguity remain visible. P017 has no
reported version and uses different or unspecified coverage denominators.
P054's score100 does not resolve raw versus bit score or an external filter:
require that exact study interpretation before claiming the cutoff. Downstream
classification, abundance, DBSCAN/KDE, GraftM and mSynOrths remain separate.
Existing CellChat warnings and its unresolved P060 custom-score analysis remain
in force; Spyrrow remains missing.

Current records: [tool inventory](tool-inventory.json), [papers](papers.json),
[summary](summary.json), [warnings and required actions](WARNINGS.md),
[DIAMOND source-role coverage](diamond-role-coverage.json) and
[validation checkpoint](diamond-catalog-validation.json).

The generated reference and earlier checkpoints below are retained exactly.
Their historical counts describe those checkpoints; current records above
describe this checkpoint.

<details>
<summary>Generated catalog reference and retained historical checkpoints</summary>

# 250 paper omics and GWAS toolbox catalog

**Current checkpoint: 94 new scoped integrations**: 19 native Java methods and
75 tested upstream adapters. There are **97 including three existing adapters**,
with **247 named tools still missing**. Cell Ranger remains excluded at the
user's request. The full toolbox goal remains active.

The fixed cohort contains 250 papers: 71 Nature, 104 Nature Genetics and 75 AJHG
articles from 2023-10-23 through 2026-10-23. No time extension was needed.
There are 400 observed tools from 438 definitions, 2,466 paper-tool observations,
1,024 source-bound reviewed roles and 357 supporting pointers. Paper-wide
semantic review and implementation remain incomplete.

Read [CellChat integration](../CELLCHAT_INTEGRATION.md) for the `cellchat-tools`
root command, self-contained standalone alternatives, explicit original source
profiles, database exports and required actions. Six reviewed paper roles
distinguish resource use, original inference, network embedding/comparison and
sample-aware strengths. This adds one tested scoped adapter. All 1,018 previous
reviews and the 399 unrelated tool entries remain unchanged.

**Warnings and required actions:** SKIP3 means skip dependent analysis until the
exact permitted prerequisite is available; if installation is unavailable or
forbidden, keep it skipped. FAIL2 admits no new result: preserve the attempt,
fix the named cause and retry new paths. Analysis installs nothing. Require
exit 0, result_admitted=true and successful complete verification; read every
warning, original output, provenance and captured parent warning.

Original CellChat invalid p-fields, fallback zeros, FNN/SNN anomalies,
missing/nonfinite strengths, parallel RNG warnings and UMAP variability remain
visible. They are not repaired or made valid by transport success. P060's custom
score aggregation remains unresolved: skip that study-score analysis until the
exact implementation is supplied. CellChat database export remains available.
Spyrrow, CellTrek, LIANA and FlowSig are separate tool roles; Spyrrow remains
missing in the catalog. Historical paper reproduction is not claimed.

Current records: [tool inventory](tool-inventory.json), [papers](papers.json),
[summary](summary.json), [warnings and required actions](WARNINGS.md) and
[CellChat source-role coverage](cellchat-role-coverage.json).

The generated reference and earlier checkpoints below are retained exactly.
Individual historical notes retain their own counts and availability limits;
the current records above are authoritative for this checkpoint.

<details>
<summary>Generated catalog reference and retained historical checkpoints</summary>

# 250 paper omics and GWAS toolbox catalog

**Current checkpoint: 93 new scoped integrations** — 19 native Java methods and
74 tested upstream adapters. There are **96 including three existing adapters**,
with **248 named tools still missing**. These are scoped implementations with
explicit limits. Cell Ranger remains excluded at the user's request.

The unchanged fixed cohort contains 250 papers: 71 Nature, 104 Nature Genetics and
75 AJHG articles from 2023-10-23 through 2026-10-23. No time extension was needed.
The catalog contains 400 observed tools from 438 definitions, 2,466 paper–tool
observations, 1,018 reviewed roles and 356 supporting pointers.

Read [cisTarget integration](../CISTARGET_INTEGRATION.md) for the native
`cistarget-tools` command, explicit numerical profiles, complete ranked-feature
inputs, optional Feather conversion and required warning/failure actions.
The seven source roles distinguish algorithm execution, SCENIC/SCENIC+ inputs and
motif-collection use. P145 adds one missed “cis-target” Methods resource
observation. P061 has one explicit review enrichment, with its prior text
retained. All 1,011 other prior reviews and every unrelated observation remain
unchanged. The 399 unrelated tool entries also remain unchanged.

Current records: [tool inventory](tool-inventory.json), [papers](papers.json),
[summary](summary.json), [warnings and required actions](WARNINGS.md), and
[cisTarget source-role coverage](cistarget-role-coverage.json).

Native TSV analysis installs nothing. Optional Feather conversion requires a
permitted private PyArrow 17.0.0 runtime: SKIP3 means skip the conversion and its
dependent analysis until that prerequisite is available. FAIL2 admits no result;
preserve partials, correct the named problem and retry new paths. Read every
warning and disposition, especially undefined or rounding-only NES values.

The full 250-paper implementation and paper-wide semantic review remain open.
The material below is retained historical checkpoint documentation; its opening
counts and availability statements describe that earlier checkpoint.

<details>
<summary>Historical MR-MEGA checkpoint and retained catalog material</summary>

# 250-paper omics/GWAS toolbox catalog

**Current checkpoint: 92 new integrations**: 18 native Java methods and 74 tested
upstream adapters. There are **95 including three existing adapters**, with
**249 named tools still missing**. These are scoped implementations, not whole
packages or whole-paper reproductions. Cell Ranger remains excluded by the user.

The unchanged fixed cohort contains 250 papers: Nature71, Nature Genetics104 and
AJHG75, published from2023-10-23 through2026-10-23. No time extension was needed.
There are400 observed tools from438 definitions,2465 observations,1,012 reviewed
roles and355 supporting pointers. This checkpoint adds three primary MR-MEGA
reviews and one native availability row. All1,009 earlier reviews,399 other
inventory rows, paper identities and observed memberships remain exact.

Read [MR-MEGA integration](../MRMEGA_INTEGRATION.md) for the mrmega-tools project
command, settings, native float32/ancestry/GC behavior and tested root supplement.
Native user analysis needs no original MR-MEGA, compiler, R or installation.
The canonical executable is unchanged. Two errors in unpublished review drafts
were corrected against retained primary XML: P072 requires at least six of seven
cohorts; P162 reports six significant index variants. The incorrect drafts remain
frozen as history and were never applied to the catalog.

**Require exit0, run.json PASS_NATIVE_MRMEGA_WITH_WARNINGS and an admitted
results.tsv. Read [WARNINGS.md](WARNINGS.md) and every row/variant disposition.**
FAIL2 admits no result table; partials stay under partial/. Correct the named
cause and retry NEW paths. SmallCohortCount rows retain NA tests. Source odd
lambda medians, duplicate/N behavior, no_alleles sign flips and float32 boundaries
are explicit. Native stable P fields never overwrite original approximation
fields. Original-reference prerequisites are separate: if installation/execution
is forbidden or unavailable, skip dependent reference work with named recovery.

The broader250-paper goal remains active. Frozen verification checks integrity
and stored relationships, not fresh scientific execution, independent user-data
refitting, authenticity or whole-paper reproduction. The preceding guide follows
verbatim as history; its counts and badges describe earlier checkpoints.

<details>
<summary>Historical prior catalog document, retained verbatim</summary>

# 250-paper omics/GWAS toolbox catalog

**Current checkpoint: 91 new integrations**: 17 native Java subsets and 74 tested
upstream adapters. There are **94 including three existing adapters**, with
**250 named tools still missing**. These are scoped workflows, not complete
packages or whole-paper reproduction. Cell Ranger remains excluded.

The fixed cohort contains 250 papers: Nature 71, Nature Genetics 104 and AJHG 75,
published from 2023-10-23 through 2026-10-23. No time extension was needed.
There are 400 observed tools from 438 definitions, 2,465 paper/tool observations,
1,009 reviewed roles and 353 supporting pointers. This checkpoint adds six
primary Sniffles reviews and one availability row. All 1,003 earlier reviews,
399 other inventory rows, paper identities and observed memberships remain exact.

Read [Sniffles workflows](../SNIFFLES_WORKFLOWS.md) for the standalone Java
entry points, exact original editions, permitted private installation and a
complete toy CRAM/reference example. Original calling remains upstream. The
canonical executable is unchanged.

**Require exit 0 AND root COMPLETED.json analysis_admitted=true for the whole
batch.** Read [WARNINGS.md](WARNINGS.md), complete original logs/VCFs and process
receipts. **SKIP3 skips dependent calling** when exact permitted software is
unavailable or execution/installation is forbidden. **FAIL2 admits no case,
including earlier complete cases.** Preserve failed/provisional output, correct
the named cause and retry NEW paths. Analysis installs nothing.

Legacy event-segment size and modern alignment length are distinct settings.
Retain the original legacy missing-deletion and DUP-to-INV discrepancies; never
relabel calls. A fatal zero-byte VCF is failed output, even with original exit0.
Existing read HP/PS phasing does not perform haplotagging. Unreported paper
commands, Boolean filters and depth fields remain unresolved. Frozen verification
checks integrity/consistency, not fresh calling, independent SV refitting,
authenticity, biological accuracy or whole-paper reproduction.

The preceding guide follows verbatim as history. Its counts and missing badges
describe earlier checkpoints. The broader implementation goal remains active.

<details>
<summary>Historical prior catalog document, retained verbatim</summary>

# 250-paper omics/GWAS toolbox catalog

**Current checkpoint: 90 new integrations**: 17 native Java subsets and 73 tested
upstream adapters. There are **93 including three existing adapters**, with
**251 named tools still missing**. These are scoped workflows, not complete
packages or whole-paper reproduction. Cell Ranger remains excluded.

The fixed cohort contains 250 papers: Nature 71, Nature Genetics 104 and AJHG 75,
published from 2023-10-23 through 2026-10-23. No time extension was needed.
There are 400 observed tools from 438 definitions, 2,465 paper/tool observations,
1,003 reviewed roles and 349 supporting pointers. This update refines three
Rsubread reviews, adds three, and changes one availability row. All 997 other
reviews, 399 other inventory rows, paper identities and observed memberships
remain exact.

Rsubread bulk counting is available through standalone development
`org.jlinalg.cli.RsubreadWorkflowCli`, with `RsubreadRuntimeCli` for binding.
Read [the complete guide](../RSUBREAD_WORKFLOWS.md). Two explicit original Windows
profiles provide Rsubread 2.26.0/R4.6.1 and selected 2.23.2/R4.4.1 counting.
Typed per-library units/strand, exact GTF/SAF inputs and mappings, original RDS
objects and complete native value/relationship checks are retained. Original
read assignment and junction discovery/counting remain upstream. The canonical
executable is unchanged.

**Require exit 0 AND root COMPLETED.json analysis_admitted=true for the entire batch.**
Read [WARNINGS.md](WARNINGS.md), original errors/logs, objects and process receipts.
**SKIP3 skips dependent analysis** when permitted exact software/bindings are
unavailable or execution/installation is forbidden. **FAIL2 admits no case,
including earlier completed cases.** Preserve failed/provisional output, correct
the named cause and retry NEW paths. Original GPL package/source export requires
explicit permission; analysis installs nothing. Linux counting/binding skips,
while frozen native verification is portable.

Declare library units and settings explicitly. Fragment thresholds do not enable
filtering when checkFragLength=false; preserve the P133 ATAC omissions and later
separate sample rename. The 2.23.2 label appears in 22 recovered upstream commits;
the selected source retains development warnings and does not identify the paper
binary. Unreported APIs, editions and annotation/aggregation choices remain
unresolved. Do not replace missing or automatically coerced identifiers.

Both JDK21/25 compiler artifacts independently pass 58 complete separate-original
comparisons: 50 WindowsJVM21 and eight WindowsJVM25 per compiler. Real runtime
skips, late original/native failures, cancellation, timeout/output/interruption,
deeper corruptions and beginner package/data-export/bind/count/verify examples
pass. Four new CLI bytecode differences are recorded, while all 14 prior value
classes and R resources remain unchanged. VERIFY is structural consistency,
not independent refitting, source-input parsing parity or execution authentication.
No independent alignment/junction counting, full-package or paper claim is made.

The complete preceding document follows verbatim as history. Earlier counts and
missing badges describe their checkpoints; use the current inventory and guides.
The broader implementation goal remains active.

<details>
<summary>Historical prior catalog document, retained verbatim</summary>

# 250-paper omics/GWAS toolbox catalog

**Current checkpoint: 89 new integrations**: 17 native Java subsets and 72 tested
upstream adapters. There are **92 including three existing adapters**, with
**252 named tools still missing**. These are scoped workflows, not complete
packages or whole-paper reproduction. Cell Ranger remains excluded.

The fixed cohort contains 250 papers: Nature 71, Nature Genetics 104 and AJHG 75,
published from 2023-10-23 through 2026-10-23. No time extension was needed.
There are 400 observed tools from 438 definitions, 2,465 paper/tool observations,
1,000 reviewed roles and 347 supporting pointers. This update adds seven hifiasm
roles and one availability row. All 993 previous reviews, other 399 inventory
rows, paper identities and observed-tool memberships remain exact.

Hifiasm is available through development `org.jlinalg.cli.HifiasmWorkflowCli`,
with separate `HifiasmSetupCli` and `HifiasmRuntimeCli`. Read
[the complete guide](../HIFIASM.md). Six exact original source profiles provide
the declared HiFi, trio, Hi-C, UL and ONT modes. Native Java inspects all reads,
parental entries, complete graphs and literal FASTA exports. Original correction,
overlap construction, consensus and phasing remain upstream. The canonical
executable is unchanged.

**Require exit 0 AND COMPLETED.json analysis_admitted=true for the entire batch.**
Read [WARNINGS.md](WARNINGS.md), graph audits, original stderr and process receipts.
**SKIP3 skips dependent analysis** when required permitted software or installation
is unavailable. **FAIL2 admits no case, including earlier completed cases.**
Preserve failed/provisional outputs and named causes; correct the problem and
retry NEW paths. Analysis installs nothing.

Old 0.14.2/0.15.1 Hi-C is excluded after retained original crashes. ONT-only
0.22.0 requires genuine FASTQ qualities. Unreported paper settings and revision
suffixes remain unresolved. Small-control defaults need explicit capacity
overrides for real genomes; streaming parental checks do not reduce the
assembler's own memory needs. Graph integrity does not certify consensus,
phasing, completeness or biological quality. Keep scaffolding and QC separate.

The full preceding document follows verbatim as history. Earlier counts and
missing badges describe their checkpoints. Use the current inventory and guides
for availability. The broader implementation goal remains active.

<details>
<summary>Historical prior catalog document, retained verbatim</summary>

# 250-paper omics/GWAS toolbox catalog

**Current checkpoint: 88 new integrations**: 17 native Java subsets and 71 tested
upstream adapters. There are **91 including three existing adapters**, with
**253 named tools still missing**. These counts describe scoped workflows,
not complete packages or whole-paper reproduction. Cell Ranger is excluded.

The catalog retains 250 papers: Nature 71, Nature Genetics 104 and AJHG 75.
Its review window is 2023-10-23 through 2026-10-23; no extension was needed.
There are 400 observed tools from 438 definitions, 2,465 paper/tool observations,
993 reviewed roles and 344 supporting pointers. This update changes only the
GSEApy availability row and six GSEApy paper roles. All other 399 tool rows,
987 reviews, paper identities and observed-tool memberships remain exact.

GSEApy is available through development `org.jlinalg.cli.GseapyWorkflowCli`
and separate `GseapyExecutionSetupCli`. It runs explicit original-class local
Enrichr, prerank, GSEA, ssGSEA and GSVA workflows for four exact editions.
Read [the execution guide](../GSEAPY_EXECUTION.md) and
[current catalog guide](../GSEAPY_CATALOG.md). The canonical executable is unchanged.
Original preprocessing, permutations/RNG and GSVA fitting remain upstream.

**SKIP3 skips dependent analysis** when required software, permitted storage or
installation/download permission is unavailable. **FAIL2 admits no case from
the whole requested batch, including earlier completed cases.** Preserve all
original failures and provisionals, correct the named cause and retry NEW paths.
Require exit 0 AND `analysis-status.json result_admitted=true`. RUN installs nothing.
Read [WARNINGS.md](WARNINGS.md), native audits and original/process logs.

Do not infer historical remote library contents, unspecified GSEA/GSVA modes or
paper settings. P098 reports a two-tailed test; the original local statistics
uses a one-sided upper tail. That discrepancy remains unresolved. Preserve
version-specific curves, SymRank no-op, zero-permutation placeholders and
nonfinite diagnostics. Native normalized-null auditing requires finite sort
inputs; unsupported families fail the whole batch.

The full preceding document follows verbatim as history. Its earlier counts
and missing badges describe those checkpoints. Use the current summary,
inventory and guides for availability. The implementation goal remains active.

<details>
<summary>Historical prior catalog document, retained verbatim</summary>

# 250-paper omics/GWAS toolbox catalog

**Current checkpoint: 87 new integrations** (17 native Java subsets and70 tested
upstream adapters), **90 including three existing adapters**, with **254 named
tools still missing**. These are explicitly scoped implementations, not claims
of complete packages or whole-paper reproduction. Cell Ranger remains excluded.

The frozen catalog contains250 papers (Nature71, Nature Genetics104 and AJHG75),
400 observed named tools from438 registry definitions,2465 paper/tool observations,
988 reviewed uses and340 supporting pointers. Its original review window is
2023-10-23 through2026-10-23; no extension was needed. All paper identities,
observations, reviewed roles and399 other tool rows are preserved by this update.

scFates is now available through the validated development
`org.jlinalg.cli.ScfatesWorkflowCli`, with separate `ScfatesSetupCli` setup.
It executes original scFates1.2.5/SimplePPT1.1.7 CPU tree/root/pseudotime on explicit
prepared coordinates. Read [the execution guide](../SCFATES_WORKFLOW.md) and
[catalog integration guide](../SCFATES_CATALOG.md). The canonical executable
is unchanged. P094's edition/root/iterations and biological results are not inferred.

**SKIP3 skips dependent analysis** if compatible software or installation/download
permission is unavailable. **FAIL2 admits no case from the entire requested batch**,
including earlier completed cases. Keep original inputs, failures, provisionals
and logs; correct the named cause and retry NEW paths. RUN installs nothing.
Read [WARNINGS.md](WARNINGS.md), console warnings, native audits and process receipts.
Original NaN/Inf, zero assignments, missing milestones, directional root rounding,
scalar-edge projection, initialization bookkeeping and NumPy ties remain explicit.
No palette, fallback probability, renormalization or annotation is fabricated.

The earlier Palantir checkpoint and all prior text follow verbatim as history.
Use the current summary/inventory and the current implementation guide for
availability; historical missing counts and pending statements describe those
earlier checkpoints. The250-paper implementation goal remains active.

<details>
<summary>Historical prior catalog document, retained verbatim</summary>

# Literature-driven omics toolbox: current status

The fixed cohort contains **250 papers,400 named tools,2,465 paper-tool observations,988 reviewed uses and340 supporting paragraph pointers**. Current scoped availability is **86 new integrations:17 native subsets and69 upstream adapters**, or **89 including three existing adapters**. **255 tools remain missing.** Paper-wide semantic completeness and the full implementation goal remain open. Five newly recognized names add four missing entries; Palantir receives the one new adapter credit.

Read the [current catalog update](../PALANTIR_CATALOG.md), [Palantir setup/workflow guide](../PALANTIR_WORKFLOW_DEVELOPMENT.md), [catalog validation](palantir-catalog-validation.json), [summary](summary.json) and [tool inventory](tool-inventory.json). Eight source-bound Palantir/scFates/SAW/Stereopy/DoRothEA roles are appended to the prior980 reviews. Raw paper identities, all prior observations and all prior reviews are retained. Original source versions and unreported paper choices remain explicit.

**Warnings and recovery:** read [WARNINGS.md](WARNINGS.md) and every analysis status. Missing or forbidden dependencies mean **SKIP3: skip dependent analysis**. **FAIL2 admits no atomic result, including earlier completed outputs.** Preserve originals and provisionals, resolve the named cause and retry NEW paths. Separate permitted setup is explicit; RUN installs nothing. Original Palantir clipping can reduce fate-row mass while entropy retains its preclip meaning. Native audits do not independently refit trajectories. Cell Ranger remains excluded.

Run current read-only verification from the project root:

```powershell
python -I -B tools/literature/verify_palantir_catalog.py
python -I -B tools/literature/palantir_workflow_evidence.py
```

The source-pointer audit additionally needs the local original XML/extraction cache. The original three-year window remains2023-10-23 through2026-10-23; no extension was needed. The canonical executable is unchanged. No release or website deployment is claimed; unfinished literature pages remain excluded from Pages.

## Retained historical documentation

All text below is preserved byte for byte from the previous document. Its counts and statements labelled current are historical and are superseded by the status above.

<details>
<summary>Previous status documents and evidence links</summary>

# Literature-driven omics toolbox: current status

The fixed cohort contains **250 papers, 390 named tools, 2,450 paper-tool observations, 932 reviewed uses and 322 supporting paragraph pointers**. Current scoped availability is **78 new integrations: 17 native subsets and 61 upstream adapters**, or **81 including three existing adapters**. **253 tools remain missing**. Paper-wide semantic completeness and the full implementation goal remain open.

The [dndscv workflow guide](../DNDSCV_WORKFLOWS.md) covers native coding annotation/opportunity arithmetic and source-bound original selection, with offline source export, exact private setup, a runnable example and explicit SKIP3/FAIL2 recovery. Seven primary roles and eleven supporting paragraphs preserve custom coverage, mouse references, clone-level events, IntOGen consensus boundaries, the unresolved0.1.0 versus0.0.1.0 version and pentanucleotide/filter ambiguities. Complete tables and N/L arrays match24 original case executions;64 native coding and17 workflow checks pass per JVM on Windows Java21/25 and Linux Java21. See the [validation and public opaque-object omission limits](../dndscv-workflow-development/VALIDATION.json).

Prior [SoupX](../SOUPX_WORKFLOWS.md), [fitdistrplus and Cicero](../FITDISTRPLUS_SOURCE_REVIEW.md) coverage remains available. The canonical executable is unchanged; use the documented separate development JARs or build current sources.

**Warnings and recovery:** read [WARNINGS.md](WARNINGS.md) and every analysis status. Missing/forbidden original dependencies mean SKIP3 and skip the dependent analysis. FAIL2 admits no atomic result, including earlier completed outputs. Preserve failed/partial evidence, correct the named cause and retry NEW paths. No silent omission, ID repair, score replacement, rescaling or version/method substitution occurs. Cell Ranger remains excluded and py-monocle's license decision remains pending.

Current verification:

```powershell
python tools/literature/dndscv_workflow_evidence.py
python tools/literature/audit_dndscv_catalog.py
python tools/literature/verify_dndscv_review_context.py
python tools/literature/verify_dndscv_catalog.py
```

Run these commands from the repository root. The source-pointer audit needs the local original XML/extraction cache. Use [summary.json](summary.json) and [tool-inventory.json](tool-inventory.json) for current counts and exact scopes. The original three-year window remains2023-10-23 through2026-10-23; no extension was needed. No release or website deployment is claimed; unfinished literature pages remain excluded from Pages.

## Retained historical checkpoints

The text below is preserved from earlier milestones. Its counts and statements labeled current describe those earlier checkpoints; they do not replace the current status above.

<details>
<summary>Earlier milestone text and evidence links</summary>

# Literature-driven omics toolbox expansion

**RepeatMasker public workflow validated:** native annotation reuse and original two-stage SEARCH pass complete output/tree comparisons in both declared profiles. [Workflow and required actions](REPEATMASKER_PUBLIC_WORKFLOW.md) and [validation](repeatmasker-validation.json) retain unsupported editions, resource permissions and scientific limits. The full 250-paper goal remains active.

**Eagle 2.4.1 cohort/reference phasing is now a validated scoped development integration.**
Use `eagle-tools` with native VCF/BCF2.2 checks and protected source/conversion
ledgers. The [workflow](EAGLE_WORKFLOWS.md), [BCF guide](EAGLE_BCF_STATUS.md),
[eleven source roles](EAGLE_SOURCE_REVIEW.md) and [validation](eagle-validation.json)
retain exact input, edition, matching and missingness boundaries. All 169 strict
tests pass on each of three JVMs; 40 original-matched phasing protocols cover
692,743 calls, and the copyable BCF examples match 512 direct-original calls.
The current catalog has **54 new validated integrations plus 3 existing
adapters (57 total)** and **265 missing**. It retains 250 papers, 379 named
tools, 2,428 observations, 703 reviewed uses and 203 supporting pointers.

[Eleven RepeatMasker source roles](REPEATMASKER_SOURCE_REVIEW.md) distinguish annotation reuse from search and masking. The scoped original workflow is available; read REPEATMASKER_PUBLIC_WORKFLOW.md for exact profiles and recovery.

**Required action:** use an admitted Linux runtime for original phasing; skip
the dependent analysis with **SKIP3** when a dependency or requested capability
cannot be provided on a permitted host. Invalid input, integrity, execution or
capacity fails with **FAIL2**. Retain diagnostics and rerun to a **new output**.
Source indexes are provenance only, never queried or certified against the BCF.
Require `COMPLETED.json` and matching manifest/file hashes. Historical/server,
imputation, biological accuracy and full-paper reconstruction remain outside
this scope. Cell Ranger remains excluded; the whole goal is active.

## Earlier checkpoints

The following milestones retain their historical counts and validation scope.
Use [summary.json](summary.json) and the current paragraph above for current totals.

**FAVOR offline CSV annotation is now a validated scoped adapter.** Use
`favor-annotate` with the repository runtime preparation and synthetic example
helpers. [Workflow and required recovery](FAVOR_WORKFLOW.md),
[validation](favor-validation.json) and [paper-role boundaries](favor-role-coverage.json)
identify the exact current ROOT candidate and supported inputs. The original
full-table exporter remains unsupported; use audited scalar values with cell
states and canonical provenance. The catalog now has **52 new validated
integrations plus 3 existing adapters**, with **267 missing**. This is a scoped
FAVOR adapter, not a claim of whole-tool or P130 pipeline reproduction.

**Native Fisher enrichment is available in development.** Start with the
[runnable examples](../../../examples/fuma-fisher-workflow/README.md) and
[input guide](FUMA_FISHER_WORKFLOWS.md). Supplied count tables or verified
known-association groups retain complete families, original/tested counts,
conditional odds and intervals, root brackets and all grouping evidence.
[Validation](fuma-fisher-validation.json) covers 1,395 focused and packaged tests,
original R references on three JVM profiles, 18 public Fisher recipe runs and
desktop/mobile catalog checks. This extends partial FUMA coverage; broader FUMA
remains marked missing. The whole goal remains active with 267 missing
integrations. Cell Ranger remains excluded.

**Required recovery:** unavailable or forbidden Java means verifier **SKIP 3**;
provide Java 17+ on a permitted host or retain the affected analysis as skipped.
Invalid inputs, models, imports or capacities fail with **exit 2**; inspect the
named cause, `WARNINGS.md` and retained `partial/` diagnostics, then rerun
corrected inputs to a NEW directory. No analysis command installs software.

**Current HOMER RNA and all twelve catalogued HOMER roles are available in development.** Original 5.1/v7.0 exon raw/RPKM quantification now has complete native tag, part, boundary, copy and value audits. [Workflow and required recovery](HOMER_RNA_WORKFLOWS.md), [validation](homer-rna-validation.json) and [role mapping](homer-role-coverage.json) retain explicit reference, filtering, mate and strand choices, fractional counts and downstream boundaries. All 1,014 focused tests in 79 suites and 1,014 exact-JAR tests per Java 21/25 pass. Two public recipes match two fresh complete originals across 1,553,877 parts and 489,584 sample values. Twelve prelaunch, two postlaunch failure, two Windows and six SAM-option protocols pass. The audit covers eleven software uses and one motif-resource reuse entry, without claiming all HOMER modules or full-paper parity. The whole goal remains active with 267 missing integrations and paper-wide semantic review open. Cell Ranger remains excluded.

**Historical HOMER ATAC region/track checkpoint.** Original 5.1 tag building, replicate merging, region-mode peaks, full-fragment coverage and pinned UCSC BigWig conversion now have complete native population/count/coverage/raw-interval checks. [Workflow, warnings and required actions](HOMER_ATAC_WORKFLOWS.md) explain plain SAM, half weights, source clamping, genome-size fallback, explicit choices, dependency skips and quarantined failures. [Validation](homer-atac-validation.json): 964 focused tests in 75 suites and 964 exact-JAR tests per Java 21/25; three synthetic public workflows match three fresh complete original references. Seventeen prelaunch controls, three postlaunch failures, two positive boundaries, two Windows skips and seven preparation controls pass. RNA/GO and broader HOMER remain open; 269 integrations remain missing, Cell Ranger stays excluded and the whole goal remains active.

**Historical HOMER generated genomic-background milestone.** Original old generation supports 5.1/4.11/4.11.1;new generation supports 5.1. [Required choices, skips and actions](HOMER_GENERATED_WORKFLOWS.md) cover version-specific overlap, unseeded draws, count shortfalls, boundary preservation, identities and resource limits. [Validation](homer-generated-validation.json):844 focused/exact packaged tests per Java 21/25,20 public generated recipes with 48 exact-population replay calls and 20 separate original draws,plus 9 private generated protocols. Broader HOMER and 269 integrations remain open;Cell Ranger stays excluded and the goal remains active.


**Historical818-test genomic phase-selection checkpoint.** Choose known-only, de novo-only or both explicitly. The current JAR passes 818 focused/exact packaged tests on each Java 21/25; 28 complete private workflows and 15 public recipe operations match fresh originals. Two additional original legacy reporting failures are retained and promoted as errors. [Workflow and required actions](HOMER_GENOMIC_WORKFLOWS.md) explain unused controls, null counts for unrequested phases, legacy division by zero, dependency skips and quarantined failures. [Current validation](homer-genome-phase-validation.json) records exact scopes. Generated backgrounds, named resources, peak/coverage/RNA and 269 integrations remain open; Cell Ranger stays excluded and the goal remains active.


**Previous 805-test HOMER supplied-background milestone (historical).** `homer-tools genome` runs complete original known/de novo/matching reports on supplied FASTA and background across three versions. The exact JAR passes 805 tests on each Java 21/25; 13 complete protocols include nine fresh original references, with nine additional public recipes/reference runs. [Workflow, warnings and recovery](HOMER_GENOMIC_WORKFLOWS.md) explain legacy strand behavior, original q versus BH, explicit setup, dependency skips (exit 3) and quarantined failures (exit 2). [Validation](homer-genome-validation.json) records scope and hashes. Broader HOMER remains missing; generated backgrounds, named resources, peak/coverage/RNA and 269 integrations remain open. Cell Ranger stays excluded; the whole goal is active.


**Native legacy/current Minimac reference blocks are validated; the typed imputation command remains unfinished.** The new Java reader passes 33 new tests and the candidate passes 504 focused/packaged tests, with no skips. Twenty-one cross-host audits cover 8,700,264 ordered haplotype alleles; three original conversions/complete exports preserve selected identities, phase and model values. Read [format warnings and required actions](MINIMAC_REFERENCE_BLOCKS.md), [evidence](minimac-blocks-validation.json) and the [runnable example](../../../examples/native-minimac-reference/README.md). Explicit boundary policies retain both rows and any ID/model change. Unsafe v2 deltas fail before upstream execution; the documented v2 subset excludes all-reference rows explicitly and does not authorize production filtering. The catalog retains 270 missing integrations and Cell Ranger remains excluded.

**Minimac private runtime setup and the Java backend are validated; the typed imputation command remains unfinished.** Four offline and four allowed-download admissions pass real health checks. The packaged backend reproduces all four original profiles and passes 17 controls. Read [setup, warnings and recovery](MINIMAC_RUNTIME_STATUS.md) and [runtime evidence](minimac-runtime-validation.json). The catalog still records 270 missing integrations, including Minimac; Cell Ranger remains excluded.

**Earlier native Minimac reference inspection and CSI indexing checkpoint.** That native-helper candidate passes 471 focused/packaged tests. Complete reference audits retain the original mixed-ploidy AN error, explicit converted-haplotype identities and Savvy region-query omissions. Read [warnings, evidence and required recovery](MINIMAC_REFERENCE_AUDITS.md), [validation](minimac-reference-validation.json) and the [runnable native example](../../../examples/native-minimac-reference/README.md). No tool-integration count is advanced; Cell Ranger stays excluded.

**Minimac source roles and native dosage moments are validated; the project imputation adapter remains missing.** Thirteen newly reviewed roles and six support pointers bring the catalog to671 reviewed roles/197 pointers, retaining250 papers/379 tools/2,428 observations and all658 prior reviews. Original Minimac3/current and historical Minimac4 profiles completed five synthetic imputation workflows; the native Java API passes433 focused tests/34suites and433 exact packaged tests on each Java 21/25. Six cross-host native audits check4,320 original genotype cells. Read [source roles and required recovery](MINIMAC_SOURCE_REVIEW.md), the [native example](../../../examples/native-haplotype-dosage/README.md) and `minimac-source-validation.json`. CRLF/index failures, historical runtime compatibility, float32 R² differences and distinct reference-preparation outputs remain explicit. This is not an integrated imputation command.37 upstream/12 native subsets and270 missing tool integrations remain;Cell Ranger stays excluded and the full goal stays active. No canonical/public release was made.

**Earlier CellBender CPU adapter checkpoint.** The original 0.4.0 full/ambient/swapping MCKP subset passed 407 focused tests in 33 suites, 407 exact packaged tests on each Java 21/25, three scientific workflows and an original-reference match across all 64 HDF5 datasets plus metric/cell-barcode CSVs. The public synthetic verifier passed. Fifteen live CLI controls, five cross-host skip checks, eight installer controls and two changed-home refusals retain explicit cause/recovery. Read [workflow and required actions](CELLBENDER_WORKFLOWS.md), [source roles](CELLBENDER_SOURCE_REVIEW.md) and `cellbender-validation.json`. CPU-only; missing, unsupported, changed or forbidden dependencies skip3, failures2 quarantine partials, and existing outputs are preserved. Twelve native and 37 bounded upstream subsets are validated;270 integrations and paper-wide semantic review remain open. The frozen catalog retains250 papers/379 tools/2,428 observations/658 reviewed roles/191 supporting pointers. Cell Ranger remains excluded. No canonical/public release was made.

**Prior FUMA score/workflow checkpoint.** Its combined candidate passed 365 focused tests in 30 suites with no skips, plus all 365 tests against exact packaged classes on Java 21/25. Twenty original R score protocols (19 completed, one retained error) support 17 valid-schema comparisons and 29 public native/control cases per Windows 21/25 and Linux 21. Fifty-seven packaged workflow runs include six original MAGMA mean/top/multi analyses; 201 tested genes and one empty annotation are retained. Another 224 prior mapping/chromatin replays preserve the earlier tables. Read [the typed workflow guide](FUMA_TYPED_WORKFLOW.md), [raw score annotations](FUMA_GENE_SCORE_ANNOTATIONS.md), [source findings](FUMA_NUMERICAL_FINDINGS.md) and `fuma-workflow-validation.json`. Missing/forbidden dependencies skip with cause and recovery; failed or partially skipped roots are not completed workflows. The catalog retains 250 papers,379 tools,2,428 observations,645 reviewed roles and187 supporting pointers;271 tool-level integrations remain missing. Cell Ranger remains excluded; the full goal stays active. No canonical/public release was made.

**Earlier supplied chromatin checkpoint.** That candidate passed 318 tests in 27 suites with no skips, plus all 318 tests against exact packaged classes on Java 21/25. Thirty-six original R protocols (34 completed, two retained failures) support 80 independent policy protocols and 152 packaged workflows. Source-policy tables agree across Windows 21/25 and Linux 21. Ten public/Unicode/recovery cases passed; portable replays cover 160 chromatin and 64 prior positional/eQTL workflows. Read [chromatin workflow and required actions](FUMA_CHROMATIN_WORKFLOWS.md), [source findings](FUMA_NUMERICAL_FINDINGS.md) and `fuma-chromatin-validation.json`. Declare membership/coordinate policies and distinguish interaction declarations, pool flags and actual links. Only actual links count as mapped genes; declaration-only runs require explicit empty retention. No external runtime is required. The catalog retains 250 papers,379 tools,2,428 observations,645 reviewed roles and187 supporting pointers;271 tool-level integrations remain missing. Cell Ranger remains excluded; the full goal stays active. No canonical/public release was made.

**Earlier FUMA positional/eQTL checkpoint.** That combined candidate passed 278 tests in 25 suites with no skips, and all 278 tests passed against exact packaged classes on Java 21/25. Thirty-two original R protocols (31 successful, one retained source error) compare 96 packaged workflows across Windows 21/25 and Linux 21; 160 table groups match across profiles. Independent association oracles cover all 32 protocols, 13 extra controls/public/Unicode cases passed, and the portable replay passed 64 workflows on Windows/Linux. Read [mapping workflow and required actions](FUMA_MAPPING_WORKFLOWS.md), [source findings](FUMA_NUMERICAL_FINDINGS.md) and `fuma-mapping-validation.json`. No external runtime is needed. Chromatin mapping, annotation/eQTL discovery, gene scores, full MAGMA orchestration and expression/cell-type workflows remain open. The frozen catalog retains 250 papers, 379 tools, 2,428 observations, 645 reviewed roles and 187 supporting pointers; 271 tool-level integrations remain missing and Cell Ranger stays excluded. The full goal is active; the canonical executable/public release is unchanged.

**Earlier FUMA locus/gene-set checkpoint.** That combined candidate passed 224 focused tests in 20 suites and 224 exact packaged tests on each of Java 21/25. Forty-three original-function protocols compare 129 typed native workflows/786 candidate rows, with 30 additional controls/public/Unicode cases and seven identical cross-profile table groups. Read [locus workflow and required recovery](FUMA_LOCUS_WORKFLOWS.md), [numerical/source findings](FUMA_NUMERICAL_FINDINGS.md) and [14 paper roles](FUMA_SOURCE_REVIEW.md). Original backward-merge failures, incremental counts, parser/tie differences and forced-seed/MHC/region semantics remain explicit. The frozen catalog still contains 250 papers, 379 tools, 2,428 observations, 645 reviewed roles and 187 supporting pointers; 271 tool-level integrations remain missing, including broader FUMA. Cell Ranger remains excluded. The full goal remains active; no canonical/public release was made.

**Earlier FUMA gene-set checkpoint.** The Java GENE2FUNC module passed 192 focused tests in 18 suites and 192 exact packaged tests on each of Java 21/25. Thirty-five original workflows, 70 packaged comparisons, 1,024 exact-probability rows, 13,920 correction fields and seven public/Unicode workflows were checked. Legacy numeric discrepancies are retained with independent exact audits. Read [workflow and required recovery](FUMA_GENESET_WORKFLOWS.md), [numerical findings](FUMA_NUMERICAL_FINDINGS.md) and [14 paper roles](FUMA_SOURCE_REVIEW.md). The frozen catalog contains 250 papers, 379 tools, 2,428 observations, 645 reviewed roles and 187 supporting pointers. It retains 271 missing tool-level integrations, including broader FUMA; Cell Ranger stays excluded. The wider implementation and semantic review remain active. The canonical executable and public release are unchanged.

**Earlier ADMIXTURE development checkpoint.** Original fitting, supervised references and projection passed 169 focused tests in 16 suites, 169 exact packaged tests on each of Java 21/25, 20 original-reference workflows and 25 runtime/recovery checks. Two combined-options comparisons and five public demo workflows also passed. [Workflow and required recovery](ADMIXTURE_WORKFLOWS.md) explain installation/download permissions, dependency skips (exit 3) and quarantined failures (exit 2). The catalog retains 250 papers, 379 tools, 2,428 observations, 638 reviewed roles and 171 supporting pointers. Twelve native and 36 bounded upstream subsets are validated; 271 tools remain missing. AdmixturePlotter/CLUMPP remain missing, and Cell Ranger stays excluded. The canonical executable and public release are unchanged. The wider implementation and semantic review remain active.

**Earlier native-only ADMIXTURE milestone (historical).** That stage added 15 reviewed roles: 13 ADMIXTURE uses plus separate AdmixturePlotter and CLUMPP entries. It preserved all 250 paper identities and 623 prior reviews, producing 379 tools, 2,428 observations, 638 reviewed roles and 171 supporting pointers. Its 138-test candidate contains the native likelihood/K=1 API and audits 20 original fixtures; that older candidate has no fitting command. At that stage, 35 upstream subsets were validated and 272 tools were missing. The current adapter above supersedes that availability restriction; earlier validation remains retained. Read [native API](NATIVE_ANCESTRY_MIXTURE.md), [source roles](ADMIXTURE_SOURCE_REVIEW.md) and [runtime recovery](ADMIXTURE_RUNTIME_STATUS.md).

The requested goal is active: catalog 250 recent primary papers from Nature,
Nature Genetics and AJHG, identify the software they use, and implement missing
workflows. The approved approach combines native Java methods and tested upstream
adapters. Downloads and installation are allowed where the operating environment
permits them. An unavailable dependency must skip the dependent analysis and
produce an actionable warning.

## SAIGE integration and earlier source checkpoint

At the earlier SAIGE source-review checkpoint, the catalog had 250 papers, 377 tools, 2,426 observations, 623 reviewed roles and 153 supporting pointers. All604 earlier reviews are preserved. [Nineteen SAIGE-family roles](SAIGE_SOURCE_REVIEW.md) distinguish16SAIGE,2SAIGE-GENE and1Meta-SAIGE uses;P147's published-summary reuse is newly recovered. Attached numeric versions are recognized without merging tool identities.

The native [unrelated-select command](UNRELATED_SELECTION_WORKFLOWS.md) is available in development candidate9786ba29:32tests/5suites,32standalone perJava 21/25,501 independent full-decision graph references and21 actual packaged cases passed. It applies phenotype eligibility before initial degrees,requires explicit ties and complete additive-GRM pair coverage,and names every retained blocker. A maximal result need not be largest. It needs no external runtime.

**Bounded SAIGE PLINK association available; wider integration active.** The admitted original SAIGE 1.5.2/R4.5.2 runtime and `saige-tools` expose typed `sparse-grm`, `fit-null` and diploid autosomal PLINK `single`. The SAIGE numerical candidate’s 122-test/12-suite gate and all 122 tests against exact packaged classes pass on Java 21 and 25. Thirteen earlier scientific workflows cover 526 variant rows; two current workflows preserve 64 reference rows, with explicit allele, imputation, cleanup, QC and reportability audits. Read the [association guide](SAIGE_ASSOCIATION_WORKFLOWS.md), [preparation guide](SAIGE_WORKFLOWS.md), [runtime recovery](SAIGE_RUNTIME_STATUS.md) and `saige-association-validation.json`. BGEN/VCF, conditional/gene/LD and Meta-SAIGE integrations remain unfinished; skip those dependent analyses. At that earlier checkpoint, coverage was 12 native tool subsets, 35 upstream subsets, 48 overlaps, 270 missing tools and one user-excluded Cell Ranger, plus the existing adapter/lookup/export categories. Current totals are stated above. The goal remains active; the canonical executable and releases are unchanged. Read the [new numerical findings](SAIGE_NUMERICAL_FINDINGS.md): original PCG failures now reject or withhold affected statistics; conditional analysis remains unavailable while sparse-storage and P/SE discrepancies are handled explicitly.

The prior IGV milestone validated18viewer roles and the bounded original `igv-tools` development command(candidate38889b96):126focused tests,17packaged cases and27runtime policy controls. See [IGV workflows](IGV_WORKFLOWS.md),[source review](IGV_SOURCE_REVIEW.md) and [runtime status](IGV_RUNTIME_STATUS.md). Its historical2425-observation/604-review source snapshot is preserved;current counts are stated above. Automatic CNA/synteny summaries,modification interpretation and historical/full-paper reconstruction remain open.

The [APBS workflow guide](APBS_WORKFLOWS.md),[PDB2PQR guide](PDB2PQR_WORKFLOWS.md) and [potential-surface guide](POTENTIAL_SURFACE_WORKFLOWS.md) now provide a validated preparation-to-solver-to-actual-map-surface workflow in development candidate b1c26fa4. The combined107-test gate,14 original preparation comparisons,6 actual surface workflows,16 preparation runtime policies and a fullJava 25 Unicode chain passed. Missing dependencies skip the affected and dependent stages with prominent recovery actions. Earlier10solver comparisons/6,013,002nodes remain separate immutable evidence. That workflow milestone retained377 observed tools/2424 observations/587 reviewed roles;the later IGV milestone added one observation and17new reviews;the current SAIGE source/component milestone above supersedes these historical counts. No paper use is invented for PDB2PQR/PROPKA dependencies. Source observations are unchanged;historical/full-paper reconstruction remains open.

The [native molecular geometry guide](MOLECULAR_GEOMETRY_WORKFLOWS.md) adds explicit-unit
distance,angle,torsion and supplied-pair proper rigid fitting without an external
runtime. Its development executable SHA starts `798d3a08`;28 focused tests and
16 packaged workflows/12 controls passed. Twenty PyMOL source roles are now reviewed;
the typed original PyMOL rendering/alignment/editing subset is validated in its development candidate. Typed preparation and actual APBS electrostatic-surface integration are now available in the separately validated workflow above.

The [PRS-CS guide](PRSCS_WORKFLOWS.md) adds original three-profile posterior
inference,native marginal/LD/posterior checks and explicit score-weight exports.
The development candidate passed218 focused tests,12 packaged workflows and28
controls on Java 21/25;its SHA starts `33b26e76`. The original56 synthetic runs
have208 output files reproduced from the revised sealed runtime. Historical
Python3.10.11 is out of support and requires explicit offline reproduction.
Read the prominent installation,model,warning and recovery actions in
[WARNINGS.md](WARNINGS.md). The canonical a104 executable remains unchanged.

The [Beagle guide](BEAGLE_WORKFLOWS.md) adds typed original phasing/reference
imputation for four pinned builds, with Java input/call/posterior validation.
The checked development JAR passed 176 focused tests, 42 packaged workflows and
24 failure controls on Java 21/25. Read the prominent phase, exclusion and
dependency actions in [WARNINGS.md](WARNINGS.md). It is available at
`build/literature-review/beagle-candidate-1/jlinalg-0.3.7.jar` (SHA starts
`5ed54e44`); the older canonical a104 executable is unchanged and lacks the new
Beagle/PLINK commands. No new full-project gate or release is claimed.

The same250 source identities now have604 individually reviewed roles and
127 supporting pointers. Cell Ranger adds44 source reviews distinguishing GEX,
ARC,ATAC,demultiplexing and downstream tools;its implementation is excluded at
the user's explicit request. Read [the exclusion and source review](CELLRANGER_SOURCE_REVIEW.md).
Tool-level counts are12 native subsets,33 upstream subsets,48 overlaps,272 missing
integrations and1 user exclusion,plus existing adapter/lookup/export categories.
Complete semantic review and implementation remain active.

The [native genotype-score guide](GENOTYPE_SCORE_WORKFLOWS.md) adds supplied-weight
diploid human autosomal BED scoring in Java, with exact effect/other alleles,
explicit imputation/omission/error policies, separate observed and denominator
counts, unreportable all-missing scores, bounded inputs and actionable quarantine.
The canonical source executable passed 1,593 tests/72 required suites, all 217
policy tests without skips and 28 earlier-tool regression groups. Native scoring
needs no original PLINK installation. Broader PLINK adapters remain open.

The [PLINK/GWAS source review](PLINK_SOURCE_REVIEW.md) corrects release identities,
recovers direct GWAS appendix/result roles and distinguishes genotype files,
annotation lookups and genuine executable use. The earlier PLINK source tranche had 2,422 observations;the current IGV-reviewed catalog has2,425;
32 new role reviews preserve cohort/model/unit boundaries. PLINK adapter work
continues, without claiming a new implementation badge from source curation.

The [native FLASH guide](FLASH_WORKFLOWS.md) adds Java paired-read reconstruction
without an external runtime, with 45 original reference workflows/5,185 pairs,
both quality encodings and orientations, gzip/interleaved input, barcode/header
mapping and actionable normalization/failure reports. Maximum overlap caps the
scoring denominator. The source audit now verifies 501 reviewed uses and 86
supporting pointers. Seven FIMO uses preserve original P/q thresholds and custom
empirical score procedures. The [DNA motif guide](FIMO_WORKFLOWS.md) documents
native Java P-value scans and the tested original FIMO 5.5.9 P/q adapter. Stored-hit
truncation fails even on empty exit-0 output; uncomputed full-mode q placeholders
are blank in canonical results. Missing or forbidden original dependencies skip
with exact recovery; native P scanning remains available without installation.

The [original Trim Galore guide](TRIM_GALORE_WORKFLOWS.md) adds tested unmodified
0.6.7/0.6.10 workflows with Cutadapt 5.2 and optional original FastQC 0.13.0.
It explains exact private runtime setup, Phred encoding, ordinary ASCII read
headers, UTF-8 recipes for Unicode Windows paths, orphan/rescue edge cases and
prominent skip/error recovery. The [native read guide](../../trim-galore-native-reads.md)
provides Java post-Cutadapt finalization and hardtrim without external software.
The same current canonical source-build JAR now includes both commands.

The [enrichment guide](ENRICHMENT_WORKFLOWS.md) adds native Java running scores,
original clusterProfiler/fgsea and explicitly separate legacy DOSE APIs. It
explains gene-set and rank inputs, engine/null differences, query backgrounds,
q-values versus adjusted P-values, incomplete testing families and exact runtime
recovery. VIPER/aREA original-engine validation awaits license eligibility.

The [kallisto guide](KALLISTO_WORKFLOWS.md) adds original 0.48.0 bulk
quantification through Java, sealed indexes, explicit library/strand/fragment
choices, legacy bias correction and verified plaintext bootstraps. Native Java
audits identities and abundance arithmetic. HDF5/Sleuth and BUS/UMI remain
unavailable through this adapter; the guide gives exact skip/recovery actions.
The canonical executable passed 1,593 tests with zero failures/errors; all 72
required suites ran without skips and five optional tests skipped. Original
Trim Galore passed 25 packaged calls/22 independent original comparisons, plus
two Unicode input/output checks; the native helper passed 40 packaged calls.

The [native transcript-import guide](TXIMPORT_WORKFLOWS.md) covers native
Salmon/kallisto/RSEM point estimates, gene summarization and four count-scaling
choices, with 204 original R cases and explicit uncertainty/length-offset
actions. It needs no quantifier runtime when importing existing files.

The [native quantile-normalization guide](QNORM_WORKFLOWS.md) adds finite-double
column normalization, explicit targets/ties, exact raw integer validation and
model warnings. It needs no Python runtime and is distinct from R qnorm.

The [deepTools guide](DEEPTOOLS_WORKFLOWS.md) covers native supplied-signal
methods and eight tested original workflows through Java, including reusable
region matrices, profiles/heatmaps, BAM summaries and Pearson/Spearman
correlation. The1,552-test gate and58actual workflow calls passed. Missing/zero
policies, exact models, ATAC all-tag/sequence/quality loss and figure presentation
limits require review. Unexposed package options remain open.

The [read-trimming guide](TRIMMOMATIC_WORKFLOWS.md) adds thirteen native Java
quality/length/MAXINFO steps and original Trimmomatic0.39/0.41 adapter clipping.
Declared Phred encoding, literal step order, forward-only cropping, four
paired/orphan files and dependency recovery remain explicit. Java 25 is installed
privately where permitted; older0.32/0.36 and whole-paper parity remain open.

Start with the [searchable offline catalog](../../../site/literature-review.html),
the [paper-by-paper catalog](catalog.md), and the
[prominent warnings and required actions](WARNINGS.md).

The [native sequence guide](NATIVE_SEQUENCE_WORKFLOWS.md) covers reproducible
paired subsampling, length/quality trimming, exact-reference extraction and
terminal-repeat scoring in Java, including poor-quality fallback warnings.

The [GATK guide](GATK_WORKFLOWS.md) adds typed germline/gVCF/filter workflows,
native reference metadata, explicit ploidy and missing-annotation choices, and
retained runtime/platform diagnostics. It distinguishes still-missing legacy and
somatic models. Sequencing QC now promotes all-filtered Cutadapt and source
FastQC findings through the final MultiQC warning/status/console outputs.

The [STAR guide](STAR_WORKFLOWS.md) adds native GTF inspection, sealed annotated
indices, splice alignment, distinct two-pass modes and raw strand-specific gene
counts. It documents the private Windows source initialization fix, BySJout
output-order handling, combined-mate filter thresholds and exact recovery steps.
STARsolo barcode/UMI processing and WASP/Hornet remain separate missing workflows.

The [native genomic-signal guide](GENOMIC_SIGNAL_WORKFLOWS.md) describes Java
bedGraph means and state/genome log2 enrichment, including explicit reference
universes, missing positions, zero signals and pseudocount choices. Peak calling
and assay normalization remain separate stages.

The [native track-peak guide](TRACK_PEAK_WORKFLOWS.md) adds supplied-score
threshold/gap/span calling and plateau summits, with actual MACS3 track-command
references and explicit float32, zero-fill and no-hit warnings. It does not run
the failed alignment-based caller or HMMRATAC.

The [REGENIE guide](REGENIE_WORKFLOWS.md) describes native Java FID/IID/table
validation, sealed whole-genome prediction bundles, quantitative/binary association
and burden/SKAT/ACAT/SBAT gene-mask workflows through pinned REGENIE 4.1.3.
Declared quantitative models remain quantitative even for 0/1 data. Coding,
alleles, missingness and correction choices are explicit; source-build warnings,
dependency skips and recovery steps stay prominent.

The [Java coordinate-conversion guide](COORDINATE_LIFT_WORKFLOWS.md) covers
directional chains, full exact reference dictionaries, aligned-base minMatch,
target-span caps and reciprocal criteria. Every original interval/status is
retained; unusable mappings and missing local data have prominent diagnostics
and recovery steps. The engine is bundled in Java and needs no external runtime.

**MACS callpeak is unavailable on the tested private Windows runtime:** its
scientific fixture crashed, and AnnData/HDF5 also failed to import. Keep affected
analyses skipped. The [MACS failure and recovery guide](MACS_RUNTIME_STATUS.md)
explains the required supported environment and scientific validation steps.

## Evidence and scope

The publication window is October 23, 2023 through October 23, 2026, inclusive,
using Europe PMC's first-publication date. No extension was required. Only the
three exact journals are eligible; other Nature-family journals are excluded.
The sample is purposive and limited to available open-access primary full texts.
It is not a systematic or representative sample of the field.

`papers.json` records DOI, PMID/PMCID, source links, dates, XML hashes, named tools,
paraphrased uses, software-version strings when explicitly found near a name, and
evidence paragraph locators/hashes. `search-provenance.json` records all search
queries and paginated response hashes. `intake-audit.json` retains exclusions
and retrieval failures. `bibliography.bib` contains all 250 references.

Tool extraction uses a named-software registry, methods/analysis section filters,
and context rules to exclude misleading ordinary words and wet-lab instruments.
For example, Eagle cell-culture medium, Fusion cloning kits, and a Hamilton STAR
robot must not become phasing, TWAS, or RNA-alignment evidence. The catalog retains
benchmark/comparison context separately. **Semantic completeness review is still
open:** some tools can be omitted, a selected paragraph may cover only one of a
tool's uses, and role summaries require paper-specific interpretation.

Six t-SNE uses have individually reviewed, paper-specific summaries, guarded by
DOI/PMCID and paragraph hashes in `tools/literature/reviewed-uses.json`. These
identify the measured inputs, published preprocessing/settings where stated,
and differences from the bounded native implementation. They do not establish
paper-wide software completeness.

Five additional uses in P001 were individually reviewed for adapter removal,
post-adapter fixed-base trimming, Bowtie 1 alignment, ribosome-profiling offsets
and STAR alignment. Bibliographic superscripts are removed only from matching
text, so a name such as `STAR` followed by citation 80 is detectable. Original
paragraph text and its evidence hash remain intact. Bowtie 1 is catalogued
separately from Bowtie 2. Enrichment history and previous catalog snapshots are
retained; the 250 paper identities stay fixed.

The [RNA alignment and counting guide](RNA_ALIGNMENT_COUNTING_WORKFLOWS.md)
adds featureCounts gene/peak/junction counts, minimap2 read/assembly mapping,
HISAT2 RNA alignment, and native Java annotation, splice, PAF and normalization
helpers. Read/pair units, strand and runtime/compiler warnings require review.

The [single-cell QC and SCTransform guide](SINGLE_CELL_QC_WORKFLOWS.md) adds
native sparse-count canonicalization, Bayesian doublet-score/error and NB residual
helpers, original Scrublet, and distinct standalone VST/Seurat SCTransform adapters.
Raw/estimated input, exact IDs, regression and expression-layer contracts are explicit.
Upstream model warnings and required dependency recovery remain prominent.

The [MAGMA guide](MAGMA_WORKFLOWS.md) adds native strand-aware gene-window mapping,
original gene/set/property and conditional/joint models, plus explicit build/LD/N,
phenotype-coding and private-runtime contracts. FUMA/R wrappers remain distinct.

The current audit verifies 462 individually reviewed tool uses and 67 supporting
paragraph pointers. It includes all 11 Trim Galore paper contexts and 36
enrichment reviews, along with
21 deepTools contexts, two pyBigWig library calls, qnorm and UCSC bigWigMerge,
and all
nine Trimmomatic contexts, BAMscale coverage and two FLASH merger uses, plus 21
MAGMA contexts and 12 related-wrapper/pipeline uses, 36
Scrublet/SCTransform contexts, 14 related single-cell tools, 42
featureCounts/minimap2/HISAT2 contexts, eight distinct R-interface/related-tool
uses, all
32 MACS-family uses, 23 REGENIE uses, 18 distinct tools in P163, five seqtk uses,
six GATK uses, and distinct legacy, somatic and phylogenetic methods. A REGENIE
mention that only listed available alternative tools was removed from P204;
the prior attribution remains in catalog history. P147 explicitly omitted
binary/Firth/SPA flags, and that model choice is retained in its summary.
The Trimmomatic review retains forward-only cropping, literal step order,
historical version limits and the source's TPM/count ambiguity. A Varioskan FLASH
plate-reader mention is excluded from paired-read merger evidence.

The [deepTools development guide](DEEPTOOLS_WORKFLOWS.md) records source-tested
native supplied-track arithmetic in the validated executable, its full and
packaged checks, and the original Windows failures/private Cygwin builds.
Validated original coverage, matrix and plotting operations retain their
declared model, typed-option and presentation limits; unexposed workflows remain open.
Additional assembly-curation uses retain their own supporting paragraph locators
and hashes. The source and public-catalog guards reject stale supporting evidence;
the searchable catalog exposes these locators in each evidence panel. This does
not establish semantic completeness for the other methods or papers.

The coordinate-conversion review distinguishes 20 reported UCSC/liftOver uses
from MungeSumstats, rtracklayer, the Bioconductor liftOver R workflow and CrossMap.
It removes pre-lifted GENCODE resource reuse, prior liftability criteria, a chain
download URL and a custom pangenome method from direct UCSC execution claims.
Additional reviewed range/QC/prediction/epistasis tools retain their own names,
models and paper-specific settings; following a harmonizer procedure is explicitly
distinguished from stated executable use. Full-paper completeness remains open.

Where a parameter paragraph continues a named method without repeating the
software name, a reviewed `method-details` pointer records a separate named
tool anchor, a shared specific method term and an explanation. Both paragraph
identities, hashes and the shared term are checked. The catalog displays that
link explicitly; it is not a claim of automated semantic completeness.

Long source paragraphs stay in the ignored `build/literature-review/` research
cache. They are not relicensed as GPL software or copied into the public catalog.
The original publishers/authors retain rights to article content. Bibliographic
metadata, links, hashes and our paraphrased catalog are separate from that content.

## Implemented first workflows

These commands are available in the source build. They have not been released.

For this local run, a separately validated executable is retained at
`build/literature-review/validated-cli/jlinalg-0.3.7.jar`. Its exact baseline,
SHA-256, test totals and exclusions are in `isolated-validation.json`;
`packaged-validation.json` records the executable workflows. This artifact
excludes concurrent uncommitted study-pipeline changes in the shared checkout.

```powershell
.\gradlew.bat check executableJar --no-daemon --no-parallel
java -jar build/cli/omicsmatic-0.3.7.jar signature-score --help
java -jar build/cli/omicsmatic-0.3.7.jar intervals --help
java -jar build/cli/omicsmatic-0.3.7.jar cell-embed --help
java -jar build/cli/omicsmatic-0.3.7.jar sequence-qc --help
java -jar build/cli/omicsmatic-0.3.7.jar alignment-tools --help
java -jar build/cli/omicsmatic-0.3.7.jar hts-tools --help
java -jar build/cli/omicsmatic-0.3.7.jar read-align --help
java -jar build/cli/omicsmatic-0.3.7.jar gatk-tools --help
java -jar build/cli/omicsmatic-0.3.7.jar star-tools --help
java -jar build/cli/omicsmatic-0.3.7.jar genomic-signal --help
```

### Rank-based signature scores

`signature-score` streams observations by row from a headered TSV whose first
column is `sample_id`, followed by finite measured feature values. Supply a GMT
file containing signature name, description and unique feature IDs.

```powershell
java -jar build/cli/omicsmatic-0.3.7.jar signature-score --method ucell `
  --matrix src/test/resources/signature-scores/expression.tsv `
  --gene-sets src/test/resources/signature-scores/signatures.gmt `
  --max-rank 30 --out build/review-ucell-example
```

- `ucell`: positive signatures and average descending ranks; normalized
  Mann-Whitney formula used in UCell 2.7.6+. Cutoff cannot exceed the measured
  feature count. Signed suffixes, smoothing and complete package parity remain
  outside this subset.
- `aucell`: normalized recovery AUC with an exclusive rank cutoff. Ties resolve
  in input feature order, which differs from upstream R's randomized ranking.
- `ssgsea`: raw integrated-walk scores with integer average-rank weights and
  configurable `--alpha` (default 0.25). This is not kernel GSVA and does not
  normalize scores across the dataset.

Missing genes default to an error. `--missing skip` explicitly changes the tested
signature; UCell also supports `--missing impute`, assigning absent genes the
cutoff rank. `coverage.tsv` records the measured/absent signature sizes. Rank
calculation is shared across signatures for each row. A cell score is descriptive;
donors or other biological replicates remain the unit of population inference.

The frozen fixtures compare 288 outputs from pinned upstream UCell, AUCell and
GSVA scoring functions. They do not exercise the entire R packages. Source
commits, hashes, R session and refresh script are retained under
`src/test/resources/signature-scores/` and
`tools/literature/verify_signature_scores.py`.

### Genomic interval operations

`intervals` provides intersection, merging, subtraction and union coverage.
Inputs are headered TSVs with `chrom`, `start`, `end`, `id` and optional `strand`.
Coordinates are zero-based and half-open; intervals must be nonempty and IDs
unique within an input. An augmented interval tree avoids an all-pairs scan.

```powershell
java -jar build/cli/omicsmatic-0.3.7.jar intervals --method intersect `
  --input features.tsv --mask regulatory-regions.tsv --genome-build GRCh38 `
  --out build/review-intersections
```

All inputs must use the declared assembly and exact chromosome labels. No
liftover or chromosome renaming is inferred. Coverage counts overlapping masks
only once. Merging joins bookended intervals by default. This is a documented
BEDTools-like subset, not complete BEDTools compatibility. Validation includes
the published BEDTools intersection example, nested/stranded randomized comparisons
against independent brute-force overlaps, boundary cases and full CLI workflows.

### Native exact t-SNE

`cell-embed --method tsne` implements exact two-dimensional t-SNE in Java and
needs no Python installation. Supply a headered TSV with unique `obs_id` values
and finite numeric component columns, typically PCA scores. Preprocessing is
explicit: the command does not normalize counts, select features or run PCA.

```powershell
java -jar build/cli/omicsmatic-0.3.7.jar cell-embed --method tsne `
  --matrix pca.tsv --perplexity 30 --iterations 1000 --seed 1 `
  --out build/review-tsne
```

The API is `org.jlinalg.embedding.Tsne.fit(observations, options)`. It calibrates
Gaussian conditional affinities to the requested perplexity, symmetrizes them,
and optimizes the Student-t map using seeded Gaussian initialization, early
exaggeration, momentum and adaptive gains. Defaults are learning rate 50 (with
the conventional factor-four gradient), exaggeration 12, and
`min(250, iterations/4)` early updates. `--learning-rate`, `--early-exaggeration`,
`--exaggeration-iterations`, and `--min-gradient-norm` make these choices explicit.

Exact optimization uses quadratic memory and computation. Limits are 3–2000
observations, at most 10000 components, `N*N*components <= 200 million`,
10000 iterations, and a 64 MiB CLI input. Use a scalable upstream implementation
for larger data. Perplexity must be greater than one and at most `N-1`. Tied
nearest neighbors can impose a higher minimum; unattainable calibration and
coincident observations produce an explicit failure. Uniform global distance
rescaling prevents overflow and preserves the affinity model; it does not
standardize individual components.

`results.tsv` preserves observation order and has `TSNE1` and `TSNE2` columns.
`session.yaml` records all effective settings, JVM version, initial/final KL,
entropy-calibration error and optimizer stopping reason. `diagnostics.tsv`
records the unexaggerated KL and the current gradient norm. Reaching an iteration
budget is reported as `iteration-limit`, not a claim of convergence. A run that
fails to improve KL retains diagnostics and `WARNINGS.md` and publishes no
successful coordinates. The CLI returns status 2 with clear corrective actions.

Frozen tests compare exact affinities, KL and gradients against scikit-learn
1.8.0, then independently check finite-difference derivatives, scale/translation
invariance, reproducibility, and local-neighbor recovery on structured data.
Reference dependency versions/hashes and refresh code are in
`src/test/resources/tsne/` and `tools/literature/verify_tsne.py`. Optimized
coordinates are not asserted to match a different optimizer. This implementation
follows [van der Maaten and Hinton (2008)](https://www.jmlr.org/papers/v9/vandermaaten08a.html);
it does not implement Barnes-Hut/FFT acceleration or out-of-sample transformation.

### Optional upstream cell representations

The adapter consumes supplied PCA coordinates with an `obs_id` first column.
It does not normalize counts, infer cell identities, or perform population
inference from clusters. It pins upstream package versions and records versions,
seed, graph definition, result identities, input/output hashes and process logs.

```powershell
python tools/literature/install_cell_dependencies.py --allow-install --allow-source-build
java -jar build/cli/omicsmatic-0.3.7.jar cell-embed --method umap `
  --matrix pca.tsv --python build/omics-cell-tools-env/Scripts/python.exe `
  --neighbors 15 --seed 1 --out build/review-umap
```

The installer uses a new private managed environment, retains each installation
attempt and pip report, and never modifies an unmanaged environment. Omit
`--allow-install` when installation is forbidden; dependencies are then explicitly
skipped. Source builds require the additional `--allow-source-build` flag.

UMAP uses the upstream Euclidean embedding. Leiden and Louvain operate on an
explicit weighted union kNN graph; this differs from Seurat SNN or Scanpy fuzzy
graphs. Exact graph construction has a documented work bound. Alternatively supply
the original weighted graph directly:

```powershell
java -jar build/cli/omicsmatic-0.3.7.jar cell-embed --method leiden `
  --nodes nodes.tsv --graph edges.tsv --resolution 1 --seed 17 `
  --python build/omics-cell-tools-env/Scripts/python.exe --out build/review-graph
```

`nodes.tsv` has one `obs_id` column listing every node, including isolates.
`edges.tsv` has `source`, `target`, `weight` columns in that order. Edges are
undirected and weights must be positive and finite. Self-loops, duplicate/reversed
edges, unknown endpoints and zero-edge graphs are rejected. No graph normalization
or neighborhood inference occurs. The canonical graph and original weights are
retained in `graph.tsv`; session metadata records isolates, objective and seed.
Limits are 100,000 nodes, 1,000,000 edges and 128 MiB per table. Do not combine this
form with `--matrix` or `--neighbors`. Both real engines passed a known two-community
fixture with an isolated node and repeatability checks. For P061 this accepts its
weighted confusion-matrix graph after explicit construction; its upstream matrix
construction and biological biclustering interpretation remain separate steps.

Harmony requires
metadata with an explicit batch column and the exact observation universe.

**Skipped and failed attempts remain visible.** A missing/incompatible dependency
produces `analysis-status.json`, `WARNINGS.md`, process logs and a manifest, returns
status 3 and publishes no successful `results.tsv`. Other execution failures
return 2 with recovery instructions. Installation success is separate from
analysis validation. See [WARNINGS.md](WARNINGS.md) for this environment's outcome.

### BWA and Bowtie 2 read mapping

The [read-alignment guide](ALIGNMENT_WORKFLOWS.md) covers sealed reference indexes,
official Bowtie 2 small/large binaries, unmodified-source BWA MEM/backtrack,
gzipped single/paired reads, sample metadata, exact primary-read validation and
actionable runtime/build failures. It connects reviewed paper settings to typed
options and distinguishes the separate, still-missing BWA-MEM2 implementation.

### SAMtools and BCFtools alignment/variant workflows

The [HTS workflow guide](HTS_WORKFLOWS.md) covers native Java FASTA indexing plus eleven typed source commands:
BAM selection, sorting/indexing, flagstat, a complete fixmate/markdup pipeline,
raw pileup, diploid/haploid variant calling, normalization, QUAL soft filters,
sample selection and variant statistics. It documents pinned Windows setup,
paper-specific settings, model choices, preserved outputs and exact skip/error
recovery actions. These are tested upstream 1.24 operations; published versions
and unexposed pipeline steps remain separate work.

### Picard alignment processing and QC

`alignment-tools` runs the official [Picard 3.5.0 release](https://github.com/broadinstitute/picard/releases/tag/3.5.0)
as a separate Java application. Its published JAR SHA-256 is checked before use;
it requires Java 17 or newer. This adapter exposes four operations, with typed
options and strict SAM/BAM checks; it does not implement all Picard programs.

```powershell
python tools/literature/install_picard.py --allow-download
java -jar build/cli/omicsmatic-0.3.7.jar alignment-tools --method sort `
  --input aligned.sam --picard build/omics-picard/picard.jar `
  --create-index true --out build/review-sorted
java -jar build/cli/omicsmatic-0.3.7.jar alignment-tools --method mark-duplicates `
  --input build/review-sorted/alignment.bam --picard build/omics-picard/picard.jar `
  --remove-duplicates true --out build/review-deduplicated
java -jar build/cli/omicsmatic-0.3.7.jar alignment-tools --method validate `
  --input build/review-deduplicated/alignment.bam --picard build/omics-picard/picard.jar `
  --out build/review-validation
java -jar build/cli/omicsmatic-0.3.7.jar alignment-tools --method alignment-summary `
  --input build/review-deduplicated/alignment.bam --reference reference.fa `
  --picard build/omics-picard/picard.jar --out build/review-alignment-metrics
```

Sorting defaults to coordinate order; `--sort-order queryname` is also checked.
Duplicate marking requires both a coordinate header and actual coordinate order;
it marks rather than removes by default. `--remove-duplicates true` requests removal.
Upstream default base-quality scoring/read-name parsing apply. Choose optical pixel
distance for your instrument explicitly (`--optical-distance`, default 100;
Picard recommends 2500 for relevant patterned flowcells). Review upstream warnings
and `duplication_metrics.txt`; PCR duplicates and optical duplicate estimates need
assay and read-name context. P007 used Picard 3.0.0 for ATAC-seq/CUT&Tag PCR duplicate
removal; our 3.5.0 fixture validation does not establish older-version equivalence.

Alignment summary requires a local FASTA and matching `.fai` and `.dict` sidecars;
their hashes are retained. CRAM/reference retrieval, RNA metrics and read-group
editing are outside this adapter. Default memory is 2048 MiB, sortable records
in memory 100,000 and timeout 3600 seconds; change the typed options to suit the
available resources. Temporary spilling remains inside the retained result bundle.

**Read the status and warnings.** A missing/wrong JAR or unavailable Java skips
with CLI status 3. Installation is explicit: omit `--allow-download` if forbidden;
the helper preserves unmanaged or corrupt installations and explains how to recover.
Execution failures return 2, quarantine partial outputs and publish no `results.tsv`.
Validation runs preserve their findings in `validation.txt`: warnings return 0,
errors return **4**, and both create prominent `WARNINGS.md`. Status 4 means the QC
ran and found errors; correct them before downstream analysis. Other upstream
warnings are promoted to `WARNINGS.md` and the console. Commands, version probe,
package checksum, input/output counts, hashes and logs are retained. See the
[upstream command documentation](https://broadinstitute.github.io/picard/command-line-overview.html)
for biological and sequencing-platform decisions.

The executable fixture also exercised paired reads: two complete pairs with one
duplicate pair; removal retained two aligned records, one of each mate, and full
mate validation passed. Evidence: `picard-paired-validation.json` and its retained
SAM/BAM/metrics bundles. On newer JVMs Picard may emit native-access warnings even
with JDK compression selected. They remain visible in `WARNINGS.md`; use a Java
17/21 runtime through `--java JAVA` if those warnings occur. They do not by
themselves mean the analysis failed.

### Sequencing quality control and adapter trimming

`sequence-qc` executes pinned Cutadapt 5.2, FastQC 0.13.0 and MultiQC 1.35. It
uses typed options, independent input/output validation, retained commands,
dependency versions/environment snapshots, source hashes and upstream logs.
Install only in an allowed environment:

```powershell
python tools/literature/install_cell_dependencies.py --profile sequence --allow-install
python tools/literature/install_fastqc.py --allow-download
```

These helpers use private directories and preserve existing unmanaged data.
The FastQC release archive must match the publisher SHA-256 before extraction;
the installed release retains its license, configuration and dependency files.
Existing verified dependencies can be used when further installation is
forbidden. Failed/forbidden installation returns an explicit skip and recovery
steps; successful installation is separate from successful analysis.

Input reads are unwrapped, four-line IUPAC DNA/RNA FASTQ, plain or gzip, using
Phred+33. The command checks every sequence/quality length and both mates'
identities/order after removing terminal `/1` or `/2`. It does not infer quality
encoding. Each read is limited to ten million bases; processing streams without
retaining the reads in memory.

```powershell
java -jar build/cli/omicsmatic-0.3.7.jar sequence-qc --method cutadapt `
  --python build/omics-sequence-tools-env/Scripts/python.exe `
  --reads R1.fastq.gz --reads2 R2.fastq.gz `
  --adapter3 AGATCGGAAGAGC --adapter3-2 AGATCGGAAGAGC `
  --minimum-length 20 --quality-cutoff 20 --out build/trimmed

java -jar build/cli/omicsmatic-0.3.7.jar sequence-qc --method fastqc `
  --fastqc-home build/omics-fastqc/FastQC `
  --reads R1.fastq.gz --reads2 R2.fastq.gz --out build/read-qc

java -jar build/cli/omicsmatic-0.3.7.jar sequence-qc --method multiqc `
  --python build/omics-sequence-tools-env/Scripts/python.exe `
  --reports qc-reports.tsv --out build/combined-qc
```

Adapter sequences are assay inputs; the examples do not infer the correct
sequence for a library. The Cutadapt workflow exposes regular 3-prime adapters,
3-prime quality trimming, `--cut-left` on both mates, minimum length, overlap,
error rate and cores. Paired reads are discarded together if either mate fails
minimum length. Original upstream processing order applies: a fixed cut inside
Cutadapt is not the same as P001's separate fixed-cut step after adapter removal.
Linked/5-prime adapters and demultiplexing require further integration. Outputs
include compressed trimmed FASTQ, `cutadapt.json`, `cutadapt.log` and validated
read-count summaries.

FastQC is launched through its compiled Java entry point, without a Python
launcher. It retains per-file HTML/ZIP reports and a module-status table, and
checks the report version, filename and read total. **WARN/FAIL quality flags
remain visible in `WARNINGS.md` and are not converted into an execution failure
or automatic read removal.** Interpret the modules in the assay/library context
before using the reads downstream.

The MultiQC manifest has columns `sample_id`, `fastqc_zip`, `cutadapt_json`;
provide one or both paths in each row, relative to the manifest or absolute.
Sample IDs are unique ignoring case and contain 1–100 ASCII letters, digits,
underscore, dot or hyphen. Reports are explicitly copied and hashed; scanning
is restricted to those staged inputs. Naming is explicitly mapped to sample
IDs, then exact identities and unscaled raw read counts are checked against
the sources. This prevents silent overwrites when original FASTQ filenames
coincide. Limits are 10,000 rows, 64 MiB per report and 2 GiB total staging.
The HTML and central raw JSON exports remain available. MultiQC AI summaries,
version checks and MegaQC uploads are disabled. `MULTIQC_*` environment overrides
are excluded from child processes; discovered standard user config files are
hashed in the environment snapshot, and naming/output identity checks still
apply.

Unavailable/incompatible dependencies return status 3 with a persisted skip.
Other failures return status 2. Both retain actionable diagnostics; generated
partial analysis outputs are quarantined under `partial/` and no successful
`results.tsv` is published. A completed FastQC run can carry QC findings while
returning status 0. Use a new output directory after correcting the cause.

Real upstream tests cover exact and partial adapter matches, quality tails,
minimum-length filtering, paired fixed cuts/order, low-quality FastQC flags,
and two-sample aggregation with colliding original filenames and different
read counts. The first MultiQC fixture exposed its 1.35 export-layout change;
the adapter now validates the actual `report_saved_raw_data` export. This is a
documented workflow subset, not a claim that every cited package version or
paper-specific option is reproduced.

### Native post-adapter fixed trimming

`sequence-qc --method trim-fixed` performs fixed-span clipping directly in Java.
It exposes the P001 FASTX-Trimmer role as an independent post-adapter step:

```powershell
java -jar build/cli/omicsmatic-0.3.7.jar sequence-qc --method trim-fixed `
  --reads build/trimmed/trimmed_R1.fastq.gz --first-base 2 `
  --out build/post-adapter-clipped
```

Positions are one-based and inclusive on the supplied read. `--last-base 0`
(default) retains through the end; a specified end beyond the read is clamped.
`--minimum-length` defaults to one. Missing/short retained spans are discarded.
With `--reads2`, both mates use the same span and the pair is discarded if
either fails. Headers and clipped qualities are preserved; plus lines are
canonicalized. Empty retained output produces a prominent warning and count
summary. Invalid inputs quarantine partial outputs and return status 2.

The public API is `FixedReadTrimmer.clip(read, options)`, supported by streaming
`FastqIO.Reader`/`Writer`. Eighty frozen results compare against actual Cutadapt
5.2 fixed-cut/length/filter runs, independently checking coordinates, quality
alignment and filtered identities. Fixtures/provenance are under
`src/test/resources/fixed-trim`; refresh with
`tools/literature/verify_fixed_trim.py`. This independently implemented span
operation uses FASTX-Trimmer-like coordinates; full FASTX-Toolkit programs,
FASTA and Phred+64 modes are outside its contract.

### Explicit R Harmony engine on Windows

The R Harmony 2.0.5 engine installs and runs on this Windows environment. The
failed harmonypy 2.1.0 attempt remains a separate Python-engine skip. Select
the R engine explicitly; no automatic result substitution occurs.

```powershell
& 'C:/Program Files/R/R-4.6.1/bin/Rscript.exe' --vanilla `
  tools/literature/install_harmony_dependencies.R `
  build/omics-harmony-r build/literature-review/harmony-r-dependency allow

java -jar build/cli/omicsmatic-0.3.7.jar cell-embed --method harmony --engine r `
  --rscript 'C:/Program Files/R/R-4.6.1/bin/Rscript.exe' `
  --r-library build/omics-harmony-r --matrix pca.tsv `
  --metadata cells.tsv --batch batch --seed 1 --out build/harmony-r-results
```

Adjust the Rscript path to the installed R runtime. The helper checks the pinned
version, installs only required dependencies in a private library, and preserves
an unmanaged existing library. Replace `allow` with `forbid` to prohibit new
installation. CRAN Windows binaries avoid the Python package's MSVC build issue;
installed package versions, paths and checks are retained. Missing or incompatible
dependencies still skip with status 3 and explicit recovery actions.

Input PCA/metadata are headered TSVs with the same unique `obs_id` universe;
metadata is aligned by ID. At least two nonblank batches and finite nonzero
observation rows are required. Limits are 4–100000 observations, 256 components,
five million input coordinate values, ten million observation-cluster entries,
and 128 MiB per input table. Default clusters are
`min(100,max(2,round(N/30)))`, deliberately avoiding the upstream one-cluster
default on tiny datasets. Parameters include `--theta 2 --lambda 1 --sigma 0.1
--iterations 10 --early-stop true`; this adapter uses fixed positive lambda
and one core. Optional `--clusters` and a nonnegative 32-bit seed are explicit.

Outputs preserve IDs/order and all coordinate dimensions. R session/package
versions, effective settings, the upstream algorithm-options object, exploratory
before/after batch centroids, commands and hashes accompany the corrected
coordinates. The adapter records the requested iteration/early-stop settings
without claiming an independently verified convergence state. Upstream warnings
remain visible. Real tests check deterministic repeat, metadata reordering,
batch-shift reduction and retained independent cell-type signal on a balanced
synthetic fixture. This does not establish parity with Python/legacy Harmony
or prove valid correction when batch and biology are confounded.

## Reproduce the catalog

```powershell
python -m unittest discover -s tools/literature -p 'test_*.py'
python tools/literature/collect_omics_review.py --workers 3 --limit-per-journal 160
python tools/literature/audit_catalog.py
python tools/literature/render_review.py
```

For a registry expansion after freezing the cohort, use
`python tools/literature/enrich_fixed_catalog.py` followed by the audit and
renderer. It retains all 250 paper identities and records added/removed tool
observations in `catalog-enrichment.json`.

The first run downloads public source texts into the ignored build cache. Later
runs re-extract cached sources. Do not run `gradlew clean` before the offline
catalog audit unless you intend to reacquire the source cache and optional
environment. The full-source audit checks all 250 DOI/source identities and every
published paragraph hash. `SHA256SUMS` covers the published catalog bundle.

The [implementation queue](implementation-plan.md) and `tool-inventory.json`
distinguish missing tools, related existing methods, existing adapters/lookups,
and newly validated subsets. Complete the remaining integrations and semantic
coverage review before marking the overall goal complete.

</details>

</details>

</details>

</details>

</details>

</details>

</details>

</details>

</details>

</details>

</details>

</details>


## MALT family source types and required actions

Three source-reviewed tool additions retain separate provenance: MALT and HOPS have main-article JATS anchors; MaltExtract is named in the P002 supplementary DOCX, section 3.3. Its `evidence_source_kind` is `supplementary-docx`, and paragraph index 246 is zero-based over all Word paragraphs, including empty ones. It is not a main-article paragraph. MALT's four supplementary supporting pointers identify the separate custom 0.5.2 reference-building/screening role. The version is 0.5.2 followed by superscript citation 61; the concatenated text is not version 0.5.261.

These additions improve the catalog and add no whole-tool or biological credit. The source-tested MALT 0.4.1 development controller does not fulfill the separate 0.5.2 role. Complete HOPS and MaltExtract operations remain unfinished; their unreported versions, settings and resource choices remain unknown. See `MALT_ALIGNMENT.md` and `MALT_HOPS_PAPER_ROLES.md`.

**Required action:** match the declared source version and operation, qualify a permitted runtime, provide the complete dated reference/mapping and query populations, and retain original warnings and failures. If any prerequisite is unavailable or cannot be installed, skip its dependent analysis. A small software-control index does not reproduce the historical 91-spirochete or 7,508-genome bacterial analyses. Insufficient-read candidates remain unassessable.

</details>

</details>

</details>

</details>

</details>

</details>

</details>

</details>

</details>

</details>

</details>
