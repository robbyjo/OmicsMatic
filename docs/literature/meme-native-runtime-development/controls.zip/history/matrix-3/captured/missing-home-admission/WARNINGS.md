

# NO RUNTIME OR USER ANALYSIS ADMITTED

org.jlinalg.cli.TomtomRuntime$Unavailable: Exact original MEME/Tomtom home is absent. Complete explicit permitted setup, or skip dependent analysis.

Required action: inspect WARNINGS.md, FAILURE.json when present, metadata/host.json, every retained probe/process stdout/stderr/ledger and the complete source/build evidence. Missing or forbidden dependencies/capabilities require a named SKIP3 and instructions to supply them on a permitted host; analysis never installs. Correct failures and retry into NEW private canonical Linux paths. A copied receipt is not a current-host runtime ticket. User input, requested settings, supervised execution, complete requested outputs and final bundle verification remain separate gates.
