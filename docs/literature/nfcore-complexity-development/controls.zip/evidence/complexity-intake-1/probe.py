import os,shutil,json
from pathlib import Path
for name in ['picard','preseq','annotatePeaks.pl','parseGTF.pl']:
 p=Path(shutil.which(name));print(name,str(p));data=p.read_bytes()
 if data.startswith(b'#!'):print(data.decode()[:300] if name=='picard' else '')
 if name in ['parseGTF.pl','annotatePeaks.pl']:(Path(__file__).parent/p.name).write_bytes(data)
for root,dirs,files in os.walk('/opt/conda/share'):
 for name in files:
  if 'picard' in name and name.endswith('.jar'):print('PICARD_JAR',str(Path(root)/name))
