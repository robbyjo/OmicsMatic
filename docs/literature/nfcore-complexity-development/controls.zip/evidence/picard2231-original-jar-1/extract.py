import os,shutil
from pathlib import Path
matches=[]
for root,dirs,files in os.walk('/opt/conda/envs/nf-core-chipseq-1.2.1/share'):
 for name in files:
  if name=='picard.jar':matches.append(Path(root)/name)
assert len(matches)==1,matches
shutil.copyfile(matches[0],Path(__file__).parent/'original-picard.jar')
print(str(matches[0]))
