# Library-complexity component only

WARNING: Optical duplicate counts remain original-engine classifications. The native audit verifies their count bounds and use in the source library-size formula; it does not independently infer optical read clusters.

WARNING: Preseq estimates and confidence intervals remain original-engine outputs. Complete finite/grid/order/bound consistency is checked; passing this component does not independently validate the extrapolation model or biological library complexity.

Required action: this is a source-specific library-complexity component, with no nf-core tool, whole-pipeline or biological admission. It counts the full original marked BAM and checks Picard 2.23.1 derived formulas and complete published histograms. It does not independently mark duplicates, identify optical duplicates or recompute Preseq extrapolation/CI. Retain all raw counts, original absent/nonfinite estimates, coordinate conventions, failed attempts and warnings. FAIL2 means no component result: inspect the named count, integrity, output or capacity discrepancy, correct its cause and retry a NEW directory. No producer work paths or substitute tools are used. Hashes establish integrity, not execution authenticity.
