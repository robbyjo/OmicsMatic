from pathlib import Path
import json,subprocess,sys,urllib.request,hashlib,shutil
sys.path.insert(0,str(Path('tools/literature').resolve()))
from validate_nfcore_engine import ROOT,BASE,DISTRO,linux
from setup_deseq2_reference import pin,save
out=BASE/'complexity-intake-1';out.mkdir();source=BASE/'picard2231-source-intake-1';name='src/main/java/picard/sam/markduplicates/util/AbstractMarkDuplicatesCommandLineProgram.java'
url='https://raw.githubusercontent.com/broadinstitute/picard/2.23.1/'+name
with urllib.request.urlopen(url,timeout=60) as r:raw=r.read(1048577)
assert len(raw)<=1048576;(out/'AbstractMarkDuplicatesCommandLineProgram.java').write_bytes(raw);save(out/'SOURCE.json',dict(url=url,**pin(out/'AbstractMarkDuplicatesCommandLineProgram.java')))
script=out/'probe.py';script.write_text('''import os,shutil,json
from pathlib import Path
for name in ['picard','preseq','annotatePeaks.pl','parseGTF.pl']:
 p=Path(shutil.which(name));print(name,str(p));data=p.read_bytes()
 if data.startswith(b'#!'):print(data.decode()[:300] if name=='picard' else '')
 if name in ['parseGTF.pl','annotatePeaks.pl']:(Path(__file__).parent/p.name).write_bytes(data)
for root,dirs,files in os.walk('/opt/conda/share'):
 for name in files:
  if 'picard' in name and name.endswith('.jar'):print('PICARD_JAR',str(Path(root)/name))
''',encoding='utf8',newline='\n')
cmd=['wsl.exe','-d',DISTRO,'--exec','/var/tmp/omicsmatic-nfcore-apptainer-1/bin/apptainer','exec','--userns','--no-home','--pid','-B',linux(out)+':'+linux(out),'/var/tmp/omicsmatic-nfcore-images-1/nfcore-chipseq-1.2.1.sif','python',linux(script)]
r=subprocess.run(cmd,capture_output=True,timeout=120);(out/'stdout').write_bytes(r.stdout);(out/'stderr').write_bytes(r.stderr);save(out/'process.json',dict(command=cmd,exit_code=r.returncode));assert r.returncode==0,r.stderr;print(r.stdout.decode())
