"""Explicit private preparation of every statically declared ChIP-seq2.0.0 SIF; no scientific analysis."""
from pathlib import Path
import argparse,concurrent.futures,hashlib,json,os,subprocess,sys,threading,time,traceback,urllib.request,urllib.error
if sys.platform!='linux':raise SystemExit(subprocess.call(['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--exec','/usr/bin/python3','/mnt/d/projects/JLinAlg/build/literature-review/nfcore-runtime/prepare_chipseq200_images1.py',*sys.argv[1:]]))
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--allow-download',action='store_true');a=p.parse_args()
if not a.allow_download:raise SystemExit('SKIP3 dependent analysis skipped: explicit --allow-download is required for separate prerequisite setup.')
root=Path('/mnt/d/projects/JLinAlg');base=root/'build/literature-review/nfcore-runtime';out=base/'chipseq200-images-1';out.mkdir();images=Path('/var/tmp/omicsmatic-nfcore-chipseq200-images-1');images.mkdir();assert images.resolve()==images
source_path=base/'chipseq200-container-source-intake-3/COMPLETED.json';source=json.loads(source_path.read_bytes());assert source['status']=='PASS_CHIPSEQ200_ORIGINAL_CONTAINER_DECLARATION_INTAKE_ONLY' and source['unique_images']==33
apptainer=Path('/var/tmp/omicsmatic-nfcore-apptainer-1/bin/apptainer');lock=threading.Lock();total=0;limit=30*1024**3;per_image=5*1024**3
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf8',newline='\n')
def pin(path):
 h=hashlib.sha256();n=0
 with path.open('rb') as f:
  for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk);n+=len(chunk)
 return dict(bytes=n,sha256=h.hexdigest())
def fetch(index,row):
 global total
 label=f'image-{index:03d}';report=dict(source=row,status='FAIL2_IMAGE_PREPARATION_NO_ADMISSION');partial=images/(label+'.download.part');started=time.monotonic()
 try:
  url=row['singularity'];assert url.startswith('https://depot.galaxyproject.org/singularity/') and len(row['modules'])>0
  req=urllib.request.Request(url,headers={'User-Agent':'OmicsMatic-permitted-private-runtime-setup'})
  digest=hashlib.sha256();size=0
  with urllib.request.urlopen(req,timeout=90) as response,partial.open('xb') as output:
   length=response.headers.get('Content-Length');expected=int(length) if length is not None else None
   if expected is not None and expected>per_image:raise ValueError('Image exceeds explicit 5GiB complete-file capacity')
   report['response']=dict(url=response.url,content_length=expected,etag=response.headers.get('ETag'),last_modified=response.headers.get('Last-Modified'))
   for chunk in iter(lambda:response.read(1048576),b''):
    size+=len(chunk)
    with lock:
     total+=len(chunk)
     if total>limit:raise ValueError('Image preparation exceeds explicit 30GiB complete-download capacity')
    if size>per_image:raise ValueError('Image exceeds explicit 5GiB complete-file capacity')
    output.write(chunk);digest.update(chunk)
  if expected is not None and size!=expected:raise ValueError('Upstream response Content-Length differs from complete downloaded bytes')
  identity=dict(bytes=size,sha256=digest.hexdigest());assert pin(partial)==identity
  image=images/(label+'-'+identity['sha256']+'.sif');assert not image.exists();partial.rename(image)
  with (out/(label+'.inspect.stdout')).open('xb') as so,(out/(label+'.inspect.stderr')).open('xb') as se:r=subprocess.run([str(apptainer),'inspect','--json',str(image)],stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=120)
  if r.returncode!=0:raise ValueError('Original Apptainer cannot inspect the complete downloaded SIF; exit '+str(r.returncode))
  assert pin(image)==identity;report.update(status='PASS_SOURCE_DECLARED_SIF_PREPARATION_ONLY',image=str(image),image_pin=identity,inspect_exit_code=r.returncode)
 except (urllib.error.HTTPError,urllib.error.URLError,TimeoutError) as error:report.update(status='SKIP3_REQUIRED_IMAGE_UNAVAILABLE',cause=repr(error))
 except PermissionError as error:report.update(status='SKIP3_INSTALL_FORBIDDEN',cause=repr(error))
 except Exception as error:report.update(cause=repr(error),traceback=traceback.format_exc())
 report.update(elapsed_seconds=round(time.monotonic()-started,3),partial_retained=partial.exists(),scientific_analysis_executed=False,new_catalog_credit=False);save(out/(label+'.json'),report);print(label,report['status'],row['singularity'],flush=True);return report
save(out/'STARTED.json',dict(source=pin(source_path),images=33,explicit_download_authorized=True,private_images_directory=str(images),scientific_analysis_executed=False,host_security_configuration_changed=False))
reports=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
 futures=[executor.submit(fetch,i,row) for i,row in enumerate(source['images'],1)]
 for future in concurrent.futures.as_completed(futures):reports.append(future.result())
passed=sum(r['status'].startswith('PASS_') for r in reports);status='PASS_CHIPSEQ200_SOURCE_DECLARED_SIF_PREPARATION_ONLY' if passed==33 else 'FAIL2_CHIPSEQ200_IMAGE_PREPARATION_NO_PROFILE_ADMISSION' if any(r['status'].startswith('FAIL2_') for r in reports) else 'SKIP3_CHIPSEQ200_DEPENDENT_ANALYSES_SKIPPED'
action='No scientific analysis executed. The prepared image bytes require separate exact runtime/source binding, engine/full-input/full-output controls before nf-core admission. Missing/forbidden prerequisites skip the affected analysis. Resolve each named download/permission/integrity/capacity cause and retry NEW setup paths; retain partials and all completed images. Do not substitute versions or shrink branches to conceal failures. Recorded SHA-256 is integrity, not image authenticity or author-history evidence.'
save(out/'COMPLETED.json',dict(status=status,source_intake=pin(source_path),requested_images=33,prepared_images=passed,complete_download_bytes=total,results=sorted(reports,key=lambda r:r['source']['singularity']),scientific_analysis_executed=False,new_catalog_credit=False,host_security_configuration_changed=False,required_action=action));(out/'WARNINGS.md').write_text('# '+status+'\n\n'+('\n\n'.join(r['source']['singularity']+': '+r.get('cause','') for r in reports if not r['status'].startswith('PASS_')) or 'Container preparation and inspection only; no workflow or biological result.')+'\n\nREQUIRED ACTION: '+action+'\n',encoding='utf8',newline='\n');print(status,passed,'of33',flush=True);raise SystemExit(0 if passed==33 else 3 if status.startswith('SKIP3') else 2)
