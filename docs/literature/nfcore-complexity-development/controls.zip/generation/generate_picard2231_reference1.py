from pathlib import Path
import json,subprocess,sys,zipfile
sys.path.insert(0,str(Path('tools/literature').resolve()))
from setup_deseq2_reference import ROOT,pin,save
from validate_nfcore_engine import BASE,DISTRO,JAVA,linux
out=BASE/'picard2231-original-reference-1';out.mkdir();classes=out/'classes';classes.mkdir();jar=BASE/'picard2231-original-jar-1/original-picard.jar';jp=pin(jar)
source=ROOT/'tools/literature/java/PicardComplexityOriginal.java';cmd=[str(JAVA/'javac.exe'),'--release','8','-encoding','UTF-8','-Xlint:all','-Werror','-sourcepath','','-cp',str(jar),'-d',str(classes),str(source)];r=subprocess.run(cmd,capture_output=True,timeout=60);assert r.returncode==0,r.stderr
attempt=BASE/'scientific-cross-platform-2/original-complete-attempt';outputs=json.loads((attempt/'outputs.json').read_bytes())['members'];rows=[]
for name,v in outputs.items():
 if name.endswith('.MarkDuplicates.metrics.txt'):
  lines=(attempt/'objects'/v['pin']['sha256']).read_text().splitlines();i=next(i for i,s in enumerate(lines) if s.startswith('LIBRARY\t'))
  for line in lines[i+1:]:
   if not line:break
   f=line.split('\t');rows.append([f[0],*f[1:3],*f[5:8]])
for name,values in [
 ('empty',[0,0,0,0,0]),('unpaired',[1000,0,100,0,0]),('no_duplicates',[0,100,0,0,0]),('all_duplicates',[0,100,0,100,0]),('all_optical',[0,100,0,100,100]),('single_duplicate',[0,1,0,1,0]),('half_duplicates',[0,100,0,50,0]),('optical_subset',[0,100,0,50,25]),('mixed',[1000,10,999,9,8]),('rare_duplicates',[0,1000000,0,1,0]),('large_counts',[0,1000000000000,0,100000000000,50000000000]),('one_unique',[0,1000000,0,999999,0]),('optical_equals_duplicates',[0,1000000,0,150000,150000]),('unpaired_only_duplicates',[1000,1000,100,0,0])]:rows.append([name,*map(str,values)])
input=out/'input.tsv';input.write_text('case\tunpaired\tpaired\tunpaired_duplicates\tpaired_duplicates\toptical_duplicates\n'+'\n'.join('\t'.join(r) for r in rows)+'\n',encoding='utf8',newline='\n')
commands={'windows21':[str(JAVA/'java.exe'),'-cp',str(classes)+';'+str(jar),'PicardComplexityOriginal',str(input),str(out/'windows21.tsv')],
 'original_image':['wsl.exe','-d',DISTRO,'--exec','/var/tmp/omicsmatic-nfcore-apptainer-1/bin/apptainer','exec','--userns','--no-home','--pid','-B',linux(ROOT)+':'+linux(ROOT),'/var/tmp/omicsmatic-nfcore-images-1/nfcore-chipseq-1.2.1.sif','java','-cp',linux(classes)+':'+linux(jar),'PicardComplexityOriginal',linux(input),linux(out/'original_image.tsv')]}
for label,cmd in commands.items():
 r=subprocess.run(cmd,capture_output=True,timeout=120);(out/(label+'.stdout')).write_bytes(r.stdout);(out/(label+'.stderr')).write_bytes(r.stderr);save(out/(label+'.process.json'),dict(command=cmd,exit_code=r.returncode));assert r.returncode==0,r.stderr
assert pin(jar)==jp;save(out/'COMPLETED.json',dict(status='PASS_ORIGINAL_PICARD2231_NUMERIC_REFERENCE_INTAKE_ONLY',cases=len(rows),original_jar=jp,reference_pins={n:pin(out/(n+'.tsv')) for n in commands},upstream_results_identical=(out/'original_image.tsv').read_bytes()==(out/'windows21.tsv').read_bytes()));print('Original references',len(rows),'cases','identical',(out/'original_image.tsv').read_bytes()==(out/'windows21.tsv').read_bytes())
