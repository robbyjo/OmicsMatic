from pathlib import Path
import json,subprocess,sys
sys.path.insert(0,str(Path('tools/literature').resolve()))
from validate_nfcore_engine import ROOT,BASE,DISTRO,linux
from setup_deseq2_reference import pin,save
out=BASE/'picard2231-original-jar-1';out.mkdir();script=out/'extract.py'
script.write_text('''import os,shutil
from pathlib import Path
matches=[]
for root,dirs,files in os.walk('/opt/conda/envs/nf-core-chipseq-1.2.1/share'):
 for name in files:
  if name=='picard.jar':matches.append(Path(root)/name)
assert len(matches)==1,matches
shutil.copyfile(matches[0],Path(__file__).parent/'original-picard.jar')
print(str(matches[0]))
''',encoding='utf8',newline='\n')
cmd=['wsl.exe','-d',DISTRO,'--exec','/var/tmp/omicsmatic-nfcore-apptainer-1/bin/apptainer','exec','--userns','--no-home','--pid','-B',linux(out)+':'+linux(out),'/var/tmp/omicsmatic-nfcore-images-1/nfcore-chipseq-1.2.1.sif','python',linux(script)]
r=subprocess.run(cmd,capture_output=True,timeout=120);(out/'stdout').write_bytes(r.stdout);(out/'stderr').write_bytes(r.stderr);assert r.returncode==0,r.stderr;save(out/'COMPLETED.json',dict(status='PASS_ORIGINAL_PRIVATE_PICARD2231_JAR_INTAKE_ONLY',jar=pin(out/'original-picard.jar'),command=cmd,exit_code=r.returncode));print('Original Picard JAR',pin(out/'original-picard.jar'))
