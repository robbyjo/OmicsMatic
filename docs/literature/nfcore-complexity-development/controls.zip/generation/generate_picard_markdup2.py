from pathlib import Path
import json,subprocess,sys,shutil
sys.path.insert(0,str(Path('tools/literature').resolve()))
from setup_deseq2_reference import ROOT,pin,save
from validate_nfcore_engine import BASE,DISTRO,linux
out=BASE/'picard2231-markdup-controls-2';out.mkdir();attempt=BASE/'scientific-cross-platform-2/original-complete-attempt';outputs=json.loads((attempt/'outputs.json').read_bytes())['members'];sample='SPT5_INPUT_R1';rg=sample+'_T1'
p=out/'optical_and_flags';p.mkdir();(p/'genome.fa').write_text('>chr1\n'+'A'*1000+'\n',encoding='ascii');(p/'library.txt').write_text(sample+'\n',encoding='utf8');(p/'case.properties').write_text('preseq-requested=false\n',encoding='utf8')
for name in ['design_reads.csv','design_controls.csv']:
 v=outputs['pipeline_info/'+name]['pin'];shutil.copyfile(attempt/'objects'/v['sha256'],p/name)
records=[]
def read(name,flag,pos,mpos=0,rname='chr1',mate='*',length=0):
 seq='AAAAAAAAAA';mapped=(flag&4)==0;records.append((pos if mapped else 2000,'\t'.join(map(str,[name,flag,rname if mapped else '*',pos if mapped else 0,60 if mapped else 0,'10M' if mapped else '*',mate,mpos,length,seq,'IIIIIIIIII','RG:Z:'+rg]))))
for i,(x,y) in enumerate([(100,100),(105,105),(1000,1000)]):
 name='A:1:FC:1:1101:'+str(x)+':'+str(y);read(name,99,100,150,mate='=',length=60);read(name,147,150,100,mate='=',length=-60)
name='A:1:FC:1:1101:2000:2000';read(name,99,300,350,mate='=',length=60);read(name,147,350,300,mate='=',length=-60)
for name in ['A:1:FC:1:1101:3000:3000','A:1:FC:1:1101:4000:4000']:read(name,0,400)
read('A:1:FC:1:1101:5000:5000',73,500,0,mate='*');read('A:1:FC:1:1101:5000:5000',133,0,500,mate='chr1')
read('A:1:FC:1:1101:6000:6000',512,600);read('A:1:FC:1:1101:7000:7000',256,700);read('A:1:FC:1:1101:7500:7500',2048,750);read('A:1:FC:1:1101:8000:8000',4,0)
(p/'input.sam').write_text('@HD\tVN:1.6\tSO:coordinate\n@SQ\tSN:chr1\tLN:1000\n@RG\tID:'+rg+'\tSM:'+sample+'\tLB:'+rg+'\tPL:ILLUMINA\n'+'\n'.join(text for _,text in sorted(records,key=lambda x:x[0]))+'\n',encoding='utf8',newline='\n')
cmd=['wsl.exe','-d',DISTRO,'--exec','/var/tmp/omicsmatic-nfcore-apptainer-1/bin/apptainer','exec','--userns','--no-home','--pid','-B',linux(ROOT)+':'+linux(ROOT),'/var/tmp/omicsmatic-nfcore-images-1/nfcore-chipseq-1.2.1.sif','picard','MarkDuplicates','INPUT='+linux(p/'input.sam'),'OUTPUT='+linux(p/'marked.bam'),'METRICS_FILE='+linux(p/'metrics.txt'),'ASSUME_SORTED=true','REMOVE_DUPLICATES=false','VALIDATION_STRINGENCY=LENIENT','TMP_DIR='+linux(p/'tmp')]
with (out/'stdout').open('xb') as so,(out/'stderr').open('xb') as se:r=subprocess.run(cmd,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=180)
save(out/'process.json',dict(command=cmd,exit_code=r.returncode));assert r.returncode==0,(out/'stderr').read_text()[-2000:]
lines=(p/'metrics.txt').read_text().splitlines();i=next(i for i,s in enumerate(lines) if s.startswith('LIBRARY\t'));data=dict(zip(lines[i].split('\t'),lines[i+1].split('\t')));assert int(data['READ_PAIR_OPTICAL_DUPLICATES'])>0,data
save(out/'COMPLETED.json',dict(status='PASS_ORIGINAL_PICARD2231_OPTICAL_AND_FLAG_CONTROL_INTAKE_ONLY',explicitly_synthetic=True,marked_records=16,source_metrics=data,files={q.relative_to(out).as_posix():pin(q) for q in p.rglob('*') if q.is_file()},scientific_result_admitted=False));print('Original optical/flags fixture',data)
