import json,urllib.request,hashlib
from pathlib import Path
out=Path('build/literature-review/nfcore-runtime/picard2231-source-intake-1');out.mkdir()
names=['src/main/java/picard/sam/DuplicationMetrics.java','src/main/java/picard/sam/markduplicates/MarkDuplicates.java','LICENSE.txt']
rows={}
for name in names:
 url='https://raw.githubusercontent.com/broadinstitute/picard/2.23.1/'+name
 with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'OmicsMatic-original-source-audit'}),timeout=60) as response:raw=response.read(1048577)
 assert len(raw)<=1048576;target=out/Path(name).name;target.write_bytes(raw);rows[name]=dict(url=url,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
(out/'SOURCE.json').write_text(json.dumps(dict(profile='Picard 2.23.1',files=rows,scientific_result_admitted=False),indent=2)+'\n',encoding='utf8');print('Pinned three original Picard source/license files')
