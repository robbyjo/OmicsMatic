from pathlib import Path
import json,re,hashlib,subprocess,sys,os,traceback
if sys.platform!='linux':raise SystemExit(subprocess.call(['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--exec','/usr/bin/python3','/mnt/d/projects/JLinAlg/build/literature-review/nfcore-runtime/inventory_chipseq200_containers2.py']))
root=Path('/mnt/d/projects/JLinAlg');base=root/'build/literature-review/nfcore-runtime';out=base/'chipseq200-container-source-intake-2';out.mkdir();source=Path('/var/tmp/omicsmatic-nfcore-sources-1/chipseq-2.0.0');lock=json.loads((root/'src/main/resources/org/jlinalg/omics/nfcore/nfcore-source-lock.json').read_bytes());profile=lock['pipelines']['chipseq-2.0.0'];rows=[];state=dict(status='FAIL2_CHIPSEQ200_CONTAINER_SOURCE_INTAKE',scientific_analysis_executed=False,new_catalog_credit=False)
try:
 pattern=re.compile(r'''^[ \t]*container[ \t]+("(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')''',re.MULTILINE)
 for name,expected in profile['files'].items():
  p=source/name;raw=p.read_bytes();assert len(raw)==expected['bytes'] and hashlib.sha256(raw).hexdigest()==expected['sha256'],name
  if not name.endswith('.nf'):continue
  text=raw.decode('utf8');matches=list(pattern.finditer(text));assert len(matches)==len(re.findall(r'^[ \t]*container[ \t]+',text,re.MULTILINE)),name
  for match in matches:
   literal=match.group(1);parts=re.findall(r"'([^']*)'",literal)
   assert len(parts)==3 and parts[0]=='singularity' and parts[1].startswith('https://depot.galaxyproject.org/singularity/') and re.fullmatch(r'[A-Za-z0-9_./-]+(?::[A-Za-z0-9_.-]+|@sha256:[a-f0-9]{64})',parts[2]),(name,literal)
   rows.append(dict(module=name,source_pin=expected,line=text[:match.start()].count('\n')+1,singularity=parts[1],oci=parts[2],source_block=match.group(0)))
 unique={}
 for row in rows:
  entry=unique.setdefault(row['singularity'],dict(singularity=row['singularity'],oci_sources=[],modules=[]))
  if row['oci'] not in entry['oci_sources']:entry['oci_sources'].append(row['oci'])
  entry['modules'].append(row['module'])
 vfs=os.statvfs('/var/tmp');state.update(status='PASS_CHIPSEQ200_ORIGINAL_CONTAINER_DECLARATION_INTAKE_ONLY',source_commit=profile['commit'],locked_source_files=len(profile['files']),complete_module_declarations=len(rows),unique_images=len(unique),declarations=rows,images=list(unique.values()),available_var_tmp_bytes=vfs.f_bavail*vfs.f_frsize,prior_parser_failure_retained=True)
except Exception as error:state.update(cause=repr(error),traceback=traceback.format_exc())
state['required_action']='Resolve and download the exact source-declared original images where permitted, record complete identities and run separate engine/runtime/full scientific controls before admission. Missing/forbidden prerequisites skip affected analyses. No author engine or image digest is inferred.'
(out/'COMPLETED.json').write_text(json.dumps(state,indent=2)+'\n',encoding='utf8',newline='\n');print(state['status'],state.get('cause',''),state.get('complete_module_declarations'),state.get('unique_images'))
raise SystemExit(0 if state['status'].startswith('PASS_') else 2)
