from pathlib import Path
import json,re,hashlib,subprocess,sys,os,traceback
if sys.platform!='linux':raise SystemExit(subprocess.call(['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--exec','/usr/bin/python3','/mnt/d/projects/JLinAlg/build/literature-review/nfcore-runtime/inventory_chipseq200_containers3.py']))
root=Path('/mnt/d/projects/JLinAlg');base=root/'build/literature-review/nfcore-runtime';out=base/'chipseq200-container-source-intake-3';out.mkdir();source=Path('/var/tmp/omicsmatic-nfcore-sources-1/chipseq-2.0.0');profile=json.loads((root/'src/main/resources/org/jlinalg/omics/nfcore/nfcore-source-lock.json').read_bytes())['pipelines']['chipseq-2.0.0'];state=dict(status='FAIL2_CHIPSEQ200_CONTAINER_SOURCE_INTAKE',scientific_analysis_executed=False,new_catalog_credit=False)

def declaration(text,start):
 # Match the outer Groovy GString while treating quoted strings inside ${...} as expression tokens.
 assert text[start]=='"';i=start+1;depth=0;tokens=[]
 while i<len(text):
  c=text[i]
  if depth==0:
   if c=='"':return text[start:i+1],tokens
   if text.startswith('${',i):depth=1;i+=2;continue
   if c=='\\':i+=2;continue
  else:
   if c in ['"',"'"]:
    quote=c;i+=1;value=''
    while i<len(text) and text[i]!=quote:
     assert text[i]!='\\','No escaped URI tokens inferred'
     value+=text[i];i+=1
    assert i<len(text),'Unterminated quoted source container token';tokens.append(value)
   elif c=='{':depth+=1
   elif c=='}':depth-=1
  i+=1
 raise AssertionError('Unterminated original container declaration')

try:
 rows=[]
 for name,expected in profile['files'].items():
  raw=(source/name).read_bytes();assert len(raw)==expected['bytes'] and hashlib.sha256(raw).hexdigest()==expected['sha256'],name
  if not name.endswith('.nf'):continue
  text=raw.decode('utf8')
  for match in re.finditer(r'^[ \t]*container[ \t]+',text,re.MULTILINE):
   block,parts=declaration(text,match.end());assert len(parts)==3 and parts[0]=='singularity' and parts[1].startswith('https://depot.galaxyproject.org/singularity/') and re.fullmatch(r'[A-Za-z0-9_./-]+(?::[A-Za-z0-9_.-]+|@sha256:[a-f0-9]{64})',parts[2]),(name,parts)
   rows.append(dict(module=name,source_pin=expected,line=text[:match.start()].count('\n')+1,singularity=parts[1],oci=parts[2],source_block=block))
 unique={}
 for row in rows:
  entry=unique.setdefault(row['singularity'],dict(singularity=row['singularity'],oci_sources=[],modules=[]))
  if row['oci'] not in entry['oci_sources']:entry['oci_sources'].append(row['oci'])
  entry['modules'].append(row['module'])
 vfs=os.statvfs('/var/tmp');state.update(status='PASS_CHIPSEQ200_ORIGINAL_CONTAINER_DECLARATION_INTAKE_ONLY',source_commit=profile['commit'],locked_source_files=len(profile['files']),complete_module_declarations=len(rows),unique_images=len(unique),declarations=rows,images=list(unique.values()),available_var_tmp_bytes=vfs.f_bavail*vfs.f_frsize,prior_parser_failures_retained=True)
except Exception as error:state.update(cause=repr(error),traceback=traceback.format_exc())
state['required_action']='Resolve/download exact source-declared images where permitted, record complete identities and run separate runtime/engine/scientific controls before admission. Missing/forbidden prerequisites skip affected analyses. No author engine/image digest is inferred.'
(out/'COMPLETED.json').write_text(json.dumps(state,indent=2)+'\n',encoding='utf8',newline='\n');print(state['status'],state.get('cause',''),state.get('complete_module_declarations'),state.get('unique_images'),state.get('available_var_tmp_bytes'))
raise SystemExit(0 if state['status'].startswith('PASS_') else 2)
