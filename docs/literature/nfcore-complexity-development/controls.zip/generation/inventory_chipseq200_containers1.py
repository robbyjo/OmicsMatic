from pathlib import Path
import json,re,hashlib,subprocess,sys,os
if sys.platform!='linux':raise SystemExit(subprocess.call(['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--exec','/usr/bin/python3','/mnt/d/projects/JLinAlg/build/literature-review/nfcore-runtime/inventory_chipseq200_containers1.py']))
root=Path('/mnt/d/projects/JLinAlg');base=root/'build/literature-review/nfcore-runtime';out=base/'chipseq200-container-source-intake-1';out.mkdir();source=Path('/var/tmp/omicsmatic-nfcore-sources-1/chipseq-2.0.0');lock=json.loads((root/'src/main/resources/org/jlinalg/omics/nfcore/nfcore-source-lock.json').read_bytes());profile=lock['pipelines']['chipseq-2.0.0'];rows=[]
for name,expected in profile['files'].items():
 p=source/name;raw=p.read_bytes();assert len(raw)==expected['bytes'] and hashlib.sha256(raw).hexdigest()==expected['sha256'],name
 if not name.endswith('.nf'):continue
 lines=raw.decode('utf8').splitlines()
 for i,line in enumerate(lines):
  if not re.match(r'^\s*container\s+["\']',line):continue
  block='\n'.join(lines[i:i+7]);urls=re.findall(r'''['"]((?:https?://|quay\.io/)[^'"\s]+)['"]''',block)
  # Source declarations in this profile use one conditional SIF/OCI pair, with literal URIs.
  assert len(urls)==2 and urls[0].startswith('https://depot.galaxyproject.org/singularity/') and urls[1].startswith('quay.io/biocontainers/'),(name,i+1,urls)
  rows.append(dict(module=name,source_pin=expected,line=i+1,singularity=urls[0],oci=urls[1],source_block=block))
unique={}
for row in rows:
 uri=row['singularity'];entry=unique.setdefault(uri,dict(singularity=uri,oci=row['oci'],modules=[]));assert entry['oci']==row['oci'];entry['modules'].append(row['module'])
vfs=os.statvfs('/var/tmp');report=dict(status='PASS_CHIPSEQ200_ORIGINAL_CONTAINER_DECLARATION_INTAKE_ONLY',source_commit=profile['commit'],locked_source_files=len(profile['files']),complete_module_declarations=len(rows),unique_images=len(unique),declarations=rows,images=list(unique.values()),available_var_tmp_bytes=vfs.f_bavail*vfs.f_frsize,scientific_analysis_executed=False,new_catalog_credit=False,required_action='Resolve and download exact source-declared upstream images where permitted, record their complete identities and run separate engine/runtime/full scientific controls before admission. Missing/forbidden prerequisites skip affected analyses. No author runtime or image digest is inferred.')
(out/'COMPLETED.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8',newline='\n');print('Source-locked ChIP-seq2.0.0 containers:',len(rows),'declarations;',len(unique),'images;free bytes',report['available_var_tmp_bytes'])
