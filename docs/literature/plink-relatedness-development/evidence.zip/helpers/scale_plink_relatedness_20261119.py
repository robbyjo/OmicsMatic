from pathlib import Path
import hashlib,json,random,subprocess,time
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');B=A/'build/plink-relatedness-development-1'
O=B/'scale-1';O.mkdir(exist_ok=False);inp=O/'synthetic';inp.mkdir();prefix=inp/'cohort'
jar=B/'build-6/omicsmatic-0.4.0.jar';java='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe';main='org.jlinalg.cli.PlinkRelatednessCli'
def save(p,v):p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
n=257;v=1025;rng=random.Random(2026111901);bed=bytearray([0x6c,0x1b,1])
for j in range(v):
 p=.1+(j%17)*.04;row=[]
 for i in range(n):
  dose=int(rng.random()<p)+int(rng.random()<p);row.append(1 if rng.random()<.02 else {0:3,1:2,2:0}[dose])
 row[1]=row[0];packed=bytearray((n+3)//4)
 for i,code in enumerate(row):packed[i//4]|=code<<(2*(i%4))
 bed.extend(packed)
prefix.with_suffix('.bed').write_bytes(bed)
prefix.with_suffix('.fam').write_text(''.join(f'family{i%19}\ts{i}\t0\t0\t{i%3}\t{1+i%2}\n' for i in range(n)),encoding='utf-8')
prefix.with_suffix('.bim').write_text(''.join(f'{1+j//100}\tv{j}\t0\t{100+j%100*41}\tA\tC\n' for j in range(v)),encoding='utf-8')
save(inp/'SYNTHETIC.json',dict(seed=2026111901,samples=n,variants=v,expected_pairs=n*(n-1)//2,paper_data=False,description='Independent binomial calls with missingness and one exact clone; test population only'))
base=json.loads((B/'pilot-handover-2/table-proportions-clean.json').read_bytes());base.update(bfile=str(prefix));base['limits'].update(pair_batch_size=1024,wall_seconds=600)
results={}
for name,operation,settings,threads in [('table-counts-1thread','KING_TABLE',dict(counts=True,rel_check=False,kinship_filter=None),1),('table-counts-4threads','KING_TABLE',dict(counts=True,rel_check=False,kinship_filter=None),4),('matrix64','KING_MATRIX',dict(precision='FLOAT64'),4),('matrix32','KING_MATRIX',dict(precision='FLOAT32'),4)]:
 request=dict(base,operation=operation,settings=settings,threads=threads,out=str(O/name));path=O/(name+'.json');save(path,request)
 for mode,req in [('run',path),('verify',O/name/'verify-request.json')]:
  start=time.monotonic()
  with (O/(name+'-'+mode+'.stdout')).open('xb') as so,(O/(name+'-'+mode+'.stderr')).open('xb') as se:r=subprocess.run([java,'-Xmx1g','-cp',str(jar),main,'--request',str(req)],cwd=A,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=660)
  results[name+'-'+mode]=dict(exit_code=r.returncode,seconds=time.monotonic()-start);save(O/'PROGRESS.json',results);print(name,mode,r.returncode,flush=True);assert r.returncode==0,name+' '+mode
 state=json.loads((O/name/'analysis-status.json').read_bytes());assert state['summary']['pair_rows_checked']==n*(n-1)//2
assert (O/'table-counts-1thread/pairs.tsv').read_bytes()==(O/'table-counts-4threads/pairs.tsv').read_bytes()
save(O/'COMPLETED.json',dict(status='PASS_257_SAMPLE_1025_SNP_ORIGINAL_CONTROLS',samples=n,variants=v,pairs=n*(n-1)//2,cases=results,thread_counts_equal=True,candidate_sha256=hashlib.sha256(jar.read_bytes()).hexdigest(),production_scale_claim=False))
