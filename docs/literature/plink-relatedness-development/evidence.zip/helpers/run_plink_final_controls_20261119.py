from pathlib import Path
p=Path('D:/projects/JLinAlg/build/control_plink_relatedness_20261119.py');code=p.read_text(encoding='utf-8')
for old,new in [("O=B/'controls-1'","O=B/'controls-2'"),("JAR=B/'build-4/omicsmatic-0.4.0.jar'","JAR=B/'build-6/omicsmatic-0.4.0.jar'"),("P=B/'pilot-handover-2'","P=B/'pilot-qualified-3'")]:
 assert old in code;code=code.replace(old,new)
anchor=" corrupt('king-count','table-counts-old'"
assert anchor in code
code=code.replace(anchor,""" def no_heterozygosity(p):
  q=p.with_suffix('.bed');b=bytearray([0x6c,0x1b,1]);row=bytes([255]*4+[3]);b.extend(row*129);q.write_bytes(b)
 root=run('all-unreportable-table',dict(bfile=fixture('all-unreportable-table',no_heterozygosity)))
 assert (root/'worker/result.kin0').is_file()
"""+anchor)
exec(compile(code,str(p)+'-FINAL-6','exec'))
