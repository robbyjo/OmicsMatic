from pathlib import Path
p=Path('D:/projects/JLinAlg/build/test_plink_relatedness_lifecycle_20261119.py');code=p.read_text(encoding='utf-8')
replacements=[("O=B/'lifecycle-tests-1'","O=B/'lifecycle-tests-3'"),
 ("jar=B/'build-5/omicsmatic-0.4.0.jar'","jar=B/'build-6/omicsmatic-0.4.0.jar'"),
 ("'--disable-ansi-colors','--details=tree']","'--disable-ansi-colors','--details=tree','--config','junit.jupiter.tempdir.cleanup.mode.default=NEVER']"),
 ("run('windows',[str(jdk/'java.exe'),'-Xmx1g'","(O/'tmp-windows').mkdir();(O/'tmp-linux').mkdir()\nrun('windows',[str(jdk/'java.exe'),'-Djava.io.tmpdir='+str(O/'tmp-windows'),'-Xmx1g'"),
 ("'--exec','/usr/bin/java','-Xmx1g'","'--exec','/usr/bin/java','-Djava.io.tmpdir='+posix(O/'tmp-linux'),'-Xmx1g'")]
for old,new in replacements:
 assert old in code,old;code=code.replace(old,new)
exec(compile(code,str(p)+'-RETAINED-FINAL-6','exec'))
