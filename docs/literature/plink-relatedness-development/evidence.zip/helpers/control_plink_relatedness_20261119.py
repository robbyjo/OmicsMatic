from pathlib import Path
import copy,csv,hashlib,io,json,os,shutil,struct,subprocess,time,traceback
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');B=A/'build/plink-relatedness-development-1'
O=B/'controls-1';O.mkdir(exist_ok=False);JAR=B/'build-4/omicsmatic-0.4.0.jar'
JAVA='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe';MAIN='org.jlinalg.cli.PlinkRelatednessCli'
P=B/'pilot-handover-2';results={}
def save(p,v):p.write_bytes((json.dumps(v,indent=2,ensure_ascii=False)+'\n').encode())
def pins(root):
 return {p.relative_to(root).as_posix():dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in root.rglob('*') if p.is_file()}
before=pins(P)
def invoke(name,request,expected,linux=False):
 path=O/(name+'.json');save(path,request)
 if linux:
  posix=lambda p:'/mnt/'+str(p)[0].lower()+str(p)[2:].replace('\\','/')
  command=['wsl.exe','--distribution','JLinAlg-Omics-SAIGE-20261026','--exec','/usr/bin/java','-Xmx1g','-cp',posix(JAR),MAIN,'--request',posix(path)]
 else:command=[JAVA,'-Xmx1g','-cp',str(JAR),MAIN,'--request',str(path)]
 start=time.monotonic()
 with (O/(name+'.stdout')).open('xb') as so,(O/(name+'.stderr')).open('xb') as se:
  r=subprocess.run(command,cwd=A,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=180)
 results[name]=dict(exit_code=r.returncode,expected=expected,seconds=time.monotonic()-start,linux=linux)
 save(O/'PROGRESS.json',results);print(name,r.returncode,'expected',expected,flush=True)
 assert r.returncode==expected,name+': '+(O/(name+'.stderr')).read_text(encoding='utf-8',errors='replace')[-2500:]
 return r
def run(name,updates=None,limits=None,expected=2):
 request=json.loads((P/'table-proportions-clean.json').read_bytes());request['out']=str(O/name)
 if updates:request.update(updates)
 if limits:request['limits'].update(limits)
 invoke(name,request,expected)
 state=json.loads((O/name/'analysis-status.json').read_bytes());assert state['results_admitted']==(expected==0)
 if expected!=0:assert not (O/name/'pairs.tsv').exists() and not (O/name/'selection.tsv').exists()
 if expected==3:assert not (O/name/'inputs').exists() and not (O/name/'worker/analysis-process.json').exists()
 return O/name
def fixture(name,edit):
 root=O/(name+'-input');shutil.copytree(P/'clean',root);edit(root/'cohort');return str(root/'cohort')
def reseal(root):
 files=pins(root);files.pop('capture-files.json',None);save(root/'capture-files.json',dict(schema_version=1,authentication=False,files=files))
def corrupt(name,case,edit):
 root=O/name;shutil.copytree(P/case,root);edit(root);reseal(root)
 invoke(name,dict(schema_version=1,mode='VERIFY',analysis=str(root),wall_seconds=120),2)
def edit_json(p,fun):
 d=json.loads(p.read_bytes());fun(d);save(p,d)
def field(p,row,column,value):
 lines=p.read_text(encoding='utf-8').splitlines();fields=lines[row].split();fields[column]=str(value);lines[row]='\t'.join(fields);p.write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\n')
try:
 run('missing-runtime',dict(runtime_home=str(O/'missing-runtime-home')),expected=3)
 changed=O/'changed-runtime-home';shutil.copytree(B/'runtime-2',changed)
 with (changed/'plink2/plink2.exe').open('r+b') as f:f.seek(1000);v=f.read(1);f.seek(1000);f.write(bytes([v[0]^1]))
 run('changed-runtime',dict(runtime_home=str(changed)),expected=3)
 replay=O/'replay';invoke('replay',dict(schema_version=1,mode='REPLAY',analysis=str(P/'table-proportions-clean'),out=str(replay),runtime_home=str(B/'runtime-2'),wall_seconds=120),0)
 assert (replay/'pairs.tsv').read_bytes()==(P/'table-proportions-clean/pairs.tsv').read_bytes()
 invoke('replay-verify',dict(schema_version=1,mode='VERIFY',analysis=str(replay),wall_seconds=120),0)
 for size in [1,31]:
  root=run('batch-'+str(size),limits=dict(pair_batch_size=size),expected=0)
  assert (root/'pairs.tsv').read_bytes()==(P/'table-proportions-clean/pairs.tsv').read_bytes()
 def padding(p):
  q=p.with_suffix('.bed');b=bytearray(q.read_bytes());b[7]|=4;q.write_bytes(b)
 def header(p):
  q=p.with_suffix('.bed');b=bytearray(q.read_bytes());b[0]=0;q.write_bytes(b)
 def duplicate(p):
  q=p.with_suffix('.fam');rows=q.read_text(encoding='utf-8').splitlines();f=rows[1].split();first=rows[0].split();f[:2]=first[:2];rows[1]='\t'.join(f);q.write_text('\n'.join(rows)+'\n',encoding='utf-8')
 def unsorted(p):
  q=p.with_suffix('.bim');rows=q.read_text(encoding='utf-8').splitlines();rows[1],rows[2]=rows[2],rows[1];q.write_text('\n'.join(rows)+'\n',encoding='utf-8')
 for name,edit in [('bad-padding',padding),('bad-header',header),('duplicate-tuple',duplicate),('unsorted-bim',unsorted)]:
  root=run(name,dict(bfile=fixture(name,edit)));assert not (root/'worker/analysis-process.json').exists()
 for name,lim in [('input-cap',dict(input_bytes=10,metadata_bytes=10)),('work-cap',dict(working_bytes=1)),('output-cap',dict(output_bytes=1)),('native-work-cap',dict(pair_variant_operations=1)),('sample-cap',dict(samples=16)),('file-cap',dict(files=16))]:run(name,limits=lim)
 def no_clone(p):
  q=p.with_suffix('.bed');b=bytearray(q.read_bytes());b[3+2*5]=(b[3+2*5]&~12)|12;q.write_bytes(b)
 root=run('valid-empty-filter',dict(bfile=fixture('valid-empty-filter',no_clone),settings=dict(counts=True,rel_check=False,kinship_filter=.5)),expected=0)
 assert len((root/'pairs.tsv').read_text(encoding='utf-8').splitlines())==1
 corrupt('king-count','table-counts-old',lambda r:field(r/'worker/result.kin0',1,4,0))
 corrupt('king-coefficient','table-counts-old',lambda r:field(r/'worker/result.kin0',1,9,.123456))
 corrupt('king-unknown-id','table-counts-old',lambda r:field(r/'worker/result.kin0',1,1,'unknown'))
 def row_change(r,mode):
  q=r/'worker/result.kin0';lines=q.read_text(encoding='utf-8').splitlines()
  if mode=='duplicate':lines[2]=lines[1]
  if mode=='reorder':lines[1],lines[2]=lines[2],lines[1]
  if mode=='missing':lines.pop(1)
  q.write_text('\n'.join(lines)+'\n',encoding='utf-8')
 for mode in ['duplicate','reorder','missing']:corrupt('king-'+mode,'table-counts-old',lambda r,m=mode:row_change(r,m))
 corrupt('king-proportion','table-proportions-clean',lambda r:field(r/'worker/result.kin0',1,5,.123456))
 def matrix(r):
  q=r/'worker/result.king.bin';b=bytearray(q.read_bytes());struct.pack_into('<d',b,0,.123456);q.write_bytes(b)
 corrupt('matrix-value','matrix64-clean',matrix)
 corrupt('matrix-axis','matrix64-clean',lambda r:field(r/'worker/result.king.id',2,1,'unknown'))
 for col,value in [(14,999),(12,.1234),(9,.1234)]:corrupt('genome-field-'+str(col),'genome-bounded-old',lambda r,c=col,v=value:field(r/'worker/result.genome',1,c,v))
 def selection(r):
  q=r/'worker/result.king.cutoff.out.id';q.write_bytes(q.read_bytes()+(r/'worker/result.king.cutoff.in.id').read_bytes().splitlines(keepends=True)[1])
 corrupt('selection-duplicate','cutoff-clean',selection)
 corrupt('source-process-exit','table-counts-old',lambda r:edit_json(r/'worker/analysis-process.json',lambda d:d.update(exit_code=9)))
 corrupt('source-process-command','table-counts-old',lambda r:edit_json(r/'worker/analysis-process.json',lambda d:d['command'].append('--unknown')))
 corrupt('runtime-binding','table-counts-old',lambda r:edit_json(r/'runtime-bindings.json',lambda d:d.update(runtime_home='different-home')))
 corrupt('summary','table-counts-old',lambda r:edit_json(r/'diagnostics.json',lambda d:d.update(pair_rows_checked=1)))
 corrupt('extra-file','table-counts-old',lambda r:(r/'unexpected.txt').write_text('extra\n',encoding='utf-8'))
 corrupt('warning-omission','table-counts-old',lambda r:(r/'worker/result.log').write_bytes((r/'worker/result.log').read_bytes()+b'Warning: synthetic qualification warning\n'))
 for name in json.loads((P/'COMPLETED.json').read_bytes())['cases']:
  expected=0 if json.loads((P/'COMPLETED.json').read_bytes())['cases'][name]['exit_code']==0 else 2
  posix=lambda p:'/mnt/'+str(p)[0].lower()+str(p)[2:].replace('\\','/')
  invoke('linux-verify-'+name,dict(schema_version=1,mode='VERIFY',analysis=posix(P/name),wall_seconds=120),expected,True)
 request=json.loads((P/'table-proportions-clean.json').read_bytes());request.update(bfile=posix(P/'clean/cohort'),runtime_home=posix(B/'runtime-2'),out=posix(O/'linux-run-skipped'))
 invoke('linux-run-skipped',request,3,True)
 assert not (O/'linux-run-skipped/inputs').exists()
 assert before==pins(P),'Frozen pilot capture changed'
 save(O/'COMPLETED.json',dict(status='PASS_PACKAGED_RELATEDNESS_CONTROLS',candidate_sha256=hashlib.sha256(JAR.read_bytes()).hexdigest(),cases=results,frozen_pilot_files_unchanged=len(before),full_qualification=False,catalog_credit=0))
 print('PASS',len(results),'controls',flush=True)
except Exception as e:
 save(O/'FAILURE.json',dict(error=repr(e),detail=traceback.format_exc(),completed_controls=len(results)));raise
