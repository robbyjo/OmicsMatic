from pathlib import Path
import hashlib,json,os,shutil,subprocess,time,sys,xml.etree.ElementTree as ET
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');B=A/'build/plink-relatedness-development-1'
O=B/'lifecycle-tests-1';O.mkdir(exist_ok=False)
jar=B/'build-5/omicsmatic-0.4.0.jar';junit=A/'build/nfcore-atacseq121-1/linux-test-runtime-1/junit-platform-console-standalone-1.13.4.jar'
jdk=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin');classes=O/'classes';classes.mkdir()
sources=[A/'src/test/java/org/jlinalg/cli'/n for n in ['PlinkRelatednessContractsTest.java','PlinkRelatednessOwnedProcessTest.java','PlinkRelatednessProcessFixture.java']]
def save(p,v):p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
def run(name,command):
 save(O/(name+'-command.json'),command);start=time.monotonic()
 with (O/(name+'.stdout')).open('xb') as so,(O/(name+'.stderr')).open('xb') as se:p=subprocess.run(command,cwd=A,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=180)
 save(O/(name+'-process.json'),dict(exit_code=p.returncode,seconds=time.monotonic()-start));print(name,p.returncode,flush=True)
 if p.returncode:print((O/(name+'.stdout')).read_text(errors='replace')[-8000:]);print((O/(name+'.stderr')).read_text(errors='replace')[-8000:]);raise SystemExit(p.returncode)
for p in sources:
 q=O/'source'/p.name;q.parent.mkdir(exist_ok=True);shutil.copyfile(p,q)
run('javac',[str(jdk/'javac.exe'),'--release','17','-g','-Xlint:all','-Werror','-cp',str(jar)+';'+str(junit),'-d',str(classes),*[str(O/'source'/p.name) for p in sources]])
args=['org.junit.platform.console.ConsoleLauncher','execute','--select-class','org.jlinalg.cli.PlinkRelatednessContractsTest','--select-class','org.jlinalg.cli.PlinkRelatednessOwnedProcessTest','--disable-ansi-colors','--details=tree']
run('windows',[str(jdk/'java.exe'),'-Xmx1g','-cp',';'.join(map(str,[junit,jar,classes])),*args,'--reports-dir',str(O/'windows-reports')])
posix=lambda p:'/mnt/'+str(p)[0].lower()+str(p)[2:].replace('\\','/')
run('linux',['wsl.exe','--distribution','JLinAlg-Omics-SAIGE-20261026','--exec','/usr/bin/java','-Xmx1g','-cp',':'.join(posix(p) for p in [junit,jar,classes]),*args,'--reports-dir',posix(O/'linux-reports')])
counts={}
for platform in ['windows','linux']:
 totals=dict(tests=0,errors=0,skipped=0,failures=0)
 for p in (O/(platform+'-reports')).glob('TEST-*.xml'):
  r=ET.parse(p).getroot()
  for key in totals:totals[key]+=int(r.attrib[key])
 assert totals==dict(tests=6,errors=0,skipped=0,failures=0),totals;counts[platform]=totals
save(O/'COMPLETED.json',dict(status='PASS_ACTUAL_WINDOWS_LINUX_LIFECYCLE_TESTS',counts=counts,sources={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},candidate_sha256=hashlib.sha256(jar.read_bytes()).hexdigest(),catalog_credit=0))
print(json.dumps(counts),flush=True)
