FAIL2_WESANDERSON037_NATIVE_CONTROLS
ValueError('Complete original/native control failed at complete-native')
Required action: supply permitted JDK21/25, complete original6012-case --reference and NEW output. Missing/forbidden prerequisites SKIP3 skip dependent comparison; FAIL2 retains every mismatch and admits no implementation parity. Never round, repair colors, truncate vectors or infer the paper palette/category assignments. This compares source-qualified scalar color generation, not R language coercions, original R plotting devices or biological validity.
