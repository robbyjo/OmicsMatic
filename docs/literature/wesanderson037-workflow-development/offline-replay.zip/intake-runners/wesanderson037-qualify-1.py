from pathlib import Path
import gzip,hashlib,json,re,shutil,sys,xml.etree.ElementTree as ET,zipfile
ROOT=Path('D:/projects/JLinAlg');B=ROOT/'build/literature-review/monocle-runtime';HERE=ROOT/'tools/literature/wesanderson037';DATA=ROOT/'docs/literature/wesanderson037-workflow-development';OUT=B/'wesanderson037-qualification-build-1';OUT.mkdir(exist_ok=False)
sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT/'tools/literature'))
from collect_omics_review import paragraphs

def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8',newline='\n')

assert {p.name for p in DATA.iterdir()}=={'.gitattributes'},'Do not overwrite a previous qualification'
baseline=json.loads((B/'imagej-catalog-preservation-1/BEFORE.json').read_bytes())
def preserve():
 assert len(baseline['protected_files'])==23
 for row in baseline['protected_files']+[baseline['canonical']]:assert pin(ROOT/row['path'])=={k:row[k] for k in ['bytes','sha256']},row['path']
preserve();assert pin(HERE/'licenses/LICENSE-project-GPL3.txt')==pin(ROOT/'LICENSE')
paper=next(p for p in json.loads((ROOT/'docs/literature/omics-2023-2026/papers.json').read_bytes()) if p['paper_id']=='P054')
raw=gzip.decompress((ROOT/'build/literature-review/xml'/(paper['pmcid']+'.xml.gz')).read_bytes());assert hashlib.sha256(raw).hexdigest()==paper['xml_sha256'];xml=ET.fromstring(raw);assert paper['doi'] in [e.text for e in xml.findall('front/article-meta/article-id') if e.get('pub-id-type')=='doi'];paragraph=next(p for p in paragraphs(xml) if p['paragraph_index']==93)
assert hashlib.sha256(paragraph['text'].encode()).hexdigest()=='49a7527526389e9d16df6a393894090861be3f2b1a7fa3379335150b931f03e8'
assert re.search(r'wesanderson\s*v\.?0\.3\.7',paragraph['match_text']) and 'MFOD1' in paragraph['match_text'] and 'viridisLite' in paragraph['match_text']
names=[line.split('\t')[0] for line in (B/'wesanderson037-original-controls-2/complete-original-palettes.tsv').read_text().splitlines()];text=' '.join(xml.itertext());named=[name for name in names if re.search(r'(?<!\w)'+re.escape(name)+r'(?!\w)',text,re.I)];assert not named,named
save(DATA/'PAPER_USE.json',dict(status='INDIVIDUALLY_REVIEWED_COMPONENT_CANDIDATE_NO_CATALOG_ADMISSION',paper_id=paper['paper_id'],pmcid=paper['pmcid'],doi=paper['doi'],title=paper['title'],primary_xml_sha256=paper['xml_sha256'],paragraph_index=93,section=paragraph['section'],paragraph_sha256=hashlib.sha256(paragraph['text'].encode()).hexdigest(),version_reported='0.3.7',reported_R_versions=['4.2.3','4.4.0'],reference_R_version='4.5.3',use_summary='The authors used wesanderson0.3.7 to construct the color scale for MFOD1 ontology levels. They separately used viridisLite0.4.2 for colorblind-friendly continuous gradients.',review_scope='Complete primary Methods paragraph93 and a known-palette-identifier scan of the primary XML; supplementary analysis code is not audited here.',palette_identifiers_named_in_primary_xml=named,palette_name_recovered=False,category_color_mapping_recovered=False,number_and_discrete_continuous_call_recovered=False,author_runtime_reproduced=False,new_tool_credit=0,whole_goal_complete=False))
for name in ['complete-original-cases.tsv','complete-original-palettes.tsv','complete-original-cases.rds','complete-original-palettes.rds']:
 assert (B/'wesanderson037-public-original-controls-2'/name).read_bytes()==(B/'wesanderson037-original-controls-2'/name).read_bytes(),name
assert json.loads((B/'wesanderson037-public-original-capture-1/COMPLETED.json').read_bytes())['status']=='PASS_ACTUAL_PUBLIC_ORIGINAL_6108_CASES_AND_24_PLOTS_WITH_COMPLETE_PROCESS_LOGS'
trees={
 'original-reference-6108':B/'wesanderson037-original-controls-2',
 'public-original':B/'wesanderson037-public-original-controls-2',
 'public-original-process':B/'wesanderson037-public-original-capture-1',
 'public-provider':B/'wesanderson037-public-provider-1',
 'setup':B/'wesanderson037-public-setup-controls-1',
 'upstream/R453':B/'wesanderson037-base-source-intake-1',
 'upstream/package-source':B/'imagej-next-source-intake-1/wesanderson037/source',
 'historical/original-reference-6012':B/'wesanderson037-original-controls-1',
 'historical/failed-native-6012':B/'wesanderson037-native21-controls-1',
 'historical/corrected-native-6012':B/'wesanderson037-native21-controls-2',
 'historical/public-original-first-pass':B/'wesanderson037-public-original-controls-1',
 'historical/provisional-windows21-build':B/'wesanderson037-package-windows21-build-1',
 'historical/pre-license-windows21-build':B/'wesanderson037-package-windows21-build-2',
 'historical/pre-license-windows25-build':B/'wesanderson037-package-windows25-build-1',
 'historical/pre-license-linux21-build':B/'wesanderson037-package-linux21-build-1'}
platforms={
 'windows21':('wesanderson037-package-windows21-build-3','wesanderson037-package-windows21-controls-2','wesanderson037-native21-controls-3','wesanderson037-package-windows21-controls-1'),
 'windows25':('wesanderson037-package-windows25-build-2','wesanderson037-package-windows25-controls-2','wesanderson037-native25-controls-1','wesanderson037-package-windows25-controls-1'),
 'linux21':('wesanderson037-package-linux21-build-2','wesanderson037-package-linux21-controls-2','wesanderson037-native-linux21-controls-1','wesanderson037-package-linux21-controls-1')}
artifacts={}
for platform,(build,packaged,direct,older) in platforms.items():
 for folder,status in [(packaged,'PASS_PACKAGED_WESANDERSON037_COMPLETE_API_CLI_AND_REFUSALS'),(direct,'PASS_COMPLETE_ORIGINAL_WESANDERSON037_NATIVE')]:assert json.loads((B/folder/'COMPLETED.json').read_bytes())['status']==status
 trees[platform+'/build']=B/build;trees[platform+'/packaged']=B/packaged;trees[platform+'/direct']=B/direct;trees['historical/pre-license-'+platform+'-controls']=B/older
 original=B/build/'wesanderson037-native-development.jar';target=DATA/('wesanderson037-native-'+platform+'-development.jar');assert not target.exists();shutil.copyfile(original,target);artifacts[target.relative_to(ROOT).as_posix()]=pin(target)
save(DATA/'ARTIFACTS.json',artifacts)
files={}
for prefix,folder in trees.items():
 assert folder.is_dir(),folder
 for path in sorted(folder.rglob('*')):
  if path.is_file() and '__pycache__' not in path.parts and path.suffix!='.pyc':
   assert not path.is_symlink(),path;name=prefix+'/'+path.relative_to(folder).as_posix();assert name not in files;files[name]=path
for name,path in [('upstream/wesanderson_0.3.7.tar.gz',B/'imagej-next-source-intake-1/wesanderson037/source.tar.gz'),('upstream/SOURCE.json',B/'imagej-next-source-intake-1/wesanderson037/SOURCE.json'),('upstream/OriginalControl-6108.R',HERE/'OriginalControl.R')]:assert name not in files;files[name]=path
layout={name:pin(path) for name,path in sorted(files.items())}
with zipfile.ZipFile(DATA/'controls.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,path in sorted(files.items()):
  assert pin(path)==layout[name],'Evidence changed while packaging: '+name;z.write(path,name)
save(DATA/'CONTROLS_LAYOUT.json',dict(status='COMPLETE_UNTRUNCATED_ORIGINAL_NATIVE_AND_HISTORICAL_EVIDENCE',files=layout,logical_files=len(layout),uncompressed_bytes=sum(v['bytes'] for v in layout.values()),biological_inputs_included=False,primary_paper_fulltext_included=False,existing_R_runtime_included=False))
sourcepaths=[ROOT/'src/main/java/org/jlinalg/plot/WesAnderson037.java',ROOT/'src/main/java/org/jlinalg/cli/WesAnderson037PaletteCli.java',ROOT/'docs/literature/WESANDERSON037_WORKFLOW_DEVELOPMENT.md',DATA/'.gitattributes',DATA/'PAPER_USE.json',*[p for p in sorted(HERE.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc']]
sources={p.relative_to(ROOT).as_posix():pin(p) for p in sourcepaths}
v=dict(status='PASS_ORIGINAL_WESANDERSON037_AND_NATIVE_PACKAGED_PALETTES',sources=sources,controls_archive=pin(DATA/'controls.zip'),controls_layout=pin(DATA/'CONTROLS_LAYOUT.json'),original_package_version='0.3.7',reference_R_version='4.5.3',complete_original_API_cases=6108,complete_original_returned_colors=224445,original_failures_retained=3397,original_palette_vectors=24,original_R_plots=24,native_R_graphics_ported=False,qualified_platforms=['windows21','windows25','linux21'],original_CLI_cases_per_platform=72,complete_CLI_colors_per_platform=1490,complete_bundle_replays_per_platform=63,actual_private_original_installs_in_setup=2,actual_official_downloads_in_setup=1,setup_refusals=9,original_source_modified=False,paper_palette_inferred=False,new_tool_credit=0,catalog_admission_pending=True,whole_goal_complete=False)
save(DATA/'VALIDATION.json',v)
(DATA/'SHA256SUMS').write_text(''.join(pin(p)['sha256']+'  '+p.name+'\n' for p in sorted(DATA.iterdir()) if p.is_file() and p.name!='SHA256SUMS'),encoding='utf8',newline='\n')
preserve();save(OUT/'COMPLETED.json',dict(status=v['status'],logical_evidence_files=len(layout),archive=pin(DATA/'controls.zip'),source_paths=len(sources),published_artifacts=artifacts,preserved_original_local_files=23,canonical_unchanged=True,new_tool_credit=0,whole_goal_complete=False));print(json.dumps(dict(status=v['status'],logical_evidence_files=len(layout),archive=pin(DATA/'controls.zip'),source_paths=len(sources)),indent=2),flush=True)
