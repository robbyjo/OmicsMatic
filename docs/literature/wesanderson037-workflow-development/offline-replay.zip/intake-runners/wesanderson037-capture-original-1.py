from pathlib import Path
import hashlib,json,os,subprocess,time
ROOT=Path('/mnt/d/projects/JLinAlg');B=ROOT/'build/literature-review/monocle-runtime';OUT=B/'wesanderson037-public-original-capture-1';OUT.mkdir(exist_ok=False)
R=B/'fastmnn129-public-fresh-setup-2/dependency-base/.pixi/envs/default/bin/Rscript';script=ROOT/'tools/literature/wesanderson037/OriginalControl.R';provider=B/'wesanderson037-public-provider-1';target=B/'wesanderson037-public-original-controls-2'
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(n,v):(OUT/n).write_text(json.dumps(v,indent=2)+'\n',encoding='utf8',newline='\n')
before={str(p):pin(p) for p in [R,script,provider/'READY.json']};save('BEFORE.json',before)
env={k:v for k,v in os.environ.items() if k not in ['R_LIBS','R_LIBS_USER','R_LIBS_SITE','R_DEFAULT_PACKAGES','R_PROFILE_USER','R_ENVIRON_USER']};command=list(map(str,[R,'--vanilla',script,provider/'library',target]));start=time.time()
with (OUT/'original.stdout').open('xb') as so,(OUT/'original.stderr').open('xb') as se:
 p=subprocess.Popen(command,cwd=ROOT,env=env,stdin=subprocess.DEVNULL,stdout=so,stderr=se);save('LIVE.json',dict(command=command,pid=p.pid,started_unix=start));code=p.wait(timeout=300)
save('original.process.json',dict(command=command,exit_code=code,elapsed_seconds=time.time()-start));assert code==0
assert all(pin(Path(n))==wanted for n,wanted in before.items())
comparisons={}
for name in ['complete-original-cases.tsv','complete-original-palettes.tsv','complete-original-cases.rds','complete-original-palettes.rds']:
 original=B/'wesanderson037-original-controls-2'/name;actual=target/name;assert actual.read_bytes()==original.read_bytes(),name;comparisons[name]=pin(actual)
save('COMPLETED.json',dict(status='PASS_ACTUAL_PUBLIC_ORIGINAL_6108_CASES_AND_24_PLOTS_WITH_COMPLETE_PROCESS_LOGS',source_pins=before,complete_original_files_identical=comparisons,paper_analysis_executed=False,existing_runtime_modified=False));print('PASS_ACTUAL_PUBLIC_ORIGINAL_6108_CASES_AND_24_PLOTS_WITH_COMPLETE_PROCESS_LOGS',flush=True)
