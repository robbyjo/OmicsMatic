from pathlib import Path
import hashlib,json
ROOT=Path('D:/projects/JLinAlg');DATA=ROOT/'docs/literature/wesanderson037-workflow-development';BACK=ROOT/'build/literature-review/monocle-runtime/wesanderson037-verifier-intake-before-1';PATH='tools/literature/wesanderson037/verify.py'
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
before=json.loads((BACK/'VALIDATION.json').read_bytes());current=json.loads((DATA/'VALIDATION.json').read_bytes());assert before==current
for name,wanted in current['sources'].items():
 if name==PATH:assert pin(BACK/'verify.py')==wanted
 else:assert pin(ROOT/name)==wanted,name
assert pin(DATA/'controls.zip')==before['controls_archive']
current['sources'][PATH]=pin(ROOT/PATH);(DATA/'VALIDATION.json').write_text(json.dumps(current,indent=2)+'\n',encoding='utf8',newline='\n')
(DATA/'SHA256SUMS').write_text(''.join(pin(p)['sha256']+'  '+p.name+'\n' for p in sorted(DATA.iterdir()) if p.is_file() and p.name!='SHA256SUMS'),encoding='utf8',newline='\n')
(BACK/'REFRESH.json').write_text(json.dumps(dict(status='NORMALIZED_FOREIGN_WINDOWS_PATH_MATCH_IN_UNPUBLISHED_VERIFIER',before_source=before['sources'][PATH],after_source=current['sources'][PATH],original_data_source_and_results_changed=False,controls_archive_unchanged=pin(DATA/'controls.zip')),indent=2)+'\n',encoding='utf8',newline='\n');print('REFRESHED_UNPUBLISHED_VERIFIER_SOURCE_PIN_ONLY',flush=True)
