from pathlib import Path
import hashlib,json,subprocess,sys,time
ROOT=Path('D:/projects/JLinAlg');B=ROOT/'build/literature-review/monocle-runtime';OUT=B/'wesanderson037-policy-controls-1';OUT.mkdir(exist_ok=False);helper=ROOT/'tools/literature/wesanderson037/verify.py';calls=[]
for label,args in [('permission-absent',['--java-bin','C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin']),('compiler-missing',['--java-bin',str(OUT/'missing-JDK'),'--allow-build','--allow-analysis'])]:
 target=OUT/label;command=[sys.executable,str(helper),*args,'--out',str(target)];start=time.time();r=subprocess.run(command,cwd=ROOT,stdin=subprocess.DEVNULL,capture_output=True,timeout=240);(OUT/(label+'.stdout')).write_bytes(r.stdout);(OUT/(label+'.stderr')).write_bytes(r.stderr);row=dict(label=label,command=command,exit_code=r.returncode,expected_exit=3,elapsed_seconds=time.time()-start);calls.append(row);(OUT/(label+'.process.json')).write_text(json.dumps(row,indent=2)+'\n',encoding='utf8',newline='\n');assert r.returncode==3
 failure=json.loads((target/'FAILURE.json').read_bytes());assert failure['status']=='SKIP3_NATIVE_REPLAY_PREREQUISITE_OR_POLICY_UNAVAILABLE';assert not (target/'packaged').exists()
 assert len(failure['calls'])==(0 if label=='permission-absent' else 1)
result=dict(status='PASS_ACTUAL_NATIVE_REPLAY_POLICY_AND_MISSING_COMPILER_SKIPS',calls=calls,helper=dict(bytes=helper.stat().st_size,sha256=hashlib.sha256(helper.read_bytes()).hexdigest()),dependent_native_analysis_launched=False,original_R_analysis_launched=False)
(OUT/'COMPLETED.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n');print(result['status'],flush=True)
