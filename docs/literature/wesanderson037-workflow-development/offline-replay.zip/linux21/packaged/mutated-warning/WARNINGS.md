Warnings removed by a controlled refusal test
