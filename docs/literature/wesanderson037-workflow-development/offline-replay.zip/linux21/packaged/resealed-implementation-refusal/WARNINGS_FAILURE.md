# FAIL2_NATIVE_PALETTE_RESULT_NOT_ADMITTED

**No result is admitted.**

java.lang.IllegalArgumentException: Saved implementation/source provenance differs: implementation-SHA256SUMS

Required action: choose an explicit palette and a NEW output directory. Native colors require Java 17 or later and no R installation. Qualification covers Java 21/25. SKIP3 skips work when required files or permissions are unavailable; supply permitted prerequisites or retain the skip. FAIL2 admits no result; correct the named request, provenance or complete-output cause and retry NEW paths. VERIFY recomputes the complete saved Java result; it does not independently refit R, authenticate a bundle, port R graphical devices, recover author inputs or infer paper palette/category assignments.
