# Stratified LDSC: scope and required actions

Prepared observed-scale partitioned Hsq, using selected CBIIT 3.0.2 fixed initial weights (old_weights=True), joint full/delete fits and explicit optional binary-annotation overlap summaries. Reference commit 6c673952cee74bd5c57aef1555a03b1c015399a0. No automatic SNP/annotation removal, deduplication, munging, allele/reference alignment, annotation/LD generation, liability conversion, historical-edition parity or whole-paper reproduction. The caller declares complete prepared rows, reference counts, genome order and annotation provenance. No Python/R runtime or external LDSC installation needed.

**REQUIRED ACTIONS:** Require exit 0, COMPLETED.json and analysis.json result_admitted=true. SKIP3 means dependent analysis skipped for a missing/forbidden prerequisite, unavailable Java dependency or unsupported requested method. Supply the named permitted resource or separately qualified method and retry NEW output. FAIL2 means no complete result admitted: retain exact inputs and partial output, read FAILURE.txt/WARNINGS.md, correct the named input, rank, reference, block, capacity or numerical issue and retry NEW output. Never remove failed SNPs/annotations/blocks, force positive heritability, replace NA/NaN, clamp final estimates or substitute a pseudoinverse to obtain success. Binary overlap counts and the unique universe must describe the same reference population/columns as the LD scores. Study-specific sidedness and multiple-testing families require separate explicit choices.

Consecutive-row jackknife inference depends on the declared genome order/reference population. M_j*tau_j are coefficient allocations; use the separate overlap summary for overlapping categories. Baseline/zero-contrast enrichment P values remain NA. No outer multiple-testing correction is inferred. The prepared model does not apply the original wrapper's raw-data filtering defaults.

## Observed model warnings

Prepared partitioned Hsq uses the original fixed initial weights (old_weights=True), not unpartitioned IRWLS or a two-step fit. No SNP/annotation removal, munging, LD/annotation generation, liability conversion or multiple-testing family is inferred.

M_j*tau_j and the unadjusted proportions/enrichments are coefficient allocations. For overlapping annotations use the explicit overlap summary and the unique reference-universe M; sum(M_j) double-counts shared variants.
