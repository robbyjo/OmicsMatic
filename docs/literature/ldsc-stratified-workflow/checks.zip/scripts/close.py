import hashlib,json,re,subprocess,sys,time,traceback,zipfile
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];out=b/'closure-1';out.mkdir();sys.dont_write_bytecode=True;sys.path.insert(0,str(r/'tools/literature'))
from ldsc_stratified import workflow_verify as w
evidence=r/'docs/literature/ldsc-stratified-workflow'
def rawpin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def pin(p):return rawpin(p.read_bytes())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
def run(tag,cmd):
 save(out/(tag+'-command.json'),cmd);start=time.monotonic()
 with (out/(tag+'.stdout')).open('xb') as so,(out/(tag+'.stderr')).open('xb') as se:p=subprocess.run(cmd,cwd=r,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=300)
 save(out/(tag+'-PROCESS.json'),dict(exit_code=p.returncode,seconds=time.monotonic()-start));assert p.returncode==0,(tag,p.returncode)
try:
 portable=json.loads((b/'portable-1/COMPLETED.json').read_bytes());assert portable['status']=='PASS_STRATIFIED_CLI_PACKAGED_WINDOWS_LINUX_AND_PUBLIC_EXAMPLES'
 expected=dict(tests=17,errors=0,failures=0,skipped=0);assert portable['windows_junit']==portable['linux_same_junit']==expected and portable['byte_identical_successful_payloads']==46
 for n,v in portable['source_guards'].items():assert pin(r/n)==v,n
 api=w.historical_api();assert set(api['metadata_changes'])=={'docs/literature/IMPLEMENTATION_PRIORITY.md'}
 cli=[p for p in portable['processes'] if p['tag'] not in ['compile-test-sources','windows-tests','linux-tests']];assert len(cli)==33 and all(p['exit_code']==p['expected'] for p in portable['processes']);counts=dict(total=len(cli),success=sum(p['exit_code']==0 for p in cli),skip3=sum(p['exit_code']==3 for p in cli),fail2=sum(p['exit_code']==2 for p in cli));assert counts==dict(total=33,success=11,skip3=6,fail2=16)
 for name in ['docs/vignettes/stratified-ldsc-workflow.md','examples/ldsc-stratified/README.md','docs/literature/ldsc-stratified-workflow/README.md']:
  for target in re.findall(r'\]\(([^)]+)\)',(r/name).read_text(encoding='utf8')):
   if not target.startswith(('https://','http://','#')):assert ((r/name).parent/target.split('#')[0]).exists(),(name,target)
 run('catalog',[sys.executable,'-X','utf8','-B',str(r/'tools/literature/ldsc_hsq/catalog.py'),'--verify','--primary-cache','D:/projects/JLinAlg/build/literature-review/xml','--out',str(out/'catalog-current')])
 catalog=json.loads((out/'catalog-current/COMPLETED.json').read_bytes());assert catalog['new_scoped_integrations']==128 and catalog['current_manifest']['entries']==794
 names=['src/main/java/org/jlinalg/cli/StratifiedLdscCli.java','src/test/java/org/jlinalg/cli/StratifiedLdscCliTest.java','src/main/java/org/jlinalg/xwas/StratifiedLdsc.java','src/test/java/org/jlinalg/xwas/StratifiedLdscTest.java','src/main/java/org/jlinalg/xwas/LdscHeritability.java','src/main/java/org/jlinalg/cli/LdscToolsCli.java','src/main/java/org/jlinalg/cli/NextflowFiles.java','src/main/java/org/jlinalg/cli/NextflowParameters.java','src/main/java/org/jlinalg/cli/NextflowJson.java','docs/vignettes/stratified-ldsc-workflow.md','docs/literature/IMPLEMENTATION_PRIORITY.md','tools/literature/ldsc_stratified/workflow_verify.py','build.gradle',w.API_EVIDENCE+'/VALIDATION.json']
 for folder in ['examples/ldsc-stratified','src/test/resources/org/jlinalg/xwas/ldsc-stratified','docs/literature/ldsc-stratified-workflow']:
  names.extend(p.relative_to(r).as_posix() for p in (r/folder).rglob('*') if p.is_file())
 guards={n:pin(r/n) for n in sorted(set(names))};payload={}
 for folder in ['build-1','build-2','build-3','portable-1','api-intake-1']:
  for p in (b/folder).rglob('*'):
   if p.is_file() and 'jar' not in p.relative_to(b/folder).parts:payload['attempts/'+p.relative_to(b).as_posix()]=p.read_bytes()
 for p in b.glob('*.py'):payload['scripts/'+p.name]=p.read_bytes()
 for n in guards:payload['snapshot/'+n]=(r/n).read_bytes()
 # Include original reference inputs/outputs/source within this bundle. The
 # complete historical API archive remains unchanged and separately verified.
 with zipfile.ZipFile(r/w.API_EVIDENCE/'checks.zip') as z:
  for n in z.namelist():
   if n.startswith('original-cbiit/') or n in ['attempts/reference-2/result/reference.json','reference-runtime/INSTALLED-FILES.json']:payload['prior-science/'+n]=z.read(n)
 for name in ['fixed-overlap','free-overlap','negative-hsq']:
  info=json.loads((b/'portable-1'/('public-example-'+name+'-OUTPUT.json')).read_bytes());folder=Path(info['output'])
  for n,expected_pin in info['files'].items():assert pin(folder/n)==expected_pin;payload['public-examples/'+name+'/'+n]=(folder/n).read_bytes()
 for p in out.rglob('*'):
  if p.is_file():payload['closure/'+p.relative_to(out).as_posix()]=p.read_bytes()
 payload['closure/historical-api-binding.json']=(json.dumps(api,indent=2)+'\n').encode();index={n:rawpin(raw) for n,raw in sorted(payload.items())};payload['ENTRY-MANIFEST.json']=(json.dumps(dict(payloads=index),indent=2)+'\n').encode();archive=evidence/'checks.zip'
 with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for n,raw in sorted(payload.items()):z.writestr(n,raw)
 assert w.read_archive(archive,pin(archive))==len(index)
 result=dict(status='PASS_NATIVE_PREPARED_STRATIFIED_LDSC_WORKFLOW',profile='native-partitioned-ldsc-cbiit302-fixed-initial-v1',windows_junit=expected,linux_same_junit=expected,original_models=48,reference_fields_each_api_and_file_boundary=22596,cli_process_counts=counts,byte_identical_successful_payloads=46,successful_model_pairs=4,public_examples=3,missing_runtime_skipped_and_component_retained=True,native_api_binding=api,source_guards=guards,artifact=portable['artifact'],all_prior_jar_members_unchanged=True,indexed_payloads=len(index),all_archive_payloads_read_back=True,archive=pin(archive),catalog_verified=catalog,original_runtime_reexecuted=False,scientific_engines_changed=False,historical_fingerprints_refreshed=False,new_family_credit=0,whole_tool_qualified=False,whole_goal_complete=False,released=False,pushed=False,website_deployed=False)
 save(evidence/'VALIDATION.json',result);run('retained-verifier',[sys.executable,'-X','utf8','-B',str(r/'tools/literature/ldsc_stratified/workflow_verify.py'),'--out',str(out/'retained-recheck')]);save(out/'COMPLETED.json',result);print(json.dumps({k:result[k] for k in ['status','cli_process_counts','indexed_payloads','archive']}),flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc()));print(traceback.format_exc(),flush=True);raise
