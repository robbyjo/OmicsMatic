import json,zipfile
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];dest=r/'examples/ldsc-stratified';dest.mkdir()
with zipfile.ZipFile(r/'src/test/resources/org/jlinalg/xwas/ldsc-stratified/reference-fixtures.zip') as z:
 configs={row.split('\t')[0]:row.split('\t') for row in z.read('cases.tsv').decode().splitlines()[1:]}
 for name,ident in [('fixed-overlap','S000'),('free-overlap','S002'),('negative-hsq','S008')]:
  c=configs[ident];labels=['A'+str(j) for j in range(int(c[2]))];input_name=ident+'.tsv';overlap_name=ident+'-overlap.tsv'
  rows=['variant\tchi_square\tweight_ld_score\tn\t'+'\t'.join(labels)]+['rs'+str(i)+'\t'+line for i,line in enumerate(z.read(ident+'/input.tsv').decode().splitlines())]
  (dest/input_name).write_text('\n'.join(rows)+'\n',encoding='utf8',newline='\n')
  rows=['annotation\t'+'\t'.join(labels)]+[labels[i]+'\t'+line for i,line in enumerate(z.read(ident+'/overlap.tsv').decode().splitlines())]
  (dest/overlap_name).write_text('\n'.join(rows)+'\n',encoding='utf8',newline='\n')
  request=dict(schema_version=1,analysis='partitioned-hsq',weighting='source-fixed-initial',input=input_name,out='../../build/stratified-ldsc-example-'+name+'-1',annotations=labels,annotation_counts=[float(v) for v in c[6].split(',')],n_blocks=int(c[3]),intercept='free' if c[4]=='free' else float(c[4]),overlap=overlap_name,reference_universe_variants=float(c[5]),data_provenance='Complete synthetic unchanged-original reference '+ident+'; no author GWAS data',row_order_declaration='Exact generated reference order; no claimed study genome order',annotation_provenance='Matching synthetic binary-resource columns/counts/intersections from '+ident)
  (dest/(name+'.json')).write_text(json.dumps(request,indent=2)+'\n',encoding='utf8',newline='\n')
(dest/'.gitattributes').write_text('* -text whitespace=cr-at-eol\n',encoding='utf8',newline='\n')
print('Prepared three complete original-reference workflow examples.')
