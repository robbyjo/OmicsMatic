import hashlib,json,os,subprocess,time,traceback,shutil,xml.etree.ElementTree as ET
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];out=b/'build-1';out.mkdir()
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
try:
 names=['src/main/java/org/jlinalg/cli/StratifiedLdscCli.java','src/test/java/org/jlinalg/cli/StratifiedLdscCliTest.java','src/main/java/org/jlinalg/xwas/StratifiedLdsc.java','src/test/java/org/jlinalg/xwas/StratifiedLdscTest.java'];guards={n:pin(r/n) for n in names};save(out/'SOURCES.json',guards)
 for n in names:
  p=out/'sources'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/n,p)
 rel=out.relative_to(r).as_posix();init=out/'private.gradle';init.write_text("gradle.projectsEvaluated { rootProject.tasks.named('test') { reports.junitXml.outputLocation.set(rootProject.layout.projectDirectory.dir('"+rel+"/test-results')); reports.html.outputLocation.set(rootProject.layout.projectDirectory.dir('"+rel+"/test-report')) }; rootProject.tasks.named('executableJar') { destinationDirectory.set(rootProject.layout.projectDirectory.dir('"+rel+"/jar')) } }\n",newline='\n')
 cmd=[str(r/'gradlew.bat'),'--no-daemon','--console=plain','-I',str(init),':test','--tests','org.jlinalg.xwas.StratifiedLdscTest','--tests','org.jlinalg.cli.StratifiedLdscCliTest',':executableJar'];save(out/'command.json',cmd);start=time.monotonic()
 with (out/'stdout').open('xb') as so,(out/'stderr').open('xb') as se:p=subprocess.run(cmd,cwd=r,env=dict(os.environ,JAVA_HOME='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot'),stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=900)
 save(out/'PROCESS.json',dict(exit_code=p.returncode,seconds=time.monotonic()-start));assert p.returncode==0
 trees=[ET.parse(p).getroot() for p in (out/'test-results').glob('TEST-*.xml')];counts={k:sum(int(t.attrib.get(k,0)) for t in trees) for k in ['tests','errors','failures','skipped']};assert counts==dict(tests=17,errors=0,failures=0,skipped=0),counts;assert all(pin(r/n)==v for n,v in guards.items());save(out/'COMPLETED.json',dict(status='PASS_STRATIFIED_CLI_AND_API_BUILD',junit=counts,artifact=pin(out/'jar/omicsmatic-0.4.0.jar')));print('PASS',counts,flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc()));print(traceback.format_exc(),flush=True);raise
