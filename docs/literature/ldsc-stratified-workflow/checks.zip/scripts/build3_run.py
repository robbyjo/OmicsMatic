import subprocess,sys
from pathlib import Path
b=Path(__file__).resolve().parent;p=b/'build3.py';p.write_text((b/'build.py').read_text().replace("out=b/'build-1'","out=b/'build-3'"),encoding='utf8',newline='\n');raise SystemExit(subprocess.call([sys.executable,'-X','utf8','-B',str(p)]))
