import copy,hashlib,json,os,shutil,subprocess,time,traceback,xml.etree.ElementTree as ET,zipfile
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];out=b/'portable-1';out.mkdir();jdk=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin');distro='JLinAlg-Omics-SAIGE-20261026';junit=r/'build/nfcore-atacseq121-1/linux-test-runtime-1/junit-platform-console-standalone-1.13.4.jar';jar=b/'build-3/jar/omicsmatic-0.4.0.jar';processes=[]
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8',newline='\n')
def linux(p):p=Path(p).resolve();return '/mnt/'+p.drive[0].lower()+'/'+p.as_posix()[3:]
def run(tag,cmd,expected=0):
 save(out/(tag+'-command.json'),cmd);start=time.monotonic()
 with (out/(tag+'.stdout')).open('xb') as so,(out/(tag+'.stderr')).open('xb') as se:p=subprocess.run(cmd,cwd=r,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=900)
 record=dict(tag=tag,exit_code=p.returncode,expected=expected,seconds=time.monotonic()-start);processes.append(record);save(out/(tag+'-PROCESS.json'),record);assert p.returncode==expected,(tag,p.returncode,expected)
def command(platform,request,thin=False):
 cp=out/'thin-runtime' if thin else jar;args=['-cp',str(cp) if platform=='windows' else linux(cp),'org.jlinalg.cli.StratifiedLdscCli','--request',str(request) if platform=='windows' else linux(request)]
 return [str(jdk/'java.exe'),*args] if platform=='windows' else ['wsl.exe','-d',distro,'--','java',*args]
def manifest(folder):
 for name,value in json.loads((folder/'manifest.json').read_bytes()).items():assert pin(folder/name)==value,(folder,name)
 assert pin(folder/'manifest.json')==json.loads((folder/'COMPLETED.json').read_bytes())['manifest']
def directory_pins(folder):return {p.relative_to(folder).as_posix():pin(p) for p in folder.rglob('*') if p.is_file()}
try:
 assert json.loads((b/'build-3/COMPLETED.json').read_bytes())['junit']==dict(tests=17,errors=0,failures=0,skipped=0)
 native_guard=json.loads((r/'docs/literature/ldsc-stratified-development/VALIDATION.json').read_bytes());assert native_guard['status']=='PASS_NATIVE_PREPARED_PARTITIONED_LDSC_API';assert json.loads((b/'api-intake-1/COMPLETED.json').read_bytes())['reference_fields']==22596
 for name,expected in native_guard['source_guards'].items():assert pin(r/name)==expected,name
 before=r/'build/ldsc-stratified-1/portable-1/jar/omicsmatic-0.4.0.jar';new=[]
 prefixes=['org/jlinalg/cli/StratifiedLdscCli','org/jlinalg/xwas/StratifiedLdsc','org/jlinalg/xwas/LdscHeritability','org/jlinalg/cli/LdscToolsCli','org/jlinalg/cli/NextflowFiles','org/jlinalg/cli/NextflowParameters','org/jlinalg/cli/NextflowJson']
 thin=out/'thin-runtime';thin.mkdir()
 with zipfile.ZipFile(before) as old,zipfile.ZipFile(jar) as current:
  assert set(old.namelist())<=set(current.namelist())
  for name in old.namelist():assert old.read(name)==current.read(name),name
  new=sorted(set(current.namelist())-set(old.namelist()));assert all(n.startswith('org/jlinalg/cli/StratifiedLdscCli') for n in new),new
  for name in current.namelist():
   if name.endswith('.class') and any(name.startswith(prefix) for prefix in prefixes):
    dest=thin/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(current.read(name))
 save(out/'PRIOR-JAR-MEMBERS.json',dict(status='PASS_ALL_PRIOR_API_JAR_MEMBERS_UNCHANGED',new_members=new,artifact=pin(jar),baseline=pin(before),deliberately_missing_thin_dependency='jdistlib.T'))
 names=['src/main/java/org/jlinalg/cli/StratifiedLdscCli.java','src/test/java/org/jlinalg/cli/StratifiedLdscCliTest.java','src/main/java/org/jlinalg/xwas/StratifiedLdsc.java','src/test/java/org/jlinalg/xwas/StratifiedLdscTest.java'];guards={n:pin(r/n) for n in names};save(out/'SOURCES.json',guards)
 for n in names:
  dest=out/'sources'/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/n,dest)
 classes=out/'test-classes';classes.mkdir();run('compile-test-sources',[str(jdk/'javac.exe'),'--release','17','-cp',os.pathsep.join(map(str,[jar,junit])),'-d',str(classes),str(r/names[1]),str(r/names[3])])
 for platform in ['windows','linux']:
  report=out/(platform+'-junit');report.mkdir();paths=[jar,classes,r/'src/test/resources'];cp=os.pathsep.join(map(str,paths)) if platform=='windows' else ':'.join(linux(p) for p in paths);args=['execute','--class-path',cp,'--select-class','org.jlinalg.xwas.StratifiedLdscTest','--select-class','org.jlinalg.cli.StratifiedLdscCliTest','--reports-dir',str(report) if platform=='windows' else linux(report),'--details','summary','--disable-ansi-colors'];cmd=[str(jdk/'java.exe'),'-jar',str(junit),*args] if platform=='windows' else ['wsl.exe','-d',distro,'--','java','-jar',linux(junit),*args];run(platform+'-tests',cmd)
  trees=[ET.parse(p).getroot() for p in report.glob('TEST-*.xml')];counts={k:sum(int(t.attrib.get(k,0)) for t in trees) for k in ['tests','errors','failures','skipped']};assert counts==dict(tests=17,errors=0,failures=0,skipped=0),counts;save(out/(platform+'-COUNTS.json'),counts)
 base=json.loads((r/'examples/ldsc-stratified/fixed-overlap.json').read_bytes());variants=[('fixed',base),('free',json.loads((r/'examples/ldsc-stratified/free-overlap.json').read_bytes())),('negative',json.loads((r/'examples/ldsc-stratified/negative-hsq.json').read_bytes()))];variants.append(('no-overlap',dict(base,overlap=None,reference_universe_variants=None)))
 cases=[(name,m,0,False) for name,m in variants]+[(name,dict(base),code,name=='missing-runtime') for name,code in [('bad-overlap',2),('duplicate',2),('unsupported',3),('missing-input',3),('missing-runtime',3),('unknown-key',2),('fractional-overlap',2),('bad-utf8',2),('overlap-order',2),('missing-count',2)]]
 control_outputs={};control_sources={}
 for platform in ['windows','linux']:
  for name,original,code,thin_mode in cases:
   folder=out/platform/name;folder.mkdir(parents=True);m=copy.deepcopy(original);m['out']='result'
   for key in ['input','overlap']:
    if m[key] is not None:shutil.copyfile(r/'examples/ldsc-stratified'/m[key],folder/m[key])
   input_path=folder/m['input'];ov=folder/m['overlap'] if m['overlap'] else None
   if name=='bad-overlap' or name=='fractional-overlap':
    rows=ov.read_text().splitlines();parts=rows[1].split('\t');parts[1]='0' if name=='bad-overlap' else '1200.5';rows[1]='\t'.join(parts);ov.write_text('\n'.join(rows)+'\n',newline='\n')
   if name=='duplicate':
    rows=input_path.read_text().splitlines();first=rows[1].split('\t')[0];parts=rows[2].split('\t');parts[0]=first;rows[2]='\t'.join(parts);input_path.write_text('\n'.join(rows)+'\n',newline='\n')
   if name=='unsupported':m['weighting']='irwls'
   if name=='missing-input':m['input']='not-installed-input.tsv'
   if name=='unknown-key':m['two_step']=30
   if name=='bad-utf8':input_path.write_bytes(input_path.read_bytes()+b'\xff\n')
   if name=='overlap-order':
    rows=ov.read_text().splitlines();rows[1],rows[2]=rows[2],rows[1];ov.write_text('\n'.join(rows)+'\n',newline='\n')
   if name=='missing-count':m['annotation_counts']=m['annotation_counts'][:-1]
   request=folder/'request.json';save(request,m);before_inputs={p.name:pin(p) for p in folder.iterdir() if p.is_file()};run(platform+'-'+name,command(platform,request,thin_mode),code);assert before_inputs=={p.name:pin(p) for p in folder.iterdir() if p.is_file()};dest=folder/'result'
   if code==0:
    assert json.loads((dest/'analysis.json').read_bytes())['result_admitted'] is True;manifest(dest)
    if name=='negative':assert json.loads((dest/'model.json').read_bytes())['fit']['totalH2']<0 and 'Negative coefficients' in (dest/'WARNINGS.md').read_text()
   else:
    assert not (dest/'COMPLETED.json').exists();stderr=(out/(platform+'-'+name+'.stderr')).read_text();assert ('SKIP3' if code==3 else 'FAIL2') in stderr and 'REQUIRED ACTIONS' in stderr
    if dest.exists():assert json.loads((dest/'analysis.json').read_bytes())['result_admitted'] is False and (dest/'FAILURE.txt').exists()
    if name in ['bad-overlap','fractional-overlap','missing-runtime','overlap-order']:assert (dest/'component-model.json').exists()
    if name=='missing-runtime':assert 'jdistlib/T' in stderr or 'jdistlib.T' in stderr
   control_outputs[platform+'-'+name]=directory_pins(dest) if dest.exists() else {};control_sources[platform+'-'+name]=before_inputs
  fixed=out/platform/'fixed';prior=directory_pins(fixed/'result');run(platform+'-existing-output',command(platform,fixed/'request.json'),2);assert directory_pins(fixed/'result')==prior
 for name,_,code,_ in cases:
  if code==0:assert control_outputs['windows-'+name]==control_outputs['linux-'+name],name
 success_payloads=sum(len(control_outputs['windows-'+name]) for name,_,code,_ in cases if code==0)
 for name in ['fixed-overlap','free-overlap','negative-hsq']:
  request=r/'examples/ldsc-stratified'/(name+'.json');dest=(request.parent/json.loads(request.read_bytes())['out']).resolve();assert not dest.exists();run('public-example-'+name,command('windows',request));manifest(dest);save(out/('public-example-'+name+'-OUTPUT.json'),dict(output=str(dest),files=directory_pins(dest)))
 assert all(pin(r/n)==v for n,v in guards.items());save(out/'COMPLETED.json',dict(status='PASS_STRATIFIED_CLI_PACKAGED_WINDOWS_LINUX_AND_PUBLIC_EXAMPLES',windows_junit=dict(tests=17,errors=0,failures=0,skipped=0),linux_same_junit=dict(tests=17,errors=0,failures=0,skipped=0),original_models=48,reference_fields_each_api_and_file_boundary=22596,byte_identical_successful_payloads=success_payloads,successful_model_pairs=4,processes=processes,all_prior_jar_members_unchanged=True,new_jar_members=new,missing_runtime_skipped_and_component_retained=True,public_examples=3,artifact=pin(jar),source_guards=guards,control_outputs=control_outputs,control_sources=control_sources));print('PASS17 same tests, both platform process controls,',success_payloads,'identical files and3 public examples',flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc()));print(traceback.format_exc(),flush=True);raise
