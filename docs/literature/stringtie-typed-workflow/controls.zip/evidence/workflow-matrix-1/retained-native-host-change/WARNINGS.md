

# FAIL2 — NO RESULT ADMITTED

Stage: current-host exact runtime and fresh health admission

java.io.IOException: Host member changed during its complete census: /etc/resolv.conf

Read WARNINGS.md, metadata/OUTPUT-AUDIT.json and fit/process.stderr plus fit/process.json. SKIP3: a required permitted runtime, helper, library or capability is unavailable; skip dependent analysis until exact permitted setup succeeds. FAIL2: invalid/changed inputs, failed process/audit, cancellation or capacity failure; no result is admitted. Preserve all attempts, correct the named cause and use NEW output paths. Verification rechecks complete captured inputs and outputs without opening recorded producer paths; hashes prove integrity, not authenticity or biological accuracy. Cell Ranger remains excluded.
