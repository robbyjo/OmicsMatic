
import copy,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
base,jar,out=map(Path,sys.argv[1:]);assert not base.exists();base.mkdir(mode=0o700)
root=Path('/mnt/d/projects/JLinAlg');old=Path('/var/tmp/omicsmatic-stringtie-setup-20261103-1');original=root/'build/literature-review/stringtie-runtime/original-controls-1';records=[];completed=[]
def pin(path):
 with path.open('rb') as stream:return dict(bytes=path.stat().st_size,sha256=hashlib.file_digest(stream,'sha256').hexdigest())
def invoke(label,args,expected=0):
 command=['/usr/bin/java','-Xmx512m','-XX:ActiveProcessorCount=2','-cp',str(jar),'org.jlinalg.cli.StringTieToolsCli',*map(str,args)]
 with (out/(label+'.stdout')).open('xb') as stdout,(out/(label+'.stderr')).open('xb') as stderr:
  process=subprocess.run(command,env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C'},stdout=stdout,stderr=stderr,timeout=180,check=False)
 record=dict(label=label,command=command,exit_code=process.returncode,expected_exit=expected);records.append(record);(out/(label+'.process.json')).write_text(json.dumps(record,indent=2)+'\n');(out/'NATIVE-PROGRESS.json').write_text(json.dumps(records,indent=2)+'\n');assert process.returncode==expected,(label,process.returncode,expected)
def recipe(version,mode):
 return dict(schema_version=1,profile='linux-x86_64-stringtie-'+version,mode=mode,bam=None if mode=='MERGE' else str(original/'inputs/reads.bam'),reference_sizes=str(original/'inputs/reference.sizes'),guide=str(original/'inputs/guide.gtf') if mode in ['ESTIMATE','MERGE'] else None,merge_inputs=[],genome_build='synthetic-two-contigs-not-human',strand='UNSTRANDED',bam_policies=None if mode=='MERGE' else dict(missing_NH='ERROR',missing_XS='ERROR',sort_header='REQUIRE_COORDINATE'),population='COMPLETE' if mode=='ESTIMATE' else None,threads=1,parameters=dict(trimming='ORIGINAL_DEFAULT',minimum_length=None,minimum_isoform_fraction=None,minimum_coverage=None,minimum_FPKM=None,minimum_TPM=None),limits={})
def fit(label,document,expected_case=None,home=None,expected=0):
 source=base/(label+'.json');source.write_text(json.dumps(document,indent=2)+'\n');bundle=base/label;version=document['profile'].removeprefix('linux-x86_64-stringtie-')
 invoke(label,['--recipe',source,'--home',home or old/('home-'+version),'--setup-report',old/('install-'+version),'--out',bundle],expected)
 if expected:
  assert (bundle/'INCOMPLETE.json').exists() and not(bundle/'COMPLETED.json').exists();assert json.loads((bundle/'FAILURE.json').read_bytes())['status'].startswith('SKIP3' if expected==3 else 'FAIL2');shutil.copytree(bundle,out/'negative-evidence'/label);return bundle
 completion=json.loads((bundle/'COMPLETED.json').read_bytes());assert completion['manifest']==pin(bundle/'manifest.json') and not(bundle/'INCOMPLETE.json').exists()
 if expected_case:
  science=lambda p:b''.join(line for line in p.read_bytes().splitlines(keepends=True) if not line.startswith(b'#'))
  assert science(bundle/'fit/transcripts.gtf')==science(original/version/expected_case/'transcripts.gtf'),(label,'original GTF scientific rows differ')
  if document['mode']=='ESTIMATE':
   for name in ['gene-abundance.tsv','t_data.ctab','e_data.ctab','i_data.ctab','e2t.ctab','i2t.ctab']:assert (bundle/'fit'/name).read_bytes()==(original/version/expected_case/name).read_bytes()
 shutil.copytree(bundle,out/'bundles'/label);completed.append(label);return bundle
for version in ['1.3.0','1.3.6','2.1.2','2.1.7','2.2.1','3.0.0','3.0.3']:
 assembly=fit(version+'-assembly',recipe(version,'ASSEMBLE'),'assembly')
 fit(version+'-estimate',recipe(version,'ESTIMATE'),'estimate')
 d=recipe(version,'MERGE');d['merge_inputs']=[str(assembly/'fit/transcripts.gtf'),str(original/version/'guided/transcripts.gtf')];d['parameters']['minimum_length']=150;fit(version+'-merge',d,'merge')
d=recipe('3.0.3','ASSEMBLE');d['guide']=str(original/'inputs/guide.gtf');fit('3.0.3-guided',d,'guided')
d=recipe('3.0.3','ESTIMATE');d['bam']=str(original/'inputs/empty.bam');empty=fit('3.0.3-empty-estimate',d,'empty-estimate');assert json.loads((empty/'metadata/OUTPUT-AUDIT.json').read_bytes())['TPM_denominator']['resolution']=='ALL_ZERO_UNRESOLVED'
d=recipe('3.0.0','ASSEMBLE');d['strand']='FR_FIRSTSTRAND';d['parameters'].update(trimming='DISABLE',minimum_length=150,minimum_isoform_fraction=0.3);fit('3.0.0-paper171-documented-rf',d,'paper171-documented-rf')
fit('missing-runtime',recipe('3.0.3','ASSEMBLE'),home=base/'not-installed',expected=3)
d=recipe('3.0.3','ASSEMBLE');d['limits']['bam_records']=1;fit('BAM-capacity',d,expected=2)
assert len(completed)==24
(out/'NATIVE.json').write_text(json.dumps(dict(status='passed-24-actual-public-command-fits-with-independent-original-output-comparisons',linux_root=str(base),complete_fit_bundles=len(completed),independent_original_comparisons=len(completed),fresh_native_runtime_health_fits=len(completed),records=records),indent=2)+'\n')
