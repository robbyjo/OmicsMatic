
import hashlib,json,shutil,subprocess,sys
from pathlib import Path
base,jar,out,prepare=map(Path,sys.argv[1:]);assert not base.exists();base.mkdir(mode=0o700);work=base/'standalone-work';work.mkdir();records=[]
def pin(path):
 with path.open('rb') as stream:return dict(bytes=path.stat().st_size,sha256=hashlib.file_digest(stream,'sha256').hexdigest())
def run(label,command,expected=0,cwd=work):
 with (out/(label+'.stdout')).open('xb') as stdout,(out/(label+'.stderr')).open('xb') as stderr:process=subprocess.run(list(map(str,command)),cwd=cwd,env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C'},stdout=stdout,stderr=stderr,timeout=180,check=False)
 row=dict(label=label,command=list(map(str,command)),exit_code=process.returncode,expected_exit=expected);records.append(row);(out/(label+'.process.json')).write_text(json.dumps(row,indent=2)+'\n');assert process.returncode==expected,(label,process.returncode)
java=['/usr/bin/java','-Xmx512m','-XX:ActiveProcessorCount=2','-cp',jar,'org.jlinalg.cli.StringTieToolsCli'];kit=base/'kit';example=base/'example';home=Path('/var/tmp/omicsmatic-stringtie-setup-20261103-1/home-3.0.3');setup=home.parent/'install-3.0.3'
run('export-runtime-kit',[*java,'--export-runtime-setup',kit]);run('prepare-example',['/usr/bin/python3','-I','-B',prepare,'--kit',kit,'--out',example,'--profile','linux-x86_64-stringtie-3.0.3']);proof=json.loads((example/'EXAMPLE.json').read_bytes());assert not proof['user_analysis_performed'] and not(example/'INCOMPLETE.json').exists()
assert all(pin(example/'inputs'/n)==v for n,v in proof['inputs'].items());initial=pin(example/'EXAMPLE.json')
for recipe,label in [('assemble','assembly'),('estimate','estimation'),('merge','merged')]:
 bundle=example/label;run(label,[*java,'--recipe',example/(recipe+'.json'),'--home',home,'--setup-report',setup,'--out',bundle]);run(label+'-verify',java+['--verify',bundle]);shutil.copytree(bundle,out/'bundles'/label)
assert initial==pin(example/'EXAMPLE.json') and all(pin(example/'inputs'/n)==v for n,v in proof['inputs'].items())
# An unmodified original invocation independently checks this example's one-input
# default merge protocol; the earlier retained control used two inputs and -m150.
reference=base/'original-one-input-default-merge';reference.mkdir();binary=home/'bin/stringtie';before=pin(binary)
run('original-default-merge',[binary,'--merge','-G',example/'inputs/guide.gtf','-o','transcripts.gtf',example/'assembly/fit/transcripts.gtf'],cwd=reference)
science=lambda path:b''.join(line for line in path.read_bytes().splitlines(keepends=True) if not line.startswith(b'#'))
assert science(reference/'transcripts.gtf')==science(example/'merged/fit/transcripts.gtf') and before==pin(binary)
shutil.copytree(reference,out/'independent-original-default-merge');shutil.copytree(kit,out/'exported-kit')
for name in ['EXAMPLE.json','assemble.json','estimate.json','merge.json']:
 shutil.copyfile(example/name,out/name)
(out/'NATIVE.json').write_text(json.dumps(dict(status='passed-actual-documented-example-from-standalone-private-working-directory',linux_root=str(base),working_directory=str(work),user_fits=3,independent_original_merge=1,records=records),indent=2)+'\n')
