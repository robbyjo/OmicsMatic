# FAIL2 NO LOWESS RESULT

AssertionError(('original-r362', b'Error: identical(expected, m$lo.fit) is not TRUE\nExecution halted\n'))

Required action: preserve complete original curves, software, parameters and failed controls. Inspect the named numeric/order/capacity discrepancy. Do not drop points, rescale inputs or replace source output to force agreement. Use a new control path after correction.
