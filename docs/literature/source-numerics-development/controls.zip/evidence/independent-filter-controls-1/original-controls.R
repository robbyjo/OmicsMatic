args <- commandArgs(trailingOnly=TRUE)
library(DESeq2)
stopifnot(as.character(getRversion())=="3.6.2",as.character(packageVersion("DESeq2"))=="1.26.0")
root <- args[1]; e <- new.env();load(file.path(root,"original-dds-rld.RData"),envir=e)
actual <- results(e$dds,contrast=c("condition","SPT5_T0","SPT5_T15"))
cases <- list(
 complete_original_1472=list(bm=actual$baseMean,p=actual$pvalue,alpha=0.1),
 at_most_ten_rejections=list(bm=seq_len(100),p=seq(0.0001,1,length.out=100),alpha=0.1),
 adaptive_many_rejections=list(bm=seq_len(300),p=c(rep(0.8,150),seq(0.00001,0.2,length.out=150)),alpha=0.1),
 all_zero_means=list(bm=rep(0,20),p=rep(NA_real_,20),alpha=0.1),
 mostly_zero_means=list(bm=c(rep(0,97),1,2,3),p=c(rep(NA_real_,97),0.001,0.2,0.01),alpha=0.1),
 mixed_missing=list(bm=seq_len(15),p=c(NA_real_,NaN,seq(0.0001,0.01,length.out=13)),alpha=0.1),
 strict_alpha_equal=list(bm=rep(1,40),p=rep(0.1,40),alpha=0.1),
 strict_alpha_just_below=list(bm=rep(1,40),p=rep(0.1-.Machine$double.eps*0.1,40),alpha=0.1),
 tied_base_means=list(bm=rep(c(0,1,10,100),each=30),p=c(rep(NA_real_,30),seq(0.5,0.9,length.out=30),seq(0.001,0.05,length.out=30),seq(0.00001,0.02,length.out=30)),alpha=0.1),
 singleton=list(bm=2,p=0.05,alpha=0.1),
 all_missing=list(bm=seq_len(15),p=rep(c(NA_real_,NaN,NA_real_),5),alpha=0.1),
 extreme_probabilities=list(bm=seq_len(100),p=c(0,10^seq(-320,-1,length.out=99)),alpha=1e-12))
fmt <- function(x) {
 ifelse(is.nan(x),"NaN",ifelse(is.na(x),"NA",sprintf("%.17g",x)))
}
for (name in names(cases)) {
 c <- cases[[name]]; directory <- file.path(root,name);dir.create(directory)
 res <- DESeqResults(S4Vectors::DataFrame(baseMean=c$bm,log2FoldChange=rep(0,length(c$bm)),lfcSE=rep(1,length(c$bm)),stat=rep(0,length(c$bm)),pvalue=c$p,padj=rep(NA_real_,length(c$bm))))
 S4Vectors::mcols(res) <- S4Vectors::DataFrame(type=rep("results",6),description=rep("",6))
 result <- DESeq2:::pvalueAdjustment(res,independentFiltering=TRUE,alpha=c$alpha,pAdjustMethod="BH")
 m <- metadata(result); theta <- m$filterNumRej$theta; cutoffs <- quantile(c$bm,theta)
 families <- genefilter::filtered_p(filter=c$bm,test=c$p,theta=theta,method="BH")
 threshold <- "NOT_CALCULATED"
 if (max(m$filterNumRej$numRej)>10) {
  residual <- m$filterNumRej$numRej[m$filterNumRej$numRej>0]-m$lo.fit$y[m$filterNumRej$numRej>0]
  threshold <- fmt(max(m$lo.fit$y)-sqrt(mean(residual^2)))
 }
 write.table(data.frame(base_mean=fmt(c$bm),pvalue=fmt(c$p)),file.path(directory,"input.tsv"),sep="\t",quote=FALSE,row.names=FALSE)
 writeLines(fmt(c$alpha),file.path(directory,"alpha.txt"))
 write.table(data.frame(theta=fmt(theta),cutoff=fmt(cutoffs),rejections=m$filterNumRej$numRej,smoothed=fmt(m$lo.fit$y)),file.path(directory,"curve.tsv"),sep="\t",quote=FALSE,row.names=FALSE)
 write.table(data.frame(index=match(m$filterTheta,theta)-1L,theta=fmt(m$filterTheta),cutoff=fmt(m$filterThreshold),threshold=threshold),file.path(directory,"selected.tsv"),sep="\t",quote=FALSE,row.names=FALSE)
 write.table(data.frame(adjusted=fmt(result$padj)),file.path(directory,"adjusted.tsv"),sep="\t",quote=FALSE,row.names=FALSE)
 text <- matrix(fmt(families),nrow=nrow(families),ncol=ncol(families))
 write.table(text,file.path(directory,"all-families.tsv"),sep="\t",quote=FALSE,row.names=FALSE,col.names=paste0("theta",seq_len(50)))
}
writeLines(names(cases),file.path(root,"cases.txt"))
writeLines(capture.output(sessionInfo()),file.path(root,"sessionInfo.txt"))
writeLines("PASS_ORIGINAL_DESEQ126_DEFAULT_FILTER_FIXTURES")
