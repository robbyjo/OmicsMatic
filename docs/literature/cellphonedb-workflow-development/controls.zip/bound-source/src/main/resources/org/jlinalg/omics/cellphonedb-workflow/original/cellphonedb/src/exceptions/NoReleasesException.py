class NoReleasesException(Exception):
    pass
