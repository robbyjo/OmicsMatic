from pathlib import Path
import concurrent.futures,json,subprocess
from prepare_skat_acat_20261122_108 import R,T,O,BASE
from prepare_handover_qtltools_20261121_105 import pin,save
B=T/'build/skat-acat-1';E=B/'example-1';J=B/'normal-gradle-2/project-build/cli/omicsmatic-0.4.0.jar'
J21='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe';J25='C:/Program Files/Java/jdk-25/bin/java.exe'
def mount(path):return '/mnt/'+path.drive[0].lower()+'/'+path.as_posix()[3:]
def run(label,command):
    f=E/label;f.mkdir();save(f/'STARTED.json',dict(command=command,working_directory=str(T)))
    with (f/'stdout').open('xb') as out,(f/'stderr').open('xb') as err:p=subprocess.run(command,cwd=T,stdin=subprocess.DEVNULL,stdout=out,stderr=err,timeout=120)
    save(f/'PROCESS.json',dict(exit_code=p.returncode));assert p.returncode==0,(label,(f/'stderr').read_text());return dict(exit_code=p.returncode)
if __name__=='__main__':
    E.mkdir();assert pin(J.read_bytes())==json.loads((B/'normal-gradle-2/RESULT.json').read_bytes())['producer']
    names=['native-matrix.json','replay.json'];inputs={n:pin((T/'examples/acat091'/n).read_bytes()) for n in names};save(E/'INPUTS.json',inputs)
    run('run',[J21,'-jar',str(J),'acat-tools','--request',str(T/'examples/acat091/native-matrix.json')])
    cap=T/'build/acat091-example';assert json.loads((cap/'analysis-status.json').read_bytes())['result_admitted']
    old=(cap/'capture-files.json').read_bytes()
    commands={'verify-windows21':[J21,'-jar',str(J),'acat-tools','--verify',str(cap)],'verify-windows25':[J25,'-jar',str(J),'acat-tools','--verify',str(cap)],'verify-linux21':['wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','-u','root','--','java','-jar',mount(J),'acat-tools','--verify',mount(cap)]}
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool: verified=dict(pool.map(lambda item:(item[0],run(*item)),commands.items()))
    run('replay',[J21,'-jar',str(J),'acat-tools','--request',str(T/'examples/acat091/replay.json')])
    replay=T/'build/acat091-example-replay';run('verify-replay',[J21,'-jar',str(J),'acat-tools','--verify',str(replay)])
    assert (cap/'capture-files.json').read_bytes()==old and (cap/'p-values.tsv').read_bytes()==(replay/'p-values.tsv').read_bytes()
    assert inputs=={n:pin((T/'examples/acat091'/n).read_bytes()) for n in names}
    save(E/'RESULT.json',dict(status='PASS_PUBLIC_EXAMPLE_NATIVE_RUN_THREE_HOST_VERIFY_AND_REPLAY',producer=pin(J.read_bytes()),requests=inputs,verification=verified,parent_unchanged=True,complete_exports_equal=True,p_values=(cap/'p-values.tsv').read_text(),original_R_executed=False,scientific_inputs_artificial=True))
    print((cap/'p-values.tsv').read_text(),flush=True)
