import json,subprocess
from prepare_skat_acat_20261122_108 import R,T,O
from prepare_handover_qtltools_20261121_105 import pin,save
B=T/'build/skat-acat-1';D=B/'replay-alias-before-fix-1';D.mkdir();jar=B/'normal-gradle-1/project-build/cli/omicsmatic-0.4.0.jar';JAVA='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe'
def run(label,args):
    with (D/(label+'.stdout')).open('xb') as stdout,(D/(label+'.stderr')).open('xb') as stderr:result=subprocess.run(args,cwd=T,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=60)
    save(D/(label+'.PROCESS.json'),dict(command=args,exit_code=result.returncode));return result.returncode
request=dict(schema_version=1,mode='RUN',engine='native',profile='0.91',operation='COMBINE',out=str(D/'parent'),p_values=[[.1],[.2]])
save(D/'request.json',request);assert run('parent',[JAVA,'-jar',str(jar),'acat-tools','--request',str(D/'request.json')])==0
before=(D/'parent/capture-files.json').read_bytes();alias=D/'alias';target=D/'parent';assert alias.resolve().is_relative_to(B.resolve()) and target.resolve().is_relative_to(B.resolve())
assert run('create-owned-junction',['cmd.exe','/c','mklink','/J',str(alias),str(target)])==0
save(D/'replay.json',dict(schema_version=1,mode='REPLAY',analysis=str(target),out=str(alias/'nested')))
code=run('replay',[JAVA,'-jar',str(jar),'acat-tools','--request',str(D/'replay.json')]);mutated=(target/'nested').exists();assert mutated,'The suspected gap was not reproduced;inspect evidence'
save(D/'RESULT.json',dict(status='FAIL2_UNADMITTED_REPLAY_ALIAS_PRESERVATION_CONTROL',producer=pin(jar.read_bytes()),replay_exit_code=code,expected_parent_unchanged=True,parent_mutated=mutated,parent_old_seal_bytes_unchanged=(target/'capture-files.json').read_bytes()==before,reason='The old lexical output check missed an owned junction to the parent. Child execution occurred inside the parent and only the final parent verify detected extra files. Preserve all synthetic outcomes and exact normal1 source;do not promote this control.',scientific_inputs_artificial=True,canonical_data_or_old_worktrees_modified=False))
print('Reproduced and retained:old replay returned',code,'but mutated its parent through the owned junction;control is unadmitted',flush=True)
