from pathlib import Path
import hashlib,json
from prepare_skat_acat_20261122_108 import R,T,O,BASE
from prepare_handover_qtltools_20261121_105 import save,git

if __name__=='__main__':
    audit=json.loads((O/'ROOT-VARIANTS.json').read_bytes()); rows=[row for row in audit['files'] if row['relation']!='same-as-main']
    objects=git(T,'rev-list','--objects',BASE,'--',*[row['path'] for row in rows]).decode().splitlines()
    known={line.split(' ',1)[0] for line in objects};result=[]
    for row in rows:
        raw=(R/row['path']).read_bytes();oid=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
        result.append(dict(path=row['path'],sha256=row['root']['sha256'],blob=oid,already_reachable_from_main=oid in known))
    save(O/'ROOT-VARIANT-HISTORY.json',dict(baseline=BASE,root_variants=result,all_already_reachable_from_main=all(row['already_reachable_from_main'] for row in result)))
    print(json.dumps(result,indent=2))
