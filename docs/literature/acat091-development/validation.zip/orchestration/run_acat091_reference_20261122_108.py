import os,subprocess
from prepare_skat_acat_20261122_108 import R,T,O
from prepare_handover_qtltools_20261121_105 import pin,save
B=T/'build/skat-acat-1';D=B/'acat091-reference-1';source=B/'upstream-intake-1/ACAT/source/R/ACAT.R';wanted=pin(source.read_bytes());assert wanted['sha256']=='cab2a44bb165ee2da87cb0c57d2170b1f7a5c5e09bc231367d7e74b47f9c28eb'
script=R/'build/collect_acat091_references_20261122_108.R';command=['C:/Program Files/R/R-4.6.1/bin/Rscript.exe','--vanilla',str(script),str(source),str(D)];env=dict(os.environ,LANG='C',LC_ALL='C',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
save(D/'STARTED.json',dict(command=command,source=wanted,driver=pin(script.read_bytes()),artificial_inputs=True))
with (D/'stdout').open('xb') as stdout,(D/'stderr').open('xb') as stderr:process=subprocess.run(command,cwd=T,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=300)
save(D/'PROCESS.json',dict(exit_code=process.returncode));assert pin(source.read_bytes())==wanted
print((D/'stdout').read_text(),(D/'stderr').read_text()[-1800:]);raise SystemExit(process.returncode)
