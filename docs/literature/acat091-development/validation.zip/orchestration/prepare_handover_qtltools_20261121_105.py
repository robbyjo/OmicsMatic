from pathlib import Path
import ast, concurrent.futures, hashlib, importlib.util, json, subprocess

R=Path('D:/projects/JLinAlg'); D=R/'build/qt-2'; T=R/'build/handover-105'
O=R/'build/git-publish/20261121-handover-qtltools-105'
BASE='ec11adbaf549b18ffd3d01fcc9d2584c2859e1d6'
JAR=R/'build/qt-1/build/qtltools-fdensity-1/normal-gradle-2/project-build/cli/omicsmatic-0.4.0.jar'
JAVA=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin')

def save(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as f: json.dump(value,f,indent=2); f.write('\n')
def pin(raw): return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def git(root,*args): return subprocess.check_output(['git','--no-replace-objects',*args],cwd=root,stdin=subprocess.DEVNULL)
def inventory():
    spec=importlib.util.spec_from_file_location('inventory',O.parent/'20261115-all-main-3/inventory.py')
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module
def diagnostic(label,sources):
    folder=O/label; folder.mkdir(); target=folder/'classes'; target.mkdir()
    command=[str(JAVA/'javac.exe'),'--release','17','-encoding','UTF-8','-cp',str(JAR),'-d',str(target),*[str(D/source) for source in sources]]
    save(folder/'STARTED.json',dict(command=command,scope='draft compilation diagnostic only; no model execution or production qualification'))
    with (folder/'stdout').open('xb') as stdout,(folder/'stderr').open('xb') as stderr:
        p=subprocess.run(command,cwd=D,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=120)
    result=dict(exit_code=p.returncode,source_files={name:pin((D/name).read_bytes()) for name in sources},production_admitted=False)
    save(folder/'RESULT.json',result); return label,result

if __name__=='__main__':
    O.mkdir(parents=True)
    inv=inventory(); states=[inv.snapshot(Path(block.splitlines()[0][9:])) for block in git(R,'worktree','list','--porcelain').decode().strip().split('\n\n')]
    assert len(states)==61; save(O/'WORKTREES-BEFORE.json',states)
    old=json.loads((O.parent/'20261121-qtltools-workflow-104/WORKTREES-BEFORE.json').read_bytes())
    lookup={s['root']:s for s in states}
    for state in old: assert lookup[state['root']]==state,state['root']
    assert git(D,'rev-parse','HEAD').decode().strip()==BASE
    assert git(D,'ls-remote','origin','refs/heads/main').decode().split()[0]==BASE
    for state in states:
        assert subprocess.run(['git','merge-base','--is-ancestor',state['head'],BASE],cwd=R,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0,state['root']
    save(O/'PRESERVATION-BASELINE.json',dict(prior60_unchanged=True,all61_HEADs_already_reachable_from_main=True,baseline=BASE))
    jar=pin(JAR.read_bytes()); assert jar==dict(bytes=197267583,sha256='4adcd89262b3f5cf748c5eb1060491bcf83aa8b957554349b9be08278633bc8e')
    save(O/'QUALIFIED-JAR.json',dict(path=str(JAR),**jar))
    command=['git','worktree','add','-b','codex/handover-20261121-qtltools',str(T),BASE]
    save(O/'WORKTREE-STARTED.json',dict(command=command))
    with (O/'worktree.stdout').open('xb') as stdout,(O/'worktree.stderr').open('xb') as stderr:
        p=subprocess.run(command,cwd=R,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=240)
    save(O/'WORKTREE-PROCESS.json',dict(exit_code=p.returncode)); assert p.returncode==0
    groups={'draft-java':['src/main/java/org/jlinalg/cli/QtltoolsWorkflow'+name+'.java' for name in ['Contracts','Files','Runtime']], 'synthetic-generator':['tools/literature/qtltools_workflow/SyntheticQtltoolsInputs.java']}
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool: results=dict(pool.map(lambda pair:diagnostic(*pair),groups.items()))
    worker=D/'src/main/resources/org/jlinalg/omics/qtltools-workflow/owned_worker.py'; ast.parse(worker.read_text(encoding='utf-8'))
    profiles=json.loads(worker.with_name('PROFILES.json').read_bytes()); assert profiles['worker_sha256']==pin(worker.read_bytes())['sha256']
    save(O/'DIAGNOSTICS.json',dict(java=results,python_syntax=True,worker_profile_hash_matches=True,scientific_analyses_executed=0,production_admitted=False))
    print(json.dumps(dict(status='HANDOVER_OWNER_READY',preserved_owners=61,publication_owner=str(T),java_exit_codes={k:v['exit_code'] for k,v in results.items()},worker_syntax=True)),flush=True)
