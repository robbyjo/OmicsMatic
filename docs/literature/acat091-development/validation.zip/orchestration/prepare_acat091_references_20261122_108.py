import json,math,random
from prepare_skat_acat_20261122_108 import R,T,O
from prepare_handover_qtltools_20261121_105 import save,pin
B=T/'build/skat-acat-1';D=B/'acat091-reference-1';D.mkdir();rows=D/'inputs';rows.mkdir();cases=[]
def add(name,p,w=None):
    if not isinstance(p[0],list):p=[[v] for v in p];w=None if w is None else [[v] for v in w]
    cases.append(dict(id=name,p=p,w=w))
add('ordinary',[.02,.0004,.2,.1,.8]);add('p-zero',[0,.1]);add('p-one',[1,.1]);add('negative-zero',[-0.0,.1]);add('zero-weight-zero',[0,.1],[0,1]);add('zero-weight-one',[1,.1],[0,1]);add('opposing-endpoints',[0,1],[1,0]);add('huge-weight-sum',[.01,.8],[1e308,1e308]);add('all-smallest',[5e-324,5e-324]);add('finite-mean-after-large-sum',[1e-308]*11);add('near-one-cancellation',[1e-16,1-1e-16]);add('exact-half',[.5]*4);add('negative-weight',[.1,.2],[-1,2]);add('zero-weight-column',[.1,.2],[0,0]);add('negative-p',[-.1,.2]);add('above-one',[1.1,.2]);add('nan-p',['NaN',.1]);add('inf-p',['Inf',.1]);add('nan-weight',[.1,.2],['NaN',1]);add('inf-weight',[.1,.2],['Inf',1]);add('matrix-endpoint-columns',[[0,1,.1],[.3,.2,.8]]);add('matrix-one-invalid-column',[[0,.1],[1,.3]])
for n,p in enumerate([1e-300,1e-200,1e-16,math.nextafter(1e-15,0),1e-15,math.nextafter(1e-15,1),.1,.25,.5,.75,1-1e-12,math.nextafter(1,0)]):add('single-'+str(n),[p])
rng=random.Random(20261122)
for n in range(240):
    nr=rng.choice([2,3,7,20,65,127]);nc=rng.choice([1,2,4]);p=[];w=[]
    for i in range(nr):
        pp=[];ww=[]
        for j in range(nc):
            choice=rng.randrange(5);value=10**rng.uniform(-307,-.0001) if choice<2 else 1-10**rng.uniform(-15,-1) if choice==2 else rng.random();pp.append(value);ww.append(0 if rng.randrange(13)==0 else 10**rng.uniform(-280,280))
        p.append(pp);w.append(ww)
    if n%2==0:add('random-'+str(n),p)
    else:
        for j in range(nc):w[0][j]=1
        add('random-'+str(n),p,w)
manifest=[]
for c in cases:
    for kind in ['p','w']:
        if c[kind] is None:continue
        path=rows/(c['id']+'-'+kind+'.tsv');path.write_text('\n'.join('\t'.join(format(v,'.17g') if isinstance(v,(int,float)) else v for v in row) for row in c[kind])+'\n',encoding='utf-8',newline='\n')
    manifest.append('\t'.join([c['id'],str(len(c['p'])),str(len(c['p'][0])),str(rows/(c['id']+'-p.tsv')),str(rows/(c['id']+'-w.tsv')) if c['w'] is not None else 'NULL']))
(D/'MANIFEST.tsv').write_text('\n'.join(manifest)+'\n',encoding='utf-8',newline='\n');save(D/'CASES.json',cases)
terms=[[1e308,1e308,-1e308],[1e308,1,-1e308],[2.0**63,1,-2.0**63],[2.0**64,1,-2.0**64],[1e308,1e308],[5e-324,1e-323,5e-324],[1,-1,0],[.1]*129,[-0.0]*3,['Inf',1],['Inf','-Inf'],['NaN',1]]
for n in range(180):terms.append([rng.choice([-1,1])*10**rng.uniform(-300,300) for _ in range(rng.choice([2,3,7,65,127]))])
(D/'SUM-INPUTS.tsv').write_text('\n'.join('sum-'+str(i)+'\t'+','.join(format(v,'.17g') if isinstance(v,(int,float)) else v for v in term) for i,term in enumerate(terms))+'\n',encoding='utf-8',newline='\n')
print('Prepared',len(cases),'artificial original-ACAT matrix cases and',len(terms),'R extended accumulation cases',flush=True)
