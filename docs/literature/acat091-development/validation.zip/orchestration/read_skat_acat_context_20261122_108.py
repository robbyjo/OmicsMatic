import json,sys
from prepare_skat_acat_20261122_108 import R,T,O
D=T/'build/skat-acat-1/source-discovery-1/private-context'
ids=sys.argv[1:]
for pid in ids:
    row=json.loads((D/(pid+'.json')).read_bytes());print('\nPAPER',pid,row['title'],row['identity']['doi'])
    print('EXISTING',[(r['tool_id'],r['evidence_paragraph_index'],r.get('version_reported_near_name')) for r in row['existing_tools']])
    existing={r['evidence_paragraph_index'] for r in row['existing_tools']}
    for block in row['paragraphs']:
        if block['paragraph_index'] in existing or any(w in block['section'].lower() for w in ['methods','method','code availability']):print('PARAGRAPH',block['paragraph_index'],block['section'],'\n'+block['text'])
    for table in row['tables']:print('TABLE',table['id'],table['text'])
