from pathlib import Path
import json,subprocess
from prepare_skat_acat_20261122_108 import R,T,O,BASE
from prepare_handover_qtltools_20261121_105 import pin,save,git,inventory

if __name__=='__main__':
    states=json.loads((O/'WORKTREES-BEFORE.json').read_bytes()); inv=inventory()
    for state in states: assert inv.snapshot(Path(state['root']))==state,state['root']
    root=states[0]; assert root['root']==str(R)
    rows=[]
    for name,wanted in root['files'].items():
        process=subprocess.run(['git','show',BASE+':'+name],cwd=T,stdin=subprocess.DEVNULL,capture_output=True)
        main=None if process.returncode else pin(process.stdout)
        local=None if wanted is None else {k:wanted[k] for k in ['bytes','sha256']}
        rows.append(dict(path=name,root=local,main=main,relation='same-as-main' if main==local else 'root-variant' if main else 'not-in-main'))
    result=dict(status='ALL64_PRECEDING_OWNERS_PRESERVED',owners=64,baseline=BASE,root_branch=root['branch'],root_head=root['head'],root_git_visible_files=len(rows),summary={k:sum(r['relation']==k for r in rows) for k in ['same-as-main','root-variant','not-in-main']},files=rows)
    save(O/'ROOT-VARIANTS.json',result)
    print(json.dumps({k:v for k,v in result.items() if k!='files'},indent=2))
    for row in rows:
        if row['relation']!='same-as-main': print(row['relation'],row['path'])
