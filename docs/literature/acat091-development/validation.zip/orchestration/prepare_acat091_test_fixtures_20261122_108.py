import csv,json,math
from prepare_skat_acat_20261122_108 import R,T,O
from prepare_handover_qtltools_20261121_105 import pin,save
B=T/'build/skat-acat-1';D=B/'acat091-reference-1';Q=T/'src/test/resources/org/jlinalg/settest/acat091';Q.mkdir(parents=True)
def table(name):
    with (D/'original'/name).open(encoding='utf-8-sig',newline='') as stream:return list(csv.DictReader(stream,delimiter='\t'))
cases=json.loads((D/'CASES.json').read_bytes());values={};errors={r['id']:r['message'] for r in table('ERRORS.tsv')};warnings={}
for row in table('VALUES.tsv'):values.setdefault(row['id'],[]).append(row['p'])
for row in table('WARNINGS.tsv'):warnings.setdefault(row['id'],[]).append(row['message'])
for row in cases:row['original']=dict(returned=row['id'] not in errors,values=values.get(row['id'],[]),error=errors.get(row['id']),warnings=warnings.get(row['id'],[]))
save(Q/'original-cases.json',cases)
sums={row['id']:row for row in table('SUM-VALUES.tsv')};lines=[]
for line in (D/'SUM-INPUTS.tsv').read_text().splitlines():
    id,values=line.split('\t');record=sums[id];lines.append('\t'.join([id,values,record['sum_hex'],record['mean_hex']]))
(Q/'original-sums.tsv').write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\n')
save(Q/'PROVENANCE.json',dict(status='ACTUAL_UNMODIFIED_UPSTREAM_AND_R461_ARITHMETIC_FIXTURES',profile='ACAT0.91',commit='e737d7d188ba6731800c5e6971539ca6a3888405',source=pin((B/'upstream-intake-1/ACAT/source/R/ACAT.R').read_bytes()),R_version='4.6.1',artificial_matrix_cases=len(cases),original_colSums_colMeans_pairs=len(lines),original_process=json.loads((D/'PROCESS.json').read_bytes()),files={name:pin((Q/name).read_bytes()) for name in ['original-cases.json','original-sums.tsv']},original_full_return_warning_error_RDS_retained_privately=str(D/'original'),native_intake='Finite weights/probabilities and nonempty rectangular matrices only. Original NaN/overflow returns remain raw and unadmitted;input errors are retained. No ACAT-V,ACAT-O or SKAT fit is established by these scalar/matrix combination fixtures.',whole_goal_complete=False))
print('Frozen',len(cases),'actual upstream combination fixtures and',len(lines),'extended-arithmetic pairs',flush=True)
