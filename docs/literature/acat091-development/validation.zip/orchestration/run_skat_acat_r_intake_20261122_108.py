import json,os,subprocess,sys
from prepare_skat_acat_20261122_108 import R,T,O
from prepare_handover_qtltools_20261121_105 import pin,save
B=T/'build/skat-acat-1';task=sys.argv[1];assert task in ['probe','install'];D=B/('original-acat-probe-1' if task=='probe' else 'private-skat-install-1');D.mkdir()
script=R/('build/probe_acat_original_20261122_108.R' if task=='probe' else 'build/install_skat_private_20261122_108.R');command=['C:/Program Files/R/R-4.6.1/bin/Rscript.exe','--vanilla',str(script)]
if task=='probe':command += [str(B/'upstream-intake-1/ACAT/source/R/ACAT.R'),str(D/'result')]
else:command += [str(D)]
env=dict(os.environ)
for key in list(env):
    if key.startswith('LC_') or key in ['LANG','LANGUAGE','R_LIBS','R_LIBS_USER','R_LIBS_SITE','R_PROFILE','R_PROFILE_USER','R_ENVIRON','R_ENVIRON_USER','R_DEFAULT_PACKAGES','R_TESTS']:env.pop(key,None)
temp=D/'tmp';temp.mkdir();env.update(LANG='C',LC_ALL='C',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',TMPDIR=str(temp),TMP=str(temp),TEMP=str(temp))
save(D/'STARTED.json',dict(command=command,script=pin(script.read_bytes()),scope='Original source probe on artificial values' if task=='probe' else 'New private official SKAT binary installation;no model run;all shared libraries remain read-only inputs'))
with (D/'stdout').open('xb') as stdout,(D/'stderr').open('xb') as stderr:process=subprocess.run(command,cwd=T,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=900)
save(D/'PROCESS.json',dict(exit_code=process.returncode));print(task,'R exit',process.returncode,flush=True)
if task=='install':
    save(D/'FILE-PINS.json',{p.relative_to(D).as_posix():pin(p.read_bytes()) for p in D.rglob('*') if p.is_file() and p.name!='FILE-PINS.json'})
print((D/'stdout').read_text(errors='replace')[-1300:],(D/'stderr').read_text(errors='replace')[-2000:]);raise SystemExit(process.returncode)
