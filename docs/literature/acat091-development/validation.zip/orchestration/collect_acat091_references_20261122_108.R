args <- commandArgs(trailingOnly=TRUE);stopifnot(length(args)==2L,getRversion()=="4.6.1")
root <- args[[2L]];.libPaths(file.path(R.home(),"library"),include.site=FALSE);env <- new.env(parent=globalenv());source(args[[1L]],local=env,keep.source=TRUE)
out <- file.path(root,"original");stopifnot(!dir.exists(out));dir.create(out)
manifest <- read.delim(file.path(root,"MANIFEST.tsv"),header=FALSE,quote="",colClasses="character",check.names=FALSE)
values <- list();warnings <- list();errors <- list()
for(i in seq_len(nrow(manifest))) {
  record <- manifest[i,];id <- record[[1L]];nr <- as.integer(record[[2L]]);nc <- as.integer(record[[3L]])
  p <- matrix(scan(record[[4L]],what=double(),quiet=TRUE),nrow=nr,ncol=nc,byrow=TRUE)
  w <- if(record[[5L]]=="NULL")NULL else matrix(scan(record[[5L]],what=double(),quiet=TRUE),nrow=nr,ncol=nc,byrow=TRUE)
  seen <- character();error <- NULL
  returned <- tryCatch(withCallingHandlers(env$ACAT(p,w,is.check=TRUE),warning=function(e){seen <<- c(seen,conditionMessage(e));invokeRestart("muffleWarning")}),error=function(e){error <<- conditionMessage(e);NULL})
  saveRDS(list(input=p,weights=w,result=returned,warnings=seen,error=error),file.path(out,paste0(id,".rds")))
  if(is.null(error))for(j in seq_along(returned))values[[length(values)+1L]] <- data.frame(id=id,column=j,p=format(returned[[j]],digits=17,scientific=TRUE),stringsAsFactors=FALSE)
  if(length(seen))for(message in seen)warnings[[length(warnings)+1L]] <- data.frame(id=id,message=message,stringsAsFactors=FALSE)
  if(!is.null(error))errors[[length(errors)+1L]] <- data.frame(id=id,message=error,stringsAsFactors=FALSE)
}
write.table(do.call(rbind,values),file.path(out,"VALUES.tsv"),sep="\t",quote=TRUE,row.names=FALSE)
write.table(do.call(rbind,warnings),file.path(out,"WARNINGS.tsv"),sep="\t",quote=TRUE,row.names=FALSE)
write.table(do.call(rbind,errors),file.path(out,"ERRORS.tsv"),sep="\t",quote=TRUE,row.names=FALSE)
sums <- read.delim(file.path(root,"SUM-INPUTS.tsv"),header=FALSE,quote="",colClasses="character");sum.rows <- list()
hex <- function(x)paste(sprintf("%02x",as.integer(writeBin(x,raw(),size=8L,endian="big"))),collapse="")
for(i in seq_len(nrow(sums))) {
  x <- matrix(as.numeric(strsplit(sums[i,2],",",fixed=TRUE)[[1L]]),ncol=1)
  sum.rows[[i]] <- data.frame(id=sums[i,1],sum_hex=hex(colSums(x)[[1L]]),mean_hex=hex(colMeans(x)[[1L]]),stringsAsFactors=FALSE)
}
write.table(do.call(rbind,sum.rows),file.path(out,"SUM-VALUES.tsv"),sep="\t",quote=TRUE,row.names=FALSE)
capture.output(sessionInfo(),file=file.path(out,"SESSION.txt"));cat("Completed",nrow(manifest),"unaltered upstream ACAT calls and",nrow(sums),"original colSums/colMeans pairs\n")
