import os,subprocess
from prepare_skat_acat_20261122_108 import R,T,O
from prepare_handover_qtltools_20261121_105 import pin,save
B=T/'build/skat-acat-1';D=B/'original-skat-probe-1';D.mkdir();script=R/'build/probe_skat_original_20261122_108.R';command=['C:/Program Files/R/R-4.6.1/bin/Rscript.exe','--vanilla',str(script),str(B/'private-skat-install-1/library'),str(D/'result')];env=dict(os.environ,LANG='C',LC_ALL='C',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
save(D/'STARTED.json',dict(command=command,source=pin(script.read_bytes()),artificial_inputs_only=True,execution_adapter_qualified=False))
with (D/'stdout').open('xb') as stdout,(D/'stderr').open('xb') as stderr:process=subprocess.run(command,cwd=T,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=600)
save(D/'PROCESS.json',dict(exit_code=process.returncode));print((D/'stdout').read_text()[-1800:],(D/'stderr').read_text()[-1800:]);raise SystemExit(process.returncode)
