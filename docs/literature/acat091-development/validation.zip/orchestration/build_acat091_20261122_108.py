from pathlib import Path
import json,os,shutil,subprocess,sys,xml.etree.ElementTree as ET
from prepare_skat_acat_20261122_108 import R,T,O
from prepare_handover_qtltools_20261121_105 import pin,save
label=sys.argv[1];D=T/'build/skat-acat-1'/label;D.mkdir();project=D/'project-build';classpath=D/'CLASSPATH.txt';init=D/'isolate.gradle'
init.write_text("allprojects { p -> if (p == rootProject) p.layout.buildDirectory.set(file('"+project.as_posix()+"')) }\ngradle.projectsEvaluated { rootProject.tasks.register('acat091Classpath') { dependsOn rootProject.tasks.named('testClasses'); doLast { file('"+classpath.as_posix()+"').text = rootProject.sourceSets.test.runtimeClasspath.asPath } } }\n",encoding='utf-8',newline='\n')
cached=R/'build/qt-1/build/qtltools-fdensity-1/normal-gradle-2/project-build/dependencies/jdistlib-all-0.10.2.jar';assert pin(cached.read_bytes())['sha256']=='8b50aaa11d2cbd512525e0d74f8e609f40db9f4fc179ccb7a885a82257e0ac81';target=project/'dependencies/jdistlib-all-0.10.2.jar';target.parent.mkdir(parents=True);shutil.copyfile(cached,target)
names=['src/main/java/org/jlinalg/settest/RLongDoubleSum.java','src/main/java/org/jlinalg/settest/Acat091.java','src/main/java/org/jlinalg/cli/AcatToolsCli.java','src/main/java/org/jlinalg/cli/JLinAlgCli.java','src/test/java/org/jlinalg/cli/Acat091ReferenceTest.java','src/test/java/org/jlinalg/cli/AcatToolsCliTest.java','src/test/java/org/jlinalg/settest/RLongDoubleSumTest.java','src/test/java/org/jlinalg/settest/Acat091Test.java','src/test/java/org/jlinalg/settest/AcatTestsTest.java','src/test/java/org/jlinalg/settest/AcatLogTest.java','src/main/java/org/jlinalg/settest/Acat.java','src/main/java/org/jlinalg/settest/AcatTests.java','build.gradle']
for directory in ['src/main/resources/org/jlinalg/omics/acat091','src/test/resources/org/jlinalg/settest/acat091']:
    names += [p.relative_to(T).as_posix() for p in (T/directory).rglob('*') if p.is_file()]
inputs={name:pin((T/name).read_bytes()) for name in names}
for name in names:
    path=D/'source'/name;path.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(T/name,path)
gradle='C:/Users/User/.gradle/wrapper/dists/gradle-9.7.1-bin/1w1c7tv4s851m17nbqdsro2tv/gradle-9.7.1/bin/gradle.bat'
command=[gradle,'--no-daemon','--offline','--console=plain','--max-workers=2','--no-configuration-cache','--project-cache-dir',str(D/'project-cache'),'--init-script',str(init),'acat091Classpath','executableJar',':test']
for name in ['org.jlinalg.cli.Acat091ReferenceTest','org.jlinalg.cli.AcatToolsCliTest','org.jlinalg.settest.RLongDoubleSumTest','org.jlinalg.settest.Acat091Test','org.jlinalg.settest.AcatTestsTest','org.jlinalg.settest.AcatLogTest']:command+=['--tests',name]
env=dict(os.environ,JAVA_HOME='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot',GRADLE_OPTS='-Dorg.gradle.daemon=false -Dfile.encoding=UTF-8');save(D/'STARTED.json',dict(command=command,source_inputs=inputs,scientific_original_R_executed_by_this_build=False))
with (D/'stdout').open('xb') as stdout,(D/'stderr').open('xb') as stderr:process=subprocess.run(command,cwd=T,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=1200)
save(D/'PROCESS.json',dict(exit_code=process.returncode));assert {name:pin((T/name).read_bytes()) for name in names}==inputs
suites={}
for path in (project/'test-results/test').glob('TEST-*.xml'):
    node=ET.fromstring(path.read_bytes());suites[node.attrib['name']]={key:int(node.attrib[key]) for key in ['tests','failures','errors','skipped']}
result=dict(exit_code=process.returncode,suites=suites,tests=sum(row['tests'] for row in suites.values()),failures=sum(row['failures']+row['errors'] for row in suites.values()),new_catalog_credit=0,whole_goal_complete=False)
jar=project/'cli/omicsmatic-0.4.0.jar'
if jar.is_file():result['producer']=pin(jar.read_bytes())
save(D/'RESULT.json',result);print(json.dumps(result),flush=True)
if process.returncode:print((D/'stdout').read_text(errors='replace')[-5000:]+(D/'stderr').read_text(errors='replace')[-2500:])
raise SystemExit(process.returncode)
