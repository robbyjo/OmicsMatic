from pathlib import Path
import ast,hashlib,io,json,re,subprocess,zipfile
from prepare_skat_acat_20261122_108 import R,T,O,BASE
from prepare_handover_qtltools_20261121_105 import pin,save,git,inventory
B=T/'build/skat-acat-1';Q=T/'docs/literature/acat091-development'
META=['docs/literature/omics-2023-2026/'+n for n in ['papers.json','tool-inventory.json','summary.json','README.md','WARNINGS.md','SHA256SUMS']]+['tools/literature/reviewed-uses.json','site/literature-review.html','site/literature-warnings.html']
def load(path):return json.loads(path.read_bytes())
def zipped(files):
    output=io.BytesIO()
    with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as target:
        for name,raw in sorted(files.items()):
            item=zipfile.ZipInfo(name,date_time=(2026,11,22,0,0,0));item.compress_type=zipfile.ZIP_DEFLATED;item.external_attr=0o100644<<16;target.writestr(item,raw)
    return output.getvalue()

if __name__=='__main__':
    Q.mkdir()
    normal=load(B/'normal-gradle-2/RESULT.json');packaged=load(B/'packaged-2/RESULT.json');example=load(B/'example-1/RESULT.json')
    assert normal['exit_code']==normal['failures']==0 and normal['tests']==500
    assert packaged['tests_each_JVM']==500 and all(v['exit_code']==0 for v in packaged['hosts'].values())
    assert normal['producer']==packaged['producer']==example['producer']
    for name,wanted in load(B/'normal-gradle-2/STARTED.json')['source_inputs'].items():assert pin((T/name).read_bytes())==wanted,name
    for name,wanted in load(B/'packaged-2/STARTED.json')['source_inputs'].items():assert pin((T/name).read_bytes())==wanted,name
    for name in META:assert (T/name).read_bytes()==git(T,'show',BASE+':'+name),name
    inv=inventory();states=load(O/'WORKTREES-BEFORE.json')
    assert len(states)==64
    for state in states:
        assert inv.snapshot(Path(state['root']))==state,state['root']
        assert subprocess.run(['git','merge-base','--is-ancestor',state['head'],BASE],cwd=T,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0,state['root']
    save(O/'PRESERVATION-FINAL.json',dict(status='PASS_ALL64_PRECEDING_OWNERS_EXACT',prior_owners=64,current_owner=65,all_prior_HEADs_reachable_from_main=True,canonical_catalog_bytes_unchanged=True))
    root=load(O/'ROOT-VARIANTS.json');assert root['summary']=={'same-as-main':286,'root-variant':23,'not-in-main':0}
    current=T/'docs/literature/HANDOVER_CURRENT.md';old=git(T,'show',BASE+':docs/literature/HANDOVER_CURRENT.md');heading=b'# Current toolbox handover\n\n';assert old.startswith(heading)
    intro='''**HANDOVER: [native ACAT checkpoint, transfer paths and exact next work](HANDOVER_2026-11-22_ACAT_SKAT.md).**
The new global acat-tools command provides native ACAT0.91 matrix combination
and RUN/VERIFY/REPLAY captures. The final normal build and packaged Windows21,
Windows25 and Linux21 JVMs each pass500 focused tests, including274 original
ACAT cases,192 R column sum/mean pairs and the actual directory-alias replay
regression. All22440 unchanged preceding JAR payloads are exact;the dispatcher
is the sole modified preceding payload,with ten new payloads. The earlier
499-test build and failed alias probe remain labelled historical/unadmitted.
**Catalog totals stay146 scoped families,1639 reviewed/1083 pending;zero new
family credit.** The full250-paper objective remains unfinished. Finish the
ACAT/SKAT/SKAT-O source review,implement a typed standalone SKAT upstream adapter,
then continue FUSION,GenomicRanges,g:Profiler and other high-impact gaps.
SKAT2.2.5 is privately installed and eight direct synthetic fits completed;
these are probes,not an execution adapter. All64 preceding worktrees are
preserved(current owner65). The23 older shared-root variants are archived
without replacing current main files. **Transfer ignored JARs,runtimes,private
primary text and complete scientific/failed evidence separately before machine
retirement;handle retained test junctions/symlinks explicitly.** Read the
handover's prominent SKIP3/FAIL2 remedies. Cell Ranger stays excluded. No release,
explicit Pages publication,whole-paper or full-goal completion is claimed.
Lower entries preserve historical checkpoints and their then-current counts.

'''
    current.write_bytes(heading+intro.encode()+old[len(heading):])
    files={}
    for label in ['normal-gradle-1','normal-gradle-2']:
        folder=B/label
        for name in ['STARTED.json','PROCESS.json','RESULT.json','stdout','stderr','isolate.gradle']:
            files['logs/'+label+'/'+name]=(folder/name).read_bytes()
        results=folder/'project-build/test-results/test'
        for path in sorted(results.glob('TEST-*.xml')):files['test-reports/'+label+'/'+path.name]=path.read_bytes()
    for label in ['packaged-1','packaged-2']:
        folder=B/label
        for name in ['STARTED.json','RESULT.json','JAR-COMPARISON.json','compile.PROCESS.json','compile.stdout','compile.stderr']:
            files['logs/'+label+'/'+name]=(folder/name).read_bytes()
        for host in ['windows21','windows25','linux21']:
            for name in ['STARTED.json','PROCESS.json','stdout','stderr']:files['logs/'+label+'/'+host+'/'+name]=(folder/host/name).read_bytes()
    for path in sorted((B/'example-1').glob('*')):
        if path.is_file():files['example/'+path.name]=path.read_bytes()
        elif path.is_dir():
            for child in sorted(path.iterdir()):
                assert child.is_file() and not child.is_symlink();files['example/'+path.name+'/'+child.name]=child.read_bytes()
    for label in ['acat091-example','acat091-example-replay']:
        folder=T/'build'/label
        for path in sorted(folder.rglob('*')):
            assert not path.is_symlink()
            if path.is_file():files['example/captures/'+label+'/'+path.relative_to(folder).as_posix()]=path.read_bytes()
    for name in ['CENSUS.json']:
        files['discovery/'+name]=(B/'source-discovery-1'/name).read_bytes()
    # Artificial original-oracle output only. No primary text, bundled SKAT data,
    # genotype inputs, binaries, RDS, PDFs or XML source full text are published.
    for path in sorted((B/'acat091-reference-1/original').iterdir()):
        if path.is_file() and path.suffix.lower() in ['.tsv','.txt','.json']:
            files['original-oracle/'+path.name]=path.read_bytes()
    for name in ['acat091-reference-1/PROCESS.json','acat091-reference-1/STARTED.json','original-acat-probe-1/PROCESS.json','original-skat-probe-1/PROCESS.json','private-skat-install-1/PROCESS.json','replay-alias-before-fix-1/RESULT.json','acat091-compile-1/OBSERVED-FAILURE.txt']:
        if (B/name).is_file():files['development/'+name]=(B/name).read_bytes()
    # Select old failing sources explicitly; never walk the alias fixture tree.
    for path in (B/'acat091-compile-1/source').glob('*.java'):files['development/first-compile-source/'+path.name]=path.read_bytes()
    for name in ['src/main/java/org/jlinalg/cli/AcatToolsCli.java','src/test/java/org/jlinalg/cli/AcatToolsCliTest.java']:
        path=B/'normal-gradle-1/source'/name
        if path.is_file():files['development/pre-alias-fix-source/'+name]=path.read_bytes()
    scripts=[path for path in (R/'build').iterdir() if path.is_file() and path.name.endswith(('_20261122_108.py','_20261122_108.R'))]
    scripts += [R/'build/Acat091Probe108.java',R/'build/prepare_handover_qtltools_20261121_105.py']
    for path in scripts:files['orchestration/'+path.name]=path.read_bytes()
    for name in ['ROOT-VARIANT-HISTORY.json','PRESERVATION-FINAL.json']:files['publication/'+name]=(O/name).read_bytes()
    for row in root['files']:
        if row['relation']=='root-variant':
            raw=(R/row['path']).read_bytes();assert pin(raw)==row['root'];files['historical-root-variants/'+row['path']]=raw
    (Q/'validation.zip').write_bytes(zipped(files))
    save(Q/'ROOT-VARIANTS.json',root)
    transfer=dict(status='PRIVATE_TRANSFER_REQUIRED_NOT_PERFORMED',current_owner=str(T),current_branch='codex/skat-acat-source-20261122',private_evidence_tree=str(B),qualified_JAR=str(B/'normal-gradle-2/project-build/cli/omicsmatic-0.4.0.jar'),producer=normal['producer'],public_example_captures=[str(T/'build/acat091-example'),str(T/'build/acat091-example-replay')],publication_receipts=str(O),private_library_and_downloads=str(B/'private-skat-install-1'),full_original_R_reference_RDS=str(B/'acat091-reference-1/original'),private_primary_context=str(B/'source-discovery-1/private-context'),full_upstream_archives_including_private_bundled_data=str(B/'upstream-intake-1'),prior_transfer_inventory='docs/literature/qtltools-catalog-admission/PRIVATE-TRANSFER.json',all64_prior_worktrees_required=True,root_checkout=str(R),root_branch='codex/analysis-pipeline',link_handling='Retain deliberate directory junctions/symlinks as labelled links;never blindly follow/flatten them. The pre-fix replay fixture is mutated and unadmitted. Preserve its actual parent and child plus old seal/logs without repair.',private_primary_XML_PDF_renders_and_runtime_binaries_published=False,whole_goal_complete=False)
    save(Q/'PRIVATE-TRANSFER.json',transfer)
    (Q/'README.md').write_text('''# ACAT component handover evidence

Read [the handover](../HANDOVER_2026-11-22_ACAT_SKAT.md) first.
`QUALIFICATION.json` pins the final 500-test normal build, three packaged JVMs,
source inputs, unchanged catalog bytes and the explicit members of validation.zip.
The archive retains original artificial R oracle output, transcripts, test reports,
the working example and exact orchestration source. Saved qualification is not a
new model execution. The earlier 499-test producer, first compile failure and
pre-fix replay alias failure are retained with their historical scope.

`historical-root-variants/` inside the ZIP contains 23 exact older shared-root
variants. They are development evidence, not replacements for current main.
To inspect them, extract only to a NEW separate directory; never restore the
archive over a live checkout. The other 286 root changes match the baseline main
snapshot. ROOT-VARIANTS.json records all 309 file comparisons.

Private full text, bundled real SKAT data, RDS, runtime executables and JARs are
excluded. PRIVATE-TRANSFER.json gives exact local locations and the preceding
transfer inventory. Preserve all evidence, including failed and null results.
No private machine-to-machine transfer or full-goal completion is claimed.

Run `python -B tools/literature/acat091/verify_checkpoint.py` from the repository
root to read back the frozen evidence. Optional `--jar PATH` hashes the exact
qualified local JAR without executing it. Later changes require checking this
checkpoint on its exact commit; never refresh its pins to accept a changed tree.
''',encoding='utf-8',newline='\n')
    fields=git(T,'status','--porcelain=v1','-z','--untracked-files=all').split(b'\0');public={}
    for field in fields:
        if not field:continue
        assert field[:2] in [b' M',b'??'],field
        name=field[3:].decode()
        if name.startswith('docs/literature/acat091-development/'):continue
        assert name.startswith(('src/main/','src/test/','tools/literature/acat091/','examples/acat091/')) or name in ['docs/literature/ACAT091_NATIVE.md','docs/literature/HANDOVER_2026-11-22_ACAT_SKAT.md','docs/literature/HANDOVER_CURRENT.md'],name
        public[name]=pin((T/name).read_bytes())
    supplementary={path.relative_to(T).as_posix():pin(path.read_bytes()) for path in [Q/'ROOT-VARIANTS.json',Q/'PRIVATE-TRANSFER.json',Q/'README.md']}
    qualification=dict(status='PASS_NATIVE_ACAT091_COMPONENT_CHECKPOINT',baseline=BASE,producer=normal['producer'],normal_build=normal,packaged=packaged,public_example=example,public_inputs=public,canonical_catalog_files={name:pin((T/name).read_bytes()) for name in META},supplementary_files=supplementary,validation_archive=pin((Q/'validation.zip').read_bytes()),validation_members={name:pin(raw) for name,raw in sorted(files.items())},prior_owners_preserved=64,current_owner=65,root_git_visible_files=309,root_files_already_current_main=286,root_older_variants_archived=23,original_matrix_cases=274,original_R_sum_mean_pairs=192,standalone_SKAT_adapter_implemented=False,eight_SKAT_fits_are_exploratory_probes=True,earlier_499_test_qualification_historical=True,pre_fix_replay_alias_control_unadmitted=True,private_transfer_completed=False,new_catalog_credit=0,whole_goal_complete=False)
    save(Q/'QUALIFICATION.json',qualification)
    for path in list((T/'tools/literature/acat091').glob('*.py')):ast.parse(path.read_text(encoding='utf-8'),filename=str(path))
    links=0
    for name in ['docs/literature/ACAT091_NATIVE.md','docs/literature/HANDOVER_2026-11-22_ACAT_SKAT.md','examples/acat091/README.md','docs/literature/acat091-development/README.md']:
        path=T/name
        for target in re.findall(r'\]\(([^)\s]+)\)',path.read_text(encoding='utf-8')):
            if target.startswith(('https:','http:','#')):continue
            assert (path.parent/target.split('#')[0]).resolve().is_file(),(name,target)
            links+=1
    save(O/'PUBLICATION-PREPARED.json',dict(public_inputs=len(public),archive_members=len(files),relative_document_links=links,producer=normal['producer'],prior_owners_preserved=64,whole_goal_complete=False))
    print('PASS public handover prepared;',len(public),'inputs;',len(files),'archive members;',links,'doc links;all64 preceding owners preserved',flush=True)
