import concurrent.futures,io,json,tarfile,urllib.request,zipfile
from pathlib import PurePosixPath
from prepare_skat_acat_20261122_108 import R,T,O
from prepare_handover_qtltools_20261121_105 import pin,save
B=T/'build/skat-acat-1';D=B/'upstream-intake-1'
def get(url,cap=32*1024*1024):
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'OmicsMatic-source-audit'}),timeout=90) as response:raw=response.read(cap+1)
    assert len(raw)<=cap,'Source capacity exceeded';return raw
def record(label,url):
    folder=D/label;folder.mkdir()
    try:
        raw=get(url);(folder/'download').write_bytes(raw);files={}
        if label.startswith('SKAT'):
            with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as archive:
                for member in archive.getmembers():
                    path=PurePosixPath(member.name);assert not path.is_absolute() and '..' not in path.parts and not member.issym() and not member.islnk()
                    if not member.isfile():continue
                    content=archive.extractfile(member).read();assert len(content)<=16*1024*1024
                    # Retain a private complete package;publish only selected source
                    # notices/metadata later,never its bundled example datasets.
                    target=folder/'package'/str(path);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(content);files[str(path)]=pin(content)
        else:
            data=json.loads(raw);sha=data['sha'];tree_url='https://api.github.com/repos/yaowuliu/ACAT/git/trees/'+sha+'?recursive=1';tree_raw=get(tree_url);(folder/'tree.json').write_bytes(tree_raw);tree=json.loads(tree_raw);assert not tree.get('truncated',False)
            for item in tree['tree']:
                name=item['path']
                if item['type']!='blob' or not(name.startswith(('R/','man/')) or name in ['DESCRIPTION','NAMESPACE','README.md','LICENSE','LICENCE']):continue
                pure=PurePosixPath(name);assert not pure.is_absolute() and '..' not in pure.parts
                content=get('https://raw.githubusercontent.com/yaowuliu/ACAT/'+sha+'/'+name,2*1024*1024);target=folder/'source'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(content);files[name]=pin(content)
        result=dict(status='PASS_PRIVATE_OFFICIAL_SOURCE_INTAKE',url=url,download=pin(raw),files=files,public_example_or_author_genotype_data_published=False,scientific_models_executed=False)
        if label=='ACAT':result.update(commit=sha,tree_url=tree_url,tree=pin(tree_raw))
    except Exception as error:result=dict(status='SKIP3_UPSTREAM_SOURCE_UNAVAILABLE',url=url,error=repr(error),required_action='Supply the exact permitted official source before qualifying that edition;retain unavailable source/analysis as skipped and continue independent work.')
    save(folder/'RESULT.json',result);return label,result
if __name__=='__main__':
    D.mkdir();tasks=[('SKAT2.2.5','https://cran.r-project.org/src/contrib/SKAT_2.2.5.tar.gz'),('SKAT2.2.4','https://cran.r-project.org/src/contrib/Archive/SKAT/SKAT_2.2.4.tar.gz'),('ACAT','https://api.github.com/repos/yaowuliu/ACAT/commits/master')]
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=dict(pool.map(lambda pair:record(*pair),tasks))
    save(D/'RESULT.json',results)
    for name,row in results.items():print(name,row['status'],'files',len(row.get('files',{})),row.get('commit',''),row.get('error',''),flush=True)
