package org.jlinalg.cli;
import java.nio.file.*;
import java.util.*;
import org.jlinalg.settest.Acat091;
public final class Acat091Probe108 {
    private Acat091Probe108(){ }
    public static void main(String[] args)throws Exception {
        Object document=SimpleJson.parse(Files.readString(Path.of(args[0])));var results=new ArrayList<Object>();
        for(Object item:(List<?>)document){var c=(Map<?,?>)item;var row=new LinkedHashMap<String,Object>();row.put("id",c.get("id"));
            try{var result=Acat091.combineMatrix(matrix(c.get("p")),c.get("w")==null?null:matrix(c.get("w")));row.put("returned",true);row.put("warnings",result.sourceWarnings());var columns=new ArrayList<Object>();for(var column:result.columns()){var value=new LinkedHashMap<String,Object>();value.put("statistic",Double.toString(column.statistic()));value.put("raw_p",Double.toString(column.rawPValue()));value.put("admitted",column.admitted());value.put("issue",column.admissionIssue());columns.add(value);}row.put("columns",columns);}
            catch(Acat091.Failure error){row.put("returned",false);row.put("warnings",error.sourceWarnings());row.put("error",error.getMessage());}
            results.add(row);
        }
        Files.write(Path.of(args[1]),RsemJson.bytes(results),StandardOpenOption.CREATE_NEW);
    }
    private static double[][] matrix(Object input){var rows=(List<?>)input;double[][] result=new double[rows.size()][];for(int i=0;i<result.length;i++){var row=(List<?>)rows.get(i);result[i]=new double[row.size()];for(int j=0;j<result[i].length;j++){Object v=row.get(j);result[i][j]=v instanceof Number n?n.doubleValue():switch(v.toString()){case "Inf"->Double.POSITIVE_INFINITY;case "-Inf"->Double.NEGATIVE_INFINITY;default->Double.parseDouble(v.toString());};}}return result;}
}
