import csv,json,math
from prepare_skat_acat_20261122_108 import R,T,O
from prepare_handover_qtltools_20261121_105 import pin,save
D=T/'build/skat-acat-1/acat091-reference-1'
def table(name):
    with (D/'original'/name).open(encoding='utf-8-sig',newline='') as stream:return list(csv.DictReader(stream,delimiter='\t'))
native={r['id']:r for r in json.loads((D/'NATIVE-PROBE.json').read_bytes())};values={};errors={r['id']:r['message'] for r in table('ERRORS.tsv')};warnings={}
for row in table('VALUES.tsv'):values.setdefault(row['id'],[]).append(row)
for row in table('WARNINGS.tsv'):warnings.setdefault(row['id'],[]).append(row['message'])
failures=[];compared=0;refusals=0;guarded=[];worst=(0,None)
for id,row in native.items():
    if row['warnings']!=warnings.get(id,[]):failures.append(dict(id=id,kind='source-warning-mismatch',expected=warnings.get(id,[]),actual=row['warnings']))
    if id in errors:
        refusals+=1
        if row['returned']:failures.append(dict(id=id,kind='original-error-returned-native-result'))
        continue
    original=values[id]
    if not row['returned']:
        if all(r['p'] in ['NA','NaN'] for r in original):refusals+=1;continue
        failures.append(dict(id=id,kind='unexpected-native-refusal',native=row));continue
    assert len(row['columns'])==len(original)
    for expected,column in zip(original,row['columns'],strict=True):
        actual=float(column['raw_p']);target=float(expected['p'].replace('NA','nan'))
        if math.isnan(target):
            if not math.isnan(actual) or column['admitted']:failures.append(dict(id=id,kind='nonfinite-source-should-remain-unadmitted'))
        else:
            compared+=1;relative=abs(actual-target)/max(1e-323,abs(target))
            if target>0 and target<.1 and relative>worst[0]:worst=(relative,id)
            if abs(actual-target)>2e-15 and relative>5e-12:failures.append(dict(id=id,kind='p-value-discrepancy',target=target,actual=actual,relative=relative))
        if not column['admitted']:guarded.append(dict(id=id,raw_p=column['raw_p'],issue=column['issue']))
record=dict(status='PASS_INITIAL_NATIVE_ORIGINAL_ACAT091_COMPARISON' if not failures else 'FAIL2_INITIAL_NATIVE_ORIGINAL_ACAT091_COMPARISON',cases=len(native),finite_probabilities_compared=compared,original_errors_or_nonfinite_inputs_refused=refusals,worst_small_tail_relative_discrepancy=worst,guarded_source_returns=guarded,failures=failures,original_R_executed=True,native_profile_only=True,whole_goal_complete=False)
save(D/'COMPARISON.json',record);print(json.dumps(record,indent=2)[:7000]);raise SystemExit(bool(failures))
