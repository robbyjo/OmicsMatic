from pathlib import Path
import gzip,json,re,sys,xml.etree.ElementTree as ET
from prepare_skat_acat_20261122_108 import R,T,O
from prepare_handover_qtltools_20261121_105 import pin,save
sys.path.insert(0,str(T/'tools/literature'))
from collect_omics_review import paragraphs,words
from gsea_catalog.primary import identities,EXTRACTOR_SHA
B=T/'build/skat-acat-1';D=B/'source-discovery-1';PATTERN=re.compile(r'(?<![A-Za-z0-9_])(?:MetaSKAT|SKATBinary(?:_Robust)?|SKAT(?:[-\s]?O)?|ACAT(?:[-\s]?[OV])?|Cauchy[\s-]+combination)(?![A-Za-z0-9_])',re.I)
if __name__=='__main__':
    D.mkdir(parents=True);private=D/'private-context';private.mkdir();papers={p['paper_id']:p for p in json.loads((T/'docs/literature/omics-2023-2026/papers.json').read_bytes())};registry=json.loads((T/'tools/literature/reviewed-uses.json').read_bytes())['reviews'];existing={(r['pmcid'],r['tool_id']) for r in registry};records=[]
    assert pin((T/'tools/literature/collect_omics_review.py').read_bytes())['sha256']==EXTRACTOR_SHA
    for identity in identities():
        raw=gzip.decompress((R/'build/literature-review/xml'/(identity['pmcid']+'.xml.gz')).read_bytes());assert pin(raw)['sha256']==identity['xml_sha256'];tree=ET.fromstring(raw);blocks=[]
        for block in paragraphs(tree):
            text=block.get('match_text',block['text']);matches=list(PATTERN.finditer(text))
            if matches:blocks.append(dict(**block,matching_names=[m.group() for m in matches]))
        tables=[dict(id=table.get('id'),text=words(table)) for table in tree.iter('table-wrap') if PATTERN.search(words(table))]
        if not blocks and not tables:continue
        pid=identity['paper_id'];paper=papers[pid];uses=[u for u in paper['tools'] if u['tool_id'] in ['skat','skato','acat','metaskat']]
        record=dict(identity=identity,title=paper['title'],existing_tools=[dict(tool_id=u['tool_id'],paragraph_index=u['evidence_paragraph_index'],reviewed=(paper['pmcid'],u['tool_id']) in existing,reported_version=u.get('version_reported_near_name')) for u in uses],paragraphs=[dict(paragraph_index=b['paragraph_index'],section=b['section'],text_sha256=pin(b['text'].encode())['sha256'],matching_names=b['matching_names']) for b in blocks],tables=[dict(id=b['id'],text_sha256=pin(b['text'].encode())['sha256']) for b in tables]);records.append(record)
        save(private/(pid+'.json'),dict(identity=identity,title=paper['title'],existing_tools=uses,paragraphs=blocks,tables=tables))
    result=dict(status='PASS_FRESH250_SKAT_ACAT_DISCOVERY_NOT_YET_SEMANTIC_REVIEW',papers_scanned=250,pattern=PATTERN.pattern,positive_papers=len(records),records=records,canonical_modified=False,whole_goal_complete=False)
    save(D/'CENSUS.json',result)
    print('Fresh250 source scan;positive papers',len(records),'paragraphs',sum(len(r['paragraphs']) for r in records),'tables',sum(len(r['tables']) for r in records))
    for row in records:print(row['identity']['paper_id'],','.join(u['tool_id'] for u in row['existing_tools']) or 'NO_CURRENT_TARGET_OBSERVATION','; '.join(str(b['paragraph_index'])+':'+','.join(b['matching_names']) for b in row['paragraphs']),row['title'][:115])
