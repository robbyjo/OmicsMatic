import shutil
from prepare_skat_acat_20261122_108 import R,T,O
from prepare_handover_qtltools_20261121_105 import pin,save
D=T/'src/main/resources/org/jlinalg/omics/acat091';D.mkdir(parents=True);(D/'.gitattributes').write_bytes(b'* -text -whitespace\n');source=T/'build/skat-acat-1/upstream-intake-1/ACAT/source';files={}
for name in ['R/ACAT.R','DESCRIPTION','NAMESPACE']:
    target=D/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source/name,target);files[name]=pin(target.read_bytes())
save(D/'SOURCE.json',dict(schema_version=1,package='ACAT',edition='0.91',commit='e737d7d188ba6731800c5e6971539ca6a3888405',license='GPLv3',source_url='https://github.com/yaowuliu/ACAT',files=files,qualified_native_operation='checked ACAT matrix p-value combination only',numeric_profile='Selected R4.6.1 x86 64-bit-significand colSums/colMeans;strict JVM trigonometry;validated against original R within declared tolerance.',original_R_executed_by_native_engine=False,ACAT_V_NULL_Model_or_ACAT_O_qualified_here=False,scope='The unchanged reference R file also defines genotype/null-model routines;shipping it does not execute or qualify those routines. Native source-return diagnostics and separate admission refusals remain explicit.'))
print('Saved3 exact unchanged GPLv3 ACAT0.91 source/metadata resources;native operation COMBINE only')
