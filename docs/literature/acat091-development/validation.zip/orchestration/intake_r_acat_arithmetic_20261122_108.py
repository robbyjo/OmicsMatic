import urllib.request
from prepare_skat_acat_20261122_108 import R,T,O
from prepare_handover_qtltools_20261121_105 import pin,save
D=T/'build/skat-acat-1/R461-arithmetic-intake-1';D.mkdir();rows=[]
for relative in ['src/main/array.c','src/nmath/pcauchy.c']:
    url='https://svn.r-project.org/R/tags/R-4-6-1/'+relative
    with urllib.request.urlopen(url,timeout=60) as response:raw=response.read(1024*1024+1)
    assert len(raw)<=1024*1024;(D/relative.rsplit('/',1)[-1]).write_bytes(raw);rows.append(dict(url=url,**pin(raw)))
save(D/'RESULT.json',dict(status='PASS_OFFICIAL_R461_ARITHMETIC_SOURCE_ONLY',records=rows))
print('Pinned original R4.6.1 array.c and pcauchy.c;no software or analysis changed')
