# Warnings and required actions

Native ACAT0.91 checked matrix p-value combination only. Each column is one declared combination;no genes,models,weights or missing values are inferred. Original R is not executed. ACAT-V/null-model fitting,ACAT-O,SKAT,genotype preparation,FDR and signed Z reconstruction are separate operations. Source warnings and raw nonfinite/overflow returns remain retained without silent repair or an engine fallback.

SKIP3: DEPENDENT ANALYSIS SKIPPED; supply the named permitted Java/runtime or packaged source resource,or retain the skip. Download/install where permitted;if prohibited,identify the affected analysis and exact prerequisite. FAIL2: NO COMPLETE RESULT;preserve raw requests,diagnostics and failed/partial captures,resolve the named input,numerical,capacity or integrity cause and retry NEW output. Read analysis-status.json and WARNINGS.md. Do not replace0/1,drop zero-weight rows,repair NaN/Inf or substitute a stable mathematical method silently. Source numeric zero does not imply infinite biological significance. Hashes establish integrity,not producer authentication.

Source warnings: []

Admission warnings: []

Result admitted: true

Error: null
