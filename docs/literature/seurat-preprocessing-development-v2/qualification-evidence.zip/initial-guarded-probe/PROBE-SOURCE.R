args <- commandArgs(trailingOnly=TRUE)
stopifnot(length(args)==2L)
out <- args[[1L]]; source_root <- args[[2L]]
dir.create(out,recursive=TRUE,showWarnings=FALSE)
.libPaths(c('D:/projects/JLinAlg/build/literature-review/signac-runtime/reference-setup-1/R-lib','D:/projects/JLinAlg/build/omics-sctransform-r',.Library))
Sys.setenv(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
options(Seurat.nthreads=1L)
suppressPackageStartupMessages(library(Seurat));suppressPackageStartupMessages(library(Matrix))
future::plan('sequential')
stopifnot(as.character(packageVersion('Seurat'))=='5.6.0')
defs <- new.env(parent=asNamespace('Seurat'))
for (file in c('R/preprocessing.R','R/utilities.R')) {
 for (expr in parse(file.path(source_root,file))) {
  if (is.call(expr) && identical(expr[[1L]],as.name('<-')) && is.symbol(expr[[2L]]) && is.call(expr[[3L]]) && identical(expr[[3L]][[1L]],as.name('function'))) eval(expr,envir=defs)
 }
}
guards <- lapply(c('LogNormalize.V3Matrix','NormalizeData.V3Matrix','RelativeCounts','CustomNormalize','ScaleData.default','FastRowScale'),function(name) {
 installed <- get(name,envir=asNamespace('Seurat'));reference <- get(name,envir=defs)
stopifnot(identical(body(installed),body(reference)),identical(formals(installed),formals(reference)));list(name=name,body_formals_identical=TRUE)
})
x <- new('dgCMatrix',Dim=as.integer(c(4,4)),i=as.integer(c(0,1,3,0,2,3,0,1,2,3,1)),p=as.integer(c(0,3,6,10,11)),x=c(1,0,4,3,0,1,2,5,4,3,0),Dimnames=list(paste0('f',1:4),paste0('c',1:4)))
results <- list()
for (method in c('LogNormalize','RC','CLR')) for (margin in if(method=='CLR')c(1,2) else 1) {
 warnings <- character();z <- tryCatch(withCallingHandlers(NormalizeData(x,normalization.method=method,scale.factor=10000,margin=margin,verbose=FALSE),warning=function(w){warnings<<-c(warnings,conditionMessage(w));invokeRestart('muffleWarning')}),error=function(e)e)
results[[paste0(method,margin)]] <- if(inherits(z,'error'))list(error=conditionMessage(z)) else list(class=class(z),values=as.vector(as.matrix(z)),i=if(inherits(z,'dgCMatrix'))z@i else NULL,p=if(inherits(z,'dgCMatrix'))z@p else NULL,x=if(inherits(z,'dgCMatrix'))z@x else NULL,warnings=warnings)
}
for (center in c(TRUE,FALSE)) for(scale in c(TRUE,FALSE)) {
 z <- ScaleData(x,features=c('f3','f1','f2','f4'),do.center=center,do.scale=scale,scale.max=.3,verbose=FALSE)
 results[[paste0('scale',center,scale)]] <- list(values=as.vector(z),features=rownames(z),cells=colnames(z))
}
versions <- lapply(c('Seurat','SeuratObject','Matrix','jsonlite','future'),function(p)list(package=p,version=as.character(packageVersion(p)),path=find.package(p)))
jsonlite::write_json(list(status='PASS_INSTALLED_SOURCE_BODY_FORMAL_GUARDS_AND_PRIMITIVE_PROBE',guards=guards,versions=versions,results=results,libs=.libPaths()),file.path(out,'PROBE.json'),pretty=TRUE,auto_unbox=TRUE,digits=17,na='string')
writeLines(capture.output(sessionInfo()),file.path(out,'session.txt'))
cat('PASS source guards and primitive calls\n')
