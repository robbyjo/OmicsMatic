# PASS_PINNED_READER_REFERENCE_INTAKE_ONLY

Reference files only; no scientific analysis or installation.

Reference intake only. Native Java stored-channel extraction requires no external scientific runtime. Preserve originals and failed intakes. If network access or permitted installation is unavailable, skip the dependent reference comparison; do not substitute an edition, bypass TLS or truncate inputs. Use NEW paths after resolving the named cause. Source identities establish integrity, not authenticity.
