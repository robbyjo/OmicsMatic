import hashlib,json,struct,subprocess,sys,time,traceback,warnings
from pathlib import Path
base=Path(__file__).resolve().parent;root=base.parents[1];out=base/'vendor-parity-1';out.mkdir()
sys.path.insert(0,str(base/'upstream-3/flowio-source/flowio-1.4.0/src'))
import flowio,numpy
jdk=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin')
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def run(label,command):
 start=time.monotonic();r=subprocess.run(list(map(str,command)),capture_output=True,timeout=180);(out/(label+'.stdout')).write_bytes(r.stdout);(out/(label+'.stderr')).write_bytes(r.stderr);save(out/(label+'.PROCESS.json'),dict(command=list(map(str,command)),exit_code=r.returncode,seconds=time.monotonic()-start));return r
records=[]
try:
 source=root/'src/main/java/org/jlinalg/cytometry/FcsReader.java';original=pin(source);probe=base/'NativeFcsProbe.java';probe_pin=pin(probe)
 (out/'classes').mkdir();r=run('javac',[jdk/'javac.exe','--release','17','-Xlint:all','-Werror','-d',out/'classes',source,probe]);assert r.returncode==0
 for i,p in enumerate(sorted((base/'upstream-3/vendor-fixtures').rglob('*.fcs'))):
  before=pin(p);expected=None;failure=None
  try:
   with warnings.catch_warnings(record=True) as ws:d=flowio.FlowData(str(p))
   h=hashlib.sha256()
   for v in d.events:h.update(struct.pack('>d',float(v)))
   expected=dict(events=d.event_count,parameters=d.channel_count,value_sha256=h.hexdigest())
  except Exception as e:failure=repr(e)
  r=run('case-'+str(i+1),[jdk/'java.exe','-cp',out/'classes','NativeFcsProbe',p]);actual=json.loads(r.stdout) if r.returncode==0 else None
  record=dict(file=str(p),input=before,original_status='PASS' if expected else 'REFUSAL',original_error=failure,original=expected,native_exit_code=r.returncode,native=actual)
  records.append(record);save(out/'PROGRESS.json',records)
  assert pin(p)==before
  if expected:assert r.returncode==0 and all(actual[k]==v for k,v in expected.items()),p.name
  else:assert r.returncode==2,p.name
  print('PASS',p.name,expected['events'] if expected else 'original/native refusal',flush=True)
 assert pin(source)==original and pin(probe)==probe_pin
 save(out/'COMPLETED.json',dict(status='PASS_COMPLETE_VENDOR_STORED_CHANNEL_PARITY_ONLY',source=original,probe=probe_pin,flowio=flowio.__version__,numpy=numpy.__version__,cases=records,transformations_or_gates_qualified=False,new_catalog_integrations=0))
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc(),completed_cases=records));print(repr(e),flush=True);raise
