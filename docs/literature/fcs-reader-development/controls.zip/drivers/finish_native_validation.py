import hashlib,json,subprocess,time,traceback,xml.etree.ElementTree as ET,zipfile
from pathlib import Path
base=Path(__file__).resolve().parent;root=base.parents[1];out=base/'validation-1';out.mkdir();built=base/'build-1';jar=built/'jar/omicsmatic-0.4.0.jar'
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return dict(bytes=p.stat().st_size,sha256=h.hexdigest())
def lp(p):return '/mnt/d/projects/JLinAlg/build/high-impact-stats-1/'+p.relative_to(root).as_posix()
def junit(folder):
 trees=[ET.parse(p).getroot() for p in folder.glob('TEST-*.xml')]
 return {k:sum(int(t.attrib.get(k,0)) for t in trees) for k in ['tests','failures','errors','skipped']}
try:
 assert json.loads((built/'gradle.PROCESS.json').read_bytes())['exit_code']==0
 counts=junit(built/'test-results');assert counts==dict(tests=6,failures=0,errors=0,skipped=0),counts
 guards=json.loads((built/'SOURCES.json').read_bytes());assert all(pin(root/name)==identity for name,identity in guards.items())
 parent=root/'build/nfcore-atacseq121-1/build-7/jar/omicsmatic-0.4.0.jar'
 with zipfile.ZipFile(parent) as a,zipfile.ZipFile(jar) as b:
  assert set(a.namelist()).issubset(b.namelist());added=sorted(set(b.namelist())-set(a.namelist()))
  assert added and all(n=='org/jlinalg/cytometry/' and b.getinfo(n).is_dir() and b.getinfo(n).file_size==0 or n.startswith('org/jlinalg/cytometry/FcsReader') and n.endswith('.class') for n in added),added
  changed=[n for n in a.namelist() if a.read(n)!=b.read(n)];assert not changed,changed
 cp=lp(jar)+':'+lp(root/'build/classes/java/test')+':'+lp(root/'build/resources/test')
 command=['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--exec','/usr/bin/java','-Xmx2048m','-jar',lp(root/'build/nfcore-atacseq121-1/linux-test-runtime-1/junit-platform-console-standalone-1.13.4.jar'),'execute','--class-path',cp,'--select-class','org.jlinalg.cytometry.FcsReaderTest','--reports-dir',lp(out/'linux-junit-reports'),'--disable-ansi-colors'];save(out/'linux-junit.command.json',command);began=time.monotonic()
 with (out/'linux-junit.stdout').open('xb') as so,(out/'linux-junit.stderr').open('xb') as se:r=subprocess.run(command,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=300)
 save(out/'linux-junit.PROCESS.json',dict(exit_code=r.returncode,seconds=time.monotonic()-began));assert r.returncode==0
 linux=junit(out/'linux-junit-reports');assert linux==counts,linux
 assert all(pin(root/name)==identity for name,identity in guards.items())
 save(out/'COMPLETED.json',dict(status='PASS_NATIVE_FCS_STORED_CHANNEL_API_BUILD_AND_TWO_PLATFORM_TESTS',artifact=pin(jar),qualified_predecessor=pin(parent),all_existing_jar_entries_byte_identical=True,added_entries=added,windows_junit=counts,linux_junit=linux,overlapping_same_tests=True,retained_prior_harness_failure='build-1 expected class files only and refused the standard zero-byte package directory entry; its Gradle build and six tests passed. No source, result or previous marker was changed.',native_cli_or_gating_implemented=False,new_catalog_integrations=0,whole_goal_complete=False))
 print('PASS six Windows and six Linux API tests; 25 independent storage controls; every existing JAR member byte-identical',flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc()));raise
