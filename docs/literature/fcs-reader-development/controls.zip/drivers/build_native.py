import hashlib,json,os,shutil,subprocess,time,traceback,xml.etree.ElementTree as ET,zipfile
from pathlib import Path
base=Path(__file__).resolve().parent;root=base.parents[1];out=base/'build-1';out.mkdir()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def pin(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return dict(bytes=p.stat().st_size,sha256=h.hexdigest())
def lp(p):return '/mnt/d/projects/JLinAlg/build/high-impact-stats-1/'+p.relative_to(root).as_posix()
def run(label,command,env=None):
 save(out/(label+'.command.json'),list(map(str,command)));began=time.monotonic()
 with (out/(label+'.stdout')).open('xb') as so,(out/(label+'.stderr')).open('xb') as se:
  r=subprocess.run(list(map(str,command)),cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=900)
 save(out/(label+'.PROCESS.json'),dict(exit_code=r.returncode,seconds=time.monotonic()-began));assert r.returncode==0,label;print('PASS',label,flush=True)
def junit(folder):
 trees=[ET.parse(p).getroot() for p in folder.glob('TEST-*.xml')]
 return {k:sum(int(t.attrib.get(k,0)) for t in trees) for k in ['tests','failures','errors','skipped']}
try:
 sources=[root/'src/main/java/org/jlinalg/cytometry/FcsReader.java',root/'src/test/java/org/jlinalg/cytometry/FcsReaderTest.java',root/'src/test/resources/org/jlinalg/cytometry/storage-controls.tsv',root/'tools/literature/cytometry/generate_reader_controls.py']
 guards={p.relative_to(root).as_posix():pin(p) for p in sources};save(out/'SOURCES.json',guards)
 for name in guards:
  target=out/'sources'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/name,target)
 relative=out.relative_to(root).as_posix();init=out/'private.gradle'
 init.write_text("gradle.projectsEvaluated {\n rootProject.tasks.named('executableJar') { destinationDirectory.set(rootProject.layout.projectDirectory.dir('"+relative+"/jar')) }\n rootProject.tasks.named('test') { reports.junitXml.outputLocation.set(rootProject.layout.projectDirectory.dir('"+relative+"/test-results')); reports.html.outputLocation.set(rootProject.layout.projectDirectory.dir('"+relative+"/test-report')) }\n}\n",encoding='utf8',newline='\n')
 run('gradle',[root/'gradlew.bat','--no-daemon','--console=plain','-I',init,':test','--tests','org.jlinalg.cytometry.FcsReaderTest',':executableJar'],dict(os.environ,JAVA_HOME='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot'))
 counts=junit(out/'test-results');assert counts==dict(tests=6,failures=0,errors=0,skipped=0),counts
 jar=out/'jar/omicsmatic-0.4.0.jar';parent=root/'build/nfcore-atacseq121-1/build-7/jar/omicsmatic-0.4.0.jar'
 with zipfile.ZipFile(parent) as a,zipfile.ZipFile(jar) as b:
  assert set(a.namelist()).issubset(b.namelist());added=sorted(set(b.namelist())-set(a.namelist()));assert added and all(n.startswith('org/jlinalg/cytometry/FcsReader') and n.endswith('.class') for n in added),added
  changed=[n for n in a.namelist() if a.read(n)!=b.read(n)];assert not changed,changed
 cp=lp(jar)+':'+lp(root/'build/classes/java/test')+':'+lp(root/'build/resources/test')
 run('linux-junit',['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--exec','/usr/bin/java','-Xmx2048m','-jar',lp(root/'build/nfcore-atacseq121-1/linux-test-runtime-1/junit-platform-console-standalone-1.13.4.jar'),'execute','--class-path',cp,'--select-class','org.jlinalg.cytometry.FcsReaderTest','--reports-dir',lp(out/'linux-junit-reports'),'--disable-ansi-colors'])
 linux=junit(out/'linux-junit-reports');assert linux==counts,linux
 assert all(pin(root/name)==identity for name,identity in guards.items())
 save(out/'COMPLETED.json',dict(status='PASS_NATIVE_FCS_STORED_CHANNEL_API_BUILD_AND_TWO_PLATFORM_TESTS',artifact=pin(jar),qualified_predecessor=pin(parent),all_existing_jar_entries_byte_identical=True,added_entries=added,windows_junit=counts,linux_junit=linux,overlapping_same_tests=True,native_cli_or_gating_implemented=False,new_catalog_integrations=0,whole_goal_complete=False))
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc()));print(repr(e),flush=True);raise
