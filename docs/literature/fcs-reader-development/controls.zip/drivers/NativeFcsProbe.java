import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.HexFormat;
import org.jlinalg.cytometry.FcsReader;

public class NativeFcsProbe {
    public static void main(String[] args) throws Exception {
        try (FcsReader reader = FcsReader.open(Path.of(args[0]), FcsReader.Limits.defaults(), Charset.forName(args[1]), FcsReader.TextPolicy.valueOf(args[2]))) {
            MessageDigest digest = MessageDigest.getInstance("SHA-256"); ByteBuffer bits = ByteBuffer.allocate(8);
            double[] event = new double[reader.info().parameters().size()];
            while (reader.readEvent(event)) for (double value : event) {
                bits.clear(); bits.putLong(Double.doubleToLongBits(value)); digest.update(bits.array());
            }
            var summary = reader.summary();
            System.out.printf(java.util.Locale.ROOT, "{\"status\":\"PASS_COMPLETE_STORED_CHANNEL_STREAM\",\"events\":%d,\"parameters\":%d,\"value_sha256\":\"%s\",\"masked_values\":%d,\"nonfinite_values\":%d}%n",
                summary.eventsRead(), event.length, HexFormat.of().formatHex(digest.digest()), summary.integerValuesWithUnusedBits(), summary.nonfiniteValues());
        } catch (FcsReader.UnsupportedFormatException skipped) { System.err.println("SKIP3 "+skipped); System.exit(3); }
        catch (java.io.IOException invalid) { System.err.println("FAIL2 "+invalid); System.exit(2); }
    }
}
