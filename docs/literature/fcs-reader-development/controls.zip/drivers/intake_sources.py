import hashlib,json,tarfile,urllib.request,urllib.parse,zipfile
from pathlib import Path,PurePosixPath
base=Path(__file__).resolve().parent;out=base/'upstream-3';out.mkdir()
records=[]
def fetch(url,name,maximum=67108864):
 request=urllib.request.Request(url,headers={'User-Agent':'OmicsMatic-research-source-intake/1','Accept':'application/vnd.github+json' if 'api.github.com' in url else '*/*'})
 with urllib.request.urlopen(request,timeout=120) as r:
  body=r.read(maximum+1);assert len(body)<=maximum;record=dict(url=url,status=r.status,content_type=r.headers.get('Content-Type'),bytes=len(body),sha256=hashlib.sha256(body).hexdigest())
 (out/name).write_bytes(body);records.append(dict(file=name,**record));return body
def save(name,value):(out/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf8')
def extract(archive,destination):
 destination.mkdir()
 with tarfile.open(archive,'r:gz') as t:
  for m in t:
   path=PurePosixPath(m.name);assert not path.is_absolute() and '..' not in path.parts
   target=destination.joinpath(*path.parts);assert target.resolve().is_relative_to(destination.resolve())
   if m.isdir():target.mkdir(parents=True,exist_ok=True)
   else:
    assert m.isfile();target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists();target.write_bytes(t.extractfile(m).read())
try:
 fetch('https://flowcytometry.gwu.edu/sites/g/files/zaskib311/files/2021-11/Data%20File%20Standard%20for%20Flow%20Cytometry%281%29.pdf','FCS31-normative-reference.pdf')
 fetch('https://isac-net.org/wp-content/uploads/2026/03/GatingML_2.0_Specification.20130122.full_.zip','GatingML20-specification.zip')
 meta=json.loads(fetch('https://pypi.org/pypi/FlowIO/1.4.0/json','flowio-1.4.0-pypi.json'))
 selected=[f for f in meta['urls'] if f['packagetype']=='sdist'];assert len(selected)==1;selected=selected[0]
 raw=fetch(selected['url'],'flowio-1.4.0.tar.gz');assert hashlib.sha256(raw).hexdigest()==selected['digests']['sha256'];extract(out/'flowio-1.4.0.tar.gz',out/'flowio-source')
 tags=json.loads(fetch('https://api.github.com/repos/whitews/FlowIO/tags?per_page=100','flowio-tags.json'))
 tag=[t for t in tags if t['name'] in ['1.4.0','v1.4.0']];assert len(tag)==1;commit=tag[0]['commit']['sha'];assert len(commit)==40
 tree=json.loads(fetch('https://api.github.com/repos/whitews/FlowIO/git/trees/'+commit+'?recursive=1','flowio-tree.json'));assert not tree.get('truncated')
 fixture_paths=[r for r in tree['tree'] if r['type']=='blob' and r['path'].lower().endswith('.fcs') and r['size']<=2097152]
 for r in fixture_paths:
  dest=Path('vendor-fixtures')/r['path'];(out/dest).parent.mkdir(parents=True,exist_ok=True)
  raw=fetch('https://raw.githubusercontent.com/whitews/FlowIO/'+commit+'/'+urllib.parse.quote(r['path'],safe='/'),dest.as_posix(),2097152);assert len(raw)==r['size'];assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==r['sha']
 save('COMPLETED.json',dict(status='PASS_OFFICIAL_SPEC_AND_ORIGINAL_FLOWIO_INTAKE_ONLY',flowio_version='1.4.0',flowio_commit=commit,selected_complete_fixture_files=len(fixture_paths),fixture_selection='All .fcs blobs at this exact source commit no larger than 2 MiB each. This selects control cases; no analysis file is truncated.',retrievals=records,scientific_analysis_executed=False))
 print('PASS',commit,len(fixture_paths),'complete fixtures',flush=True)
except Exception as e:
 save('FAILURE.json',dict(status='FAIL2_SOURCE_INTAKE_NO_RESULT',error=repr(e),completed_retrievals=records));raise
