from pathlib import Path
import json, os, subprocess
ROOT=Path('/mnt/d/projects/JLinAlg')
OUT=ROOT/'build/literature-review/monocle-runtime/arrow1201-candidate-audit-2'
WORKSPACE=Path('/opt/omicsmatic-arrow1201-reference-20261114-2')
PREFIX=WORKSPACE/'.pixi/envs/default'
HERE=ROOT/'tools/literature/arrow1201'
OUT.mkdir(exist_ok=False)
command=[str(PREFIX/'bin/Rscript'),'--vanilla',str(HERE/'AuditEntry.R'),str(HERE/'AuditRuntime.R'),str(WORKSPACE/'source-original'),str(OUT/'AST-AUDIT.rds')]
with (OUT/'audit.stdout').open('xb') as stdout,(OUT/'audit.stderr').open('xb') as stderr:
    child=subprocess.run(command,cwd=OUT,env={**os.environ,'PATH':str(PREFIX/'bin')+':'+os.environ.get('PATH','')},stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr)
(OUT/'PROCESS.json').write_text(json.dumps(dict(command=command,exit_code=child.returncode,new_family_credit=0),indent=2)+'\n')
print('ORIGINAL_ARROW1201_CANDIDATE_AUDIT_EXIT',child.returncode,flush=True)
raise SystemExit(child.returncode)
