from pathlib import Path, PurePosixPath
import hashlib, json, os, subprocess, tarfile

ROOT = Path('/mnt/d/projects/JLinAlg')
OUT = ROOT/'build/literature-review/monocle-runtime/arrow1201-candidate-audit-1'
WORKSPACE = Path('/opt/omicsmatic-arrow1201-reference-20261114-2')
PREFIX = WORKSPACE/'.pixi/envs/default'
SOURCE = WORKSPACE/'source-original'
OUT.mkdir(exist_ok=False)
SOURCE.mkdir(exist_ok=False)
profile = json.loads((ROOT/'build/literature-review/monocle-runtime/arrow1201-intake-1/CRAN-SOURCE.json').read_bytes())
source_archive = ROOT/'build/literature-review/monocle-runtime/arrow1201-intake-1/arrow_12.0.1.tar.gz'
with tarfile.open(source_archive,'r:gz') as archive:
    for member in archive.getmembers():
        path = PurePosixPath(member.name)
        assert not path.is_absolute() and '..' not in path.parts and path.parts[0] == 'arrow'
        assert member.isdir() or member.isfile(), member.name
        target = SOURCE.joinpath(*path.parts[1:])
        if member.isdir():
            target.mkdir(parents=True,exist_ok=True)
        else:
            raw = archive.extractfile(member).read()
            assert dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()) == profile['files'][member.name]
            target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(raw)
            target.chmod(member.mode & 0o777)
meta = []
for path in (PREFIX/'conda-meta').glob('*.json'):
    d = json.loads(path.read_bytes())
    if d['name'] in ['r-arrow','arrow-cpp','libarrow','r-dplyr','r-bit64','r-jsonlite']:
        meta.append({k:d.get(k) for k in ['name','version','build','url','sha256','package_tarball_full_path','extracted_package_dir']})
(OUT/'CONDA-PACKAGES.json').write_text(json.dumps(meta,indent=2)+'\n')
code = ('source("'+str(ROOT/'tools/literature/arrow1201/AuditRuntime.R')+'");'
        'audit.arrow1201("'+str(SOURCE)+'","'+str(OUT/'AST-AUDIT.rds')+'")')
with (OUT/'audit.stdout').open('xb') as stdout, (OUT/'audit.stderr').open('xb') as stderr:
    child = subprocess.run([str(PREFIX/'bin/Rscript'),'--vanilla','-e',code],
        env={**os.environ,'PATH':str(PREFIX/'bin')+':'+os.environ.get('PATH','')},
        cwd=OUT,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr)
(OUT/'PROCESS.json').write_text(json.dumps(dict(exit_code=child.returncode,source_regular_files=len(profile['files']),
    actual_original_functions_audited=13 if child.returncode == 0 else None, new_family_credit=0),indent=2)+'\n')
print('ORIGINAL_ARROW1201_CANDIDATE_AUDIT_EXIT',child.returncode,flush=True)
raise SystemExit(child.returncode)
