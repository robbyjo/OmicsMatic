from pathlib import Path
import hashlib,json,os,subprocess,sys,zipfile,datetime

ROOT=Path('/mnt/d/projects/JLinAlg')
HERE=ROOT/'tools/literature/arrow1201'
BASE=ROOT/'build/literature-review/monocle-runtime'
sys.path.insert(0,str(HERE))
from Runtime import sources,pin,load,save,check
DATA=ROOT/'docs/literature/arrow1201-workflow-validation'
WORKFLOW=BASE/'arrow1201-workflow-candidate-3'
FINAL=BASE/'arrow1201-final-saved-controls-1'
RECORDING=BASE/'arrow1201-recording-controls-1'
ONLINE=Path('/opt/omicsmatic-arrow1201-public-install-20261114-2')
OFFLINE=Path('/opt/omicsmatic-arrow1201-public-offline-install-20261114-1')

result=load(WORKFLOW/'COMPLETED.json');replay=load(FINAL/'COMPLETED.json')
assert (result['controls'],result['complete_returns'],result['original_failures_without_result'])==(13,10,3)
assert (replay['unchanged_comparator_controls'],replay['tampered_comparator_rejections'])==(2,12)
assert replay['whole_condition_identity_controls']==12
for installation in [ONLINE,OFFLINE]:
    receipt=load(installation/'COMPLETED.json')
    assert receipt['status']=='PASS_INSTALLED_AUDITED_ORIGINAL_ARROW1201_RUNTIME_NOT_ANALYSIS'
    assert receipt['adapter_sources']==sources()
    assert len(receipt['calls'])==2 and all(c['exit_code']==0 for c in receipt['calls'])
    check(load(installation/'provider/READY.json'))
assert load(ONLINE/'DOWNLOAD.json')['source']=='permitted-download'
assert load(OFFLINE/'DOWNLOAD.json')['source']=='local-copy'
assert '--offline' in load(OFFLINE/'locked-dependencies-PROCESS.json')['command']
assert not (RECORDING/'missing-runtime/LIVE.json').exists()
assert load(RECORDING/'missing-runtime/FAILURE.json')['status']=='SKIP3_ARROW1201_PREREQUISITE_UNAVAILABLE'
assert not (RECORDING/'installation-forbidden/runtime').exists()
assert 'Installation forbidden' in load(RECORDING/'installation-forbidden/FAILURE.json')['cause']
partial=RECORDING/'post-original-recording-failure'
assert load(partial/'original/R-status.json')['exit_code']==0
assert (partial/'original/complete-result.rds').is_file() and not (partial/'COMPLETED.json').exists()
assert load(partial/'FINALIZATION_ERROR.json')['status']=='FAIL2_ARROW1201_UNADMITTED'
assert load(BASE/'arrow1201-permission-controls-1/PROCESS.json')['exit_code']==0
for name,case in result['cases'].items():
    adapter=WORKFLOW/name/'adapter'
    assert load(adapter/'ASSETS-BEFORE.json')==load(adapter/'ASSETS-AFTER.json')
    assert load(adapter/'PROCESS.json')['exit_code']==case['adapter_exit']
    assert not (adapter/'FINALIZATION_ERROR.json').exists()
    assert (adapter/'COMPLETED.json').exists()==case['reference_returned']
    assert (adapter/'original/complete-conditions.rds').is_file()

files={}
def add(name,path):
    assert name not in files,name
    files[name]=Path(path).read_bytes()
def tree(stem,path,skip=()):
    for candidate in sorted(Path(path).rglob('*')):
        if candidate.is_file() and not any(part in skip for part in candidate.relative_to(path).parts):
            add(stem+'/'+candidate.relative_to(path).as_posix(),candidate)

tree('current-workflow',WORKFLOW,skip=('home','tmp'))
tree('final-saved-controls',FINAL,skip=('home','tmp'))
tree('recording-controls',RECORDING,skip=('home','tmp'))
tree('permission-controls',BASE/'arrow1201-permission-controls-1')
for label,installation in [('download-enabled-installation',ONLINE),('cache-only-installation',OFFLINE)]:
    for candidate in sorted(installation.iterdir()):
        if candidate.is_file():add(label+'/'+candidate.name,candidate)
    tree(label+'/provider',installation/'provider',skip=('home','tmp'))
for candidate in sorted(HERE.iterdir()):
    if candidate.is_file():add('qualified-module-source/'+candidate.name,candidate)
for name in ['COMPLETED.json','CRAN-SOURCE.json','intake.py','setup_runtime.py','setup_runtime_2.py',
             'audit_candidate.py','rerun_audit_2.py','rerun_audit_3.py','final_saved_controls.py','seal_workflow.py']:
    add('original-source-intake/'+name,BASE/'arrow1201-intake-1'/name)
for relative in ['arrow1201-runtime-install-1','arrow1201-runtime-install-2',
                 'arrow1201-candidate-audit-1','arrow1201-candidate-audit-2','arrow1201-candidate-audit-3']:
    for candidate in sorted((BASE/relative).iterdir()):
        if candidate.is_file():add('history/'+relative+'/'+candidate.name,candidate)
for relative in ['arrow1201-workflow-candidate-1','arrow1201-workflow-candidate-2']:
    previous=BASE/relative
    for candidate in sorted(previous.iterdir()):
        if candidate.is_file():add('history/'+relative+'/'+candidate.name,candidate)
    tree('history/'+relative+'/attempted-adapter-source',previous/'attempted-adapter-source')

module_sources={p.name:pin(p) for p in sorted(HERE.iterdir()) if p.is_file()}
condition_difference=load(FINAL/'CONDITION-DIFFERENCES.json')
assert condition_difference['differing_fields']=='trace'
reviews=load(ROOT/'tools/literature/doubletfinder_catalog/reviews.json')['reviews']
primary=next(r for r in reviews if r['tool_id']=='arrow-r')
assert primary['paper_id']=='P059' and primary['version_reported_near_name']=='12.0.1'
current_inventory=load(ROOT/'docs/literature/omics-2023-2026/tool-inventory.json')
assert next(r for r in current_inventory if r['id']=='arrow-r')['implementation_status']=='missing'
proof=dict(status='PASS_ORIGINAL_ARROW1201_SCOPED_PARQUET_WORKFLOW_AND_INSTALLATION',
    adapter_sources=sources(),module_sources=module_sources,
    source_edition='12.0.1',selected_R='4.2.3',selected_dplyr='1.1.4',matching_cpp_edition='12.0.1',
    original_source_regular_files=1619,original_namespace_functions_audited=13,
    original_controls=13,complete_returns=10,original_failures_without_result=3,
    complete_return_R_identity=True,numeric_bits_and_NA_NaN_payloads_checked=True,
    complete_RNG_compared=True,error_classes_messages_and_calls_identical=True,
    complete_original_conditions_retained=True,whole_condition_identity_controls=12,
    complete_condition_difference=condition_difference,
    condition_fields_deleted_or_coerced=False,live_execution_context_identity_claimed=False,
    unchanged_comparator_controls=2,tampered_comparator_rejections=12,
    actual_recording_and_policy_tests=4,real_denied_subtree_UID=65534,
    installation_modes_passed=['permitted-download','cache-only-no-download'],
    installation_steps_per_setup=2,
    actual_finalization_failure_after_real_original_return=True,failed_recording_result_admitted=False,
    protected_runtime_output_rejected_before_creation=True,
    source_archive=load(HERE/'source-profile.json')['source_archive'],
    primary_review=primary,primary_roles=['chunked-expression-Parquet-loading','pairwise-cluster-DEG-Parquet-query'],
    paper_arrow_calls_and_schema_unreported=True,author_environment_inferred=False,
    reported_chunk_cells=50000,reported_chunk_genes=500,actual_dimension_fixture=[50000,500],
    fixture_layout_is_author_layout=False,sparse_matrix_conversion_qualified=False,
    supported_operations=['read-chunks','dataset-query'],
    live_dataset_or_table_pointer_persistence_qualified=False,
    upstream_source_algorithms_changed=False,private_runtime_binary_payloads_bundled=False,
    catalog_admission_pending=True,new_family_credit=0,native_family_credit=0,
    whole_tool_qualified=False,paper_reproduction_qualified=False,whole_goal_complete=False,
    comparisons=replay['comparisons'],
    history='Earlier attempts remain failed and retained. Original field-name and chained-alias audit bugs, an R top-level else parse error and an attributed-double payload comparator error were corrected in new source snapshots. No original Arrow algorithm, result or old evidence hash was changed. Full earlier build directories remain on disk; bundled history contains their diagnostic and source snapshots.',
    qualified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
DATA.mkdir(exist_ok=False)
(DATA/'.gitattributes').write_bytes(b'* -text whitespace=cr-at-eol\n')
files['QUALIFICATION.json']=(json.dumps(proof,ensure_ascii=False,indent=2)+'\n').encode()
manifest={name:dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()) for name,raw in files.items() if name!='QUALIFICATION.json'}
files['BUNDLE-MANIFEST.json']=(json.dumps(dict(files=manifest),ensure_ascii=False,indent=2)+'\n').encode()
assert len(files)==len(set(n.casefold() for n in files))
bundle=DATA/'original-workflow-and-installation-evidence.zip'
with zipfile.ZipFile(bundle,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,raw in sorted(files.items()):
        entry=zipfile.ZipInfo(name,(2026,11,15,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED;entry.external_attr=0o100644<<16
        archive.writestr(entry,raw)
proof.update(evidence_bundle=pin(bundle),bundle_members=len(files))
save(DATA/'QUALIFICATION.json',proof)
(DATA/'README.md').write_text('# R Arrow 12.0.1 scoped workflow qualification\n\n'
    'Thirteen direct original controls: ten complete returns and three original failures. '
    'Complete returned objects, numeric payloads and RNG match. Twelve complete condition controls match; '
    'the missing-column error differs only in its full trace field because the caller context differs. '
    'Both original errors and every field are retained. Twelve tampered saved objects are rejected.\n\n'
    'Download-enabled and cache-only installs passed. Four real policy/recording tests and a real '
    'UID-65534 permission test passed. A real original return followed by an injected manifest '
    'recording denial exits FAIL2 and admits no result. Earlier failed attempts and original warnings '
    'are retained. The bundle contains complete current scientific input/output/control evidence, '
    'runtime identities and source snapshots; it excludes private executable runtime payloads and scratch directories.\n\n'
    'See tools/literature/arrow1201/README.md for setup, requests, warnings and retry commands. '
    'Catalog admission is pending; no family credit is added by this checkpoint. '
    'The author schema, exact Arrow calls and memory-map settings are unreported. '
    'The 50,000 x 500 wide fixture is a project layout. No whole-tool, biological or paper reproduction claim.\n',encoding='utf-8')
save(BASE/'arrow1201-workflow-seal-1.json',dict(status=proof['status'],bundle=pin(bundle),members=len(files),
    original_controls=13,complete_returns=10,original_errors=3,new_family_credit=0,whole_goal_complete=False))
print(json.dumps(dict(status=proof['status'],bundle=pin(bundle),members=len(files))),flush=True)
