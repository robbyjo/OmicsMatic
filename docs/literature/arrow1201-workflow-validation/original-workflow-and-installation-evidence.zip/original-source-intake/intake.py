from pathlib import Path
import datetime, gzip, hashlib, io, json, re, sys, tarfile, urllib.request
import xml.etree.ElementTree as ET

ROOT = Path('D:/projects/JLinAlg')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'tools/literature'))
from collect_omics_review import paragraphs

def identity(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def fetch(name, url):
    path = OUT / name
    request = urllib.request.Request(url, headers={'User-Agent':'OmicsMatic-original-source-intake'})
    with urllib.request.urlopen(request, timeout=90) as response:
        raw = response.read()
        metadata = dict(requested_url=url, final_url=response.url, status=response.status,
                        headers=dict(response.headers), **identity(raw))
    with path.open('xb') as stream:
        stream.write(raw)
    (OUT / (name + '.provenance.json')).write_text(json.dumps(metadata,indent=2)+'\n', encoding='utf-8')
    return raw, metadata

xml = gzip.decompress((ROOT / 'build/literature-review/xml/PMC10719114.xml.gz').read_bytes())
assert hashlib.sha256(xml).hexdigest() == '48771a4387270374add8ea5c2127306e44260dc2dc2d82b0ceb358a060ca1b94'
ps = [p for p in paragraphs(ET.fromstring(xml)) if p['paragraph_index'] in (87,91)]
(OUT/'PRIMARY-PARAGRAPHS.json').write_text(json.dumps(ps,indent=2,ensure_ascii=False)+'\n', encoding='utf-8')
for p in ps:
    print(p['paragraph_index'], p['section'])
    print('\n'.join(s for s in re.split(r'(?<=[.;])\s+',p['text']) if any(w in s.lower() for w in ['arrow','parquet','chunk'])))

raw, source = fetch('arrow_12.0.1.tar.gz', 'https://cran.r-project.org/src/contrib/Archive/arrow/arrow_12.0.1.tar.gz')
members = {}
with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
    for member in archive.getmembers():
        if member.isfile():
            data = archive.extractfile(member).read()
            members[member.name] = identity(data)
    description = archive.extractfile('arrow/DESCRIPTION').read().decode()
    assert re.search(r'^Version:\s*12\.0\.1\s*$', description, flags=re.M)
    print(description[:1800])
(OUT/'CRAN-SOURCE.json').write_text(json.dumps(dict(source=source, files=members, description=description),indent=2)+'\n', encoding='utf-8')
for name, url in [
    ('open_dataset.html','https://arrow.apache.org/docs/12.0/r/reference/open_dataset.html'),
    ('read_parquet.html','https://arrow.apache.org/docs/12.0/r/reference/read_parquet.html'),
    ('dataset.html','https://arrow.apache.org/docs/12.0/r/articles/dataset.html'),
    ('install.html','https://arrow.apache.org/docs/12.0/r/articles/install.html'),
]:
    fetch(name,url)
record = dict(status='PASS_ORIGINAL_CRAN_ARROW1201_SOURCE_INTAKE', source=source, regular_files=len(members),
              paper='P059', paper_version='12.0.1', paper_arrow_calls_unreported=True,
              implementation_credit=0, whole_goal_complete=False,
              retrieved_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(OUT/'COMPLETED.json').write_text(json.dumps(record,indent=2)+'\n', encoding='utf-8')
print(json.dumps(record))
