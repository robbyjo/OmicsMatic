from pathlib import Path
import json, os, shutil, subprocess, time

ROOT = Path('/mnt/d/projects/JLinAlg')
OUT = ROOT / 'build/literature-review/monocle-runtime/arrow1201-runtime-install-1'
PREFIX = Path('/opt/omicsmatic-arrow1201-reference-20261114-1')
PIXI = ROOT / 'build/literature-review/saige-runtime/pixi-bootstrap-1/pixi'
OUT.mkdir(exist_ok=False)
PREFIX.mkdir(exist_ok=False)
shutil.copyfile(ROOT / 'tools/literature/arrow1201/reference-pixi.toml', PREFIX / 'pixi.toml')
command = [str(PIXI), 'install', '--manifest-path', str(PREFIX / 'pixi.toml')]
start = time.time()
with (OUT/'pixi.stdout').open('xb') as stdout, (OUT/'pixi.stderr').open('xb') as stderr:
    child = subprocess.run(command, cwd=PREFIX, env={**os.environ,'PIXI_NO_PROGRESS':'1'},
                           stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr)
record = dict(status='PASS_EXACT_ARROW1201_LOCKED_ENVIRONMENT' if not child.returncode else 'FAILED_ARROW1201_CANDIDATE_ENVIRONMENT',
              command=command, exit_code=child.returncode, seconds=time.time()-start,
              runtime=str(PREFIX), dependent_workflow_executed=False, implementation_credit=0, whole_goal_complete=False)
(OUT/'PROCESS.json').write_text(json.dumps(record,indent=2)+'\n')
if child.returncode == 0:
    command = [str(PREFIX/'.pixi/envs/default/bin/Rscript'),'--vanilla','-e',
               'stopifnot(as.character(packageVersion("arrow")) == "12.0.1"); print(arrow::arrow_info()); print(sessionInfo())']
    with (OUT/'probe.stdout').open('xb') as stdout, (OUT/'probe.stderr').open('xb') as stderr:
        probe = subprocess.run(command,cwd=PREFIX,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr)
    record['probe_exit_code'] = probe.returncode
    if probe.returncode:
        record['status'] = 'FAILED_ARROW1201_CANDIDATE_RUNTIME_PROBE'
    else:
        shutil.copyfile(PREFIX/'pixi.lock', OUT/'pixi.lock')
    (OUT/'COMPLETED.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record),flush=True)
    raise SystemExit(probe.returncode)
print(json.dumps(record),flush=True)
raise SystemExit(child.returncode)
