from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/handover-101';O=R/'build/git-publish/20261121-handover-catalog-101';B=T/'build/handover-101-checks/controls'
Q='docs/literature/handover-2026-11-21-monocle-catalog';P='C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
if __name__=='__main__':
    profile=json.loads((T/Q/'PROFILE.json').read_bytes());B.mkdir(parents=True,exist_ok=False);results={}
    for label in ['credited-draft','applied-preview','resealed-corrupt-blob']:
        out=B/label;root=out/'copy';root.mkdir(parents=True,exist_ok=False)
        names=set(profile['source_inputs'])|set(profile['canonical_unchanged'])|{Q+'/'+name for name in profile['packet_files']}|{Q+'/PROFILE.json'}
        for name in names:
            target=root/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(T/name,target)
        modified=json.loads((root/Q/'PROFILE.json').read_bytes())
        if label=='credited-draft':modified['new_catalog_credit']=1;expected='Different handover scope'
        elif label=='applied-preview':modified['catalog_applied']=True;expected='Unapplied draft or excluded private data promoted'
        else:
            archive=root/Q/'evidence.zip'
            with zipfile.ZipFile(archive) as z:values={name:z.read(name) for name in z.namelist()}
            key=next(name for name,value in values.items() if value);value=values[key];values[key]=bytes([value[0]^1])+value[1:]
            # This is an owned disposable copy, never the retained packet.
            with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
                for name,raw in values.items():z.writestr(name,raw)
            modified['packet_files']['evidence.zip']=pin(archive.read_bytes());expected='Changed retained blob'
        (root/Q/'PROFILE.json').write_text(json.dumps(modified,indent=2)+'\n',encoding='utf-8',newline='\n')
        command=[P,'-X','utf8','-B',str(root/'tools/literature/verify_monocle_catalog_handover.py'),'--out',str(out/'result')];save(out/'STARTED.json',dict(command=command))
        with (out/'stdout').open('xb') as stdout,(out/'stderr').open('xb') as stderr:p=subprocess.run(command,cwd=root,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=120)
        save(out/'PROCESS.json',dict(exit_code=p.returncode));message=(out/'result/FAILURE.txt').read_text();assert p.returncode==2 and expected in message and not (out/'result/RESULT.json').exists(),(label,p.returncode,message)
        results[label]=dict(exit_code=p.returncode,refused=True,expected=expected,message=message.strip())
    save(B/'RESULT.json',dict(status='PASS_UNAPPLIED_HANDOVER_SCOPE_AND_RESEALED_BLOB_REFUSALS',controls=results));save(O/'NEGATIVE-CONTROLS.json',results);print('PASS: credited draft, applied preview and resealed corrupt evidence all refused',flush=True)
