from pathlib import Path
import argparse,json,subprocess
R=Path('D:/projects/JLinAlg');T=R/'build/handover-101';O=R/'build/git-publish/20261121-handover-catalog-101';B=T/'build/handover-101-checks'
P='C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
def save(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('host',choices=['windows','linux']);args=p.parse_args();host=args.host;out=B/host
    assert (T/'docs/literature/handover-2026-11-21-monocle-catalog/PROFILE.json').is_file()
    if host=='windows':command=[P,'-X','utf8','-B',str(T/'tools/literature/verify_monocle_catalog_handover.py'),'--out',str(out),'--restore']
    else:command=['wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','--user','root','--exec','/usr/bin/python3','-B','/mnt/d/projects/JLinAlg/build/handover-101/tools/literature/verify_monocle_catalog_handover.py','--out','/mnt/d/projects/JLinAlg/build/handover-101/build/handover-101-checks/linux','--git','/mnt/c/Program Files/Git/cmd/git.exe']
    save(O/('reader-'+host+'.STARTED.json'),dict(command=command))
    with (O/('reader-'+host+'.stdout')).open('xb') as stdout,(O/('reader-'+host+'.stderr')).open('xb') as stderr:p=subprocess.run(command,cwd=T,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=600)
    save(O/('reader-'+host+'.PROCESS.json'),dict(exit_code=p.returncode));print(host,'reader exit',p.returncode,flush=True)
    print((out/('RESULT.json' if p.returncode==0 else 'FAILURE.txt')).read_text()[-2000:]);raise SystemExit(p.returncode)
