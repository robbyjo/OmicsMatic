from pathlib import Path
import ast,hashlib,importlib.util,json,re,subprocess,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/handover-101';D=R/'build/mo-8';O=R/'build/git-publish/20261121-handover-catalog-101';Q=T/'docs/literature/handover-2026-11-21-monocle-catalog';B=T/'build/handover-101-checks';BASE='67a3b45b86c93eab12216b257a9ab9b399d329b9'
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
def git(root,*args):return subprocess.check_output(['git','--no-replace-objects',*args],cwd=root)
if __name__=='__main__':
    for host in ['windows','linux']:assert json.loads((O/('reader-'+host+'.PROCESS.json')).read_bytes())['exit_code']==0
    a=json.loads((B/'windows/RESULT.json').read_bytes());b=json.loads((B/'linux/RESULT.json').read_bytes());assert a.pop('restored') is True and b.pop('restored') is False and a==b
    assert (a['historical_worktrees'],a['git_visible_files'],a['logical_evidence_files'])==(57,2228,1114)
    states=json.loads((Q/'WORKTREES.json').read_bytes());restored=patches=0
    with zipfile.ZipFile(Q/'deltas.zip') as z:
        for index,state in enumerate(states):
            root=B/'windows/worktrees'/f'{index:02d}';assert json.loads((root/'STATE.json').read_bytes())==state
            assert (root/'INDEX.patch').read_bytes()==z.read(state['index_patch']['member']);patches+=1
            for name,wanted in state['files'].items():
                path=root/'files'/name
                if wanted is None:assert not path.exists();continue
                assert pin(path.read_bytes())=={k:wanted[k] for k in ['bytes','sha256']},name;restored+=1
    inventory=json.loads((Q/'INVENTORY.json').read_bytes());assert not any('private-primary-1' in name for name in inventory)
    for name,wanted in inventory.items():assert pin((B/'windows/evidence'/name).read_bytes())==wanted,name
    mapping=json.loads((T/'tools/literature/monocle_catalog_development/RESTORE.json').read_bytes());assert len(mapping)==27
    for name,row in mapping.items():assert (D/name).read_bytes()==(T/row['draft']).read_bytes(),name
    old=git(T,'show',BASE+':docs/literature/HANDOVER_CURRENT.md');new=(T/'docs/literature/HANDOVER_CURRENT.md').read_bytes();heading=b'# Current toolbox handover\n\n';assert old.startswith(heading) and new.startswith(heading) and new.endswith(old[len(heading):])
    links=0
    for path in [T/'docs/literature/HANDOVER_2026-11-21_MONOCLE_CATALOG.md',T/'tools/literature/monocle_catalog_development/README.md',Q/'README.md']:
        for name in re.findall(r'\]\(([^)]+)\)',path.read_text(encoding='utf-8')):
            if ':' in name or name.startswith('#'):continue
            assert (path.parent/name.split('#',1)[0]).resolve().exists(),(str(path),name);links+=1
    python_files=[T/'tools/literature/verify_monocle_catalog_handover.py',*(T/'tools/literature/monocle_catalog_development').rglob('*.py')]
    for path in python_files:ast.parse(path.read_text(encoding='utf-8'),filename=str(path))
    node='C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe';cjs=list((T/'tools/literature/monocle_catalog_development').rglob('*.cjs'));assert len(cjs)==1
    command=[node,'--check',str(cjs[0])];save(O/'Node-syntax.STARTED.json',dict(command=command))
    with (O/'Node-syntax.stdout').open('xb') as stdout,(O/'Node-syntax.stderr').open('xb') as stderr:p=subprocess.run(command,cwd=T,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=30)
    save(O/'Node-syntax.PROCESS.json',dict(exit_code=p.returncode));assert p.returncode==0
    # Inspect only candidate counts/paths; never print potential credential values.
    patterns=[re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),re.compile(rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b'),re.compile(rb'\bgh[pousr]_[A-Za-z0-9]{36}\b'),re.compile(rb'\bgithub_pat_[A-Za-z0-9_]{50,}\b')]
    candidates=[];scanned=0
    for archive in [Q/'evidence.zip',Q/'deltas.zip']:
        with zipfile.ZipFile(archive) as z:
            for name in z.namelist():
                raw=z.read(name);scanned+=1
                if any(pattern.search(raw) for pattern in patterns):candidates.append(dict(archive=archive.name,member=name))
    save(O/'CREDENTIAL-PATTERN-CHECK.json',dict(scanned_blobs=scanned,candidates=candidates));assert not candidates,'Credential candidate requires private inspection'
    controls=json.loads((O/'NEGATIVE-CONTROLS.json').read_bytes());assert len(controls)==3 and all(row['refused'] and row['exit_code']==2 for row in controls.values())
    profile=json.loads((Q/'PROFILE.json').read_bytes())
    for name,wanted in profile['canonical_unchanged'].items():assert pin((T/name).read_bytes())==wanted,name
    summary=json.loads((T/'docs/literature/omics-2023-2026/summary.json').read_bytes());assert summary['integration_family_counts']['scoped']==144 and summary['implementation_status_counts']['missing']==259
    spec=importlib.util.spec_from_file_location('inventory',O.parent/'20261115-all-main-3/inventory.py');inv=importlib.util.module_from_spec(spec);spec.loader.exec_module(inv)
    for state in json.loads((O/'WORKTREES-BEFORE.json').read_bytes()):assert inv.snapshot(Path(state['root']))==state,state['root']
    assert not git(T,'diff',BASE,'--name-only','--','src','site','.github','tools/literature/reviewed-uses.json','docs/literature/omics-2023-2026','build.gradle','settings.gradle','gradle.properties')
    sources={}
    for name in ['run_handover_catalog_checks_20261121_101.py','control_handover_catalog_20261121_101.py','finalize_handover_catalog_20261121_101.py']:sources['orchestration/'+name]=R/'build'/name
    for host in ['windows','linux']:
        for suffix in ['STARTED.json','PROCESS.json','stdout','stderr']:sources['reader-'+host+'/'+suffix]=O/('reader-'+host+'.'+suffix)
        sources['reader-'+host+'/RESULT.json']=B/host/'RESULT.json'
    for label in controls:
        for name in ['STARTED.json','PROCESS.json','stdout','stderr','result/FAILURE.txt']:sources['controls/'+label+'/'+name]=B/'controls'/label/name
    for name in ['Node-syntax.STARTED.json','Node-syntax.PROCESS.json','Node-syntax.stdout','Node-syntax.stderr','CREDENTIAL-PATTERN-CHECK.json']:sources['handover/'+name]=O/name
    sources['controls/RESULT.json']=B/'controls/RESULT.json'
    for label in ['P99','catalog']:sources['preceding/'+label+'-RESULT.json']=R/'build/mo-7/build'/('monocle-catalog100-predecessor-'+label+'-1')/'RESULT.json'
    saved={}
    with zipfile.ZipFile(Q/'validation.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,path in sorted(sources.items()):
            raw=path.read_bytes();info=zipfile.ZipInfo(name,(2026,11,21,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,raw);saved[name]=pin(raw)
    result=dict(status='PASS_UNAPPLIED_MONOCLE_CATALOG_HANDOVER_TRANSPORT_AND_SCOPE',baseline=BASE,original_worktrees_preserved=57,git_visible_files_restored_exact=restored,staged_patches_restored_exact=patches,evidence_files_restored_exact=len(inventory),draft_files_saved_exact=27,windows_restore_and_linux_verify_pass=True,negative_controls=controls,relative_document_links_checked=links,python_files_syntax_checked=len(python_files),javascript_files_syntax_checked=1,credential_candidates=0,prior_handover_bytes_retained_exact=True,production_source_build_site_changed=False,canonical_files_unchanged=30,catalog=profile['catalog'],profile=pin((Q/'PROFILE.json').read_bytes()),validation_archive=pin((Q/'validation.zip').read_bytes()),validation_members=saved,scientific_analyses_run_by_handover=0,catalog_applied=False,installed_verification_run=False,installed_UI_run=False,new_catalog_credit=0,whole_goal_complete=False)
    save(Q/'VALIDATION.json',result);save(O/'VALIDATION.json',result)
    print('PASS: 57 owners preserved;2228 variants/57 staged patches/1114 evidence files restored exactly;3 refusal controls;27 drafts saved;canonical unchanged',flush=True)
