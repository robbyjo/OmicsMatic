from pathlib import Path
import ast,hashlib,json,shutil,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/mo-9';B=T/'build/monocle-catalog-1';Q=T/'docs/literature/monocle-admission-checkpoint';O=R/'build/git-publish/20261121-monocle-admission-102'
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
def write(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as f:f.write(value)
if __name__=='__main__':
    assert json.loads((B/'verify-windows-1/PROCESS.json').read_bytes())['exit_code']==0 and json.loads((B/'verify-linux-2/PROCESS.json').read_bytes())['exit_code']==0
    Q.mkdir(exist_ok=False);write(Q/'.gitattributes','* -text whitespace=cr-at-eol\n')
    current=T/'docs/literature/HANDOVER_CURRENT.md';old=current.read_bytes();heading=b'# Current toolbox handover\n\n';assert old.startswith(heading)
    intro='''**Current: [applied Monocle admission and next high-impact work](MONOCLE_ADMISSION_CHECKPOINT_2026-11-21.md).**
The catalog now has **145 scoped families (26 native +119 upstream)**. Nine
Monocle scopes and one related py-monocle policy note are corrected; no review
or observation is appended. Counts remain250 papers,2722 observations,1630
reviewed/1092 pending uses, with258 missing and29 method-overlap labels.
Final41 tests/eight source refusals pass on each host;four actual archive,
fixture/transcript corruptions are refused. Installed Windows/Linux verification
with fresh all250 source audits and desktop/mobile report checks pass. Independent
readback confirms10 scope-only review edits,445/484 unrelated definitions and
all838 prior manifest members,now841. Original proof/inverse records are retained.
Scientific/build code stays at the qualified889-test P99 baseline;29 retained
current-JAR original-R scientific files are verified without refitting models.
Initial filename-collision refusals and the WSL Git-path failure remain preserved.
The packet reader supplies an owned Git launcher when needed. **Next: high-impact
QTLtools/GWAS source and implementation work,plus1092 individual-use reviews.**
Preserve58 preceding owners. **Transfer ignored runtimes,JARs,full text,private
author source and complete private evidence separately before retiring this
machine.** Both reports remain off Pages;no release or goal completion is claimed.
Lower entries retain historical checkpoints and their then-current counts.

'''.encode();current.write_bytes(heading+intro+old[len(heading):]);save(O/'HANDOVER-PREPEND.json',dict(previous=pin(old),current=pin(current.read_bytes()),previous_body_retained_exact=True))
    files={}
    for folder in B.iterdir():
        if not folder.is_dir():continue
        if folder.name.startswith(('controls-','source-','verify-','installed-ui-','independent-readback-')) or folder.name in ['restored-draft-controls','control-revision-before-final-seal','control-revision-before-distinct-proof-seal','controls-before-unique-name-fix','git-shim']:
            for path in folder.rglob('*'):
                if path.is_file():files[path.relative_to(B).as_posix()]=path.read_bytes()
        elif folder.name in ['plan-1','plan-2','plan-3','inspect-1','inspect-3','apply-1','apply-3']:
            for path in folder.iterdir():
                if path.is_file() and path.suffix=='.json':files[path.relative_to(B).as_posix()]=path.read_bytes()
    files['control-integrity-2/RESULT.json']=(B/'control-integrity-2/RESULT.json').read_bytes()
    for path in sorted((R/'build').glob('*monocle*20261121_102.py')):files['orchestration/'+path.name]=path.read_bytes()
    with zipfile.ZipFile(Q/'checks.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,raw in sorted(files.items()):
            info=zipfile.ZipInfo(name,(2026,11,21,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,raw)
    save(Q/'INDEX.json',{name:pin(raw) for name,raw in files.items()})
    transfer=json.loads((T/'docs/literature/monocle-response-checkpoint/PRIVATE-TRANSFER.json').read_bytes());transfer.update(status='PRIVATE_ARTIFACTS_REQUIRE_SEPARATE_CHECKSUMMED_TRANSFER',current_admission_evidence=str(B),all58_preceding_owners_and_current_owner_must_be_preserved=True,prior_draft_and_full_original_captures='D:/projects/JLinAlg/build/mo-8/build/monocle-catalog-1',new_scientific_runtimes_installed=False,prior_transfer_records=['docs/literature/handover-2026-11-21-monocle-catalog/PRIVATE-TRANSFER.json','docs/literature/monocle-response-checkpoint/PRIVATE-TRANSFER.json']);transfer.pop('all55_original_worktrees_and_current_owner_must_be_preserved',None);save(Q/'PRIVATE-TRANSFER.json',transfer)
    write(Q/'README.md','''# Applied Monocle scoped admission checkpoint

Read [the checkpoint](../MONOCLE_ADMISSION_CHECKPOINT_2026-11-21.md) and
[paper crosswalk](../MONOCLE_CATALOG_INTEGRATION.md). One scoped upstream family,
nine existing Monocle scope updates and one related policy note;no appended reviews.
The full250-paper implementation/review objective remains unfinished.

PROFILE.json pins this packet,reader/current handover,and the preceding public
original-control archive. INDEX.json lists checks.zip members. The installed
admission proof binds exact source,fixtures,control archive and canonical bytes.
The reader verifies29 complete original scientific files from the preceding
archive,without calling models or refreshing older fingerprints. --restore
extracts checkpoint receipts only into NEW output. Use the older exact owner to
restore its historical workspace snapshots. Read PRIVATE-TRANSFER.json before
retiring this machine;GitHub does not replace the private evidence/runtime backup.
''')
    source_names=['tools/literature/verify_monocle_admission_packet.py','docs/literature/MONOCLE_ADMISSION_CHECKPOINT_2026-11-21.md','docs/literature/HANDOVER_CURRENT.md']
    ast.parse((T/source_names[0]).read_text())
    ref='docs/literature/handover-2026-11-21-monocle-catalog'
    references={ref+'/'+name:pin((T/ref/name).read_bytes()) for name in ['evidence.zip','INVENTORY.json','PROFILE.json','VALIDATION.json']}
    record=dict(schema_version=1,status='PASS_MONOCLE_SCOPED_FAMILY_ADMISSION',parent_commit='2109e928da8ccc88e0c9c57aadccce665d51a8ed',scientific_and_metadata_before_commit='67a3b45b86c93eab12216b257a9ab9b399d329b9',new_catalog_credit=1,upstream_family_credit=1,native_helpers_additional_credit=0,catalog_applied=True,whole_goal_complete=False,whole_paper_reproduced=False,catalog=dict(papers=250,observations=2722,labels=446,registry_definitions=485,scoped_families=145,native=26,upstream=119,reviewed=1630,pending=1092,missing=258,method_overlap=29,manifest_members=841),source_inputs={name:pin((T/name).read_bytes()) for name in source_names},files={path.name:pin(path.read_bytes()) for path in Q.iterdir() if path.is_file()},original_archive_folder=ref,reference_evidence=references,preceding_owners=58,checkpoint_members=len(files),scientific_models_executed_by_packet_reader=False)
    save(Q/'PROFILE.json',record);print('SEALED applied145-family checkpoint with',len(files),'members;retained original capture archive reused byte-exact',flush=True)
