from pathlib import Path
import io,json,shutil,sys,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/mo-9';B=T/'build/monocle-catalog-1';sys.path.insert(0,str(T/'tools/literature'));from monocle_catalog import primary as p,evidence as e,catalog as c
if __name__=='__main__':
    folder=T/e.CONTROLS;prior=B/'restored-draft-controls';prior.mkdir(exist_ok=False)
    for name in ['checks.zip','CONTROL-CHECKS.json']:shutil.copyfile(folder/name,prior/name)
    files={};hosts={}
    for host in ['windows','linux']:
        root=B/('controls-'+host+'-1');result=json.loads((root/'checks/RESULT.json').read_bytes());process=json.loads((root/'PROCESS.json').read_bytes());assert process['exit_code']==0 and (result['tests'],result['source_refusals'],result['failures'],result['errors'],result['skipped'])==(41,8,0,0,0)
        hosts[host]=dict(exit_code=0,tests=41,source_refusals=8,result=result)
        for path in root.rglob('*'):
            if path.is_file():files[host+'/'+path.relative_to(root).as_posix()]=path.read_bytes()
    for name in e.OWN:files['source/'+name]=(T/name).read_bytes()
    for name in ['metadata-before.zip','QUALIFICATION-BASE.json','FIXTURE.json']:files['fixture/'+name]=(folder/name).read_bytes()
    stream=io.BytesIO()
    with zipfile.ZipFile(stream,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,raw in sorted(files.items()):z.writestr(name,raw)
    (folder/'checks.zip').write_bytes(stream.getvalue());record=dict(status='PASS_MONOCLE_MODEL_TRANSACTION_AND_SOURCE_CONTROLS_BOTH_HOSTS',hosts=hosts,source_code=e.sources(),archive=p.pin(stream.getvalue()),files={name:p.pin(raw) for name,raw in files.items()},scientific_models_run=0,canonical_metadata_modified=False)
    (folder/'CONTROL-CHECKS.json').write_bytes(p.encoded(record));assert c.control_evidence()==record
    print('PASS: both41/8 receipts, all tested sources/fixtures and archive members independently bound',flush=True)
