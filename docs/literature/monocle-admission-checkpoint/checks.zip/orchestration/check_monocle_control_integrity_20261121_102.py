from pathlib import Path
from unittest.mock import patch
import io,json,shutil,sys,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/mo-9';B=T/'build/monocle-catalog-1/control-integrity-1';sys.path.insert(0,str(T/'tools/literature'));from monocle_catalog import primary as p,evidence as e,catalog as c
if __name__=='__main__':
    B.mkdir(exist_ok=False);results={}
    for label in ['changed-archive','resealed-changed-member','resealed-failed-transcript','changed-fixture']:
        root=B/label;folder=root/e.CONTROLS;folder.mkdir(parents=True)
        for path in (T/e.CONTROLS).iterdir():
            if path.is_file():shutil.copyfile(path,folder/path.name)
        for name in e.OWN:
            target=root/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(T/name,target)
        record=json.loads((folder/'CONTROL-CHECKS.json').read_bytes())
        if label=='changed-archive':
            raw=(folder/'checks.zip').read_bytes();(folder/'checks.zip').write_bytes(raw+b'changed');expected='Changed control archive bytes'
        elif label=='changed-fixture':
            (folder/'FIXTURE.json').write_bytes(b'{}\n');expected='Changed tested fixture'
        else:
            with zipfile.ZipFile(folder/'checks.zip') as z:files={name:z.read(name) for name in z.namelist()}
            key='windows/checks/unittest.txt';files[key]=b'Ran 41 tests\nFAILED (failures=1)\n'
            if label=='resealed-failed-transcript':record['files'][key]=p.pin(files[key]);expected='Missing successful unittest transcript'
            else:expected='Changed retained control member'
            buffer=io.BytesIO()
            with zipfile.ZipFile(buffer,'w',compression=zipfile.ZIP_DEFLATED) as z:
                for name,raw in files.items():z.writestr(name,raw)
            (folder/'checks.zip').write_bytes(buffer.getvalue());record['archive']=p.pin(buffer.getvalue());(folder/'CONTROL-CHECKS.json').write_bytes(p.encoded(record))
        with patch.object(c,'ROOT',root):
            try:c.control_evidence()
            except ValueError as error:
                assert expected in str(error),(label,str(error));results[label]=dict(refused=True,error=str(error))
            else:raise AssertionError('Untrusted controls accepted: '+label)
    (B/'RESULT.json').write_bytes(p.encoded(dict(status='PASS_ACTUAL_CONTROL_ARCHIVE_SOURCE_FIXTURE_TRANSCRIPT_REFUSALS',controls=results,scientific_models_run=0)));print('PASS: four actual control-evidence corruption/refusal cases',flush=True)
