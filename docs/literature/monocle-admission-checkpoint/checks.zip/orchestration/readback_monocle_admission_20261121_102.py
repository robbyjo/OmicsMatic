from pathlib import Path
from collections import Counter
import hashlib,json,subprocess,sys,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/mo-9';B=T/'build/monocle-catalog-1/independent-readback-1';sys.path.insert(0,str(T/'tools/literature'))
from monocle_catalog import primary as p,model as m,evidence as e
if __name__=='__main__':
    B.mkdir(exist_ok=False)
    with zipfile.ZipFile(T/e.FOLDER/'metadata-before.zip') as z:before={name:z.read(name) for name in z.namelist()}
    old=json.loads(before[m.META[0]]);new=json.loads((T/m.META[0]).read_bytes());assert len(old)==len(new)==250
    changed=[];observations=0
    for a,b in zip(old,new,strict=True):
        assert {k:v for k,v in a.items() if k!='tools'}=={k:v for k,v in b.items() if k!='tools'}
        assert [row['tool_id'] for row in a['tools']]==[row['tool_id'] for row in b['tools']]
        for x,y in zip(a['tools'],b['tools'],strict=True):
            observations+=1
            if x==y:continue
            fields={key for key in set(x)|set(y) if x.get(key)!=y.get(key)}
            if x['tool_id']=='monocle':assert fields<={'analysis_role','implementation_scope_note','source_role_qualification'} and 'implementation_scope_note' in fields
            else:assert a['paper_id']=='P024' and x['tool_id']=='py-monocle' and fields=={'implementation_scope_note'}
            changed.append(dict(paper_id=a['paper_id'],tool_id=x['tool_id'],fields=sorted(fields)))
    assert observations==2722 and Counter(row['tool_id'] for row in changed)=={'monocle':9,'py-monocle':1}
    oldreviews=json.loads(before[m.META[5]])['reviews'];reviews=json.loads((T/m.META[5]).read_bytes())['reviews'];assert len(oldreviews)==len(reviews)==1630
    assert [(r['pmcid'],r['tool_id']) for r in oldreviews]==[(r['pmcid'],r['tool_id']) for r in reviews]
    edited=[]
    for x,y in zip(oldreviews,reviews,strict=True):
        if x==y:continue
        assert {key:value for key,value in x.items() if key!='implementation_scope_note'}=={key:value for key,value in y.items() if key!='implementation_scope_note'};edited.append((x['pmcid'],x['tool_id']))
    assert len(edited)==10
    a=json.loads(before[m.META[1]]);b=json.loads((T/m.META[1]).read_bytes());assert [r for r in a if r['id']!='monocle']==[r for r in b if r['id']!='monocle'];assert len(b)==446
    from twosamplemr_catalog.model import registry as previous
    a=previous();b=m.registry();assert len(a)==len(b)==485 and [r for r in a if r['id']!='monocle']==[r for r in b if r['id']!='monocle']
    def manifest(raw):
        result={}
        for line in raw.decode().splitlines():
            sha,name=line.split('  ',1);assert name not in result;result[name]=sha
        return result
    previousmanifest=manifest((T/e.FOLDER/'PREVIOUS-SHA256SUMS').read_bytes());current=manifest((T/m.DATA/'SHA256SUMS').read_bytes());assert len(previousmanifest)==838 and len(current)==841 and set(previousmanifest)<=set(current)
    altered=[]
    allowed={(T/name).resolve() for name in m.META}
    for name,wanted in previousmanifest.items():
        actual=hashlib.sha256((T/m.DATA/name).read_bytes()).hexdigest();assert actual==current[name]
        if actual!=wanted:assert (T/m.DATA/name).resolve() in allowed,name;altered.append(name)
    for name in ['monocle-catalog-validation.json','monocle-reviews-shared-source-compatibility.json']:assert current[name]==previousmanifest[name]
    plan=json.loads((T/'build/monocle-catalog-1/plan-3/PLAN.json').read_bytes())
    for name,wanted in plan['preview'].items():assert p.pin((T/name).read_bytes())==wanted,name
    assert not subprocess.check_output(['git','diff','--name-only','2109e928da8ccc88e0c9c57aadccce665d51a8ed','--','src','site/index.html','.github','build.gradle','settings.gradle','gradle.properties'],cwd=T)
    result=dict(status='PASS_INDEPENDENT_MONOCLE_SCOPE_COUNTS_MEMBERSHIP_PRIOR_MANIFEST_READBACK',papers=250,observations=observations,reviewed_uses=1630,pending_uses=1092,changed_paper_tool_scopes=changed,changed_review_scope_records=len(edited),unchanged_reviews=1620,unrelated_inventory_rows_exact=445,unrelated_registry_definitions_exact=484,previous_manifest_members_retained=838,current_manifest_members=841,old_manifest_members_with_intended_metadata_changes=altered,historical_monocle_proof_and_inverse_preserved=True,plan_preview_equals_installed=True,production_source_build_and_Pages_configuration_unchanged=True,whole_goal_complete=False)
    (B/'RESULT.json').write_bytes(p.encoded(result));print('PASS:250 identities/2722 memberships;10 scope-only review changes;445/484 unrelated definitions;all838 previous members retained',flush=True)
