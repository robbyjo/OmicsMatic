from pathlib import Path
import hashlib,importlib.util,json,subprocess
R=Path('D:/projects/JLinAlg');T=R/'build/mo-9';D=R/'build/mo-8';O=R/'build/git-publish/20261121-monocle-admission-102';BASE='2109e928da8ccc88e0c9c57aadccce665d51a8ed'
def save(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
def git(root,*args):return subprocess.check_output(['git','--no-replace-objects',*args],cwd=root)
if __name__=='__main__':
    O.mkdir(parents=True,exist_ok=False);spec=importlib.util.spec_from_file_location('inventory',O.parent/'20261115-all-main-3/inventory.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
    states=[v.snapshot(Path(b.splitlines()[0][9:])) for b in git(R,'worktree','list','--porcelain').decode().strip().split('\n\n')];assert len(states)==58;save(O/'WORKTREES-BEFORE.json',states)
    assert git(R,'ls-remote','origin','refs/heads/main').decode().split()[0]==BASE
    command=['git','worktree','add','-b','codex/monocle-admission-20261121',str(T),BASE];save(O/'WORKTREE-STARTED.json',dict(command=command))
    with (O/'worktree.stdout').open('xb') as stdout,(O/'worktree.stderr').open('xb') as stderr:p=subprocess.run(command,cwd=R,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=240)
    save(O/'WORKTREE-PROCESS.json',dict(exit_code=p.returncode));assert p.returncode==0
    mapping=json.loads((T/'tools/literature/monocle_catalog_development/RESTORE.json').read_bytes())
    for name,row in mapping.items():
        raw=(T/row['draft']).read_bytes();assert dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())=={k:row[k] for k in ['bytes','sha256']};target=T/name;assert not target.exists();target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);assert raw==(D/name).read_bytes()
    save(O/'DRAFT-RESTORED.json',dict(source_owner=str(D),files=27,byte_exact=True,old_owner_changed=False));print('PASS: 58 owners saved;59th owner restored27 exact draft files on current main',flush=True)
