from pathlib import Path
import hashlib,json,shutil
R=Path('D:/projects/JLinAlg');T=R/'build/mo-9';B=T/'build/monocle-catalog-1';O=R/'build/git-publish/20261121-monocle-admission-102'
if __name__=='__main__':
    canonical=json.loads((O.parent/'20261121-handover-catalog-101/CANONICAL-UNCHANGED.json').read_bytes())
    for name,wanted in canonical.items():
        raw=(T/name).read_bytes();assert dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())==wanted,name
    source=(T/'docs/literature/monocle-catalog-admission').resolve();target=(B/'apply-1-empty-prewrite-owner').resolve();assert source.is_relative_to(T.resolve()) and target.is_relative_to(B.resolve()) and source.is_dir() and not any(source.iterdir()) and not target.exists();source.rename(target)
    prior=B/'controls-before-unique-name-fix';prior.mkdir()
    for name in ['checks.zip','CONTROL-CHECKS.json']:shutil.copyfile(T/'docs/literature/monocle-catalog-controls'/name,prior/name)
    script=(R/'build/run_monocle_admission_checks_20261121_102.py').read_text();script=script.replace("folder=B/(mode+'-'+host+'-1')","folder=B/(mode+'-'+host+'-2')")
    (R/'build/run_monocle_admission_checks_v2_20261121_102.py').write_text(script,encoding='utf-8',newline='\n')
    seal=(R/'build/seal_monocle_admission_controls_20261121_102.py').read_text().replace("prior=B/'restored-draft-controls'","prior=B/'control-revision-before-final-seal'").replace("'controls-'+host+'-1'","'controls-'+host+'-2'")
    (R/'build/seal_monocle_admission_controls_v2_20261121_102.py').write_text(seal,encoding='utf-8',newline='\n')
    (B/'apply-1/PRESERVED-FAILURE-SCOPE.json').write_text(json.dumps(dict(status='OWNERSHIP_GUARD_REFUSED_HISTORICAL_FILENAME_COLLISION_BEFORE_WRITES',canonical_files_unchanged=30,historical_record_preserved=True,source='docs/literature/omics-2023-2026/monocle-reviews-shared-source-compatibility.json',new_distinct_record='monocle-admission-reviews-shared-source-compatibility.json',empty_prewrite_owner_retained=str(target)),indent=2)+'\n',encoding='utf-8',newline='\n');print('PASS: all30 canonical files unchanged; historical record and failed empty owner retained',flush=True)
