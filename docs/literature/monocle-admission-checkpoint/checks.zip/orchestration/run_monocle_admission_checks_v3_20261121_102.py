from pathlib import Path
import argparse,json,subprocess
R=Path('D:/projects/JLinAlg');T=R/'build/mo-9';B=T/'build/monocle-catalog-1';P='C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
def save(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('host',choices=['windows','linux']);parser.add_argument('mode',choices=['controls','source','verify']);args=parser.parse_args();host=args.host;mode=args.mode;folder=B/(mode+'-'+host+'-3');folder.mkdir(parents=True,exist_ok=False)
    tool={'controls':'check_monocle_catalog_controls.py','source':'audit_monocle_source_roles.py','verify':'close_monocle_catalog.py'}[mode]
    extra=[] if mode=='controls' else ['--primary-cache','D:/projects/JLinAlg/build/literature-review/xml']
    if mode=='verify':extra=['--verify',*extra]
    if host=='windows':command=[P,'-X','utf8','-B',str(T/'tools/literature'/tool),*extra,'--out',str(folder/'checks')]
    else:
        extra=[item.replace('D:/','/mnt/d/') for item in extra];command=['wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','-u','root','--','/usr/bin/env','MONOCLE_CATALOG_GIT=/mnt/c/Program Files/Git/cmd/git.exe','python3','-B','/mnt/d/projects/JLinAlg/build/mo-9/tools/literature/'+tool,*extra,'--out','/mnt/d/projects/JLinAlg/build/mo-9/build/monocle-catalog-1/'+folder.name+'/checks']
    save(folder/'STARTED.json',dict(command=command))
    with (folder/'stdout').open('xb') as stdout,(folder/'stderr').open('xb') as stderr:p=subprocess.run(command,cwd=T,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=300)
    save(folder/'PROCESS.json',dict(exit_code=p.returncode));print(host,mode,'exit',p.returncode,flush=True)
    if p.returncode:print((folder/'stderr').read_text(errors='replace')[-3000:])
    raise SystemExit(p.returncode)
