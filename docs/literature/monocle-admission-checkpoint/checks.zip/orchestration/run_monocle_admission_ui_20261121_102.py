from pathlib import Path
import functools,http.server,json,subprocess,threading,urllib.parse
R=Path('D:/projects/JLinAlg');T=R/'build/mo-9';B=T/'build/monocle-catalog-1';O=B/'installed-ui-1';O.mkdir();browser=O/'browser';browser.mkdir()
record=json.loads((B/'apply-3/COMPLETED.json').read_bytes());assert record['result']['integrations']==145
log=(O/'server.log').open('x',encoding='utf-8')
class Handler(http.server.SimpleHTTPRequestHandler):
    def log_message(self,format,*args):log.write(format%args+'\n');log.flush()
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(T/'site')));thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();node=Path('C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/node');command=[str(node/'bin/node.exe'),str(T/'tools/literature/check_monocle_catalog_ui.cjs'),str(node/'node_modules/playwright'),str(browser),'http://127.0.0.1:'+str(server.server_port)]
try:
    with (O/'stdout').open('xb') as stdout,(O/'stderr').open('xb') as stderr:process=subprocess.run(command,cwd=T,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=150)
    (O/'PROCESS.json').write_text(json.dumps(dict(command=command,exit_code=process.returncode,mode='installed',scientific_models_run=False),indent=2)+'\n',encoding='utf-8',newline='\n');print((O/'stdout').read_text(errors='replace'),(O/'stderr').read_text(errors='replace')[-3000:],flush=True);assert process.returncode==0,'Inspect retained browser output'
finally:server.shutdown();server.server_close();thread.join(timeout=10);log.close()
(O/'SERVER-CLOSED.json').write_text(json.dumps(dict(owned_helper_stopped=not thread.is_alive()))+'\n',encoding='utf-8')
