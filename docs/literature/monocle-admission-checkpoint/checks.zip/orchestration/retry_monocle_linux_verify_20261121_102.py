from pathlib import Path
import json,subprocess
R=Path('D:/projects/JLinAlg');T=R/'build/mo-9';B=T/'build/monocle-catalog-1';O=B/'verify-linux-2'
if __name__=='__main__':
    O.mkdir(exist_ok=False);linux='/mnt/d/projects/JLinAlg/build/mo-9';shim=linux+'/build/monocle-catalog-1/git-shim'
    chmod=['wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','-u','root','--','chmod','0755',shim+'/git'];subprocess.run(chmod,check=True,timeout=30)
    command=['wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','-u','root','--','/usr/bin/env','MONOCLE_CATALOG_GIT=/mnt/c/Program Files/Git/cmd/git.exe','PATH='+shim+':/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin','python3','-B',linux+'/tools/literature/close_monocle_catalog.py','--verify','--primary-cache','/mnt/d/projects/JLinAlg/build/literature-review/xml','--out',linux+'/build/monocle-catalog-1/verify-linux-2/checks']
    (O/'STARTED.json').write_text(json.dumps(dict(command=command,reason='Linked Windows checkout: route inherited hard-coded git calls and current configurable calls through unchanged Windows Git; no source/hash refresh'),indent=2)+'\n',encoding='utf-8',newline='\n')
    with (O/'stdout').open('xb') as stdout,(O/'stderr').open('xb') as stderr:p=subprocess.run(command,cwd=T,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=300)
    (O/'PROCESS.json').write_text(json.dumps(dict(exit_code=p.returncode))+'\n',encoding='utf-8');print('Linux installed verification retry exit',p.returncode,flush=True)
    if p.returncode:print((O/'stderr').read_text(errors='replace')[-3000:])
    raise SystemExit(p.returncode)
