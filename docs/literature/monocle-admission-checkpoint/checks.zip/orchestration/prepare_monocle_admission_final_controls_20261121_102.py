from pathlib import Path
R=Path('D:/projects/JLinAlg');B=R/'build/mo-9/build/monocle-catalog-1'
if __name__=='__main__':
    run=(R/'build/run_monocle_admission_checks_v2_20261121_102.py').read_text().replace("folder=B/(mode+'-'+host+'-2')","folder=B/(mode+'-'+host+'-3')")
    (R/'build/run_monocle_admission_checks_v3_20261121_102.py').write_text(run,encoding='utf-8',newline='\n')
    seal=(R/'build/seal_monocle_admission_controls_v2_20261121_102.py').read_text().replace("prior=B/'control-revision-before-final-seal'","prior=B/'control-revision-before-distinct-proof-seal'").replace("'controls-'+host+'-2'","'controls-'+host+'-3'")
    (R/'build/seal_monocle_admission_controls_v3_20261121_102.py').write_text(seal,encoding='utf-8',newline='\n')
    control=(R/'build/check_monocle_control_integrity_20261121_102.py').read_text().replace("B=T/'build/monocle-catalog-1/control-integrity-1'","B=T/'build/monocle-catalog-1/control-integrity-2'")
    (R/'build/check_monocle_control_integrity_v2_20261121_102.py').write_text(control,encoding='utf-8',newline='\n')
    print('Prepared final-source control runners',flush=True)
