from pathlib import Path
import argparse,json,subprocess
R=Path('D:/projects/JLinAlg');T=R/'build/mo-9';B=T/'build/monocle-catalog-1';O=R/'build/git-publish/20261121-monocle-admission-102'
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('host',choices=['windows','linux']);args=p.parse_args();host=args.host;out=B/('packet-'+host+'-1')
    if host=='windows':command=['C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe','-X','utf8','-B',str(T/'tools/literature/verify_monocle_admission_packet.py'),'--out',str(out),'--restore']
    else:command=['wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','-u','root','--','python3','-B','/mnt/d/projects/JLinAlg/build/mo-9/tools/literature/verify_monocle_admission_packet.py','--out','/mnt/d/projects/JLinAlg/build/mo-9/build/monocle-catalog-1/packet-linux-1','--git','/mnt/c/Program Files/Git/cmd/git.exe']
    with (O/('packet-'+host+'.STARTED.json')).open('x',encoding='utf-8',newline='\n') as f:json.dump(dict(command=command),f,indent=2);f.write('\n')
    with (O/('packet-'+host+'.stdout')).open('xb') as stdout,(O/('packet-'+host+'.stderr')).open('xb') as stderr:p=subprocess.run(command,cwd=T,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=300)
    with (O/('packet-'+host+'.PROCESS.json')).open('x',encoding='utf-8') as f:json.dump(dict(exit_code=p.returncode),f)
    print(host,'packet exit',p.returncode,flush=True)
    if p.returncode:print((O/('packet-'+host+'.stderr')).read_text(errors='replace')[-3000:])
    else:print((out/'RESULT.json').read_text()[-1700:])
    raise SystemExit(p.returncode)
