from pathlib import Path
import ast,copy,hashlib,importlib.util,json,re,subprocess,sys,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/mo-9';B=T/'build/monocle-catalog-1';Q=T/'docs/literature/monocle-admission-checkpoint';O=R/'build/git-publish/20261121-monocle-admission-102';BASE='2109e928da8ccc88e0c9c57aadccce665d51a8ed'
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
def git(*args):return subprocess.check_output(['git','--no-replace-objects',*args],cwd=T)
if __name__=='__main__':
    for host in ['windows','linux']:assert json.loads((O/('packet-'+host+'.PROCESS.json')).read_bytes())['exit_code']==0
    a=json.loads((B/'packet-windows-1/RESULT.json').read_bytes());b=json.loads((B/'packet-linux-1/RESULT.json').read_bytes());assert a.pop('restored') is True and b.pop('restored') is False and a==b
    index=json.loads((Q/'INDEX.json').read_bytes());assert len(index)==109
    for name,wanted in index.items():assert pin((B/'packet-windows-1/captured'/name).read_bytes())==wanted,name
    sys.path.insert(0,str(T/'tools/literature'));import verify_monocle_admission_packet as reader
    profile=json.loads((Q/'PROFILE.json').read_bytes());refusals={}
    for label,mutate in [('whole-goal',lambda row:row.update(whole_goal_complete=True)),('double-helper-credit',lambda row:row.update(native_helpers_additional_credit=1)),('wrong-count',lambda row:row['catalog'].update(scoped_families=146))]:
        changed=copy.deepcopy(profile);mutate(changed)
        try:reader.profile_scope(changed)
        except ValueError as error:refusals[label]=dict(refused=True,error=str(error))
        else:raise AssertionError('False packet scope admitted: '+label)
    links=0
    for path in [T/'docs/literature/MONOCLE_ADMISSION_CHECKPOINT_2026-11-21.md',T/'docs/literature/MONOCLE_CATALOG_INTEGRATION.md',Q/'README.md',T/'tools/literature/monocle_catalog/ADMISSION.md']:
        for name in re.findall(r'\]\(([^)]+)\)',path.read_text(encoding='utf-8')):
            if ':' in name or name.startswith('#'):continue
            assert (path.parent/name.split('#',1)[0]).resolve().exists(),(str(path),name);links+=1
    old=git('show',BASE+':docs/literature/HANDOVER_CURRENT.md');current=(T/'docs/literature/HANDOVER_CURRENT.md').read_bytes();assert current.endswith(old[len(b'# Current toolbox handover\n\n'):])
    pyfiles=[T/'tools/literature/verify_monocle_admission_packet.py',T/'tools/literature/close_monocle_catalog.py',T/'tools/literature/check_monocle_catalog_controls.py',T/'tools/literature/audit_monocle_source_roles.py',*(T/'tools/literature/monocle_catalog').glob('*.py')]
    for path in pyfiles:ast.parse(path.read_text(encoding='utf-8'),filename=str(path))
    spec=importlib.util.spec_from_file_location('inventory',O.parent/'20261115-all-main-3/inventory.py');inv=importlib.util.module_from_spec(spec);spec.loader.exec_module(inv)
    for state in json.loads((O/'WORKTREES-BEFORE.json').read_bytes()):assert inv.snapshot(Path(state['root']))==state,state['root']
    assert not git('diff',BASE,'--name-only','--','src','.github','build.gradle','settings.gradle','gradle.properties')
    sources={}
    for name in ['run_monocle_admission_packet_20261121_102.py','finalize_monocle_admission_20261121_102.py']:sources['orchestration/'+name]=R/'build'/name
    for host in ['windows','linux']:
        for suffix in ['STARTED.json','PROCESS.json','stdout','stderr']:sources['packet-'+host+'/'+suffix]=O/('packet-'+host+'.'+suffix)
        sources['packet-'+host+'/RESULT.json']=B/('packet-'+host+'-1')/'RESULT.json'
    saved={}
    with zipfile.ZipFile(Q/'validation.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,path in sorted(sources.items()):
            raw=path.read_bytes();info=zipfile.ZipInfo(name,(2026,11,21,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,raw);saved[name]=pin(raw)
    value=dict(status='PASS_FINAL_SCOPED_MONOCLE_CATALOG_ADMISSION',catalog=profile['catalog'],final_source_tests_per_host=41,source_refusals_per_host=8,actual_control_integrity_refusals=4,packet_scope_refusals=refusals,windows_restore_linux_verify=True,checkpoint_files_restored_exact=109,retained_original_scientific_files_verified=29,relative_document_links_checked=links,python_files_syntax_checked=len(pyfiles),prior_owners_preserved=58,production_source_build_and_Pages_configuration_unchanged=True,previous_handover_body_retained_exact=True,profile=pin((Q/'PROFILE.json').read_bytes()),validation_archive=pin((Q/'validation.zip').read_bytes()),validation_members=saved,new_catalog_credit=1,whole_goal_complete=False)
    save(Q/'VALIDATION.json',value);save(O/'VALIDATION.json',value);print('PASS:145 scoped families;109 checkpoint files restored;29 retained scientific files verified;all58 preceding owners preserved',flush=True)
