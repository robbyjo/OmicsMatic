package org.jlinalg.cli;
import java.nio.file.*;
import java.util.*;
import java.util.zip.GZIPOutputStream;
import org.jlinalg.sequence.FastpReadFilter;
public final class FastpOutputControlMain {
 private FastpOutputControlMain() { }
 static final List<String> NAMES=List.of("se-default","se-custom-adapter","se-polyg","se-polyx","se-cut-and-cap","se-gzip-phred64-plus","se-literal","se-all-filtered","se-dedup","pe-discard-orphans","pe-store-orphans","pe-overlap-correction","pe-custom-adapter","pe-dedup");
 static String dna(int n,long seed){var random=new Random(seed);var out=new StringBuilder();for(int i=0;i<n;i++)out.append("ACGT".charAt(random.nextInt(4)));return out.toString();}
 static String rc(String value){var out=new StringBuilder();for(int i=value.length()-1;i>=0;i--)out.append(switch(value.charAt(i)){case 'A'->'T';case 'C'->'G';case 'G'->'C';case 'T'->'A';default->'N';});return out.toString();}
 static String fq(String header,String seq,String qual,String plus){return header+"\n"+seq+"\n"+plus+"\n"+qual+"\n";}
 static String q(int n){return "I".repeat(n);}
 static FastpOriginalStage.Limits limits(boolean high){return new FastpOriginalStage.Limits(new FastpFastq.Limits(16777216,67108864,100000,10000000,10000,1000),new FastpProcess.Limits(high?240000:120000,(high?28L:6L)<<30,180,16777216,256,67108864,256,16,64,(high?27L:5L)<<30,25),134217728,512);}
 static FastpParameters.Options options(String name,String version){
  var d=FastpParameters.Options.defaults(3);var adapters=d.adapters();var global=d.global();var cutting=d.cutting();var filter=d.filters();var poly=d.polyG();boolean px=false,correct=false,orphans=false;var dup=new FastpParameters.Duplication(false,false,0);
  if(name.contains("custom-adapter"))adapters=new FastpParameters.Adapters(true,false,"AGATCGGAAGAGCACACGTCT",name.startsWith("pe-")?"AGATCGGAAGAGCGTCGTGTAG":"");
  if(!name.startsWith("pe-")&&!name.contains("custom-adapter"))adapters=new FastpParameters.Adapters(false,false,"","");
  if(name.equals("se-polyg"))poly=FastpParameters.PolyG.ENABLE;
  if(name.equals("se-polyx")){poly=FastpParameters.PolyG.DISABLE;px=true;}
  if(name.equals("se-cut-and-cap")){cutting=new FastpParameters.Cutting(new FastpReadFilter.Cut(true,4,20),new FastpReadFilter.Cut(true,4,20),FastpReadFilter.Cut.disabled());global=new FastpParameters.Global(2,1,0,0,80,0);}
  if(name.equals("se-all-filtered"))filter=new FastpReadFilter.Filters(true,15,40,0,5,true,200,0,false,30);
  if(name.equals("pe-store-orphans"))orphans=true;
  if(name.equals("pe-overlap-correction"))correct=true;
  if(name.contains("dedup"))dup=new FastpParameters.Duplication(true,true,version.equals("0.22.0")?0:1);
  if(name.equals("p054-reported-options")){adapters=new FastpParameters.Adapters(true,true,"","");correct=true;cutting=new FastpParameters.Cutting(FastpReadFilter.Cut.disabled(),new FastpReadFilter.Cut(true,4,20),FastpReadFilter.Cut.disabled());filter=new FastpReadFilter.Filters(true,15,40,30,5,true,100,0,false,30);dup=new FastpParameters.Duplication(true,true,6);}
  return new FastpParameters.Options(3,adapters,global,cutting,filter,poly,10,px,10,correct,dup,d.overlap(),orphans);
 }
 static void run(String version,String name,Path root)throws Exception {
  Path context=Path.of("/opt/omicsmatic-fastp-managed-1");var runtime=FastpRuntime.open(context.resolve("homes").resolve(version),"linux-x86_64-fastp-"+version,context.resolve("reports").resolve(version),()->{});Files.createDirectory(root);
  boolean paired=name.startsWith("pe-")||name.startsWith("p054-");var one=new StringBuilder();var two=new StringBuilder();String a1="AGATCGGAAGAGCACACGTCT",a2="AGATCGGAAGAGCGTCGTGTAG";
  for(int i=0;i<20;i++){
   int group=i%10;int length=(group==3?12:130);String seq=dna(length,group+100);String mate=rc(seq);String qual=q(seq.length()),mq=q(mate.length());String header="@fixture:"+i+(paired?"/1":""),mh="@fixture:"+i+"/2";
   if(group==1)qual="!".repeat(seq.length());if(group==2)mq="!".repeat(mate.length());if(group==4)seq="N".repeat(8)+seq.substring(8);
   if(name.contains("custom-adapter")||name.contains("overlap-correction")||name.equals("p054-reported-options")){seq+=a1;qual+=q(a1.length());mate+=a2;mq+=q(a2.length());}
   if((name.contains("overlap-correction")||name.equals("p054-reported-options"))&&group==5){int p=60;seq=seq.substring(0,p)+(seq.charAt(p)=='A'?'C':'A')+seq.substring(p+1);qual=qual.substring(0,p)+"#"+qual.substring(p+1);}
   if(name.equals("se-polyg")){seq+="GGGGGGGGGGGGGGGGGGGG";qual+=q(20);}
   if(name.equals("se-polyx")){String tail=List.of("AAAAAAAAAAAAAAAAAAAA","TTTTTTTTTTTTTTTTTTTT","NNNNNNNNNNNNNNNNNNNN").get(group%3);seq+=tail;qual+=q(tail.length());}
   if(name.equals("se-cut-and-cap")){qual="!!!!"+qual.substring(4,Math.min(90,qual.length()))+(qual.length()>90?"!".repeat(qual.length()-90):"");}
   if(name.equals("se-literal"))seq=seq.toLowerCase(Locale.ROOT);
   boolean encoded=name.equals("se-gzip-phred64-plus");if(encoded){var out=new StringBuilder();for(char value:qual.toCharArray())out.append((char)(value+31));qual=out.toString();}
   String plus=encoded?"+fixture:"+i+" carried-plus-comment":"+";
   one.append(fq(header,seq,qual,plus));if(paired)two.append(fq(mh,mate,mq,"+"));
  }
  Path input=root.resolve(name.equals("se-gzip-phred64-plus")?"input.original":"input1.fq");if(name.equals("se-gzip-phred64-plus")){try(var out=new GZIPOutputStream(Files.newOutputStream(input))){out.write(one.toString().getBytes(java.nio.charset.StandardCharsets.US_ASCII));}}else Files.writeString(input,one);
  Path second=paired?root.resolve("input2.fq"):null;if(paired)Files.writeString(second,two);
  if(name.equals("p054-reported-options")){
   long available=Files.readAllLines(Path.of("/proc/meminfo")).stream().filter(s->s.startsWith("MemAvailable:")).mapToLong(s->Long.parseLong(s.trim().split("\\s+")[1])*1024).findFirst().orElseThrow();
   if(available<(28L<<30))throw new IllegalStateException("High-memory source control unavailable: MemAvailable below28GiB;do not lower requested accuracy");
   FastpFiles.writeJson(root.resolve("memory-preflight.json"),Map.of("mem_available_bytes",available,"minimum_available_bytes",28L<<30,"requested_bloom_bytes",24L<<30,"accuracy",6));
  }
  var result=FastpOriginalStage.run(runtime,input,second,name.equals("se-gzip-phred64-plus")?FastpFastq.Encoding.PHRED64:FastpFastq.Encoding.PHRED33,name.equals("se-literal")?FastpFastq.Alphabet.LITERAL_ASCII:FastpFastq.Alphabet.UPPER_ACGTN,name.equals("se-gzip-phred64-plus")?FastpFastq.Plus.MATCH_FIRST_TOKEN_OR_EMPTY:FastpFastq.Plus.EMPTY_ONLY,paired?FastpFastq.Pairing.TERMINAL_MATE_SUFFIX:FastpFastq.Pairing.EXACT_FIRST_TOKEN,options(name,version),root.resolve("result"),limits(name.equals("p054-reported-options")),()->{});
  FastpFiles.writeJson(root.resolve("control.json"),Map.of("version",version,"case",name,"status","ORIGINAL_EXECUTED_OUTPUT_AUDIT_PENDING","exit_code",result.process().exitCode(),"owned_live_after_cleanup",result.process().ownedLiveAfterCleanup()));
  System.out.println(version+" "+name+" original-exit0");System.out.flush();
 }
 static void next(String version,String name,Path requested)throws Exception {
  Path target=requested;
  if(Files.exists(target.resolve("control.json"))){
   var receipt=FastpRuntime.object(FastpFiles.json(target.resolve("control.json"),65536));var request=FastpRuntime.object(FastpFiles.json(target.resolve("result/request.json"),65536));var process=FastpRuntime.object(FastpFiles.json(target.resolve("result/original/process.json"),65536));
   if(!version.equals(receipt.get("version"))||!name.equals(receipt.get("case"))||!Long.valueOf(0).equals(process.get("exit_code"))||!List.of().equals(process.get("owned_live_after_cleanup"))||!SimpleJson.parse(FastpJson.json(options(name,version))).equals(request.get("options")))throw new IllegalStateException("Existing terminal case differs;preserve it without reuse");
   for(Object object:(List<?>)FastpFiles.json(target.resolve("result/input-captures.json"),65536)){
    var capture=FastpRuntime.object(object);String member=FastpFiles.member(FastpRuntime.text(capture.get("snapshot")));var expected=FastpRuntime.fingerprint(FastpRuntime.object(FastpRuntime.object(capture.get("identity")).get("pin")));
    if(!FastpFiles.pin(target.resolve("result").resolve(member),16777216,()->{}).equals(expected)||!FastpFiles.pin(Path.of(FastpRuntime.text(capture.get("originalPath"))),16777216,()->{}).equals(expected))throw new IllegalStateException("Retained source/snapshot differs");
   }
   System.out.println(version+" "+name+" verified-retained-without-rerun");return;
  }
  if(Files.exists(target))target=target.resolveSibling(target.getFileName()+"-attempt2");
  run(version,name,target);
 }
 public static void main(String[] args)throws Exception {
  Path root=Path.of("/opt/omicsmatic-fastp-output-controls-1");if(args.length==0)Files.createDirectory(root);else if(args.length!=1||!args[0].equals("--resume")||!root.toRealPath().equals(root))throw new IllegalArgumentException("Explicit --resume and canonical retained root required");
  for(String version:List.of("0.22.0","0.23.2","0.25.0","1.0.1")){Path folder=root.resolve(version);if(!Files.exists(folder))Files.createDirectory(folder);for(String name:NAMES)next(version,name,folder.resolve(name));}
  next("0.23.2","p054-reported-options",root.resolve("p054-reported-options"));
 }
}
