from pathlib import Path
import hashlib,json,subprocess,zipfile,xml.etree.ElementTree as ET
R=Path('D:/projects/JLinAlg');B=R/'build/literature-review/fastp-runtime/output-audit-1';D=R/'docs/literature'
load=lambda p:json.loads(p.read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest()
def pin(p):
 raw=p.read_bytes();return dict(bytes=len(raw),sha256=sha(raw))
old=[]
for name in ['FASTP_NATIVE_DEVELOPMENT_VALIDATION.json','FASTP_ORIGINAL_STAGE_DEVELOPMENT_VALIDATION.json']:
 proof=load(D/name)
 for path,expected in proof['source_pins'].items():assert pin(R/path)==expected,path
 assert pin(D/proof['artifact']['path'])=={k:v for k,v in proof['artifact'].items() if k!='path'}
 old.append(dict(report=name,source_pins=len(proof['source_pins'])))
canonical=pin(R/'build/cli/omicsmatic-0.3.7.jar');assert canonical['sha256']=='bd1a3b2448d7016ae4ded3f30a6c5ae92e05a0078ae688f4b93d046cc355eeb2'
assert sha((R/'site/literature-review.html').read_bytes())=='0ba1942da9ad2d7d00331cadda4a300e6e9b9c2111745e02be8b656f51b66c86'
checksums={}
for manifest in sorted((R/'docs').rglob('SHA256SUMS'))+sorted((R/'src/test/resources').rglob('SHA256SUMS')):
 lines=manifest.read_text().splitlines()
 for line in lines:
  expected,member=line.split('  ',1);p=(manifest.parent/member).resolve();assert p.is_relative_to(R.resolve()) and pin(p)['sha256']==expected,str(p)
 checksums[manifest.relative_to(R).as_posix()]=len(lines)
assert len(checksums)==8 and sum(checksums.values())==578
matrix=load(B/'packaged-tests-1/summary.json');assert matrix['tests_found_per_JVM']==327 and len(matrix['runs'])==3 and all(r['exit_code']==0 for r in matrix['runs'])
assert pin(R/matrix['artifact'])['sha256']==matrix['artifact_sha256']
assert matrix['corpus']==dict(additionally_constrained_fields=11288,independently_recomputed_fields=383617,input_reads=1560,originals_rerun=False,represented_reads=1362,unrepresented_reads=198,visible_corrected_bases=9)
assert 'BUILD SUCCESSFUL' in (B/'verification-1/build-5.log').read_text() and 'Ran 619 tests' in (B/'verification-1/python-full-1.log').read_text() and 'OK (skipped=46)' in (B/'verification-1/python-full-1.log').read_text()
tests={};total=failed=skipped=0
for p in sorted((R/'build/test-results/test').glob('TEST-*Fastp*.xml')):
 node=ET.fromstring(p.read_bytes());a=node.attrib;count=int(a['tests']);errors=int(a['failures'])+int(a['errors']);skip=int(a['skipped']);total+=count;failed+=errors;skipped+=skip;tests[p.name]=dict(tests=count,failed=errors,skipped=skip)
assert (total,failed,skipped)==(460,0,150),(total,failed,skipped)
capture=load(B/'output-controls-1.json');assert capture['completed_original_controls']==57 and capture['files']==1164 and capture['high_memory_reported_P054_options_executed'] and capture['all_owned_processes_terminal']
fixture=R/'src/test/resources/org/jlinalg/cli/fastp-output/original-output-controls.zip';assert pin(fixture)=={k:v for k,v in capture['artifact'].items() if k!='path'}
with zipfile.ZipFile(fixture) as z:
 process=load(B/'audited-corpus-1/p054-reported-options/original/process.json');assert process['exit_code']==0 and process['owned_live_after_cleanup']==[]
 assert len(z.namelist())==len(set(z.namelist()))
 print('P054 process resource fields:',json.dumps({k:v for k,v in process.items() if any(word in k.lower() for word in ['peak','rss'])}))
paths=set()
for name in ['FASTP_NATIVE_DEVELOPMENT_VALIDATION.json','FASTP_ORIGINAL_STAGE_DEVELOPMENT_VALIDATION.json']:paths.update(load(D/name)['source_pins'])
for folder,pattern in [('src/main/java/org/jlinalg/cli','Fastp*.java'),('src/test/java/org/jlinalg/cli','Fastp*Test.java')]:paths.update(p.relative_to(R).as_posix() for p in (R/folder).glob(pattern))
paths.update(['docs/literature/FASTP_OUTPUT_AUDIT_DEVELOPMENT.md','tools/literature/fastp-runtime-lock.json','tools/literature/install_fastp.py','tools/literature/test_install_fastp.py','tools/literature/fastp-development.init.gradle','src/main/resources/org/jlinalg/omics/fastp-runtime-lock.json','src/main/resources/org/jlinalg/omics/fastp-MIT-NOTICE.txt'])
source={p:pin(R/p) for p in sorted(paths)};payload={}
def add(name,p):
 assert name not in payload,name;payload[name]=p.read_bytes()
for name in source:add('source/'+name,R/name)
add('original-output-controls.zip',fixture)
for p in sorted(B.glob('source-*/src/*')):
 if p.is_file():add('upstream-source/'+p.relative_to(B).as_posix(),p)
for p in sorted((B/'audited-corpus-1').rglob('*')):
 if p.is_file() and ('audit' in p.relative_to(B/'audited-corpus-1').parts or p.name=='AUDIT-SUMMARY.json'):add('complete-audits/'+p.relative_to(B/'audited-corpus-1').as_posix(),p)
for name in ['FastpOutputControlMain.java','FastpOutputControlMain-before-se-adapter-fix.java.txt','capture_controls.py','output-controls-1.json','original-controls-1.stdout','original-controls-1.stderr','original-controls-1.observed.json','original-controls-2.stdout','original-controls-2.stderr','original-controls-2.observed.json','control-command.json','run_packaged.py','finalize.py','packaged-matrix.log']:add('development/'+name,B/name)
for folder in ['verification-1','packaged-tests-1']:
 for p in sorted((B/folder).rglob('*')):
  if p.is_file() and 'classes' not in p.relative_to(B/folder).parts:add('development/'+p.relative_to(B).as_posix(),p)
for p in sorted((R/'build/test-results/test').glob('TEST-*Fastp*.xml')):add('development/final-gradle-tests/'+p.name,p)
census={name:dict(bytes=len(raw),sha256=sha(raw)) for name,raw in sorted(payload.items())};payload['MANIFEST.json']=(json.dumps(census,indent=2)+'\n').encode()
archive=D/'fastp-output-audit-development-controls.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,raw in sorted(payload.items()):z.writestr(name,raw)
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(set(z.namelist()))==len(census)+1
 for name,expected in census.items():raw=z.read(name);assert dict(bytes=len(raw),sha256=sha(raw))==expected
summary=load(D/'omics-2023-2026/summary.json');assert summary['papers']==250 and summary['implementation_status_counts']['missing']==260
report=dict(schema_version=1,status='passed-scoped-fastp-complete-output-and-report-audit-development',artifact=dict(path=archive.name,**pin(archive)),source_pins=source,previous_frozen_sources_verified=old,original_control_evidence=capture,counts=matrix['corpus'],packaged_tests=matrix,gradle_tests=dict(total=total,passed=total-skipped,skipped=skipped,failed=0,suites=tests),python_tests=dict(total=619,passed=573,skipped=46,failed=0),prior_failed_attempts_preserved=True,canonical_executable_unchanged=canonical,catalog_pages_unchanged=True,checksum_files=578,checksum_manifests=8,new_scoped_integrations=60,native_scopes=13,upstream_adapters=47,named_tools_missing=260,fastp_catalog_status='missing',public_CLI_pending=True,complete_bundle_finalization_pending=True,whole_goal_complete=False,released_or_deployed=False,next_steps=['Connect typed public Java CLI and recipe to the validated captured-input/original/output stages.','Implement complete bundle finalization and portable replay;preserve all failure outcomes and warnings.','Apply seven reviewed paper roles and promote catalog only after scoped public workflow validation.'])
destination=D/'FASTP_OUTPUT_AUDIT_DEVELOPMENT_VALIDATION.json';assert not destination.exists();destination.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
checkpoint=R/'build/literature-review/fastp-runtime/current-checkpoint.json';(B/'checkpoint-before-output-audit.json').write_bytes(checkpoint.read_bytes());state=load(checkpoint);state.update(status=report['status'],validation='docs/literature/'+destination.name,current_guide='docs/literature/FASTP_OUTPUT_AUDIT_DEVELOPMENT.md',latest_evidence='build/literature-review/fastp-runtime/output-audit-1/final-audit.json',next_actions=report['next_steps'],resource_warning='P054 accuracy6 synthetic reported-option control completed at about24.05GiB sampledRSS;full biological workflow remains unreproduced. Never silently lower accuracy.',retained_original_runs=189,latest_original_corpus_runs=57,all_owned_processes_terminal=True,scientific_output_admission_pending=True,source_artifact=matrix['artifact'],source_artifact_sha256=matrix['artifact_sha256']);checkpoint.write_text(json.dumps(state,indent=2)+'\n',encoding='utf-8',newline='\n')
final=dict(status=report['status'],source_pins=len(source),archive_members=len(payload),artifact=report['artifact'],counts=matrix['corpus'],JVM_tests=327,python_tests=report['python_tests'],catalog_integrations=60,named_tools_missing=260,whole_goal_complete=False,released_or_deployed=False)
(B/'final-audit.json').write_text(json.dumps(final,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(final))
