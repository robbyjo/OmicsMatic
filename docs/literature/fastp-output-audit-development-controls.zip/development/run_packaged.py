from pathlib import Path
import concurrent.futures,hashlib,json,os,re,subprocess,zipfile
R=Path('D:/projects/JLinAlg'); B=R/'build/literature-review/fastp-runtime/output-audit-1'; O=B/'packaged-tests-1'; O.mkdir()
jar=B/'package-5/omicsmatic-0.3.7-fastp-development.jar'; libs=sorted((R/'build/literature-review/shapeit-runtime/owned-common-native-matrix-4/lib').glob('*.jar')); assert len(libs)==9
names=['org.jlinalg.sequence.FastpReadFilterTest',*[f'org.jlinalg.cli.{x}Test' for x in ['FastpFastq','FastpRuntime','FastpParameters','FastpProcess','FastpMetrics','FastpSort','FastpJoin','FastpOutputAudit']]]
runner=O/'RunFastpOutputChecks.java';runner.write_text('''import java.io.PrintWriter;
import org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder;
import org.junit.platform.launcher.core.LauncherFactory;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;
public final class RunFastpOutputChecks {
 private RunFastpOutputChecks() { }
 public static void main(String[] args) {
  var request=LauncherDiscoveryRequestBuilder.request().selectors(SELECTORS).build();
  var listener=new SummaryGeneratingListener();LauncherFactory.create().execute(request,listener);
  listener.getSummary().printTo(new PrintWriter(System.out));listener.getSummary().printFailuresTo(new PrintWriter(System.out));
  if(listener.getSummary().getTestsFailedCount()>0||listener.getSummary().getTestsFoundCount()!=327)System.exit(1);
 }
}
'''.replace('SELECTORS',','.join(f'selectClass("{name}")' for name in names)))
control=O/'FastpOutputAuditControlMain.java';control.write_text('''package org.jlinalg.cli;
import java.nio.file.*;
import java.util.*;
import java.util.zip.ZipFile;
public final class FastpOutputAuditControlMain {
 private FastpOutputAuditControlMain() { }
 public static void main(String[] args)throws Exception {
  Path root=Path.of(args[0]).toAbsolutePath().normalize();Files.createDirectory(root);FastpOutputAuditTest.temporary=root;
  var results=new ArrayList<Object>();long fields=0,constrained=0,input=0,represented=0,absent=0,corrected=0;
  try(var z=new ZipFile(args[1])){
   List<?> rows;try(var in=z.getInputStream(z.getEntry("CASES.json"))){rows=FastpMetrics.array(FastpRuntime.object(SimpleJson.parse(FastpFiles.utf8(in.readAllBytes()))).get("cases"));}
   for(Object row:rows){String name=FastpRuntime.text(FastpRuntime.object(row).get("path"));Path raw=FastpOutputAuditTest.extract(z,name);Path target=root.resolve(name);Files.createDirectories(target.getParent());Files.move(raw,target);
    var result=FastpOutputAudit.verify(FastpOutputAuditTest.data(target),target.resolve("audit"),FastpOutputAuditTest.limits(),()->{},()->{});results.add(Map.of("case",name,"result",result));fields+=result.independentlyRecomputedReportFields();constrained+=result.additionallyConstrainedReportFields();input+=result.conservation().inputReads();represented+=result.conservation().representedReads();absent+=result.conservation().unrepresentedReads();corrected+=result.conservation().visibleCorrectedBases();
   }
  }
  FastpFiles.writeJson(root.resolve("AUDIT-SUMMARY.json"),Map.of("cases",results,"independently_recomputed_fields",fields,"additionally_constrained_fields",constrained,"input_reads",input,"represented_reads",represented,"unrepresented_reads",absent,"visible_corrected_bases",corrected,"originals_rerun",false));
  System.out.println("Audited "+results.size()+" retained original cases;fields="+fields+";reads="+input);
 }
}
''')
classes=O/'classes';classes.mkdir();j='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin';cp=os.pathsep.join(map(str,[jar,*libs]));sources=[runner,control,*sorted((R/'src/test/java/org/jlinalg/cli').glob('Fastp*Test.java')),R/'src/test/java/org/jlinalg/sequence/FastpReadFilterTest.java']
compile_cmd=[j+'/javac.exe','--release','17','-Xlint:all','-Werror','-cp',cp,'-d',str(classes),*map(str,sources)]
with (O/'compile.stdout').open('xb') as out,(O/'compile.stderr').open('xb') as err:compiled=subprocess.run(compile_cmd,cwd=R,stdout=out,stderr=err,timeout=120)
assert compiled.returncode==0,(O/'compile.stderr').read_text()
linux=lambda p:'/mnt/d/'+p.relative_to(Path('D:/')).as_posix();entries=[classes,jar,R/'src/test/resources',*libs]
windows_cp=os.pathsep.join(map(str,entries));runs=[('windows-java21',[j+'/java.exe','-Xmx128m','-XX:ActiveProcessorCount=2','-cp',windows_cp,'RunFastpOutputChecks'],310,17),('windows-java25',['C:/Program Files/Common Files/Oracle/Java/javapath/java.exe','-Xmx128m','-XX:ActiveProcessorCount=2','-cp',windows_cp,'RunFastpOutputChecks'],310,17),('linux-java21',['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','env','JLINALG_FASTP_MANAGED_ROOT=/opt/omicsmatic-fastp-managed-1','/usr/bin/java','-Xmx128m','-XX:ActiveProcessorCount=2','-cp',':'.join(map(linux,entries)),'RunFastpOutputChecks'],327,0)]
def execute(row):
 name,cmd,passed,aborted=row
 with (O/(name+'.stdout')).open('xb') as out,(O/(name+'.stderr')).open('xb') as err:p=subprocess.run(cmd,cwd=R,stdout=out,stderr=err,timeout=1200)
 record=dict(name=name,command=cmd,exit_code=p.returncode,tests_found=327,expected_passed=passed,expected_aborted_platform_controls=aborted);(O/(name+'.observed.json')).write_text(json.dumps(record,indent=2)+'\n')
 text=(O/(name+'.stdout')).read_text(errors='replace');assert p.returncode==0,(name,text[-4000:])
 for count,label in [(327,'tests found'),(passed,'tests successful'),(0,'tests failed'),(aborted,'tests aborted')]:assert re.search(r'\[\s*'+str(count)+' '+label+r'\s*\]',text),(name,label,text[-4000:])
 print(name,'passed',passed,'platform-aborted',aborted,flush=True);return record
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:observed=list(pool.map(execute,runs))
control_cmd=[j+'/java.exe','-Xmx128m','-XX:ActiveProcessorCount=2','-cp',windows_cp,'org.jlinalg.cli.FastpOutputAuditControlMain',str(B/'audited-corpus-1'),str(R/'src/test/resources/org/jlinalg/cli/fastp-output/original-output-controls.zip')]
with (O/'corpus.stdout').open('xb') as out,(O/'corpus.stderr').open('xb') as err:p=subprocess.run(control_cmd,cwd=R,stdout=out,stderr=err,timeout=600)
assert p.returncode==0,(O/'corpus.stderr').read_text();corpus=json.loads((B/'audited-corpus-1/AUDIT-SUMMARY.json').read_bytes());assert len(corpus['cases'])==57
record=dict(status='passed-actual-JAR-fastp-complete-output-audit-matrix',tests_found_per_JVM=327,runs=observed,artifact=jar.relative_to(R).as_posix(),artifact_sha256=hashlib.sha256(jar.read_bytes()).hexdigest(),heap_mib=128,strict_Java_release=17,original_stage_scientific_protocols_rerun=False,new_original_cases=57,corpus={k:v for k,v in corpus.items() if k!='cases'})
(O/'summary.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record['corpus']))
