package org.jlinalg.cli;
import java.nio.file.*;
import java.util.*;
import java.util.zip.ZipFile;
public final class FastpOutputAuditControlMain {
 private FastpOutputAuditControlMain() { }
 public static void main(String[] args)throws Exception {
  Path root=Path.of(args[0]).toAbsolutePath().normalize();Files.createDirectory(root);FastpOutputAuditTest.temporary=root;
  var results=new ArrayList<Object>();long fields=0,constrained=0,input=0,represented=0,absent=0,corrected=0;
  try(var z=new ZipFile(args[1])){
   List<?> rows;try(var in=z.getInputStream(z.getEntry("CASES.json"))){rows=FastpMetrics.array(FastpRuntime.object(SimpleJson.parse(FastpFiles.utf8(in.readAllBytes()))).get("cases"));}
   for(Object row:rows){String name=FastpRuntime.text(FastpRuntime.object(row).get("path"));Path raw=FastpOutputAuditTest.extract(z,name);Path target=root.resolve(name);Files.createDirectories(target.getParent());Files.move(raw,target);
    var result=FastpOutputAudit.verify(FastpOutputAuditTest.data(target),target.resolve("audit"),FastpOutputAuditTest.limits(),()->{},()->{});results.add(Map.of("case",name,"result",result));fields+=result.independentlyRecomputedReportFields();constrained+=result.additionallyConstrainedReportFields();input+=result.conservation().inputReads();represented+=result.conservation().representedReads();absent+=result.conservation().unrepresentedReads();corrected+=result.conservation().visibleCorrectedBases();
   }
  }
  FastpFiles.writeJson(root.resolve("AUDIT-SUMMARY.json"),Map.of("cases",results,"independently_recomputed_fields",fields,"additionally_constrained_fields",constrained,"input_reads",input,"represented_reads",represented,"unrepresented_reads",absent,"visible_corrected_bases",corrected,"originals_rerun",false));
  System.out.println("Audited "+results.size()+" retained original cases;fields="+fields+";reads="+input);
 }
}
