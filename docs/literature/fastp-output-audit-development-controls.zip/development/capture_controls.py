from pathlib import Path
import hashlib,json,zipfile
O=Path('/opt/omicsmatic-fastp-output-controls-1');S=Path('/mnt/d/projects/JLinAlg/build/literature-review/fastp-runtime/output-audit-1');sha=lambda raw:hashlib.sha256(raw).hexdigest();manifest={};cases=[]
for receipt in sorted(O.rglob('control.json')):
 record=json.loads(receipt.read_bytes());assert record['exit_code']==0 and record['owned_live_after_cleanup']==[];case=receipt.parent.relative_to(O).as_posix();cases.append(dict(path=case,version=record['version'],name=record['case']))
assert len(cases)==57
for p in sorted(O.rglob('*')):
 assert not p.is_symlink()
 if p.is_file():raw=p.read_bytes();manifest[p.relative_to(O).as_posix()]=dict(bytes=len(raw),sha256=sha(raw))
target=S/'output-controls-1.zip';assert not target.exists()
summary=dict(status='captured-original-outputs-scientific-audit-pending',completed_original_controls=57,prior_rejected_fixture_preserved=True,cases=cases,files=len(manifest),all_owned_processes_terminal=True,high_memory_reported_P054_options_executed=True)
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
 for name in manifest:z.write(O/name,name)
 z.writestr('CAPTURE-MANIFEST.json',json.dumps(manifest,indent=2)+'\n');z.writestr('CASES.json',json.dumps(summary,indent=2)+'\n')
(S/'output-controls-1.json').write_text(json.dumps(dict(**summary,artifact=dict(path=target.name,bytes=target.stat().st_size,sha256=sha(target.read_bytes()))),indent=2)+'\n');print('Captured',len(cases),'complete controls including the unchanged resumed case;all raw files retained.')
