import hashlib,json,struct,sys
from pathlib import Path
import pyBigWig
file=Path(sys.argv[1])/'native-controls/unsigned32-coordinates/native.bw'
with pyBigWig.open(str(file)) as bw:
    print(json.dumps(dict(native_sha256=hashlib.sha256(file.read_bytes()).hexdigest(),module=pyBigWig.__file__,dictionary=bw.chroms(),original_intervals=bw.intervals('huge'),header=bw.header()),indent=2),flush=True)
