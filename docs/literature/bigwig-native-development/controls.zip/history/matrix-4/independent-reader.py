
import hashlib,json,math,struct,sys
from pathlib import Path
import pyBigWig
root=Path(sys.argv[1]);assert pyBigWig.__version__=='0.3.26';assert hashlib.sha256(Path(pyBigWig.__file__).read_bytes()).hexdigest()=='e8ffa2730b27c762870d27e3ed51b89d3b84d263099eac2cc7fca505767041df'
cases=json.loads((root/'native-controls/CONTROLS.json').read_bytes())['cases'];results=[]
def f32(value):return struct.unpack('<f',struct.pack('<f',float(value)))[0]
def fingerprint(rows):
 digest=hashlib.sha256()
 for chrom,start,end,value in rows:
  name=chrom.encode();digest.update(struct.pack('<I',len(name)));digest.update(name);digest.update(struct.pack('<QQf',start,end,value))
 return digest.hexdigest()
def summary(path):
 with path.open('rb') as stream:
  head=stream.read(64);offset=struct.unpack_from('<Q',head,44)[0];stream.seek(offset);raw=stream.read(40)
 values=struct.unpack('<Qdddd',raw);names=['covered_bases','minimum','maximum','sum','sum_squares']
 return dict(raw_hex=raw.hex(),fields={k:(repr(v) if isinstance(v,float) and not math.isfinite(v) else v) for k,v in zip(names,values)})
for case in cases:
 folder=root/'native-controls'/case['id'];rows=[]
 for line in (folder/'signal.bedGraph').read_text().splitlines():
  c,a,b,v=line.split('\t');rows.append((c,int(a),int(b),f32(v)))
 rows.sort(key=lambda r:(r[0].encode(),r[1],r[2]));expected=fingerprint(rows);dictionary=case['report']['dictionary']
 with pyBigWig.open(str(folder/'native.bw')) as bw:
  assert bw.isBigWig() and bw.chroms()==dictionary,(case['id'],'dictionary')
  actual=[];signed_coordinate_views=[]
  for chrom in sorted(dictionary,key=lambda c:c.encode()):
   for start,end,value in bw.intervals(chrom) or []:
    if start<0 or end<0:
     assert case['id']=='unsigned32-coordinates' and -2147483648<=start<=2147483647 and -2147483648<=end<=2147483647
     signed_coordinate_views.append(dict(chromosome=chrom,original_signed_start=start,original_signed_end=end,format_unsigned_start=start&0xffffffff,format_unsigned_end=end&0xffffffff));start,end=start&0xffffffff,end&0xffffffff
    actual.append((chrom,start,end,value))
  assert len(actual)==len(rows) and fingerprint(actual)==expected,(case['id'],'raw values')
  decoded=[]
  for line in (root/'original-controls'/case['id']/'native-decoded.bedGraph').read_text().splitlines():
   chrom,start,end,_=line.split('\t');decoded.append((chrom,int(start),int(end)))
  assert decoded==[(c,a,b) for c,a,b,_ in rows],(case['id'],'complete UCSC-decoded unsigned coordinates')
  count=sum(b-a for _,a,b,_ in rows);weighted=math.fsum((b-a)*float(v) for _,a,b,v in rows);squares=math.fsum((b-a)*float(v)*float(v) for _,a,b,v in rows);native=case['report']
  assert count==native['coveredBases']
  for key,value in [('sum',weighted),('sumSquares',squares)]:assert math.isclose(native[key],value,rel_tol=2e-15,abs_tol=1e-300),(case['id'],key,native[key],value)
  header=bw.header();assert header['nLevels']==0 and header['nBasesCovered']==count
  # libBigWig exposes some total-summary fields as Python ints; retain its original header literally.
  native_header=header
 original=root/'original-controls'/case['id']/'original.bw';processes=json.loads((original.parent/'processes.json').read_bytes());conversion=next(r for r in processes if r['label']=='convert');comparison=dict(original_conversion_exit=conversion['exit_code'],original_conversion_timed_out=conversion['timed_out'])
 if conversion['exit_code']==0:
  with pyBigWig.open(str(original)) as bw:
   original_rows=[]
   for chrom in sorted(bw.chroms(),key=lambda c:c.encode()):
    for start,end,value in bw.intervals(chrom) or []:original_rows.append((chrom,start,end,value))
   assert len(original_rows)==len(rows) and fingerprint(original_rows)==expected,(case['id'],'original converter raw values');comparison.update(original_raw_float32_exact=True,original_dictionary=bw.chroms(),original_stored_total_summary=summary(original))
   if any(isinstance(v,str) for v in comparison['original_stored_total_summary']['fields'].values()):comparison['original_header_unavailable']='Observed pinned Cygwin pyBigWig0.3.26 header() segmentation fault on this original nonfinite summary. The complete raw float32 interval family is still independently verified; exact raw IEEE summary bytes and nonfinite values are retained. Native double summary remains finite.'
   else:
    try:comparison['original_header']=bw.header()
    except (OverflowError,ValueError) as failure:comparison['original_header_unavailable']=str(failure)
   source_fields=comparison['original_stored_total_summary']['fields'];native_fields=summary(folder/'native.bw')['fields'];comparison['total_summary_differences']=[dict(field=k,native=v,original=source_fields[k]) for k,v in native_fields.items() if v!=source_fields[k]]
 results.append(dict(id=case['id'],complete_records=len(rows),exact_float32_fingerprint=expected,original_pyBigWig_signed_coordinate_views=signed_coordinate_views,complete_UCSC_unsigned_coordinates_exact=True,native_header=native_header,native_stored_total_summary=summary(folder/'native.bw'),native_summary=native,comparison=comparison))
(root/'INDEPENDENT-READERS.json').write_text(json.dumps(dict(status='passed-every-native-and-successful-original-interval-through-pinned-pyBigWig',version=pyBigWig.__version__,module=pyBigWig.__file__,module_sha256=hashlib.sha256(Path(pyBigWig.__file__).read_bytes()).hexdigest(),cases=results),indent=2,allow_nan=False)+'\n');print('Exact independent float32 records:',sum(r['complete_records'] for r in results),'in',len(results),'protocols',flush=True)
