from pathlib import Path
root=Path(__file__).resolve().parent
target=root/'debug-independent-reader-1.py'
assert not target.exists()
source=(root/'independent-reader.py').read_text()
source='import faulthandler; faulthandler.enable()\n'+source
source=source.replace('for case in cases:', 'for case in cases:\n print("START",case["id"],flush=True)')
source=source.replace('  header=bw.header();', '  print("NATIVE_HEADER",case["id"],flush=True); header=bw.header();')
source=source.replace("   try:comparison['original_header']=bw.header()", "   try:\n    print('ORIGINAL_HEADER',case['id'],flush=True); comparison['original_header']=bw.header()")
source=source.replace("root/'INDEPENDENT-READERS.json'", "root/'INDEPENDENT-READERS-debug-1.json'")
target.write_text(source,encoding='utf-8')
