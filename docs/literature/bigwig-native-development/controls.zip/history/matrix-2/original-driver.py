
import hashlib,json,os,subprocess,sys
from pathlib import Path
root,tools=map(Path,sys.argv[1:]);cases=json.loads((root/'native-controls/CONTROLS.json').read_bytes())['cases'];records=[]
def pin(path):return dict(bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
before={p.name:pin(p) for p in tools.iterdir() if p.is_file()};(root/'original-controls').mkdir(mode=0o700)
for spec in cases:
 name=spec['id'];source=root/'native-controls'/name;out=root/'original-controls'/name;out.mkdir(mode=0o700);runs=[]
 commands=[('convert',[str(tools/'bedGraphToBigWig'),'-itemsPerSlot='+str(spec['options']['itemsPerSection']),'-blockSize='+str(spec['options']['treeFanout']),*(['-unc'] if not spec['options']['compressed'] else []),str(source/'signal.bedGraph'),str(source/'reference.sizes'),str(out/'original.bw')]),('read-native',[str(tools/'bigWigToBedGraph'),str(source/'native.bw'),str(out/'native-decoded.bedGraph')]),('native-info',[str(tools/'bigWigInfo'),'-chroms','-zooms',str(source/'native.bw')])]
 for label,command in commands:
  with (out/(label+'.stdout')).open('xb') as stdout,(out/(label+'.stderr')).open('xb') as stderr:
   try:r=subprocess.run(command,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=30);row=dict(label=label,command=command,exit_code=r.returncode,timed_out=False)
   except subprocess.TimeoutExpired:row=dict(label=label,command=command,exit_code=None,timed_out=True)
  runs.append(row)
  if label!='convert':assert row['exit_code']==0 and not row['timed_out'],(name,label,row)
  elif row['exit_code']!=0:assert name in ['empty-declared-track','unsigned32-coordinates'],(name,row)
 (out/'processes.json').write_text(json.dumps(runs,indent=2)+'\n');records.append(dict(id=name,runs=runs))
assert {p.name:pin(p) for p in tools.iterdir() if p.is_file()}==before
(root/'ORIGINAL-CONTROLS.json').write_text(json.dumps(dict(status='completed-original-UCSC-native-file-read-and-converter-probes',tool_pins=before,cases=records),indent=2)+'\n')
print('Original UCSC read every native file:',len(records),flush=True)
