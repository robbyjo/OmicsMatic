from pathlib import Path
OUT=Path(__file__).resolve().parent;PRIOR=OUT.parent/'velociraptor-native-grid-project-check-1'
source=(PRIOR/'prepare.py').read_text()
assert source.count("CHECKOUT=OUT/'checkout'")==1
source=source.replace("CHECKOUT=OUT/'checkout'","CHECKOUT=ROOT/'build/vg120-check-1'")
source=source.replace("['git','-c','core.autocrlf=false','worktree'","['git','-c','core.longpaths=true','-c','core.autocrlf=false','worktree'")
(OUT/'prepare-short.py').write_bytes(source.encode())
(OUT/'PRIOR-WINDOWS-PATH-FAILURE.txt').write_text('The first fresh checkout terminated with Git exit128: Windows Filename too long for existing PRS-CS fixtures. Git automatically removed that failed fresh checkout before any candidate files were copied. All raw logs remain in project-check-1. This attempt uses the new shorter workspace path D:/projects/JLinAlg/build/vg120-check-1 and a command-local longpaths override. No original worktree was reset, moved or deleted.\n')
exec(compile(source,str(OUT/'prepare-short.py'),'exec'))
