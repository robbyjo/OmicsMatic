from pathlib import Path
import hashlib,json,os,subprocess,time,traceback,xml.etree.ElementTree as ET,zipfile
ROOT=Path('D:/projects/JLinAlg');OUT=Path(__file__).resolve().parent;CHECKOUT=ROOT/'build/vg120-check-1'
def pin(path):
 h=hashlib.sha256();size=0
 with path.open('rb') as stream:
  for data in iter(lambda:stream.read(1048576),b''):h.update(data);size+=len(data)
 return dict(bytes=size,sha256=h.hexdigest())
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
try:
 sources=json.loads((OUT/'SOURCE-PINS.json').read_bytes());before=json.loads((ROOT/'build/git-merge/20261114-scvelo-sync-1/BEFORE.json').read_bytes())
 for name,wanted in sources.items():assert pin(ROOT/name)==wanted and pin(CHECKOUT/name)==wanted,name
 for row in before['files']:assert pin(ROOT/row['path'])==dict(bytes=row['size'],sha256=row['sha256']),row['path']
 dependency=ROOT/'build/dependencies/jdistlib-all-0.10.2.jar';target=CHECKOUT/'build/dependencies/jdistlib-all-0.10.2.jar'
 if dependency.is_file():
  import shutil
  assert pin(dependency)['sha256']=='8b50aaa11d2cbd512525e0d74f8e609f40db9f4fc179ccb7a885a82257e0ac81'
  target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists();shutil.copyfile(dependency,target);assert pin(target)==pin(dependency)
 env=dict(os.environ,JAVA_HOME='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot')
 command=[str(CHECKOUT/'gradlew.bat'),'test','--tests','org.jlinalg.singlecell.VelociraptorGrid120Test','jar','--no-daemon','--no-parallel','--no-configuration-cache','--max-workers=2','--console=plain']
 start=time.time()
 with (OUT/'gradle.stdout').open('xb') as so,(OUT/'gradle.stderr').open('xb') as se:
  child=subprocess.Popen(command,cwd=CHECKOUT,env=env,stdin=subprocess.DEVNULL,stdout=so,stderr=se);save('LIVE.json',dict(pid=child.pid,command=command,started_unix=start));code=child.wait()
 save('TERMINAL.json',dict(command=command,exit_code=code,elapsed_seconds=time.time()-start));assert code==0
 xml=CHECKOUT/'build/test-results/test/TEST-org.jlinalg.singlecell.VelociraptorGrid120Test.xml';results=ET.fromstring(xml.read_bytes())
 assert int(results.get('tests'))==3 and int(results.get('failures'))==0 and int(results.get('errors'))==0
 jars=[path for path in (CHECKOUT/'build/libs').glob('*.jar') if not any(value in path.name for value in ['sources','javadoc','benchmark'])]
 assert len(jars)==1,jars
 jar=jars[0]
 with zipfile.ZipFile(jar) as archive:
  assert 'org/jlinalg/singlecell/VelociraptorGrid120.class' in archive.namelist()
  assert archive.read('META-INF/LICENSE-velociraptor120.txt')==(ROOT/'src/main/resources/META-INF/LICENSE-velociraptor120.txt').read_bytes()
 for name,wanted in sources.items():assert pin(ROOT/name)==wanted and pin(CHECKOUT/name)==wanted,name
 for row in before['files']:assert pin(ROOT/row['path'])==dict(bytes=row['size'],sha256=row['sha256']),row['path']
 save('COMPLETED.json',dict(status='PASS_ISOLATED_PROJECT_NATIVE_GRID_TESTS_AND_LIBRARY_JAR_PACKAGING',tests=3,failures=0,errors=0,original_R_reference_cases=31,full_scalar_comparisons=20331,library_JAR=dict(path=str(jar),**pin(jar)),original_MIT_notice_packaged_byte_exact=True,protected_root_paths_unchanged=len(before['files']),canonical_cli_JAR_unchanged=True,root_Gradle_run=False,new_family_implementation_credit=0,whole_goal_complete=False));print('PASS_ISOLATED_NATIVE_GRID_PROJECT_TESTS_AND_PACKAGING',flush=True)
except BaseException as error:
 save('FAILURE.json',dict(status='FAIL2_ISOLATED_NATIVE_GRID_PROJECT_CHECK_UNADMITTED',cause=repr(error),traceback=traceback.format_exc(),new_tool_credit=0));raise
