from pathlib import Path
import hashlib,json,shutil,subprocess,time
ROOT=Path('D:/projects/JLinAlg');OUT=Path(__file__).resolve().parent;CHECKOUT=ROOT/'build/vg120-check-1'
FILES=['src/main/java/org/jlinalg/singlecell/VelociraptorGrid120.java','src/main/resources/META-INF/LICENSE-velociraptor120.txt','src/test/java/org/jlinalg/singlecell/VelociraptorGrid120Test.java','src/test/resources/velociraptor-grid120-reference.zip']
def pin(path):
 h=hashlib.sha256();size=0
 with path.open('rb') as stream:
  for data in iter(lambda:stream.read(1048576),b''):h.update(data);size+=len(data)
 return dict(bytes=size,sha256=h.hexdigest())
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip();assert commit=='4bf762fe03f0be3eaf03d70909408bda6770262c'
before={name:pin(ROOT/name) for name in FILES};save('SOURCE-PINS.json',before)
command=['git','-c','core.longpaths=true','-c','core.autocrlf=false','worktree','add','--detach',str(CHECKOUT),commit];start=time.time()
with (OUT/'worktree.stdout').open('xb') as so,(OUT/'worktree.stderr').open('xb') as se:child=subprocess.run(command,cwd=ROOT,stdin=subprocess.DEVNULL,stdout=so,stderr=se)
save('WORKTREE-TERMINAL.json',dict(command=command,exit_code=child.returncode,elapsed_seconds=time.time()-start));assert child.returncode==0
for name,wanted in before.items():
 target=CHECKOUT/name;assert not target.exists(),name
 target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/name,target);assert pin(target)==wanted and pin(ROOT/name)==wanted,name
save('PREPARED.json',dict(status='EXACT_FOUR_NATIVE_COMPONENT_FILES_IN_NEW_ISOLATED_COMMITTED_BASE',commit=commit,checkout=str(CHECKOUT),source_pins=before,main_worktree_Gradle_run=False))
print('PREPARED_EXACT_ISOLATED_NATIVE_GRID_PROJECT_CHECK',flush=True)
