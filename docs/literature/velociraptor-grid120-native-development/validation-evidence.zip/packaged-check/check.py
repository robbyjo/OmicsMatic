from pathlib import Path
import hashlib,json,os,shutil,subprocess,time,traceback
ROOT=Path('D:/projects/JLinAlg');BASE=ROOT/'build/literature-review/monocle-runtime';OUT=Path(__file__).resolve().parent;JDK=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin')
def pin(path):
 h=hashlib.sha256();size=0
 with path.open('rb') as stream:
  for data in iter(lambda:stream.read(1048576),b''):h.update(data);size+=len(data)
 return dict(bytes=size,sha256=h.hexdigest())
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
processes=[]
def run(label,command):
 command=list(map(str,command));start=time.time()
 with (OUT/(label+'.stdout')).open('xb') as so,(OUT/(label+'.stderr')).open('xb') as se:child=subprocess.run(command,cwd=ROOT,stdin=subprocess.DEVNULL,stdout=so,stderr=se)
 row=dict(label=label,command=command,exit_code=child.returncode,elapsed_seconds=time.time()-start);processes.append(row);save('PROCESSES.json',processes);assert child.returncode==0,label
try:
 project=json.loads((BASE/'velociraptor-native-grid-project-check-2/COMPLETED.json').read_bytes());assert project['status']=='PASS_ISOLATED_PROJECT_NATIVE_GRID_TESTS_AND_LIBRARY_JAR_PACKAGING'
 jar=Path(project['library_JAR']['path']);assert pin(jar)=={k:project['library_JAR'][k] for k in ['bytes','sha256']}
 probes=OUT/'probe-only-classes';probes.mkdir(exist_ok=False)
 for source in (BASE/'velociraptor-native-grid-java-1/classes').glob('*.class'):shutil.copyfile(source,probes/source.name)
 assert not (probes/'org').exists()
 classpath=str(jar)+os.pathsep+str(probes)
 run('packaged-native-controls',[JDK/'java.exe','-verbose:class','-cp',classpath,'VelociraptorGrid120Controls'])
 text=(OUT/'packaged-native-controls.stdout').read_text(encoding='utf-8',errors='replace')
 origin=[line for line in text.splitlines() if 'org.jlinalg.singlecell.VelociraptorGrid120 source:' in line]
 assert len(origin)==1 and jar.as_posix().lower() in origin[0].replace('\\','/').lower(),origin
 assert 'PASS_NATIVE_GRID_GUARDS_AND_INPUT_IMMUTABILITY checks=31' in text
 reference=BASE/'velociraptor-native-grid-binary-2';case=json.loads((reference/'INDEX.json').read_bytes())['cases'][0];target=OUT/'packaged-case'
 run('packaged-native-example',[JDK/'java.exe','-cp',classpath,'VelociraptorGrid120Probe',reference/case['directory'],target,case['resolution'],str(case['scale']).lower()])
 for source in (BASE/'velociraptor-native-grid-java-1/results'/case['directory']).glob('*.bin'):assert (target/source.name).read_bytes()==source.read_bytes(),source.name
 assert json.loads((target/'RESULT.json').read_bytes())==json.loads((BASE/'velociraptor-native-grid-java-1/results'/case['directory']/'RESULT.json').read_bytes())
 before=json.loads((ROOT/'build/git-merge/20261114-scvelo-sync-1/BEFORE.json').read_bytes())
 for row in before['files']:assert pin(ROOT/row['path'])==dict(bytes=row['size'],sha256=row['sha256']),row['path']
 save('COMPLETED.json',dict(status='PASS_PACKAGED_LIBRARY_JAR_NATIVE_GRID_CLASS_ORIGIN_CONTROLS_AND_COMPLETE_EXAMPLE',library_JAR=project['library_JAR'],class_origin_line=origin[0],native_control_checks=31,complete_example_output_fields=9,original_R_goldens_checked_in_project_test=31,root_protected_paths_unchanged=len(before['files']),canonical_cli_JAR_unchanged=True,release_published=False,new_family_implementation_credit=0,whole_R_wrapper_adapter_qualified=False,whole_goal_complete=False));print('PASS_PACKAGED_NATIVE_GRID_CLASS_ORIGIN_AND_CONTROLS',flush=True)
except BaseException as error:
 save('FAILURE.json',dict(status='FAIL2_PACKAGED_NATIVE_GRID_CHECK_UNADMITTED',cause=repr(error),traceback=traceback.format_exc(),new_tool_credit=0));raise
