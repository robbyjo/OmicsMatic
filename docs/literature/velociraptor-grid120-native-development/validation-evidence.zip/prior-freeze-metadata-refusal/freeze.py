from pathlib import Path
import hashlib,json,zipfile
ROOT=Path('D:/projects/JLinAlg');BASE=ROOT/'build/literature-review/monocle-runtime';OUT=Path(__file__).resolve().parent;DEST=ROOT/'docs/literature/velociraptor-grid120-native-development'
SOURCES=['src/main/java/org/jlinalg/singlecell/VelociraptorGrid120.java','src/main/resources/META-INF/LICENSE-velociraptor120.txt','src/test/java/org/jlinalg/singlecell/VelociraptorGrid120Test.java','src/test/resources/velociraptor-grid120-reference.zip','tools/literature/java/VelociraptorGrid120Probe.java','tools/literature/java/VelociraptorGrid120Controls.java','docs/literature/VELOCIRAPTOR_GRID120_NATIVE.md']
def identity(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def pin(path):return identity(path.read_bytes())
def save(path,value):path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n',encoding='utf-8')
math=json.loads((BASE/'velociraptor-native-grid-java-1/COMPLETED.json').read_bytes());project=json.loads((BASE/'velociraptor-native-grid-project-check-2/COMPLETED.json').read_bytes());packaged=json.loads((BASE/'velociraptor-native-grid-packaged-check-1/COMPLETED.json').read_bytes());repeat=json.loads((BASE/'velociraptor-grid-stack-diagnostic-1/COMPLETED.json').read_bytes())
assert math['cases']==31 and math['maximum_absolute_error']==0 and project['tests']==3 and packaged['native_control_checks']==31 and repeat['original_value_cases']==31
DEST.mkdir(exist_ok=False)
(DEST/'.gitattributes').write_bytes(b'* -text whitespace=cr-at-eol\n')
sources={name:pin(ROOT/name) for name in SOURCES}
old=json.loads((BASE/'velociraptor-native-grid-java-1/SOURCE-PINS.json').read_bytes())
for name,wanted in old.items():assert sources[name]==wanted,name
files={}
def add(name,path):
 raw=path.read_bytes();assert name not in files;files[name]=raw
def folder(prefix,path,skip=()):
 for item in sorted(path.rglob('*')):
  relative=item.relative_to(path)
  if any(part in skip for part in relative.parts):continue
  if item.is_symlink():raise ValueError('Unexpected evidence link: '+str(item))
  if item.is_file():add(prefix+'/'+relative.as_posix(),item)
folder('native-comparison',BASE/'velociraptor-native-grid-java-1')
for name in ['prepare.py','SOURCE-PINS.json','worktree.stdout','worktree.stderr','WORKTREE-TERMINAL.json']:
 add('prior-Windows-path-refusal/'+name,BASE/'velociraptor-native-grid-project-check-1'/name)
folder('project-check',BASE/'velociraptor-native-grid-project-check-2')
folder('packaged-check',BASE/'velociraptor-native-grid-packaged-check-1')
folder('original-namespace-diagnostic',BASE/'velociraptor-grid-stack-diagnostic-1')
jar=Path(project['library_JAR']['path']);assert pin(jar)=={key:project['library_JAR'][key] for key in ['bytes','sha256']};add('library-JAR/'+jar.name,jar)
results=ROOT/'build/vg120-check-1/build/test-results/test/TEST-org.jlinalg.singlecell.VelociraptorGrid120Test.xml'
add('project-test-results/VelociraptorGrid120Test.xml',results)
for name in SOURCES:
 if name.endswith('.zip'):continue
 add('executed-source-snapshot/'+name,ROOT/name)
archive=DEST/'validation-evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as output:
 for name,raw in sorted(files.items()):
  info=zipfile.ZipInfo(name,(2000,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;output.writestr(info,raw)
with zipfile.ZipFile(archive) as output:
 assert set(output.namelist())==set(files)
 for name,raw in files.items():assert output.read(name)==raw,name
members={name:identity(raw) for name,raw in sorted(files.items())};save(DEST/'EVIDENCE_MEMBERS.json',dict(schema_version=1,members=members))
scope=dict(status='VALIDATED_SCOPED_NATIVE_VELOCIRAPTOR120_GRID_COMPONENT_NOT_R_WRAPPER_ADMISSION',source_version='1.20.0',scope='Two-dimensional finite coordinates/vectors, nondegenerate finite axes, positive integer resolution and nonoverflowing group sums/scaled lengths. Every supplied row retained. Original first-match labels, gaps, categories, all arithmetic fields and computed NaN/Inf classes preserved.',role='Summarize supplied projected velocity vectors into occupied plotting bins. Does not fit velocity or latent time; no P228 grid use/author settings inferred.',native_source_modified_original_algorithms=False,whole_R_wrapper_adapter_qualified=False,new_family_implementation_credit=0,whole_goal_complete=False)
save(DEST/'SCOPE.json',scope)
proof=dict(schema_version=1,status='PASS_SCOPED_NATIVE_JAVA_GRID31_FULL_ORIGINAL_R_CASES_PROJECT_AND_PACKAGED_JAR',sources=sources,fixture=sources['src/test/resources/velociraptor-grid120-reference.zip'],evidence=pin(archive),evidence_members=pin(DEST/'EVIDENCE_MEMBERS.json'),scope=pin(DEST/'SCOPE.json'),native_math=math,project=project,packaged=packaged,original_repetition=repeat,source_fixture_cases=31,full_output_fields=279,full_scalar_comparisons=20331,original_R_namespace_stack_diagnostic_review_required=True,original_native_C_cause_resolved=False,raw_console_diagnostic_counts_complete=False,biological_or_paper_validation_claimed=False,new_family_implementation_credit=0,whole_R_wrapper_adapter_qualified=False,whole_goal_complete=False)
save(DEST/'VALIDATION.json',proof)
(DEST/'README.md').write_text('''# Native velocity-grid component checkpoint

This dossier qualifies only the documented finite two-dimensional native Java
grid arithmetic against31 full original R controls. Read SCOPE.json, the linked
VELOCIRAPTOR_GRID120_NATIVE.md guide, the frozen source fixture and VALIDATION.json.
It grants zero catalog family credit and does not qualify the R RNA-velocity
wrapper, latent time, convergence, biological interpretation or a paper result.

All279 arithmetic fields/20,331 values were checked. The isolated project tests,
library JAR packaging, actual packaged class origin and guard/example checks
passed. The canonical CLI JAR and24 pre-existing protected root paths remained
unchanged. No release or GitHub push is part of this checkpoint.

WARNING REVIEW REQUIRED: The original R reference emitted a native stack-
imbalance diagnostic. A fresh stage-marked probe localized it to namespace
loading and reproduced all31 complete original grid results with strict R-value
equality. The underlying native cause remains unresolved. Full original logs,
conditions, repeated results, actual binaries, source snapshots and earlier
Windows-path refusal logs remain retained. Delivered R condition counts are not
universal raw-console diagnostic totals; unknown totals are not reported as zero.

The test fixture contains all341 original binary input/intermediate fields,
complete original RDS objects, source archive/lock/producer code and refused
exporter history. validation-evidence.zip contains all31 complete native outputs,
execution logs, project XML, the library JAR and packaged-origin checks.
EVIDENCE_MEMBERS.json covers every evidence archive member. SHA-256 establishes
integrity, not authenticity. Existing failed/historical proofs were not rewritten.
''',encoding='utf-8')
names=['.gitattributes','README.md','SCOPE.json','VALIDATION.json','EVIDENCE_MEMBERS.json','validation-evidence.zip']
(DEST/'SHA256SUMS').write_text(''.join(pin(DEST/name)['sha256']+'  '+name+'\n' for name in names),encoding='ascii')
for name,wanted in sources.items():assert pin(ROOT/name)==wanted,name
save(OUT/'COMPLETED.json',dict(status=proof['status'],destination=str(DEST),evidence=proof['evidence'],members=len(members),source_files=len(sources),new_family_implementation_credit=0,whole_goal_complete=False));print('FROZEN_NATIVE_GRID_EVIDENCE',len(members),'members',proof['evidence']['bytes'],'bytes',flush=True)
