from pathlib import Path
import hashlib,json,math,os,struct,subprocess,time,traceback
ROOT=Path('D:/projects/JLinAlg');BASE=ROOT/'build/literature-review/monocle-runtime';OUT=BASE/'velociraptor-native-grid-java-1';REFERENCE=BASE/'velociraptor-native-grid-binary-2'
JDK=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin')
SOURCES=[ROOT/'src/main/java/org/jlinalg/singlecell/VelociraptorGrid120.java',ROOT/'tools/literature/java/VelociraptorGrid120Probe.java',ROOT/'tools/literature/java/VelociraptorGrid120Controls.java',ROOT/'src/main/resources/META-INF/LICENSE-velociraptor120.txt']
def pin(path):
 h=hashlib.sha256();size=0
 with path.open('rb') as stream:
  for data in iter(lambda:stream.read(1048576),b''):h.update(data);size+=len(data)
 return dict(bytes=size,sha256=h.hexdigest())
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n',encoding='utf-8')
processes=[]
def run(label,command):
 command=list(map(str,command));start=time.time()
 with (OUT/(label+'.stdout')).open('xb') as so,(OUT/(label+'.stderr')).open('xb') as se:child=subprocess.run(command,cwd=ROOT,stdin=subprocess.DEVNULL,stdout=so,stderr=se)
 row=dict(label=label,command=command,exit_code=child.returncode,elapsed_seconds=time.time()-start);processes.append(row);save('PROCESSES.json',processes)
 if child.returncode:raise RuntimeError('Native validation failed at '+label+'; preserve full console, original references and all partial results')
 return row
try:
 before=json.loads((ROOT/'build/git-merge/20261114-scvelo-sync-1/BEFORE.json').read_bytes())
 for row in before['files']:assert pin(ROOT/row['path'])==dict(bytes=row['size'],sha256=row['sha256']),row['path']
 source_pins={str(path.relative_to(ROOT)):pin(path) for path in SOURCES};save('SOURCE-PINS.json',source_pins)
 index=json.loads((REFERENCE/'INDEX.json').read_bytes());reference_pins=json.loads((REFERENCE/'BINARY-PAYLOADS.json').read_bytes())
 assert index['status']=='COMPLETE_ORIGINAL_GRID_BINARY_TRANSCRIPT' and index['case_count']==31
 for name,wanted in reference_pins.items():assert pin(REFERENCE/name)==wanted,name
 classes=OUT/'classes';classes.mkdir(exist_ok=False)
 run('javac',[JDK/'javac.exe','--release','17','-Xlint:all','-Werror','-d',classes,*SOURCES[:3]])
 run('native-controls',[JDK/'java.exe','-cp',classes,'VelociraptorGrid120Controls'])
 results=OUT/'results';results.mkdir(exist_ok=False);cases=[];finite=nonfinite=integers=bit_equal=nan_bits_differ=0;maximum_error=0.0
 expected_names={'start','end','vectors','limits','delta','categories','groups','group_labels','populations'}
 for ordinal,case in enumerate(index['cases'],1):
  target=results/case['directory'];run('case-'+str(ordinal).zfill(4),[JDK/'java.exe','-cp',classes,'VelociraptorGrid120Probe',REFERENCE/case['directory'],target,case['resolution'],str(case['scale']).lower()])
  result=json.loads((target/'RESULT.json').read_bytes());bins=case['fields']['start']['rows']
  assert result==dict(status='COMPLETE_NATIVE_GRID',cells=case['cells'],bins=bins,resolution=case['resolution'],scaled=case['scale'],requires_nonfinite_review=case['requires_nonfinite_review']),case['id']
  assert {path.name for path in target.iterdir()}=={name+'.bin' for name in expected_names}|{'RESULT.json'}
  fields=[];case_error=0.0;case_values=0
  for name in sorted(expected_names):
   field=case['fields'][name];reference=(REFERENCE/field['path']).read_bytes();actual=(target/(name+'.bin')).read_bytes()
   assert len(reference)==len(actual)==field['bytes'],(case['id'],name,'incomplete population')
   count=field['rows']*field['columns'];case_values+=count
   if field['kind']=='int32':
    assert len(reference)==count*4 and reference==actual,(case['id'],name,'original integer/categories/order differs')
    integers+=count
   else:
    assert field['kind']=='float64' and len(reference)==count*8
    for position,(expected,observed) in enumerate(zip(struct.unpack('<'+'d'*count,reference),struct.unpack('<'+'d'*count,actual))):
     expected_bits=reference[8*position:8*position+8];actual_bits=actual[8*position:8*position+8]
     if math.isnan(expected):
      assert math.isnan(observed),(case['id'],name,position,'NaN replaced');nonfinite+=1;nan_bits_differ+=expected_bits!=actual_bits
     elif math.isinf(expected):assert observed==expected,(case['id'],name,position,'infinity changed');nonfinite+=1
     else:
      assert math.isfinite(observed) and math.isclose(expected,observed,rel_tol=1e-12,abs_tol=1e-12),(case['id'],name,position,expected,observed)
      finite+=1;case_error=max(case_error,abs(expected-observed));bit_equal+=expected_bits==actual_bits
   fields.append(dict(name=name,kind=field['kind'],rows=field['rows'],columns=field['columns'],values=count,original=pin(REFERENCE/field['path']),native=pin(target/(name+'.bin'))))
  maximum_error=max(maximum_error,case_error);cases.append(dict(id=case['id'],cells=case['cells'],bins=bins,complete_fields=len(fields),values=case_values,maximum_absolute_error=case_error,requires_nonfinite_review=result['requires_nonfinite_review'],fields=fields))
 save('COMPLETE-COMPARISONS.json',cases)
 for name,wanted in reference_pins.items():assert pin(REFERENCE/name)==wanted,name
 for path in SOURCES:assert pin(path)==source_pins[str(path.relative_to(ROOT))]
 for row in before['files']:assert pin(ROOT/row['path'])==dict(bytes=row['size'],sha256=row['sha256']),row['path']
 controls=(OUT/'native-controls.stdout').read_text().strip();assert controls.startswith('PASS_NATIVE_GRID_GUARDS_AND_INPUT_IMMUTABILITY checks=')
 proof=dict(status='PASS_SCOPED_NATIVE_JAVA_VELOCIRAPTOR120_GRID_ALL31_ORIGINAL_R_CASES',cases=len(cases),complete_output_fields=sum(row['complete_fields'] for row in cases),integer_values=integers,finite_values=finite,finite_bit_equal_values=bit_equal,nonfinite_value_classes_preserved=nonfinite,generated_NaN_payloads_with_different_bits=nan_bits_differ,native_generated_NaN_bit_parity_claimed=False,maximum_absolute_error=maximum_error,absolute_tolerance=1e-12,relative_tolerance=1e-12,native_control_checks=int(controls.split('=')[-1]),original_R_reference_diagnostic_review_required=True,raw_C_stack_diagnostic_cause_unresolved=True,root_protected_paths_unchanged=len(before['files']),canonical_JAR_unchanged=True,main_worktree_Gradle_run=False,new_family_implementation_credit=0,whole_R_wrapper_adapter_qualified=False,whole_goal_complete=False)
 save('COMPLETED.json',proof);print(json.dumps(proof),flush=True)
except BaseException as error:
 save('FAILURE.json',dict(status='FAIL2_NATIVE_JAVA_GRID_QUALIFICATION_UNADMITTED',cause=repr(error),traceback=traceback.format_exc(),processes=processes,new_tool_credit=0));raise
