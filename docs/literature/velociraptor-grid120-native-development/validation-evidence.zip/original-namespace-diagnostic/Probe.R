args <- commandArgs(TRUE);lib <- args[[1L]];reference <- args[[2L]];out <- args[[3L]];recorder <- args[[4L]]
marker <- function(label) cat(paste0("PROJECT_DIAGNOSTIC_STAGE: ",label),file=stderr(),sep=intToUtf8(10L))
.libPaths(c(lib,.libPaths()))
marker("before-original-namespace-load")
ns <- loadNamespace("velociraptor",lib.loc=lib)
marker("after-original-namespace-load")
marker("before-original-reference-read")
originals <- readRDS(reference)
marker("after-original-reference-read")
actual <- list();conditions <- list()
for (id in names(originals)) {
 input <- originals[[id]]$input
 marker(paste0("before-grid-",id))
 result <- withCallingHandlers(velociraptor::gridVectors(input$coordinates,input$embedded,resolution=input$resolution,scale=input$scale,as.data.frame=FALSE,return.intermediates=TRUE),warning=function(w)conditions[[length(conditions)+1L]] <<- list(id=id,object=w,calls=sys.calls()))
 marker(paste0("after-grid-",id))
 same <- identical(result,originals[[id]]$result,num.eq=FALSE,single.NA=FALSE,attrib.as.set=FALSE,ignore.bytecode=FALSE,ignore.environment=FALSE,ignore.srcref=FALSE,extptr.as.ref=TRUE)
 if (!same) {saveRDS(list(actual=result,original=originals[[id]]$result),file.path(out,"DIFFERENT-ORIGINAL-VALUES.rds"));stop("Complete original repeated grid values differ: ",id)}
 actual[[id]] <- result
}
marker("before-complete-result-serialization")
saveRDS(actual,file.path(out,"COMPLETE-REPEATED-ORIGINAL-GRID-RESULTS.rds"))
saveRDS(conditions,file.path(out,"COMPLETE-DELIVERED-R-GRID-CONDITIONS.rds"))
marker("after-complete-result-serialization")
marker("before-recorder-source")
source(recorder,local=TRUE)
marker("after-recorder-source")
marker("before-complete-value-capture")
captureRValues(actual,file.path(out,"complete-original-values"))
marker("after-complete-value-capture")
jsonlite::write_json(list(status="PASS_ALL31_REPEATED_ORIGINAL_GRID_VALUES_STRICT",cases=length(actual),R_version=as.character(getRversion()),delivered_R_grid_warning_count=length(conditions),raw_console_diagnostic_counts_complete=FALSE,new_tool_credit=0L),file.path(out,"R-COMPLETED.json"),pretty=TRUE,auto_unbox=TRUE,null="null",na="string")
marker("complete")
