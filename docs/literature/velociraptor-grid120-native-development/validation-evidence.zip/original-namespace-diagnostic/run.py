from pathlib import Path
import json,os,subprocess,time,traceback
ROOT=Path('/mnt/d/projects/JLinAlg');BASE=ROOT/'build/literature-review/monocle-runtime';OUT=BASE/'velociraptor-grid-stack-diagnostic-1';P=Path('/opt/omicsmatic-velociraptor120-r453-20261114-1');LIB=Path('/opt/omicsmatic-velociraptor120-system-20261114-2/R-library')
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
try:
 command=[str(P/'.pixi/envs/default/bin/Rscript'),'--vanilla',str(OUT/'Probe.R'),str(LIB),str(BASE/'velociraptor-native-grid-reference-1/COMPLETE-ORIGINAL-GRID-RESULTS.rds'),str(OUT),str(ROOT/'tools/literature/velociraptor120/RValues.R')]
 env=dict(os.environ,R_LIBS_USER=str(LIB),BASILISK_USE_SYSTEM_DIR='1',BASILISK_NO_DESTROY='1',BASILISK_NO_PYENV='1',PIP_NO_INDEX='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1');start=time.time()
 with (OUT/'process.stdout').open('xb') as so,(OUT/'process.stderr').open('xb') as se:child=subprocess.run(command,env=env,stdin=subprocess.DEVNULL,stdout=so,stderr=se)
 save('TERMINAL.json',dict(command=command,exit_code=child.returncode,elapsed_seconds=time.time()-start));assert child.returncode==0
 result=json.loads((OUT/'R-COMPLETED.json').read_bytes());assert result['cases']==31
 stage=None;diagnostics=[]
 for line in (OUT/'process.stderr').read_text().splitlines():
  if line.startswith('PROJECT_DIAGNOSTIC_STAGE: '):stage=line.split(': ',1)[1]
  elif 'stack imbalance' in line:diagnostics.append(dict(most_recent_stage=stage,raw_line=line))
 save('COMPLETED.json',dict(status='PASS_REPEATED_COMPLETE_ORIGINAL_GRID_VALUES_WITH_STAGE_MARKED_DIAGNOSTIC_REVIEW',original_value_cases=31,raw_stack_diagnostic_observations=diagnostics,raw_console_diagnostic_counts_complete=False,underlying_native_C_cause_resolved=False,original_algorithms_modified=False,new_tool_credit=0,whole_goal_complete=False))
 print('REPEATED_ORIGINAL_GRID_VALUES_31_STRICT; observed stack diagnostics',json.dumps(diagnostics),flush=True)
except BaseException as error:
 save('FAILURE.json',dict(status='FAIL2_ORIGINAL_GRID_DIAGNOSTIC_PROBE_UNADMITTED',cause=repr(error),traceback=traceback.format_exc(),new_tool_credit=0));raise
