import hashlib,json,sys,zipfile
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path('D:/projects/JLinAlg');sys.path.insert(0,str(ROOT/'tools/literature'))
from mashr_original_runtime import census,pin
RUN=ROOT/'build/literature-review/fuma-runtime/ld-reference-development-1'
DEST=ROOT/'docs/literature/fuma-ld-core'
matrix=json.loads((RUN/'matrix-1/COMPLETED.json').read_text(encoding='utf-8'));original=json.loads((RUN/'original-controls-1/COMPLETED.json').read_text(encoding='utf-8'))
assert matrix['status']=='passed-three-JVM-packaged-hardcall-LD-and-window-core' and matrix['tests_per_JVM']==56 and len(matrix['runs'])==3 and all(r['process']['exit_code']==0 for r in matrix['runs'])
assert original['status']=='passed-original-PLINK19-hardcall-LD-controls' and len(original['cases'])==10 and original['matrix_values']==7568
assert all(pin(ROOT/n)==v for record in [matrix,original] for n,v in record['source_pins'].items())
assert pin(ROOT/matrix['artifact']['path'])=={k:matrix['artifact'][k] for k in ['bytes','sha256']}
assert pin(ROOT/'build/cli/omicsmatic-0.3.7.jar')==matrix['canonical_executable_unchanged']
assert not DEST.exists();DEST.mkdir();(DEST/'.gitattributes').write_text('* -text\n',encoding='utf-8',newline='\n')
sources={**matrix['source_pins'],'docs/literature/FUMA_LD_CORE.md':pin(ROOT/'docs/literature/FUMA_LD_CORE.md'),'docs/literature/fuma-ld-core/.gitattributes':pin(DEST/'.gitattributes')}
for p in sorted((ROOT/'examples/fuma-ld-core').rglob('*')):
    if p.is_file():sources[p.relative_to(ROOT).as_posix()]=pin(p)
unchanged_cli={}
for name in ['FumaLociCli.java','FumaToolsCli.java']:
    relative='src/main/java/org/jlinalg/cli/'+name;assert pin(ROOT/relative)==pin(RUN/'before'/name);unchanged_cli[relative]=pin(ROOT/relative)
example=(RUN/'example-run-1.log').read_text(encoding='utf-8');assert 'Paired calls=3, r=-1.0, r2=1.0' in example and 'OUTSIDE_DECLARED_WINDOW' in example and (RUN/'example-compile-1.log').read_bytes()==b''
thresholds=json.loads((RUN/'threshold-probes-1/RESULT.json').read_text(encoding='utf-8'));assert len(thresholds)==2 and all(v['source_pair_reported'] and v['source']==v['integer_ratio']==v['threshold'] for v in thresholds)
items={};graphs={}
def tree(path,prefix):
    graph=census(path,1073741824,100000);graphs[path]=graph
    for n,v in graph.items():assert prefix+'/'+n not in items;items[prefix+'/'+n]=(path/n,v)
    return graph
for folder,record in [('matrix-1',matrix),('original-controls-1',original)]:
    graph=tree(RUN/folder,'evidence/'+folder);assert {n:v for n,v in graph.items() if n!='COMPLETED.json'}==record['files']
for folder in ['original-intake-1','original-probe-1','threshold-probes-1','example-classes-1']:tree(RUN/folder,'evidence/'+folder)
for folder in ['before','native-tests-1-sources']:tree(RUN/folder,'history/'+folder)
for name in ['native-tests-1.log','native-tests-2.log','native-original-tests-1.log','original-controls-1.log','build-1.log','matrix-1.log','example-compile-1.log','example-run-1.log']:p=RUN/name;items['logs/'+name]=(p,pin(p))
for n,v in sources.items():items['source/'+n]=(ROOT/n,v)
items['source/record-core-checkpoint.py']=(Path(__file__),pin(Path(__file__)))
with zipfile.ZipFile(DEST/'controls.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for n,(p,v) in sorted(items.items()):
        raw=p.read_bytes();assert pin(p)==v,n;e=zipfile.ZipInfo(n,(1980,1,1,0,0,0));e.compress_type=zipfile.ZIP_DEFLATED;e.external_attr=0o100644<<16;archive.writestr(e,raw)
assert all(census(p,1073741824,100000)==g for p,g in graphs.items()) and all(pin(ROOT/n)==v for n,v in sources.items())
proof=dict(schema_version=1,status='passed-native-hardcall-LD-and-reference-window-development-core',recorded_utc=datetime.now(timezone.utc).isoformat(),scope='Library API: explicit aligned diploid hardcalls, allele frequencies and pairwise-complete unphased Pearson LD, exact undefined states, and explicit genomic-distance/index coverage for supplied FUMA references. Typed preparation/capture/replay/handoff remain open.',artifact=matrix['artifact'],tests_per_JVM=56,new_tests_per_JVM=32,prior_locus_tests=24,heap_mib=128,platforms=[r['name'] for r in matrix['runs']],original_version=original['original_version'],original_cases=10,original_matrix_values_per_JVM=7568,original_frequency_rows_per_JVM=228,threshold_probes=thresholds,source_pins=sources,unchanged_cli_source_pins=unchanged_cli,unchanged_prior_packaged_classes=matrix['unchanged_prior_packaged_classes'],changed_prior_packaged_classes=matrix['changed_prior_packaged_classes'],new_packaged_classes=matrix['new_packaged_classes'],owned_classes=matrix['owned_classes'],prior_artifact=matrix['prior_artifact'],canonical_executable_unchanged=matrix['canonical_executable_unchanged'],archive=dict(path='controls.zip',**pin(DEST/'controls.zip'),entries=len(items)),archive_files={n:v for n,(_,v) in sorted(items.items())},retained_failed_attempt='native-tests-1: test-source Java compound-var declarations failed compilation before numerical execution. Corrected test declarations; production math was unchanged.',claims=dict(native_ld_api_available=True,explicit_window_reference_api_available=True,reference_preparation_cli_available=False,resource_capture_and_replay_available=False,automatic_locus_handoff_available=False,full_FUMA_reproduced=False,paper_historical_reference_reconstructed=False,catalog_promoted=False,whole_goal_complete=False,released_or_deployed=False),required_action='Use FUMA_LD_CORE.md and the identified candidate. Declare aligned samples and a diploid unphased model; inspect every undefined status. Outside-window pairs are uncomputed, not zero/weak LD. Do not turn undefined estimates into sparse omissions. Complete typed reference preparation and capture/replay before claiming an available reference-building workflow. Per-pair capacities do not bound a caller that retains all rows/results. Correct invalid input/capacity causes and rerun completely; keep failed evidence.')
(DEST/'VALIDATION.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
with zipfile.ZipFile(DEST/'controls.zip') as archive:
    assert len(archive.infolist())==len(items)==len({e.filename for e in archive.infolist()})
    for n,v in proof['archive_files'].items():
        raw=archive.read(n);assert len(raw)==v['bytes'] and hashlib.sha256(raw).hexdigest()==v['sha256'],n
print(json.dumps(dict(status=proof['status'],tests_per_JVM=56,original_matrix_values_per_JVM=7568,unchanged_prior_packaged_classes=proof['unchanged_prior_packaged_classes'],archive=proof['archive'],catalog_promoted=False)))
