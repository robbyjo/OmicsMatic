from pathlib import Path
import subprocess,os,json
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');O=A/'build/seurat-workflow-1/runtime-probe-1';O.mkdir(exist_ok=False)
cmd=['C:/Program Files/R/R-4.6.1/bin/Rscript.exe','--vanilla','D:/projects/JLinAlg/build/probe_seurat_workflow_packages_20261119.R',str(O/'PACKAGES.json')]
with (O/'stdout').open('xb') as so,(O/'stderr').open('xb') as se:p=subprocess.run(cmd,cwd=A,env=dict(os.environ,LC_ALL='C',LANG='C'),stdin=subprocess.DEVNULL,stdout=so,stderr=se)
print('EXIT',p.returncode,(O/'stderr').read_text(errors='replace')[-2000:],flush=True)
if (O/'PACKAGES.json').exists():print((O/'PACKAGES.json').read_text(encoding='utf-8'),flush=True)
raise SystemExit(p.returncode)
