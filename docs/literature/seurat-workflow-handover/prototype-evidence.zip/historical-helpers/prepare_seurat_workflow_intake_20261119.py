from pathlib import Path
import urllib.request,json,hashlib,subprocess,shutil,re
R=Path('D:/projects/JLinAlg');A=R/'build/high-impact-stats-1';B=A/'build/seurat-workflow-1';O=B/'source-1';O.mkdir(parents=True,exist_ok=False);commit='75dfa8603befe31505e6287d32dc86c607732bd6'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=A,text=True).strip()=='304a37b384d3c753f8fa95ac2e0a634dc761557d';assert not subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=A)
print(subprocess.check_output(['git','switch','-c','codex/seurat-workflows-20261119'],cwd=A,text=True),flush=True)
def get(url):
 request=urllib.request.Request(url,headers={'User-Agent':'OmicsMatic-Seurat-source-audit','Accept':'application/vnd.github+json' if 'api.github.com' in url else 'application/octet-stream'})
 with urllib.request.urlopen(request,timeout=45) as response:return response.read()
tree=json.loads(get('https://api.github.com/repos/satijalab/seurat/git/trees/'+commit+'?recursive=1'));paths={r['path'] for r in tree['tree']}
print('CPP SOURCE',[p for p in sorted(paths) if p.startswith('src/')],flush=True)
wanted=['R/preprocessing.R','R/preprocessing5.R','R/clustering.R','R/dimensional_reduction.R','R/objects.R','R/generics.R','DESCRIPTION','LICENSE']+[p for p in sorted(paths) if p.startswith('src/') and any(k in p.lower() for k in ['snn','modularity','data_manipulation'])]
records={}
for name in wanted:
 if name not in paths:print('SOURCE NOT PRESENT',name,flush=True);continue
 url='https://raw.githubusercontent.com/satijalab/seurat/'+commit+'/'+name;raw=get(url);path=O/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw);records[name]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),url=url)
(O/'SOURCE.json').write_text(json.dumps(dict(tag='v5.6.0',commit=commit,files=records),indent=2)+'\n',encoding='utf-8')
data=json.loads((A/'build/seurat-high-impact-1/primary-intake-1/PRIMARY-CANDIDATES.private.json').read_bytes());terms=['NormalizeData','SCTransform','FindVariableFeatures','ScaleData','RunPCA','FindNeighbors','FindClusters','RunUMAP','RunTSNE','FindIntegrationAnchors','IntegrateData','FindTransferAnchors','TransferData','MapQuery','FindAllMarkers','FindMarkers','AddModuleScore','CellCycleScoring']
for term in terms:
 ids=[p['paper_id'] for p in data['candidates'] if p['existing_observation'] and any(re.search(re.escape(term),r['text'],re.I) for r in p['paragraphs'])];print('NAMED CONTEXTS',term,len(ids),','.join(ids),flush=True)
print('SOURCES',len(records),flush=True)
