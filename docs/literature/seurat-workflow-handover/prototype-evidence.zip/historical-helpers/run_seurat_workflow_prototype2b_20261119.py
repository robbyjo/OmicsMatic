from pathlib import Path
import subprocess,os,json,shutil
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');O=A/'build/seurat-workflow-1/prototype-2';O.mkdir(exist_ok=False);source=Path('D:/projects/JLinAlg/build/prototype_seurat_workflow_20261119.R');shutil.copyfile(source,O/'PROTOTYPE.R')
cmd=['C:/Program Files/R/R-4.6.1/bin/Rscript.exe','--vanilla',str(O/'PROTOTYPE.R'),str(O)]
with (O/'stdout').open('xb') as so,(O/'stderr').open('xb') as se:p=subprocess.run(cmd,cwd=A,env=dict(os.environ,LC_ALL='C',LANG='C',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1'),stdin=subprocess.DEVNULL,stdout=so,stderr=se)
print('EXIT',p.returncode,(O/'stdout').read_text(errors='replace')[-1800:],(O/'stderr').read_text(errors='replace')[-1800:],flush=True)
if (O/'RESULTS.json').exists():
 result=json.loads((O/'RESULTS.json').read_bytes());print(json.dumps(result,indent=2),flush=True);assert len(result)==4
raise SystemExit(p.returncode)
