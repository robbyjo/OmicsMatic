from pathlib import Path
import json
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');old=A/'build/seurat-workflow-1/prototype-1';(old/'FAILURE.json').write_text(json.dumps(dict(status='RETAINED_PROTOTYPE_REPORT_SERIALIZATION_FAILURE',cause='The first complete original workflow reached export, but jsonlite refused its S3 table summary. RDS, graphs, PCA and embedding files are retained; the overall prototype run was incomplete.',correction='Serialize cluster counts as named integer lists, not S3 table objects.',original_scientific_functions_changed=False),indent=2)+'\n',encoding='utf-8')
p=Path('D:/projects/JLinAlg/build/run_seurat_workflow_prototype_20261119.py');code=p.read_text(encoding='utf-8').replace("/'prototype-1'","/'prototype-2'");exec(compile(code,str(p)+'-report-fix','exec'))
result=json.loads((A/'build/seurat-workflow-1/prototype-2/RESULTS.json').read_bytes());assert len(result)==4
print('PROTOTYPE STATUSES',[(name,row['status'],row.get('stage'),row.get('error')) for name,row in result.items()])
