from pathlib import Path
import subprocess,os,json,shutil
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');O=A/'build/seurat-workflow-1/prototype-1';O.mkdir(exist_ok=False);script=Path('D:/projects/JLinAlg/build/prototype_seurat_workflow_20261119.R');shutil.copyfile(script,O/'PROTOTYPE.R');cmd=['C:/Program Files/R/R-4.6.1/bin/Rscript.exe','--vanilla',str(O/'PROTOTYPE.R'),str(O)]
with (O/'stdout').open('xb') as so,(O/'stderr').open('xb') as se:p=subprocess.run(cmd,cwd=A,env=dict(os.environ,LC_ALL='C',LANG='C',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1'),stdin=subprocess.DEVNULL,stdout=so,stderr=se)
print('EXIT',p.returncode,(O/'stdout').read_text(errors='replace')[-2000:],(O/'stderr').read_text(errors='replace')[-2000:],flush=True)
if (O/'RESULTS.json').exists():print((O/'RESULTS.json').read_text(encoding='utf-8'),flush=True)
