args<-commandArgs(trailingOnly=TRUE);stopifnot(length(args)==1L)
.libPaths(c('D:/projects/JLinAlg/build/literature-review/signac-runtime/reference-setup-1/R-lib','D:/projects/JLinAlg/build/omics-sctransform-r',.Library))
packages<-c('Seurat','SeuratObject','Matrix','jsonlite','future','sctransform','glmGamPoi','irlba','RANN','RcppAnnoy','uwot','Rtsne','leidenbase','igraph','leiden','reticulate')
rows<-lapply(packages,function(package) {
 error<-tryCatch({loadNamespace(package);NULL},error=function(e)conditionMessage(e))
 list(package=package,available=is.null(error),version=if(is.null(error))as.character(packageVersion(package)) else NULL,error=error)
})
jsonlite::write_json(list(R=as.character(getRversion()),packages=rows),args[[1L]],pretty=TRUE,auto_unbox=TRUE)
cat('PROBED',length(rows),'packages\n')
