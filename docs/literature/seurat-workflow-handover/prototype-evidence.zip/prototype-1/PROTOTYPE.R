args<-commandArgs(trailingOnly=TRUE);stopifnot(length(args)==1L);out<-args[[1L]]
.libPaths(c('D:/projects/JLinAlg/build/literature-review/signac-runtime/reference-setup-1/R-lib','D:/projects/JLinAlg/build/omics-sctransform-r',.Library))
suppressPackageStartupMessages(library(Seurat));suppressPackageStartupMessages(library(Matrix));options(Seurat.nthreads=1L);future::plan('sequential')
set.seed(8281L);genes<-300L;cells<-96L;group<-rep(1:3,each=cells/3);base<-runif(genes,.3,5);mu<-outer(base,runif(cells,.6,1.6));mu[1:40,group==1]<-mu[1:40,group==1]*4;mu[41:80,group==2]<-mu[41:80,group==2]*4
counts<-matrix(rnbinom(length(mu),mu=as.vector(mu),size=7),genes,cells);counts[genes,]<-0;dimnames(counts)<-list(paste0('f',seq_len(genes)),paste0('c',seq_len(cells)));counts<-as(counts,'dgCMatrix');metadata<-data.frame(depth_cov=seq(-1,1,length.out=cells),batch=factor(rep(c('l1','l2'),cells/2),levels=c('l1','l2')),row.names=colnames(counts))
Matrix::writeMM(counts,file.path(out,'COUNTS.mtx'));saveRDS(list(counts=counts,metadata=metadata),file.path(out,'INPUT.rds'));summaries<-list()
cases<-list(list(name='log-exact-rann-louvain',norm='log',regress=FALSE,pca='exact',nn='rann',algorithm=1L),list(name='log-default-annoy-slm',norm='log',regress=FALSE,pca='default',nn='annoy',algorithm=3L),list(name='log-regression-irlba-rann-multilevel',norm='log',regress=TRUE,pca='irlba',nn='rann',algorithm=2L),list(name='sct-v2-igraph-leiden',norm='sct',regress=FALSE,pca='default',nn='annoy',algorithm=4L))
for(cfg in cases) {
 folder<-file.path(out,cfg$name);dir.create(folder);warnings<-list();stage<-'construct';started<-proc.time();cat('START',cfg$name,'\n');flush.console()
 record<-tryCatch(withCallingHandlers({
  obj<-CreateSeuratObject(counts=counts,meta.data=metadata,min.cells=0,min.features=0,assay='RNA',project='OmicsMaticSynthetic')
  stage<-'normalize'
  if(cfg$norm=='log') {
   obj<-NormalizeData(obj,normalization.method='LogNormalize',scale.factor=10000,verbose=FALSE)
   obj<-FindVariableFeatures(obj,selection.method='vst',nfeatures=80,loess.span=.3,clip.max='auto',verbose=FALSE)
   stage<-'scale';obj<-ScaleData(obj,features=VariableFeatures(obj),vars.to.regress=if(cfg$regress)c('depth_cov','batch') else NULL,do.center=TRUE,do.scale=TRUE,scale.max=10,verbose=FALSE)
  } else {
   obj<-SCTransform(obj,assay='RNA',new.assay.name='SCT',vst.flavor='v2',ncells=96L,variable.features.n=80L,return.only.var.genes=FALSE,do.correct.umi=TRUE,seed.use=42L,verbose=FALSE)
  }
  stage<-'pca';extra<-switch(cfg$pca,exact=list(approx=FALSE),irlba=list(approx=TRUE,tol=1e-5,maxit=1000),default=list(approx=TRUE));obj<-do.call(RunPCA,c(list(object=obj,npcs=10L,seed.use=42L,weight.by.var=TRUE,verbose=FALSE),extra))
  stage<-'neighbors';obj<-FindNeighbors(obj,reduction='pca',dims=1:8,k.param=12L,nn.method=cfg$nn,annoy.metric='euclidean',n.trees=50L,nn.eps=0,prune.SNN=1/15,graph.name=c('wf_nn','wf_snn'),verbose=FALSE)
  stage<-'clusters';obj<-FindClusters(obj,graph.name='wf_snn',resolution=c(.4,.8),algorithm=cfg$algorithm,leiden_method='igraph',n.start=10L,n.iter=10L,random.seed=42L,group.singletons=TRUE,verbose=FALSE)
  stage<-'umap';obj<-RunUMAP(obj,reduction='pca',dims=1:8,n.neighbors=12L,n.components=2L,metric='cosine',n.epochs=60L,min.dist=.3,spread=1,seed.use=42L,uwot.sgd=FALSE,return.model=FALSE,verbose=FALSE)
  stage<-'tsne';obj<-RunTSNE(obj,reduction='pca',dims=1:8,seed.use=42L,perplexity=10,tsne.method='Rtsne',max_iter=500,num_threads=1L,verbose=FALSE)
  stage<-'export';saveRDS(obj,file.path(folder,'ORIGINAL-SEURAT.rds'));Matrix::writeMM(obj[['wf_nn']],file.path(folder,'nn.mtx'));Matrix::writeMM(obj[['wf_snn']],file.path(folder,'snn.mtx'))
  for(reduction in c('pca','umap','tsne'))write.table(Embeddings(obj,reduction),file.path(folder,paste0(reduction,'.tsv')),sep='\t',quote=FALSE,col.names=NA)
  cluster.columns<-grep('^wf_snn_res[.]',colnames(obj[[]]),value=TRUE);write.table(obj[[]][,cluster.columns,drop=FALSE],file.path(folder,'clusters.tsv'),sep='\t',quote=FALSE,col.names=NA)
  list(status='PASS_ORIGINAL_PROTOTYPE',stage=stage,features=nrow(obj),cells=ncol(obj),active_assay=DefaultAssay(obj),variable_features=length(VariableFeatures(obj)),scaled_features=nrow(LayerData(obj,layer='scale.data')),pca_dim=dim(Embeddings(obj,'pca')),nn_edges=length(obj[['wf_nn']]@x),snn_edges=length(obj[['wf_snn']]@x),clusters=lapply(obj[[]][,cluster.columns,drop=FALSE],function(v)table(v)),seconds=unname((proc.time()-started)[['elapsed']]))
 },warning=function(w){warnings[[length(warnings)+1L]]<<-list(stage=stage,message=conditionMessage(w));invokeRestart('muffleWarning')}),error=function(e)list(status='FAIL_ORIGINAL_PROTOTYPE',stage=stage,error=conditionMessage(e),seconds=unname((proc.time()-started)[['elapsed']])))
 record$config<-cfg;record$warnings<-warnings;summaries[[cfg$name]]<-record;jsonlite::write_json(record,file.path(folder,'RESULT.json'),pretty=TRUE,auto_unbox=TRUE,digits=17);cat(record$status,cfg$name,record$stage,'\n');flush.console()
}
jsonlite::write_json(summaries,file.path(out,'RESULTS.json'),pretty=TRUE,auto_unbox=TRUE,digits=17);writeLines(capture.output(sessionInfo()),file.path(out,'session.txt'))
