# PASS_ORIGINAL_SNPRELATE146_KING_MATRIX_REFERENCE_COLLECTION_ONLY



REQUIRED ACTION: No project SNPRelate analysis is admitted by this reference collector. Require complete native checks before adapter/catalog credit. If the named exact private R runtime/packages cannot be supplied or installation is forbidden, skip dependent SNPRelate analysis. Use setup_snprelate_reference.py with explicit download/install flags only where permitted. Never substitute standalone KING, PLINK2-hosted KING or a different package version, infer paper defaults, repair IDs or silently remove samples/variants.
