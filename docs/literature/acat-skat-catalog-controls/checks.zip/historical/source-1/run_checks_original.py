from pathlib import Path
import argparse,json,os,re,subprocess,sys
from prepare_acat_skat_catalog_20261122_109 import R,T,O,BASE
from prepare_handover_qtltools_20261121_105 import pin,save
sys.path.insert(0,str(T/'tools/literature'))
from acat_skat_catalog import evidence as e
B=T/'build/acat-skat-catalog-1';PY='C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe';DEP=R/'build/qt-4/build/qtltools-catalog-1/pdf-reader-dependency-1/python'
def mount(path):return '/mnt/d/'+path.relative_to(R.anchor).as_posix()
def run(folder,args,host='windows',expected=0,owner=None,stamp=False):
    folder.mkdir(parents=True);env=os.environ.copy();env['PYTHONPATH']=str(T/'tools/literature')+os.pathsep+str(DEP)
    command=[PY,'-X','utf8','-B',*args] if host=='windows' else ['wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','-u','root','--','env','PYTHONPATH='+mount(T/'tools/literature')+':'+mount(DEP),'python3','-B',*args]
    start=dict(command=command,expected_exit_code=expected)
    if owner:start['actual_owner']=str(owner)
    if stamp:start['source_inputs']=e.sources()
    save(folder/'STARTED.json',start)
    with (folder/'stdout').open('xb') as out,(folder/'stderr').open('xb') as err:p=subprocess.run(command,cwd=owner or T,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,timeout=300)
    save(folder/'PROCESS.json',dict(exit_code=p.returncode));assert p.returncode==expected,(str(folder),p.returncode,(folder/'stderr').read_text()[-5000:]);return folder
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['native-reader','source','controls']);parser.add_argument('--host',choices=['windows','linux'],default='windows');args=parser.parse_args();assert json.loads((B/'CONTROL-SOURCE.json').read_bytes())==e.sources()
    if args.mode=='native-reader':
        native=R/'build/sa-1';run(B/'native-predecessor-reader',[str(native/'tools/literature/acat091/verify_checkpoint.py'),'--jar',str(native/'build/skat-acat-1/normal-gradle-2/project-build/cli/omicsmatic-0.4.0.jar')],owner=native);print('PASS actual immutable native ACAT checkpoint reader')
    else:
        script=T/'tools/literature/audit_acat_skat_source_roles.py';cache=R/'build/literature-review/xml';pdf=R/'build/qt-4/build/qtltools-catalog-1/auxiliary-intake-1/P190-mmc1.pdf';bad=B/'source-refusal-inputs';path=mount if args.host=='linux' else str
        if args.mode=='source':
            folder=B/('fresh-source-'+args.host+'-1');run(folder,[path(script),'--primary-cache',path(cache),'--supplement-pdf',path(pdf),'--out',path(folder/'result')],args.host,stamp=True);print('PASS fresh source',args.host)
        else:
            folder=B/('catalog-controls-'+args.host+'-1');folder.mkdir();unit=run(folder/'model-transaction',['-m','unittest','-v','acat_skat_catalog.test_model','acat_skat_catalog.test_transaction'],args.host);log=(unit/'stderr').read_text();match=re.search(r'Ran (\d+) tests',log);assert match and '\nOK\n' in log;count=int(match[1]);assert count==32,count
            results={}
            for name,c,p,code,reason in [('missing-xml',bad/'missing-cache',pdf,3,'SKIP3'),('changed-xml',bad/'changed-cache',pdf,2,'Primary XML identity differs'),('missing-pdf',cache,bad/'missing.pdf',3,'SKIP3'),('changed-pdf',cache,bad/'wrong.pdf',2,'Changed P190 publisher supplement')]:
                f=folder/name;run(f,[path(script),'--primary-cache',path(c),'--supplement-pdf',path(p),'--out',path(f/'result')],args.host,code);failure=json.loads((f/'result/FAILURE.json').read_bytes());assert reason in failure['status']+' '+failure['error'];results[name]=dict(exit_code=code,status=failure['status'],error=failure['error'])
            save(folder/'RESULT.json',dict(status='PASS_ACAT_SKAT_CATALOG_MODEL_TRANSACTION_AND_SOURCE_REFUSALS',model_transaction_tests=count,source_refusals=4,all_source_refusals_passed=True,source_refusal_results=results,canonical_metadata_changed=False,scientific_models_executed=False));print('PASS',args.host,count,'model/transaction tests and4 real source refusals')
    assert json.loads((B/'CONTROL-SOURCE.json').read_bytes())==e.sources(),'Source changed during checks;retain attempt unadmitted'
