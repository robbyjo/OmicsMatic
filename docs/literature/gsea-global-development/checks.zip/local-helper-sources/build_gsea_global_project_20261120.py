from pathlib import Path
R=Path('D:/projects/JLinAlg')
s=(R/'build/build_native_gsea_project_20261120.py').read_text()
s=s.replace("H=R/'build/gs-2';B=H/'build/gsea-high-impact-2';O=B/'native-gradle-1'","H=R/'build/gs-5';B=H/'build/gsea-admission-1';O=B/'global-gradle-1'")
s=s.replace("'org.jlinalg.enrichment.BroadGseaStatisticsTest']","'org.jlinalg.enrichment.BroadGseaStatisticsTest','--tests','org.jlinalg.enrichment.BroadGseaEngineTest','--tests','org.jlinalg.cli.BroadGseaRecipeTest']")
exec(compile(s,str(Path(__file__)),'exec'))
