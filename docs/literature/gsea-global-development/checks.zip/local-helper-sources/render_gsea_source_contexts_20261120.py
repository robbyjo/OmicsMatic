from pathlib import Path
import json
R=Path('D:/projects/JLinAlg');T=R/'build/gs-5';B=T/'build/gsea-admission-1';O=B/'source-contexts-1';O.mkdir(exist_ok=False)
census=json.loads((R/'build/gs-1/build/gsea-high-impact-1/source-census-intake-1/CANDIDATES.json').read_bytes());papers={p['paper_id']:p for p in json.loads((T/'docs/literature/omics-2023-2026/papers.json').read_bytes())}
for c in census['candidates']:
    pid=c['paper_id'];paper=papers[pid];lines=[pid+' '+paper['title'],paper['doi']+' / '+paper['pmcid'],'EXISTING_GSEA_OBSERVATION '+str(c['existing_observation'])]
    for a in c['anchors']:lines+=['','PARAGRAPH '+str(a['paragraph_index'])+' / '+a['section']+' / '+a['paragraph_sha256'],a['text']]
    (O/(pid+'.txt')).write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\n')
(O/'INDEX.json').write_text(json.dumps({c['paper_id']:dict(existing=c['existing_observation'],paragraphs=[a['paragraph_index'] for a in c['anchors']],words=sum(len(a['text'].split()) for a in c['anchors'])) for c in census['candidates']},indent=2)+'\n',encoding='utf-8')
print('Rendered exact frozen paragraphs for',len(census['candidates']),'candidate papers',flush=True)
