from pathlib import Path
import importlib.util,json,hashlib,subprocess,xml.etree.ElementTree as ET
R=Path('D:/projects/JLinAlg');T=R/'build/gs-5';B=T/'build/gsea-admission-1'
s=(R/'build/qualify_gsea_file_final_hosts_20261120.py').read_text()
old="T=R/'build/gs-4';B=T/'build/gsea-high-impact-4';O=B/'file-hosts-qualification-3'"
new="T=R/'build/gs-5';B=T/'build/gsea-admission-1';O=B/'global-hosts-qualification-1'"
assert old in s;s=s.replace(old,new)
s=s.replace("JAR=B/'native-gradle-3/project-build/cli/omicsmatic-0.4.0.jar';OLD=R/'build/gs-3/build/gsea-high-impact-3/native-gradle-1/project-build/cli/omicsmatic-0.4.0.jar'", "JAR=B/'global-gradle-1/project-build/cli/omicsmatic-0.4.0.jar';OLD=R/'build/gs-4/build/gsea-high-impact-4/native-gradle-3/project-build/cli/omicsmatic-0.4.0.jar'")
s=s.replace("B/'native-gradle-3/PROCESS-EXIT.json'","B/'global-gradle-1/PROCESS-EXIT.json'")
old="""    before=set(old.namelist());after=set(new.namelist());assert before<=after
    for n in sorted(before):assert old.read(n)==new.read(n),n
    added=sorted(after-before);assert added and all(n.startswith('org/jlinalg/cli/BroadGsea') and n.endswith('.class') for n in added)"""
new="""    before=set(old.namelist());after=set(new.namelist());assert before==after and len(before)==23522
    changed=[n for n in sorted(before) if old.read(n)!=new.read(n)]
    assert changed==['org/jlinalg/cli/JLinAlgCli.class'],changed
    added=[]"""
assert old in s;s=s.replace(old,new)
s=s.replace("unchanged_predecessor_members=len(before),added_members=added", "unchanged_predecessor_members=len(before)-1,changed_members=changed,added_members=added")
s=s.replace("prefix+['-cp',jar,'org.jlinalg.cli.BroadGseaWorkflowCli','--request',convert(recipe)]", "prefix+['-jar',jar,'broad-gsea-tools','--request',convert(recipe)]")
s=s.replace("    before=None\n", """    for label,args,expected in [('global-help',['--help'],0),('command-help',['broad-gsea-tools','--help'],0),('missing-request',['broad-gsea-tools'],3)]:
        command=prefix+['-jar',jar]+args
        p=subprocess.run(command,capture_output=True,stdin=subprocess.DEVNULL,timeout=45)
        (root/(label+'.stdout')).write_bytes(p.stdout);(root/(label+'.stderr')).write_bytes(p.stderr)
        save(root/(label+'.PROCESS.json'),dict(command=command,exit_code=p.returncode))
        assert p.returncode==expected,(host,label,p.returncode)
        if label=='global-help':assert b'broad-gsea-tools' in p.stdout
    before=None
""")
s=s.replace("    result=dict(host=host", """    old_capture=R/'build/gs-4/build/gsea-high-impact-4/file-hosts-qualification-3'/host/'examples/run-out'
    old_snapshot=snapshot(old_capture)
    for mode in ['VERIFY','REPLAY']:
        request=root/('previous-'+mode.lower()+'.json')
        save(request,dict(schema_version=1,mode=mode,analysis=convert(old_capture),out=convert(root/('previous-'+mode.lower()+'-out')),limits=limits))
        run('previous-'+mode.lower(),request)
        assert snapshot(old_capture)==old_snapshot
        status=json.loads((root/('previous-'+mode.lower()+'-out')/'analysis-status.json').read_bytes())
        assert status['complete_result'] and status['status']=='PASS_'+mode
    result=dict(previous_producer_capture_VERIFY_REPLAY=True,global_help=True,command_help=True,missing_request_SKIP3=True,host=host""")
s=s.replace('PASS_NATIVE_GSEA_FILE_WORKFLOW_ORIGINAL_COMPARISONS_THREE_JVMS','PASS_NATIVE_GSEA_GLOBAL_ROUTE_ORIGINAL_COMPARISONS_THREE_JVMS')
s=s.replace('global_dispatch_registered=False','global_dispatch_registered=True')
spec=importlib.util.spec_from_file_location('transition',T/'tools/literature/gsea_dispatch_transition.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
raw=(T/m.DISPATCH).read_bytes();before=m.dispatcher_before(raw)
assert before==subprocess.check_output(['git','show',m.BASE+':'+m.DISPATCH],cwd=T)
cases={'missing-route':raw.replace(m.ROUTE,b'',1),'missing-help':raw.replace(m.HELP,b'',1),'duplicate-route':raw+m.ROUTE,'duplicate-help':raw+m.HELP,'moved-route':raw.replace(m.ROUTE,b'',1)+m.ROUTE,'moved-help':raw.replace(m.HELP,b'',1)+m.HELP,'unrelated-change':raw+b'\n'}
controls=[]
for name,changed in cases.items():
    try:m.dispatcher_before(changed)
    except ValueError as error:controls.append(dict(name=name,status='EXPECTED_REFUSAL',diagnostic=str(error)))
    else:raise AssertionError('Admitted '+name)
out=B/'global-transition-controls-1';out.mkdir(exist_ok=False)
(out/'COMPLETED.json').write_text(json.dumps(dict(status='PASS_EXACT_THREE_LINE_INVERSE_AND_SEVEN_REFUSALS',before=m.pin(before),after=m.pin(raw),controls=controls),indent=2)+'\n',encoding='utf-8',newline='\n')
tests=[]
for p in sorted((B/'global-gradle-1/project-build/test-results/test').glob('TEST-*.xml')):
    a=ET.parse(p).getroot().attrib;assert a['failures']==a['errors']=='0';tests.append(a)
assert sum(int(a['tests']) for a in tests)==8
(out/'JUNIT.json').write_text(json.dumps(tests,indent=2)+'\n',encoding='utf-8',newline='\n')
print('PASS exact dispatcher inverse, seven refusals, eight focused tests; checking normal global JAR on three JVMs',flush=True)
exec(compile(s,str(Path(__file__)),'exec'))
