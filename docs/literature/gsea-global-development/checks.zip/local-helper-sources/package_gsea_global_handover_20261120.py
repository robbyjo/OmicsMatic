from pathlib import Path
import hashlib,importlib.util,json,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/gs-5';B=T/'build/gsea-admission-1';H=B/'global-hosts-qualification-2';Q=T/'docs/literature/gsea-global-development';O=B/'global-proof-package-1';O.mkdir(exist_ok=False)
def pin(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def enc(v):return (json.dumps(v,indent=2)+'\n').encode()
files={}
def add(n,p):
    assert n not in files;files[n]=Path(p).read_bytes()
def module(n,p):
    s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
qold=json.loads((T/'docs/literature/gsea-workflow-development/QUALIFICATION.json').read_bytes())
with zipfile.ZipFile(T/'docs/literature/gsea-workflow-development/checks.zip') as z:mapping=json.loads(z.read('RESULT-REFERENCES.json'))
expected=qold['archives']['docs/literature/gsea-workflow-development/workflow-results.zip']['files']
hosts=json.loads((H/'COMPLETED.json').read_bytes());assert hosts['global_dispatch_registered'] and len(hosts['results'])==3
add('producer/PRODUCER.json',H/'PRODUCER.json');add('hosts/COMPLETED.json',H/'COMPLETED.json')
for n in ['COMPLETED.json','JUNIT.json']:add('transition/'+n,B/'global-transition-controls-2'/n)
for n in ['COMMAND.json','PROCESS-EXIT.json','stdout','stderr']:add('gradle/'+n,B/'global-gradle-1'/n)
for host in ['windows-java21','windows-java25','linux-java21']:
    root=H/host;objects={};batches=json.loads((root/'corpus/BATCHES.json').read_bytes());byid={id:(batch,i) for batch,ids in batches.items() for i,id in enumerate(ids)}
    for name,ref in mapping.items():
        if ref['kind']=='long':
            edition,mode=name.removeprefix('long/').removesuffix('.bin').split('/')
            index=['4.4.0','4.3.2','4.3.3'].index(edition)*3+['preranked','expression-phenotype','expression-geneset'].index(mode)
            source=root/'examples/run-out/results'/('case-%04d'%index)/'result.bin'
        else:
            id=name.removeprefix('options/').removesuffix('.bin');batch,index=byid[id];source=root/'corpus'/(batch+'-out')/'results'/('case-%04d'%index)/'result.bin'
        objects[name]=pin(source.read_bytes())
    assert objects==expected and len(objects)==432
    files['hosts/'+host+'/COUNTERPART-PINS.json']=enc(objects)
    for n in ['COMPLETED.json','version.stdout','version.stderr']:add('hosts/'+host+'/'+n,root/n)
    for label in ['run','verify','replay','previous-verify','previous-replay','global-help','command-help','missing-request']:
        for source,target in [(label+'.PROCESS.json','PROCESS.json'),(label+'.stdout','stdout'),(label+'.stderr','stderr')]:add('hosts/'+host+'/'+label+'/'+target,root/source)
        if label in ['run','verify','replay','previous-verify','previous-replay']:
            capture=root/(label+'-out') if label.startswith('previous-') else root/'examples'/(label+'-out')
            for n in ['analysis-status.json','capture-files.json','process.json','original-request.json','effective-request.json','producer.json','worker/status.json']:add('hosts/'+host+'/'+label+'/'+n,capture/n)
    for batch in batches:
        add('hosts/'+host+'/'+batch+'/PROCESS.json',root/(batch+'.PROCESS.json'))
        add('hosts/'+host+'/'+batch+'/analysis-status.json',root/'corpus'/(batch+'-out')/'analysis-status.json')
    for n in ['global-help','command-help','missing-request']:
        for suffix in ['PROCESS.json','stdout','stderr']:add('retained-harness-attempt/'+host+'/'+n+'.'+suffix,B/'global-hosts-qualification-1'/host/(n+'.'+suffix))
files['retained-harness-attempt/CORRECTION.json']=enc(dict(cause='The missing --request command syntax correctly returned FAIL2 (2); the initial harness incorrectly expected SKIP3 (3).',application_changed=False,scientific_policy_changed=False,new_output='global-hosts-qualification-2'))
sourcefiles=['start_gsea_admission_20261120.py','inspect_gsea_source_contexts_20261120.py','render_gsea_source_contexts_20261120.py','inspect_gsea_provider_details_20261120.py','prepare_gsea_global_route_20261120.py','build_gsea_global_project_20261120.py','intake_gsea_author_supplements_20261120.py','qualify_gsea_global_handover_20261120.py','retry_gsea_global_handover_20261120.py','package_gsea_global_handover_20261120.py']
for n in sourcefiles:add('local-helper-sources/'+n,R/'build'/n)
identity=json.loads((B/'author-sources-1/P096-CODE-IDENTITY.json').read_bytes());identity['files']={p.name:pin(p.read_bytes()) for p in sorted((B/'author-sources-1').glob('*')) if p.is_file()};files['source-audit/AUTHOR-INTAKE-IDENTITIES.json']=enc(identity)
with zipfile.ZipFile(Q/'checks.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,b in sorted(files.items()):
        info=zipfile.ZipInfo(n,(2026,11,20,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,b)
reader=module('gsea_global_reader',T/'tools/literature/verify_broad_gsea_global.py')
own=['src/main/java/org/jlinalg/cli/JLinAlgCli.java','tools/literature/gsea_dispatch_transition.py','tools/literature/verify_broad_gsea_global.py','docs/vignettes/broad-gsea-tools.md','docs/literature/HANDOVER_2026-11-20_GSEA_GLOBAL.md']+[p.relative_to(T).as_posix() for p in Q.iterdir() if p.name in ['README.md','SOURCE-AUDIT-RESUME.md','.gitattributes']]
q=dict(schema_version=1,status=reader.STATUS,sources={n:pin((T/n).read_bytes()) for n in sorted(own)},archive=pin((Q/'checks.zip').read_bytes()),files={n:pin(b) for n,b in sorted(files.items())},producer=hosts['producer'],new_catalog_credit=0,private_transfer_required=True)
(Q/'QUALIFICATION.json').write_bytes(enc(q));result=reader.verify(jar=B/'global-gradle-1/project-build/cli/omicsmatic-0.4.0.jar');(O/'COMPLETED.json').write_bytes(enc(result));print(json.dumps(result,indent=2),flush=True)
