from pathlib import Path
R=Path('D:/projects/JLinAlg');s=(R/'build/qualify_gsea_global_handover_20261120.py').read_text()
s=s.replace('global-hosts-qualification-1','global-hosts-qualification-2').replace('global-transition-controls-1','global-transition-controls-2')
assert "('missing-request',['broad-gsea-tools'],3)" in s
s=s.replace("('missing-request',['broad-gsea-tools'],3)","('missing-request',['broad-gsea-tools'],2)")
s=s.replace('missing_request_SKIP3=True','missing_request_syntax_FAIL2=True')
exec(compile(s,str(Path(__file__)),'exec'))
