from pathlib import Path
import gzip,hashlib,json,re,sys,xml.etree.ElementTree as ET
R=Path('D:/projects/JLinAlg');T=R/'build/gs-5';O=T/'build/gsea-admission-1/provider-contexts-1';O.mkdir(exist_ok=False)
sys.dont_write_bytecode=True;sys.path.insert(0,str(T/'tools/literature'))
from collect_omics_review import paragraphs
papers={p['paper_id']:p for p in json.loads((T/'docs/literature/omics-2023-2026/papers.json').read_bytes())};report={}
selected=['P009','P024','P032','P042','P049','P077','P079','P089','P094','P096','P098','P133','P145','P151','P165','P170','P220']
for pid in selected:
    p=papers[pid]
    with gzip.open(R/'build/literature-review/xml'/(p['pmcid']+'.xml.gz'),'rb') as f:raw=f.read()
    assert hashlib.sha256(raw).hexdigest()==p['xml_sha256'];xml=ET.fromstring(raw);rows=[]
    for a in paragraphs(xml):
        if not re.search(r'gsea|enrich|gene.?set|msigdb|gprofiler|clusterprofiler|magma|pathfind|zenith',a['text'],re.I):continue
        sentences=re.split(r'(?<=[.!?])\s+(?=[A-Z])',a['text'])
        chosen=[s for s in sentences if re.search(r'gsea|enrich|gene.?set|msigdb|gprofiler|clusterprofiler|magma|zenith',s,re.I)]
        rows.append(dict(paragraph_index=a['paragraph_index'],section=a['section'],paragraph_sha256=hashlib.sha256(a['text'].encode()).hexdigest(),selected_sentences=chosen,text=a['text']))
    links=[]
    for node in xml.iter():
        if node.tag.rsplit('}',1)[-1] in {'supplementary-material','media','ext-link'}:
            href=node.get('{http://www.w3.org/1999/xlink}href')
            if href and (re.search(r'pdf|esm|zenodo|figshare',href,re.I) or node.tag.rsplit('}',1)[-1]=='supplementary-material'):
                links.append(dict(tag=node.tag,href=href,text=' '.join(' '.join(node.itertext()).split())))
    report[pid]=dict(paragraphs=rows,links=links)
    (O/(pid+'.json')).write_text(json.dumps(report[pid],indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
    if pid in {'P009','P032','P042','P089','P094','P098','P145','P170','P220'}:
        print('\n'+pid,flush=True)
        for a in rows:
            if re.search(r'method|analysis|analyses|processing',a['section'],re.I):
                print(str(a['paragraph_index'])+' / '+a['section']+' / '+' '.join(a['selected_sentences'])[:2400],flush=True)
print('\nP077_LINKS',json.dumps(report['P077']['links'],ensure_ascii=False),flush=True)
