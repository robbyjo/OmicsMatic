from pathlib import Path
import json
R=Path('D:/projects/JLinAlg');p=R/'build/gs-1/build/gsea-high-impact-1/source-census-intake-1/CANDIDATES.json'
data=json.loads(p.read_bytes());print('ROOT_KEYS',list(data),flush=True)
for key,value in data.items():
    if key=='source_identities':continue
    print(key,type(value).__name__,len(value) if hasattr(value,'__len__') else value,flush=True)
    if isinstance(value,list) and value:print('FIRST_ITEM_KEYS',list(value[0]) if isinstance(value[0],dict) else repr(value[0])[:200],flush=True)
papers=json.loads((R/'build/gs-4/docs/literature/omics-2023-2026/papers.json').read_bytes())
for paper in papers:
    if paper['paper_id'] in {'P077','P096','P220'}:
        print(json.dumps({k:paper[k] for k in ['paper_id','title','doi','pmcid','fulltext_url']},ensure_ascii=False),flush=True)
