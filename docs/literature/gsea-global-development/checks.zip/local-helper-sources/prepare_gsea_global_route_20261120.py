from pathlib import Path
import hashlib,json
R=Path('D:/projects/JLinAlg');T=R/'build/gs-5';O=T/'build/gsea-admission-1/dispatcher-edit-1';O.mkdir(exist_ok=False)
name='src/main/java/org/jlinalg/cli/JLinAlgCli.java';p=T/name;before=p.read_bytes()
anchor=b'            if (arguments.length > 0 && arguments[0].equals("edger-tools"))\n'
help_anchor=b'              java -jar omicsmatic-<version>.jar edger-tools --help\n'
route=b'            if (arguments.length > 0 && arguments[0].equals("broad-gsea-tools"))\n                return BroadGseaWorkflowCli.run(Arrays.copyOfRange(arguments, 1, arguments.length), output, errorOutput);\n'
help=b'              java -jar omicsmatic-<version>.jar broad-gsea-tools --help\n'
assert before.count(anchor)==before.count(help_anchor)==1 and b'"broad-gsea-tools"' not in before
after=before.replace(anchor,route+anchor,1).replace(help_anchor,help+help_anchor,1)
(O/'before.java').write_bytes(before);(O/'after.java').write_bytes(after)
p.write_bytes(after)
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
(O/'CHANGE.json').write_text(json.dumps(dict(base='8d09589e78ff758cd7b648a92357b8cebcd7748e',path=name,before=pin(before),after=pin(after),additive_lines=3,scientific_engines_changed=False),indent=2)+'\n',encoding='utf-8')
module='''"""Exact native Broad GSEA global route/help inverse; scientific components stay frozen."""
import hashlib
DISPATCH=%r
BASE='8d09589e78ff758cd7b648a92357b8cebcd7748e'
BEFORE=%r
ROUTE=%r
HELP=%r
ANCHOR=%r
HELP_ANCHOR=%r
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def require(ok,message):
    if not ok:raise ValueError(message)
def dispatcher_before(after):
    require(after.count(ROUTE)==after.count(HELP)==1,'Missing/duplicate qualified Broad GSEA route/help')
    before=after.replace(ROUTE,b'',1).replace(HELP,b'',1)
    require(pin(before)==BEFORE,'Dispatcher differs beyond the three additive Broad GSEA lines')
    require(before.count(ANCHOR)==before.count(HELP_ANCHOR)==1,'Ambiguous original edgeR anchors')
    require(after==before.replace(ANCHOR,ROUTE+ANCHOR,1).replace(HELP_ANCHOR,HELP+HELP_ANCHOR,1),'Broad GSEA lines moved outside their reviewed anchors')
    return before
'''%(name,pin(before),route,help,anchor,help_anchor)
(T/'tools/literature/gsea_dispatch_transition.py').write_text(module,encoding='utf-8',newline='\n')
print('Prepared exact additive Broad GSEA global route/help',pin(before),pin(after),flush=True)
