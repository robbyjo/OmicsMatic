from pathlib import Path
import hashlib,json,urllib.request
R=Path('D:/projects/JLinAlg');T=R/'build/gs-5';O=T/'build/gsea-admission-1/author-sources-1';O.mkdir(exist_ok=False)
def save(name,value):(O/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
def fetch(name,url,maximum):
    request=urllib.request.Request(url,headers={'User-Agent':'OmicsMatic-source-role-audit/1.0'})
    with urllib.request.urlopen(request,timeout=45) as response:
        raw=response.read(maximum+1);assert len(raw)<=maximum,'Named author source exceeds bounded intake'
        (O/name).write_bytes(raw);save(name+'.HTTP.json',dict(requested_url=url,resolved_url=response.url,status=response.status,content_type=response.headers.get('Content-Type'),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
    return raw
record=json.loads(fetch('P096-zenodo-record.json','https://zenodo.org/api/records/13321265',2_000_000));assert record['id']==13321265
for name in ['Script_19.R','Script_20.sh']:
    item=next(f for f in record['files'] if f['key']==name);raw=fetch('P096-'+name,item['links']['self'],1_000_000)
    assert item['checksum']=='md5:'+hashlib.md5(raw).hexdigest(),name
    print('\nP096 '+name+'\n'+raw.decode('utf-8-sig'),flush=True)
save('P096-CODE-IDENTITY.json',dict(record_id=record['id'],doi=record.get('doi'),license=record['metadata'].get('license'),read_only_source_audit=True,code_executed=False))
pdf='41588_2025_2397_MOESM1_ESM.pdf'
raw=fetch('P077-supplement.pdf','https://static-content.springer-cdn.com/esm/art%3A10.1038%2Fs41588-025-02397-7/MediaObjects/'+pdf,40_000_000)
assert raw.startswith(b'%PDF-'),'Not the named P077 supplementary PDF'
print('Saved exact P077 supplementary PDF',len(raw),'bytes',flush=True)
