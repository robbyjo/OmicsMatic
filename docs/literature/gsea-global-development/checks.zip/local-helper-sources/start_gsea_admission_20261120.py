from pathlib import Path
import importlib.util,json,subprocess
R=Path('D:/projects/JLinAlg');H=R/'build/gs-4';T=R/'build/gs-5';P=R/'build/git-publish/20261120-gsea-files-64'
O=R/'build/gsea-admission-start-20261120-1';O.mkdir(exist_ok=False);BASE='8d09589e78ff758cd7b648a92357b8cebcd7748e'
def git(root,*args):return subprocess.check_output(['git','--no-replace-objects',*args],cwd=root)
def save(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
assert git(H,'rev-parse','HEAD').decode().strip()==BASE and git(H,'ls-remote','origin','refs/heads/main').decode().split()[0]==BASE
previous=json.loads((P/'WORKTREES-EXPECTED.json').read_bytes());assert len(previous)==20
spec=importlib.util.spec_from_file_location('inventory',P.parent/'20261115-all-main-3/inventory.py');inv=importlib.util.module_from_spec(spec);spec.loader.exec_module(inv)
for row in previous:assert inv.snapshot(Path(row['root']))==row,row['root']
save('WORKTREES-BEFORE.json',previous);assert not T.exists()
p=subprocess.run(['git','worktree','add','-b','codex/gsea-admission-20261120',str(T),BASE],cwd=R,capture_output=True)
(O/'worktree.stdout').write_bytes(p.stdout);(O/'worktree.stderr').write_bytes(p.stderr);assert p.returncode==0
assert git(T,'rev-parse','HEAD').decode().strip()==BASE and not git(T,'status','--porcelain=v1','-z','--untracked-files=all')
(T/'build/gsea-admission-1').mkdir(parents=True)
save('COMPLETED.json',dict(status='PASS_20_EXISTING_WORKTREES_AND_NEW_GSEA_ADMISSION_CHECKOUT',base=BASE,root=str(T),worktrees=21))
print('PASS 20 preserved current worktrees; new GSEA admission checkout',T,flush=True)
