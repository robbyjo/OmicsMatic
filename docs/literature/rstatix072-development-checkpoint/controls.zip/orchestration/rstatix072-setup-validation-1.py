from pathlib import Path
import concurrent.futures,json,os,subprocess,sys,time
ROOT=Path('D:/projects/JLinAlg');BASE=ROOT/'build/literature-review/monocle-runtime';OUT=Path(__file__).with_suffix('');OUT.mkdir(exist_ok=False)
LROOT='/mnt/d/projects/JLinAlg';LBASE=LROOT+'/build/literature-review/monocle-runtime';wsl=['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','-u','root','--'];env=dict(os.environ);env['PYTHONDONTWRITEBYTECODE']='1'
def save(n,x):(OUT/n).write_text(json.dumps(x,indent=2)+'\n',encoding='utf8',newline='\n')
def run(label,command):
 command=list(map(str,command));start=time.time()
 with (OUT/(label+'.stdout')).open('xb') as so,(OUT/(label+'.stderr')).open('xb') as se:
  p=subprocess.Popen(command,cwd=ROOT,env=env,stdin=subprocess.DEVNULL,stdout=so,stderr=se);save(label+'.live.json',dict(command=command,pid=p.pid,started_unix=start));code=p.wait(timeout=600)
 row=dict(label=label,command=command,exit_code=code,elapsed_seconds=time.time()-start);save(label+'.process.json',row);print(label,'exit',code,flush=True);return row
base=BASE/'rstatix072-runtime-install-1';archive=BASE/'rstatix072-intake-1/rstatix_0.7.2.tar.gz'
commands=[('windows-refusal',[sys.executable,ROOT/'tools/literature/rstatix072/test_setup.py','--base',base,'--source-archive',archive,'--out',BASE/'rstatix072-setup-controls-windows-1']),
 ('linux-refusals',wsl+['/usr/bin/python3',LROOT+'/tools/literature/rstatix072/test_setup.py','--base',LBASE+'/rstatix072-runtime-install-1','--source-archive',LBASE+'/rstatix072-intake-1/rstatix_0.7.2.tar.gz','--out',LBASE+'/rstatix072-setup-controls-linux-1']),
 ('actual-public-download-setup',wsl+['/usr/bin/python3',LROOT+'/tools/literature/rstatix072/provider.py','--base',LBASE+'/rstatix072-runtime-install-1','--allow-download','--allow-install','--out',LBASE+'/rstatix072-public-download-provider-1'])]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(lambda x:run(*x),commands))
save('PROCESSES.json',results);assert all(r['exit_code']==0 for r in results),results
save('COMPLETED.json',dict(status='PASS_RSTATIX_ORIGINAL_PUBLIC_DOWNLOAD_SETUP_AND_SEVEN_PREREQUISITE_REFUSALS',calls=results,whole_goal_complete=False,new_tool_credit=0))
