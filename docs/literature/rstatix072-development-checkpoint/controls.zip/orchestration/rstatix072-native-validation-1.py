from pathlib import Path
import concurrent.futures,json,os,subprocess,sys,time
ROOT=Path('D:/projects/JLinAlg');BASE=ROOT/'build/literature-review/monocle-runtime';OUT=Path(__file__).with_suffix('');OUT.mkdir(exist_ok=False)
LROOT='/mnt/d/projects/JLinAlg';LBASE=LROOT+'/build/literature-review/monocle-runtime';wsl=['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','-u','root','--']
env=dict(os.environ);env['PYTHONDONTWRITEBYTECODE']='1'
def save(n,x):(OUT/n).write_text(json.dumps(x,indent=2)+'\n',encoding='utf8',newline='\n')
def run(label,command):
 command=list(map(str,command));start=time.time()
 with (OUT/(label+'.stdout')).open('xb') as so,(OUT/(label+'.stderr')).open('xb') as se:
  p=subprocess.Popen(command,cwd=ROOT,env=env,stdin=subprocess.DEVNULL,stdout=so,stderr=se);save(label+'.live.json',dict(command=command,pid=p.pid,started_unix=start));code=p.wait(timeout=600)
 result=dict(label=label,command=command,exit_code=code,elapsed_seconds=time.time()-start);save(label+'.process.json',result);print(label,'exit',code,flush=True);return result
ref=run('original-reference',wsl+[LBASE+'/rstatix072-runtime-install-1/.pixi/envs/default/bin/Rscript','--vanilla',LROOT+'/tools/literature/rstatix072/OriginalLeveneControl.R',LBASE+'/rstatix072-provider-2',LBASE+'/rstatix072-levene-fixtures-2/request.json',LBASE+'/rstatix072-original-levene-reference-2']);assert ref['exit_code']==0
for n in ['w21','w25','l21']:assert (BASE/('rstatix072-native-build-'+n+'-1/BUILD.json')).is_file(),n
commands=[]
for name,jdk in [('w21','C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin'),('w25','C:/Program Files/Java/jdk-25/bin')]:
 commands.append((name,[sys.executable,'-X','utf8',ROOT/'tools/literature/rstatix072/test_native.py','--java-bin',jdk,'--jar',BASE/('rstatix072-native-build-'+name+'-1/levene-native-development.jar'),'--fixtures',BASE/'rstatix072-levene-fixtures-2','--reference',BASE/'rstatix072-original-levene-reference-2','--out',BASE/('rstatix072-native-controls-'+name+'-1')]))
commands.append(('l21',wsl+['/usr/bin/python3',LROOT+'/tools/literature/rstatix072/test_native.py','--java-bin','/usr/lib/jvm/java-21-openjdk-amd64/bin','--jar',LBASE+'/rstatix072-native-build-l21-1/levene-native-development.jar','--fixtures',LBASE+'/rstatix072-levene-fixtures-2','--reference',LBASE+'/rstatix072-original-levene-reference-2','--out',LBASE+'/rstatix072-native-controls-l21-1']))
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(lambda x:run(*x),commands))
save('PROCESSES.json',[ref,*results]);assert all(x['exit_code']==0 for x in results),results
save('COMPLETED.json',dict(status='PASS_NATIVE_LEVENE_THREE_CONTROLLER_PLATFORMS_AND_COMPLETE_ORIGINAL_REFERENCE',calls=[ref,*results],whole_goal_complete=False,new_tool_credit=0))
