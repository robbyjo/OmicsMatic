from pathlib import Path
import hashlib,json,shutil,subprocess,sys,zipfile
ROOT=Path('D:/projects/JLinAlg');BASE=ROOT/'build/literature-review/monocle-runtime';OUT=Path(__file__).with_suffix('');OUT.mkdir(exist_ok=False)
sys.path.insert(0,str(ROOT/'tools/literature'))
from qupath_catalog.model import META
def pin(path):
 raw=path.read_bytes();return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf8',newline='\n')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()=='9f85d4d204b148946cdccc5510b9eb8b88b6321e'
baseline=json.loads((BASE/'qupath-catalog-preflight-1/COMPLETED.json').read_bytes())
for row in baseline['protected']+[baseline['canonical']]:assert pin(ROOT/row['path'])=={k:row[k] for k in ['bytes','sha256']},row['path']
for n in META:assert subprocess.check_output(['git','show','HEAD:'+n],cwd=ROOT)==(ROOT/n).read_bytes(),n
assert json.loads((BASE/'rstatix072-native-validation-1/COMPLETED.json').read_bytes())['status']=='PASS_NATIVE_LEVENE_THREE_CONTROLLER_PLATFORMS_AND_COMPLETE_ORIGINAL_REFERENCE'
assert json.loads((BASE/'rstatix072-setup-validation-1/COMPLETED.json').read_bytes())['status']=='PASS_RSTATIX_ORIGINAL_PUBLIC_DOWNLOAD_SETUP_AND_SEVEN_PREREQUISITE_REFUSALS'
DATA=ROOT/'docs/literature/rstatix072-development-checkpoint';DATA.mkdir(exist_ok=False);(DATA/'.gitattributes').write_text('* -text whitespace=cr-at-eol\n',encoding='ascii',newline='\n')
artifacts={}
for platform,folder in [('windows21','w21'),('windows25','w25'),('linux21','l21')]:
 source=BASE/('rstatix072-native-build-'+folder+'-1/levene-native-development.jar');dest=DATA/('levene-native-'+platform+'-development.jar');shutil.copyfile(source,dest);artifacts[dest.relative_to(ROOT).as_posix()]=pin(dest)
save(DATA/'ARTIFACTS.json',artifacts);shutil.copyfile(BASE/'rstatix072-intake-1/CENSUS.json',DATA/'CENSUS.json')
sources=[p for p in sorted((ROOT/'tools/literature/rstatix072').rglob('*')) if p.is_file() and '__pycache__' not in p.parts]
sources += [ROOT/'src/main/java/org/jlinalg/stats/LeveneTest.java',ROOT/'src/main/java/org/jlinalg/cli/LeveneTestCli.java',ROOT/'docs/literature/RSTATIX072_DEVELOPMENT.md',ROOT/'LICENSE',ROOT/'tools/literature/collect_omics_review.py']
sources += [ROOT/'src/main/java/org/jlinalg/cli'/(n+'.java') for n in ['SimpleJson','NextflowJson','NextflowParameters']]
source_pins={p.relative_to(ROOT).as_posix():pin(p) for p in sources};members={};omissions=[]
def add(path,name):
 assert path.is_file() and not path.is_symlink() and name not in members,name;members[name]=path
def tree(path,prefix,exclude=()):
 assert path.is_dir(),path
 for p in sorted(path.rglob('*')):
  relative=p.relative_to(path)
  if any(relative.parts[0]==x for x in exclude):continue
  if p.is_file():add(p,prefix+'/'+relative.as_posix())
for source in sources:add(source,'current-source/'+source.relative_to(ROOT).as_posix())
for platform,folder in [('windows21','w21'),('windows25','w25'),('linux21','l21')]:
 tree(BASE/('rstatix072-native-build-'+folder+'-1'),'builds/'+platform)
 tree(BASE/('rstatix072-native-controls-'+folder+'-1'),'native/'+platform)
tree(BASE/'rstatix072-levene-fixtures-1','fixtures-before-positive-run')
tree(BASE/'rstatix072-levene-fixtures-2','fixtures')
for n in [1,2]:tree(BASE/('rstatix072-original-levene-reference-'+str(n)),'original/reference-'+str(n))
for folder,name in [('rstatix072-provider-1','failed-export-order'),('rstatix072-provider-2','local-ready'),('rstatix072-public-download-provider-1','public-download-ready')]:tree(BASE/folder,'providers/'+name)
tree(BASE/'rstatix072-setup-controls-windows-1','setup/windows');tree(BASE/'rstatix072-setup-controls-linux-1','setup/linux')
for folder in ['rstatix072-native-validation-1','rstatix072-setup-validation-1']:tree(BASE/folder,'processes/'+folder)
for p in sorted((BASE/'rstatix072-intake-1').iterdir()):
 if p.is_file() and p.name!='PRIMARY_PARAGRAPHS.json':add(p,'intake/'+p.name)
omissions.append(dict(path='rstatix072-intake-1/PRIMARY_PARAGRAPHS.json',reason='Private complete primary paragraph text; public evidence retains exact identities/hashes/sections and individual source summaries.',file=pin(BASE/'rstatix072-intake-1/PRIMARY_PARAGRAPHS.json')))
runtime=BASE/'rstatix072-runtime-install-1'
for p in sorted(runtime.iterdir()):
 if p.is_file():add(p,'runtime-install/'+p.name)
omissions.append(dict(path='rstatix072-runtime-install-1/.pixi, pixi-cache, pixi-home and tmp',reason='Private installed dependency runtime/package caches; exact manifest/lock, original install diagnostics and provider dependency metadata are retained. No scientific control input/output is omitted.'))
for name in ['rstatix072-runtime-install-1.py','rstatix072-native-validation-1.py','rstatix072-setup-validation-1.py','rstatix072-checkpoint-1.py']:add(BASE/name,'orchestration/'+name)
# The first reference was observed through the tool stream; a fresh second run retains separate raw stdout/stderr.
observed=dict(status='OBSERVED_TOOL_RESULT_NOT_SEPARATE_RAW_PROCESS_FILES',reference='original/reference-1',exit_code=0,reported_output='COMPLETE_LEVENE_CASES 206\nORIGINAL WARNING ANOVA F-tests on an essentially perfect fit are unreliable\nORIGINAL WARNING ANOVA F-tests on an essentially perfect fit are unreliable\n[1] TRUE\nPASS_COMPLETE_ORIGINAL_RSTATIX072_LEVENE_REFERENCE cases=206\n',same_scientific_request_bytes=(BASE/'rstatix072-levene-fixtures-1/request.json').read_bytes()==(BASE/'rstatix072-levene-fixtures-2/request.json').read_bytes(),separate_complete_raw_process_logs='processes/rstatix072-native-validation-1/original-reference.stdout and original-reference.stderr')
save(OUT/'FIRST_REFERENCE_TOOL_OBSERVATION.json',observed);add(OUT/'FIRST_REFERENCE_TOOL_OBSERVATION.json','original/FIRST_REFERENCE_TOOL_OBSERVATION.json')
with zipfile.ZipFile(DATA/'controls.zip','x',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for name,p in sorted(members.items()):
  info=zipfile.ZipInfo(name,(2026,11,13,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;archive.writestr(info,p.read_bytes())
layout=dict(status='COMPLETE_RETAINED_RSTATIX_SOURCE_PROVIDER_NATIVE_CONTROL_AND_DIAGNOSTIC_FILES',files={n:pin(p) for n,p in sorted(members.items())},explicit_private_dependency_or_primary_text_omissions=omissions,scientific_control_inputs_or_outputs_omitted=False)
save(DATA/'CONTROLS_LAYOUT.json',layout)
validation=dict(status='PASS_NATIVE_LEVENE_AND_ORIGINAL_RSTATIX072_PROVIDER_DEVELOPMENT_CHECKPOINT',sources=source_pins,artifacts=artifacts,
 archive=pin(DATA/'controls.zip'),controls_layout=pin(DATA/'CONTROLS_LAYOUT.json'),complete_archive_files=len(members),main_catalog_files={n:pin(ROOT/n) for n in META},
 complete_cases_per_platform=206,computed_cases_per_platform=196,original_scalar_comparisons_per_platform=784,native_refusals_per_platform=10,
 public_API_checks_per_platform=29,CLI_refusals_per_platform=6,original_rstatix_version='0.7.2',original_R_version='4.5.3',original_car_version='3.1-5',
 original_source_files=166,original_source_functions_checked=339,original_exports=126,private_installs_executed=3,ready_providers=2,public_download_installs=1,setup_refusal_controls=7,
 reviewed_primary_papers=6,named_primary_anchors=12,original_source_modified=False,main_catalog_modified=False,canonical_unchanged=True,unfinished_files_preserved=23,
 first_failed_provider_retained=True,original_near_perfect_fit_warning_and_huge_statistic_retained=True,native_Levene_independent_mathematical_implementation=True,
 original_supervised_analysis_adapter_completed=False,whole_rstatix_qualified=False,paper_reproduced=False,new_tool_credit=0,whole_goal_complete=False,previous_goal_turn_classification='progress')
save(DATA/'VALIDATION.json',validation)
(DATA/'SHA256SUMS').write_text(''.join(pin(DATA/n)['sha256']+'  '+n+'\n' for n in ['controls.zip','CONTROLS_LAYOUT.json','ARTIFACTS.json','CENSUS.json','VALIDATION.json']),encoding='ascii',newline='\n')
for row in baseline['protected']+[baseline['canonical']]:assert pin(ROOT/row['path'])=={k:row[k] for k in ['bytes','sha256']},row['path']
save(OUT/'COMPLETED.json',dict(status=validation['status'],complete_members=len(members),archive=validation['archive'],sources=len(source_pins),new_tool_credit=0,main_catalog_unchanged=True));print(json.dumps(dict(status=validation['status'],complete_members=len(members),archive=validation['archive'],sources=len(source_pins))),flush=True)
