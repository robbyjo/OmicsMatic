from pathlib import Path
import json,os,subprocess,time
BASE=Path('/mnt/d/projects/JLinAlg/build/literature-review/monocle-runtime');OUT=BASE/'rstatix072-runtime-install-1';OUT.mkdir(exist_ok=False)
manifest=OUT/'pixi.toml';manifest.write_text('''[workspace]
name = "rstatix072-original-reference"
version = "0.1.0"
channels = ["conda-forge"]
platforms = ["linux-64"]

[dependencies]
r-base = "==4.5.3"
r-car = "*"
r-corrplot = "*"
r-broom = "*"
r-tidyr = "*"
r-purrr = "*"
r-rlang = "*"
r-tibble = "*"
r-dplyr = "*"
r-magrittr = "*"
r-tidyselect = "*"
r-generics = "*"
r-jsonlite = "*"
r-emmeans = "*"
r-coin = "*"
''',encoding='utf8')
env=dict(os.environ);env.update(PIXI_NO_PATH_UPDATE='1',PIXI_HOME=str(OUT/'pixi-home'),PIXI_CACHE_DIR=str(OUT/'pixi-cache'),TMPDIR=str(OUT/'tmp'));(OUT/'tmp').mkdir()
command=[str(BASE.parent/'saige-runtime/pixi-bootstrap-1/pixi'),'install','--manifest-path',str(manifest)]
start=time.time()
with (OUT/'install.stdout').open('xb') as so,(OUT/'install.stderr').open('xb') as se:
 p=subprocess.Popen(command,cwd=OUT,env=env,stdin=subprocess.DEVNULL,stdout=so,stderr=se)
 (OUT/'LIVE.json').write_text(json.dumps(dict(command=command,pid=p.pid,started_unix=start),indent=2)+'\n')
 while True:
  try:code=p.wait(timeout=30);break
  except subprocess.TimeoutExpired:print('SAME_INSTALL_RUNNING',p.pid,round(time.time()-start),'seconds',flush=True)
row=dict(command=command,exit_code=code,elapsed_seconds=time.time()-start)
(OUT/'process.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True)
raise SystemExit(code)
