from pathlib import Path
import hashlib,json,shutil,subprocess,sys,time,zipfile
ROOT=Path('D:/projects/JLinAlg');BASE=ROOT/'build/literature-review/monocle-runtime';OUT=Path(__file__).with_suffix('');OUT.mkdir(exist_ok=False)
DATA='docs/literature/rstatix072-development-checkpoint';original=ROOT/DATA;proof=json.loads((original/'VALIDATION.json').read_bytes())
def rawpin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def pin(p):return rawpin(p.read_bytes())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8',newline='\n')
before={p.name:pin(p) for p in original.iterdir() if p.is_file()};calls=[]
for case in ['changed-current-source','missing-artifact','resealed-native-statistic','resealed-missing-native-case']:
 scope=OUT/case;scope.mkdir();root=scope/'repo';root.mkdir();assert root.resolve().is_relative_to(BASE.resolve())
 for name in proof['sources']:
  target=root/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/name,target)
 data=root/DATA;data.mkdir(parents=True,exist_ok=True);shutil.copyfile(original/'VALIDATION.json',data/'VALIDATION.json')
 if case=='changed-current-source':
  target=root/'src/main/java/org/jlinalg/stats/LeveneTest.java';target.write_bytes(target.read_bytes()+b'\n// Deliberately changed isolated refusal-control source.\n')
 elif case=='missing-artifact':pass
 else:
  for name in proof['main_catalog_files']:
   target=root/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/name,target)
  for p in original.iterdir():
   if p.is_file():shutil.copyfile(p,data/p.name)
  with zipfile.ZipFile(data/'controls.zip') as archive:members={n:archive.read(n) for n in archive.namelist()}
  prefix='native/windows21/mixed-complete/';name=prefix+'cases.json';rows=json.loads(members[name])
  if case=='resealed-native-statistic':rows[0]['statistic']+=1
  else:rows.pop(0)
  members[name]=(json.dumps(rows,ensure_ascii=False)+'\n').encode('utf8')
  manifest=json.loads(members[prefix+'MANIFEST.json']);manifest['files']['cases.json']=rawpin(members[name]);members[prefix+'MANIFEST.json']=(json.dumps(manifest)+'\n').encode()
  layout=json.loads((data/'CONTROLS_LAYOUT.json').read_bytes())
  for n in [name,prefix+'MANIFEST.json']:layout['files'][n]=rawpin(members[n])
  rebuilt=scope/'deliberately-resealed-controls.zip'
  with zipfile.ZipFile(rebuilt,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
   for n,raw in members.items():archive.writestr(n,raw)
  shutil.copyfile(rebuilt,data/'controls.zip');save(data/'CONTROLS_LAYOUT.json',layout);v=json.loads((data/'VALIDATION.json').read_bytes());v['archive']=pin(data/'controls.zip');v['controls_layout']=pin(data/'CONTROLS_LAYOUT.json');save(data/'VALIDATION.json',v)
  (data/'SHA256SUMS').write_text(''.join(pin(data/n)['sha256']+'  '+n+'\n' for n in ['controls.zip','CONTROLS_LAYOUT.json','ARTIFACTS.json','CENSUS.json','VALIDATION.json']),encoding='ascii',newline='\n')
  (scope/'deliberately-forged-cases.json').write_bytes(members[name])
 command=list(map(str,[sys.executable,root/'tools/literature/rstatix072/verify.py','--out',root/'build/literature-review/monocle-runtime/verify-control']));start=time.time();r=subprocess.run(command,stdin=subprocess.DEVNULL,capture_output=True,timeout=180);expected=3 if case=='missing-artifact' else 2
 (scope/'process.stdout').write_bytes(r.stdout);(scope/'process.stderr').write_bytes(r.stderr);row=dict(case=case,command=command,exit_code=r.returncode,expected_exit=expected,elapsed_seconds=time.time()-start);calls.append(row);save(scope/'process.json',row)
 assert r.returncode==expected,row
 diagnostic=json.loads((root/'build/literature-review/monocle-runtime/verify-control/FAILURE.json').read_bytes())
 wanted={'changed-current-source':'Current checkpoint source/artifact/catalog differs','missing-artifact':None,'resealed-native-statistic':'Complete original scalar differs','resealed-missing-native-case':'Incomplete native scientific cases'}[case]
 assert wanted is None or wanted in diagnostic['cause'],(case,diagnostic['cause'])
 print(case,'refused',flush=True)
assert all(pin(original/n)==wanted for n,wanted in before.items()),'Actual checkpoint changed'
save(OUT/'COMPLETED.json',dict(status='PASS_FROZEN_RSTATIX_CHECKPOINT_SOURCE_ARTIFACT_AND_RESEALED_NATIVE_RESULT_REFUSALS',controls=4,calls=calls,actual_qualified_data_unchanged=True,original_analysis_executed=False))
