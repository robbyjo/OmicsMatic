
# FAIL2 — NO RESULT ADMITTED

java.io.IOException: Complete ordered nominal-P feature IDs differ

Required action: require exit0, top-level COMPLETED.json and successful --verify before dependent analysis. Read WARNINGS.md and native/WARNINGS.md. EMPTY_SELECTED_POPULATION and UNDEFINED_SELECTED_RATIO are NA sharing estimates, never zero or biological nonreplication. Marginal sign-score products are not joint probabilities, Pr(nonzero), or proof of equal effect directions. Unsupported formal tests are SKIP3: skip that requested analysis; use an explicitly supported mode or a separately validated method. FAIL2 means invalid input, integrity, numerical, capacity, cancellation or finalization failure: preserve inputs, partial outputs and diagnostics, correct the named cause or explicitly increase permitted limits/heap, then retry into NEW paths. No missing values, P values or method choices are inferred. SHA-256 establishes integrity, not authenticity; no biological accuracy or whole-paper reproduction is certified.
