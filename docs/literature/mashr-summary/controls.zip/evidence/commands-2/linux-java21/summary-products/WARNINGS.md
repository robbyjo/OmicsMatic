# Verified native mash posterior summaries

Significance counts use the explicitly requested STRICT boundary. Pairwise source sharing always selects LFSR strictly below threshold, uses strict ratio inequalities, and mirrors the upper triangle.

These summaries use retained posterior tables after full native replay. Native replay has its own documented numerical tolerances; it does not authenticate execution history. Read native/WARNINGS.md and every retained fit warning, including residual rollback.

All summary identities, discrete states, counts, fractions and rounded products replay exactly. Only finite log-product values use absolute1e-12 plus relative1e-12 tolerance; nonpositive log domain and exact-zero states remain enforced.

Marginal sign products enabled: true. Nominal P values and group membership are explicit independent inputs. Products can be high for opposite estimated effect directions. Exact-zero log products are -Inf; underflow has a separate state and finite log score.

Empty pairwise cells: 0; undefined selected-ratio cells: 0; underflow scores: 0. NA fractions are retained without dropping their denominator rows.

Required action: require exit0, top-level COMPLETED.json and successful --verify before dependent analysis. Read WARNINGS.md and native/WARNINGS.md. EMPTY_SELECTED_POPULATION and UNDEFINED_SELECTED_RATIO are NA sharing estimates, never zero or biological nonreplication. Marginal sign-score products are not joint probabilities, Pr(nonzero), or proof of equal effect directions. Unsupported formal tests are SKIP3: skip that requested analysis; use an explicitly supported mode or a separately validated method. FAIL2 means invalid input, integrity, numerical, capacity, cancellation or finalization failure: preserve inputs, partial outputs and diagnostics, correct the named cause or explicitly increase permitted limits/heap, then retry into NEW paths. No missing values, P values or method choices are inferred. SHA-256 establishes integrity, not authenticity; no biological accuracy or whole-paper reproduction is certified.
