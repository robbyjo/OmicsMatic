param([string]$AliasPath,[string]$TargetPath)
if (Test-Path -LiteralPath $AliasPath) { throw 'Preserve existing alias' }
New-Item -ItemType Junction -Path $AliasPath -Target $TargetPath -ErrorAction Stop | Out-Null
