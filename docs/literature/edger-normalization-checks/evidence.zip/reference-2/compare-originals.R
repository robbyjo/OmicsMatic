args<-commandArgs(TRUE)
a<-readRDS(args[1]);b<-readRDS(args[2])
stopifnot(identical(a$datasets,b$datasets),identical(a$normalization_returns,b$normalization_returns),
    identical(a$RNG_before,b$RNG_before),identical(a$RNG_after,b$RNG_after))
take<-function(r)r[c("name","values","warnings","messages","gene_lengths")]
stopifnot(identical(lapply(a$reference$transforms,take),lapply(b$reference$transforms,take)))
cat("PASS original inputs, all 2350 model returns, 552 transform outputs, conditions and RNG unchanged; only exported input decimals corrected\n")
