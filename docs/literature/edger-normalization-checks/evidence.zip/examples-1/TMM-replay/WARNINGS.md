# Native edgeR warnings and required actions

Native Java edgeR matrix normalization/CPM/RPKM only; no dispersion fitting, differential tests, offsets, S4 objects or automatic upstream fallback. Source-built standalone component; no whole-tool or paper reproduction.



SKIP3: supply the named permitted exact input/edition or keep dependent analysis skipped. FAIL2: NO COMPLETE RESULT; preserve inputs, partials and diagnostics, resolve the named cause and retry a NEW output. Never repair identifiers or non-finite values silently.
