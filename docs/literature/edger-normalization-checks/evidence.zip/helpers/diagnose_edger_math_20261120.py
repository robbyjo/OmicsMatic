from pathlib import Path
import hashlib,json,subprocess,urllib.request,xml.etree.ElementTree as ET
E=Path('D:/projects/JLinAlg/build/edge-1');B=E/'build/edger-high-impact-1';O=B/'math-source-1';O.mkdir(exist_ok=False)
sha=subprocess.check_output(['git','ls-remote','https://github.com/JuliaMath/openlibm.git','refs/tags/v0.8.7','refs/tags/v0.8.7^{}'],text=True).splitlines()
rows=[line.split() for line in sha];commit=next((a for a,b in rows if b.endswith('^{}')),rows[0][0]);records={}
for name in ['src/e_log2.c','src/k_log.h','LICENSE.md']:
    url='https://raw.githubusercontent.com/JuliaMath/openlibm/'+commit+'/'+name
    with urllib.request.urlopen(url,timeout=60) as response:raw=response.read(1_000_001)
    assert len(raw)<=1_000_000;p=O/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
    records[name]=dict(url=url,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
(O/'SOURCES.json').write_text(json.dumps(dict(tag='v0.8.7',commit=commit,files=records),indent=2)+'\n')
print('Pinned source',commit);print((O/'src/k_log.h').read_text())
root=ET.parse(B/'preflight-1/reports/TEST-junit-jupiter.xml').getroot();cases=[]
for t in root.findall('testcase'):
    if t.find('failure') is not None:
        out=t.findtext('system-out','');cases.append(dict(name=t.get('name'),out=out,failure=t.find('failure').get('message')))
(O/'FAILED-CASES.json').write_text(json.dumps(cases,indent=2)+'\n')
print('First failed source checks',json.dumps(cases[:3],indent=2))
