from pathlib import Path
import hashlib,json,os,subprocess,sys,xml.etree.ElementTree as ET
R=Path('D:/projects/JLinAlg');A=R/'build/high-impact-stats-1';E=R/'build/edge-1';B=E/'build/edger-high-impact-1';O=B/'preflight-1';O.mkdir(exist_ok=False)
jdk=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin');jar=A/'build/susie-dispatch-1/workflow-gradle-2/project-build/cli/omicsmatic-0.4.0.jar'
junit=A/'build/nfcore-atacseq121-1/linux-test-runtime-1/junit-platform-console-standalone-1.13.4.jar'
classes=O/'classes';classes.mkdir();reports=O/'reports';reports.mkdir()
sources=[E/n for n in ['src/main/java/org/jlinalg/differential/EdgeRNormalization.java','src/test/java/org/jlinalg/cli/EdgeRNormalizationTest.java','src/test/java/org/jlinalg/differential/EmpiricalBayesDifferentialTest.java']]
commands=[('javac',[str(jdk/'javac.exe'),'--release','21','-encoding','UTF-8','-cp',str(jar)+os.pathsep+str(junit),'-d',str(classes),*map(str,sources)]),
    ('test',[str(jdk/'java.exe'),'-Xmx2g','-Domicsmatic.edger.reference.audit='+str(O/'NUMERICS.json'),'-jar',str(junit),'execute','--disable-banner','--details=summary','--reports-dir',str(reports),'--class-path',os.pathsep.join(map(str,[classes,jar,E/'src/test/resources'])),
        '--select-class','org.jlinalg.cli.EdgeRNormalizationTest','--select-class','org.jlinalg.differential.EmpiricalBayesDifferentialTest'])]
(O/'COMMANDS.json').write_text(json.dumps(dict(commands=commands,producer_scope='Preflight candidate classes before full normal Gradle build',sources={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}),indent=2)+'\n')
for name,command in commands:
    with (O/(name+'.stdout')).open('xb') as so,(O/(name+'.stderr')).open('xb') as se:p=subprocess.run(command,cwd=E,stdout=so,stderr=se,timeout=180)
    print(name,p.returncode,flush=True);print((O/(name+'.stdout')).read_text(errors='replace')[-6000:]);print((O/(name+'.stderr')).read_text(errors='replace')[-2500:]);assert p.returncode==0
suites=[ET.fromstring(p.read_bytes()) for p in reports.glob('*.xml')];totals={k:sum(int(s.get(k,0)) for s in suites) for k in ['tests','errors','failures','skipped']}
assert totals['tests']>=2910 and all(totals[k]==0 for k in ['errors','failures','skipped'])
(O/'COMPLETED.json').write_text(json.dumps(dict(status='PASS_NATIVE_EDGER_ORIGINAL_REFERENCES_AND_EXISTING_DIFFERENTIAL_PREFLIGHT',totals=totals,numerics=json.loads((O/'NUMERICS.json').read_bytes())),indent=2)+'\n');print(totals,flush=True)
