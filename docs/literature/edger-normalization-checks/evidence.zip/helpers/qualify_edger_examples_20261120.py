from pathlib import Path
import concurrent.futures,json,os,subprocess
R=Path('D:/projects/JLinAlg');E=R/'build/edge-1';B=E/'build/edger-high-impact-1';O=B/'examples-1';O.mkdir(exist_ok=False)
jar=B/'workflow-gradle-2/project-build/cli/omicsmatic-0.4.0.jar';java='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe';main='org.jlinalg.cli.EdgeRNormalizationCli'
def enc(v):return (json.dumps(v,indent=2)+'\n').encode()
def process(name,command,expected,env=None):
    with (O/(name+'.stdout')).open('xb') as so,(O/(name+'.stderr')).open('xb') as se:p=subprocess.run(command,cwd=E,env=env,stdout=so,stderr=se,timeout=180)
    row=dict(name=name,command=command,exit_code=p.returncode,expected=expected);(O/(name+'.PROCESS.json')).write_bytes(enc(row));assert p.returncode==expected,(name,(O/(name+'.stderr')).read_text(errors='replace'));return row
native_env=dict(os.environ,PATH='',R_HOME=str(O/'R-not-present'),R_LIBS_USER=str(O/'R-not-present'))
records=[];captures={}
for file,label in [('request.json','TMM'),('log-rpkm.json','TMMwsp')]:
    request=json.loads((E/'examples/edger-native'/file).read_bytes())
    for field in ['counts','libraries','gene_lengths']:
        if field in request:request[field]=str(E/'examples/edger-native'/request[field])
    capture=O/label;request['out']=str(capture);path=O/(label+'.json');path.write_bytes(enc(request));captures[label]=capture
    records.append(process(label,[java,'-cp',str(jar),main,'--request',str(path)],0,native_env));records.append(process('verify-'+label,[java,'-cp',str(jar),main,'--verify',str(capture)],0,native_env))
replay=O/'replay.json';replay.write_bytes(enc(dict(schema_version=1,mode='REPLAY',analysis=str(captures['TMM']),out=str(O/'TMM-replay'))))
records.append(process('replay',[java,'-cp',str(jar),main,'--request',str(replay)],0,native_env));assert (O/'TMM-replay/expression.tsv').read_bytes()==(captures['TMM']/'expression.tsv').read_bytes()
libs=O/'libraries.txt';libs.write_text(str(B/'runtime-3.42.4-1/R-lib')+'\n'+(R/'build/literature-review/monocle-runtime/idep244-adopted-provider-4/libraries-requested.txt').read_text())
records.append(process('original',['C:/Program Files/R/R-4.6.1/bin/Rscript.exe','--vanilla',str(E/'examples/edger-native/compare-original.R'),str(E/'examples/edger-native'),str(O/'original'),str(libs)],0,dict(os.environ,LC_ALL='C',LANG='C')))
maximum=scaled=0;compared=0
for label,capture in captures.items():
    original=json.loads((O/'original'/(label+'.json')).read_bytes());rows=[line.split('\t') for line in (capture/'expression.tsv').read_text().splitlines()]
    assert rows[0][1:]==original['samples'] and [row[0] for row in rows[1:]]==original['features']
    actual=[[float(v) for v in row[1:]] for row in rows[1:]]
    for source,current in zip(original['values'],actual,strict=True):
        for s,a in zip(source,current,strict=True):
            value=float(s);error=abs(value-a);maximum=max(maximum,error);scaled=max(scaled,error/max(1,abs(value)));compared+=1;assert error<=4e-13*max(1,abs(value)),(label,s,a)
    factors=[float(row.split('\t')[2]) for row in (capture/'normalization.tsv').read_text().splitlines()[1:]]
    assert all(abs(a-float(s))<=4e-13*max(1,abs(float(s))) for a,s in zip(factors,original['factors'],strict=True))
record=dict(status='PASS_NORMAL_JAR_NATIVE_EXAMPLES_WITHOUT_R_AND_INDEPENDENT_ORIGINAL_COMPOSITIONS',original_package='edgeR 3.42.4',original_host='Windows R4.6.1',native_R_absent_from_PATH=True,
    pipelines=2,actual_native_replays=1,numeric_values_compared=compared,maximum_absolute_error=maximum,maximum_scaled_error=scaled,processes=records,whole_paper_reproduced=False)
(O/'COMPLETED.json').write_bytes(enc(record));print(json.dumps({k:v for k,v in record.items() if k!='processes'},indent=2),flush=True)
