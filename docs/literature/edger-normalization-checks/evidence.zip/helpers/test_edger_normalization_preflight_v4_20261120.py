from pathlib import Path
p=Path('D:/projects/JLinAlg/build/test_edger_normalization_preflight_20261120.py');source=p.read_text()
assert "O=B/'preflight-1'" in source;source=source.replace("O=B/'preflight-1'","O=B/'preflight-4'")
old="['src/main/java/org/jlinalg/differential/EdgeRNormalization.java'";assert old in source
source=source.replace(old,"['src/main/java/org/jlinalg/cli/EdgeRNormalizationCli.java','src/test/java/org/jlinalg/cli/EdgeRNormalizationCliTest.java','src/main/java/org/jlinalg/differential/EdgeRLog2.java','src/main/java/org/jlinalg/differential/EdgeRNormalization.java'")
old="'--select-class','org.jlinalg.cli.EdgeRNormalizationTest'";assert old in source
source=source.replace(old,"'--select-class','org.jlinalg.cli.EdgeRNormalizationCliTest',"+old)
source=source.replace("for name,command in commands:","import zipfile\nwith zipfile.ZipFile(O/'source-before.zip','x',compression=zipfile.ZIP_DEFLATED) as z:\n    for p in sources:z.writestr(p.relative_to(E).as_posix(),p.read_bytes())\nfor name,command in commands:")
exec(compile(source,__file__+'-FILE-WORKFLOW','exec'))
