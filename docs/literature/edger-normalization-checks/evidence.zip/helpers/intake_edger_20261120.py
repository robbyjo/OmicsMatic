from pathlib import Path
import concurrent.futures,gzip,hashlib,json,re,sys,tarfile,traceback,urllib.error,urllib.request,xml.etree.ElementTree as ET
R=Path('D:/projects/JLinAlg');E=R/'build/edge-1';B=E/'build/edger-high-impact-1';O=B/'source-intake-1';O.mkdir(exist_ok=False)
sys.dont_write_bytecode=True;sys.path.insert(0,str(E/'tools/literature'))
from collect_omics_review import paragraphs
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def encoded(v):return (json.dumps(v,indent=2,ensure_ascii=False)+'\n').encode()
pattern=re.compile(r'(?<![A-Za-z0-9_])(?:edgeR|calcNormFactors|filterByExpr|glmQLFit|glmQLFTest|exactTest)(?![A-Za-z0-9_])',re.I)
papers=json.loads((E/'docs/literature/omics-2023-2026/papers.json').read_bytes());hits=[]
for p in papers:
    with gzip.open(R/'build/literature-review/xml'/(p['pmcid']+'.xml.gz'),'rb') as f:raw=f.read()
    assert pin(raw)['sha256']==p['xml_sha256']
    selected=[b for b in paragraphs(ET.fromstring(raw)) if pattern.search(b.get('match_text',b['text']))]
    if selected:hits.append(dict(paper_id=p['paper_id'],doi=p['doi'],existing_edger_observation=any(t['tool_id']=='edger' for t in p['tools']),paragraphs=selected))
(O/'EDGE-HITS-PRIVATE.json').write_bytes(encoded(hits))
previous=json.loads((B/'EDGE-HITS-PRIVATE.json').read_bytes());print('Case-insensitive full-cohort census',len(hits),'papers; first case-sensitive scan retained',len(previous),flush=True)
for p in hits:
    if p['paper_id'] not in {x['paper_id'] for x in previous}:
        print(p['paper_id'],p['doi'],flush=True)
        for b in p['paragraphs']:print(' paragraph',b['paragraph_index'],b['text'],flush=True)
versions={'3.22.3':'3.7','3.32.1':'3.12','3.36.0':'3.14','3.40.2':'3.16','3.42.4':'3.17','4.10.7':'3.23'}
def get(item):
    version,bioc=item;folder=O/version;folder.mkdir();records=[]
    for stem in ['https://bioconductor.org/packages/'+bioc+'/bioc/src/contrib/','https://bioconductor.org/packages/'+bioc+'/bioc/src/contrib/Archive/edgeR/']:
        url=stem+'edgeR_'+version+'.tar.gz'
        try:
            with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'OmicsMatic-source-qualification'}),timeout=90) as response:
                raw=response.read(16*1024*1024+1);final_url=response.url
            assert len(raw)<=16*1024*1024
            path=folder/('edgeR_'+version+'.tar.gz');path.write_bytes(raw)
            with tarfile.open(path) as archive:
                assert sum(m.size for m in archive.getmembers())<=64*1024*1024
                for member in archive.getmembers():
                    target=(folder/'source'/member.name).resolve();assert target.is_relative_to((folder/'source').resolve())
                archive.extractall(folder/'source',filter='data')
            files={p.relative_to(folder/'source').as_posix():pin(p.read_bytes()) for p in (folder/'source').rglob('*') if p.is_file()}
            record=dict(status='PASS_EXACT_ORIGINAL_SOURCE_DOWNLOAD',version=version,url=url,final_url=final_url,archive=pin(raw),files=files,previous_attempts=records)
            (folder/'SOURCE.json').write_bytes(encoded(record));print('downloaded',version,len(raw),'bytes',flush=True);return version,record
        except Exception as error:records.append(dict(url=url,error=repr(error)))
    record=dict(status='SKIP3_EXACT_SOURCE_UNAVAILABLE',version=version,attempts=records,required_action='Restore exact permitted original edgeR '+version+' source; keep dependent qualification skipped. Do not substitute another edition.')
    (folder/'SKIP3.json').write_bytes(encoded(record));print('SKIP3 source',version,records,flush=True);return version,record
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:sources=dict(pool.map(get,versions.items()))
(O/'SOURCES.json').write_bytes(encoded(sources))
assert all(r['status']=='PASS_EXACT_ORIGINAL_SOURCE_DOWNLOAD' for r in sources.values()),'See prominent named SKIP3 records; exact editions not substituted'
comparison={name:{version:pin((O/version/'source/edgeR/R'/name).read_bytes()) for version in versions} for name in ['calcNormFactors.R','cpm.R','rpkm.R','filterByExpr.R'] if all((O/v/'source/edgeR/R'/name).is_file() for v in versions)}
(O/'NORMALIZATION-SOURCE-COMPARISON.json').write_bytes(encoded(comparison))
(O/'COMPLETED.json').write_bytes(encoded(dict(status='PASS_EDGER_SIX_EXACT_SOURCE_EDITIONS_AND_250_IDENTITY_CENSUS',named_papers=len(hits),versions=list(versions))))
