from pathlib import Path
p=Path('D:/projects/JLinAlg/build/gradle_enrichr_workflow_20261119.py');source=p.read_text()
source=source.replace("A=R/'build/high-impact-stats-1';B=A/'build/enrichr-high-impact-1'","A=R/'build/edge-1';B=A/'build/edger-high-impact-1'")
assert "A=R/'build/edge-1'" in source
exec(compile(source,__file__+'-NORMAL-STRICT-GRADLE-EDGER-JAR','exec'))
