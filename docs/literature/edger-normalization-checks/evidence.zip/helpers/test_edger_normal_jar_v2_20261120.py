from pathlib import Path
import json
E=Path('D:/projects/JLinAlg/build/edge-1');B=E/'build/edger-high-impact-1'
(B/'normal-tests-1/FAILURE.json').write_text(json.dumps(dict(status='FAIL2_JAR_INVENTORY_CONVENTION_MISMATCH',scientific_tests_run=False,
    detail='The first helper excluded ZIP directory entries while applying the preceding all-member count. Its assertion stopped before compilation or JVM tests. Compare the same full decoded member inventory in normal-tests-2; do not weaken byte equality.'),indent=2)+'\n')
p=Path('D:/projects/JLinAlg/build/test_edger_normal_jar_20261120.py');source=p.read_text().replace("O=B/'normal-tests-1'","O=B/'normal-tests-2'")
assert source.count(' if not i.is_dir()')==2;source=source.replace(' if not i.is_dir()','')
exec(compile(source,__file__+'-EXACT-SAME-ZIP-MEMBER-CONVENTION','exec'))
