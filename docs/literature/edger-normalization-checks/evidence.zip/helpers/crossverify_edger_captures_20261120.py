from pathlib import Path
import concurrent.futures,json,os,subprocess
E=Path('D:/projects/JLinAlg/build/edge-1');B=E/'build/edger-high-impact-1';O=B/'cross-host-verify-1';O.mkdir(exist_ok=False)
jar=B/'workflow-gradle-2/project-build/cli/omicsmatic-0.4.0.jar';main='org.jlinalg.cli.EdgeRNormalizationCli'
parents=[]
for p in (B/'normal-tests-2/windows21-captures').iterdir():
    if p.name.startswith(('source-factor-','source-transform-','literal-')) and (p/'analysis/analysis-status.json').is_file():
        if json.loads((p/'analysis/analysis-status.json').read_bytes()).get('complete_result'):parents.append(p/'analysis')
assert len(parents)>=20,len(parents)
def linux(p):return '/mnt/d/'+Path(p).relative_to(Path('D:/')).as_posix()
def host(label):
    target=O/label;target.mkdir();rows=[]
    for i,parent in enumerate(parents):
        if label=='windows25':command=['C:/Program Files/Java/jdk-25/bin/java.exe','-cp',str(jar),main,'--verify',str(parent)]
        else:command=['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/java','-cp',linux(jar),main,'--verify',linux(parent)]
        p=subprocess.run(command,cwd=E,capture_output=True,timeout=60);(target/(str(i)+'.stdout')).write_bytes(p.stdout);(target/(str(i)+'.stderr')).write_bytes(p.stderr)
        rows.append(dict(capture=str(parent),exit_code=p.returncode));assert p.returncode==0,(label,parent,p.stderr.decode(errors='replace'))
    (target/'RESULTS.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,len(rows),'Windows21 captures recomputed exactly',flush=True);return label,rows
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=dict(pool.map(host,['windows25','linux21']))
(O/'COMPLETED.json').write_text(json.dumps(dict(status='PASS_WINDOWS21_NATIVE_CAPTURES_EXACTLY_RECOMPUTED_ON_WINDOWS25_AND_LINUX21',captures=len(parents),results=results,R_runtime_used=False),indent=2)+'\n')
