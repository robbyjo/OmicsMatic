from pathlib import Path
import hashlib,json,os,subprocess
R=Path('D:/projects/JLinAlg');E=R/'build/edge-1';B=E/'build/edger-high-impact-1';O=B/'runtime-3.42.4-1';O.mkdir(exist_ok=False)
base=R/'build/literature-review/monocle-runtime';requested=base/'idep244-adopted-provider-4/libraries-requested.txt'
def pin(path):
    with Path(path).open('rb') as f:return dict(bytes=Path(path).stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
def enc(value):return (json.dumps(value,indent=2)+'\n').encode()
libs=requested.read_text().splitlines();selected={name:next(Path(p)/name for p in libs if (Path(p)/name/'DESCRIPTION').is_file()) for name in ['edgeR','limma','locfit','jsonlite','Rcpp']}
before={str(p):pin(p) for root in selected.values() for p in root.rglob('*') if p.is_file()};(O/'BASE-PACKAGES-BEFORE.json').write_bytes(enc(before))
compiler=base/'rtools-intake-1/toolchain-3/x86_64-w64-mingw32.static.posix';host=base/'build-host-4/host/usr/bin'
archive=B/'source-intake-1/3.42.4/edgeR_3.42.4.tar.gz'
(O/'SOURCE.json').write_bytes(enc(dict(source_archive=pin(archive),compiler=pin(compiler/'bin/g++.exe'),make=pin(host/'make.exe'),original_source_modified=False)))
script=O/'install.R'
script.write_text('''args<-commandArgs(TRUE);stopifnot(length(args)==4);out<-args[2];lib<-file.path(out,"R-lib");stopifnot(!dir.exists(lib));dir.create(lib)
.libPaths(c(lib,readLines(args[3])),include.site=FALSE)
options(Ncpus=1)
install.packages(args[1],repos=NULL,type="source",lib=lib,dependencies=FALSE,INSTALL_opts=c("--no-multiarch","--no-clean-on-error"))
stopifnot(requireNamespace("edgeR",quietly=TRUE),as.character(packageVersion("edgeR"))=="3.42.4",normalizePath(find.package("edgeR"))==normalizePath(file.path(lib,"edgeR")))
e<-new.env(parent=asNamespace("stats"));for(n in c("calcNormFactors.R","cpm.R","rpkm.R"))sys.source(file.path(args[4],"R",n),envir=e)
names<-c("calcNormFactors.default",".calcFactorTMM",".calcFactorTMMwsp","cpm.default","rpkm.default")
for(n in names)stopifnot(identical(body(get(n,e)),body(get(n,asNamespace("edgeR")))),identical(formals(get(n,e)),formals(get(n,asNamespace("edgeR")))))
writeLines(capture.output(sessionInfo()),file.path(out,"SESSION.txt"))
saveRDS(list(version=as.character(packageVersion("edgeR")),path=find.package("edgeR"),functions=names,original_source_modified=FALSE),file.path(out,"namespace-audit.rds"))
cat("PASS installed and source-audited original edgeR 3.42.4; setup is not an analysis\\n")
''',encoding='utf-8')
for name in ['tmp','empty-library']:(O/name).mkdir()
env=dict(os.environ)
for name in list(env):
    if name.startswith('R_') or name.startswith('LC_') or name in ['LANG','LANGUAGE']:env.pop(name,None)
env.update(R_USER=str(O),R_LIBS_USER=str(O/'empty-library'),R_LIBS_SITE=str(O/'empty-library'),TMP=str(O/'tmp'),TEMP=str(O/'tmp'),TMPDIR=str(O/'tmp'),LC_ALL='C',LANG='C',
    R_CUSTOM_TOOLS_SOFT=compiler.as_posix(),R_CUSTOM_TOOLS_PATH=(compiler/'bin').as_posix()+';'+host.as_posix(),PATH=str(compiler/'bin')+';'+str(host)+';'+env.get('PATH',''))
command=['C:/Program Files/R/R-4.6.1/bin/Rscript.exe','--vanilla',str(script),str(archive),str(O),str(requested),str(B/'source-intake-1/3.42.4/source/edgeR')]
(O/'COMMAND.json').write_bytes(enc(dict(command=command,locale='C',R_LIBS_read_only=libs,new_install_library=str(O/'R-lib'))))
with (O/'install.stdout').open('xb') as so,(O/'install.stderr').open('xb') as se:
    child=subprocess.Popen(command,cwd=O,env=env,stdout=so,stderr=se);(O/'LIVE.json').write_bytes(enc(dict(pid=child.pid,command=command)));code=child.wait(timeout=900)
after={str(p):pin(p) for root in selected.values() for p in root.rglob('*') if p.is_file()};assert before==after
record=dict(status='PASS_ORIGINAL_EDGER3424_PRIVATE_SETUP_NO_ANALYSIS' if code==0 else 'SKIP3_ORIGINAL_EDGER3424_INSTALL_UNAVAILABLE',exit_code=code,shared_package_folders_unchanged=len(selected),shared_files=len(before),analysis_run=False,
    required_action='If setup fails or installation is forbidden, retain the named skip and dependent analysis; supply the exact permitted runtime in a NEW private directory. Preserve logs and partials; no adjacent-edition substitution.')
(O/('COMPLETED.json' if code==0 else 'SKIP3.json')).write_bytes(enc(record));print((O/'install.stdout').read_text(errors='replace')[-2400:]);print((O/'install.stderr').read_text(errors='replace')[-2400:]);print(json.dumps(record,indent=2),flush=True)
raise SystemExit(0 if code==0 else 3)
