from pathlib import Path
import concurrent.futures,json,subprocess,sys
R=Path('D:/projects/JLinAlg');E=R/'build/edge-1';B=E/'build/edger-high-impact-1';O=B/'historical-installs-1';O.mkdir(exist_ok=False)
source=(R/'build/install_edger_historical_20261120.py').read_text()
def setup(version):
    code=source.replace('3.42.4',version).replace('3424',version.replace('.',''))
    script=O/('install-'+version+'.py');script.write_text(code,encoding='utf-8')
    with (O/(version+'.stdout')).open('xb') as so,(O/(version+'.stderr')).open('xb') as se:p=subprocess.run([sys.executable,'-B',str(script)],cwd='C:/Windows/Temp',stdout=so,stderr=se,timeout=960)
    print(version,'setup exit',p.returncode,flush=True);return version,dict(exit_code=p.returncode)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=dict(pool.map(setup,['3.32.1','3.36.0','3.40.2']))
(O/'RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
if not all(r['exit_code']==0 for r in results.values()):
    (O/'SKIP3.json').write_text(json.dumps(dict(status='SKIP3_SOME_EXACT_EDGER_PROFILES_UNAVAILABLE',results=results,required_action='Retain exact named skips, installer warnings and partials. Supply permitted original runtimes in NEW paths; do not silently substitute editions.'),indent=2)+'\n');sys.exit(3)
(O/'COMPLETED.json').write_text(json.dumps(dict(status='PASS_THREE_ORIGINAL_EDGER_PROFILES_PRIVATELY_INSTALLED_NO_ANALYSIS',results=results),indent=2)+'\n')
