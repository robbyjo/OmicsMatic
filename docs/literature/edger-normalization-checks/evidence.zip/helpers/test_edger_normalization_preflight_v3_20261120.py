from pathlib import Path
p=Path('D:/projects/JLinAlg/build/test_edger_normalization_preflight_20261120.py');source=p.read_text()
assert "O=B/'preflight-1'" in source;source=source.replace("O=B/'preflight-1'","O=B/'preflight-3'")
old="['src/main/java/org/jlinalg/differential/EdgeRNormalization.java'";assert old in source
source=source.replace(old,"['src/main/java/org/jlinalg/differential/EdgeRLog2.java','src/main/java/org/jlinalg/differential/EdgeRNormalization.java'")
exec(compile(source,__file__+'-BINARY-LOG-EXACT-INPUT-DECIMALS','exec'))
