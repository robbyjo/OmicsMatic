from pathlib import Path
import hashlib,json,subprocess,sys
R=Path('D:/projects/JLinAlg');A=R/'build/high-impact-stats-1';E=R/'build/edge-1';B=E/'build/edger-high-impact-1';O=B/'predecessor-1';O.mkdir(exist_ok=False)
base='ae5c476b435edf72838dfa288b336c92975d7c41'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=A).decode().strip()==base
assert not subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=A)
records={}
for label,tool,args in [('component','verify_susie_dispatch.py',[]),('catalog','close_susie_dispatch.py',['--verify'])]:
    out=A/'build'/('edger-native-'+label+'-predecessor-20261120-1')
    command=[sys.executable,'-X','utf8','-B',str(A/'tools/literature'/tool),*args,'--out',str(out)]
    p=subprocess.run(command,cwd=A,capture_output=True,timeout=90);(O/(label+'.stdout')).write_bytes(p.stdout);(O/(label+'.stderr')).write_bytes(p.stderr)
    assert p.returncode==0,(label,p.stderr.decode(errors='replace'));records[label]=dict(command=command,exit_code=p.returncode,result=json.loads((out/'COMPLETED.json').read_bytes()))
before=json.loads((R/'build/git-publish/20261120-susie-dispatch-55/CANONICAL-AFTER.json').read_bytes())
for name,w in before.items():
    for root in [A,E]:
        raw=(root/name).read_bytes();assert dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())==w,name
assert not subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=A)
result=dict(status='PASS_UNCHANGED_EXACT_PREDECESSOR_COMPONENT_CATALOG_AND_15_CANONICAL_FILES',historical_commit=base,root=str(A),records=records,manifest_entries=820,canonical_files_unchanged=15,
    source_overlay=False,new_family_credit=0,new_canonical_reviews=0,fresh_R_models_run=False)
(O/'COMPLETED.json').write_text(json.dumps(result,indent=2)+'\n');print(result['status'],flush=True)
