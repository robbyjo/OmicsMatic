from pathlib import Path
import json,shutil,subprocess
E=Path('D:/projects/JLinAlg/build/edge-1');B=E/'build/edger-high-impact-1';O=B/'alias-controls-1';O.mkdir(exist_ok=False)
jar=B/'workflow-gradle-2/project-build/cli/omicsmatic-0.4.0.jar';java='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe';main='org.jlinalg.cli.EdgeRNormalizationCli';original=B/'examples-1/TMM';rows=[]
def run(name,command,expected):
    p=subprocess.run(command,cwd=E,capture_output=True,timeout=120);(O/(name+'.stdout')).write_bytes(p.stdout);(O/(name+'.stderr')).write_bytes(p.stderr)
    assert p.returncode==expected,(name,p.returncode,p.stderr.decode(errors='replace'));return p
for mode in ['direct','junction']:
    parent=O/(mode+'-parent');shutil.copytree(original,parent);run(mode+'-before',[java,'-cp',str(jar),main,'--verify',str(parent)],0)
    if mode=='junction':
        alias=O/'windows-alias';assert not alias.exists() and alias.parent.resolve()==O.resolve() and parent.resolve().is_relative_to(B.resolve())
        script=O/'make-junction.ps1';script.write_text("param([string]$AliasPath,[string]$TargetPath)\nif (Test-Path -LiteralPath $AliasPath) { throw 'Preserve existing alias' }\nNew-Item -ItemType Junction -Path $AliasPath -Target $TargetPath -ErrorAction Stop | Out-Null\n")
        run('make-junction',['C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe','-NoProfile','-NonInteractive','-File',str(script),'-AliasPath',str(alias),'-TargetPath',str(parent)],0);assert alias.is_junction();target=alias/'nested/new'
    else:target=parent/'nested/new'
    request=O/(mode+'.json');request.write_text(json.dumps(dict(schema_version=1,mode='REPLAY',analysis=str(parent),out=str(target)),indent=2)+'\n')
    p=run(mode+'-replay',[java,'-cp',str(jar),main,'--request',str(request)],2);assert b'outside its original analysis' in p.stderr and not (parent/'nested').exists()
    run(mode+'-after',[java,'-cp',str(jar),main,'--verify',str(parent)],0);rows.append(dict(control='Windows-'+mode,exit_code=2,parent_before_exit=0,parent_after_exit=0,output_created=False))
parent=O/'linux-parent';shutil.copytree(original,parent)
def linux(p):return '/mnt/d/'+Path(p).relative_to(Path('D:/')).as_posix()
code='''import json,pathlib,subprocess,sys
jar,main,parent,out=sys.argv[1:];root=pathlib.Path('/tmp/omicsmatic-edger-replay-alias-20261120-1');root.mkdir(exist_ok=False);alias=root/'alias';alias.symlink_to(parent,target_is_directory=True)
def run(args):return subprocess.run(['/usr/bin/java','-cp',jar,main,*args],capture_output=True)
assert run(['--verify',parent]).returncode==0
request=pathlib.Path(out)/'linux.json';request.write_text(json.dumps(dict(schema_version=1,mode='REPLAY',analysis=parent,out=str(alias/'nested/new'))))
p=run(['--request',str(request)]);(pathlib.Path(out)/'linux-replay.stdout').write_bytes(p.stdout);(pathlib.Path(out)/'linux-replay.stderr').write_bytes(p.stderr)
assert p.returncode==2 and b'outside its original analysis' in p.stderr and not (pathlib.Path(parent)/'nested').exists();assert run(['--verify',parent]).returncode==0
print(json.dumps(dict(control='Linux-symlink',exit_code=2,parent_before_exit=0,parent_after_exit=0,output_created=False)))
'''
p=run('linux-control',['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/python3','-I','-B','-c',code,linux(jar),main,linux(parent),linux(O)],0);rows.append(json.loads(p.stdout))
result=dict(status='PASS_NATIVE_EDGER_REPLAY_PARENT_PROTECTION_AND_PATH_ALIASES',controls=rows,original_capture_modified=False,R_runtime_used=False)
(O/'COMPLETED.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
