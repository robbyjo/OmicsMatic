from pathlib import Path
import hashlib,json,os,shutil,sys,zipfile
R=Path('D:/projects/JLinAlg');E=R/'build/edge-1';B=E/'build/edger-high-impact-1';F=E/'docs/literature/edger-normalization-checks'
sys.dont_write_bytecode=True;sys.path.insert(0,str(E/'tools/literature'))
from verify_edger_normalization import verify,pin,STATUS
assert not (F/'QUALIFICATION.json').exists() and not (F/'evidence.zip').exists()
def enc(v):return (json.dumps(v,indent=2,ensure_ascii=False)+'\n').encode()
assert (B/'source-census-2/CENSUS.json').read_bytes()==(B/'source-census-linux-1/CENSUS.json').read_bytes()
shutil.copyfile(B/'source-census-2/CENSUS.json',F/'CENSUS.json')
payload={}
def add(p,name):
    assert name not in payload,name;payload[name]=p.read_bytes()
def tree(parent,prefix):
    for directory,dirs,files in os.walk(parent,followlinks=False):
        dirs[:]=[n for n in dirs if not (Path(directory)/n).is_symlink() and not (Path(directory)/n).is_junction()]
        for n in files:
            p=Path(directory)/n
            if p.is_symlink():continue
            add(p,prefix+'/'+p.relative_to(parent).as_posix())
def top(parent,prefix,exclude=()):
    for p in parent.iterdir():
        if p.is_file() and p.name not in exclude:add(p,prefix+'/'+p.name)
for name in ['normal-tests-2','preflight-1','preflight-2','preflight-3','preflight-4','preflight-5','preflight-6','preflight-7','preflight-8']:
    top(B/name,name,exclude=['linux21-native-test-root.tar'])
    for p in (B/name).iterdir():
        if p.is_dir() and p.name.startswith('reports'):tree(p,name+'/'+p.name)
for name in ['reference-1','reference-2']:
    top(B/name,name);tree(B/name/'original',name+'/original')
top(B/'historical-cpm-3','historical-cpm-3')
for version in ['3.32.1','3.36.0','3.40.2','3.42.4']:
    top(B/'historical-cpm-3'/version,'historical-cpm-3/'+version);tree(B/'historical-cpm-3'/version/'original','historical-cpm-3/'+version+'/original')
    top(B/('runtime-'+version+'-1'),'runtime-'+version+'-1')
for name in ['historical-cpm-1','normal-tests-1','predecessor-1','alias-controls-1']:
    top(B/name,name)
tree(B/'examples-1','examples-1');tree(B/'cross-host-verify-1','cross-host-verify-1')
for name in ['workflow-gradle-1','workflow-gradle-2']:top(B/name,name)
for revision in ['kernel-cpm-1','kernel-cpm-2']:
    top(B/revision,revision)
    for version in ['3.32.1','3.36.0']:
        top(B/revision/version,revision+'/'+version,exclude=['original-edger-'+version+'.dll'])
        for name in ['R_calculate_cpm.cpp','add_prior.cpp','objects.cpp','objects.h','utils.h','add_prior.h','Makevars']:
            add(B/revision/version/'src'/name,revision+'/'+version+'/src/'+name)
for name in ['SOURCE-COMPARISON.json','SOURCES.json','NORMALIZATION-SOURCE-COMPARISON.json','COMPLETED.json']:
    p=B/'source-intake-1'/name
    if p.is_file():add(p,'source-intake-1/'+name)
for name in ['SOURCES.json','FAILED-CASES.json']:add(B/'math-source-1'/name,'math-source-1/'+name)
for name in ['src/e_log2.c','src/k_log.h','LICENSE.md']:add(B/'math-source-1'/name,'original-openlibm/'+name)
for p in (R/'build').glob('*edger*20261120*'):
    if p.is_file():add(p,'helpers/'+p.name)
jar=B/'workflow-gradle-2/project-build/cli/omicsmatic-0.4.0.jar'
members=json.loads((B/'normal-tests-2/JAR-PAYLOADS.json').read_bytes())
with zipfile.ZipFile(jar) as z:
    for name in members['additions']:payload['producer/new-members/'+name]=z.read(name)
size=sum(map(len,payload.values()));assert size<128*1024*1024,size
with zipfile.ZipFile(F/'evidence.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for n,raw in sorted(payload.items()):z.writestr(n,raw)
sources=['src/main/java/'+p for p in ['org/jlinalg/differential/EdgeRNormalization.java','org/jlinalg/differential/EdgeRLog2.java','org/jlinalg/cli/EdgeRNormalizationCli.java',
    'org/jlinalg/cli/SimpleJson.java','org/jlinalg/cli/SeuratDifferentialContracts.java','org/jlinalg/cli/RsemJson.java','org/jlinalg/cli/RegenieRuntime.java']]
sources+=['src/test/java/'+p for p in ['org/jlinalg/cli/EdgeRNormalizationTest.java','org/jlinalg/cli/EdgeRHistoricalCpmTest.java','org/jlinalg/cli/EdgeRNormalizationCliTest.java','org/jlinalg/differential/EmpiricalBayesDifferentialTest.java']]
sources+=['tools/literature/'+p for p in ['edger_normalization_reference.R','edger_historical_cpm_reference.R','edger_source_roles.py','verify_edger_normalization.py','collect_omics_review.py','catalog_fixed_cohort.py']]
sources+=['docs/literature/EDGER_NORMALIZATION.md','src/main/resources/META-INF/NOTICE-edger-normalization.txt','docs/literature/susie-dispatch-catalog/metadata-before.zip']
sources+=[p.relative_to(E).as_posix() for p in (E/'examples/edger-native').iterdir() if p.is_file()]
fixtures={p.name:pin(p.read_bytes()) for p in (E/'src/test/resources/org/jlinalg/differential/edger-normalization').glob('*.zip')}
sources+=['src/test/resources/org/jlinalg/differential/edger-normalization/'+n for n in fixtures]
q=dict(schema_version=1,status=STATUS,baseline_commit='ae5c476b435edf72838dfa288b336c92975d7c41',sources={n:pin((E/n).read_bytes()) for n in sorted(set(sources))},
    producer=json.loads((B/'normal-tests-2/COMPLETED.json').read_bytes())['producer'],archive=pin((F/'evidence.zip').read_bytes()),payloads={n:pin(raw) for n,raw in sorted(payload.items())},
    census=pin((F/'CENSUS.json').read_bytes()),fixtures=fixtures,new_family_credit=0,new_canonical_reviews=0,whole_tool_qualified=False,whole_paper_reproduced=False,whole_goal_complete=False,
    limitations=['Five source editions are bounded matrix operations, not stock author deployments','Two old stock-package GLM deployments remain SKIP3; selected original kernels have separate controls',
        'Source roles are audited proposals; canonical census/admission remains unchanged','Scientific JVM evidence is saved, not rerun by this reader','Old inputs/results/attempts remain retained with exact supersession context'])
(F/'QUALIFICATION.json').write_bytes(enc(q));result=verify();(F/'READBACK.json').write_bytes(enc(result))
print(json.dumps(dict(status=result['status'],sources=len(q['sources']),payloads=len(payload),uncompressed_bytes=size,archive_bytes=(F/'evidence.zip').stat().st_size),indent=2),flush=True)
