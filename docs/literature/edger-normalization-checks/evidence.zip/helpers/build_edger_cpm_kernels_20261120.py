from pathlib import Path
import concurrent.futures,hashlib,json,os,shutil,subprocess
R=Path('D:/projects/JLinAlg');E=R/'build/edge-1';B=E/'build/edger-high-impact-1';O=B/'kernel-cpm-1';O.mkdir(exist_ok=False)
base=R/'build/literature-review/monocle-runtime';compiler=base/'rtools-intake-1/toolchain-3/x86_64-w64-mingw32.static.posix';host=base/'build-host-4/host/usr/bin'
libs=(base/'idep244-adopted-provider-4/libraries-requested.txt').read_text().splitlines();rcpp=next(Path(p)/'Rcpp' for p in libs if (Path(p)/'Rcpp/DESCRIPTION').is_file())
Rhome=Path('C:/Program Files/R/R-4.6.1');rcmd=next(p for p in [Rhome/'bin/Rcmd.exe',Rhome/'bin/x64/Rcmd.exe'] if p.is_file())
def pin(p):
    with Path(p).open('rb') as f:return dict(bytes=Path(p).stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
def enc(v):return (json.dumps(v,indent=2)+'\n').encode()
def build(version):
    folder=O/version;src=folder/'src';src.mkdir(parents=True);source=B/'source-intake-1'/version/'source/edgeR/src'
    names=['R_calculate_cpm.cpp','add_prior.cpp','objects.cpp','objects.h','utils.h','add_prior.h','Makevars']
    originals={n:pin(source/n) for n in names}
    for n in names:shutil.copyfile(source/n,src/n);assert pin(src/n)==originals[n]
    env=dict(os.environ)
    for n in list(env):
        if n.startswith('R_') or n.startswith('LC_') or n in ['LANG','LANGUAGE']:env.pop(n,None)
    (folder/'tmp').mkdir();(folder/'empty-library').mkdir()
    env.update(R_USER=str(folder),R_LIBS_USER=str(folder/'empty-library'),R_LIBS_SITE=str(folder/'empty-library'),TMP=str(folder/'tmp'),TEMP=str(folder/'tmp'),TMPDIR=str(folder/'tmp'),LC_ALL='C',LANG='C',
        R_CUSTOM_TOOLS_SOFT=compiler.as_posix(),R_CUSTOM_TOOLS_PATH=(compiler/'bin').as_posix()+';'+host.as_posix(),PATH=str(compiler/'bin')+';'+str(host)+';'+env.get('PATH',''),PKG_CPPFLAGS='-I"'+(rcpp/'include').as_posix()+'"')
    dll=folder/('original-edger-'+version+'.dll');command=[str(rcmd),'SHLIB','-o',str(dll),'R_calculate_cpm.cpp','add_prior.cpp','objects.cpp']
    with (folder/'build.stdout').open('xb') as so,(folder/'build.stderr').open('xb') as se:p=subprocess.run(command,cwd=src,env=env,stdout=so,stderr=se,timeout=180)
    (folder/'PROCESS.json').write_bytes(enc(dict(command=command,exit_code=p.returncode,Rcpp_header_root=str(rcpp),Rcpp_DESCRIPTION=pin(rcpp/'DESCRIPTION'),original_sources=originals,compiler=pin(compiler/'bin/g++.exe'))))
    assert p.returncode==0,(version,(folder/'build.stderr').read_text(errors='replace'))
    assert all(pin(src/n)==originals[n] and pin(source/n)==originals[n] for n in names)
    row=dict(status='PASS_UNCHANGED_ORIGINAL_CPM_KERNEL_PROVIDER_BUILD_ONLY',version=version,dll=pin(dll),source_algorithms_modified=False,full_original_package_installed=False,
        skipped_full_package='R4.6 LAPACK character-length ABI compilation failure is retained separately; no GLM or whole-package analysis is admitted')
    (folder/'COMPLETED.json').write_bytes(enc(row));print(version,'unchanged original C++ kernels compiled',flush=True);return version,row
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=dict(pool.map(build,['3.32.1','3.36.0']))
(O/'COMPLETED.json').write_bytes(enc(dict(status='PASS_TWO_ORIGINAL_CPM_KERNEL_PROVIDERS_NO_WHOLE_PACKAGE_CLAIM',results=results)))
