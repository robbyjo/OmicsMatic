from pathlib import Path
import json,subprocess
E=Path('D:/projects/JLinAlg/build/edge-1');B=E/'build/edger-high-impact-1'
p=Path('D:/projects/JLinAlg/build/qualify_edger_normalization_20261120.py');source=p.read_text()
assert "O=B/'reference-1'" in source and 'reference-20261120.zip' in source
source=source.replace("O=B/'reference-1'","O=B/'reference-2'").replace('reference-20261120.zip','reference-20261120-v2.zip')
exec(compile(source,__file__+'-ROUND-TRIP-DECIMALS','exec'))
script=B/'reference-2/compare-originals.R'
script.write_text('''args<-commandArgs(TRUE)
a<-readRDS(args[1]);b<-readRDS(args[2])
stopifnot(identical(a$datasets,b$datasets),identical(a$normalization_returns,b$normalization_returns),
    identical(a$RNG_before,b$RNG_before),identical(a$RNG_after,b$RNG_after))
take<-function(r)r[c("name","values","warnings","messages","gene_lengths")]
stopifnot(identical(lapply(a$reference$transforms,take),lapply(b$reference$transforms,take)))
cat("PASS original inputs, all 2350 model returns, 552 transform outputs, conditions and RNG unchanged; only exported input decimals corrected\\n")
''',encoding='utf-8')
command=['C:/Program Files/R/R-4.6.1/bin/Rscript.exe','--vanilla',str(script),str(B/'reference-1/original/original-returns.rds'),str(B/'reference-2/original/original-returns.rds')]
p=subprocess.run(command,cwd=E,capture_output=True,timeout=60)
(B/'reference-2/compare-originals.stdout').write_bytes(p.stdout);(B/'reference-2/compare-originals.stderr').write_bytes(p.stderr)
assert p.returncode==0,p.stderr.decode(errors='replace')
(B/'reference-2/ORIGINALS-UNCHANGED.json').write_text(json.dumps(dict(status='PASS_ORIGINAL_INPUTS_RETURNS_CONDITIONS_AND_RNG_IDENTICAL',exit_code=p.returncode,normalizations=2350,transforms=552,changed_only='JSON input numeric serialization now uses explicit 17-significant-digit strings; original inputs/model results unchanged'),indent=2)+'\n')
print(p.stdout.decode(errors='replace'),flush=True)
