from pathlib import Path
E=Path('D:/projects/JLinAlg/build/edge-1');p=E/'src/main/java/org/jlinalg/cli/EdgeRNormalizationCli.java'
raw=p.read_bytes();old=b',"org/jlinalg/differential/EdgeRNormalization$1"';assert raw.count(old)==1;p.write_bytes(raw.replace(old,b'',1))
p=Path('D:/projects/JLinAlg/build/test_edger_normalization_preflight_20261120.py');source=p.read_text()
source=source.replace("O=B/'preflight-1'","O=B/'preflight-6'")
old="['src/main/java/org/jlinalg/differential/EdgeRNormalization.java'";assert old in source
source=source.replace(old,"['src/main/java/org/jlinalg/cli/EdgeRNormalizationCli.java','src/test/java/org/jlinalg/cli/EdgeRNormalizationCliTest.java','src/main/java/org/jlinalg/differential/EdgeRLog2.java','src/main/java/org/jlinalg/differential/EdgeRNormalization.java'")
old="'--select-class','org.jlinalg.cli.EdgeRNormalizationTest'";assert old in source
source=source.replace(old,"'--select-class','org.jlinalg.cli.EdgeRNormalizationCliTest',"+old)
source=source.replace("'-Xmx2g'","'-Xmx2g','-Domicsmatic.edger.test_root='+str(O/'captures')")
source=source.replace("for name,command in commands:","import zipfile\nwith zipfile.ZipFile(O/'source-before.zip','x',compression=zipfile.ZIP_DEFLATED) as z:\n    for p in sources:z.writestr(p.relative_to(E).as_posix(),p.read_bytes())\nfor name,command in commands:")
exec(compile(source,__file__+'-EXACT-ACTUAL-PRODUCER-CLASS-LIST','exec'))
