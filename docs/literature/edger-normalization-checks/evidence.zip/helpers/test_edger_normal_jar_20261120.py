from pathlib import Path
import concurrent.futures,hashlib,json,os,subprocess,sys,xml.etree.ElementTree as ET,zipfile
R=Path('D:/projects/JLinAlg');A=R/'build/high-impact-stats-1';E=R/'build/edge-1';B=E/'build/edger-high-impact-1';O=B/'normal-tests-1';O.mkdir(exist_ok=False)
jar=B/'workflow-gradle-2/project-build/cli/omicsmatic-0.4.0.jar';old=A/'build/susie-dispatch-1/workflow-gradle-2/project-build/cli/omicsmatic-0.4.0.jar'
junit=A/'build/nfcore-atacseq121-1/linux-test-runtime-1/junit-platform-console-standalone-1.13.4.jar';classes=O/'test-classes';classes.mkdir()
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def enc(v):return (json.dumps(v,indent=2)+'\n').encode()
with zipfile.ZipFile(old) as before,zipfile.ZipFile(jar) as after:
    previous={i.filename:pin(before.read(i)) for i in before.infolist() if not i.is_dir()};current={i.filename:pin(after.read(i)) for i in after.infolist() if not i.is_dir()}
    assert len(previous)==23460 and set(previous)<=set(current)
    assert all(current[n]==wanted for n,wanted in previous.items()),[n for n in previous if current[n]!=previous[n]]
    additions=set(current)-set(previous);assert len(additions)==11 and all(n.startswith(('org/jlinalg/cli/EdgeRNormalizationCli','org/jlinalg/differential/EdgeR')) or n=='META-INF/NOTICE-edger-normalization.txt' for n in additions),additions
    (O/'JAR-PAYLOADS.json').write_bytes(enc(dict(previous_count=len(previous),current_count=len(current),all_previous_payloads_unchanged=True,additions={n:current[n] for n in sorted(additions)},previous_payloads=previous)))
sources=[E/('src/test/java/'+name+'.java') for name in ['org/jlinalg/cli/EdgeRNormalizationTest','org/jlinalg/cli/EdgeRNormalizationCliTest','org/jlinalg/cli/EdgeRHistoricalCpmTest','org/jlinalg/differential/EmpiricalBayesDifferentialTest']]
command=['C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/javac.exe','--release','17','-Xlint:all','-Werror','-encoding','UTF-8','-cp',str(jar)+os.pathsep+str(junit),'-d',str(classes),*map(str,sources)]
with (O/'javac.stdout').open('xb') as so,(O/'javac.stderr').open('xb') as se:p=subprocess.run(command,cwd=E,stdout=so,stderr=se,timeout=90)
assert p.returncode==0,(O/'javac.stderr').read_text();assert not list(classes.rglob('EdgeRNormalization.class')) and not list(classes.rglob('EdgeRNormalizationCli.class'))
selected=[]
for name in ['org.jlinalg.cli.EdgeRNormalizationTest','org.jlinalg.cli.EdgeRNormalizationCliTest','org.jlinalg.cli.EdgeRHistoricalCpmTest','org.jlinalg.differential.EmpiricalBayesDifferentialTest']:selected+=['--select-class',name]
(O/'SOURCES.json').write_bytes(enc({str(p.relative_to(E)):pin(p.read_bytes()) for p in sources}))
def linux(path):return '/mnt/d/'+Path(path).relative_to(Path('D:/')).as_posix()
linux_code='''import json,os,subprocess,sys,tarfile
java,junit,jar,classes,resources,reports,root,audit,historical,archive,*selected=sys.argv[1:]
assert not os.path.exists(root);os.makedirs(root)
command=[java,'-Xmx2g','-Domicsmatic.edger.test_root='+root,'-Domicsmatic.edger.reference.audit='+audit,'-Domicsmatic.edger.historical.audit='+historical,'-jar',junit,'execute','--disable-banner','--details=summary','--reports-dir',reports,'--class-path',os.pathsep.join([classes,jar,resources]),*selected]
p=subprocess.run(command,cwd=root)
with tarfile.open(archive,'x') as t:t.add(root,arcname='linux21-native-test-root',recursive=True)
sys.exit(p.returncode)
'''
(O/'linux-driver.py').write_text(linux_code,encoding='utf-8')
def host(label):
    reports=O/('reports-'+label);reports.mkdir();root=O/(label+'-captures');audit=O/(label+'-NUMERICS.json');historical=O/(label+'-HISTORICAL-NUMERICS.json')
    if label=='linux21':
        command=['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/python3','-I','-B',linux(O/'linux-driver.py'),'/usr/bin/java',linux(junit),linux(jar),linux(classes),linux(E/'src/test/resources'),linux(reports),'/tmp/omicsmatic-edger-normalization-20261120-1',linux(audit),linux(historical),linux(O/'linux21-native-test-root.tar'),*selected]
    else:
        java='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe' if label=='windows21' else 'C:/Program Files/Java/jdk-25/bin/java.exe'
        command=[java,'-Xmx2g','-Domicsmatic.edger.test_root='+str(root),'-Domicsmatic.edger.reference.audit='+str(audit),'-Domicsmatic.edger.historical.audit='+str(historical),'-jar',str(junit),'execute','--disable-banner','--details=summary','--reports-dir',str(reports),'--class-path',os.pathsep.join(map(str,[classes,jar,E/'src/test/resources'])),*selected]
    with (O/(label+'.stdout')).open('xb') as so,(O/(label+'.stderr')).open('xb') as se:p=subprocess.run(command,cwd=E,stdout=so,stderr=se,timeout=240)
    suites=[ET.fromstring(p.read_bytes()) for p in reports.glob('*.xml')];totals={k:sum(int(s.get(k,0)) for s in suites) for k in ['tests','errors','failures','skipped']}
    value=dict(exit_code=p.returncode,command=command,totals=totals,numerics=json.loads(audit.read_bytes()),historical_numerics=json.loads(historical.read_bytes()))
    (O/(label+'-RESULTS.json')).write_bytes(enc(value));print(label,p.returncode,totals,flush=True);return label,value
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=dict(pool.map(host,['windows21','windows25','linux21']))
(O/'RESULTS.json').write_bytes(enc(results));assert all(r['exit_code']==0 and r['totals']==dict(tests=5165,errors=0,failures=0,skipped=0) for r in results.values())
(O/'COMPLETED.json').write_bytes(enc(dict(status='PASS_NORMAL_JAR_NATIVE_EDGER_ORIGINAL_REFERENCES_AND_FILE_CONTRACTS_THREE_JVMS',tests_per_JVM=5165,producer=pin(jar.read_bytes()),unchanged_previous_payloads=23460,new_payloads=11,results=results,production_class_overlay=False,fresh_R_models_run=False)))
