from pathlib import Path
import hashlib,json,shutil,subprocess,sys
R=Path('D:/projects/JLinAlg');A=R/'build/high-impact-stats-1';E=R/'build/edge-1';O=R/'build/edger-start-20261120-1';O.mkdir(exist_ok=False)
BASE='ae5c476b435edf72838dfa288b336c92975d7c41'
assert not E.exists() and shutil.disk_usage(R).free>12*1024**3
def git(*args):return subprocess.check_output(['git','--no-replace-objects',*args],cwd=A)
assert git('rev-parse','HEAD').decode().strip()==BASE and not git('status','--porcelain=v1','-z','--untracked-files=all')
assert git('ls-remote','origin','refs/heads/main').decode().split()[0]==BASE
previous=R/'build/git-publish/20261120-susie-dispatch-55'
assert json.loads((previous/'PUBLISHED.json').read_bytes())['head']==BASE
shutil.copyfile(previous/'WORKTREES-EXPECTED.json',O/'PREVIOUS-WORKTREES.json')
command=['git','-c','core.longpaths=true','worktree','add','-b','codex/edger-high-impact-20261120',str(E),BASE]
with (O/'worktree.stdout').open('xb') as so,(O/'worktree.stderr').open('xb') as se:p=subprocess.run(command,cwd=A,stdout=so,stderr=se)
assert p.returncode==0,(O/'worktree.stderr').read_text(errors='replace')[-1000:]
B=E/'build/edger-high-impact-1';B.mkdir(parents=True,exist_ok=False)
shutil.copyfile(O/'PREVIOUS-WORKTREES.json',B/'PREVIOUS-WORKTREES.json')
sys.path.insert(0,str(E/'tools/literature'));sys.dont_write_bytecode=True
import gzip,re,xml.etree.ElementTree as ET
from collect_omics_review import paragraphs
papers=json.loads((E/'docs/literature/omics-2023-2026/papers.json').read_bytes());assert len(papers)==250
pattern=re.compile(r'(?<![A-Za-z0-9_])(?:edgeR|calcNormFactors|filterByExpr|glmQLFit|glmQLFTest|exactTest)(?![A-Za-z0-9_])')
identities=[];hits=[]
for paper in papers:
    path=R/'build/literature-review/xml'/(paper['pmcid']+'.xml.gz')
    with gzip.open(path,'rb') as f:raw=f.read(64*1024*1024+1)
    assert len(raw)<=64*1024*1024 and hashlib.sha256(raw).hexdigest()==paper['xml_sha256'],paper['paper_id']
    root=ET.fromstring(raw);doi=[n.text for n in root.findall('front/article-meta/article-id') if n.get('pub-id-type')=='doi']
    assert doi==[paper['doi']] or [s.lower() for s in doi]==[paper['doi'].lower()],paper['paper_id']
    identities.append({k:paper[k] for k in ['paper_id','pmcid','doi','xml_sha256']})
    selected=[b for b in paragraphs(root) if pattern.search(b.get('match_text',b['text']))]
    if selected:hits.append(dict(paper_id=paper['paper_id'],doi=paper['doi'],existing_edger_observation=any(t['tool_id']=='edger' for t in paper['tools']),paragraphs=selected))
(B/'PRIMARY-IDENTITIES.json').write_text(json.dumps(identities,indent=2)+'\n')
(B/'EDGE-HITS-PRIVATE.json').write_text(json.dumps(hits,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
for paper in hits:
    print(paper['paper_id'],paper['doi'],'existing',paper['existing_edger_observation'])
    for b in paper['paragraphs']:print(' paragraph',b['paragraph_index'],b['section'],b['text'])
(O/'COMPLETED.json').write_text(json.dumps(dict(status='PASS_CLEAN_EDGER_WORKTREE_AND_250_SOURCE_IDENTITY_SCAN',base=BASE,worktree=str(E),named_papers=len(hits),frozen_papers=250),indent=2)+'\n')
