from pathlib import Path
E=Path('D:/projects/JLinAlg/build/edge-1');p=E/'src/main/java/org/jlinalg/cli/EdgeRNormalizationCli.java'
raw=p.read_bytes();old=b',"org/jlinalg/differential/EdgeRNormalization$1"';assert raw.count(old)==1;p.write_bytes(raw.replace(old,b'',1))
p=Path('D:/projects/JLinAlg/build/test_edger_normalization_preflight_20261120.py');source=p.read_text().replace("O=B/'preflight-1'","O=B/'preflight-8'")
source=source.replace("'--release','21'","'--release','17','-Xlint:all','-Werror'")
source=source.replace("['src/main/java/org/jlinalg/differential/EdgeRNormalization.java'","['src/main/java/org/jlinalg/cli/EdgeRNormalizationCli.java','src/test/java/org/jlinalg/cli/EdgeRNormalizationCliTest.java','src/main/java/org/jlinalg/differential/EdgeRLog2.java','src/main/java/org/jlinalg/differential/EdgeRNormalization.java'")
source=source.replace("'--select-class','org.jlinalg.cli.EdgeRNormalizationTest'","'--select-class','org.jlinalg.cli.EdgeRNormalizationCliTest','--select-class','org.jlinalg.cli.EdgeRNormalizationTest'")
source=source.replace("'-Xmx2g'","'-Xmx2g','-Domicsmatic.edger.test_root='+str(O/'captures')")
source=source.replace("for name,command in commands:","import zipfile\nwith zipfile.ZipFile(O/'source-before.zip','x',compression=zipfile.ZIP_DEFLATED) as z:\n    for p in sources:z.writestr(p.relative_to(E).as_posix(),p.read_bytes())\nfor name,command in commands:")
exec(compile(source,__file__+'-ACTUAL-RELEASE17-CLASS-INVENTORY','exec'))
