from pathlib import Path
p=Path('D:/projects/JLinAlg/build/build_edger_cpm_kernels_20261120.py');source=p.read_text()
assert "O=B/'kernel-cpm-1'" in source;source=source.replace("O=B/'kernel-cpm-1'","O=B/'kernel-cpm-2'")
assert "str(dll),'R_calculate" in source;source=source.replace("str(dll),'R_calculate","dll.as_posix(),'R_calculate")
exec(compile(source,__file__+'-POSIX-MAKE-OUTPUT-PATH','exec'))
