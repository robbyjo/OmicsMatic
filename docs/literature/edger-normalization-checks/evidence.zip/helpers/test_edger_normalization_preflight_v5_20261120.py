from pathlib import Path
p=Path('D:/projects/JLinAlg/build/test_edger_normalization_preflight_v4_20261120.py');source=p.read_text()
assert "O=B/'preflight-4'" in source;source=source.replace("O=B/'preflight-4'","O=B/'preflight-5'")
exec(compile(source,__file__+'-TEST-FACTORY-DECLARATIONS','exec'))
