from pathlib import Path
import concurrent.futures,hashlib,json,os,subprocess,zipfile
R=Path('D:/projects/JLinAlg');E=R/'build/edge-1';B=E/'build/edger-high-impact-1';O=B/'historical-cpm-2';O.mkdir(exist_ok=False)
def pin(p):
    with Path(p).open('rb') as f:return dict(bytes=Path(p).stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
def enc(v):return (json.dumps(v,indent=2)+'\n').encode()
versions=['3.32.1','3.36.0','3.40.2','3.42.4'];names=['R/cpm.R','R/rpkm.R','src/R_calculate_cpm.cpp','src/add_prior.cpp','src/objects.h','src/objects.cpp','src/utils.h','src/add_prior.h']
comparison={n:{v:pin(B/'source-intake-1'/v/'source/edgeR'/n) for v in versions} for n in names}
core=names[:4];assert all(len({r['sha256'] for r in comparison[n].values()})==1 for n in core)
(O/'SOURCE-COMPARISON.json').write_bytes(enc(dict(core_CPM_RPKM_files_byte_identical=core,whole_selected_header_trees_equal=False,files=comparison,
    scope='All four exact original packages are separately installed and executed; no shared-header equivalence is assumed.')))
old=B/'historical-cpm-1';(old/'FAILURE.json').write_bytes(enc(dict(status='FAIL2_OVERBROAD_HEADER_IDENTITY_ASSERTION',scientific_process_run=False,
    error='The four reviewed CPM/RPKM R/kernel files are byte-identical, but not all eight selected header/object files are. The first helper stopped before any R execution.',
    superseded_by='historical-cpm-2: execute each exact original package independently; do not infer full-header equivalence',source_comparison=comparison)))
libs=R/'build/literature-review/monocle-runtime/idep244-adopted-provider-4/libraries-requested.txt'
def qualify(version):
    folder=O/version;folder.mkdir();runtime=B/('runtime-'+version+'-1/R-lib/edgeR')
    assert json.loads((runtime.parents[1]/'COMPLETED.json').read_bytes())['exit_code']==0
    before={str(p):pin(p) for p in runtime.rglob('*') if p.is_file()};(folder/'RUNTIME-BEFORE.json').write_bytes(enc(before))
    command=['C:/Program Files/R/R-4.6.1/bin/Rscript.exe','--vanilla',str(E/'tools/literature/edger_historical_cpm_reference.R'),str(B/'reference-2/original/original-returns.rds'),str(B/'source-intake-1'),str(folder/'original'),str(runtime.parent),str(libs),version]
    with (folder/'R.stdout').open('xb') as so,(folder/'R.stderr').open('xb') as se:p=subprocess.run(command,cwd=E,env=dict(os.environ,LC_ALL='C',LANG='C'),stdout=so,stderr=se,timeout=180)
    (folder/'PROCESS.json').write_bytes(enc(dict(command=command,exit_code=p.returncode)))
    assert p.returncode==0,(version,(folder/'R.stderr').read_text(errors='replace'))
    assert {str(p):pin(p) for p in runtime.rglob('*') if p.is_file()}==before
    row=dict(status='PASS_ORIGINAL_PACKAGE_CPM_RPKM_AND_UNCHANGED_RUNTIME',version=version,unchanged_files=len(before),result=json.loads((folder/'original/COMPLETED.json').read_bytes()))
    (folder/'COMPLETED.json').write_bytes(enc(row));print(version,row['result']['transforms'],'actual original transforms',flush=True);return version,row
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=dict(pool.map(qualify,versions))
dest=E/'src/test/resources/org/jlinalg/differential/edger-normalization/historical-cpm-20261120.zip'
with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for version in versions:
        for p in (O/version/'original').iterdir():
            if p.is_file():z.writestr(version+'/'+p.name,p.read_bytes())
        for n in names:z.writestr('original-source/'+version+'/'+n,(B/'source-intake-1'/version/'source/edgeR'/n).read_bytes())
    z.writestr('SOURCE-COMPARISON.json',(O/'SOURCE-COMPARISON.json').read_bytes())
    z.writestr('reference-driver.R',(E/'tools/literature/edger_historical_cpm_reference.R').read_bytes())
record=dict(status='PASS_FOUR_ACTUAL_ORIGINAL_HISTORICAL_EDGER_CPM_PACKAGES',fixture=pin(dest),results=results,original_returns=sum(r['result']['transforms'] for r in results.values()),inference_run=False,author_hosts_reproduced=False)
(O/'COMPLETED.json').write_bytes(enc(record));print(json.dumps({k:v for k,v in record.items() if k!='results'},indent=2),flush=True)
