from pathlib import Path
import hashlib,json,os,subprocess,zipfile
R=Path('D:/projects/JLinAlg');E=R/'build/edge-1';B=E/'build/edger-high-impact-1';O=B/'reference-1';O.mkdir(exist_ok=False)
libraries=R/'build/literature-review/monocle-runtime/idep244-adopted-provider-4/libraries-requested.txt'
def pin(p):
    p=Path(p)
    with p.open('rb') as f:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
def encoded(v):return (json.dumps(v,indent=2)+'\n').encode()
def roots():
    result={}
    for name in ['edgeR','limma','locfit','jsonlite']:
        path=next(Path(lib)/name for lib in libraries.read_text().splitlines() if (Path(lib)/name/'DESCRIPTION').is_file())
        result[name]=str(path)
    return result
selected=roots();files={str(p):pin(p) for root in selected.values() for p in Path(root).rglob('*') if p.is_file()}
(O/'RUNTIME-BEFORE.json').write_bytes(encoded(dict(roots=selected,files=files)))
command=['C:/Program Files/R/R-4.6.1/bin/Rscript.exe','--vanilla',str(E/'tools/literature/edger_normalization_reference.R'),str(B/'source-intake-1'),str(O/'original'),str(libraries)]
env=dict(os.environ,R_ENVIRON_USER=str(O/'empty-environ'),R_PROFILE_USER=str(O/'empty-profile'),R_LIBS_USER=str(O/'empty-library'),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
(O/'empty-environ').write_bytes(b'');(O/'empty-profile').write_bytes(b'');(O/'empty-library').mkdir()
(O/'COMMAND.json').write_bytes(encoded(dict(command=command,source=pin(E/'tools/literature/edger_normalization_reference.R'),Rscript=pin(command[0]),libraries=pin(libraries))))
with (O/'R.stdout').open('xb') as so,(O/'R.stderr').open('xb') as se:p=subprocess.run(command,cwd=E,env=env,stdout=so,stderr=se,timeout=300)
(O/'PROCESS.json').write_bytes(encoded(dict(exit_code=p.returncode)))
print((O/'R.stdout').read_text(errors='replace')[-2500:]);print((O/'R.stderr').read_text(errors='replace')[-2500:]);assert p.returncode==0
assert {str(p):pin(p) for root in selected.values() for p in Path(root).rglob('*') if p.is_file()}==files
(O/'RUNTIME-AFTER.json').write_bytes(encoded(dict(status='PASS_FOUR_ORIGINAL_PACKAGE_FOLDERS_UNCHANGED',packages=len(selected),files=len(files))))
dest=E/'src/test/resources/org/jlinalg/differential/edger-normalization/reference-20261120.zip';dest.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in (O/'original').iterdir():
        if p.is_file():z.writestr(p.name,p.read_bytes())
    for version in ['3.32.1','3.36.0','3.40.2','3.42.4','4.10.7']:
        for name in ['DESCRIPTION','R/calcNormFactors.R','R/cpm.R','R/rpkm.R']:
            source=B/'source-intake-1'/version/'source/edgeR'/name;z.writestr('original-source/'+version+'/'+name,source.read_bytes())
    z.writestr('reference-driver.R',(E/'tools/literature/edger_normalization_reference.R').read_bytes())
record=dict(status='PASS_ORIGINAL_EDGER_NORMALIZATION_REFERENCE_AND_UNMODIFIED_RUNTIME',reference=pin(dest),runtime_packages=len(selected),runtime_files=len(files),result=json.loads((O/'original/COMPLETED.json').read_bytes()))
(O/'COMPLETED.json').write_bytes(encoded(record));print(json.dumps(record,indent=2),flush=True)
