from pathlib import Path
import hashlib,json,os,subprocess,zipfile
R=Path('D:/projects/JLinAlg');E=R/'build/edge-1';B=E/'build/edger-high-impact-1';O=B/'historical-cpm-1';O.mkdir(exist_ok=False)
def pin(p):
    with Path(p).open('rb') as f:return dict(bytes=Path(p).stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
def enc(v):return (json.dumps(v,indent=2)+'\n').encode()
old=['3.32.1','3.36.0','3.40.2','3.42.4'];names=['R/cpm.R','R/rpkm.R','src/R_calculate_cpm.cpp','src/add_prior.cpp','src/objects.h','src/objects.cpp','src/utils.h','src/add_prior.h']
comparison={n:{v:pin(B/'source-intake-1'/v/'source/edgeR'/n) for v in old} for n in names}
assert all(len({r['sha256'] for r in row.values()})==1 for row in comparison.values())
(O/'IDENTICAL-FOUR-EDITION-SOURCES.json').write_bytes(enc(dict(status='PASS_EIGHT_CPM_RPKM_FILES_BYTE_IDENTICAL_FOUR_EDITIONS',files=comparison,entire_packages_equal=False)))
runtime=B/'runtime-3.42.4-1/R-lib/edgeR';assert json.loads((B/'runtime-3.42.4-1/COMPLETED.json').read_bytes())['exit_code']==0
before={str(p):pin(p) for p in runtime.rglob('*') if p.is_file()};(O/'RUNTIME-BEFORE.json').write_bytes(enc(before))
libs=R/'build/literature-review/monocle-runtime/idep244-adopted-provider-4/libraries-requested.txt'
command=['C:/Program Files/R/R-4.6.1/bin/Rscript.exe','--vanilla',str(E/'tools/literature/edger_historical_cpm_reference.R'),str(B/'reference-2/original/original-returns.rds'),str(B/'source-intake-1'),str(O/'original'),str(runtime.parent),str(libs)]
env=dict(os.environ,LC_ALL='C',LANG='C')
with (O/'R.stdout').open('xb') as so,(O/'R.stderr').open('xb') as se:p=subprocess.run(command,cwd=E,env=env,stdout=so,stderr=se,timeout=180)
(O/'PROCESS.json').write_bytes(enc(dict(command=command,exit_code=p.returncode)))
print((O/'R.stdout').read_text(errors='replace')[-1500:]);print((O/'R.stderr').read_text(errors='replace')[-1500:]);assert p.returncode==0
assert {str(p):pin(p) for p in runtime.rglob('*') if p.is_file()}==before
dest=E/'src/test/resources/org/jlinalg/differential/edger-normalization/historical-cpm-20261120.zip'
with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in (O/'original').iterdir():
        if p.is_file():z.writestr(p.name,p.read_bytes())
    for n in names:z.writestr('original-source/3.42.4/'+n,(B/'source-intake-1/3.42.4/source/edgeR'/n).read_bytes())
    z.writestr('IDENTICAL-FOUR-EDITION-SOURCES.json',(O/'IDENTICAL-FOUR-EDITION-SOURCES.json').read_bytes())
    z.writestr('reference-driver.R',(E/'tools/literature/edger_historical_cpm_reference.R').read_bytes())
record=dict(status='PASS_ACTUAL_ORIGINAL_EDGER3424_CPM_WITH_FOUR_IDENTICAL_SOURCE_SCOPES',fixture=pin(dest),unchanged_original_package_files=len(before),result=json.loads((O/'original/COMPLETED.json').read_bytes()))
(O/'COMPLETED.json').write_bytes(enc(record));print(json.dumps(record,indent=2),flush=True)
