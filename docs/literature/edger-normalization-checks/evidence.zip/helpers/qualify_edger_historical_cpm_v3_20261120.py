from pathlib import Path
import concurrent.futures,hashlib,json,os,subprocess,zipfile
R=Path('D:/projects/JLinAlg');E=R/'build/edge-1';B=E/'build/edger-high-impact-1';O=B/'historical-cpm-3';O.mkdir(exist_ok=False)
def pin(p):
    with Path(p).open('rb') as f:return dict(bytes=Path(p).stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
def enc(v):return (json.dumps(v,indent=2)+'\n').encode()
versions=['3.32.1','3.36.0','3.40.2','3.42.4'];names=['R/cpm.R','R/rpkm.R','R/makeCompressedMatrix.R','src/R_calculate_cpm.cpp','src/add_prior.cpp','src/objects.h','src/objects.cpp','src/utils.h','src/add_prior.h']
comparison={n:{v:pin(B/'source-intake-1'/v/'source/edgeR'/n) for v in versions} for n in names}
(O/'SOURCE-COMPARISON.json').write_bytes(enc(dict(files=comparison,scope='Actual separate original providers are executed; no full-package or complete-header equivalence is assumed.')))
old=B/'historical-cpm-1';assert not (old/'FAILURE.json').exists()
(old/'FAILURE.json').write_bytes(enc(dict(status='FAIL2_OVERBROAD_HEADER_IDENTITY_ASSERTION',scientific_process_run=False,
    error='Four CPM/RPKM R/kernel files match, but not all selected header bytes. The first helper stopped before R execution.',superseded_by='historical-cpm-3: separate actual original providers, with failed whole-package scopes still SKIP3',source_comparison=comparison)))
kernel_old=B/'kernel-cpm-1';(kernel_old/'FAILURE.json').write_bytes(enc(dict(status='FAIL2_MAKE_OUTPUT_PATH_RECORDING',scientific_analysis_run=False,compiler_exit_codes=[0,0],
    error='Backslash output paths were consumed by make. Original source copies, logs and misplaced DLLs remain at their original private paths. No producer was admitted.',
    retained_DLLs={str(p.relative_to(kernel_old)):pin(p) for p in kernel_old.rglob('*.dll')},superseded_by='kernel-cpm-2 uses POSIX output paths; original algorithms unchanged')))
libs=R/'build/literature-review/monocle-runtime/idep244-adopted-provider-4/libraries-requested.txt'
def qualify(version):
    folder=O/version;folder.mkdir();kernel=version in ['3.32.1','3.36.0'];kind='original-kernel' if kernel else 'package'
    if kernel:
        assert (B/('runtime-'+version+'-1/SKIP3.json')).is_file();runtime=B/'kernel-cpm-2'/version;provider=runtime/('original-edger-'+version+'.dll')
        assert json.loads((runtime/'COMPLETED.json').read_bytes())['source_algorithms_modified'] is False
    else:
        runtime=B/('runtime-'+version+'-1/R-lib/edgeR');provider=runtime.parent;assert json.loads((runtime.parents[1]/'COMPLETED.json').read_bytes())['exit_code']==0
    before={str(p):pin(p) for p in runtime.rglob('*') if p.is_file()};(folder/'RUNTIME-BEFORE.json').write_bytes(enc(before))
    command=['C:/Program Files/R/R-4.6.1/bin/Rscript.exe','--vanilla',str(E/'tools/literature/edger_historical_cpm_reference.R'),str(B/'reference-2/original/original-returns.rds'),str(B/'source-intake-1'),str(folder/'original'),str(provider),str(libs),version,kind]
    with (folder/'R.stdout').open('xb') as so,(folder/'R.stderr').open('xb') as se:p=subprocess.run(command,cwd=E,env=dict(os.environ,LC_ALL='C',LANG='C'),stdout=so,stderr=se,timeout=180)
    (folder/'PROCESS.json').write_bytes(enc(dict(command=command,exit_code=p.returncode,provider=kind)))
    assert p.returncode==0,(version,(folder/'R.stderr').read_text(errors='replace'))
    assert {str(p):pin(p) for p in runtime.rglob('*') if p.is_file()}==before
    row=dict(status='PASS_ORIGINAL_PROVIDER_CPM_RPKM_AND_UNCHANGED_FILES',version=version,provider=kind,unchanged_files=len(before),result=json.loads((folder/'original/COMPLETED.json').read_bytes()))
    (folder/'COMPLETED.json').write_bytes(enc(row));print(version,kind,row['result']['transforms'],'actual original transforms',flush=True);return version,row
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=dict(pool.map(qualify,versions))
dest=E/'src/test/resources/org/jlinalg/differential/edger-normalization/historical-cpm-20261120.zip'
with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for version in versions:
        for p in (O/version/'original').iterdir():
            if p.is_file():z.writestr(version+'/'+p.name,p.read_bytes())
        for n in names:z.writestr('original-source/'+version+'/'+n,(B/'source-intake-1'/version/'source/edgeR'/n).read_bytes())
    z.writestr('SOURCE-COMPARISON.json',(O/'SOURCE-COMPARISON.json').read_bytes());z.writestr('reference-driver.R',(E/'tools/literature/edger_historical_cpm_reference.R').read_bytes())
record=dict(status='PASS_FOUR_ACTUAL_ORIGINAL_HISTORICAL_EDGER_CPM_PROVIDERS',fixture=pin(dest),results=results,original_returns=sum(r['result']['transforms'] for r in results.values()),inference_run=False,
    full_package_SKIPs=['3.32.1: R4.6 LAPACK character-length ABI','3.36.0: R4.6 LAPACK character-length ABI'],author_hosts_reproduced=False)
(O/'COMPLETED.json').write_bytes(enc(record));print(json.dumps({k:v for k,v in record.items() if k!='results'},indent=2),flush=True)
