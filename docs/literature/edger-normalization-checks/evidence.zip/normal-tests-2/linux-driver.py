import json,os,subprocess,sys,tarfile
java,junit,jar,classes,resources,reports,root,audit,historical,archive,*selected=sys.argv[1:]
assert not os.path.exists(root);os.makedirs(root)
command=[java,'-Xmx2g','-Domicsmatic.edger.test_root='+root,'-Domicsmatic.edger.reference.audit='+audit,'-Domicsmatic.edger.historical.audit='+historical,'-jar',junit,'execute','--disable-banner','--details=summary','--reports-dir',reports,'--class-path',os.pathsep.join([classes,jar,resources]),*selected]
p=subprocess.run(command,cwd=root)
with tarfile.open(archive,'x') as t:t.add(root,arcname='linux21-native-test-root',recursive=True)
sys.exit(p.returncode)
