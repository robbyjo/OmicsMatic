from pathlib import Path
import hashlib,json,os,zipfile

ROOT=Path('D:/projects/JLinAlg');CHECKOUT=ROOT/'build/arrowcat-1'
OUT=ROOT/'build/literature-review/monocle-runtime/arrow-catalog-isolated-check-1'
DATA=ROOT/'docs/literature/arrow-catalog-validation'
def load(path):return json.loads(Path(path).read_bytes())
def pin(path):
    raw=Path(path).read_bytes();return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
full=load(OUT/'COMPLETED.json')
assert full['status']=='PASS_ISOLATED_ALL_PREDECESSORS_ARROW_PRIMARY_COUNTS_AND_BROWSER'
assert full['processes'][-1]['exit_code']==0
assert (full['scientific']['new_scoped_integrations'],full['scientific']['missing'],full['scientific']['registry_definitions'])==(115,264,476)
transferred=load(OUT/'TRANSFERRED.json')['files']
for name,expected in transferred.items():
    assert pin(ROOT/name)==expected,name
    assert pin(CHECKOUT/name)==expected,name
files={}
def add(name,path):
    assert name not in files,name
    files[name]=Path(path).read_bytes()
def tree(stem,root,extensions=None,excluded=()):
    for parent,dirs,names in os.walk(root):
        dirs[:]=[d for d in dirs if d not in excluded]
        for name in sorted(names):
            path=Path(parent)/name
            if extensions is None or path.suffix.lower() in extensions:
                add(stem+'/'+path.relative_to(root).as_posix(),path)
tree('isolated-controller-and-browser',OUT)
tree('cumulative-scientific-reports',CHECKOUT/'build/literature-review',
    extensions={'.json','.stdout','.stderr','.md'},excluded={'frozen','xml','home','tmp'})
tree('controller-source',ROOT/'build/literature-review/monocle-runtime/arrow-catalog-bootstrap-1',extensions={'.py'})
for name in ['arrow-catalog-validation.json','arrow1201-role-coverage.json','arrow-reviews-shared-source-compatibility.json']:
    add('admission-proof/'+name,ROOT/'docs/literature/omics-2023-2026'/name)
history=dict(status='PREPARATION_GUARDS_RETAINED_NO_SCIENTIFIC_GATE_OR_SOURCE_HASH_CHANGED',
    observations=[
        'Fresh worktree inherited the system core.autocrlf=true despite the creation-command override; LICENSE was CRLF rather than the committed LF blob.',
        'The preparation guard rejected it before cache/legacy CLI setup. The first controller guard then rejected the absent BASE-PREPARED receipt before running tests.',
        'Only isolated LICENSE was restored from the exact 4ad178ef Git blob. Git retained a phantom status change although both object IDs matched.',
        'Set core.autocrlf=false only in this isolated worktree and renormalized its LICENSE index entry; the staged/index/HEAD blob remained identical and status became clean.',
        'The subsequent isolated source census, invariants, browser and complete scientific audit passed without changing an old program, evidence file or verification hash.'
    ],root_user_index_changed_by_preparation=False,shared_development_CLI_written=False,
    license_correction=load(OUT/'LICENSE-CHECKOUT-CORRECTION.json'))
files['SETUP-HISTORY.json']=(json.dumps(history,indent=2)+'\n').encode()
assert len(files)==len(set(n.casefold() for n in files))
manifest={n:dict(bytes=len(v),sha256=hashlib.sha256(v).hexdigest()) for n,v in files.items()}
files['REPORT-MANIFEST.json']=(json.dumps(dict(files=manifest),indent=2)+'\n').encode()
DATA.mkdir(exist_ok=False);(DATA/'.gitattributes').write_bytes(b'* -text whitespace=cr-at-eol\n')
bundle=DATA/'catalog-validation-records.zip'
with zipfile.ZipFile(bundle,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,raw in sorted(files.items()):
        info=zipfile.ZipInfo(name,(2026,11,15,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
        archive.writestr(info,raw)
proof=load(ROOT/'docs/literature/omics-2023-2026/arrow-catalog-validation.json')
record=dict(status=full['status'],scientific=full['scientific'],browser=full['browser'],
    validation_bundle=pin(bundle),validation_bundle_members=len(files),
    selected_snapshot_base='4ad178efde5b109fdf3f9838c58a06851de2dfdb',
    catalog_proof=pin(ROOT/'docs/literature/omics-2023-2026/arrow-catalog-validation.json'),
    metadata_after=proof['after_files'],selected_files=len(transferred),
    complete_scientific_audit_seconds=full['processes'][-1]['seconds'],
    browser_mobile_screenshot_visually_inspected=True,
    prior_scientific_sources_and_hashes_unchanged=True,scientific_overlays=False,
    exact_git_license_restored_only_in_isolated_checkout=True,initial_setup_guards_retained=True,
    root_Gradle_executed=False,shared_development_CLI_written=False,
    public_site_deployed=False,whole_goal_complete=False)
(DATA/'VALIDATION.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
(DATA/'README.md').write_text('# R Arrow catalog validation\n\n'
    'All cumulative scientific gates and the 250-source census passed in an isolated 4ad178ef checkout '
    'with the historically qualified legacy CLI. The root development build and unrelated work were left untouched. '
    'The selected update admits one existing R Arrow family, changes one coverage note in one observation/review '
    'and preserves every primary fact. It adds no papers, observations, reviews or registry definitions.\n\n'
    'The catalog has 115 scoped new integrations (20 native subsets and 95 upstream workflows), '
    '118 including existing adapters, and 264 missing named families. Its 250 papers, 438 families, '
    '2,679 observations, 1,180 reviewed uses and 476 cumulative definitions remain unchanged. '
    '1,499 uses await review; the full objective is incomplete.\n\n'
    'Five catalog tests passed. Actual Edge/Playwright desktop 1440x1000 and mobile-dark 390x1000 '
    'checks verified the P059 row, R Arrow card, complete paper/tool lists, source-build restrictions, '
    'counters and visible recovery warnings. No browser errors or mobile warning overflow occurred. '
    'The mobile screenshot was visually inspected.\n\n'
    'The complete prior mapping and DoubletFinder gates ran unchanged. The Arrow replay checked all '
    '984 frozen members and thirteen complete saved comparisons. The missing-column trace-only '
    'caller-context difference remains explicit; no condition field is removed or coerced. '
    'The invalidated patched-C++ candidate stays retained and unqualified.\n\n'
    'A fresh-checkout LICENSE line-ending guard failed before scientific execution. The exact committed '
    'license bytes were restored only in the isolated checkout, and its identical Git index entry '
    'was refreshed. SETUP-HISTORY.json and the original checked-out bytes preserve that preparation history. '
    'No preceding verifier or old hash was changed.\n\n'
    'The report archive retains controller/process records, scientific summaries, source-census and '
    'complete-comparison reports, browser screenshots and a full member manifest. It excludes duplicate '
    'frozen scientific payloads, XML cache and scratch directories; those original inputs remain in '
    'their already qualified evidence archives. Development HTML was not deployed. '
    'Read ARROW1201_CATALOG_INTEGRATION.md for source scope, setup, SKIP3/FAIL2 and recovery.\n',encoding='utf-8')
print(json.dumps(dict(status=record['status'],members=len(files),bundle=pin(bundle))),flush=True)
