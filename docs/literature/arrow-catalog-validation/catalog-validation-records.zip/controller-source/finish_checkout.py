from pathlib import Path
import hashlib,json,shutil,subprocess
ROOT=Path('D:/projects/JLinAlg');CHECKOUT=ROOT/'build/arrowcat-1'
OUT=ROOT/'build/literature-review/monocle-runtime/arrow-catalog-isolated-check-1'
def pin(path):
    digest=hashlib.sha256();size=0
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1048576),b''):digest.update(block);size+=len(block)
    return dict(bytes=size,sha256=digest.hexdigest())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=CHECKOUT).decode().strip()=='4ad178efde5b109fdf3f9838c58a06851de2dfdb'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=CHECKOUT)
assert pin(CHECKOUT/'LICENSE')==dict(bytes=35149,sha256='3972dc9744f6499f0f9b2dbf76696f2ae7ad8af9b23dde66d6af86c9dfb36986')
cache=CHECKOUT/'build/literature-review/xml';cache.mkdir(parents=True)
for path in (ROOT/'build/literature-review/xml').glob('*.xml.gz'):shutil.copyfile(path,cache/path.name)
legacy=ROOT/'build/smapcat-1/build/cli/omicsmatic-0.3.7.jar'
assert pin(legacy)==dict(bytes=164898617,sha256='545917aaf820f2fe404873e1f0bc72186ebe90d3a11fd7f6f26f592115fbf2f2')
target=CHECKOUT/'build/cli/omicsmatic-0.3.7.jar';target.parent.mkdir(parents=True);shutil.copyfile(legacy,target)
assert pin(target)==pin(legacy)
record=dict(status='PASS_CLEAN_ISOLATED_BASE_CACHE_LEGACY_CLI_AND_GIT_LICENSE',base='4ad178efde5b109fdf3f9838c58a06851de2dfdb',
    checkout=str(CHECKOUT),xml_files=len(list(cache.glob('*.xml.gz'))),legacy_CLI=pin(target),
    exact_committed_license=True,root_Gradle_executed=False,shared_development_CLI_written=False,
    first_checkout_line_ending_guard_failed_and_retained=True)
(OUT/'BASE-PREPARED.json').open('x',encoding='utf-8').write(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
