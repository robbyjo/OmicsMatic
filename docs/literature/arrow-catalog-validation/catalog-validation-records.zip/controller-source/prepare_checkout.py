from pathlib import Path
import hashlib,json,shutil,subprocess
ROOT=Path('D:/projects/JLinAlg')
BASE=ROOT/'build/literature-review/monocle-runtime'
OUT=BASE/'arrow-catalog-isolated-check-1'
CHECKOUT=ROOT/'build/arrowcat-1'
OUT.mkdir(exist_ok=False)
expected='4ad178efde5b109fdf3f9838c58a06851de2dfdb'
def git(*args,cwd=ROOT):return subprocess.check_output(['git',*args],cwd=cwd).decode().strip()
def pin(path):
    digest=hashlib.sha256();size=0
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1048576),b''):digest.update(block);size+=len(block)
    return dict(bytes=size,sha256=digest.hexdigest())
assert git('rev-parse','HEAD')==expected
subprocess.run(['git','-c','core.autocrlf=false','worktree','add','--detach',str(CHECKOUT),expected],cwd=ROOT,check=True)
assert not git('status','--porcelain',cwd=CHECKOUT)
assert git('hash-object','--no-filters','LICENSE',cwd=CHECKOUT)==git('rev-parse',expected+':LICENSE')
cache=CHECKOUT/'build/literature-review/xml';cache.mkdir(parents=True)
for path in (ROOT/'build/literature-review/xml').glob('*.xml.gz'):shutil.copyfile(path,cache/path.name)
legacy=ROOT/'build/smapcat-1/build/cli/omicsmatic-0.3.7.jar'
assert pin(legacy)==dict(bytes=164898617,sha256='545917aaf820f2fe404873e1f0bc72186ebe90d3a11fd7f6f26f592115fbf2f2')
target=CHECKOUT/'build/cli/omicsmatic-0.3.7.jar';target.parent.mkdir(parents=True);shutil.copyfile(legacy,target)
assert pin(target)==pin(legacy)
record=dict(status='PASS_CLEAN_ISOLATED_BASE_CACHE_LEGACY_CLI_AND_GIT_LICENSE',base=expected,
    checkout=str(CHECKOUT),xml_files=len(list(cache.glob('*.xml.gz'))),legacy_CLI=pin(target),
    exact_committed_license=True,root_Gradle_executed=False,shared_development_CLI_written=False)
(OUT/'BASE-PREPARED.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record))
