from pathlib import Path
import functools,hashlib,http.server,json,os,shutil,subprocess,sys,threading,time

ROOT=Path('D:/projects/JLinAlg')
CHECKOUT=ROOT/'build/arrowcat-1'
OUT=ROOT/'build/literature-review/monocle-runtime/arrow-catalog-isolated-check-1'
PYTHON=Path(sys.executable)
sys.path.insert(0,str(ROOT/'tools/literature'))
from arrow_catalog.model import META,PROOF,COVERAGE,COMPATIBILITY,GUIDE,CURRENT,MODULE,EVIDENCE

def pin(path):
    raw=Path(path).read_bytes();return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(value,indent=2)+'\n')
assert (OUT/'BASE-PREPARED.json').is_file()
assert (ROOT/PROOF).is_file()
names=set(META)|{PROOF,COVERAGE,COMPATIBILITY,GUIDE,CURRENT}
names.update(p.relative_to(ROOT).as_posix() for folder in [ROOT/MODULE,ROOT/EVIDENCE] for p in folder.rglob('*') if p.is_file())
assert len(names)==26,len(names)
before={n:pin(ROOT/n) for n in sorted(names)}
for name in sorted(names):
    dest=CHECKOUT/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/name,dest)
    assert pin(dest)==before[name]
save(OUT/'TRANSFERRED.json',dict(files=before,selected_files=len(names),base='4ad178efde5b109fdf3f9838c58a06851de2dfdb'))
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1')
calls=[]
def run(label,command):
    command=list(map(str,command));began=time.monotonic()
    with (OUT/(label+'.stdout')).open('xb') as stdout,(OUT/(label+'.stderr')).open('xb') as stderr:
        child=subprocess.Popen(command,cwd=CHECKOUT,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr)
        save(OUT/(label+'-LIVE.json'),dict(pid=child.pid,command=command))
        while True:
            try:code=child.wait(timeout=10);break
            except subprocess.TimeoutExpired:print('SAME_ISOLATED_ARROW_CATALOG_CHILD_RUNNING',label,child.pid,flush=True)
    record=dict(command=command,exit_code=code,seconds=time.monotonic()-began)
    save(OUT/(label+'-PROCESS.json'),record);calls.append(dict(label=label,**record))
    print('ISOLATED_ARROW_CATALOG_PROCESS',label,code,flush=True)
    if code:raise RuntimeError(label+' failed; inspect full logs')

run('unit',[PYTHON,'-X','utf8','-B','-m','unittest','discover','-s','tools/literature/arrow_catalog','-p','test_catalog.py','-v'])
class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*args):pass
handler=functools.partial(QuietHandler,directory=str(CHECKOUT/'site'))
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),handler)
thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
try:
    run('browser',[Path('C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe'),
        CHECKOUT/'tools/literature/arrow_catalog/check_ui.cjs',
        'C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules',
        'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',OUT/'browser',
        'http://127.0.0.1:'+str(server.server_address[1])])
finally:
    server.shutdown();server.server_close();thread.join()

run('full-scientific',[PYTHON,'-X','utf8','-B',CHECKOUT/'tools/literature/arrow_catalog/catalog.py',
    '--verify','--rescan-sources',
    '--runtime','/opt/omicsmatic-arrow1201-pristine-public-offline-install-20261114-1/provider',
    '--prior-runtime','/mnt/d/projects/JLinAlg/build/literature-review/monocle-runtime/scrattch02-public-provider-live-scan-1',
    '--doubletfinder-runtime','/opt/omicsmatic-doubletfinder206-public-install-20261114-3/provider',
    '--wsl-distro','JLinAlg-Omics-SAIGE-20261026',
    '--out',CHECKOUT/'build/literature-review/monocle-runtime/current-arrow-catalog-check-1'])
for name,expected in before.items():
    assert pin(CHECKOUT/name)==expected,name
    assert pin(ROOT/name)==expected,'Concurrent root catalog edit: '+name
result=json.loads((CHECKOUT/'build/literature-review/monocle-runtime/current-arrow-catalog-check-1/COMPLETED.json').read_bytes())
assert (result['new_scoped_integrations'],result['missing'],result['registry_definitions'])==(115,264,476)
save(OUT/'COMPLETED.json',dict(status='PASS_ISOLATED_ALL_PREDECESSORS_ARROW_PRIMARY_COUNTS_AND_BROWSER',
    source_base='4ad178efde5b109fdf3f9838c58a06851de2dfdb',selected_files=len(names),
    scientific=result,browser=json.loads((OUT/'browser/COMPLETED.json').read_bytes()),processes=calls,
    root_Gradle_executed=False,shared_development_CLI_written=False,whole_goal_complete=False))
print('PASS_ISOLATED_ALL_PREDECESSORS_ARROW_PRIMARY_COUNTS_AND_BROWSER',flush=True)
