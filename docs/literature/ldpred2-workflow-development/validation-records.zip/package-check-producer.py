from pathlib import Path
import hashlib,json,shutil,struct,subprocess,time,zipfile

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
LAB=OUT/'package-checks'
LAB.mkdir(exist_ok=False)
JAVA='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe'

def save(name,obj):
    with (LAB/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(obj,f,indent=2);f.write('\n')

def pin(p):
    raw=p.read_bytes();return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

def classes(p):
    with zipfile.ZipFile(p) as z:return {n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.endswith('.class')}

jar=LAB/'candidate.jar';shutil.copy2(ROOT/'build/cli/omicsmatic-0.4.0.jar',jar)
before=classes(OUT/'final-validation/pre-workflow.jar');after=classes(jar)
changed=[n for n in before if before[n]!=after.get(n)]
added=sorted(set(after)-set(before))
save('CLASS-CONTINUITY.json',dict(previous_classes=len(before),changed=changed,added=added))
assert not changed,changed
assert all(n.startswith(('org/jlinalg/cli/LdPred2Workflow','org/jlinalg/cli/LdPred2OriginalRuntime','org/jlinalg/genetics/LdPred2Seeds')) for n in added),added
with zipfile.ZipFile(ROOT/'src/test/resources/org/jlinalg/genetics/ldpred2-whole-grid-r433.zip') as z:
    ref={n:z.read(n).decode() for n in z.namelist()}
data=LAB/'data';data.mkdir();stats=[[float(s) for s in row.split('\t')] for row in ref['summary.tsv'].splitlines()];ld=[[float(s) for s in row.split('\t')] for row in ref['ld.tsv'].splitlines()];m=len(stats)
labels=[('NA' if i==0 else 'v'+str(i))+'\tA\tG' for i in range(m)]
(data/'summary.tsv').write_text('variant\teffect_allele\tother_allele\tbeta\tbeta_se\tn_eff\n'+''.join(label+'\t'+'\t'.join(map(str,row))+'\n' for label,row in zip(labels,stats)),encoding='utf-8')
(data/'variants.tsv').write_text('variant\teffect_allele\tother_allele\n'+'\n'.join(labels)+'\n',encoding='utf-8')
pointers=[];rows=[];values=[]
for col in range(m):
    pointers.append(len(rows))
    for row in range(m):
        if ld[row][col]!=0:rows.append(row);values.append(ld[row][col])
pointers.append(len(rows))
for name,fmt,seq in [('p.bin','i',pointers),('i.bin','i',rows),('x.bin','d',values)]:
    (data/name).write_bytes(struct.pack('<'+fmt*len(seq),*seq))
models='model\th2\tp\tsparse\n'
for k,line in enumerate(ref['grid.tsv'].splitlines(),1):
    p,h,s=line.split('\t');models+=f'm{k}\t{h}\t{p}\t'+('true' if s=='1' else 'false')+'\n'
(data/'models.tsv').write_text(models,encoding='utf-8')
base='engine=native\nmethod=grid\nsummary=summary.tsv\nld_variants=variants.tsv\nld_pointers=p.bin\nld_rows=i.bin\nld_values=x.bin\ngenome_build=synthetic\nld_population=synthetic\nmodels=models.tsv\nseed=4096\nburn_in=10\niterations=20\njava_heap_mb=256\n'
request=data/'request.properties';request.write_text(base,encoding='utf-8')
checks=[]

def run(label,command,expected=0):
    command=list(map(str,command));start=time.monotonic()
    with (LAB/(label+'.stdout')).open('xb') as so,(LAB/(label+'.stderr')).open('xb') as se:p=subprocess.run(command,cwd=ROOT,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=180)
    record=dict(label=label,command=command,exit_code=p.returncode,expected_exit_code=expected,seconds=round(time.monotonic()-start,3));save(label+'.process.json',record);checks.append(record);print(json.dumps(record),flush=True)
    assert p.returncode==expected,(label,p.returncode)

cli='org.jlinalg.cli.LdPred2WorkflowCli';win=[JAVA,'-Xmx256m','-cp',jar,cli]
run('windows-help',win+['--help'])
run('windows-native-grid',win+['--request',request,'--out',LAB/'windows-grid'])
run('windows-genuine-replay',win+['--verify',LAB/'windows-grid','--out',LAB/'windows-replay'])
def linux(p):
    p=p.resolve().as_posix();return '/mnt/'+p[0].lower()+p[2:]
lin=['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/timeout','--kill-after=5','120','/usr/bin/java','-Xmx256m','-cp',linux(jar),cli]
run('linux-genuine-replay-of-windows-grid',lin+['--verify',linux(LAB/'windows-grid'),'--out',linux(LAB/'linux-replay')])
expected=[[float(s) for s in line.split('\t')] for line in ref['effects.tsv'].splitlines()];maxerror=0
for k in range(6):
    got=[float(s.split('\t')[3]) for s in (LAB/f'windows-grid/results/m{k+1}/effects.tsv').read_text().splitlines()[1:]]
    maxerror=max(maxerror,max(abs(got[i]-expected[i][k]) for i in range(m)))
assert maxerror<2e-13,maxerror
(data/'auto.tsv').write_text('model\tp_init\nchain1\t0.1\n',encoding='utf-8')
auto=base.replace('engine=native','engine=original').replace('method=grid','method=auto').replace('models=models.tsv','models=auto.tsv')+'heritability=0.3\nruntime=missing-runtime\n'
auto_request=data/'original.properties';auto_request.write_text(auto,encoding='utf-8')
run('windows-original-prerequisite-skip',win+['--request',auto_request,'--out',LAB/'windows-skipped'],3)
run('linux-missing-original-runtime-skip',lin+['--request',linux(auto_request),'--out',linux(LAB/'linux-skipped')],3)
for folder in ['windows-skipped','linux-skipped']:
    assert not (LAB/folder/'COMPLETED.properties').exists()
    assert 'SKIP3' in (LAB/folder/'FAILURE.txt').read_text()
save('COMPLETED.json',dict(status='PASS_SCOPED_NATIVE_WORKFLOW_PACKAGE_CHECKS',candidate=pin(jar),checks=checks,original_whole_grid_effect_max_abs_error=maxerror,previous_classes_unchanged=len(before),original_runtime_analysis_executed=False,original_adapter_qualified=False,new_catalog_credit=0,whole_goal_complete=False))
print('PASS_SCOPED_NATIVE_WORKFLOW_PACKAGE_CHECKS',flush=True)
