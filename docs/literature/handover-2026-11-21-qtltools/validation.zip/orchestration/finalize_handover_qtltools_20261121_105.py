from pathlib import Path
import ast,hashlib,json,re,zipfile
from prepare_handover_qtltools_20261121_105 import R,D,T,O,BASE,git,inventory,pin,save

Q=T/'docs/literature/handover-2026-11-21-qtltools';B=T/'build/handover-105-checks'

if __name__=='__main__':
    profile=json.loads((Q/'PROFILE.json').read_bytes());states=json.loads((Q/'WORKTREES.json').read_bytes())
    for label in ['current-windows','current-linux','previous-windows-2','previous-linux-2']:
        assert json.loads((O/(label+'.PROCESS.json')).read_bytes())['exit_code']==0,label
    a=json.loads((B/'current-windows/RESULT.json').read_bytes());b=json.loads((B/'current-linux/RESULT.json').read_bytes())
    assert a.pop('restored') is True and b.pop('restored') is False and a==b
    assert (a['historical_worktrees'],a['git_visible_files'],a['staged_patches'],a['draft_files'],a['evidence_files'])==(61,2234,61,6,66)
    restored=0
    for index,state in enumerate(states):
        root=B/'current-windows/worktrees'/f'{index:02d}'
        assert json.loads((root/'STATE.json').read_bytes())==state
        assert pin((root/'INDEX.patch').read_bytes())=={key:state['index_patch'][key] for key in ['bytes','sha256']}
        for name,wanted in state['files'].items():
            path=root/'files'/name
            if wanted is None:assert not path.exists()
            else:assert pin(path.read_bytes())=={key:wanted[key] for key in ['bytes','sha256']};restored+=wanted is not None
    for name,wanted in json.loads((Q/'INVENTORY.json').read_bytes()).items():assert pin((B/'current-windows/evidence'/name).read_bytes())==wanted
    mapping=json.loads((T/'tools/literature/qtltools_workflow_development/RESTORE.json').read_bytes())
    for name,row in mapping.items():assert (D/name).read_bytes()==(T/row['draft']).read_bytes(),name
    old=git(T,'show',BASE+':docs/literature/HANDOVER_CURRENT.md');new=(T/'docs/literature/HANDOVER_CURRENT.md').read_bytes();heading=b'# Current toolbox handover\n\n'
    assert new.startswith(heading) and new.endswith(old[len(heading):])
    links=0
    for path in [T/'docs/literature/HANDOVER_2026-11-21_QTLTOOLS.md',T/'tools/literature/qtltools_workflow_development/README.md',Q/'README.md']:
        for name in re.findall(r'\]\(([^)]+)\)',path.read_text(encoding='utf-8')):
            if ':' in name or name.startswith('#'):continue
            assert (path.parent/name.split('#',1)[0]).resolve().exists(),(str(path),name);links+=1
    for name in profile['source_inputs']:
        if name.endswith('.py'):ast.parse((T/name).read_text(encoding='utf-8'),filename=name)
    controls=json.loads((O/'NEGATIVE-CONTROLS.json').read_bytes());assert len(controls)==3 and all(row['refused'] and row['exit_code']==2 for row in controls.values())
    for name,wanted in profile['canonical_unchanged'].items():assert pin((T/name).read_bytes())==wanted,name
    assert not git(T,'diff',BASE,'--name-only','--','src','site','.github','build.gradle','settings.gradle','gradle.properties','tools/literature/reviewed-uses.json','docs/literature/omics-2023-2026')
    inv=inventory()
    for state in json.loads((O/'WORKTREES-BEFORE.json').read_bytes()):assert inv.snapshot(Path(state['root']))==state,state['root']
    sources={}
    def include(name,path):assert path.is_file();sources[name]=path
    for name in ['run_handover_qtltools_checks_20261121_105.py','retry_previous_qtltools_handover_20261121_105.py','control_handover_qtltools_20261121_105.py','finalize_handover_qtltools_20261121_105.py']:
        include('orchestration/'+name,R/'build'/name)
    for label in ['current-windows','current-linux','previous-windows','previous-windows-2','previous-linux-2']:
        for suffix in ['STARTED.json','PROCESS.json','stdout','stderr']:include('readers/'+label+'/'+suffix,O/(label+'.'+suffix))
    for label in ['current-windows','current-linux']:include('readers/'+label+'/RESULT.json',B/label/'RESULT.json')
    for host in ['windows','linux']:include('readers/previous-'+host+'-2/RESULT.json',R/'build/qt-1/build'/('handover105-previous-'+host+'-2')/'RESULT.json')
    for label in controls:
        for name in ['STARTED.json','PROCESS.json','stdout','stderr','result/FAILURE.txt']:include('negative-controls/'+label+'/'+name,B/'negative-controls'/label/name)
    include('negative-controls/RESULT.json',O/'NEGATIVE-CONTROLS.json')
    validation_members={}
    patterns=[re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),re.compile(rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b'),re.compile(rb'\bgh[pousr]_[A-Za-z0-9]{36}\b'),re.compile(rb'\bgithub_pat_[A-Za-z0-9_]{50,}\b')]
    with zipfile.ZipFile(Q/'validation.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as target:
        for name,path in sorted(sources.items()):
            raw=path.read_bytes();raw.decode('utf-8');assert not any(pattern.search(raw) for pattern in patterns)
            info=zipfile.ZipInfo(name,(2026,11,21,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;target.writestr(info,raw);validation_members[name]=pin(raw)
    # Validation is supplementary and deliberately outside the frozen packet's own
    # input pins, avoiding self-referential hashes or refreshing any older proof.
    result=dict(status='PASS_UNFINISHED_QTLTOOLS_HANDOVER_TRANSPORT_AND_SCOPE',baseline=BASE,
        original_worktrees_preserved=61,git_visible_files_restored_exact=restored,staged_patches_restored_exact=61,evidence_files_restored_exact=66,
        draft_files_saved_exact=6,windows_restore_and_linux_verify_pass=True,negative_controls=controls,
        prior_frozen_reader_and_exact_normal_JAR_verified_on_windows_and_linux=True,
        retained_initial_reader_refusal='First prior-reader call used the new owner output path;its frozen own-workspace guard refused it. Retried in NEW output under the actual unchanged qt-1 owner;no proof/hash/source was refreshed.',
        java_draft_classes_compile=True,synthetic_generator_compiles=True,python_worker_syntax_pass=True,
        workflow_scientific_execution_run=False,workflow_qualified=False,relative_document_links_checked=links,
        canonical_files_unchanged=len(profile['canonical_unchanged']),prior_handover_content_retained_exact=True,
        production_source_build_site_changed=False,credential_candidates=0,
        profile=pin((Q/'PROFILE.json').read_bytes()),validation_archive=pin((Q/'validation.zip').read_bytes()),validation_members=validation_members,
        catalog=profile['catalog'],scientific_analyses_run_by_handover=0,new_catalog_credit=0,whole_goal_complete=False)
    save(Q/'VALIDATION.json',result);save(O/'VALIDATION.json',result)
    public=[name for name in git(T,'status','--porcelain=v1','-z','--untracked-files=all').decode().split('\0') if name]
    names=sorted(item[3:] for item in public)
    assert all(name=='docs/literature/HANDOVER_CURRENT.md' or name=='docs/literature/HANDOVER_2026-11-21_QTLTOOLS.md' or name=='tools/literature/verify_qtltools_handover.py' or name.startswith('docs/literature/handover-2026-11-21-qtltools/') or name.startswith('tools/literature/qtltools_workflow_development/') for name in names)
    save(O/'PUBLICATION-FILES.json',dict(explicit_paths=names,pins={name:pin((T/name).read_bytes()) for name in names}))
    with (O/'PUBLICATION-FILES.nul').open('xb') as stream:stream.write(b'\0'.join(name.encode() for name in names)+b'\0')
    print(json.dumps(dict(status='HANDOVER_READY_TO_PUBLISH',public_files=len(names),all61_original_owners_preserved=True,restored_files=restored,controls=3,prior_reader_path_refusal_retained=True)),flush=True)
