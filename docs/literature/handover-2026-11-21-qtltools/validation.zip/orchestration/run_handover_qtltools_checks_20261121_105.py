from pathlib import Path
import json,subprocess,sys
from prepare_handover_qtltools_20261121_105 import R,T,O,save

host,scope=sys.argv[1:];assert host in {'windows','linux'} and scope in {'current','previous'}
owner=T if scope=='current' else R/'build/qt-1'
reader='tools/literature/verify_qtltools_handover.py' if scope=='current' else 'tools/literature/qtltools_fdensity/verify.py'
label=scope+'-'+host;out=T/'build/handover-105-checks'/label
def mount(path):return '/mnt/d/'+path.resolve().relative_to(Path('D:/')).as_posix()
if host=='windows':command=['C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe','-X','utf8','-B',str(owner/reader),'--out',str(out)]
else:
    command=['wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','-u','root','--','python3','-B',mount(owner/reader),'--out',mount(out)]
    if scope=='current':command+=['--git','/mnt/c/Program Files/Git/cmd/git.exe']
if scope=='current' and host=='windows':command+=['--restore']
save(O/(label+'.STARTED.json'),dict(command=command,scope='saved byte/scope verification; no scientific execution'))
with (O/(label+'.stdout')).open('xb') as stdout,(O/(label+'.stderr')).open('xb') as stderr:p=subprocess.run(command,cwd=owner,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=600)
save(O/(label+'.PROCESS.json'),dict(exit_code=p.returncode));print(label,'exit',p.returncode,flush=True)
if p.returncode:print((O/(label+'.stderr')).read_text(errors='replace')[-1800:])
else:print((out/'RESULT.json').read_text()[:1300])
raise SystemExit(p.returncode)
