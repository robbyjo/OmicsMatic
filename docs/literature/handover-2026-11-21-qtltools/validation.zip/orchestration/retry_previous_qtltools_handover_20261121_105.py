from pathlib import Path
import subprocess,sys
from prepare_handover_qtltools_20261121_105 import R,O,JAR,save
host=sys.argv[1];assert host in {'windows','linux'}
owner=R/'build/qt-1';out=owner/'build'/('handover105-previous-'+host+'-2');label='previous-'+host+'-2'
reader=owner/'tools/literature/qtltools_fdensity/verify.py'
def mount(path):return '/mnt/d/'+path.resolve().relative_to(Path('D:/')).as_posix()
if host=='windows':command=['C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe','-X','utf8','-B',str(reader),'--out',str(out),'--jar',str(JAR)]
else:command=['wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','-u','root','--','python3','-B',mount(reader),'--out',mount(out),'--jar',mount(JAR)]
save(O/(label+'.STARTED.json'),dict(command=command,reason='Use the frozen reader on its actual unchanged owner and its own NEW build output;preserve initial path refusal'))
with (O/(label+'.stdout')).open('xb') as stdout,(O/(label+'.stderr')).open('xb') as stderr:p=subprocess.run(command,cwd=owner,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=300)
save(O/(label+'.PROCESS.json'),dict(exit_code=p.returncode));print(label,'exit',p.returncode,flush=True)
print(((out/'RESULT.json') if not p.returncode else (O/(label+'.stderr'))).read_text()[:1500]);raise SystemExit(p.returncode)
