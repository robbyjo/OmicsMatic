from pathlib import Path
import copy,json,shutil,subprocess
from prepare_handover_qtltools_20261121_105 import R,T,O,pin,save

Q=Path('docs/literature/handover-2026-11-21-qtltools')
B=T/'build/handover-105-checks/negative-controls';B.mkdir(parents=True)
profile=json.loads((T/Q/'PROFILE.json').read_bytes());results={}
original={name:pin((T/name).read_bytes()) for name in [*profile['source_inputs'],*profile['canonical_unchanged'],str(Q/'PROFILE.json'),*[str(Q/name) for name in profile['packet_files']],profile['prior_archive']['path']]}
for label in ['changed-draft','changed-evidence','promoted-qualification']:
    folder=B/label;root=folder/'checkout';root.mkdir(parents=True)
    for name in original:
        destination=root/name;destination.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(T/name,destination)
    if label=='changed-draft':
        name=next(name for name in profile['source_inputs'] if name.endswith('QtltoolsWorkflowContracts.java'))
        with (root/name).open('ab') as stream:stream.write(b'\n// deliberate negative-control mutation\n')
    elif label=='changed-evidence':
        target=root/Q/'evidence.zip';raw=bytearray(target.read_bytes());raw[len(raw)//2]^=1;target.write_bytes(raw)
    else:
        changed=copy.deepcopy(profile);changed['workflow_qualified']=True;(root/Q/'PROFILE.json').write_text(json.dumps(changed)+'\n',encoding='utf-8')
    command=['C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe','-X','utf8','-B',str(T/'tools/literature/verify_qtltools_handover.py'),'--root',str(root),'--out',str(folder/'result')]
    save(folder/'STARTED.json',dict(command=command,expected_exit_code=2))
    with (folder/'stdout').open('xb') as stdout,(folder/'stderr').open('xb') as stderr:p=subprocess.run(command,cwd=T,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=120)
    failure=(folder/'result/FAILURE.txt').read_text();assert p.returncode==2 and not (folder/'result/RESULT.json').exists(),label
    expected={'changed-draft':'Changed source/canonical','changed-evidence':'Changed handover file','promoted-qualification':'promoted to qualified'}[label]
    assert expected in failure,(label,failure)
    results[label]=dict(exit_code=p.returncode,refused=True,reason=failure.strip());save(folder/'PROCESS.json',dict(exit_code=p.returncode))
for name,wanted in original.items():assert pin((T/name).read_bytes())==wanted,name
save(B/'RESULT.json',results);save(O/'NEGATIVE-CONTROLS.json',results);print('PASS: three actual corrupted-draft/archive/scope refusals;original bytes unchanged',flush=True)
