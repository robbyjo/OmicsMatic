import java.io.File;import java.io.PrintWriter;
import org.junit.platform.launcher.core.*;import org.junit.platform.launcher.listeners.*;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;
public final class StringTieNormalizationChecks {public static void main(String[] args)throws Exception {
for(Class<?> type:new Class<?>[]{org.jlinalg.sequence.StringTieGtf.class,org.jlinalg.sequence.StringTieTables.class,org.jlinalg.sequence.StringTieNormalization.class})if(!type.getProtectionDomain().getCodeSource().getLocation().toURI().equals(new File(args[0]).toURI()))throw new AssertionError("Wrong actual normalization JAR");
var listener=new SummaryGeneratingListener();LauncherFactory.create().execute(LauncherDiscoveryRequestBuilder.request().selectors(selectClass("org.jlinalg.sequence.StringTieGtfTest"),selectClass("org.jlinalg.sequence.StringTieTablesTest"),selectClass("org.jlinalg.sequence.StringTieNormalizationTest")).build(),listener);
var s=listener.getSummary();s.printTo(new PrintWriter(System.out));s.printFailuresTo(new PrintWriter(System.out));
if(s.getTestsFoundCount()!=1256||s.getTestsSucceededCount()!=1256||s.getTestsSkippedCount()!=0||s.getTestsAbortedCount()!=0||s.getTestsFailedCount()!=0||s.getContainersFailedCount()!=0)throw new AssertionError("Incomplete normalization checks");
System.out.println("COMPLETE_STRINGTIE_NORMALIZATION_CHECKS 1256 NO_SKIPS");}}
