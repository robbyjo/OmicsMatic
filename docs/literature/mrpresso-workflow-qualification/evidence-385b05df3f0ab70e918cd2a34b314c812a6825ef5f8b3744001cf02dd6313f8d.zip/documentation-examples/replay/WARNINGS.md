# Warnings and required actions

Native Java original-profile MRPRESSO1.0, commit3e3c92d7eda6dce0d1d66077373ec0f7ff4f7e87, with one outcome and1..64 exposures. Prepared associations only; harmonization, allele selection, weak-instrument filtering, multiple-testing correction, biological causality and study-specific method selection are separate. Original R source is captured as provenance and is not executed. Paper editions/settings remain unreported where unknown. Older analytic PRESSO-style commands are separate methods. Exact input IDs, complete-case row mapping, RNG state, original branch conventions and source probability bounds are retained. No whole-tool/paper or author-environment reproduction, OS memory containment, signature or host-authentication claim.

SKIP3: DEPENDENT ANALYSIS SKIPPED. Supply the exact named permitted file/Java17+ or complete qualified producer JAR; if unavailable or installation is prohibited, keep the skip. FAIL2: NO COMPLETE RESULT. Retain requests, inputs, raw/partial diagnostics, NA/NaN/Inf and failed/superseded evidence; fix the stated input, numerical, resource, timeout or integrity problem and retry NEW output. Read analysis-status.json and WARNINGS.md. Do not repair aliases, impute omitted associations, replace strict probability bounds by zero, add Monte Carlo pseudocounts, clamp original multivariable distortion values or substitute a different engine. VERIFY recomputes the full bounded native calculation; it uses no R process or network. Retain the exact producer JAR for future verification/replay. SHA256 checks byte integrity, not authenticity.

Native/source-profile warnings: []

Results admitted: true

Contains unreportable fields: false. Conditional NA corrected estimates are explicitly marked SOURCE_NOT_ESTIMATED.
