package org.jlinalg.mrpresso;
public final class MrPressoExtendedProbe {
 public static void main(String[] args)throws Exception {
  int count=0;
  for(Class<?> type:java.util.List.of(MrPressoRandomTest.class,MrPressoOriginalTest.class,MrPressoExtendedReferenceTest.class)){
   Object instance=type.getDeclaredConstructor().newInstance();
   for(var method:type.getDeclaredMethods())if(method.isAnnotationPresent(org.junit.jupiter.api.Test.class)){
    System.out.println("RUN "+type.getSimpleName()+"."+method.getName());
    try{method.invoke(instance);}catch(java.lang.reflect.InvocationTargetException failure){throw new RuntimeException(method.getName(),failure.getCause());}count++;
   }
  }
  System.out.println("PASS "+count+" component methods; Java="+System.getProperty("java.version")+"; OS="+System.getProperty("os.name"));
 }
}
