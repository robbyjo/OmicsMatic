$ErrorActionPreference='Stop'
$taskRoot='D:\projects\JLinAlg\build\fu-1\build\mrpresso-1\protocol-controls-1'
$taskSource=Join-Path $taskRoot 'owned-parent'
$taskTarget=Join-Path $taskRoot 'relocated-parent'
$taskResolved=(Resolve-Path -LiteralPath $taskSource).Path
if ($taskResolved -ne $taskSource -or -not $taskTarget.StartsWith($taskRoot+'\',[StringComparison]::OrdinalIgnoreCase) -or (Test-Path -LiteralPath $taskTarget)) { throw 'Unexpected relocation target' }
$taskItem=Get-Item -LiteralPath $taskSource -Force
while ($null -ne $taskItem) { if (($taskItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Reparse point in relocation path' }; $taskItem=$taskItem.Parent }
Rename-Item -LiteralPath $taskSource -NewName 'relocated-parent' -ErrorAction Stop
