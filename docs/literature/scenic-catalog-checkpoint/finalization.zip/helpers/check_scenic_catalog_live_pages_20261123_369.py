from pathlib import Path
import hashlib,json,subprocess,urllib.error,urllib.request
T=Path('D:/projects/JLinAlg/build/fu-1');O=Path('D:/projects/JLinAlg/build/git-publish/20261123-scenic-catalog-355')
run=json.loads((O/'HOSTED-RUN-45225473490.json').read_bytes());assert run['status']=='completed' and run['conclusion']=='success'
base='https://robbyjo.github.io/OmicsMatic/';rows=[]
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
for name in ('','literature-review.html','literature-warnings.html'):
 url=base+name;request=urllib.request.Request(url,headers={'User-Agent':'OmicsMatic-publication-validation','Cache-Control':'no-cache'})
 try:
  with urllib.request.urlopen(request,timeout=45) as response:code=response.status;raw=response.read()
 except urllib.error.HTTPError as error:code=error.code;raw=error.read()
 row=dict(url=url,status=code,response=pin(raw));rows.append(row)
 if name:assert code==404,('Excluded report is reachable',row)
 else:
  assert code==200
  expected=subprocess.check_output(['git','show',run['head_sha']+':site/index.html'],cwd=T);assert raw==expected,'Live homepage differs from the deployed Git blob'
  assert b'literature-review.html' not in raw and b'literature-warnings.html' not in raw
result=dict(status='PASS_DEPLOYED_HOMEPAGE_EXACT_AND_BOTH_LITERATURE_REPORTS_404',deployment_commit=run['head_sha'],workflow_run=run['html_url'],checks=rows,full_checkWebsite_passed=False,known_citation_failures=33)
(O/'LIVE-PAGES.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
