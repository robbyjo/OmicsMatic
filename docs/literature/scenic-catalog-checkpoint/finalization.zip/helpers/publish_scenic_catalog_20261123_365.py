"""Publish selected source/catalog evidence only; preserve unrelated work and restricted refs."""
from pathlib import Path
import ast,hashlib,json,subprocess
from handover_inventory_20261122_111 import snapshot,save,pin,git,entries
R=Path('D:/projects/JLinAlg');T=R/'build/fu-1';O=R/'build/git-publish/20261123-scenic-catalog-355';base='50fec3c4ce99eec755343f02dc1bd5462448659f'
assert git('rev-parse','HEAD',cwd=T).decode().strip()==base and not git('diff','--cached','--name-only',cwd=T)
assert git('ls-remote','origin','refs/heads/main',cwd=T).decode().split()[0]==base
initial=json.loads((O/'WORKTREES-BEFORE.json').read_bytes());owners=snapshot();save(O/'WORKTREES-BEFORE-PUSH.json',owners);assert len(initial)==len(owners)==19
for old in initial:
 if Path(old['worktree'])!=T:assert next(r for r in owners if r['worktree']==old['worktree'])==old,old['worktree']
indexes=json.loads((O/'INDEXES-BEFORE.json').read_bytes());assert all(pin(Path(row['path']))==row['identity'] for owner,row in indexes.items() if Path(owner)!=T)
unmerged=git('for-each-ref','--no-merged=refs/remotes/origin/main','--format=%(refname) %(objectname)','refs/heads').decode().splitlines();assert len(unmerged)==10 and all('codex/handover-20261122-owner' in row or 'codex/release-v0.3.1 ' in row for row in unmerged)
save(O/'UNPUBLISHED-REFS-BEFORE.json',dict(refs=unmerged))
names={'.gitattributes','docs/literature/HANDOVER_CURRENT.md','docs/literature/HANDOVER_2026-11-23.md','docs/literature/SCENIC_CATALOG_CHECKPOINT_2026-11-23.md','tools/literature/close_scenic_catalog.py','tools/literature/verify_scenic_catalog_checkpoint.py','tools/literature/reviewed-uses.json','site/literature-review.html','site/literature-warnings.html'}
names.update('docs/literature/omics-2023-2026/'+n for n in ('papers.json','tool-inventory.json','summary.json','README.md','WARNINGS.md','SHA256SUMS','scenic-source-role-coverage.json','scenic-catalog-validation.json'))
for directory in ('tools/literature/scenic_catalog','docs/literature/scenic-catalog-sources','docs/literature/scenic-catalog-admission','docs/literature/scenic-catalog-checkpoint'):
 names.update(p.relative_to(T).as_posix() for p in (T/directory).rglob('*') if p.is_file())
names=sorted(names);assert set(row['path'] for row in entries(T))==set(names)
for name in names:
 path=T/name;assert path.stat().st_size<25_000_000,name
 if path.suffix=='.py':ast.parse(path.read_text(encoding='utf-8'),filename=name)
reader=json.loads((T/'docs/literature/scenic-catalog-checkpoint/READBACK.json').read_bytes());assert len(reader['checks'])==2 and len(reader['controls'])==3
assert all(r['measured']['counts']['scoped_families']==155 and r['measured']['fresh_primary_XML_checked']==250 for r in reader['checks'])
git('diff','--check',cwd=T);git('add','--',*names,cwd=T)
assert set(git('diff','--cached','--name-only','-z',cwd=T).decode().strip('\0').split('\0'))==set(names)
git('diff','--cached','--check',cwd=T);files={}
for name in names:
 raw=git('show',':'+name,cwd=T);assert raw==(T/name).read_bytes(),('Staged conversion requires investigation',name)
 files[name]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
save(O/'PUBLICATION-FILES.json',files)
print(git('commit','-m','Admit scoped SCENIC workflow and review five paper roles',cwd=T).decode(),flush=True)
head=git('rev-parse','HEAD',cwd=T).decode().strip();save(O/'COMMITTED.json',dict(commit=head,base=base,files=len(files)))
p=subprocess.run(['git','push','origin',head+':refs/heads/main'],cwd=T,stdout=subprocess.PIPE,stderr=subprocess.PIPE);(O/'push.stdout').write_bytes(p.stdout);(O/'push.stderr').write_bytes(p.stderr);save(O/'PUSH.json',dict(commit=head,exit_code=p.returncode,force=False,only_ref='refs/heads/main'));assert p.returncode==0,p.stderr
assert git('ls-remote','origin','refs/heads/main',cwd=T).decode().split()[0]==head
git('fetch','--no-tags','origin','main',cwd=T);assert git('rev-parse','refs/remotes/origin/main',cwd=T).decode().strip()==head
assert not git('status','--porcelain=v1',cwd=T)
save(O/'PUSHED.json',dict(commit=head,files=len(files),force=False,restricted_refs_exported=False))
print(json.dumps(dict(main=head,files=len(files),only_ref='refs/heads/main',current_checkout_clean=True,other_owners_preserved=18),indent=2))
