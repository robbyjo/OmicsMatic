$ErrorActionPreference='Stop'
$workspaceRoot=[IO.Path]::GetFullPath('D:\projects\JLinAlg')
$taskRoot=[IO.Path]::GetFullPath('D:\projects\JLinAlg\build\fu-1\build\scenic-catalog-355')
$receiptRoot='D:\projects\JLinAlg\build\git-publish\20261123-scenic-catalog-355'
$published=Get-Content -LiteralPath (Join-Path $receiptRoot 'RAW-READBACK.json') -Raw | ConvertFrom-Json
if (@($published.failures.PSObject.Properties).Count -ne 0) {throw 'Public recovery readback is incomplete'}
$targets=@(
    'D:\projects\JLinAlg\build\fu-1\build\scenic-catalog-355\ui-preview-1\owned-edge-profile',
    'D:\projects\JLinAlg\build\fu-1\build\scenic-catalog-355\ui-preview-2\owned-edge-profile',
    'D:\projects\JLinAlg\build\fu-1\build\scenic-catalog-355\ui-installed-1\owned-edge-profile'
)
$rows=@()
foreach($path in $targets){
    $target=[IO.Path]::GetFullPath($path)
    if(-not $target.StartsWith($taskRoot+'\',[StringComparison]::OrdinalIgnoreCase)-or (Split-Path -Leaf $target)-cne 'owned-edge-profile'){throw 'Cleanup path escapes task or is not the exact isolated profile'}
    if((Resolve-Path -LiteralPath $target).ProviderPath -cne $target){throw 'Cleanup target resolved differently'}
    $parent=Split-Path -Parent $target
    $closed=Get-Content -LiteralPath (Join-Path $parent 'CLOSE.json') -Raw | ConvertFrom-Json
    if($closed.exit_code-ne 0){throw 'The recorded own-profile close did not pass'}
    $latest=Get-ChildItem -LiteralPath $parent -Filter 'own-processes-after-*.json' | Sort-Object LastWriteTimeUtc -Descending | Select-Object -First 1
    $remaining=@(Get-Content -LiteralPath $latest.FullName -Raw | ConvertFrom-Json)
    if($remaining.Count-ne 0){throw 'The last exact-profile process observation was not empty'}
    $live=@(Get-CimInstance Win32_Process -Filter "Name='msedge.exe'" | Where-Object {$_.CommandLine -and $_.CommandLine.Replace('/','\').IndexOf($target,[StringComparison]::OrdinalIgnoreCase)-ge 0})
    if($live.Count-ne 0){throw 'The isolated profile is referenced by a live process; preserve it'}
    $cursor=$target
    while($cursor.Length-ge $workspaceRoot.Length){
        if((Get-Item -LiteralPath $cursor -Force).Attributes-band [IO.FileAttributes]::ReparsePoint){throw 'Reparse point in cleanup ancestors'}
        $cursor=Split-Path -Parent $cursor
    }
    $pending=New-Object 'System.Collections.Generic.Stack[string]';$pending.Push($target);$files=@();$bytes=0L
    while($pending.Count-gt 0){
        foreach($item in Get-ChildItem -LiteralPath $pending.Pop() -Force){
            if($item.Attributes-band [IO.FileAttributes]::ReparsePoint){throw 'Nested reparse point; preserve the profile'}
            if($item.PSIsContainer){$pending.Push($item.FullName)}else{
                $hash=(Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
                $files += [PSCustomObject]@{path=$item.FullName.Substring($target.Length+1);bytes=$item.Length;sha256=$hash;write_time_utc=$item.LastWriteTimeUtc.ToString('o')};$bytes+=$item.Length
            }
        }
    }
    $rows += [PSCustomObject]@{path=$target;file_count=$files.Count;bytes=$bytes;files=$files;active_processes=0;recorded_close_exit=0;recovery='Recreate a new isolated profile with the retained runner. DOM receipts, screenshots, exact harness sources and raw failed/successful consoles remain in the public evidence packet and private task tree. No exact browser-cache reconstruction is claimed.'}
}
$before=([IO.DriveInfo]::new('D:\')).AvailableFreeSpace
foreach($row in $rows){
    foreach($file in $row.files){
        $now=Get-Item -LiteralPath (Join-Path $row.path $file.path) -Force
        if($now.Length-ne $file.bytes-or $now.LastWriteTimeUtc.ToString('o')-cne $file.write_time_utc){throw 'Profile changed after inspection; preserve remaining targets'}
    }
    Remove-Item -LiteralPath $row.path -Recurse -Force
    if(Test-Path -LiteralPath $row.path){throw 'Cleanup target remains'}
}
$after=([IO.DriveInfo]::new('D:\')).AvailableFreeSpace
$full=[ordered]@{status='COMPLETE_CLOSED_ISOLATED_BROWSER_PROFILES_ONLY';time_utc=[DateTime]::UtcNow.ToString('o');root=$taskRoot;removed=$rows;removed_directories=$rows.Count;removed_files=($rows|Measure-Object -Property file_count -Sum).Sum;verified_file_bytes=($rows|Measure-Object -Property bytes -Sum).Sum;disk_free_before=$before;disk_free_after=$after;measured_free_space_change=$after-$before;note='Measured drive change includes filesystem allocation and unrelated activity. Private browser-profile contents and per-file cache hashes are not published.';preserved=@('all 19 worktrees','all source and catalog metadata','all exact executable JARs and installed runtimes','all scientific captures and raw failures','all primary XML including controlled failures','all screenshots, DOM receipts and browser consoles','all transaction-test evidence','all private/restricted histories')}
[IO.File]::WriteAllText((Join-Path $receiptRoot 'CLEANUP-PRIVATE.json'),($full|ConvertTo-Json -Depth 15)+"`n",[Text.UTF8Encoding]::new($false))
$public=[ordered]@{}
foreach($entry in $full.GetEnumerator()){if($entry.Key-ne 'removed'){$public[$entry.Key]=$entry.Value}}
$public['removed']=@($rows|Select-Object path,file_count,bytes,active_processes,recorded_close_exit,recovery)
$json=($public|ConvertTo-Json -Depth 12)+"`n"
[IO.File]::WriteAllText((Join-Path $receiptRoot 'CLEANUP.json'),$json,[Text.UTF8Encoding]::new($false))
[IO.File]::WriteAllText('D:\projects\JLinAlg\build\fu-1\docs\literature\scenic-catalog-checkpoint\CLEANUP.json',$json,[Text.UTF8Encoding]::new($false))
[PSCustomObject]$public|Select-Object status,removed_directories,removed_files,verified_file_bytes,measured_free_space_change|ConvertTo-Json
