"""Check every selected GitHub byte and preservation of all other worktree owners."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import hashlib,json,urllib.request,urllib.parse
from handover_inventory_20261122_111 import snapshot,save,pin,git
R=Path('D:/projects/JLinAlg');T=R/'build/fu-1';O=R/'build/git-publish/20261123-scenic-catalog-355'
head=json.loads((O/'PUSHED.json').read_bytes())['commit'];wanted=json.loads((O/'PUBLICATION-FILES.json').read_bytes())
def read(name):
 url='https://raw.githubusercontent.com/robbyjo/OmicsMatic/'+head+'/'+urllib.parse.quote(name,safe='/')
 request=urllib.request.Request(url,headers={'User-Agent':'OmicsMatic-handover-readback','Cache-Control':'no-cache'})
 with urllib.request.urlopen(request,timeout=45) as response:raw=response.read()
 actual=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest());assert actual==wanted[name],name
 return name,actual
readback={};failures={}
with ThreadPoolExecutor(max_workers=6) as pool:
 pending={pool.submit(read,name):name for name in wanted}
 for future in as_completed(pending):
  try:name,identity=future.result();readback[name]=identity
  except Exception as error:failures[pending[future]]=repr(error)
save(O/'RAW-READBACK.json',dict(commit=head,files=readback,failures=failures));assert not failures,failures;assert readback==wanted
request=urllib.request.Request('https://api.github.com/repos/robbyjo/OmicsMatic/actions/runs?head_sha='+head,headers={'User-Agent':'OmicsMatic-handover-readback','Accept':'application/vnd.github+json'})
with urllib.request.urlopen(request,timeout=30) as response:runs=json.load(response)
hosted=dict(head_sha=head,total_count=runs['total_count'],runs=[dict(name=r['name'],status=r['status'],conclusion=r['conclusion'],url=r['html_url']) for r in runs['workflow_runs']]);save(O/'HOSTED-RUNS.json',hosted)
after=snapshot();save(O/'WORKTREES-AFTER-PUSH.json',after);before=json.loads((O/'WORKTREES-BEFORE.json').read_bytes());assert len(after)==len(before)==19
for old in before:
 now=next(r for r in after if r['worktree']==old['worktree'])
 if Path(old['worktree'])==T:assert now['HEAD']==head and now['status']==[]
 else:assert now==old,old['worktree']
indexes=json.loads((O/'INDEXES-BEFORE.json').read_bytes());assert all(pin(Path(row['path']))==row['identity'] for owner,row in indexes.items() if Path(owner)!=T)
unmerged=git('for-each-ref','--no-merged=refs/remotes/origin/main','--format=%(refname) %(objectname)','refs/heads').decode().splitlines();assert unmerged==json.loads((O/'UNPUBLISHED-REFS-BEFORE.json').read_bytes())['refs']
save(O/'PRESERVATION-AFTER.json',dict(worktrees=19,other_owners_identical=18,other_indexes_identical=18,restricted_histories_exported=False,current_checkout_clean=True))
print(json.dumps(dict(main=head,public_files_byte_exact=len(readback),other_owners_and_indexes_preserved=18,hosted_runs=hosted),indent=2))
