from pathlib import Path
import hashlib,json,os,subprocess,time
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[2];OUT=BASE/'allelicseries-original-reference-run-1';OUT.mkdir()
installed=json.loads((BASE/'allelicseries-original-install-1/COMPLETED.json').read_bytes())
assert installed['status']=='PRIVATE_ORIGINAL_ALLELICSERIES0112_INSTALLED_NOT_YET_QUALIFIED'
prefix=BASE/'fastmnn129-public-fresh-setup-2/dependency-base/.pixi/envs/default';library=Path(installed['library'])
env={k:v for k,v in os.environ.items() if k not in ['R_LIBS','R_LIBS_USER','R_LIBS_SITE','R_DEFAULT_PACKAGES','R_PROFILE_USER','R_ENVIRON_USER']}
env.update(PATH=str(prefix/'bin')+':/usr/bin:/bin',R_HOME=str(prefix/'lib/R'),LD_LIBRARY_PATH=str(prefix/'lib'),R_PROFILE_USER='/dev/null',R_ENVIRON_USER='/dev/null',LC_ALL='C.UTF-8',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
commands=[('readiness',[str(prefix/'bin/Rscript'),'--vanilla',str(ROOT/'tools/literature/allelicseries0112/check_runtime.R'),str(library),str(prefix/'lib/R/library'),str(BASE/'allelicseries-source-intake-1/candidate-0112-source/AllelicSeries'),str(OUT)]),('original-reference',[str(prefix/'bin/Rscript'),'--vanilla',str(ROOT/'tools/literature/allelicseries0112/OriginalControl.R'),str(library),str(prefix/'lib/R/library'),str(OUT/'reference')])]
calls=[]
for label,command in commands:
    start=time.time()
    with (OUT/(label+'.stdout')).open('xb') as so,(OUT/(label+'.stderr')).open('xb') as se:
        p=subprocess.Popen(command,env=env,stdin=subprocess.DEVNULL,stdout=so,stderr=se);(OUT/'LIVE.json').write_text(json.dumps(dict(label=label,command=command,pid=p.pid,started_unix=start),indent=2)+'\n');code=p.wait()
    row=dict(label=label,command=command,exit_code=code,elapsed_seconds=time.time()-start);calls.append(row);(OUT/(label+'.process.json')).write_text(json.dumps(row,indent=2)+'\n');print(label,'exit',code,flush=True)
    if code:raise SystemExit(code)
(OUT/'COMPLETED.json').write_text(json.dumps(dict(status='ORIGINAL_ALLELICSERIES0112_REFERENCE_CAPTURED',calls=calls,whole_goal_complete=False),indent=2)+'\n')
