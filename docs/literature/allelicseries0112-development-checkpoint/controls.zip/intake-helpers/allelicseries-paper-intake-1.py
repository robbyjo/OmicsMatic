from pathlib import Path
import gzip,hashlib,json,sys,xml.etree.ElementTree as ET
ROOT=Path('D:/projects/JLinAlg');OUT=ROOT/'build/literature-review/monocle-runtime/allelicseries-paper-intake-1';OUT.mkdir();sys.path.insert(0,str(ROOT/'tools/literature'))
from collect_omics_review import paragraphs
census=json.loads((ROOT/'docs/literature/software-frontier-audit/CENSUS.json').read_bytes());anchors=[r for r in census['matches'] if r['tool_id']=='allelicseries'];assert {r['paper_id'] for r in anchors}=={'P204'}
paper=next(p for p in json.loads((ROOT/'docs/literature/omics-2023-2026/papers.json').read_bytes()) if p['paper_id']=='P204')
raw=gzip.decompress((ROOT/'build/literature-review/xml'/(paper['pmcid']+'.xml.gz')).read_bytes());assert hashlib.sha256(raw).hexdigest()==paper['xml_sha256']
ps={p['paragraph_index']:p for p in paragraphs(ET.fromstring(raw))};entries=[];chunks=[];part=[];size=0
for row in anchors:
    p=ps[row['paragraph_index']];assert hashlib.sha256(p['text'].encode()).hexdigest()==row['paragraph_sha256']
    text='P204 paragraph'+str(row['paragraph_index'])+' ['+row['section']+']\n'+p['text']+'\n'
    entries.append(dict(paragraph_index=row['paragraph_index'],section=row['section'],paragraph_sha256=row['paragraph_sha256'],characters=len(p['text'])))
    if part and size+len(text)>10500:chunks.append('\n'.join(part));part=[];size=0
    part.append(text);size+=len(text)
if part:chunks.append('\n'.join(part))
for i,text in enumerate(chunks,1):(OUT/('reading-'+str(i).zfill(2)+'.txt')).write_text(text,encoding='utf8',newline='\n')
(OUT/'INDEX.json').write_text(json.dumps(dict(paper={k:paper[k] for k in ['paper_id','pmcid','doi','xml_sha256']},anchors=entries,chunks=len(chunks),whole_paper_review_claim=False),indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps(dict(anchors=len(entries),chunks=len(chunks),characters=sum(e['characters'] for e in entries))))
