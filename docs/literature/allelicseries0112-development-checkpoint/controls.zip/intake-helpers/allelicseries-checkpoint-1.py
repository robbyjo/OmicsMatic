from pathlib import Path
import hashlib,json,subprocess,zipfile

ROOT=Path('D:/projects/JLinAlg');BASE=ROOT/'build/literature-review/monocle-runtime'
OUT=ROOT/'docs/literature/allelicseries0112-development-checkpoint'
GUIDE=ROOT/'docs/literature/ALLELICSERIES0112_DEVELOPMENT.md'
TOOLS=ROOT/'tools/literature/allelicseries0112'

def pin(p):
 h=hashlib.sha256();n=0
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b);n+=len(b)
 return dict(bytes=n,sha256=h.hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8',newline='\n')
def read(p):return json.loads(p.read_bytes())

assert not OUT.exists() and not GUIDE.exists()
native_roots=['allelicseries-native-controls-w21-3','allelicseries-native-controls-w25-2','allelicseries-native-controls-l21-2']
for name in native_roots:
 c=read(BASE/name/'COMPLETED.json');assert c['status']=='PASS_COMPLETE_ORIGINAL_ALLELICSERIES0112_NATIVE_BURDEN_VALUES' and c['original_case_population']==539
 assert 'values=2623 original_errors=12 scalar_zero_returns=4' in (BASE/name/'complete-native.stdout').read_text()
runner=read(BASE/'allelicseries-original-runner-controls-2/COMPLETED.json')
assert runner['status']=='PASS_ORIGINAL_ALLELICSERIES0112_FULL_EXPORT_RUNNER_AND_INDEPENDENT_OBJECTS' and runner['complete_original_object_comparisons']==16 and runner['refusal_or_skip_controls']==7
assert runner['original_warning_visibility_controls']==1
ready=read(BASE/'allelicseries-public-provider-run-2/provider/READY.json')
assert ready['status']=='READY_PRIVATE_ORIGINAL_ALLELICSERIES0112_NOT_ANALYSIS' and ready['source_functions_checked']==42
assert read(BASE/'allelicseries-public-provider-run-2/PROCESS.json')['exit_code']==0
for name,count in [('allelicseries-setup-controls-l21-1',4),('allelicseries-setup-controls-win-1',2)]:
 assert read(BASE/name/'COMPLETED.json')['controls']==count

# Protect every original unfinished file, the canonical executable and main catalog.
baseline=read(ROOT/'build/git-merge/20261113-analysis-main-6/BEFORE.json')
for row in baseline['preserved']+[baseline['canonical']]:
 assert pin(ROOT/row['path'])=={k:row[k] for k in ['bytes','sha256']},row['path']
metadata=read(ROOT/'docs/literature/software-frontier-audit/MAIN_CATALOG_BASELINE.json')
assert isinstance(metadata,dict)
for name,wanted in metadata['files'].items():assert pin(ROOT/name)==wanted,name
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT)

GUIDE.write_text('''# AllelicSeries 0.1.1.2 development checkpoint

**Warnings and required actions:** the paper reports `1.1.2`; the actual selected CRAN archive declares `0.1.1.2`. Exact paper-build equivalence remains unproven. Missing/forbidden installation or runtime is **SKIP3**, which skips dependent analysis. Original errors, nonfinite returns and integrity failures admit no analysis; retain the complete failed output, read its original conditions and raw logs, correct the named cause where permitted, and retry NEW paths. See the [copyable setup, original-method and Java API instructions](../../tools/literature/allelicseries0112/README.md).

The complete unchanged original package is now available through a private Linux/WSL R4.5.3 source-install provider and a public method adapter. The selected package archive contains83 original files, SHA-256 `20108a358d2c198dde13e5f32fcb847f15d964b40f1eaf106c5b821ac6917b22`. The provider installs eight fixed original dependency sources in its NEW library, verifies all42 installed R function bodies/formals against the pristine sources, and exposes all16 original function exports. Existing R installations/libraries are retained.

The adapter passed full returned-object identity comparisons for all16 exports against an independent original execution on retained synthetic fixtures. Seven actual runner refusal/skip controls, six setup refusal/skip controls and an original-warning visibility control passed. Original warnings appear in command output, result metadata and the prominent warning file, with the original cause and required action. Complete typed input RDS, all original returned objects and conditions, RNG states, logs, sources and manifests are retained. Nonfinite returns remain visible and admit no analysis; they are not converted into ordinary successful p-values.

Native Java supplies the baseline and weighted-sum summary-statistic burden methods and the checked ASBTSS wrapper, with source-bound genomic control and positive-definiteness helpers. All539 original burden cases passed on Windows Java21, Windows Java25 and Linux Java21, comparing2,623 returned numerical values per runtime,12 original errors and four low-level scalar-zero returns. These are complete comparisons within the stated population, not universal R-language equivalence. Original COAST/SKAT-O remain available through the unchanged upstream package.

Earlier attempts remain separately labeled. The first setup verifier compared a normalized R version against Matrix's literal DESCRIPTION `1.7-6`; it skipped before installation, and the check was corrected to read the literal field. The initial native implementation failed two Inf/NaN comparisons; a subsequent attempt failed one weighted-sum comparison. Original matrix multiplication order caused these differences. Complete failed source snapshots, inputs, outputs and logs remain retained. The first full-namespace fixture also omitted Counts' required `n_anno`; its original error is retained and replayed as a refusal control. No original package code, versions or scientific inputs were repaired.

The [validation record](allelicseries0112-development-checkpoint/VALIDATION.json) and [complete evidence member inventory](allelicseries0112-development-checkpoint/CONTROLS_LAYOUT.json) describe the retained [evidence archive](allelicseries0112-development-checkpoint/controls.zip). It contains complete original sources, reference objects, successful/failed controls and code snapshots. Installed private R libraries and the pre-existing R prefix are not redistributed; their inventories/metadata and the original source archives are retained. This is not a self-contained R runtime or an offline R refit. JDistlib0.10.2 is the existing project dependency used for native comparisons.

P204, [A scalable framework for identifying allelic series from summary statistics](https://doi.org/10.1016/j.ajhg.2025.09.012), reports full in-sample LD for UKB and borrowed UKB LD for meta-analysis/TOPMed. All26 named source anchors are individually bound in the component's paper-use intake. COAST-SS's quantitative derivation and unproven binary/discrete calibration remain explicit. The version lookup preserves the literal paper string, official archive index, requested `1.1.2` archive's HTTP404 response, Git tags/description history and actual `0.1.1.2` source. It does not infer that the builds are identical. No paper analysis or biological reproduction occurred.

Broader argument/model coverage, utility controls, packaged native workflows, offline replay and main-catalog admission remain open. This checkpoint adds no main-catalog implementation badge. The250-paper source cohort, catalog metadata, prior scientific verifiers, canonical executable and23 unrelated unfinished files are unchanged. The full paper/tool audit and implementation goal remains active.
''',encoding='utf8',newline='\n')
OUT.mkdir();(OUT/'.gitattributes').write_text('*.json -text\n*.zip -text\nSHA256SUMS -text\n',encoding='utf8',newline='\n')

source_files=[*sorted(p for p in TOOLS.rglob('*') if p.is_file() and '__pycache__' not in p.parts),ROOT/'src/main/java/org/jlinalg/genetics/AllelicSeries0112.java',GUIDE]
sources={p.relative_to(ROOT).as_posix():pin(p) for p in source_files}
members={}
def add(name,path):
 assert name not in members and path.is_file() and not path.is_symlink(),name
 members[name]=path
for p in source_files:add('current-source/'+p.relative_to(ROOT).as_posix(),p)
include=[
 'allelicseries-source-intake-1','allelicseries-preflight-1','allelicseries-dependency-intake-1',
 'allelicseries-original-install-1','allelicseries-original-reference-run-1','allelicseries-original-reference-run-2',
 'allelicseries-public-provider-run-1','allelicseries-public-provider-run-2',
 'allelicseries-native-controls-w21-1','allelicseries-native-controls-w21-2','allelicseries-native-controls-w25-1','allelicseries-native-controls-l21-1',
 *native_roots,'allelicseries-original-runner-controls-1','allelicseries-original-runner-controls-2','allelicseries-license-intake-1',
 'allelicseries-setup-controls-l21-1','allelicseries-setup-controls-win-1']
excluded=[]
for folder in include:
 root=BASE/folder;assert root.is_dir()
 for p in sorted(root.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(root)
  if any(part in {'.repository','__pycache__'} for part in rel.parts) or rel.parts[0] in {'library','tmp','cache'} or rel.parts[:2] in [('provider','library'),('provider','tmp'),('provider','archives')]:
   excluded.append(folder+'/'+rel.as_posix());continue
  add('evidence/'+folder+'/'+rel.as_posix(),p)
for p in sorted(BASE.glob('allelicseries-*.py')):add('intake-helpers/'+p.name,p)
layout={name:pin(path) for name,path in sorted(members.items())}
with zipfile.ZipFile(OUT/'controls.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,path in sorted(members.items()):
  raw=path.read_bytes();assert dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())==layout[name];z.writestr(name,raw)
with zipfile.ZipFile(OUT/'controls.zip') as z:
 assert set(z.namelist())==set(layout)
 for name,wanted in layout.items():
  raw=z.read(name);assert dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())==wanted,name
save(OUT/'CONTROLS_LAYOUT.json',dict(status='COMPLETE_RETAINED_DEVELOPMENT_EVIDENCE_INVENTORY',files=layout,excluded_private_runtime_or_duplicate_archive_paths=excluded,full_original_package_and_dependency_archives_retained=True,installed_R_libraries_redistributed=False,complete_paper_texts_redistributed=False))
save(OUT/'VALIDATION.json',dict(status='PASS_ALLELICSERIES0112_DEVELOPMENT_CHECKPOINT_NOT_CATALOG_ADMISSION',sources=sources,original_archive=dict(bytes=73667,sha256='20108a358d2c198dde13e5f32fcb847f15d964b40f1eaf106c5b821ac6917b22'),archive=pin(OUT/'controls.zip'),controls_layout=pin(OUT/'CONTROLS_LAYOUT.json'),original_source_files=83,source_functions_checked=42,original_function_exports=16,complete_independent_original_return_objects_compared=16,original_runner_refusals_or_skips=7,setup_refusals_or_skips=6,original_warning_visibility_controls=1,primary_named_source_anchors_reviewed=26,native_platforms=['Windows Java21','Windows Java25','Linux Java21'],native_original_cases_per_platform=539,native_values_per_platform=2623,original_errors_per_native_platform=12,source_scalar_zero_returns_per_native_platform=4,reported_paper_version='1.1.2',actual_package_version='0.1.1.2',paper_build_equivalence_proven=False,package_source_modified=False,paper_analysis_executed=False,canonical_unchanged=True,original_files_preserved=23,main_catalog_unchanged=True,new_tool_credit=0,whole_goal_complete=False,previous_goal_turn_classification='progress',broader_qualification_and_catalog_admission_pending=True))
names=['.gitattributes','controls.zip','CONTROLS_LAYOUT.json','VALIDATION.json']
(OUT/'SHA256SUMS').write_text(''.join(pin(OUT/name)['sha256']+'  '+name+'\n' for name in names),encoding='utf8',newline='\n')
assert all(pin(ROOT/name)==wanted for name,wanted in sources.items())
print(json.dumps(dict(status='CREATED_VALIDATED_DEVELOPMENT_CHECKPOINT',files=len(layout),archive=pin(OUT/'controls.zip'),new_tool_credit=0,whole_goal_complete=False)),flush=True)
