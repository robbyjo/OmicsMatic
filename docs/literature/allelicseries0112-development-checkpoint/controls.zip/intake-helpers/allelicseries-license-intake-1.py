from pathlib import Path
import hashlib,json,shutil,urllib.request
ROOT=Path('D:/projects/JLinAlg');BASE=ROOT/'build/literature-review/monocle-runtime';OUT=BASE/'allelicseries-license-intake-1';OUT.mkdir();DEST=ROOT/'tools/literature/allelicseries0112/licenses';DEST.mkdir()
url='https://svn.r-project.org/R/trunk/share/licenses/BSD_3_clause'
with urllib.request.urlopen(url,timeout=45) as response:raw=response.read()
assert b'Redistribution and use in source and binary forms' in raw and b'COPYRIGHT HOLDER' in raw
(OUT/'BSD_3_clause').write_bytes(raw);(DEST/'LICENSE-CRAN-BSD3-template.txt').write_bytes(raw)
shutil.copyfile(BASE/'allelicseries-source-intake-1/candidate-0112-source/AllelicSeries/LICENSE',DEST/'LICENSE-AllelicSeries-original.txt')
shutil.copyfile(ROOT/'tools/literature/wesanderson037/licenses/LICENSE-project-GPL3.txt',DEST/'LICENSE-project-GPL3.txt')
(OUT/'INTAKE.json').write_text(json.dumps(dict(url=url,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),original_short_notice_preserved=True),indent=2)+'\n',encoding='utf8',newline='\n')
print('Retained original copyright notice, official BSD3 template, and project GPL3')
