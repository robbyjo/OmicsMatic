from pathlib import Path
import hashlib,json
ROOT=Path('D:/projects/JLinAlg');BASE=ROOT/'build/literature-review/monocle-runtime';INTAKE=BASE/'allelicseries-paper-intake-1'
index=json.loads((INTAKE/'INDEX.json').read_bytes())
# Individually authored after reading all three complete private context batches.
manual={
3:('method-overview','Summary-statistic inputs; study overview.'),
10:('model-scope','Max/indicator components omitted.'),
11:('method-derivation','Score-statistic reconstruction.'),
29:('simulation-calibration','Real-genotype null permutations.'),
31:('runtime-benchmark','Original-versus-summary runtime benchmarking.'),
36:('software-analysis','UKB full-LD association.'),
37:('software-analysis','UKB/MVP approximate-LD association.'),
39:('software-analysis','TOPMed borrowed-LD replication.'),
40:('reported-validation','Individual-level comparison; null calibration.'),
41:('LD-robustness-experiment','Full/subsample/identity LD comparison.'),
42:('LD-robustness-experiment','LD misspecification stress tests.'),
43:('power-experiment','LD sensitivity/power comparisons.'),
44:('analysis-policy','Subsequent full-LD default.'),
45:('preprocessing-and-performance','Preprocessing separated from timing.'),
47:('annotation-weighting-experiment','Alternative annotation/weighting experiments.'),
48:('software-analysis','Meta-analysis discovery; LD fallback.'),
49:('lookup-and-replication','Association lookups; TOPMed replication.'),
50:('result-interpretation','Detected-category effect patterns.'),
51:('model-scope','Summary/individual-level model differences.'),
52:('scope-limitation','LD generalizability unproven.'),
54:('result-interpretation','Discovery/support interpretation.'),
55:('scope-limitation','LD/ancestry/frequency limitations.'),
56:('scope-limitation','Quantitative derivation; binary unqualified.'),
57:('software-availability','CRAN availability conclusion.'),
58:('software-availability','CRAN code availability.'),
64:('duplicate-availability-statement','Repeated code-availability statement.')}
assert set(manual)=={r['paragraph_index'] for r in index['anchors']}
rows=[]
for anchor in index['anchors']:
    category,summary=manual[anchor['paragraph_index']]
    rows.append(dict(paragraph_index=anchor['paragraph_index'],paragraph_sha256=anchor['paragraph_sha256'],classification=category,use_summary=summary,reading_scope='complete-named-primary-paragraph'))
ledger={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(INTAKE.glob('reading-*.txt'))}
out=ROOT/'tools/literature/allelicseries0112/paper-use-intake.json';assert not out.exists()
value=dict(status='DEVELOPMENT_COMPONENT_PRIMARY_ANCHOR_REVIEW_NOT_MAIN_CATALOG',paper=index['paper'],reviews=rows,complete_named_anchors_reviewed=26,private_reading_batches=ledger,reported_package_version_literal='1.1.2',actual_selected_archive_version='0.1.1.2',exact_build_equivalence_proven=False,whole_paper_semantic_review_complete=False,main_catalog_modified=False,new_tool_credit=0,source_roles=dict(UKB='full in-sample LD',UKB_MVP='borrowed UKB LD; independence otherwise',TOPMed='borrowed UKB LD',phenotype_scope='quantitative lipid traits; binary/discrete calibration remains unproven',preprocessing='SAIGE supplies effects/SEs; NumPy supplies MAF/LD; Hail/Python/VEP preprocessing is separate',runtime_benchmark_R_version_literal='4.1.0'),whole_goal_complete=False)
out.write_text(json.dumps(value,indent=2)+'\n',encoding='utf8',newline='\n')
print('Bound26 individually reviewed named anchors to exact P204 primary source; no catalog mutation')
