from pathlib import Path
import json,os,shutil,subprocess,time
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[2];OUT=BASE/'allelicseries-public-provider-run-1';OUT.mkdir()
CACHE=OUT/'cache';CACHE.mkdir()
for row in json.loads((ROOT/'tools/literature/allelicseries0112/source-profile.json').read_bytes())['private_dependency_sources']:
    shutil.copyfile(BASE/'allelicseries-dependency-intake-1'/row['archive'],CACHE/row['archive'])
shutil.copyfile(BASE/'allelicseries-source-intake-1/candidate-0112.tar.gz',CACHE/'AllelicSeries_0.1.1.2.tar.gz')
prefix=BASE/'fastmnn129-public-fresh-setup-2/dependency-base/.pixi/envs/default'
cmd=['python3',str(ROOT/'tools/literature/allelicseries0112/provider.py'),'--r-prefix',str(prefix),'--source-cache',str(CACHE),'--allow-install','--out',str(OUT/'provider')]
start=time.time()
with (OUT/'stdout').open('xb') as so,(OUT/'stderr').open('xb') as se:
    p=subprocess.Popen(cmd,stdout=so,stderr=se,stdin=subprocess.DEVNULL);(OUT/'LIVE.json').write_text(json.dumps(dict(command=cmd,pid=p.pid,started_unix=start),indent=2)+'\n');code=p.wait()
(OUT/'PROCESS.json').write_text(json.dumps(dict(command=cmd,exit_code=code,elapsed_seconds=time.time()-start),indent=2)+'\n')
print('Public source provider actual exit',code,flush=True);raise SystemExit(code)
