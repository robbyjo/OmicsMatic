from pathlib import Path
import hashlib,json,re
ROOT=Path('D:/projects/JLinAlg');BASE=ROOT/'build/literature-review/monocle-runtime';OUT=ROOT/'tools/literature/allelicseries0112';OUT.mkdir(exist_ok=True)
source=BASE/'allelicseries-source-intake-1/candidate-0112-source'
members={p.relative_to(source).as_posix():dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(source.rglob('*')) if p.is_file()}
deps=json.loads((BASE/'allelicseries-dependency-intake-1/DEPENDENCIES.json').read_bytes())['packages']
deps=[{k:v for k,v in d.items() if k!='source_files'} for d in deps]
exports=re.findall(r'^export\((\w+)\)$',(source/'AllelicSeries/NAMESPACE').read_text(),re.M)
profile=dict(status='DEVELOPMENT_ORIGINAL_SOURCE_PROFILE_NOT_CATALOG_ADMISSION',package='AllelicSeries',version='0.1.1.2',url='https://cran.r-project.org/src/contrib/Archive/AllelicSeries/AllelicSeries_0.1.1.2.tar.gz',archive=dict(bytes=73667,sha256='20108a358d2c198dde13e5f32fcb847f15d964b40f1eaf106c5b821ac6917b22'),source_files=members,function_exports=exports,S4_exports=['COAST','DfOrNULL'],reference_R_version='4.5.3',base_package_versions=dict(glue='1.8.1',Rcpp='1.1.2',Matrix='1.7-6'),private_dependency_sources=deps,paper=dict(paper_id='P204',pmcid='PMC12808971',doi='10.1016/j.ajhg.2025.09.012',reported_version_literal='1.1.2',selected_archive_version='0.1.1.2',exact_build_equivalence_proven=False,role='COAST-SS with full in-sample LD matrices',required_action='Keep the literal paper version. The official archive has 0.1.1.2; no 1.1.2 archive or Git tag was found in the retained intake. Qualify the actual selected archive explicitly, without silently equating the builds or claiming paper reproduction.'),new_tool_credit=0,whole_goal_complete=False)
(OUT/'source-profile.json').write_text(json.dumps(profile,indent=2)+'\n',encoding='utf8',newline='\n')
print('Created original-source profile:',len(members),'target files,',len(exports),'function exports,',len(deps),'fixed dependency sources')
