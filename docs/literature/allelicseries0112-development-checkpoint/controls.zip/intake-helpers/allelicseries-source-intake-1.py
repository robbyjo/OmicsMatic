from pathlib import Path
import datetime,hashlib,json,re,subprocess,tarfile,urllib.error,urllib.request
ROOT=Path('D:/projects/JLinAlg');OUT=ROOT/'build/literature-review/monocle-runtime/allelicseries-source-intake-1';OUT.mkdir(exist_ok=False);REPO=OUT/'.repository';calls=[]
def save(n,v):(OUT/n).write_text(json.dumps(v,indent=2)+'\n',encoding='utf8',newline='\n')
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def run(label,args):
 args=list(map(str,args));r=subprocess.run(args,cwd=ROOT,stdin=subprocess.DEVNULL,capture_output=True,timeout=300);(OUT/(label+'.stdout')).write_bytes(r.stdout);(OUT/(label+'.stderr')).write_bytes(r.stderr);row=dict(label=label,command=args,exit_code=r.returncode);calls.append(row)
 if r.returncode:raise RuntimeError('Source intake failed at '+label)
 return r.stdout
run('clone',['git','clone','--bare','https://github.com/insitro/AllelicSeries.git',REPO]);base=['git','--git-dir',REPO];head=run('head',[*base,'rev-parse','HEAD']).decode().strip();tags=run('tags',[*base,'show-ref','--tags']).decode().splitlines();commits=run('commits',[*base,'rev-list','--all']).decode().splitlines();history=[]
for i,sha in enumerate(commits):
 r=subprocess.run([*map(str,base),'show',sha+':DESCRIPTION'],cwd=ROOT,capture_output=True,timeout=30)
 if r.returncode:continue
 raw=r.stdout;version=re.search(rb'^Version:\s*([^\r\n]+)',raw,re.M)
 if not version:continue
 description=OUT/'descriptions'/(sha+'.DESCRIPTION');description.parent.mkdir(exist_ok=True);description.write_bytes(raw);history.append(dict(commit=sha,version=version.group(1).decode().strip(),description=pin(description)))
fetched=[]
for label,url in [('archive-index','https://cran.r-project.org/src/contrib/Archive/AllelicSeries/'),('reported-112','https://cran.r-project.org/src/contrib/Archive/AllelicSeries/AllelicSeries_1.1.2.tar.gz'),('candidate-0112','https://cran.r-project.org/src/contrib/Archive/AllelicSeries/AllelicSeries_0.1.1.2.tar.gz'),('current-description','https://raw.githubusercontent.com/insitro/AllelicSeries/master/DESCRIPTION')]:
 target=OUT/(label+('.tar.gz' if label in ['reported-112','candidate-0112'] else '.txt'))
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'OmicsMatic-original-source-audit/1'})
  with urllib.request.urlopen(req,timeout=60) as response:status=response.status;raw=response.read()
 except urllib.error.HTTPError as e:status=e.code;raw=e.read()
 except OSError as e:fetched.append(dict(label=label,url=url,status='unavailable',cause=repr(e)));continue
 target.write_bytes(raw);record=dict(label=label,url=url,http_status=status,path=target.name,**pin(target));fetched.append(record)
 if status==200 and label in ['reported-112','candidate-0112']:
  source=OUT/(label+'-source');source.mkdir();members={}
  with tarfile.open(target) as tar:
   for m in tar:
    if m.isdir():continue
    if not m.isfile() or m.issym() or m.islnk() or m.name.startswith('/') or '\\' in m.name or any(s in ['','.','..'] for s in m.name.split('/')):raise ValueError('Unsafe original archive member')
    p=source/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(tar.extractfile(m).read());members[m.name]=pin(p)
  record['source_members']=members
save('SOURCE_INTAKE.json',dict(status='READ_ONLY_UPSTREAM_SOURCE_AND_VERSION_IDENTITY_INTAKE',repository='https://github.com/insitro/AllelicSeries.git',head=head,tags=tags,history=history,fetches=fetched,calls=calls,reported_paper_version='1.1.2',source_version_mapping_assumed=False,source_modified=False,package_installed=False,analysis_executed=False,checked_at=datetime.datetime.now(datetime.timezone.utc).isoformat()))
print(json.dumps(dict(head=head,tags=tags,git_description_versions=sorted({r['version'] for r in history}),fetches=[{k:v for k,v in r.items() if k!='source_members'} for r in fetched],package_installed=False,analysis_executed=False),indent=2),flush=True)
