FAIL2_ORIGINAL_ALLELICSERIES_NO_ANALYSIS_ADMISSION
ValueError('Original function error or nonfinite return; inspect the retained complete result and original conditions')
ORIGINAL_NONFINITE_RETURN_NO_ANALYSIS_ADMISSION
numeric
0
0

Required action: use a successful unmodified private provider, a complete named argument-list RDS and explicit --allow-analysis. Supply an explicit --seed for reproducible stochastic calls. Missing/forbidden runtime or execution SKIP3 skips dependent analysis. Original errors and nonfinite returns are retained and admit no analysis; inspect original-error.txt, original-warnings.txt, complete-original-return.rds and raw process logs, correct the named cause and retry NEW paths. Preserve failed outputs. No substitution, automatic variant/allele alignment, category repair, LD repair beyond the actual source behavior, or silent component imputation is performed. The actual archive is0.1.1.2; paper1.1.2 equivalence and biological reproduction remain unproven.
