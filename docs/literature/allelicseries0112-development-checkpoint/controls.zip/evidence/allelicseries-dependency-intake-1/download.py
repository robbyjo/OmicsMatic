from pathlib import Path
import gzip,hashlib,json,tarfile,urllib.request

OUT=Path(__file__).resolve().parent;BASE=OUT.parent
blocks=gzip.decompress((BASE/'allelicseries-preflight-1/PACKAGES.gz').read_bytes()).decode('utf8').split('\n\n')
names=['RcppArmadillo','RcppEigen','RSpectra','SPAtest','plyr','RNOmni','CompQuadForm','SKAT']
by={}
for block in blocks:
    lines=[]
    for line in block.splitlines():
        if line.startswith((' ','\t')):lines[-1]+=' '+line.strip()
        else:lines.append(line)
    d=dict(line.split(': ',1) for line in lines if ': ' in line)
    if d.get('Package') in names and 'Path' not in d:by[d['Package']]=d
assert set(by)==set(names)
records=[]
for name in names:
    d=by[name];filename=name+'_'+d['Version']+'.tar.gz';url='https://cran.r-project.org/src/contrib/'+filename
    with urllib.request.urlopen(url,timeout=90) as response:raw=response.read(32000001)
    assert len(raw)<=32000000 and hashlib.md5(raw).hexdigest()==d['MD5sum'],filename
    path=OUT/filename;path.write_bytes(raw)
    with tarfile.open(path) as tar:
        source={}
        for member in tar.getmembers():
            if member.isdir():continue
            assert member.isfile() and not member.name.startswith('/') and '\\' not in member.name and not any(p in ['', '.', '..'] for p in member.name.split('/'))
            assert member.name not in source
            b=tar.extractfile(member).read();source[member.name]=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
        desc=tar.extractfile(name+'/DESCRIPTION').read();(OUT/(name+'.DESCRIPTION')).write_bytes(desc)
        print(filename,'source-files',len(source),'compile-files',[n for n in source if n.startswith(name+'/src/') and n.endswith(('.cpp','.c','.f','.f90','.F'))],flush=True)
    records.append(dict(name=name,version=d['Version'],url=url,archive=filename,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),repository_metadata=d,source_files=source))
(OUT/'DEPENDENCIES.json').write_text(json.dumps(dict(status='EXACT_ORIGINAL_REFERENCE_DEPENDENCY_SOURCE_INTAKE',packages=records,selection_note='Current official CRAN metadata snapshot used for a new R4.5.3 reference runtime, not recovered paper dependencies.'),indent=2)+'\n',encoding='utf8',newline='\n')
print('Downloaded and pinned all8 original dependency archives',flush=True)
