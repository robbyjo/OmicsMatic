args <- commandArgs(trailingOnly=TRUE)
dir.create(args[1], recursive=TRUE, showWarnings=FALSE)
wanted <- c('CompQuadForm','glue','methods','Rcpp','RNOmni','SKAT','RcppArmadillo','Matrix','RSpectra','RcppEigen','SPAtest')
ip <- installed.packages()
rows <- ip[ip[,'Package'] %in% wanted,c('Package','Version','LibPath','License'),drop=FALSE]
write.table(rows,file=file.path(args[1],'installed.tsv'),quote=FALSE,sep='\t',row.names=FALSE)
writeLines(c(R.version.string,.libPaths(),paste('RHOME',R.home()),paste('CXX',system2(file.path(R.home('bin'),'R'),c('CMD','config','CXX'),stdout=TRUE))),file.path(args[1],'runtime.txt'))
cat(readLines(file.path(args[1],'installed.tsv')),sep='\n')
