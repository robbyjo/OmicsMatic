from pathlib import Path
import gzip,json,os,shutil,subprocess,urllib.request,hashlib

OUT=Path(__file__).resolve().parent
PREFIX=OUT.parent/'fastmnn129-public-fresh-setup-2/dependency-base/.pixi/envs/default'
env=dict(os.environ);env.update(PATH=str(PREFIX/'bin')+':/usr/bin:/bin',R_HOME=str(PREFIX/'lib/R'),LD_LIBRARY_PATH=str(PREFIX/'lib'),R_PROFILE_USER='/dev/null',R_ENVIRON_USER='/dev/null',LC_ALL='C.UTF-8',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
cmd=[str(PREFIX/'bin/Rscript'),'--vanilla',str(OUT/'inspect.R'),str(OUT)]
r=subprocess.run(cmd,env=env,capture_output=True,timeout=60);(OUT/'R.stdout').write_bytes(r.stdout);(OUT/'R.stderr').write_bytes(r.stderr)
print(r.stdout.decode(),flush=True);print(r.stderr.decode(),flush=True)
result=dict(R_exit=r.returncode,command=cmd,tools={s:shutil.which(s,path=env['PATH']) for s in ['gcc','g++','gfortran','make','x86_64-conda-linux-gnu-c++']})
url='https://cran.r-project.org/src/contrib/PACKAGES.gz'
with urllib.request.urlopen(url,timeout=60) as response:raw=response.read()
(OUT/'PACKAGES.gz').write_bytes(raw)
names={'CompQuadForm','glue','Rcpp','RNOmni','SKAT','RcppArmadillo','Matrix','RSpectra','RcppEigen','SPAtest'}
rows=[]
for block in gzip.decompress(raw).decode('utf8').split('\n\n'):
    lines=[]
    for line in block.splitlines():
        if line.startswith((' ','\t')):lines[-1]+=' '+line.strip()
        else:lines.append(line)
    d=dict(line.split(': ',1) for line in lines if ': ' in line)
    if d.get('Package') in names:rows.append(d)
result.update(metadata_url=url,metadata_bytes=len(raw),metadata_sha256=hashlib.sha256(raw).hexdigest(),packages=rows)
(OUT/'PREFLIGHT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps(result,indent=2),flush=True)
