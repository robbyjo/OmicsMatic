from pathlib import Path
import hashlib,json,os,subprocess,time,traceback

OUT=Path(__file__).resolve().parent;BASE=OUT.parent
PREFIX=BASE/'fastmnn129-public-fresh-setup-2/dependency-base/.pixi/envs/default'
SOURCE=BASE/'allelicseries-source-intake-1/candidate-0112.tar.gz'
DEPS=BASE/'allelicseries-dependency-intake-1'

def pin(p):
    raw=p.read_bytes();return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(n,v):(OUT/n).write_text(json.dumps(v,indent=2)+'\n',encoding='utf8',newline='\n')
calls=[]
try:
    assert not (OUT/'BEFORE.json').exists()
    before={str(p):pin(p) for p in [PREFIX/'bin/Rscript',PREFIX.parents[2]/'pixi.lock',PREFIX.parents[2]/'pixi.toml',*sorted((PREFIX/'lib/R/library').glob('*/DESCRIPTION'))]}
    save('BEFORE.json',before)
    library=OUT/'library';library.mkdir();(OUT/'tmp').mkdir()
    env={k:v for k,v in os.environ.items() if k not in ['R_LIBS','R_LIBS_USER','R_LIBS_SITE','R_DEFAULT_PACKAGES','R_PROFILE_USER','R_ENVIRON_USER']}
    env.update(PATH=str(PREFIX/'bin')+':/usr/bin:/bin',R_HOME=str(PREFIX/'lib/R'),LD_LIBRARY_PATH=str(PREFIX/'lib'),R_PROFILE_USER='/dev/null',R_ENVIRON_USER='/dev/null',R_LIBS=str(library)+':'+str(PREFIX/'lib/R/library'),R_LIBS_USER=str(library),R_LIBS_SITE='',LC_ALL='C.UTF-8',TMPDIR=str(OUT/'tmp'),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',MAKEFLAGS='-j2')
    records=json.loads((DEPS/'DEPENDENCIES.json').read_bytes())['packages']
    for row in records+[dict(name='AllelicSeries',version='0.1.1.2',archive=str(SOURCE),bytes=73667,sha256='20108a358d2c198dde13e5f32fcb847f15d964b40f1eaf106c5b821ac6917b22')]:
        archive=Path(row['archive'])
        if not archive.is_absolute():archive=DEPS/archive
        assert pin(archive)=={k:row[k] for k in ['bytes','sha256']}
        command=[str(PREFIX/'bin/R'),'CMD','INSTALL','--no-multiarch','--library='+str(library),str(archive)]
        label=row['name'];start=time.time()
        with (OUT/(label+'.stdout')).open('xb') as so,(OUT/(label+'.stderr')).open('xb') as se:
            p=subprocess.Popen(command,env=env,cwd=OUT,stdin=subprocess.DEVNULL,stdout=so,stderr=se);save('LIVE.json',dict(label=label,pid=p.pid,command=command,started_unix=start));print('Installing',label,row['version'],flush=True);code=p.wait(timeout=1800)
        result=dict(label=label,version=row['version'],exit_code=code,elapsed_seconds=time.time()-start,command=command);calls.append(result);save(label+'.process.json',result)
        if code:raise OSError('Private source installation unavailable at '+label+'; inspect raw logs, correct permitted toolchain prerequisites and retry NEW output paths. No dependent analysis admitted.')
    assert all(pin(Path(name))==wanted for name,wanted in before.items()),'Pre-existing runtime metadata changed'
    save('COMPLETED.json',dict(status='PRIVATE_ORIGINAL_ALLELICSERIES0112_INSTALLED_NOT_YET_QUALIFIED',rscript=str(PREFIX/'bin/Rscript'),library=str(library),calls=calls,base_metadata_unchanged=True,reported_paper_version='1.1.2',actual_selected_package_version='0.1.1.2',paper_version_equivalence_proven=False,paper_analysis_executed=False))
    print('Installed complete unchanged candidate package and8 dependencies; runtime/API validation pending',flush=True)
except Exception as e:
    save('FAILURE.json',dict(status='SKIP3_PRIVATE_ORIGINAL_INSTALL_UNAVAILABLE' if isinstance(e,OSError) else 'FAIL2_ORIGINAL_INSTALL',cause=repr(e),traceback=traceback.format_exc(),calls=calls,analysis_admitted=False));print(repr(e),flush=True);raise SystemExit(3 if isinstance(e,OSError) else 2)
