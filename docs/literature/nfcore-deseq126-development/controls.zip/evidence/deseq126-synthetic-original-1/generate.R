args <- commandArgs(trailingOnly=TRUE)
root <- args[1];set.seed(36)
for (name in c("three_groups","outlier_replacement")) {
 groups <- if (name=="three_groups") rep(c("A","B","C"),each=2) else rep(c("A","B"),each=8)
 samples <- unlist(lapply(unique(groups),function(g)paste0(g,"_R",seq_len(sum(groups==g)))))
 n <- 300L;counts <- matrix(rnbinom(n*length(samples),mu=50,size=10),nrow=n)
 counts[1,] <- 0L
 if (name=="three_groups") { counts[2,groups %in% c("A","B")] <- 0L; counts[2,groups=="C"] <- 60L;counts[3:35,groups=="A"] <- counts[3:35,groups=="A"]*4L }
 else counts[2,3] <- 100000000L
 directory <- file.path(root,name);dir.create(directory);dir.create(file.path(directory,"peaks"));dir.create(file.path(directory,"published"))
 writeLines(samples,file.path(directory,"libraries.txt"))
 writeLines(c("published_directory=deseq2","model_prefix=CONTROL.consensus_peaks","genes=300","bam_suffix=.mLb.clN.bam"),file.path(directory,"case.properties"))
 order <- rev(seq_along(samples))
 annotation <- data.frame(Geneid=paste0("Interval_",seq_len(n)),Chr="chr1",Start=seq_len(n)*100L,End=seq_len(n)*100L+50L,Strand="+",Length=51L)
 colnames(counts) <- paste0(samples,".mLb.clN.bam")
 path <- file.path(directory,"featureCounts.txt");writeLines("# Program:featureCounts v2.0.1; Command: explicitly simulated complete differential count control",path)
 write.table(cbind(annotation,counts[,order,drop=FALSE]),file=path,append=TRUE,sep="\t",quote=FALSE,row.names=FALSE,col.names=TRUE)
 for (sample in samples) write.table(data.frame(Chr="chr1",Start=annotation$Start,End=annotation$End,Name=paste0(sample,"_peak_",seq_len(n)),Score=100L,Strand=".",Fold=2,P=3,Q=4),file=file.path(directory,"peaks",paste0(sample,"_peaks.broadPeak")),sep="\t",quote=FALSE,row.names=FALSE,col.names=FALSE)
}
