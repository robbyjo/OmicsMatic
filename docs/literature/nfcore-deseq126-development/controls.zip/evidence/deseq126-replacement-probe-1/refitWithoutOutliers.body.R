{
    cooks <- assays(object)[["cooks"]]
    object <- replaceOutliers(object, minReplicates = minReplicatesForReplace)
    nrefit <- sum(mcols(object)$replace, na.rm = TRUE)
    if (nrefit > 0) {
        object <- getBaseMeansAndVariances(object)
        newAllZero <- which(mcols(object)$replace & mcols(object)$allZero)
    }
    if (nrefit > 0 && nrefit > length(newAllZero)) {
        if (!quiet) 
            message(paste("-- replacing outliers and refitting for", nrefit, "genes\n-- DESeq argument 'minReplicatesForReplace' =", minReplicatesForReplace, "\n-- original counts are preserved in counts(dds)"))
        refitReplace <- which(mcols(object)$replace & !mcols(object)$allZero)
        objectSub <- object[refitReplace, ]
        intermediateOrResults <- which(mcols(mcols(objectSub))$type %in% c("intermediate", "results"))
        mcols(objectSub) <- mcols(objectSub)[, -intermediateOrResults, drop = FALSE]
        if (!quiet) 
            message("estimating dispersions")
        objectSub <- estimateDispersionsGeneEst(objectSub, quiet = quiet, modelMatrix = modelMatrix)
        mcols(objectSub)$dispFit <- dispersionFunction(objectSub)(mcols(objectSub)$baseMean)
        mcols(mcols(objectSub), use.names = TRUE)["dispFit", ] <- DataFrame(type = "intermediate", description = "fitted values of dispersion")
        dispPriorVar <- attr(dispersionFunction(object), "dispPriorVar")
        objectSub <- estimateDispersionsMAP(objectSub, quiet = quiet, dispPriorVar = dispPriorVar, modelMatrix = modelMatrix)
        if (!quiet) 
            message("fitting model and testing")
        if (test == "Wald") {
            betaPriorVar <- attr(object, "betaPriorVar")
            objectSub <- nbinomWaldTest(objectSub, betaPrior = betaPrior, betaPriorVar = betaPriorVar, quiet = quiet, modelMatrix = modelMatrix, modelMatrixType = modelMatrixType)
        }
        else if (test == "LRT") {
            objectSub <- nbinomLRT(objectSub, full = full, reduced = reduced, quiet = quiet)
        }
        idx <- match(names(mcols(objectSub)), names(mcols(object)))
        mcols(object)[refitReplace, idx] <- mcols(objectSub)
        mcols(object)[newAllZero, mcols(mcols(object))$type == "results"] <- NA
        if (all(object$replaceable)) {
            mcols(object)$maxCooks <- NA
        }
        else {
            replaceCooks <- assays(object)[["cooks"]]
            replaceCooks[, object$replaceable] <- 0
            mcols(object)$maxCooks <- recordMaxCooks(design(object), colData(object), attr(object, "dispModelMatrix"), replaceCooks, nrow(object))
        }
    }
    if (nrefit > 0) {
        assays(object)[["replaceCounts"]] <- counts(object)
        assays(object)[["replaceCooks"]] <- assays(object)[["cooks"]]
        counts(object) <- assays(object)[["originalCounts"]]
        assays(object)[["cooks"]] <- cooks
        assays(object)[["originalCounts"]] <- NULL
    }
    object
}
