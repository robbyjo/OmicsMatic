library(DESeq2)
load(commandArgs(trailingOnly=TRUE)[1])
print(mcols(dds)[1:4,c("allZero","replace","baseMean","betaConv")])
for(n in c("DESeq","replaceOutliers","refitWithoutOutliers")) {
fn<-get(n,asNamespace("DESeq2"));writeLines(deparse(body(fn),width.cutoff=500),file.path(commandArgs(trailingOnly=TRUE)[2],paste0(n,".body.R")))
}
