{
    if (is.null(attr(object, "modelMatrix")) | !("cooks" %in% assayNames(object))) {
        stop("first run DESeq, nbinomWaldTest, or nbinomLRT to identify outliers")
    }
    if (minReplicates < 3) {
        stop("at least 3 replicates are necessary in order to indentify a sample as a count outlier")
    }
    stopifnot(is.numeric(minReplicates) & length(minReplicates) == 1)
    p <- ncol(attr(object, "modelMatrix"))
    m <- ncol(object)
    if (m <= p) {
        assays(object)[["originalCounts"]] <- counts(object)
        return(object)
    }
    if (missing(cooksCutoff)) {
        cooksCutoff <- qf(0.99, p, m - p)
    }
    idx <- which(assays(object)[["cooks"]] > cooksCutoff)
    mcols(object)$replace <- apply(assays(object)[["cooks"]], 1, function(row) any(row > cooksCutoff))
    mcols(mcols(object), use.names = TRUE)["replace", ] <- DataFrame(type = "intermediate", description = "had counts replaced")
    trimBaseMean <- apply(counts(object, normalized = TRUE), 1, mean, trim = trim)
    replacementCounts <- if (!is.null(normalizationFactors(object))) {
        as.integer(matrix(rep(trimBaseMean, ncol(object)), ncol = ncol(object)) * normalizationFactors(object))
    }
    else {
        as.integer(outer(trimBaseMean, sizeFactors(object), "*"))
    }
    newCounts <- counts(object)
    newCounts[idx] <- replacementCounts[idx]
    if (missing(whichSamples)) {
        whichSamples <- nOrMoreInCell(attr(object, "modelMatrix"), n = minReplicates)
    }
    stopifnot(is.logical(whichSamples))
    object$replaceable <- whichSamples
    mcols(colData(object), use.names = TRUE)["replaceable", ] <- DataFrame(type = "intermediate", description = "outliers can be replaced")
    assays(object)[["originalCounts"]] <- counts(object)
    if (sum(whichSamples) == 0) {
        return(object)
    }
    counts(object)[, whichSamples] <- newCounts[, whichSamples, drop = FALSE]
    object
}
