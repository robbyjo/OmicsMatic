# SKIP3 ANALYSIS SKIPPED

org.jlinalg.cli.NextflowProcess$Unavailable: Pinned Apptainer home or original image is missing. Install/download the permitted exact prerequisites separately and retry a NEW audit directory. Analysis skipped.

Required action: inspect WARNINGS.md, audit.json, every process/process.stderr and the original warning/session files. This is a DESeq2 postfit component audit: no negative-binomial refit, independent rlog/vst recomputation, whole-pipeline, biological or paper admission; zero nf-core tool credit. Preserve originals and failed attempts. SKIP3 means a missing/forbidden prerequisite: install the exact permitted runtime/image separately, or use an allowed Linux environment, then retry a NEW output path. FAIL2 means no component result: inspect the named integrity, input, process, capacity or numeric discrepancy; correct its cause and retry a NEW path. Hashes establish integrity, not execution authenticity.
