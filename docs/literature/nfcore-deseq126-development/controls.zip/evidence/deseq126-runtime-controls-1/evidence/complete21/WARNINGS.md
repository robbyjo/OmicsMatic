# Postfit component only: no scientific result admitted

WARNING: Original ChIP-seq1.2.1 copies BED zero-based Start unchanged into SAF; featureCounts treats SAF positions inclusively. This audit preserves that convention and Length=End-Start+1. Any coordinate conversion requires a separate declared analysis with originals retained.

SPT5: ORIGINAL_DISPERSION_FIT: local; retained from the fitted object, without refitting or substituting a parametric curve.

SPT5: original runtime reports warnings in antibody-000001/process/process.stderr; review the retained complete stderr and sessionInfo.txt.
Loading required package: S4Vectors
Loading required package: stats4
Loading required package: BiocGenerics
Loading required package: parallel

Attaching package: ‘BiocGenerics’

The following objects are masked from ‘package:parallel’:

    clusterApply, clusterApplyLB, clusterCall, clusterEvalQ,
    clusterExport, clusterMap, parApply, parCapply, parLapply,
    parLapplyLB, parRapply, parSapply, parSapplyLB

The following objects are masked from ‘package:stats’:

    IQR, mad, sd, var, xtabs

The following objects are masked from ‘package:base’:

    anyDuplicated, append, as.data.frame, basename, cbind, colnames,
    dirname, do.call, duplicated, eval, evalq, Filter, Find, get, grep,
    grepl, intersect, is.unsorted, lapply, Map, mapply, match, mget,
    order, paste, pmax, pmax.int, pmin, pmin.int, Position, rank,
    rbind, Reduce, rownames, sapply, setdiff, sort, table, tapply,
    union, unique, unsplit, which, which.max, which.min


Attaching package: ‘S4Vectors’

The following object is masked from ‘package:base’:

    expand.grid

Loading required package: IRanges
Loading required package: GenomicRanges
Loading required package: GenomeInfoDb
Loading required package: SummarizedExperiment
Loading required package: Biobase
Welcome to Bioconductor

    Vignettes contain introductory material; view with
    'browseVignettes()'. To cite Bioconductor, see
    'citation("Biobase")', and for packages 'citation("pkgname")'.

Loading required package: DelayedArray
Loading required package: matrixStats

Attaching package: ‘matrixStats’

The following objects are masked from ‘package:Biobase’:

    anyMissing, rowMedians

Loading required package: BiocParallel

Attaching package: ‘DelayedArray’

The following objects are masked from ‘package:matrixStats’:

    colMaxs, colMins, colRanges, rowMaxs, rowMins, rowRanges

The following objects are masked from ‘package:base’:

    aperm, apply, rowsum

Warning message:
package ‘matrixStats’ was built under R version 3.6.3 


Required action: inspect WARNINGS.md, audit.json, every process/process.stderr and the original warning/session files. This is a DESeq2 postfit component audit: no negative-binomial refit, independent rlog/vst recomputation, whole-pipeline, biological or paper admission; zero nf-core tool credit. Preserve originals and failed attempts. SKIP3 means a missing/forbidden prerequisite: install the exact permitted runtime/image separately, or use an allowed Linux environment, then retry a NEW output path. FAIL2 means no component result: inspect the named integrity, input, process, capacity or numeric discrepancy; correct its cause and retry a NEW path. Hashes establish integrity, not execution authenticity.
