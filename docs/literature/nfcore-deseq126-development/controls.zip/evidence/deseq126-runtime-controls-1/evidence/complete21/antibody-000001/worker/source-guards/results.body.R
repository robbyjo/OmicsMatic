{
    stopifnot(is(object, "DESeqDataSet"))
    format <- match.arg(format, choices = c("DataFrame", "GRanges", "GRangesList"))
    altHypothesis <- match.arg(altHypothesis, choices = c("greaterAbs", "lessAbs", "greater", "less"))
    if (!missing(test)) {
        test <- match.arg(test, choices = c("Wald", "LRT"))
    }
    stopifnot(lfcThreshold >= 0)
    stopifnot(length(lfcThreshold) == 1)
    stopifnot(length(alpha) == 1)
    stopifnot(alpha > 0 & alpha < 1)
    stopifnot(length(pAdjustMethod) == 1)
    stopifnot(length(listValues) == 2 & is.numeric(listValues))
    stopifnot(listValues[1] > 0 & listValues[2] < 0)
    if (!"results" %in% mcols(mcols(object))$type) {
        stop("couldn't find results. you should first run DESeq()")
    }
    if (missing(test)) {
        test <- attr(object, "test")
    }
    else if (test == "Wald" & attr(object, "test") == "LRT") {
        object <- makeWaldTest(object)
    }
    else if (test == "LRT" & attr(object, "test") == "Wald") {
        stop("the LRT requires the user run nbinomLRT or DESeq(dds,test='LRT')")
    }
    if (lfcThreshold == 0 & altHypothesis == "lessAbs") {
        stop("when testing altHypothesis='lessAbs', set the argument lfcThreshold to a positive value")
    }
    if (addMLE) {
        if (!attr(object, "betaPrior")) {
            stop("addMLE=TRUE is only for when a beta prior was used.\notherwise, the log2 fold changes are already MLE")
        }
        if (!missing(name) & missing(contrast)) {
            stop("addMLE=TRUE should be used by providing character vector\nof length 3 to 'contrast' instead of using 'name'")
        }
    }
    if (format == "GRanges" & is(rowRanges(object), "GRangesList")) {
        if (any(elementNROWS(rowRanges(object)) == 0)) {
            stop("rowRanges is GRangesList and one or more GRanges have length 0. Use format='DataFrame' or 'GRangesList'")
        }
    }
    if (!missing(contrast)) {
        if (attr(object, "modelMatrixType") == "user-supplied" & is.character(contrast)) {
            stop("only list- and numeric-type contrasts are supported for user-supplied model matrices")
        }
    }
    if (is(design(object), "formula")) {
        hasIntercept <- attr(terms(design(object)), "intercept") == 1
        isExpanded <- attr(object, "modelMatrixType") == "expanded"
        termsOrder <- attr(terms.formula(design(object)), "order")
        if ((test == "Wald") & (isExpanded | !hasIntercept) & missing(contrast) & missing(name) & all(termsOrder < 2)) {
            designVars <- all.vars(design(object))
            lastVarName <- designVars[length(designVars)]
            lastVar <- colData(object)[[lastVarName]]
            if (is.factor(lastVar)) {
                nlvls <- nlevels(lastVar)
                contrast <- c(lastVarName, levels(lastVar)[nlvls], levels(lastVar)[1])
            }
        }
    }
    if (missing(name)) {
        name <- lastCoefName(object)
    }
    else {
        if (length(name) != 1 | !is.character(name)) {
            stop("the argument 'name' should be a character vector of length 1")
        }
    }
    WaldResults <- paste0("WaldPvalue_", name) %in% names(mcols(object))
    LRTResults <- "LRTPvalue" %in% names(mcols(object))
    useT <- "tDegreesFreedom" %in% names(mcols(object))
    if (!missing(contrast)) {
        resNames <- resultsNames(object)
        contrast <- checkContrast(contrast, resNames)
        if (!parallel) {
            res <- cleanContrast(object, contrast, expanded = isExpanded, listValues = listValues, test = test, useT = useT, minmu = minmu)
        }
        else if (parallel) {
            nworkers <- getNworkers(BPPARAM)
            idx <- factor(sort(rep(seq_len(nworkers), length.out = nrow(object))))
            res <- do.call(rbind, bplapply(levels(idx), function(l) {
                cleanContrast(object[idx == l, , drop = FALSE], contrast, expanded = isExpanded, listValues = listValues, test = test, useT = useT, minmu = minmu)
            }, BPPARAM = BPPARAM))
        }
    }
    else {
        log2FoldChange <- getCoef(object, name)
        lfcSE <- getCoefSE(object, name)
        stat <- getStat(object, test, name)
        pvalue <- getPvalue(object, test, name)
        res <- cbind(mcols(object)["baseMean"], log2FoldChange, lfcSE, stat, pvalue)
        names(res) <- c("baseMean", "log2FoldChange", "lfcSE", "stat", "pvalue")
    }
    rownames(res) <- rownames(object)
    if (addMLE) {
        if (is.numeric(contrast)) 
            stop("addMLE only implemented for: contrast=c('condition','B','A')")
        if (is.list(contrast)) 
            stop("addMLE only implemented for: contrast=c('condition','B','A')")
        res <- cbind(res, mleContrast(object, contrast))
        res <- res[, c("baseMean", "log2FoldChange", "lfcMLE", "lfcSE", "stat", "pvalue")]
        res$lfcMLE[which(res$log2FoldChange == 0 & res$stat == 0)] <- 0
    }
    if (!(lfcThreshold == 0 & altHypothesis == "greaterAbs")) {
        if (test == "LRT") {
            stop("tests of log fold change above or below a theshold must be Wald tests.")
        }
        if (altHypothesis == "lessAbs" & attr(object, "betaPrior")) {
            stop("testing altHypothesis='lessAbs' requires setting the DESeq() argument betaPrior=FALSE")
        }
        LFC <- res$log2FoldChange
        SE <- res$lfcSE
        T <- lfcThreshold
        if (useT) {
            df <- mcols(object)$tDegreesFreedom
            pfunc <- function(q) pt(q, df = df, lower.tail = FALSE)
        }
        else {
            pfunc <- function(q) pnorm(q, lower.tail = FALSE)
        }
        if (altHypothesis == "greaterAbs") {
            newStat <- sign(LFC) * pmax((abs(LFC) - T)/SE, 0)
            newPvalue <- pmin(1, 2 * pfunc((abs(LFC) - T)/SE))
        }
        else if (altHypothesis == "lessAbs") {
            newStatAbove <- pmax((T - LFC)/SE, 0)
            pvalueAbove <- pfunc((T - LFC)/SE)
            newStatBelow <- pmax((LFC + T)/SE, 0)
            pvalueBelow <- pfunc((LFC + T)/SE)
            newStat <- pmin(newStatAbove, newStatBelow)
            newPvalue <- pmax(pvalueAbove, pvalueBelow)
        }
        else if (altHypothesis == "greater") {
            newStat <- pmax((LFC - T)/SE, 0)
            newPvalue <- pfunc((LFC - T)/SE)
        }
        else if (altHypothesis == "less") {
            newStat <- pmin((LFC + T)/SE, 0)
            newPvalue <- pfunc((-T - LFC)/SE)
        }
        res$stat <- newStat
        res$pvalue <- newPvalue
    }
    m <- nrow(attr(object, "dispModelMatrix"))
    p <- ncol(attr(object, "dispModelMatrix"))
    defaultCutoff <- qf(0.99, p, m - p)
    if (missing(cooksCutoff)) {
        cooksCutoff <- defaultCutoff
    }
    stopifnot(length(cooksCutoff) == 1)
    if (is.logical(cooksCutoff) & cooksCutoff) {
        cooksCutoff <- defaultCutoff
    }
    performCooksCutoff <- (is.numeric(cooksCutoff) | cooksCutoff)
    if (performCooksCutoff) {
        cooksOutlier <- mcols(object)$maxCooks > cooksCutoff
        if (any(cooksOutlier, na.rm = TRUE) & is(design(object), "formula")) {
            designVars <- all.vars(design(object))
            if (length(designVars) == 1) {
                var <- colData(object)[[designVars]]
                if (is(var, "factor") && nlevels(var) == 2) {
                  dontFilter <- logical(sum(cooksOutlier, na.rm = TRUE))
                  for (i in seq_along(dontFilter)) {
                    ii <- which(cooksOutlier)[i]
                    outCount <- counts(object)[ii, which.max(assays(object)[["cooks"]][ii, ])]
                    if (sum(counts(object)[ii, ] > outCount) >= 3) {
                      dontFilter[i] <- TRUE
                    }
                  }
                  cooksOutlier[which(cooksOutlier)][dontFilter] <- FALSE
                }
            }
        }
        res$pvalue[which(cooksOutlier)] <- NA
    }
    if (sum(mcols(object)$replace, na.rm = TRUE) > 0) {
        nowZero <- which(mcols(object)$replace & mcols(object)$baseMean == 0)
        res$log2FoldChange[nowZero] <- 0
        if (addMLE) {
            res$lfcMLE[nowZero] <- 0
        }
        res$lfcSE[nowZero] <- 0
        res$stat[nowZero] <- 0
        res$pvalue[nowZero] <- 1
    }
    deseq2.version <- packageVersion("DESeq2")
    if (!attr(object, "betaPrior")) {
        priorInfo <- list(type = "none", package = "DESeq2", version = deseq2.version)
    }
    else {
        betaPriorVar <- attr(object, "betaPriorVar")
        priorInfo <- list(type = "normal", package = "DESeq2", version = deseq2.version, betaPriorVar = betaPriorVar)
    }
    deseqRes <- DESeqResults(res, priorInfo = priorInfo)
    if (missing(filterFun)) {
        deseqRes <- pvalueAdjustment(deseqRes, independentFiltering, filter, theta, alpha, pAdjustMethod)
    }
    else {
        deseqRes <- filterFun(deseqRes, filter, alpha, pAdjustMethod)
    }
    metadata(deseqRes)[["lfcThreshold"]] <- lfcThreshold
    if (tidy) {
        colnms <- colnames(deseqRes)
        deseqRes$row <- rownames(deseqRes)
        mcols(deseqRes, use.names = TRUE)["row", "type"] <- "results"
        mcols(deseqRes, use.names = TRUE)["row", "description"] <- "row names"
        deseqRes <- deseqRes[, c("row", colnms)]
        rownames(deseqRes) <- NULL
        deseqRes <- as.data.frame(deseqRes)
    }
    out <- resultsFormatSwitch(object = object, res = deseqRes, format = format)
    return(out)
}
