{
    if (independentFiltering) {
        if (missing(filter)) {
            filter <- res$baseMean
        }
        if (missing(theta)) {
            lowerQuantile <- mean(filter == 0)
            if (lowerQuantile < 0.95) 
                upperQuantile <- 0.95
            else upperQuantile <- 1
            theta <- seq(lowerQuantile, upperQuantile, length = 50)
        }
        stopifnot(length(theta) > 1)
        stopifnot(length(filter) == nrow(res))
        filtPadj <- filtered_p(filter = filter, test = res$pvalue, theta = theta, method = pAdjustMethod)
        numRej <- colSums(filtPadj < alpha, na.rm = TRUE)
        lo.fit <- lowess(numRej ~ theta, f = 1/5)
        if (max(numRej) <= 10) {
            j <- 1
        }
        else {
            residual <- if (all(numRej == 0)) {
                0
            }
            else {
                numRej[numRej > 0] - lo.fit$y[numRej > 0]
            }
            thresh <- max(lo.fit$y) - sqrt(mean(residual^2))
            j <- if (any(numRej > thresh)) {
                which(numRej > thresh)[1]
            }
            else {
                1
            }
        }
        padj <- filtPadj[, j, drop = TRUE]
        cutoffs <- quantile(filter, theta)
        filterThreshold <- cutoffs[j]
        filterNumRej <- data.frame(theta = theta, numRej = numRej)
        filterTheta <- theta[j]
        metadata(res)[["filterThreshold"]] <- filterThreshold
        metadata(res)[["filterTheta"]] <- filterTheta
        metadata(res)[["filterNumRej"]] <- filterNumRej
        metadata(res)[["lo.fit"]] <- lo.fit
        metadata(res)[["alpha"]] <- alpha
    }
    else {
        padj <- p.adjust(res$pvalue, method = pAdjustMethod)
    }
    res$padj <- padj
    mcols(res)$type[names(res) == "padj"] <- "results"
    mcols(res)$description[names(res) == "padj"] <- paste(pAdjustMethod, "adjusted p-values")
    res
}
