from pathlib import Path
import json,zipfile
from hashlib import sha256
b=Path('build/literature-review/nfcore-runtime');target=Path('src/test/resources/org/jlinalg/cli/nfcore-deseq126');target.mkdir(parents=True)
payload={}
for case in ['captured','three_groups','outlier_replacement']:
 root=b/'deseq126-native-controls-4'/case
 for path in root.rglob('*'):
  if not path.is_file():continue
  name=path.relative_to(root).as_posix()
  if name in ['libraries.txt','case.properties','featureCounts.txt'] or name.startswith(('worker/','peaks/')) or name.startswith('published/') and name.endswith(('.results.txt','.results.bed','.sizeFactor.txt')):payload[case+'/'+name]=path.read_bytes()
source=dict(schema_version=1,scientific_result_admitted=False,scope='Complete original postfit exports and original published differential tables; component controls only. Captured test workflow and complete explicitly simulated controls, not biological or paper-reproduction results.',populations={'captured':dict(genes=1472,samples=4,comparisons=1,original_fit_type='local'),'three_groups':dict(genes=300,samples=6,comparisons=3,seed=36,includes_all_zero=True,includes_contrast_all_zero=True),'outlier_replacement':dict(genes=300,samples=16,comparisons=1,seed=36,outlier_count=100000000,source_replaced_gene='Interval_2',source_NA_replacement_gene='Interval_1')},original_source=dict(pipeline='nf-core/chipseq',tag='1.2.1',commit='0f487ed76dc947793ab48527d8d3025f5f3060a5',featurecounts_script=dict(bytes=14358,sha256='2cc0b8a836db7897fec8237785cb11f045a1044a6eeddce228f750c0f5a38b16')),worker=dict(bytes=(Path('src/main/resources/org/jlinalg/omics/nfcore-deseq126/inspect.R')).stat().st_size,sha256=sha256(Path('src/main/resources/org/jlinalg/omics/nfcore-deseq126/inspect.R').read_bytes()).hexdigest()),files={n:dict(bytes=len(v),sha256=sha256(v).hexdigest()) for n,v in sorted(payload.items())})
payload['SOURCE.json']=(json.dumps(source,indent=2)+'\n').encode();payload['ORIGINAL-nfcore-LICENSE']=(b/'deseq126-synthetic-original-1/ORIGINAL-LICENSE').read_bytes()
with zipfile.ZipFile(target/'reference.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,raw in sorted(payload.items()):
  info=zipfile.ZipInfo(name,(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,raw)
(target/'SOURCE.json').write_bytes(payload['SOURCE.json']);(target/'.gitattributes').write_bytes(b'* -text\n');print('reference',len(payload),(target/'reference.zip').stat().st_size,sha256((target/'reference.zip').read_bytes()).hexdigest())
