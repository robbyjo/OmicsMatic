import json,shutil,subprocess,sys
from pathlib import Path
sys.path.insert(0,str(Path('tools/literature').resolve()))
from validate_nfcore_engine import ROOT,BASE,DISTRO,linux
from setup_deseq2_reference import pin,save
out=BASE/'deseq126-synthetic-original-1';out.mkdir();attempt=BASE/'scientific-cross-platform-2/original-complete-attempt';cap=json.loads((attempt/'capture.json').read_bytes())
item=cap['roots'][0]['items']['workflow/bin/featurecounts_deseq2.r']['original']['pin'];script=attempt/'objects'/item['sha256'];assert pin(script)==item;shutil.copyfile(script,out/'featurecounts_deseq2.r')
license=cap['roots'][0]['items']['workflow/LICENSE']['original']['pin'];shutil.copyfile(attempt/'objects'/license['sha256'],out/'ORIGINAL-LICENSE')
generate=r'''args <- commandArgs(trailingOnly=TRUE)
root <- args[1];set.seed(36)
for (name in c("three_groups","outlier_replacement")) {
 groups <- if (name=="three_groups") rep(c("A","B","C"),each=2) else rep(c("A","B"),each=8)
 samples <- unlist(lapply(unique(groups),function(g)paste0(g,"_R",seq_len(sum(groups==g)))))
 n <- 300L;counts <- matrix(rnbinom(n*length(samples),mu=50,size=10),nrow=n)
 counts[1,] <- 0L
 if (name=="three_groups") { counts[2,groups %in% c("A","B")] <- 0L; counts[2,groups=="C"] <- 60L;counts[3:35,groups=="A"] <- counts[3:35,groups=="A"]*4L }
 else counts[2,3] <- 100000000L
 directory <- file.path(root,name);dir.create(directory);dir.create(file.path(directory,"peaks"));dir.create(file.path(directory,"published"))
 writeLines(samples,file.path(directory,"libraries.txt"))
 writeLines(c("published_directory=deseq2","model_prefix=CONTROL.consensus_peaks","genes=300","bam_suffix=.mLb.clN.bam"),file.path(directory,"case.properties"))
 order <- rev(seq_along(samples))
 annotation <- data.frame(Geneid=paste0("Interval_",seq_len(n)),Chr="chr1",Start=seq_len(n)*100L,End=seq_len(n)*100L+50L,Strand="+",Length=51L)
 colnames(counts) <- paste0(samples,".mLb.clN.bam")
 path <- file.path(directory,"featureCounts.txt");writeLines("# Program:featureCounts v2.0.1; Command: explicitly simulated complete differential count control",path)
 write.table(cbind(annotation,counts[,order,drop=FALSE]),file=path,append=TRUE,sep="\t",quote=FALSE,row.names=FALSE,col.names=TRUE)
 for (sample in samples) write.table(data.frame(Chr="chr1",Start=annotation$Start,End=annotation$End,Name=paste0(sample,"_peak_",seq_len(n)),Score=100L,Strand=".",Fold=2,P=3,Q=4),file=file.path(directory,"peaks",paste0(sample,"_peaks.broadPeak")),sep="\t",quote=FALSE,row.names=FALSE,col.names=FALSE)
}
'''
(out/'generate.R').write_text(generate,encoding='utf8',newline='\n')
base=['wsl.exe','-d',DISTRO,'--exec','/var/tmp/omicsmatic-nfcore-apptainer-1/bin/apptainer','exec','--userns','--no-home','--pid','-B',linux(ROOT)+':'+linux(ROOT),'/var/tmp/omicsmatic-nfcore-images-1/nfcore-chipseq-1.2.1.sif','Rscript','--vanilla']
def run(label,cmd,timeout=300):
 with (out/(label+'.stdout')).open('xb') as so,(out/(label+'.stderr')).open('xb') as se:r=subprocess.run(cmd,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=timeout)
 save(out/(label+'.process.json'),dict(command=cmd,exit_code=r.returncode));assert r.returncode==0,(label,r.returncode,(out/(label+'.stderr')).read_bytes()[-3000:]);print('PASS',label,flush=True)
run('generate',base+[linux(out/'generate.R'),linux(out)])
for name in ['three_groups','outlier_replacement']:
 p=out/name
 run(name+'-original-source',base+[linux(out/'featurecounts_deseq2.r'),'--featurecount_file',linux(p/'featureCounts.txt'),'--bam_suffix','.mLb.clN.bam','--outdir',linux(p/'published/deseq2'),'--outprefix','CONTROL.consensus_peaks','--outsuffix','','--cores','2'],timeout=300)
 run(name+'-postfit-worker',base+[linux(ROOT/'src/main/resources/org/jlinalg/omics/nfcore-deseq126/inspect.R'),linux(p/'published/deseq2/CONTROL.consensus_peaks.dds.rld.RData'),linux(p/'featureCounts.txt'),'.mLb.clN.bam',linux(p/'worker')])
save(out/'COMPLETED.json',dict(status='PASS_TWO_COMPLETE_ORIGINAL_DIFFERENTIAL_CONTROLS_ONLY',cases=['three_groups','outlier_replacement'],scientific_result_admitted=False));print('PASS original multi-group and replacement controls',flush=True)
