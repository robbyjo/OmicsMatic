from pathlib import Path
import json,subprocess,sys
sys.path.insert(0,str(Path('tools/literature').resolve()))
from validate_nfcore_engine import ROOT,BASE,DISTRO,linux
out=BASE/'deseq126-replacement-probe-1';out.mkdir()
script=out/'probe.R'
script.write_text('''library(DESeq2)
load(commandArgs(trailingOnly=TRUE)[1])
print(mcols(dds)[1:4,c("allZero","replace","baseMean","betaConv")])
for(n in c("DESeq","replaceOutliers","refitWithoutOutliers")) {
fn<-get(n,asNamespace("DESeq2"));writeLines(deparse(body(fn),width.cutoff=500),file.path(commandArgs(trailingOnly=TRUE)[2],paste0(n,".body.R")))
}
''',encoding='utf8',newline='\n')
cmd=['wsl.exe','-d',DISTRO,'--exec','/var/tmp/omicsmatic-nfcore-apptainer-1/bin/apptainer','exec','--userns','--no-home','--pid','-B',linux(ROOT)+':'+linux(ROOT),'/var/tmp/omicsmatic-nfcore-images-1/nfcore-chipseq-1.2.1.sif','Rscript','--vanilla',linux(script),linux(BASE/'deseq126-synthetic-original-1/outlier_replacement/published/deseq2/CONTROL.consensus_peaks.dds.rld.RData'),linux(out)]
with (out/'stdout').open('xb') as so,(out/'stderr').open('xb') as se:r=subprocess.run(cmd,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=120)
(out/'process.json').write_text(json.dumps(dict(command=cmd,exit_code=r.returncode),indent=2)+'\n',encoding='utf8');print('exit',r.returncode);print((out/'stdout').read_text())
