from pathlib import Path
import json,shutil,subprocess,sys
sys.path.insert(0,str(Path('tools/literature').resolve()))
from validate_nfcore_engine import ROOT,BASE,DISTRO,linux
from setup_deseq2_reference import pin,save
out=BASE/'deseq126-worker-controls-3';out.mkdir()
worker=ROOT/'src/main/resources/org/jlinalg/omics/nfcore-deseq126/inspect.R';shutil.copyfile(worker,out/'inspect.R');before=pin(worker)
cases={
 'captured':(BASE/'deseq126-model-intake-1/original-dds-rld.RData',BASE/'deseq126-model-intake-1/original-featureCounts.txt'),
 **{name:(BASE/'deseq126-synthetic-original-1'/name/'published/deseq2/CONTROL.consensus_peaks.dds.rld.RData',BASE/'deseq126-synthetic-original-1'/name/'featureCounts.txt') for name in ['three_groups','outlier_replacement']}}
base=['wsl.exe','-d',DISTRO,'--exec','/var/tmp/omicsmatic-nfcore-apptainer-1/bin/apptainer','exec','--userns','--no-home','--pid','-B',linux(ROOT)+':'+linux(ROOT),'/var/tmp/omicsmatic-nfcore-images-1/nfcore-chipseq-1.2.1.sif','Rscript','--vanilla']
for name,(model,counts) in cases.items():
 cmd=base+[linux(out/'inspect.R'),linux(model),linux(counts),'.mLb.clN.bam',linux(out/name)]
 with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:r=subprocess.run(cmd,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=120)
 save(out/(name+'.process.json'),dict(command=cmd,exit_code=r.returncode,worker_pin=before,input_pins=dict(model=pin(model),counts=pin(counts))));print(name,'exit',r.returncode,flush=True)
 assert r.returncode==0,(out/(name+'.stderr')).read_bytes()[-2000:]
assert pin(worker)==before
save(out/'COMPLETED.json',dict(status='PASS_THREE_COMPLETE_POSTFIT_EXPORTS_ONLY',cases=list(cases),scientific_result_admitted=False))
