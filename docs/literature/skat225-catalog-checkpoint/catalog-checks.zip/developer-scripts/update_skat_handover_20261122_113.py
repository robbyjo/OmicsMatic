import json
from prepare_skat_qualification_20261122_113 import T,B,BASE
from handover_inventory_20261122_111 import git
path=T/'HANDOVER_2026-11-22.md';old=path.read_bytes();assert old==git('show',BASE+':HANDOVER_2026-11-22.md')
assert json.loads((T/'docs/literature/omics-2023-2026/summary.json').read_bytes())['integration_family_counts']['scoped']==148
(B/'HANDOVER-BEFORE.md').write_bytes(old)
path.write_text('''# Omics toolbox handover — 2026-11-22

**The full goal is unfinished.** The catalog contains 250 papers and **148 scoped
families: 27 native + 121 upstream**; 151 includes three existing adapters. There
are 1,661 reviewed and 1,062 pending paper/tool uses, with 258 missing labels and
25 method overlaps. Three aliases receive no additional family credit. These are
bounded implementations, not complete reproduction of every tool or paper.

Original **SKAT 2.2.5 prepared matrix workflows are now qualified and admitted**
as one upstream family. SKAT-O within that provider is an operation/alias.
[Integration and evidence](docs/literature/skat225-qualification/INTEGRATION.md)
describe RUN, offline VERIFY, fresh REPLAY, exact Windows/R prerequisites,
scientific limits, source roles and recovery. [Catalog admission commands](tools/literature/skat225_catalog/ADMISSION.md)
explain the separate guarded metadata transition and its verifier.

Qualification includes 722 selected normal-build tests, 89 independent-original
matrix cases, six additional zero-resampling cases, 33 distinct public tamper
controls and eight real replay/dependency/capacity controls. A fresh source audit
preserves all 15 reviewed SKAT/SKAT-O uses. P246's supplementary workbook has been
inspected read-only; its exact omitted method options remain unestablished.
Other software providers and comparator-only mentions stay distinct. This does
not reconstruct a P246 command or reproduce a biological result.

Current owner: `D:/projects/JLinAlg/build/sk-3`, branch
`codex/skat-qualification-20261122`. Evidence root: `build/skat-qualification-1`.
Publication receipts: `D:/projects/JLinAlg/build/git-publish/20261122-skat-qualification-113`.
Preserve all **69 worktrees**, the dirty root, original indexes, private libraries,
JARs and scientific evidence. The unchanged qualified SKAT JAR remains in
`build/sk-2/build/skat-runtime-1/normal-gradle-8/project-build/cli`.

The preceding development handovers and pinned readers belong to their frozen
owners: `build/sk-1` at `00c262af2a2677baf7cdb35ca0e662a8a6100526` and
`build/sk-2` at `abee077e478906a1a2d3f15005806f9767c2c880`. Their old catalog/root
pins are intentionally historical. Do not refresh them to accept this admission.
The new qualification binds unchanged scientific source and its own evidence.

**Warnings and required actions:** missing/prohibited prerequisites mean **SKIP3**;
supply the exact named permitted item or retain the dependent skip. Input,
numerical, capacity, process and integrity failures mean **FAIL2**, with no
complete admitted result. Preserve raw/null/failed/partial/superseded evidence and
retry NEW output after correcting the named cause. The old matrix4 constant-
outcome result is retained **invalidated evidence: do not use its export**.
Never repair IDs, NaN/Inf, endpoints, weights, unknown options or old hashes
silently. Cell Ranger remains excluded.

Private runtimes, exact JARs, primary source files and private manuscript/rendering
outputs require separate transfer; it has not been performed. See the current
[private transfer inventory](docs/literature/skat225-qualification/PRIVATE-TRANSFER.json)
and its preceding inventories. A GitHub clone alone is not a complete private
handover. Historical backup branch exports remain blocked by automatic approval
review as potentially sensitive broad snapshots; specific approval is pending.
Do not upload the private bundle or merge old snapshots as a workaround.

Next: prioritize feasible high-impact gaps such as GenomicRanges, g:Profiler and
FUSION, then continue the remaining 1,062 use reviews and missed-tool recovery.
Keep native Java for feasible methods and tested upstream adapters where
appropriate. The frozen 2023-10-23..2026-10-23 collection remains 71 Nature,
104 Nature Genetics and 75 AJHG papers. No release, unfinished Pages-report
publication, whole-tool parity or full-goal completion is claimed.
''',encoding='utf-8',newline='\n')
print('Updated current handover from verified canonical148-family state;old note retained unchanged',flush=True)
