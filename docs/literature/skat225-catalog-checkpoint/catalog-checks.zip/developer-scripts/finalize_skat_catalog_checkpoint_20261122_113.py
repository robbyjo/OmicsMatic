from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,zipfile
from prepare_skat_qualification_20261122_113 import R,T,O,B,JAR,BASE
from handover_inventory_20261122_111 import pin,save,git,snapshot
sys.path.insert(0,str(T/'tools/literature'))
from skat225_catalog import model as m,catalog as c
P=T/'docs/literature/skat225-catalog-checkpoint';P.mkdir()
(P/'.gitattributes').write_text('* -text whitespace=cr-at-eol\n',encoding='utf-8',newline='\n')
q=c.packet();proof=json.loads((T/m.PROOF).read_bytes());completed=json.loads((B/'verify-1/result/COMPLETED.json').read_bytes());assert completed['status']==c.STATUS and completed['result']['scoped_families']==148 and completed['current_manifest']['entries']==849
assert completed['actual_runtime_rechecked']['resolved_runtime_files']==154 and completed['actual_runtime_rechecked']['producer']==pin(JAR)
assert json.loads((B/'installed-ui-1/browser/COMPLETED.json').read_bytes())['integrations']==148
assert json.loads((B/'catalog-model-tests-2/PROCESS.json').read_bytes())['exit_code']==0
model_log=(B/'catalog-model-tests-2/stderr').read_text(encoding='utf-8');assert 'Ran 10 tests' in model_log and '\nOK\n' in model_log
assert json.loads((B/'plan-2/result/PLAN.json').read_bytes())['source_code']==c.sources()
assert (T/m.META[0]).read_bytes()==git('show',BASE+':'+m.META[0]) and (T/m.META[5]).read_bytes()==git('show',BASE+':'+m.META[5])
for name in ['literature-review.html','literature-warnings.html']:assert (T/'site'/name).read_bytes()==(B/'plan-2/result/preview/site'/name).read_bytes()
members={}
for directory in ['catalog-model-tests-1','catalog-model-tests-2','plan-1','plan-2','inspect-1','apply-1','verify-1','preview-ui-1','installed-ui-1']:
 for path in (B/directory).rglob('*'):
  if path.is_file():members[path.relative_to(B).as_posix()]=path
for name in ['update_skat_handover_20261122_113.py','run_skat_catalog_model_20261122_113.py','run_skat_catalog_phase_20261122_113.py','run_skat_catalog_ui_20261122_113.py','finalize_skat_catalog_checkpoint_20261122_113.py']:
 members['developer-scripts/'+name]=R/'build'/name
archive=P/'catalog-checks.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,path in sorted(members.items()):z.write(path,name)
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
save(P/'EVIDENCE.json',{'archive':archive.name,'archive_pin':pin(archive),'members':{name:pin(path) for name,path in sorted(members.items())},'prior_plan1_retained':'Superseded before application when standalone command bootstrap and browser/admission documentation were added. Plan2 is exact admitted code;no scientific source/hash or result was refreshed.','raw_qualification_archive':'../skat225-qualification/EVIDENCE.json','all_genotype_phenotype_controls_artificial':True,'installed_runtime_or_JARs_included':False,'website_published':False,'whole_goal_complete':False})
save(P/'QUALIFIED-CURRENT-STATE.json',{'status':'PASS_CURRENT_SKAT225_CATALOG_AND_BROWSER_CHECKPOINT','base':BASE,'counts':completed['result'],'qualified_producer':pin(JAR),'source_code':c.sources(),'scientific_source_unchanged':True,'qualified_packet_status':pin(T/'docs/literature/skat225-qualification/STATUS.json'),'catalog_proof':{'path':m.PROOF,**pin(T/m.PROOF)},'full_manifest':completed['current_manifest'],'normal_build_tests':722,'original_reference_workflow_cases':95,'public_resealed_controls':33,'public_runtime_controls':8,'catalog_model_tests':10,'source_uses_preserved':15,'all_prior_papers_observations_and_reviews_byte_identical':True,'preview_and_installed_HTML_byte_identical':True,'desktop_mobile_preview_visually_reviewed':True,'website_published':False,'new_upstream_family_credit':1,'whole_tool_qualified':False,'whole_paper_reproduced':False,'whole_goal_complete':False})
(P/'README.md').write_text('# Original SKAT catalog checkpoint\n\n'+m.CURRENT+'\n\nThe unchanged original prepared-workflow producer is qualified separately.\nAll95 original-reference workflow cases,33 public resealed controls,eight real\nruntime controls and10 catalog-model tests pass. Preview and installed browser\nreports pass with all15 source uses preserved. These are bounded scientific and\nmetadata checks,not whole-tool or paper reproduction.\n\nRead [integration and warnings](../skat225-qualification/INTEGRATION.md),\n[admission protocol](../../../tools/literature/skat225_catalog/ADMISSION.md),\nand the root handover for exact resume/transfer requirements. The full goal\nremains unfinished;148 scoped families do not imply completion of all250 papers.\n',encoding='utf-8',newline='\n')
before=json.loads((O/'WORKTREES-BEFORE.json').read_bytes());now=snapshot();assert len(before)==68 and len(now)==69;lookup={x['worktree']:x for x in now}
for old in before:assert lookup[old['worktree']]==old,old['worktree']
names=sorted(x[3:].decode('utf-8') for x in git('status','--porcelain=v1','-z','-uall',cwd=T).split(b'\0') if x)
assert all(not name.startswith('build/') for name in names)
save(O/'PUBLICATION-PLAN.json',{'base':BASE,'paths':names,'pins':{name:pin(T/name) for name in names},'counts':completed['result'],'source_code':c.sources(),'qualified_JAR_unchanged':pin(JAR),'prior68_owners_preserved':True,'historical_backup_payloads_included':False,'whole_goal_complete':False})
(O/'MAIN-PATHS.txt').write_text('\n'.join(names)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'status':'READY_TO_STAGE_CURRENT_SKAT_CATALOG_PUBLICATION','files':len(names),'archive':pin(archive),'scoped_families':148,'prior_owners_preserved':68,'scientific_source_unchanged':True},indent=2),flush=True)
