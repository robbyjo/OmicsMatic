from pathlib import Path
import functools,http.server,json,subprocess,sys,threading
from prepare_skat_qualification_20261122_113 import T,B
from handover_inventory_20261122_111 import pin,save
mode=sys.argv[1];assert mode in ['preview','installed'];attempt=int(sys.argv[2]) if len(sys.argv)>2 else 1;D=B/(mode+'-ui-'+str(attempt));D.mkdir();browser=D/'browser';browser.mkdir();site=B/'plan-2/result/preview/site' if mode=='preview' else T/'site';log=(D/'server.log').open('x',encoding='utf-8')
class Handler(http.server.SimpleHTTPRequestHandler):
 def translate_path(self,path):
  candidate=Path(super().translate_path(path))
  if candidate.is_file():return str(candidate)
  relative=candidate.resolve().relative_to(site.resolve());fallback=(T/'site'/relative).resolve();assert fallback.is_relative_to((T/'site').resolve());return str(fallback)
 def log_message(self,format,*args):log.write(format%args+'\n');log.flush()
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(site)));thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();node=Path('C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/node');script=T/'tools/literature/skat225_catalog/check_ui.cjs';command=[str(node/'bin/node.exe'),str(script),str(node/'node_modules/playwright'),str(browser),'http://127.0.0.1:'+str(server.server_port)]
save(D/'STARTED.json',{'command':command,'mode':mode,'source':pin(script),'HTML':{n:pin(site/n) for n in ['literature-review.html','literature-warnings.html']},'website_published':False})
try:
 with (D/'stdout').open('xb') as out,(D/'stderr').open('xb') as err:p=subprocess.run(command,cwd=T,stdin=subprocess.DEVNULL,stdout=out,stderr=err,timeout=180)
 save(D/'PROCESS.json',{'exit_code':p.returncode});print(mode,'UI',p.returncode,flush=True);print((D/'stdout').read_text(errors='replace'),(D/'stderr').read_text(errors='replace')[-3500:],flush=True);assert p.returncode==0,'Inspect retained browser failure'
finally:
 server.shutdown();server.server_close();thread.join(timeout=10);log.close();save(D/'SERVER-CLOSED.json',{'owned_helper_stopped':not thread.is_alive()})
