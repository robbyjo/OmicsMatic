import argparse,json,os,subprocess,sys
from prepare_skat_qualification_20261122_113 import R,T,B,JAR
from handover_inventory_20261122_111 import save
parser=argparse.ArgumentParser();parser.add_argument('phase',choices=['plan','inspect','apply','verify']);parser.add_argument('--attempt',type=int,default=1);args=parser.parse_args();D=B/(args.phase+'-'+str(args.attempt));D.mkdir()
command=[sys.executable,'-X','utf8','-B',str(T/'tools/literature/skat225_catalog/catalog.py'),'--'+args.phase,'--out',str(D/'result'),'--checks-root',str(B),'--jar',str(JAR)]
if args.phase in ['inspect','apply']:command+=['--plan-dir',str(B/'plan-2/result')]
env=dict(os.environ,PYTHONPATH=str(T/'tools/literature'));save(D/'STARTED.json',{'command':command})
with (D/'stdout').open('xb') as out,(D/'stderr').open('xb') as err:p=subprocess.run(command,cwd=T,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,timeout=360)
save(D/'PROCESS.json',{'exit_code':p.returncode});print((D/'stdout').read_text(errors='replace') if p.returncode==0 else (D/'stderr').read_text(errors='replace')[-4500:],flush=True);raise SystemExit(p.returncode)
