import argparse,json,os,subprocess,sys
from prepare_skat_qualification_20261122_113 import T,B
from handover_inventory_20261122_111 import save
parser=argparse.ArgumentParser();parser.add_argument('--attempt',type=int,default=1);args=parser.parse_args();D=B/f'catalog-model-tests-{args.attempt}';D.mkdir();command=[sys.executable,'-X','utf8','-B','-m','unittest','-v','skat225_catalog.test_model'];env=dict(os.environ,PYTHONPATH=str(T/'tools/literature'),SKAT225_QUALIFICATION=str(B/'QUALIFICATION.json'))
save(D/'STARTED.json',{'command':command,'actual_qualification_fixture':str(B/'QUALIFICATION.json')})
with (D/'stdout').open('xb') as out,(D/'stderr').open('xb') as err:p=subprocess.run(command,cwd=T,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,timeout=180)
save(D/'PROCESS.json',{'exit_code':p.returncode});print((D/'stderr').read_text(encoding='utf-8',errors='replace')[-4000:],flush=True);raise SystemExit(p.returncode)
