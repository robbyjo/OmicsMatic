param([string]$AliasPath,[string]$TargetPath)
New-Item -ItemType Junction -Path $AliasPath -Value $TargetPath -ErrorAction Stop | Out-Null
