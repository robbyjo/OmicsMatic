# NO COMPLETE RESULT: SKIP3

org.jlinalg.cli.BroadGseaFiles$Unavailable: Native GSEA requires the normal executable JAR. Build executableJar, then run its BroadGseaWorkflowCli entry point.

Native Broad GSEA prepared-data ranking, permutations and meandiv statistics only. No vendor file ingestion, expression transformation, identifier mapping, annotation/chip collapse or marker/GUI reports. No whole-paper reproduction.

SKIP3: supply the named exact permitted input or executable prerequisite, or retain the dependent analysis as skipped. FAIL2: NO COMPLETE RESULT; preserve inputs, partials and diagnostics, correct the named data/design/integrity/numerical/capacity/process cause and retry NEW output. Never silently repair identifiers or nonfinite values, change editions or substitute algorithms.

Heap, wall time and observed output limits are enforced for the owned Java worker. These are not OS RSS/CPU containment. Preserve all partials. SHA-256 is integrity, not a signature.
