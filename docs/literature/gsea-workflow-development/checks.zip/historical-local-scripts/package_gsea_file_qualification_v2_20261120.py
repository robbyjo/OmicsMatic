from pathlib import Path
R=Path('D:/projects/JLinAlg')
s=(R/'build/package_gsea_file_qualification_20261120.py').read_text().replace("O=B/'public-file-proof-1'","O=B/'public-file-proof-2'")
s=s.replace('files={};binaries={};mapping={}','files={};binaries={};mapping={};reparse_nodes=[]')
start=s.index('def tree(');end=s.index('def archive(',start)
s=s[:start]+'''def tree(name,root):
    def linked(p):
        st=p.lstat()
        if getattr(st,'st_file_attributes',0)&0x400 or p.is_symlink() or p.is_junction():
            reparse_nodes.append(dict(member=name+'/'+p.relative_to(root).as_posix(),kind='reparse_or_link_test_node',reparse_tag=getattr(st,'st_reparse_tag',None),content_dereferenced=False));return True
        return False
    for directory,dirs,names in os.walk(root,followlinks=False):
        dirs[:]=[n for n in dirs if not linked(Path(directory)/n)]
        for n in names:
            p=Path(directory)/n
            if linked(p):continue
            add(name+'/'+p.relative_to(root).as_posix(),p)
''' + s[end:]
s=s.replace("archive(Q/'checks.zip',files);archive(Q/'workflow-results.zip',binaries)","files['TEST-ALIAS-NODES.json']=enc(reparse_nodes);archive(Q/'checks.zip',files);archive(Q/'workflow-results.zip',binaries)")
exec(compile(s,str(Path(__file__)),'exec'))
