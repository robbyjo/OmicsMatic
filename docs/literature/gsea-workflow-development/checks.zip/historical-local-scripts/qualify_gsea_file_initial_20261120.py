from pathlib import Path
import hashlib,importlib.util,json,shutil,subprocess,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/gs-4';B=T/'build/gsea-high-impact-4';O=B/'initial-workflow-1';O.mkdir(exist_ok=False)
JAR=B/'native-gradle-1/project-build/cli/omicsmatic-0.4.0.jar';J=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe')
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
def pin(p):
    with p.open('rb') as f:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
def snapshot(root):return {p.relative_to(root).as_posix():dict(pin(p),mtime_ns=p.stat().st_mtime_ns) for p in root.rglob('*') if p.is_file()}
assert json.loads((B/'native-gradle-1/PROCESS-EXIT.json').read_bytes())['exit_code']==0
examples=O/'examples';shutil.copytree(T/'examples/native-gsea',examples)
before=None
for mode in ['run','verify','replay']:
    command=[str(J),'-cp',str(JAR),'org.jlinalg.cli.BroadGseaWorkflowCli','--request',str(examples/(mode+'.json'))]
    with (O/(mode+'.stdout')).open('xb') as stdout,(O/(mode+'.stderr')).open('xb') as stderr:
        p=subprocess.run(command,cwd=O,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=240)
    save(O/(mode+'.PROCESS.json'),dict(command=command,exit_code=p.returncode));assert p.returncode==0,'Inspect '+mode+' logs'
    if mode=='run':before=snapshot(examples/'run-out')
    else:assert snapshot(examples/'run-out')==before,'Parent changed during '+mode
    status=json.loads((examples/(mode+'-out')/'analysis-status.json').read_bytes());assert status['complete_result'] and status['status']=='PASS_'+mode.upper()
    print('PASS normal-JAR native workflow',mode,'parent preserved',flush=True)
spec=importlib.util.spec_from_file_location('checker',T/'tools/literature/gsea_workflows/check_results.py');checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)
reference=O/'reference';reference.mkdir()
with zipfile.ZipFile(T/'docs/literature/gsea-engine-development/complete-null-references.zip') as z:
    for n in z.namelist():
        if n.startswith('reference/'):
            path=reference/n;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(z.read(n))
fields=0;i=0
for edition in ['4.4.0','4.3.2','4.3.3']:
    for mode in ['preranked','expression-phenotype','expression-geneset']:
        fields+=checker.compare(examples/'run-out/results'/('case-%04d'%i)/'result.bin',reference/'reference'/edition/(mode+'.tsv'));i+=1
assert fields==468270
save(O/'COMPLETED.json',dict(status='PASS_INITIAL_NORMAL_JAR_NATIVE_GSEA_RUN_VERIFY_REPLAY',producer=pin(JAR),original_exact_fields=fields,complete_original_forms=9,permutations_per_form=10000,parent_bytes_and_mtimes_preserved=True,project_global_dispatch_registered=False,new_catalog_credit=0))
print('PASS actual file workflow original complete-null exact fields',fields,flush=True)
