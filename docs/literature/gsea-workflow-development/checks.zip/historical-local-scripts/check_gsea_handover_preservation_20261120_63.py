from pathlib import Path
import hashlib,importlib.util,json,subprocess,sys
R=Path('D:/projects/JLinAlg');T=R/'build/gs-3';K=R/'build/edg-3'
P=R/'build/git-publish/20261120-gsea-native-62';O=R/'build/git-publish/20261120-gsea-handover-63';O.mkdir(exist_ok=False)
def save(n,v):
    with (O/n).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
spec=importlib.util.spec_from_file_location('inventory',O.parent/'20261115-all-main-3/inventory.py');inv=importlib.util.module_from_spec(spec);spec.loader.exec_module(inv)
prior=json.loads((P/'WORKTREES-EXPECTED.json').read_bytes());assert len(prior)==30
current=subprocess.check_output(['git','worktree','list','--porcelain'],cwd=T).decode().strip().split('\n\n')
assert {Path(b.splitlines()[0][9:]).resolve() for b in current}=={Path(r['root']).resolve() for r in prior}|{T.resolve()}
for i,row in enumerate(prior,1):
    assert inv.snapshot(Path(row['root']))==row,row['root']
    if i%5==0:print('Preserved exact historical worktrees:',i,'/30',flush=True)
save('WORKTREES-BEFORE.json',prior+[inv.snapshot(T)])
for name,command,cwd in [
    ('historical-overlays',[sys.executable,'-B',str(T/'docs/literature/handover-20261119/verify.py')],T),
    ('saved-native',[sys.executable,'-B',str(T/'tools/literature/verify_broad_gsea_native.py')],T),
    ('catalog',[sys.executable,'-B',str(K/'tools/literature/close_edger_catalog.py'),'--verify','--primary-cache',str(R/'build/literature-review/xml'),'--out',str(K/'build/gsea-engine-handover-catalog-readback-1')],K)]:
    with (O/(name+'.stdout')).open('xb') as stdout,(O/(name+'.stderr')).open('xb') as stderr:
        p=subprocess.run(command,cwd=cwd,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=1200)
    save(name+'.PROCESS.json',dict(command=command,exit_code=p.returncode));assert p.returncode==0,'Inspect '+name+' logs'
    print('PASS fresh readback',name,flush=True)
canonical=json.loads((P/'CANONICAL-AFTER.json').read_bytes());assert len(canonical)==15
for name,w in canonical.items():
    raw=(T/name).read_bytes();assert dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())==w,name
save('CANONICAL-BEFORE.json',canonical);save('CANONICAL-AFTER.json',canonical)
save('READBACKS-COMPLETED.json',dict(status='PASS_30_PRIOR_WORKTREES_OVERLAYS_NATIVE_AND_CATALOG_READBACKS',prior_worktrees=30,total_worktrees=31,canonical_files_unchanged=15))
