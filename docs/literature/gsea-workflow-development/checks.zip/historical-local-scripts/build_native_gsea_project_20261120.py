from pathlib import Path
import hashlib,json,os,shutil,subprocess
R=Path('D:/projects/JLinAlg');H=R/'build/gs-2';B=H/'build/gsea-high-impact-2';O=B/'native-gradle-1';O.mkdir(exist_ok=False)
OUT=O/'project-build';(OUT/'dependencies').mkdir(parents=True)
dependency=R/'build/edg-3/build/edger-admission-1/dispatch-gradle-1/project-build/dependencies/jdistlib-all-0.10.2.jar'
with dependency.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()=='8b50aaa11d2cbd512525e0d74f8e609f40db9f4fc179ccb7a885a82257e0ac81'
shutil.copyfile(dependency,OUT/'dependencies'/dependency.name)
init=O/'isolate.gradle';init.write_text("gradle.beforeProject { p -> p.layout.buildDirectory.set(new File('"+OUT.as_posix()+"')) }\n",encoding='utf-8',newline='\n')
gradle=next(Path('C:/Users/User/.gradle/wrapper/dists').glob('gradle-9.7.1-bin/*/gradle-9.7.1/bin/gradle.bat'))
command=[str(gradle),'--no-daemon','--offline','--console=plain','--max-workers=2','--project-cache-dir',str(O/'project-cache'),
    '--init-script',str(init),'executableJar',':test','--tests','org.jlinalg.enrichment.BroadGseaStatisticsTest']
(O/'COMMAND.json').write_text(json.dumps(dict(command=command,cwd=str(H),JAVA_HOME='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot'),indent=2)+'\n',encoding='utf-8')
with (O/'stdout').open('xb') as stdout,(O/'stderr').open('xb') as stderr:
    p=subprocess.Popen(command,cwd=H,env=dict(os.environ,JAVA_HOME='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot'),stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr)
    (O/'PROCESS.json').write_text(json.dumps(dict(pid=p.pid),indent=2)+'\n',encoding='utf-8');code=p.wait()
(O/'PROCESS-EXIT.json').write_text(json.dumps(dict(exit_code=code),indent=2)+'\n',encoding='utf-8')
print('Native GSEA normal project build / focused source-counterpart tests exit',code,flush=True)
assert code==0,'Inspect retained Gradle stdout/stderr'
