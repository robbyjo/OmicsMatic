from pathlib import Path
import hashlib,importlib.util,json,os,re,subprocess,sys,traceback,zipfile
R=Path('D:/projects/JLinAlg');H=R/'build/gs-2';K=R/'build/edg-3';B=H/'build/gsea-high-impact-2'
P=R/'build/git-publish/20261120-gsea-handover-61';O=R/'build/git-publish/20261120-gsea-native-62'
BASE='7a50e4a18d27e0bccd82d70b9a5632062abb3fc3';O.mkdir(exist_ok=False);sys.dont_write_bytecode=True
def git(*a):return subprocess.check_output(['git','--no-replace-objects',*a],cwd=H)
def rawpin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def pin(p):
    with Path(p).open('rb') as f:return dict(bytes=Path(p).stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
def statpin(p):
    s=Path(p).stat();return dict(bytes=s.st_size,mtime_ns=s.st_mtime_ns)
def save(n,v):
    with (O/n).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
try:
    assert git('rev-parse','HEAD').decode().strip()==BASE
    assert git('remote','get-url','origin').decode().strip()=='https://github.com/robbyjo/OmicsMatic.git'
    assert git('ls-remote','origin','refs/heads/main').decode().split()[0]==BASE
    assert not git('diff','--cached','--name-only')
    assert not git('diff','--name-only','--','site','.github','src/main/java','tools/literature/reviewed-uses.json')
    canonical=json.loads((P/'CANONICAL-AFTER.json').read_bytes());assert len(canonical)==15
    for name,w in canonical.items():assert pin(H/name)==w==rawpin(git('show',BASE+':'+name)),name
    save('CANONICAL-BEFORE.json',canonical);save('CANONICAL-AFTER.json',canonical)
    command=[sys.executable,'-B',str(K/'tools/literature/close_edger_catalog.py'),'--verify','--primary-cache',str(R/'build/literature-review/xml'),
        '--out',str(K/'build/gsea-native-catalog-readback-1')]
    with (O/'catalog.stdout').open('xb') as stdout,(O/'catalog.stderr').open('xb') as stderr:
        process=subprocess.run(command,cwd=K,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=900)
    save('CATALOG-PROCESS.json',dict(command=command,exit_code=process.returncode));assert process.returncode==0,'Inspect saved catalog stderr.'
    catalog=json.loads((K/'build/gsea-native-catalog-readback-1/COMPLETED.json').read_bytes())
    assert catalog['result']['integrations']==139 and catalog['current_manifest']['entries']==823
    save('CURRENT-VERIFICATION.json',catalog)
    spec=importlib.util.spec_from_file_location('native_reader',H/'tools/literature/verify_broad_gsea_native.py');reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
    result,_=reader.verify();assert result['exact_field_comparisons_per_JVM']==356286 and result['source_bound_refusals_per_JVM']==1701
    save('SAVED-NATIVE-QUALIFICATION.json',result)
    controls=json.loads((H/'docs/literature/gsea-native-development/READER-CONTROLS.json').read_bytes())
    raw=(H/'docs/literature/gsea-native-development/reader-controls.zip').read_bytes();assert rawpin(raw)==controls['archive']
    import io
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        assert set(z.namelist())==set(controls['files']) and z.testzip() is None
        for n,w in controls['files'].items():assert rawpin(z.read(n))==w,n
    assert controls['hosts']==2 and controls['refusals']==12
    for rows in controls['controls']['results'].values():assert len(rows)==7 and all(r['exit_code']==r['expected'] for r in rows)
    links=0
    docs=['docs/literature/HANDOVER_CURRENT.md','docs/literature/GSEA_NATIVE_CHECKPOINT_2026-11-20.md',
        'docs/literature/gsea-native-development/README.md','docs/vignettes/gsea-native-statistics.md','tools/literature/gsea_original/README.md']
    for name in docs:
        for match in re.finditer(r'\]\(([^)]+)\)',(H/name).read_text(encoding='utf-8')):
            target=match[1].split('#',1)[0]
            if target and '://' not in target:assert (H/name).parent.joinpath(target).exists(),(name,target);links+=1
    save('DOCUMENT-LINKS-PASS.json',dict(status='PASS_ALL_RELATIVE_LINKS',links=links))
    spec=importlib.util.spec_from_file_location('inventory',O.parent/'20261115-all-main-3/inventory.py');inv=importlib.util.module_from_spec(spec);spec.loader.exec_module(inv)
    previous=json.loads((P/'WORKTREES-EXPECTED.json').read_bytes());assert len(previous)==29
    roots={Path(b.splitlines()[0][9:]).resolve() for b in git('worktree','list','--porcelain').decode().strip().split('\n\n')}
    assert roots=={Path(r['root']).resolve() for r in previous}|{H.resolve()}
    for i,row in enumerate(previous,1):
        assert inv.snapshot(Path(row['root']))==row,'Prior worktree changed: '+row['root']
        git('merge-base','--is-ancestor',row['head'],BASE)
        if i%5==0:print('Prior worktrees exact:',i,'/29',flush=True)
    active=inv.snapshot(H);assert active['head']==BASE and active['branch']=='codex/gsea-workflows-20261120'
    save('WORKTREES-BEFORE.json',previous+[active])
    protected=json.loads((P/'PROTECTED-ARTIFACTS.json').read_bytes());stats=json.loads((P/'PROTECTED-STAT-BEFORE.json').read_bytes())
    inherited=len(protected);assert inherited==len(stats)==345727 and set(protected)==set(stats)
    for i,(n,w) in enumerate(stats.items(),1):
        assert statpin(n)==w and w['bytes']==protected[n]['bytes'],n
        if i%50000==0:print('Inherited artifact size/mtime exact:',i,'/',inherited,flush=True)
    added=0
    for parent in [B,R/'build/gsea-workflow-start-20261120-1',K/'build/gsea-native-catalog-readback-1']:
        assert parent.exists() and parent.resolve().is_relative_to(R.resolve())
        for directory,dirs,files in os.walk(parent,followlinks=False):
            dirs[:]=[n for n in dirs if not (Path(directory)/n).is_symlink() and not (Path(directory)/n).is_junction()]
            for name in files:
                path=Path(directory)/name
                if path.is_symlink() or str(path) in protected:continue
                protected[str(path)]=pin(path);stats[str(path)]=statpin(path);added+=1
    for path in sorted((R/'build').glob('*gsea*20261120*.py')):
        if str(path) in protected:continue
        protected[str(path)]=pin(path);stats[str(path)]=statpin(path);added+=1
    save('PROTECTED-ARTIFACTS.json',protected);save('PROTECTED-STAT-BEFORE.json',stats)
    save('INHERITED-PRESERVATION-SCOPE.json',dict(inherited_artifacts=inherited,inherited_source_receipt=pin(P/'PUBLISHED.json'),
        inherited_SHA256_manifest=pin(P/'PROTECTED-ARTIFACTS.json'),full_inherited_hash_pass_repeated=False,
        inherited_size_mtime_unchanged=True,new_artifacts_SHA256_pinned=added))
    print('New artifacts SHA256 pinned:',added,'total protected',len(protected),flush=True)
    allowed={'.gitattributes','docs/literature/HANDOVER_CURRENT.md','docs/literature/GSEA_NATIVE_CHECKPOINT_2026-11-20.md',
        'docs/vignettes/gsea-native-statistics.md','tools/literature/verify_broad_gsea_native.py',
        'src/main/java/org/jlinalg/enrichment/BroadGseaStatistics.java','src/main/resources/META-INF/licenses/GSEA-DESKTOP-LICENSE.txt',
        'src/test/java/org/jlinalg/enrichment/BroadGseaStatisticsTest.java','src/test/resources/org/jlinalg/enrichment/broad-gsea-originals.zip'}
    for folder in [H/'tools/literature/gsea_original',H/'docs/literature/gsea-native-development']:
        allowed.update(p.relative_to(H).as_posix() for p in folder.rglob('*') if p.is_file())
    entries=[e for e in git('status','--porcelain=v1','-z','--untracked-files=all').split(b'\0') if e]
    assert all(e[:2] in [b' M',b'??'] for e in entries)
    actual={e[3:].decode() for e in entries};assert actual==allowed,dict(unexpected=sorted(actual-allowed),missing=sorted(allowed-actual))
    for n in sorted(allowed):assert git('hash-object','--no-filters','--',n)==git('hash-object','--path='+n,'--',n),'Git would normalize: '+n
    pins={n:pin(H/n) for n in sorted(allowed)};save('ALLOWED.json',pins)
    with zipfile.ZipFile(O/'PUBLIC-BEFORE-COMMIT.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
        for n in sorted(allowed):z.writestr(n,(H/n).read_bytes())
    git('add','--',*sorted(allowed))
    assert set(git('diff','--cached','--name-only','-z').decode().strip('\0').split('\0'))==allowed
    for n,w in pins.items():assert rawpin(git('show',':'+n))==w,n
    process=subprocess.run(['git','diff','--cached','--check'],cwd=H,capture_output=True)
    (O/'DIFF-CHECK.stdout').write_bytes(process.stdout);(O/'DIFF-CHECK.stderr').write_bytes(process.stderr);assert process.returncode==0,'Inspect saved whitespace check.'
    message=('feat: qualify native Broad GSEA score and empirical-statistics arithmetic\n\n'
        'Implement source float/mixed score walks, meandiv NES, sign-tail nominal\n'
        'P, per-column empirical FDR and FWER without external software. Refuse\n'
        'source substitution, undefined-result and explicit capacity boundaries.\n'
        'Retain the original BSD notice and all prior scientific JAR payloads.\n\n'
        'Check unchanged original 4.3.2/4.3.3/4.4.0 CLI/API counterparts in three\n'
        '10000-permutation forms each. Pass 356286 exact fields and 1701 source\n'
        'refusals per JVM on Windows21/25 and Linux21, normal build/JUnit, saved\n'
        'readers on two hosts and twelve reader refusals. Preserve failures.\n\n'
        'Leave canonical catalog, integration counts, site and release unchanged.\n'
        'Document exact next work and preserve all 30 worktrees/private evidence.\n'
        'Project file workflows, global dispatch, per-paper review, GSEA admission\n'
        'and the full 250-paper implementation/review goal remain unfinished.\n')
    (O/'COMMIT-MESSAGE.txt').write_text(message,encoding='utf-8',newline='\n')
    process=subprocess.run(['git','commit','-F',str(O/'COMMIT-MESSAGE.txt')],cwd=H,capture_output=True)
    (O/'commit.stdout').write_bytes(process.stdout);(O/'commit.stderr').write_bytes(process.stderr);assert process.returncode==0,'Inspect saved commit stderr.'
    head=git('rev-parse','HEAD').decode().strip();assert not git('status','--porcelain=v1','-z','--untracked-files=all')
    for row in previous:assert inv.snapshot(Path(row['root']))==row,row['root']
    now=inv.snapshot(H);assert now['head']==head and not now['files'] and not now['status_hex']
    save('WORKTREES-EXPECTED.json',previous+[now])
    save('COMMITTED.json',dict(head=head,base=BASE,files=pins,worktrees=30,protected_artifacts=len(protected),inherited_artifacts=inherited,
        new_artifacts_SHA256_pinned=added,canonical_files_unchanged=15,all_preceding_scientific_payloads_unchanged=True,
        native_GSEA_arithmetic_qualified=True,new_catalog_credit=0,GSEA_project_workflow_qualified=False,whole_goal_complete=False))
    print(json.dumps(dict(status='COMMITTED_NATIVE_GSEA_ARITHMETIC_READY_TO_PUSH',head=head,files=len(pins),worktrees=30,protected_artifacts=len(protected))),flush=True)
except Exception as error:
    save('FAILURE.json',dict(error=repr(error),detail=traceback.format_exc()));raise
