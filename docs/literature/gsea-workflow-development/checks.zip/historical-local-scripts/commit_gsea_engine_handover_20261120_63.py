from pathlib import Path
import hashlib,importlib.util,json,os,re,subprocess,traceback,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/gs-3';K=R/'build/edg-3';B=T/'build/gsea-high-impact-3'
P=R/'build/git-publish/20261120-gsea-native-62';O=R/'build/git-publish/20261120-gsea-handover-63'
BASE='7f4cc3185a642c61c7ab42b8b84a2630fac1fec7'
def git(*args):return subprocess.check_output(['git','--no-replace-objects',*args],cwd=T)
def pinraw(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def pin(p):
    with Path(p).open('rb') as f:return dict(bytes=Path(p).stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
def statpin(p):
    s=Path(p).stat();return dict(bytes=s.st_size,mtime_ns=s.st_mtime_ns)
def save(n,v):
    with (O/n).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
try:
    assert git('rev-parse','HEAD').decode().strip()==BASE
    assert git('remote','get-url','origin').decode().strip()=='https://github.com/robbyjo/OmicsMatic.git'
    assert git('ls-remote','origin','refs/heads/main').decode().split()[0]==BASE
    assert not git('diff','--cached','--name-only')
    assert json.loads((O/'READBACKS-COMPLETED.json').read_bytes())['total_worktrees']==31
    spec=importlib.util.spec_from_file_location('reader',T/'tools/literature/verify_broad_gsea_engine_checkpoint.py');reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
    result=reader.verify();save('SAVED-ENGINE-QUALIFICATION.json',result)
    canonical=json.loads((O/'CANONICAL-AFTER.json').read_bytes());assert len(canonical)==15
    for n,w in canonical.items():assert pin(T/n)==w==pinraw(git('show',BASE+':'+n)),n
    catalog=json.loads((K/'build/gsea-engine-handover-catalog-readback-1/COMPLETED.json').read_bytes())
    assert catalog['result']['integrations']==139 and catalog['current_manifest']['entries']==823
    save('CURRENT-CATALOG-VERIFICATION.json',catalog)
    docs=['docs/literature/HANDOVER_CURRENT.md','docs/literature/HANDOVER_2026-11-20_GSEA_ENGINE.md','docs/literature/gsea-engine-development/README.md','tools/literature/gsea_engine/README.md']
    links=0
    for n in docs:
        for m in re.finditer(r'\]\(([^)]+)\)',(T/n).read_text(encoding='utf-8')):
            target=m[1].split('#',1)[0]
            if target and '://' not in target:assert (T/n).parent.joinpath(target).exists(),(n,target);links+=1
    save('DOCUMENT-LINKS-PASS.json',dict(status='PASS_ALL_RELATIVE_LINKS',links=links))
    spec=importlib.util.spec_from_file_location('inventory',O.parent/'20261115-all-main-3/inventory.py');inv=importlib.util.module_from_spec(spec);spec.loader.exec_module(inv)
    previous=json.loads((P/'WORKTREES-EXPECTED.json').read_bytes());assert len(previous)==30
    roots={Path(b.splitlines()[0][9:]).resolve() for b in git('worktree','list','--porcelain').decode().strip().split('\n\n')}
    assert roots=={Path(row['root']).resolve() for row in previous}|{T.resolve()}
    for row in previous:
        assert inv.snapshot(Path(row['root']))==row,row['root'];git('merge-base','--is-ancestor',row['head'],BASE)
    active=inv.snapshot(T);assert active['head']==BASE and active['branch']=='codex/gsea-engine-20261120'
    protected=json.loads((P/'PROTECTED-ARTIFACTS.json').read_bytes());stats=json.loads((P/'PROTECTED-STAT-BEFORE.json').read_bytes())
    inherited=len(protected);assert inherited==len(stats)==389663 and set(protected)==set(stats)
    for i,(n,w) in enumerate(stats.items(),1):
        assert statpin(n)==w and w['bytes']==protected[n]['bytes'],n
        if i%50000==0:print('Inherited artifact size/mtime exact:',i,'/',inherited,flush=True)
    added=0
    for parent in [B,R/'build/gsea-engine-start-20261120-1',K/'build/gsea-engine-handover-catalog-readback-1']:
        assert parent.exists() and parent.resolve().is_relative_to(R.resolve())
        for directory,dirs,files in os.walk(parent,followlinks=False):
            dirs[:]=[n for n in dirs if not (Path(directory)/n).is_symlink() and not (Path(directory)/n).is_junction()]
            for name in files:
                path=Path(directory)/name
                if path.is_symlink() or str(path) in protected:continue
                protected[str(path)]=pin(path);stats[str(path)]=statpin(path);added+=1
    for path in sorted((R/'build').glob('*gsea*20261120*.py')):
        if str(path) in protected:continue
        protected[str(path)]=pin(path);stats[str(path)]=statpin(path);added+=1
    save('PROTECTED-ARTIFACTS.json',protected);save('PROTECTED-STAT-BEFORE.json',stats)
    save('INHERITED-PRESERVATION-SCOPE.json',dict(inherited_artifacts=inherited,inherited_source_receipt=pin(P/'PUBLISHED.json'),inherited_SHA256_manifest=pin(P/'PROTECTED-ARTIFACTS.json'),full_inherited_hash_pass_repeated=False,inherited_size_mtime_unchanged=True,new_artifacts_SHA256_pinned=added))
    print('New artifacts SHA256 pinned:',added,'total protected',len(protected),flush=True)
    allowed={'docs/literature/HANDOVER_CURRENT.md','docs/literature/HANDOVER_2026-11-20_GSEA_ENGINE.md','src/main/java/org/jlinalg/enrichment/BroadGseaEngine.java','src/test/java/org/jlinalg/enrichment/BroadGseaEngineTest.java','src/test/resources/org/jlinalg/enrichment/broad-gsea-engine-originals.zip','tools/literature/verify_broad_gsea_engine_checkpoint.py'}
    for folder in [T/'docs/literature/gsea-engine-development',T/'tools/literature/gsea_engine']:
        allowed.update(p.relative_to(T).as_posix() for p in folder.rglob('*') if p.is_file())
    entries=[e for e in git('status','--porcelain=v1','-z','--untracked-files=all').split(b'\0') if e]
    assert all(e[:2] in [b' M',b'??'] for e in entries)
    actual={e[3:].decode() for e in entries};assert actual==allowed,dict(unexpected=sorted(actual-allowed),missing=sorted(allowed-actual))
    for n in sorted(allowed):assert git('hash-object','--no-filters','--',n)==git('hash-object','--path='+n,'--',n),'Git would normalize '+n
    pins={n:pin(T/n) for n in sorted(allowed)};save('ALLOWED.json',pins)
    with zipfile.ZipFile(O/'PUBLIC-BEFORE-COMMIT.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
        for n in sorted(allowed):z.writestr(n,(T/n).read_bytes())
    git('add','--',*sorted(allowed))
    assert set(git('diff','--cached','--name-only','-z').decode().strip('\0').split('\0'))==allowed
    for n,w in pins.items():assert pinraw(git('show',':'+n))==w,n
    p=subprocess.run(['git','diff','--cached','--check'],cwd=T,capture_output=True)
    (O/'DIFF-CHECK.stdout').write_bytes(p.stdout);(O/'DIFF-CHECK.stderr').write_bytes(p.stderr);assert p.returncode==0,'Inspect saved whitespace check'
    message=('feat: preserve native GSEA engine and explicit handover checkpoint\n\n'
        'Implement prepared-data source ranking and original phenotype/gene-set\n'
        'permutations using the qualified native Broad GSEA statistics. Preserve\n'
        'strict refusal boundaries and original class/member ordering.\n\n'
        'Pass normal build and three focused JUnit tests, plus 668739 exact\n'
        'fields and 201 expected refusals per JVM on Windows21/25 and Linux21.\n'
        'Retain all 23490 predecessor JAR payloads, complete source fixtures,\n'
        'prior attempt versions and exact resume/transfer instructions.\n\n'
        'Leave the GSEA file workflow, RUN/VERIFY/REPLAY, global command and\n'
        'catalog admission explicitly unfinished. Keep the 139-integration\n'
        'catalog, 1520 reviews, site, withheld reports and release unchanged.\n'
        'Preserve all 31 worktrees and historical overlay/private evidence.\n')
    (O/'COMMIT-MESSAGE.txt').write_text(message,encoding='utf-8',newline='\n')
    p=subprocess.run(['git','commit','-F',str(O/'COMMIT-MESSAGE.txt')],cwd=T,capture_output=True)
    (O/'commit.stdout').write_bytes(p.stdout);(O/'commit.stderr').write_bytes(p.stderr);assert p.returncode==0,'Inspect saved commit logs'
    head=git('rev-parse','HEAD').decode().strip();assert not git('status','--porcelain=v1','-z','--untracked-files=all')
    for row in previous:assert inv.snapshot(Path(row['root']))==row,row['root']
    now=inv.snapshot(T);assert not now['files'] and not now['status_hex']
    save('WORKTREES-EXPECTED.json',previous+[now])
    save('COMMITTED.json',dict(head=head,base=BASE,files=pins,worktrees=31,protected_artifacts=len(protected),inherited_artifacts=inherited,new_artifacts_SHA256_pinned=added,canonical_files_unchanged=15,unchanged_predecessor_JAR_members=23490,native_GSEA_engine_qualified=True,new_catalog_credit=0,GSEA_project_file_workflow_qualified=False,whole_goal_complete=False))
    print(json.dumps(dict(status='COMMITTED_GSEA_ENGINE_HANDOVER_READY_TO_PUSH',head=head,files=len(pins),worktrees=31,protected_artifacts=len(protected))),flush=True)
except Exception as error:
    save('COMMIT-FAILURE.json',dict(error=repr(error),detail=traceback.format_exc()));raise
