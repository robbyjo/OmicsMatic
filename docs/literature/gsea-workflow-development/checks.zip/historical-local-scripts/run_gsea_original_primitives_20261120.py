from pathlib import Path
import hashlib,json,subprocess,traceback
R=Path('D:/projects/JLinAlg');H=R/'build/gs-2';B=H/'build/gsea-high-impact-2';O=B/'original-primitives-1';O.mkdir(exist_ok=False)
F=R/'build/gs-1/build/gsea-high-impact-1/runtime-source-4.4.0-1';J=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin')
def save(p,v):p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
source=H/'tools/literature/gsea_original/OriginalPrimitiveProbe.java';classes=O/'classes';classes.mkdir()
p=subprocess.run([str(J/'javac.exe'),'--release','17','-cp',str(F/'modules/*'),'-d',str(classes),str(source)],capture_output=True)
(O/'javac.stdout').write_bytes(p.stdout);(O/'javac.stderr').write_bytes(p.stderr);assert p.returncode==0
home=O/'home';home.mkdir();cwd=O/'worker';cwd.mkdir()
command=[str(J/'java.exe'),'-Xmx1g','-Djava.awt.headless=true','-Duser.home='+str(home),'-DMAKE_GSEA_UPDATE_CHECK=false',
    '-cp',str(F/'modules/*')+';'+str(classes),'OriginalPrimitiveProbe',str(O/'original-primitives.tsv')]
with (O/'stdout').open('xb') as stdout,(O/'stderr').open('xb') as stderr:
    p=subprocess.run(command,cwd=cwd,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=180)
save(O/'PROCESS.json',dict(command=command,exit_code=p.returncode,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest()))
assert p.returncode==0,'Inspect retained stderr'
print('PASS original primitive export',O/'original-primitives.tsv',flush=True)
