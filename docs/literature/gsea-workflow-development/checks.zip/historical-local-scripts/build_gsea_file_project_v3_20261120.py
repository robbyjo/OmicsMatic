from pathlib import Path
R=Path('D:/projects/JLinAlg')
s=(R/'build/build_gsea_file_project_v2_20261120.py').read_text().replace("snapshot=B/'source-output-cap-correction-2'","snapshot=B/'source-canonical-ledgers-3'").replace("O=B/'native-gradle-2'","O=B/'native-gradle-3'")
exec(compile(s,str(Path(__file__)),'exec'))
