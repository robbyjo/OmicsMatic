from pathlib import Path
p=Path('D:/projects/JLinAlg/build/compile_gsea_file_workflow_20261120.py')
exec(compile(p.read_text().replace("O=B/'compile-1'","O=B/'compile-3'"),str(Path(__file__)),'exec'))
