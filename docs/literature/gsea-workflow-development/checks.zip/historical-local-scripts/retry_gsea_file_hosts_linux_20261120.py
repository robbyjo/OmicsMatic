from pathlib import Path
import json
R=Path('D:/projects/JLinAlg');B=R/'build/gs-4/build/gsea-high-impact-4'
assert json.loads((B/'linux-preflight-1/pymol-java.PROCESS.json').read_bytes())['exit_code']==0
reason=dict(previous='file-hosts-qualification-1/linux-java21',reason='Original SAIGE distribution reported E_ILLEGAL_STATE_CHANGE during external compaction before Java started. Preserve the failed preflight. Retry on the independently preflighted existing PyMOL distribution running OpenJDK 21.0.12.1; no scientific engine, source edition or algorithm changes and no installation performed.')
(B/'LINUX-HOST-RETRY-REASON.json').write_text(json.dumps(reason,indent=2)+'\n',encoding='utf-8')
s=(R/'build/qualify_gsea_file_hosts_20261120.py').read_text().replace("O=B/'file-hosts-qualification-1'","O=B/'file-hosts-qualification-2'").replace('JLinAlg-Omics-SAIGE-20261026','JLinAlg-Omics-PyMOL-20261026')
s=s.replace("pool.map(task,['windows-java21','windows-java25','linux-java21'])","pool.map(task,['linux-java21'])")
s=s.replace("status='PASS_NATIVE_GSEA_FILE_WORKFLOW_ORIGINAL_COMPARISONS_THREE_JVMS'","status='PASS_NATIVE_GSEA_FILE_WORKFLOW_ORIGINAL_COMPARISONS_LINUX_RETRY'")
exec(compile(s,str(Path(__file__)),'exec'))
