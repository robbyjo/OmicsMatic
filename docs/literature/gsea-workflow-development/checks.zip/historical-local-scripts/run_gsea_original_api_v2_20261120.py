from pathlib import Path
import hashlib,json,subprocess,traceback,xml.etree.ElementTree as ET
R=Path('D:/projects/JLinAlg');H=R/'build/gs-2';B=H/'build/gsea-high-impact-2';O=B/'original-api-4.4.0-2';O.mkdir(exist_ok=False)
F=R/'build/gs-1/build/gsea-high-impact-1/runtime-source-4.4.0-1';J=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin')
I=B/'original-workflow-forms-4.4.0-2/inputs';source=H/'tools/literature/gsea_original/OriginalGseaProbe.java'
def save(p,v):p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
def pin(p):
    with p.open('rb') as f:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
try:
    classes=O/'classes';classes.mkdir();cp=str(F/'modules/*')
    command=[str(J/'javac.exe'),'--release','17','-cp',cp,'-d',str(classes),str(source)]
    p=subprocess.run(command,capture_output=True,stdin=subprocess.DEVNULL);(O/'javac.stdout').write_bytes(p.stdout);(O/'javac.stderr').write_bytes(p.stderr)
    save(O/'COMPILE.json',dict(command=command,exit_code=p.returncode,source=pin(source)));assert p.returncode==0,'Inspect javac.stderr'
    results=[]
    for mode in ['preranked','expression-phenotype','expression-geneset']:
        folder=O/mode;folder.mkdir();home=folder/'home';home.mkdir();cwd=folder/'worker';cwd.mkdir()
        output=folder/'original.tsv'
        command=[str(J/'java.exe'),'-Xmx1g','-Djava.awt.headless=true','-Duser.home='+str(home),'-DMAKE_GSEA_UPDATE_CHECK=false',
            '-Djava.util.logging.config.file='+str(F/'logging.properties'),'-Dprobe.output='+str(output),'-cp',cp+';'+str(classes),
            'OriginalGseaProbe',mode,str(I/('ranks.rnk' if mode=='preranked' else 'expression.gct')),str(I/'groups.cls')+'#A_versus_B',
            str(I/'sets.gmt'),'10000','12345','15','100']
        save(folder/'COMMAND.json',dict(command=command,cwd=str(cwd),full_precision=True,independent_of_project_arithmetic=True))
        with (folder/'stdout').open('xb') as stdout,(folder/'stderr').open('xb') as stderr:
            p=subprocess.Popen(command,cwd=cwd,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr);save(folder/'PROCESS.json',dict(pid=p.pid))
            code=p.wait(timeout=240)
        save(folder/'PROCESS-EXIT.json',dict(exit_code=code));print('Original full-precision API',mode,'exit',code,flush=True)
        if code!=0:results.append(dict(mode=mode,exit_code=code));continue
        lines=[line.split('\t') for line in output.read_text().splitlines()]
        scores={row[1]:row[2:] for row in lines if row[0]=='SCORE'}
        edb=next((B/'original-workflow-forms-4.4.0-2'/mode/'reports').rglob('results.edb'));root=ET.fromstring(edb.read_bytes())
        comparisons=[]
        for row in root.findall('DTG'):
            name=row.get('GENESET').split('#')[-1];values=scores[name]
            for i,field in enumerate(['ES','NES','NP','FDR','FWER']):
                actual=float(values[i]);formatted=float(row.get(field));assert abs(actual-formatted)<=0.0000501,(mode,name,field,actual,formatted)
                comparisons.append(dict(set=name,field=field,original_full_float=values[i],original_cli_formatted=row.get(field)))
        save(folder/'CLI-COMPARISONS.json',dict(status='PASS_ORIGINAL_API_TO_ORIGINAL_CLI_AT_SOURCE_FOUR_DECIMAL_EXPORT_PRECISION',
            comparisons=comparisons,not_a_project_arithmetic_validation=True))
        results.append(dict(mode=mode,exit_code=0,sets=len(scores),comparisons=len(comparisons),output=pin(output)))
    save(O/'COMPLETED.json',dict(status='OBSERVED_ORIGINAL_FULL_PRECISION_API_AND_CLI_COUNTERPARTS',results=results,source=pin(source),project_arithmetic_tested=False))
except Exception as error:
    save(O/'FAILURE.json',dict(error=repr(error),detail=traceback.format_exc()));raise
