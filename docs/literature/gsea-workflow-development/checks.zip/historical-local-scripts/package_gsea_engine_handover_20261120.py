from pathlib import Path
import hashlib,importlib.util,json,subprocess,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/gs-3';B=T/'build/gsea-high-impact-3';Q=T/'docs/literature/gsea-engine-development'
O=B/'public-engine-proof-1';O.mkdir(exist_ok=False)
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def enc(v):return (json.dumps(v,indent=2)+'\n').encode()
files={}
def add(n,p):assert n not in files;files[n]=Path(p).read_bytes()
def archive(path,payloads):
    with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for n,b in sorted(payloads.items()):
            i=zipfile.ZipInfo(n,(2026,11,20,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16;z.writestr(i,b)
pack=B/'packaged-engine-qualification-1';gradle=B/'native-gradle-1'
complete=json.loads((pack/'COMPLETED.json').read_bytes());assert complete['status']=='PASS_PACKAGED_NATIVE_GSEA_ENGINE_THREE_JVMS'
for n in ['PRODUCER.json','COMPLETED.json','javac.stdout','javac.stderr']:add('packaged/'+n,pack/n)
for host in ['windows-java21','windows-java25','linux-java21']:
    for n in ['version.stdout','version.stderr']:add('packaged/'+host+'/'+n,pack/host/n)
    for form in ['sweep','complete-nulls']:
        for n in ['PROCESS.json','stdout','stderr']:add('packaged/'+host+'/'+form+'/'+n,pack/host/form/n)
for n in ['COMMAND.json','PROCESS-EXIT.json','stdout','stderr','isolate.gradle']:add('gradle/'+n,gradle/n)
for n in ['BroadGseaEngineTest','BroadGseaStatisticsTest']:add('gradle/'+n+'.xml',gradle/'project-build/test-results/test'/('TEST-org.jlinalg.enrichment.'+n+'.xml'))
for attempt in [1,2]:
    for v in ['4.4.0','4.3.2','4.3.3']:
        folder=B/('original-engine-sweep-'+str(attempt))/v
        for n in ['COMMAND.json','COMPILE.json','COMPLETED.json','PROCESS-EXIT.json','OriginalEngineProbe.java','stdout','stderr','javac.stdout','javac.stderr']:add('original-sweep-'+str(attempt)+'/'+v+'/'+n,folder/n)
        add('original-sweep-'+str(attempt)+'/'+v+'/COUNTS.tsv',folder/'cases/COUNTS.tsv')
    folder=B/('native-engine-sweep-'+str(attempt))
    for n in ['BroadGseaEngine.java','BroadGseaStatistics.java','CheckEngineSweep.java','PROCESS.json','stdout','stderr','javac.stdout','javac.stderr']:add('native-sweep-'+str(attempt)+'/'+n,folder/n)
for n in ['BroadGseaEngine.java','BroadGseaStatistics.java','CheckNativeEngine.java','PROCESS.json','stdout','stderr','javac.stdout','javac.stderr']:add('initial-native/'+n,B/'native-engine-initial-1'/n)
names=['start_gsea_engine_20261120.py','check_gsea_native_engine_initial_20261120.py','reference_gsea_engine_sweep_20261120.py','reference_gsea_engine_sweep_v2_20261120.py','check_gsea_engine_sweep_20261120.py','check_gsea_engine_sweep_v2_20261120.py','prepare_gsea_engine_handover_20261120.py','build_gsea_engine_handover_20261120.py','qualify_gsea_engine_handover_20261120.py']
for n in names:add('historical-local-scripts/'+n,R/'build'/n)
pub=R/'build/git-publish/20261120-gsea-handover-63'
assert (pub/'READBACKS-COMPLETED.json').exists()
for n in ['historical-overlays.stdout','historical-overlays.stderr','historical-overlays.PROCESS.json','saved-native.stdout','saved-native.stderr','saved-native.PROCESS.json','SAVED-NATIVE-RETRY-REASON.json','saved-native-2.stdout','saved-native-2.stderr','saved-native-2.PROCESS.json','catalog.stdout','catalog.stderr','catalog.PROCESS.json','READBACKS-COMPLETED.json']:add('publication-readbacks/'+n,pub/n)
archive(Q/'checks.zip',files)
source_names=['src/main/java/org/jlinalg/enrichment/BroadGseaEngine.java','src/main/java/org/jlinalg/enrichment/BroadGseaStatistics.java','src/main/resources/META-INF/licenses/GSEA-DESKTOP-LICENSE.txt','src/test/java/org/jlinalg/enrichment/BroadGseaEngineTest.java','tools/literature/verify_broad_gsea_engine_checkpoint.py','tools/literature/gsea_engine/README.md','docs/literature/gsea-engine-development/README.md']
source_names += [p.relative_to(T).as_posix() for p in sorted((T/'tools/literature/gsea_engine').glob('*.java'))]
archives={}
for p in [Q/'checks.zip',Q/'complete-null-references.zip',T/'src/test/resources/org/jlinalg/enrichment/broad-gsea-engine-originals.zip']:
    with zipfile.ZipFile(p) as z:
        assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))
        archives[p.relative_to(T).as_posix()]=dict(archive=pin(p.read_bytes()),files={n:pin(z.read(n)) for n in z.namelist()})
qualification=dict(schema_version=1,status=complete['status'],sources={n:pin((T/n).read_bytes()) for n in source_names},archives=archives,producer=complete['producer'],exact_fields_per_JVM=668739,strict_refusals_per_JVM=201,project_RUN_VERIFY_REPLAY_qualified=False,new_catalog_credit=0,private_transfer_required=True)
(Q/'QUALIFICATION.json').write_bytes(enc(qualification))
command=[str(Path('C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')),'-B',str(T/'tools/literature/verify_broad_gsea_engine_checkpoint.py')]
p=subprocess.run(command,cwd=T,capture_output=True);(O/'stdout').write_bytes(p.stdout);(O/'stderr').write_bytes(p.stderr);assert p.returncode==0
(O/'COMPLETED.json').write_bytes(enc(dict(status='PASS_PUBLIC_ENGINE_PROOF_PACKAGED_AND_READ_BACK',producer=complete['producer'],qualification=pin((Q/'QUALIFICATION.json').read_bytes()),archives={n:v['archive'] for n,v in archives.items()})))
print(p.stdout.decode(),flush=True)
