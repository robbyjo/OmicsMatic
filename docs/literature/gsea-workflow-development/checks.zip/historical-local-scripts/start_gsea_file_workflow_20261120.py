from pathlib import Path
R=Path('D:/projects/JLinAlg')
s=(R/'build/start_gsea_engine_20261120.py').read_text()
s=s.replace("H=R/'build/gs-2';T=R/'build/gs-3';P=R/'build/git-publish/20261120-gsea-native-62'", "H=R/'build/gs-3';T=R/'build/gs-4';P=R/'build/git-publish/20261120-gsea-handover-63'")
s=s.replace('gsea-engine-start-20261120-1','gsea-file-start-20261120-1').replace('7f4cc3185a642c61c7ab42b8b84a2630fac1fec7','7b6ed9d96d9d52bc0b141811dc741bed874616ba')
s=s.replace('len(previous)==30','len(previous)==31').replace('codex/gsea-engine-20261120','codex/gsea-files-20261120').replace('build/gsea-high-impact-3','build/gsea-high-impact-4').replace('worktrees=31','worktrees=32').replace('all30','all31')
exec(compile(s,str(Path(__file__)),'exec'))
