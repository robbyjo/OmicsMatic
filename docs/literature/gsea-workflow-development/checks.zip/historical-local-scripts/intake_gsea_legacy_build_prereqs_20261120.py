from pathlib import Path,PurePosixPath
import concurrent.futures,hashlib,json,re,stat,traceback,urllib.request,zipfile
R=Path('D:/projects/JLinAlg');B=R/'build/gs-2/build/gsea-high-impact-2';O=B/'legacy-build-prereqs-1';O.mkdir(exist_ok=False)
def enc(v):return (json.dumps(v,indent=2)+'\n').encode()
def pin(p):
    with p.open('rb') as f:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
def get(url,path,limit):
    request=urllib.request.Request(url,headers={'User-Agent':'OmicsMatic-original-GSEA-private-build-intake'})
    with urllib.request.urlopen(request,timeout=90) as response,path.open('xb') as stream:
        size=0
        while chunk:=response.read(1024*1024):
            size+=len(chunk);assert size<=limit,'Download capacity exceeded';stream.write(chunk)
        headers=dict(response.headers);final_url=response.url
    return dict(requested_url=url,final_url=final_url,headers=headers,content=pin(path))
def extract(archive,folder):
    folder.mkdir();files={}
    with zipfile.ZipFile(archive) as z:
        infos=z.infolist();assert len(infos)==len({i.filename for i in infos}) and len(infos)<50000
        assert sum(i.file_size for i in infos)<1500000000
        for i in infos:
            p=PurePosixPath(i.filename)
            assert not p.is_absolute() and '\\' not in i.filename and ':' not in i.filename and all(n not in ['.','..'] for n in p.parts)
            assert not stat.S_ISLNK(i.external_attr>>16)
            if i.is_dir():continue
            target=folder/p.as_posix();target.parent.mkdir(parents=True,exist_ok=True);raw=z.read(i);target.write_bytes(raw)
            files[p.as_posix()]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
    return files
def task(kind):
    folder=O/kind;folder.mkdir()
    if kind=='gradle-4.10.2':
        url='https://services.gradle.org/distributions/gradle-4.10.2-bin.zip'
        checksum=get(url+'.sha256',folder/'official.sha256',10000)
        expected=(folder/'official.sha256').read_text().strip();assert re.fullmatch('[0-9a-f]{64}',expected)
    else:
        url='https://api.adoptium.net/v3/assets/latest/8/hotspot?architecture=x64&image_type=jdk&os=windows&vendor=eclipse'
        metadata=get(url,folder/'official-api.json',5000000);rows=json.loads((folder/'official-api.json').read_bytes());assert len(rows)==1
        package=rows[0]['binary']['package'];url=package['link'];expected=package['checksum'];assert re.fullmatch('[0-9a-f]{64}',expected)
        checksum=get(package['checksum_link'],folder/'official.sha256',10000)
        assert (folder/'official.sha256').read_text().split()[0]==expected
    downloaded=get(url,folder/'original.zip',300000000);assert downloaded['content']['sha256']==expected
    files=extract(folder/'original.zip',folder/'extracted')
    record=dict(status='PASS_EXACT_OFFICIAL_PRIVATE_BUILD_PREREQUISITE_INTAKE',kind=kind,download=downloaded,
        official_checksum=checksum,expected_sha256=expected,files=files,system_install=False,global_environment_changed=False)
    (folder/'COMPLETED.json').write_bytes(enc(record));print('PASS private prerequisite',kind,downloaded['content'],flush=True)
    return kind,dict(archive=downloaded['content'],files=len(files),root=str(folder/'extracted'))
try:
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=dict(pool.map(task,['gradle-4.10.2','jdk8-windows']))
    (O/'COMPLETED.json').write_bytes(enc(dict(status='PASS_TWO_OFFICIAL_GSEA_LEGACY_BUILD_PREREQUISITES',results=results)))
except Exception as error:
    (O/'FAILURE.json').write_bytes(enc(dict(error=repr(error),detail=traceback.format_exc())));raise
