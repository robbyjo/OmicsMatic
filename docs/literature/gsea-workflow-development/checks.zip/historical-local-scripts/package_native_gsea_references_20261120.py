from pathlib import Path
import hashlib,json,shutil,zipfile
R=Path('D:/projects/JLinAlg');H=R/'build/gs-2';B=H/'build/gsea-high-impact-2';O=B/'native-reference-packet-1';O.mkdir(exist_ok=False)
def enc(v):return (json.dumps(v,indent=2)+'\n').encode()
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
files={};profiles={}
for version in ['4.4.0','4.3.2','4.3.3']:
    if version=='4.4.0':
        folders={mode:B/'original-api-4.4.0-3'/mode for mode in ['preranked','expression-phenotype','expression-geneset']}
        primitives=B/'original-primitives-1/original-primitives.tsv'
        original_profile=R/'build/gs-1/build/gsea-high-impact-1/runtime-source-4.4.0-1/PROFILE.json'
        profile=json.loads(original_profile.read_bytes());runtime=original_profile.parent
        producer=R/'build/gs-1/build/gsea-high-impact-1/original-build-4.4.0-1/PRODUCER.json'
    else:
        root=B/'original-4.3-profiles-1'/version
        folders={mode:root/('api-'+mode) for mode in ['preranked','expression-phenotype','expression-geneset']}
        primitives=root/'primitives/original-primitives.tsv';profile=json.loads((root/'PROFILE.json').read_bytes());runtime=root/'runtime'
        producer=B/'original-build-4.3-source-1'/version/'PRODUCER.json'
    for name,w in profile['files'].items():assert pin((runtime/name).read_bytes())==w,(version,name)
    profiles[version]=dict(profile=profile,producer=json.loads(producer.read_bytes()),
        original_source_build=True,vendor_distribution=False,original_runtime='Windows JDK21',
        workflow_forms=3,permutations_each=10000,project_workflow_qualified=False)
    for mode,folder in folders.items():
        assert json.loads((folder/'PROCESS-EXIT.json').read_bytes())['exit_code']==0
        files[version+'/'+mode+'.tsv']=(folder/'original.tsv').read_bytes()
        files['provenance/'+version+'/'+mode+'-PROCESS.json']=(folder/'COMMAND.json').read_bytes()
        files['provenance/'+version+'/'+mode+'-CLI-COMPARISONS.json']=(folder/'CLI-COMPARISONS.json').read_bytes()
    files[version+'/primitives.tsv']=primitives.read_bytes()
for name in ['OriginalGseaProbe.java','OriginalPrimitiveProbe.java']:
    files['reference-source/'+name]=(H/'tools/literature/gsea_original'/name).read_bytes()
files['PROFILES.json']=enc(profiles)
files['SCOPE.json']=enc(dict(status='ORIGINAL_SOURCE_COUNTERPART_INPUTS_FOR_NATIVE_ARITHMETIC_QUALIFICATION',
    editions=['4.3.2','4.3.3','4.4.0'],source_tag_aliases_43_share_commit=True,synthetic_only=True,
    source_walk_cases_per_edition=1280,source_family_cases_per_edition=240,
    workflow_forms_per_edition=3,permutations_per_workflow=10000,
    complete_original_CLI_API_comparisons=225,EDB_export_rounds_to_four_decimals=True,full_float_exports_included=True,
    field_count_is_not_an_analysis_or_paper_count=True,new_catalog_credit=0,project_adapter_qualified=False))
manifest=''.join(pin(raw)['sha256']+'  '+name+'\n' for name,raw in sorted(files.items()))
files['SHA256SUMS']=manifest.encode()
target=H/'src/test/resources/org/jlinalg/enrichment/broad-gsea-originals.zip';target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists()
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,raw in sorted(files.items()):
        info=zipfile.ZipInfo(name,date_time=(2026,11,20,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
        z.writestr(info,raw)
with zipfile.ZipFile(target) as z:
    assert set(z.namelist())==set(files) and z.testzip() is None
    for name,raw in files.items():assert z.read(name)==raw,name
(O/'COMPLETED.json').write_bytes(enc(dict(status='PASS_ORIGINAL_REFERENCE_PACKET_AND_RUNTIME_IDENTITIES',fixture=pin(target.read_bytes()),
    decoded_files=len(files),files={name:pin(raw) for name,raw in files.items()},profile_editions=list(profiles))))
print('PASS original reference packet',pin(target.read_bytes()),'decoded files',len(files),flush=True)
