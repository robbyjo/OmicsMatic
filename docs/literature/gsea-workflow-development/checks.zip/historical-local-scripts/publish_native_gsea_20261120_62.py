from pathlib import Path
import concurrent.futures, datetime, hashlib, importlib.util, json, os, subprocess, time, traceback, urllib.error, urllib.request

R=Path('D:/projects/JLinAlg');G=R/'build/gs-2';O=R/'build/git-publish/20261120-gsea-native-62'
P=R/'build/git-publish/20261120-gsea-handover-61'
def git(*args):return subprocess.check_output(['git','--no-replace-objects',*args],cwd=G)
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(name,value):
    with (O/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
def fetch(url):
    for attempt in range(3):
        try:
            request=urllib.request.Request(url,headers={'User-Agent':'OmicsMatic-GSEA-handover-publication-verifier',
                'Accept':'application/vnd.github+json' if 'api.github.com' in url else 'application/octet-stream'})
            with urllib.request.urlopen(request,timeout=45) as response:return response.read()
        except urllib.error.HTTPError:raise
        except Exception:
            if attempt==2:raise
            time.sleep(2)
def artifacts(stats,label):
    for index,(name,wanted) in enumerate(stats.items(),1):
        st=Path(name).stat();assert dict(bytes=st.st_size,mtime_ns=st.st_mtime_ns)==wanted,name
        if index%100000==0:print(label,index,'/',len(stats),flush=True)
try:
    assert not (O/'PUSH-STARTED.json').exists(),'Inspect existing push receipts; do not start another push.'
    commit=json.loads((O/'COMMITTED.json').read_bytes());head,base=commit['head'],commit['base']
    assert base=='7a50e4a18d27e0bccd82d70b9a5632062abb3fc3'
    assert git('rev-parse','HEAD').decode().strip()==head and not git('status','--porcelain=v1','-z','--untracked-files=all')
    assert git('rev-list','--count',base+'..'+head).strip()==b'1'
    assert set(git('diff','--name-only',base,head).decode().splitlines())==set(commit['files'])
    assert set(git('diff','--name-only','--diff-filter=M',base,head).decode().splitlines())=={'.gitattributes','docs/literature/HANDOVER_CURRENT.md'}
    assert not git('diff','--name-only',base,head,'--','site','.github')
    for name,wanted in commit['files'].items():assert pin((G/name).read_bytes())==pin(git('show',head+':'+name))==wanted,name
    canonical=json.loads((O/'CANONICAL-AFTER.json').read_bytes())
    assert canonical==json.loads((O/'CANONICAL-BEFORE.json').read_bytes()) and len(canonical)==15
    for name,wanted in canonical.items():assert pin((G/name).read_bytes())==wanted,name
    trees=json.loads((O/'WORKTREES-EXPECTED.json').read_bytes());assert len(trees)==30
    spec=importlib.util.spec_from_file_location('inventory',O.parent/'20261115-all-main-3/inventory.py');inv=importlib.util.module_from_spec(spec);spec.loader.exec_module(inv)
    for row in trees:
        assert inv.snapshot(Path(row['root']))==row,row['root']
        git('merge-base','--is-ancestor',row['head'],head)
    stats=json.loads((O/'PROTECTED-STAT-BEFORE.json').read_bytes());scope=json.loads((O/'INHERITED-PRESERVATION-SCOPE.json').read_bytes())
    assert len(stats)==commit['protected_artifacts']==scope['inherited_artifacts']+scope['new_artifacts_SHA256_pinned']
    assert scope['inherited_artifacts']==345727
    artifacts(stats,'Pre-push artifact size/mtime checks')
    assert git('ls-remote','origin','refs/heads/main').decode().split()[0]==base,'Remote main advanced; integrate safely without force.'
    command=['git','push','origin','HEAD:refs/heads/main']
    save('PUSH-STARTED.json',dict(head=head,base=base,command=command,started=datetime.datetime.now(datetime.timezone.utc).isoformat()))
    with (O/'push.stdout').open('xb') as stdout,(O/'push.stderr').open('xb') as stderr:
        process=subprocess.run(command,cwd=G,env=dict(os.environ,GIT_TERMINAL_PROMPT='0',GCM_INTERACTIVE='Never'),
            stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=300)
    save('push.PROCESS.json',dict(exit_code=process.returncode));print((O/'push.stderr').read_text(errors='replace')[-1500:],flush=True)
    assert process.returncode==0,'Inspect saved push logs.'
    assert git('ls-remote','origin','refs/heads/main').decode().split()[0]==head
    save('PUSHED.json',dict(status='PUSHED_NATIVE_BROAD_GSEA_ARITHMETIC_TO_MAIN',head=head,no_force_push=True))
    print('GitHub main push verified:',head,flush=True)
    for row in trees:assert inv.snapshot(Path(row['root']))==row,row['root']
    artifacts(stats,'Post-push artifact size/mtime checks')
    for name,wanted in canonical.items():assert pin((G/name).read_bytes())==wanted,name
    save('POST-PUSH-PRESERVATION.json',dict(status='PASS_30_WORKTREES_AND_PROTECTED_ARTIFACTS',worktrees=30,
        protected_artifacts=len(stats),inherited_artifacts=345727,inherited_SHA256_evidence_retained=True,
        inherited_size_mtime_unchanged=True,full_inherited_hash_pass_repeated=False,
        new_artifacts_SHA256_pinned=scope['new_artifacts_SHA256_pinned'],canonical_files_unchanged=15,active_worktree_clean=True))
    api='https://api.github.com/repos/robbyjo/OmicsMatic/'
    remote=json.loads(fetch(api+'git/ref/heads/main?gsea-handover='+head));assert remote['object']['sha']==head
    def public_file(name):
        raw=fetch('https://raw.githubusercontent.com/robbyjo/OmicsMatic/'+head+'/'+name)
        assert pin(raw)==commit['files'][name] and raw==git('show',head+':'+name),name
        return name,pin(raw)
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:public=dict(pool.map(public_file,commit['files']))
    save('PUBLIC-FILES.json',public);print('Exact public files verified:',len(public),flush=True)
    flows=json.loads(fetch(api+'actions/runs?head_sha='+head));checks=json.loads(fetch(api+'commits/'+head+'/check-runs'))
    save('PUBLIC-WORKFLOWS-OBSERVED.json',flows);save('PUBLIC-CHECK-RUNS-OBSERVED.json',checks)
    for attempt in range(120):
        active=any(r['status']!='completed' for r in flows['workflow_runs']) or any(r['status']!='completed' for r in checks['check_runs'])
        if not active:break
        if attempt%6==0:print('Waiting for observed hosted checks',flush=True)
        time.sleep(5)
        flows=json.loads(fetch(api+'actions/runs?head_sha='+head));checks=json.loads(fetch(api+'commits/'+head+'/check-runs'))
    save('PUBLIC-WORKFLOWS-FINAL.json',flows);save('PUBLIC-CHECK-RUNS-FINAL.json',checks)
    assert all(r['status']=='completed' and r['conclusion'] in ['success','neutral','skipped'] for r in flows['workflow_runs'])
    assert all(r['status']=='completed' and r['conclusion'] in ['success','neutral','skipped'] for r in checks['check_runs'])
    previous=json.loads((P/'PUBLISHED.json').read_bytes());assert previous['head']==base and previous['site_changed'] is False
    actual_deployment=R/'build/git-publish/20261120-edger-admission-60/PUBLISHED.json'
    assert json.loads(actual_deployment.read_bytes())['pages_deployment_successful']
    home='https://robbyjo.github.io/OmicsMatic/'
    raw=fetch(home+'?gsea-handover='+head);assert raw==git('show',head+':site/index.html')
    live=[dict(url=home,status=200,exact_unchanged_source=True,content=pin(raw))]
    for name in ['literature-review.html','literature-warnings.html']:
        try:
            fetch(home+name+'?gsea-handover='+head)
            raise AssertionError('Withheld report is public: '+name)
        except urllib.error.HTTPError as error:
            assert error.code==404;live.append(dict(url=home+name,status=404,withheld=True))
    save('LIVE-PAGES.json',dict(site_changed=False,no_new_deployment_claimed=True,
        preceding_actual_deployment_receipt=pin(actual_deployment.read_bytes()),pages=live))
    assert git('ls-remote','origin','refs/heads/main').decode().split()[0]==head
    receipt=dict(status='PASS_PUBLIC_GITHUB_MAIN_NATIVE_BROAD_GSEA_ARITHMETIC',head=head,base=base,remote_main_verified=head,
        no_force_push=True,exact_public_files_verified=public,worktrees_preserved=30,protected_artifacts_preserved=len(stats),
        inherited_artifacts=345727,new_artifacts_SHA256_pinned=scope['new_artifacts_SHA256_pinned'],
        inherited_protection_scope='Prior SHA256 evidence retained; inherited size/mtime unchanged; new artifacts SHA256 pinned',
        active_worktree_clean=True,canonical_files_unchanged=15,manifest_entries=823,source_papers=250,
        observations=2705,reviewed_uses=1520,pending_uses=1185,integrations=139,native=25,upstream=114,
        fresh_saved_native_and_cumulative_catalog_readbacks=True,original_R_refits=False,
        GSEA_original_source_build_passed=True,native_Broad_GSEA_arithmetic_qualified=True,exact_field_checks_per_JVM=356286,source_bound_refusals_per_JVM=1701,JVMs=3,unchanged_predecessor_JAR_payloads=23485,original_source_profiles=3,original_workflow_forms=9,permutations_per_form=10000,GSEA_project_file_workflow_qualified=False,new_catalog_credit=0,
        site_changed=False,no_new_Pages_deployment_claimed=True,literature_pages_withheld=True,
        hosted_workflows_observed=flows['total_count'],hosted_checks_observed=checks['total_count'],private_transfer_required=True,
        released=False,whole_goal_complete=False,commit_url='https://github.com/robbyjo/OmicsMatic/commit/'+head)
    save('PUBLISHED.json',receipt)
    print(json.dumps(dict(status=receipt['status'],head=head,public_files=len(public),worktrees=30,
        protected_artifacts=len(stats),private_transfer_required=True,whole_goal_complete=False)),flush=True)
except Exception as error:
    save('PUBLICATION-FAILURE.json',dict(error=repr(error),detail=traceback.format_exc()));raise
