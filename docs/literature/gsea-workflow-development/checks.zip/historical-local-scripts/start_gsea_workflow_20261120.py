from pathlib import Path
import importlib.util,json,subprocess
R=Path('D:/projects/JLinAlg');G=R/'build/gs-1';H=R/'build/gs-2'
P=R/'build/git-publish/20261120-gsea-handover-61';O=R/'build/gsea-workflow-start-20261120-1'
BASE='7a50e4a18d27e0bccd82d70b9a5632062abb3fc3';O.mkdir(exist_ok=False)
def git(root,*a):return subprocess.check_output(['git','--no-replace-objects',*a],cwd=root)
def save(n,v):(O/n).write_bytes((json.dumps(v,indent=2)+'\n').encode())
assert git(G,'rev-parse','HEAD').decode().strip()==BASE
assert git(G,'ls-remote','origin','refs/heads/main').decode().split()[0]==BASE
prior=json.loads((P/'WORKTREES-EXPECTED.json').read_bytes());assert len(prior)==29
spec=importlib.util.spec_from_file_location('inv',P.parent/'20261115-all-main-3/inventory.py');inv=importlib.util.module_from_spec(spec);spec.loader.exec_module(inv)
for row in prior:assert inv.snapshot(Path(row['root']))==row,row['root']
save('WORKTREES-BEFORE.json',prior);assert not H.exists()
p=subprocess.run(['git','worktree','add','-b','codex/gsea-workflows-20261120',str(H),BASE],cwd=R,capture_output=True)
(O/'worktree.stdout').write_bytes(p.stdout);(O/'worktree.stderr').write_bytes(p.stderr);assert p.returncode==0
assert git(H,'rev-parse','HEAD').decode().strip()==BASE and not git(H,'status','--porcelain=v1','-z','--untracked-files=all')
(H/'build/gsea-high-impact-2').mkdir(parents=True)
save('COMPLETED.json',dict(status='PASS_EXACT_HANDOVER_AND_NEW_GSEA_WORKFLOW_WORKTREE',base=BASE,worktrees=30,root=str(H)))
print('PASS all29 prior worktrees exact, new GSEA workflow checkout',H,flush=True)
