from pathlib import Path
import hashlib,json
R=Path('D:/projects/JLinAlg');P=R/'build/git-publish/20261120-gsea-handover-63';O=R/'build/git-publish/20261120-gsea-files-64';A=O/'artifact-transition-1';A.mkdir(exist_ok=False)
def save(n,v):
    with (A/n).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def statpin(p):
    s=p.stat();return dict(bytes=s.st_size,mtime_ns=s.st_mtime_ns)
def pin(p):
    with p.open('rb') as f:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
assert json.loads((O/'EXTERNAL-CLEANUP-TRANSITION.json').read_bytes())['status']=='PASS_EXACT_COMPLETED_CLEANUP_AND_RECOVERY_PAYLOADS'
old=json.loads((P/'PROTECTED-ARTIFACTS.json').read_bytes());stats=json.loads((P/'PROTECTED-STAT-BEFORE.json').read_bytes());assert set(old)==set(stats) and len(old)==401823
caches=json.loads((O/'external-cleanup/CACHE-REMOVALS.json').read_bytes());retired_roots=json.loads((O/'external-cleanup/WORKTREE-RETIREMENTS.json').read_bytes())
live={};live_stats={};retired={};mtime={};unresolved={}
for i,(name,wanted) in enumerate(old.items(),1):
    path=Path(name)
    cache=next((c for c in caches if path.is_relative_to(Path(c['path']))),None)
    tree=next((c for c in retired_roots if path.is_relative_to(Path(c['path']))),None)
    if not path.exists():
        if cache:retired[name]=dict(prior=wanted,prior_stat=stats[name],kind='explicit_removed_rebuildable_cache',cleanup_target=cache['path'],category=cache['category'])
        elif tree and path.relative_to(Path(tree['path'])).parts[0] not in tree['preserved']:
            retired[name]=dict(prior=wanted,prior_stat=stats[name],kind='retired_checkout_source_or_metadata',cleanup_target=tree['path'],head=tree['head'],recovery_archive=tree['archive'])
        else:unresolved[name]=dict(kind='MISSING_OUTSIDE_EXPLICIT_CLEANUP_TARGETS',prior=wanted)
    else:
        observed=statpin(path)
        if observed==stats[name]:live[name]=wanted;live_stats[name]=observed
        else:
            actual=pin(path)
            if actual==wanted:
                live[name]=wanted;live_stats[name]=observed;mtime[name]=dict(prior=stats[name],observed=observed,sha256_reverified=actual)
            else:unresolved[name]=dict(kind='CHANGED_INHERITED_BYTES',prior=wanted,observed=actual,observed_stat=observed)
    if i%50000==0:print('Inherited artifact cleanup audit:',i,'/',len(old),'retired',len(retired),'unresolved',len(unresolved),flush=True)
save('LIVE-PROTECTED.json',live);save('LIVE-STAT.json',live_stats);save('RETIRED-ARTIFACTS.json',retired);save('MTIME-ONLY-REHASHED.json',mtime);save('UNRESOLVED.json',unresolved)
summary=dict(status='PASS_EXPLICIT_CLEANUP_ARTIFACT_TRANSITION' if not unresolved else 'FAIL_UNEXPLAINED_INHERITED_ARTIFACT_CHANGE',prior_artifacts=len(old),live_inherited_artifacts=len(live),explicitly_retired_artifacts=len(retired),mtime_only_rehashed=len(mtime),unresolved=len(unresolved),old_SHA256_manifests_preserved=True,full_inherited_rehash_repeated=False,live_size_mtime_checked=True,all_retirements_under_exact_completed_cleanup_targets=not unresolved)
save('COMPLETED.json',summary);print(json.dumps(summary),flush=True);assert not unresolved,'Inspect UNRESOLVED.json; do not refresh hashes or remove evidence.'
