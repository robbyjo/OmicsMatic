from pathlib import Path
import hashlib,json,zipfile
R=Path('D:/projects/JLinAlg');H=R/'build/gs-2';B=H/'build/gsea-high-impact-2';Q=H/'docs/literature/gsea-native-development';P=B/'native-reader-controls-1'
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
result=json.loads((P/'COMPLETED.json').read_bytes())
files={'SOURCE.py':(R/'build/check_native_gsea_reader_20261120.py').read_bytes(),'COMPLETED.json':(P/'COMPLETED.json').read_bytes()}
for host in ['windows','linux']:
    records=result['results'][host];assert len(records)==7 and all(r['exit_code']==r['expected'] for r in records)
    for row in records:
        for name in ['PROCESS.json','stdout','stderr']:
            files[host+'/'+row['case']+'/'+name]=(P/host/row['case']/name).read_bytes()
archive=Q/'reader-controls.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for name,raw in sorted(files.items()):z.writestr(name,raw)
record=dict(status='PASS_SAVED_NATIVE_READER_AND_SIX_REFUSALS_ON_TWO_HOSTS',hosts=2,pass_cases=2,refusals=12,
    controls=result,archive=pin(archive.read_bytes()),files={n:pin(v) for n,v in sorted(files.items())},
    no_original_evidence_or_source_modified=True)
(Q/'READER-CONTROLS.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print('PASS saved both native readers and 12 refusals with source/logs',flush=True)
