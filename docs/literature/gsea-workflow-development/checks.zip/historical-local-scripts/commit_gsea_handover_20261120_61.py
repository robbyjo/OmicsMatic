from pathlib import Path
import hashlib, importlib.util, json, os, re, subprocess, sys, traceback, zipfile

R=Path('D:/projects/JLinAlg');G=R/'build/gs-1';K=R/'build/edg-3';B=G/'build/gsea-high-impact-1'
P=R/'build/git-publish/20261120-edger-admission-60';O=R/'build/git-publish/20261120-gsea-handover-61'
BASE='0de612c6182b87d42a1d574af5f06a99630a0924';Q=G/'docs/literature/gsea-handover-20261120'
O.mkdir(exist_ok=False);sys.dont_write_bytecode=True
def git(*args):return subprocess.check_output(['git','--no-replace-objects',*args],cwd=G)
def rawpin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def pin(p):
    with Path(p).open('rb') as f:return dict(bytes=Path(p).stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
def statpin(p):
    s=Path(p).stat();return dict(bytes=s.st_size,mtime_ns=s.st_mtime_ns)
def save(n,v):
    with (O/n).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
try:
    assert git('rev-parse','HEAD').decode().strip()==BASE
    assert git('remote','get-url','origin').decode().strip()=='https://github.com/robbyjo/OmicsMatic.git'
    assert git('ls-remote','origin','refs/heads/main').decode().split()[0]==BASE
    assert not git('diff','--cached','--name-only')
    assert not git('diff','--name-only','--','src','site','.github','tools')
    assert b'ignore_patterns("literature-review.html", "literature-warnings.html")' in (G/'.github/workflows/pages.yml').read_bytes()
    canonical=json.loads((P/'CANONICAL-AFTER.json').read_bytes());assert len(canonical)==15
    for name,wanted in canonical.items():assert pin(G/name)==wanted==rawpin(git('show',BASE+':'+name)),name
    save('CANONICAL-BEFORE.json',canonical);save('CANONICAL-AFTER.json',canonical)
    readback=json.loads((Q/'READBACK.json').read_bytes())
    assert readback['new_family_credit']==0 and readback['new_GSEA_reviews']==0 and not readback['GSEA_statistical_execution_qualified']
    catalog=json.loads((Q/'EDGER-CATALOG-READBACK.json').read_bytes())
    assert catalog['current_manifest']['entries']==823 and catalog['result']['integrations']==139
    save('CURRENT-VERIFICATION.json',catalog)
    # Confirm the portable reader's current recorded input population and default result.
    spec=importlib.util.spec_from_file_location('gsea_handover_reader',Q/'verify.py');reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
    result=reader.verify();assert result['packet_files']==32 and result['scientific_processes_executed']==0
    save('PACKET-READBACK.json',result)
    links=0
    for path in [G/'docs/literature/HANDOVER_2026-11-20_GSEA.md',G/'docs/literature/HANDOVER_CURRENT.md',Q/'README.md',Q/'SOURCE-NOTES.md']:
        for match in re.finditer(r'\]\(([^)]+)\)',path.read_text(encoding='utf-8')):
            target=match[1].split('#',1)[0]
            if target and '://' not in target:
                assert (path.parent/target).exists(),(str(path),target)
                links+=1
    save('DOCUMENT-LINKS-PASS.json',dict(status='PASS_ALL_RELATIVE_HANDOVER_LINKS',links=links))
    spec=importlib.util.spec_from_file_location('inventory',O.parent/'20261115-all-main-3/inventory.py');inv=importlib.util.module_from_spec(spec);spec.loader.exec_module(inv)
    previous=json.loads((P/'WORKTREES-EXPECTED.json').read_bytes());assert len(previous)==28
    roots={Path(b.splitlines()[0][9:]).resolve() for b in git('worktree','list','--porcelain').decode().strip().split('\n\n')}
    assert roots=={Path(row['root']).resolve() for row in previous}|{G.resolve()}
    for index,row in enumerate(previous,1):
        assert inv.snapshot(Path(row['root']))==row,'Prior worktree changed: '+row['root']
        git('merge-base','--is-ancestor',row['head'],BASE)
        if index%5==0:print('Prior worktrees exact:',index,'/28',flush=True)
    active=inv.snapshot(G);assert active['head']==BASE and active['branch']=='codex/gsea-high-impact-20261120'
    save('WORKTREES-BEFORE.json',previous+[active])
    protected=json.loads((P/'PROTECTED-ARTIFACTS.json').read_bytes());stats=json.loads((P/'PROTECTED-STAT-BEFORE.json').read_bytes())
    inherited=len(protected);assert inherited==len(stats)==342957 and set(protected)==set(stats)
    for index,(name,wanted) in enumerate(stats.items(),1):
        assert statpin(name)==wanted and wanted['bytes']==protected[name]['bytes'],name
        if index%50000==0:print('Inherited artifact size/mtime exact:',index,'/',inherited,flush=True)
    added=0
    parents=[B,R/'build/gsea-start-20261120-1',K/'build/gsea-handover-20261120-catalog-2']
    for parent in parents:
        assert parent.exists() and parent.resolve().is_relative_to(R.resolve()),str(parent)
        for directory,dirs,files in os.walk(parent,followlinks=False):
            dirs[:]=[n for n in dirs if not (Path(directory)/n).is_symlink() and not (Path(directory)/n).is_junction()]
            for name in files:
                path=Path(directory)/name
                if path.is_symlink() or str(path) in protected:continue
                protected[str(path)]=pin(path);stats[str(path)]=statpin(path);added+=1
    for path in sorted((R/'build').glob('*gsea*20261120*.py')):
        if str(path) in protected:continue
        protected[str(path)]=pin(path);stats[str(path)]=statpin(path);added+=1
    save('PROTECTED-ARTIFACTS.json',protected);save('PROTECTED-STAT-BEFORE.json',stats)
    save('INHERITED-PRESERVATION-SCOPE.json',dict(inherited_artifacts=inherited,inherited_source_receipt=pin(P/'PUBLISHED.json'),
        inherited_SHA256_manifest=pin(P/'PROTECTED-ARTIFACTS.json'),full_inherited_hash_pass_repeated=False,
        inherited_size_mtime_unchanged=True,new_artifacts_SHA256_pinned=added))
    print('New artifacts SHA256 pinned:',added,'total protected',len(protected),flush=True)
    allowed={'docs/literature/HANDOVER_CURRENT.md','docs/literature/HANDOVER_2026-11-20_GSEA.md'}
    allowed.update(p.relative_to(G).as_posix() for p in Q.rglob('*') if p.is_file())
    entries=[e for e in git('status','--porcelain=v1','-z','--untracked-files=all').split(b'\0') if e]
    assert all(e[:2] in [b' M',b'??'] for e in entries)
    actual={e[3:].decode() for e in entries};assert actual==allowed,dict(unexpected=sorted(actual-allowed),missing=sorted(allowed-actual))
    for name in sorted(allowed):
        assert git('hash-object','--no-filters','--',name)==git('hash-object','--path='+name,'--',name),'Git would normalize: '+name
    pins={name:pin(G/name) for name in sorted(allowed)};save('ALLOWED.json',pins)
    with zipfile.ZipFile(O/'PUBLIC-BEFORE-COMMIT.zip','x',compression=zipfile.ZIP_DEFLATED) as archive:
        for name in sorted(allowed):archive.writestr(name,(G/name).read_bytes())
    git('add','--',*sorted(allowed))
    assert set(git('diff','--cached','--name-only','-z').decode().strip('\0').split('\0'))==allowed
    for name,wanted in pins.items():assert rawpin(git('show',':'+name))==wanted,name
    p=subprocess.run(['git','diff','--cached','--check'],cwd=G,capture_output=True)
    (O/'DIFF-CHECK.stdout').write_bytes(p.stdout);(O/'DIFF-CHECK.stderr').write_bytes(p.stderr)
    assert p.returncode==0,'Inspect saved whitespace-check output.'
    message=('docs: hand over GSEA source-build research and remaining toolbox work\n\n'
        'Record current admitted totals, prioritized provider-aware source review,\n'
        'expression/phenotype and preranked requirements, exact runtime/build paths,\n'
        'failure recovery and separate private machine-transfer requirements.\n'
        'Save candidate anchors, immutable upstream source/dependency hashes,\n'
        'unchanged-source build logs/producer pins, unsupported-help probes and\n'
        'six original one-shot helpers with a portable integrity reader.\n\n'
        'Fresh source/build/runtime and saved edgeR/catalog readbacks pass.\n'
        'Keep 29 worktrees and inherited/private evidence intact. No scientific\n'
        'engine, canonical catalog, site, release or integration credit changes.\n'
        'GSEA statistical execution, project implementation, cumulative admission\n'
        'and the full 250-paper implementation/review goal remain unfinished.\n')
    (O/'COMMIT-MESSAGE.txt').write_text(message,encoding='utf-8',newline='\n')
    p=subprocess.run(['git','commit','-F',str(O/'COMMIT-MESSAGE.txt')],cwd=G,capture_output=True)
    (O/'commit.stdout').write_bytes(p.stdout);(O/'commit.stderr').write_bytes(p.stderr);assert p.returncode==0,'Inspect saved commit stderr.'
    head=git('rev-parse','HEAD').decode().strip();assert not git('status','--porcelain=v1','-z','--untracked-files=all')
    for row in previous:assert inv.snapshot(Path(row['root']))==row,row['root']
    now=inv.snapshot(G);assert now['head']==head and not now['files'] and not now['status_hex'] and now['branch']==active['branch']
    save('WORKTREES-EXPECTED.json',previous+[now])
    save('COMMITTED.json',dict(head=head,base=BASE,files=pins,worktrees=29,protected_artifacts=len(protected),
        inherited_artifacts=inherited,new_artifacts_SHA256_pinned=added,canonical_files_unchanged=15,
        source_code_unchanged=True,new_catalog_credit=0,GSEA_statistical_execution_qualified=False,whole_goal_complete=False))
    print(json.dumps(dict(status='COMMITTED_GSEA_HANDOVER_READY_TO_PUSH',head=head,files=len(pins),
        worktrees=29,protected_artifacts=len(protected))),flush=True)
except Exception as error:
    save('FAILURE.json',dict(error=repr(error),detail=traceback.format_exc()));raise
