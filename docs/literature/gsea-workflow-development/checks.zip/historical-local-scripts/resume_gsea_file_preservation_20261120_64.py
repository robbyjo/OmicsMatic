from pathlib import Path
import hashlib,importlib.util,json,subprocess,sys,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/gs-4';K=R/'build/edg-3';P=R/'build/git-publish/20261120-gsea-handover-63';O=R/'build/git-publish/20261120-gsea-files-64'
BASE='7b6ed9d96d9d52bc0b141811dc741bed874616ba'
def enc(v):return (json.dumps(v,indent=2)+'\n').encode()
def save(n,v):
    with (O/n).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def pin(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def git(*args):return subprocess.check_output(['git','--no-replace-objects',*args],cwd=T)
spec=importlib.util.spec_from_file_location('inventory',O.parent/'20261115-all-main-3/inventory.py');inv=importlib.util.module_from_spec(spec);spec.loader.exec_module(inv)
prior=json.loads((P/'WORKTREES-EXPECTED.json').read_bytes());assert len(prior)==31
index=json.loads((R/'build/cleanup-20261120.json').read_bytes());summary=json.loads(Path(index['summary']).read_bytes());verification=json.loads(Path(index['verification']).read_bytes())
retired=json.loads(Path(summary['records']['worktrees']).read_bytes());caches=json.loads(Path(summary['records']['caches']).read_bytes())
assert index['cleanup_complete'] and summary['all_cleanup_preservation_checks_passed'] and verification['all_cleanup_preservation_checks_passed']
assert verification['root_status_unchanged'] and verification['root_diff_unchanged'] and not verification['unexpected_removed_registrations']
assert len(retired)==12 and len(caches)==155
save('INITIAL-INVENTORY-REFUSAL.json',dict(reason='The strict predecessor worktree-set assertion correctly refused because a concurrent completed cleanup retired 12 historical checkouts. No scientific code or source hash was changed. Reconcile the exact cleanup receipts and recovery payloads, preserving all current worktrees.'))
copies=O/'external-cleanup';copies.mkdir(exist_ok=False);records={}
for name,path in [('INDEX.json',R/'build/cleanup-20261120.json'),('SUMMARY.json',Path(index['summary'])),('VERIFICATION.json',Path(index['verification'])),('WORKTREE-RETIREMENTS.json',Path(summary['records']['worktrees'])),('CACHE-REMOVALS.json',Path(summary['records']['caches']))]:
    raw=path.read_bytes();(copies/name).write_bytes(raw);records[name]=pin(raw)
roots={Path(b.splitlines()[0][9:]).resolve() for b in git('worktree','list','--porcelain').decode().strip().split('\n\n')}
retired_roots={Path(row['path']).resolve() for row in retired}
assert roots==({Path(row['root']).resolve() for row in prior}-retired_roots)|{T.resolve()} and len(roots)==20
current=[];retirement_proofs=[];working_payloads=staged_payloads=0
for row in prior:
    root=Path(row['root']);git('merge-base','--is-ancestor',row['head'],BASE)
    if root.resolve() not in retired_roots:
        assert inv.snapshot(root)==row,row['root'];current.append(row);continue
    record=next(r for r in retired if Path(r['path']).resolve()==root.resolve());assert record['head']==row['head']
    if row['branch']:assert git('rev-parse','refs/heads/'+row['branch']).decode().strip()==row['head']
    proof=dict(root=str(root),head=row['head'],branch_retained=True,previous_dirty_files=len(row['files']),recovery=None)
    if record['archive']:
        archive=Path(record['archive']);manifest_path=archive.parent/'manifest.json';manifest_raw=manifest_path.read_bytes();manifest=json.loads(manifest_raw)
        assert manifest['head']==row['head'] and Path(manifest['original_path']).resolve()==root.resolve()
        assert manifest['all_local_blobs_in_persistent_git_history']
        expected={'working-files/'+r['path']:r for r in manifest['working_files']}
        expected.update({'index-files/'+r['path']:r for r in manifest['staged_files']})
        working={r['path']:r for r in manifest['working_files']}
        for n,w in row['files'].items():assert n in working and all(working[n][k]==w[k] for k in ['bytes','sha256']),n
        with zipfile.ZipFile(archive) as z:
            assert z.testzip() is None and len(z.namelist())==len(set(z.namelist())) and set(z.namelist())==set(expected)|{'manifest.json'}
            assert z.read('manifest.json')==manifest_raw
            for n,w in expected.items():
                raw=z.read(n);assert pin(raw)==dict(bytes=w['bytes'],sha256=w['sha256']),n
                blob=git('cat-file','blob',w['git_blob']);assert blob==raw,n
        alias='recovery-'+str(len(retirement_proofs)).zfill(2);folder=copies/alias;folder.mkdir()
        for path in archive.parent.iterdir():
            if path.is_file():raw=path.read_bytes();(folder/path.name).write_bytes(raw);records[alias+'/'+path.name]=pin(raw)
        working_payloads+=len(manifest['working_files']);staged_payloads+=len(manifest['staged_files'])
        proof['recovery']=dict(archive=pin(archive.read_bytes()),files=len(expected),manifest=pin(manifest_raw))
    else:assert not row['files'],'A dirty retired worktree has no recovery'
    retirement_proofs.append(proof)
assert len(current)==19 and len(retirement_proofs)==12
save('EXTERNAL-CLEANUP-TRANSITION.json',dict(status='PASS_EXACT_COMPLETED_CLEANUP_AND_RECOVERY_PAYLOADS',predecessor_worktrees=31,new_active_worktree=str(T),current_worktrees=20,retired_worktrees=12,declared_cache_directories=155,working_recovery_payloads=working_payloads,staged_recovery_payloads=staged_payloads,records=records,retirements=retirement_proofs,all_prior_registered_live_worktrees_exact=True,full_inherited_artifact_retirement_audit_pending=True))
save('WORKTREES-BEFORE.json',current+[inv.snapshot(T)])
print('PASS 19 prior live worktrees exact, 12 retirement records and six hash/CRC/Git-blob-verified recovery archives; active total 20',flush=True)
for name,command,cwd in [
 ('historical-overlays',[sys.executable,'-B',str(T/'docs/literature/handover-20261119/verify.py')],T),
 ('saved-native-arithmetic',[sys.executable,'-B',str(T/'tools/literature/verify_broad_gsea_native.py'),'--out',str(T/'build/gsea-high-impact-4/predecessor-arithmetic-readback-1')],T),
 ('saved-native-engine',[sys.executable,'-B',str(T/'tools/literature/verify_broad_gsea_engine_checkpoint.py')],T),
 ('catalog',[sys.executable,'-B',str(K/'tools/literature/close_edger_catalog.py'),'--verify','--primary-cache',str(R/'build/literature-review/xml'),'--out',str(K/'build/gsea-file-workflow-catalog-readback-1')],K)]:
    with (O/(name+'.stdout')).open('xb') as stdout,(O/(name+'.stderr')).open('xb') as stderr:
        p=subprocess.run(command,cwd=cwd,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=1200)
    save(name+'.PROCESS.json',dict(command=command,exit_code=p.returncode));assert p.returncode==0,'Inspect '+name+' logs'
    print('PASS fresh predecessor/current readback',name,flush=True)
canonical=json.loads((P/'CANONICAL-AFTER.json').read_bytes());assert len(canonical)==15
for n,w in canonical.items():assert pin((T/n).read_bytes())==w,n
save('CANONICAL-BEFORE.json',canonical);save('CANONICAL-AFTER.json',canonical)
save('READBACKS-COMPLETED.json',dict(status='PASS_LIVE_WORKTREES_VERIFIED_RETIREMENTS_AND_FRESH_OVERLAY_NATIVE_ENGINE_AND_CATALOG_READBACKS',prior_live_worktrees=19,current_worktrees=20,retired_worktrees=12,canonical_files_unchanged=15))
