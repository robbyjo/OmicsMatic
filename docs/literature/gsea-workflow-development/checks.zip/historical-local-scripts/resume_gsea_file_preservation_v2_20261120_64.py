from pathlib import Path
import json
R=Path('D:/projects/JLinAlg');O=R/'build/git-publish/20261120-gsea-files-64'
diagnosis=json.loads((O/'RECOVERY-MANIFEST-DIAGNOSIS.json').read_bytes());assert len(diagnosis)==6 and all(not r['differences'] for r in diagnosis)
with (O/'RECOVERY-MANIFEST-RETRY-REASON.json').open('x',encoding='utf-8') as f:
    json.dump(dict(reason='ZIP and sibling recovery manifests have identical parsed JSON metadata but different raw formatting. Preserve both byte encodings; compare metadata objects and continue enforcing exact SHA-256/length/Git-blob equality for every archived working and staged payload. No metadata or prior scientific source hash was refreshed.'),f,indent=2);f.write('\n')
s=(R/'build/resume_gsea_file_preservation_20261120_64.py').read_text()
s=s.replace("save('INITIAL-INVENTORY-REFUSAL.json'","save('INITIAL-INVENTORY-REFUSAL-2.json'").replace("copies=O/'external-cleanup'","copies=O/'external-cleanup-2'")
s=s.replace("assert z.read('manifest.json')==manifest_raw","assert json.loads(z.read('manifest.json'))==manifest")
s=s.replace("records=records,retirements=retirement_proofs","record_directory=str(copies),records=records,retirements=retirement_proofs")
exec(compile(s,str(Path(__file__)),'exec'))
