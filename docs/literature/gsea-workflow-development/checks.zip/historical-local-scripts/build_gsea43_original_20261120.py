from pathlib import Path
import hashlib,json,subprocess,traceback,zipfile
R=Path('D:/projects/JLinAlg');B=R/'build/gs-2/build/gsea-high-impact-2';P=R/'build/gs-1/build/gsea-high-impact-1/source-intake-1/4.3.2'
O=B/'original-build-4.3-source-1';O.mkdir(exist_ok=False)
JDK=R/'build/literature-review/hail-runtime/reference-setup-130-2/mamba-root/pkgs/https/conda.anaconda.org/conda-forge/linux-64/openjdk-11.0.30-ha668962_0/lib/jvm'
GRADLE=B/'legacy-build-prereqs-1/gradle-4.10.2/extracted/gradle-4.10.2/bin/gradle'
def linux(p):return '/mnt/d/'+str(p.relative_to(Path('D:/'))).replace('\\','/')
def save(p,v):p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
def pin(p):
    with p.open('rb') as f:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
try:
    source=json.loads((P/'COMPLETED.json').read_bytes())
    for name,w in source['files'].items():assert pin(P/'source'/name)==w,name
    assert pin(JDK/'bin/java')['sha256']=='564067b56b32b2240354277bc2e50d82da8e9d43ffa48a1a57e9f39731dc6d86'
    results=[]
    for version in ['4.3.2','4.3.3']:
        folder=O/version;folder.mkdir();out=folder/'project-build';init=folder/'isolate.gradle'
        init.write_text("gradle.beforeProject { p -> p.buildDir = new File('"+linux(out)+"') }\n",encoding='utf-8',newline='\n')
        command=['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--exec','/usr/bin/env','JAVA_HOME='+linux(JDK),
            '/bin/sh',linux(GRADLE),'--no-daemon','--offline','--console=plain','--max-workers=2','--gradle-user-home',linux(folder/'gradle-home'),
            '--project-cache-dir',linux(folder/'project-cache'),'--init-script',linux(init),'-p',linux(P/'source'),'-Pversion='+version,
            '-PversionMajor=4','-PversionMinor=3','-PversionPatch='+version.split('.')[-1],'-PbuildNumber=0',
            '-Ptimestamp=unmodified-source-e1ae61cd83dd-local-JDK11','jar']
        save(folder/'COMMAND.json',dict(command=command,source_tag='v'+version,source_commit=source['commit'],source_modified=False,
            local_source_build=True,vendor_binary=False,build_JDK='Linux cached OpenJDK11; observed build attempt, not a claim of official Gradle compatibility',
            Gradle='4.10.2 original wrapper edition',JDK8_intake_failed_and_unused=True))
        with (folder/'stdout').open('xb') as stdout,(folder/'stderr').open('xb') as stderr:
            p=subprocess.Popen(command,cwd=R,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr);save(folder/'PROCESS.json',dict(pid=p.pid))
            code=p.wait(timeout=240)
        save(folder/'PROCESS-EXIT.json',dict(exit_code=code));print('Original',version,'source build exit',code,flush=True)
        for name,w in source['files'].items():assert pin(P/'source'/name)==w,name
        jar=out/('libs/gsea-minimal-'+version+'.jar')
        record=dict(version=version,exit_code=code,source_files_unchanged=len(source['files']),source_commit=source['commit'])
        if code==0:
            assert jar.is_file();record['producer']=pin(jar)
            with zipfile.ZipFile(jar) as z:members={n:dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()) for n in z.namelist() for raw in [z.read(n)]}
            save(folder/'PRODUCER.json',dict(jar=str(jar),jar_pin=pin(jar),members=members,source_commit=source['commit'],vendor_binary=False))
        results.append(record)
        if code!=0:break
    save(O/'COMPLETED.json',dict(status='OBSERVED_UNMODIFIED_GSEA43_SOURCE_BUILD_ATTEMPT',results=results,new_catalog_credit=0))
except Exception as error:
    save(O/'FAILURE.json',dict(error=repr(error),detail=traceback.format_exc()));raise
