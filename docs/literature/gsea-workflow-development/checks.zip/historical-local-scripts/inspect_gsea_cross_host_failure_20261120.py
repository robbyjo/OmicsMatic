from pathlib import Path
import hashlib,json
R=Path('D:/projects/JLinAlg');B=R/'build/gs-4/build/gsea-high-impact-4';O=B/'cross-host-newline-diagnosis-1';O.mkdir(exist_ok=False)
parent=B/'file-controls-2/linux-java21/baseline/analysis/results'
child=B/'file-transport-1/windows-java21/cross-host-verify/analysis/results'
left={p.relative_to(parent).as_posix():p for p in parent.rglob('*') if p.is_file()};right={p.relative_to(child).as_posix():p for p in child.rglob('*') if p.is_file()}
assert set(left)==set(right);different=[]
for name in left:
    a,b=left[name].read_bytes(),right[name].read_bytes()
    if a!=b:
        assert a==b.replace(b'\r\n',b'\n'),name
        different.append(dict(name=name,parent_bytes=len(a),child_bytes=len(b),normalized_bytes_equal=True))
assert {d['name'] for d in different}=={'case-0000/partial/dispositions.jsonl','case-0000/partial/observed.jsonl'}
assert (parent/'case-0000/result.bin').read_bytes()==(child/'case-0000/result.bin').read_bytes()
(O/'DIAGNOSIS.json').write_text(json.dumps(dict(status='CONFIRMED_PLATFORM_LINE_ENDINGS_ONLY',different_files=different,exact_binary_numerical_objects_equal=True,required_fix='Emit explicit LF in both JSON-lines progress ledgers; preserve old captures and require fresh final-producer qualification.'),indent=2)+'\n',encoding='utf-8')
print('Confirmed two CRLF/LF-only ledger differences; exact numerical binary unchanged',flush=True)
