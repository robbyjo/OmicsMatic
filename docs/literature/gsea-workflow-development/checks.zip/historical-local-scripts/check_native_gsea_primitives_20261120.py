from pathlib import Path
import json,subprocess
R=Path('D:/projects/JLinAlg');H=R/'build/gs-2';B=H/'build/gsea-high-impact-2';O=B/'native-primitives-check-1';O.mkdir(exist_ok=False)
J=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin');classes=O/'classes';classes.mkdir()
sources=[H/'src/main/java/org/jlinalg/enrichment/BroadGseaStatistics.java',H/'tools/literature/gsea_original/CheckNativeBroadPrimitives.java']
command=[str(J/'javac.exe'),'--release','17','-d',str(classes),*[str(p) for p in sources]]
p=subprocess.run(command,capture_output=True);(O/'javac.stdout').write_bytes(p.stdout);(O/'javac.stderr').write_bytes(p.stderr);assert p.returncode==0
command=[str(J/'java.exe'),'-cp',str(classes),'CheckNativeBroadPrimitives',str(B/'original-primitives-1/original-primitives.tsv')]
p=subprocess.run(command,capture_output=True);(O/'stdout').write_bytes(p.stdout);(O/'stderr').write_bytes(p.stderr)
(O/'PROCESS.json').write_text(json.dumps(dict(command=command,exit_code=p.returncode),indent=2)+'\n',encoding='utf-8')
print(p.stdout.decode(errors='replace'),flush=True);print(p.stderr.decode(errors='replace'),flush=True);assert p.returncode==0
