from pathlib import Path
import concurrent.futures,hashlib,importlib.util,json,os,shutil,subprocess,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/gs-4';B=T/'build/gsea-high-impact-4';O=B/'file-hosts-qualification-3';O.mkdir(exist_ok=False)
JAR=B/'native-gradle-3/project-build/cli/omicsmatic-0.4.0.jar';OLD=R/'build/gs-3/build/gsea-high-impact-3/native-gradle-1/project-build/cli/omicsmatic-0.4.0.jar'
J21=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe');J25=Path('C:/Program Files/Java/jdk-25/bin/java.exe')
def save(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n',encoding='utf-8',newline='\n')
def pin(p):
    with p.open('rb') as f:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
def snapshot(root):return {p.relative_to(root).as_posix():dict(pin(p),mtime_ns=p.stat().st_mtime_ns) for p in root.rglob('*') if p.is_file()}
def linux(p):return '/mnt/d/'+Path(p).relative_to(Path('D:/')).as_posix()
def module(name,p):
    s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
assert json.loads((B/'native-gradle-3/PROCESS-EXIT.json').read_bytes())['exit_code']==0
with zipfile.ZipFile(OLD) as old,zipfile.ZipFile(JAR) as new:
    before=set(old.namelist());after=set(new.namelist());assert before<=after
    for n in sorted(before):assert old.read(n)==new.read(n),n
    added=sorted(after-before);assert added and all(n.startswith('org/jlinalg/cli/BroadGsea') and n.endswith('.class') for n in added)
    members={n:dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()) for n in new.namelist() for raw in [new.read(n)]}
save(O/'PRODUCER.json',dict(producer=pin(JAR),prior_producer=pin(OLD),unchanged_predecessor_members=len(before),added_members=added,members=members))
checker=module('gsea_file_checker',T/'tools/literature/gsea_workflows/check_results.py')
translator=module('gsea_fixture_translator',T/'tools/literature/gsea_workflows/prepare_fixture_requests.py')
limits=json.loads((T/'examples/native-gsea/run.json').read_bytes())['limits']
reference=O/'complete-null-reference';reference.mkdir()
with zipfile.ZipFile(T/'docs/literature/gsea-engine-development/complete-null-references.zip') as z:
    for name in z.namelist():
        if name.startswith('reference/'):
            p=reference/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(name))
def task(host):
    root=O/host;root.mkdir();examples=root/'examples';shutil.copytree(T/'examples/native-gsea',examples)
    if host=='linux-java21':prefix=['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','--exec','/usr/bin/java'];jar=linux(JAR);convert=linux
    else:prefix=[str(J21 if host=='windows-java21' else J25)];jar=str(JAR);convert=str
    version=subprocess.run(prefix+['-version'],capture_output=True,stdin=subprocess.DEVNULL,timeout=30)
    (root/'version.stdout').write_bytes(version.stdout);(root/'version.stderr').write_bytes(version.stderr);assert version.returncode==0
    def run(label,recipe):
        command=prefix+['-cp',jar,'org.jlinalg.cli.BroadGseaWorkflowCli','--request',convert(recipe)]
        with (root/(label+'.stdout')).open('xb') as stdout,(root/(label+'.stderr')).open('xb') as stderr:
            p=subprocess.run(command,cwd=root,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=240)
        save(root/(label+'.PROCESS.json'),dict(command=command,exit_code=p.returncode));assert p.returncode==0,'Inspect '+host+'/'+label
    before=None
    for mode in ['run','verify','replay']:
        run(mode,examples/(mode+'.json'))
        if mode=='run':before=snapshot(examples/'run-out')
        else:assert snapshot(examples/'run-out')==before,'Parent changed during '+mode
        status=json.loads((examples/(mode+'-out')/'analysis-status.json').read_bytes());assert status['complete_result'] and status['status']=='PASS_'+mode.upper()
    long_fields=0;i=0
    for edition in ['4.4.0','4.3.2','4.3.3']:
        for mode in ['preranked','expression-phenotype','expression-geneset']:
            long_fields+=checker.compare(examples/'run-out/results'/('case-%04d'%i)/'result.bin',reference/'reference'/edition/(mode+'.tsv'));i+=1
    assert long_fields==468270
    corpus=root/'corpus';mapping=translator.prepare(T/'src/test/resources/org/jlinalg/enrichment/broad-gsea-engine-originals.zip',corpus,limits)
    sweep_fields=0;admitted=0
    for batch,ids in mapping.items():
        run(batch,corpus/(batch+'.json'))
        for i,id in enumerate(ids):sweep_fields+=checker.compare(corpus/(batch+'-out')/'results'/('case-%04d'%i)/'result.bin',corpus/'reference'/(id+'.tsv'),raw_metrics=True);admitted+=1
    assert sweep_fields==200469 and admitted==423
    result=dict(host=host,exit_code=0,complete_null_original_fields=long_fields,option_original_fields=sweep_fields,admitted_option_cases=admitted,exact_fields=long_fields+sweep_fields,parent_bytes_and_mtimes_preserved=True,upstream_runtime_on_classpath=False)
    save(root/'COMPLETED.json',result);print('PASS final normal-JAR file workflow',host,result['exact_fields'],'original fields; 423 option cases; RUN/VERIFY/REPLAY',flush=True);return host,result
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=dict(pool.map(task,['windows-java21','windows-java25','linux-java21']))
save(O/'COMPLETED.json',dict(status='PASS_NATIVE_GSEA_FILE_WORKFLOW_ORIGINAL_COMPARISONS_THREE_JVMS',producer=pin(JAR),results=results,original_fields_per_JVM=668739,new_catalog_credit=0,global_dispatch_registered=False))
