from pathlib import Path
import concurrent.futures,copy,hashlib,importlib.util,json,struct,subprocess
R=Path('D:/projects/JLinAlg');T=R/'build/gs-4';B=T/'build/gsea-high-impact-4';O=B/'file-transport-1';O.mkdir(exist_ok=False)
JAR=B/'native-gradle-2/project-build/cli/omicsmatic-0.4.0.jar';J21=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe');J25=Path('C:/Program Files/Java/jdk-25/bin/java.exe')
template=json.loads((T/'examples/native-gsea/run.json').read_bytes());base=json.loads((T/'examples/native-gsea/preranked.json').read_bytes())
def save(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
def linux(p):return '/mnt/d/'+Path(p).relative_to(Path('D:/')).as_posix()
def pin(p):
    with p.open('rb') as f:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
def snapshot(root):return {p.relative_to(root).as_posix():dict(pin(p),mtime_ns=p.stat().st_mtime_ns) for p in root.rglob('*') if p.is_file()}
s=importlib.util.spec_from_file_location('binary',T/'tools/literature/gsea_workflows/check_results.py');binary=importlib.util.module_from_spec(s);s.loader.exec_module(binary)
assert json.loads((B/'file-controls-2/COMPLETED.json').read_bytes())['status']=='PASS_NATIVE_GSEA_FILE_WORKFLOW_CONTROLS_THREE_JVMS'
parents={host:B/'file-controls-2'/host/'baseline/analysis' for host in ['windows-java21','windows-java25','linux-java21']};before={host:snapshot(path) for host,path in parents.items()}
def task(host):
    root=O/host;root.mkdir();rows=[]
    if host=='linux-java21':prefix=['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','--exec','/usr/bin/java'];jar=linux(JAR);convert=linux
    else:prefix=[str(J21 if host=='windows-java21' else J25)];jar=str(JAR);convert=str
    def invoke(name,recipe,expected=0,classes=False):
        folder=root/name;folder.mkdir();save(folder/'request.json',recipe)
        cp=jar
        if classes:cp=str(B/'native-gradle-2/project-build/classes/java/main')+';'+str(JAR)
        command=prefix+['-cp',cp,'org.jlinalg.cli.BroadGseaWorkflowCli','--request',convert(folder/'request.json')]
        with (folder/'stdout').open('xb') as stdout,(folder/'stderr').open('xb') as stderr:
            p=subprocess.run(command,cwd=folder,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=240)
        save(folder/'PROCESS.json',dict(command=command,exit_code=p.returncode,expected_exit=expected));assert p.returncode==expected,host+'/'+name
        status=json.loads((folder/'analysis/analysis-status.json').read_bytes());assert status['complete_result']==(expected==0)
        rows.append(dict(name=name,exit_code=p.returncode,expected_exit=expected));return folder/'analysis'
    def recipe(input,seed='12345'):
        a=copy.deepcopy(template['analyses'][0]);a.update(input=convert(input),permutations=127,seed=seed,id='../../literal:\tΩ\n😀')
        return dict(schema_version=1,mode='RUN',engine='native-broad-gsea-source-core',out='analysis',limits=copy.deepcopy(template['limits']),analyses=[a])
    input=root/'input.json';save(input,base)
    for name,seed in [('signed-seed-min','-9223372036854775808'),('signed-seed-max','9223372036854775807')]:
        capture=invoke(name,recipe(input,seed));effective=json.loads((capture/'effective-request.json').read_bytes());assert effective['analyses'][0]['seed']==seed
    unicode=copy.deepcopy(base);mapping={gene:'é|e\u0301|\t\n😀/'+gene for gene in unicode['genes']};unicode['genes']=[mapping[g] for g in unicode['genes']]
    for gs in unicode['gene_sets']:gs['name']='set\t"Ω\n'+gs['name'];gs['members']=[mapping.get(g,g) for g in gs['members']]
    save(input,unicode);capture=invoke('literal-unicode-and-control-identities',recipe(input));decoded=binary.decode(capture/'results/case-0000/result.bin')
    assert [r['name'] for r in decoded['ranks']]==unicode['genes'];assert all(gs['name'] in {g['name'] for g in unicode['gene_sets']} for gs in decoded['sets'])
    midpoint=copy.deepcopy(base);midpoint['ranking_scores'][0]='__F32_MIDPOINT__'
    input.write_text(json.dumps(midpoint,indent=2).replace('"__F32_MIDPOINT__"','1.000000059604644775390625000000000000001')+'\n',encoding='utf-8',newline='\n')
    capture=invoke('float32-lexeme-midpoint',recipe(input));decoded=binary.decode(capture/'results/case-0000/result.bin')
    assert struct.pack('>f',decoded['ranks'][0]['score'])==bytes.fromhex('3f800001') and decoded['ranks'][0]['name']==base['genes'][0]
    parent=parents['windows-java21' if host=='linux-java21' else 'linux-java21']
    for mode in ['VERIFY','REPLAY']:
        control=dict(schema_version=1,mode=mode,analysis=convert(parent),out='analysis',limits=copy.deepcopy(template['limits']))
        invoke('cross-host-'+mode.lower(),control)
    if host=='windows-java21':
        save(input,base);capture=invoke('class-directory-is-explicit-skip',recipe(input),3,classes=True)
        assert 'normal executable JAR' in (capture/'WARNINGS.md').read_text()
    result=dict(host=host,status='PASS_LITERAL_FLOAT32_AND_CROSS_HOST_WORKFLOW_TRANSPORT',checks=rows,cross_host_parent_preserved=True)
    save(root/'COMPLETED.json',result);print('PASS native GSEA transport',host,'checks',len(rows),flush=True);return host,result
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=dict(pool.map(task,['windows-java21','windows-java25','linux-java21']))
for host,path in parents.items():assert snapshot(path)==before[host],host+' cross-host parent changed'
save(O/'COMPLETED.json',dict(status='PASS_NATIVE_GSEA_LITERAL_FLOAT32_AND_CROSS_HOST_TRANSPORT_THREE_JVMS',results=results,all_parent_bytes_and_mtimes_preserved=True))
