from pathlib import Path
import concurrent.futures,copy,hashlib,json,os,shutil,subprocess,sys
R=Path('D:/projects/JLinAlg');T=R/'build/gs-4';B=T/'build/gsea-high-impact-4';O=B/'file-controls-1';O.mkdir(exist_ok=False)
JAR=B/'native-gradle-2/project-build/cli/omicsmatic-0.4.0.jar'
J21=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe');J25=Path('C:/Program Files/Java/jdk-25/bin/java.exe')
template=json.loads((T/'examples/native-gsea/run.json').read_bytes());limits=template['limits'];prerank=json.loads((T/'examples/native-gsea/preranked.json').read_bytes());expression=json.loads((T/'examples/native-gsea/expression.json').read_bytes())
def save(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n',encoding='utf-8',newline='\n')
def pin(p):
    with p.open('rb') as f:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
def snapshot(root):return {p.relative_to(root).as_posix():dict(pin(p),mtime_ns=p.stat().st_mtime_ns) for p in root.rglob('*') if p.is_file()}
def linux(p):return '/mnt/d/'+Path(p).relative_to(Path('D:/')).as_posix()
def reseal(root):
    inventory={p.relative_to(root).as_posix():pin(p) for p in root.rglob('*') if p.is_file() and p.name not in {'capture-files.json','analysis-status.json'}}
    save(root/'capture-files.json',inventory);status=json.loads((root/'analysis-status.json').read_bytes());status['manifest']=pin(root/'capture-files.json');save(root/'analysis-status.json',status)
def task(host):
    root=O/host;root.mkdir();rows=[]
    if host=='linux-java21':prefix=['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--exec','/usr/bin/java'];jar=linux(JAR);convert=linux
    else:prefix=[str(J21 if host=='windows-java21' else J25)];jar=str(JAR);convert=str
    def invoke(label,recipe,expected,environment=None):
        folder=root/label;folder.mkdir(exist_ok=False);path=folder/'request.json'
        if isinstance(recipe,str):path.write_text(recipe,encoding='utf-8',newline='\n')
        else:save(path,recipe)
        command=prefix+['-cp',jar,'org.jlinalg.cli.BroadGseaWorkflowCli','--request',convert(path)]
        with (folder/'stdout').open('xb') as stdout,(folder/'stderr').open('xb') as stderr:
            p=subprocess.run(command,cwd=folder,env=environment,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=180)
        save(folder/'PROCESS.json',dict(command=command,exit_code=p.returncode,expected_exit=expected));assert p.returncode==expected,host+'/'+label+': inspect retained logs'
        output=folder/'analysis'
        if output.exists():
            status=json.loads((output/'analysis-status.json').read_bytes());assert status['complete_result']==(expected==0)
            if expected:assert status['status']==('SKIP3' if expected==3 else 'FAIL2') and 'NO COMPLETE RESULT' in (output/'WARNINGS.md').read_text()
        rows.append(dict(name=label,exit_code=p.returncode,expected_exit=expected,capture_preserved=output.exists()));return folder,output
    def run_recipe(a=None,data=None):
        a=copy.deepcopy(a or template['analyses'][0]);a['permutations']=127;a['input']=convert(root/'input.json')
        save(root/'input.json',data or prerank)
        return dict(schema_version=1,mode='RUN',engine='native-broad-gsea-source-core',out='analysis',limits=copy.deepcopy(limits),analyses=[a])
    _,golden=invoke('baseline',run_recipe(),0);before=snapshot(golden)
    invoke('duplicate-json-key','{"mode":"RUN","mode":"RUN"}',2)
    recipe=run_recipe();recipe['unexpected']=1;invoke('unknown-request-key',recipe,2)
    recipe=run_recipe();recipe['analyses'][0]['edition']='2023.1';invoke('unsupported-exact-edition',recipe,3)
    recipe=run_recipe();recipe['analyses'][0]['input']=convert(root/'does-not-exist.json');invoke('missing-exact-input',recipe,3)
    recipe=run_recipe();recipe['analyses'][0]['seed']=12345;invoke('numeric-seed-refused',recipe,2)
    for name,mutate in [
        ('nonfinite-float32',lambda d:d['ranking_scores'].__setitem__(0,1e100)),
        ('nan-string',lambda d:d['ranking_scores'].__setitem__(0,'NaN')),
        ('duplicate-gene',lambda d:d['genes'].__setitem__(1,d['genes'][0])),
        ('duplicate-set-member',lambda d:d['gene_sets'][0]['members'].append(d['gene_sets'][0]['members'][0])),
        ('undefined-weight-mass',lambda d:d.__setitem__('ranking_scores',[0]*len(d['genes']))),
    ]:
        data=copy.deepcopy(prerank);mutate(data);invoke(name,run_recipe(data=data),2)
    for name,mutate in [
        ('class-overlap',lambda d:d['class1'].__setitem__(0,d['class0'][0])),
        ('class-incomplete',lambda d:d['class1'].pop()),
        ('too-few-snr-samples',lambda d:(d.__setitem__('class0',[0,1]),d.__setitem__('class1',list(range(2,len(d['samples'])))))),
    ]:
        data=copy.deepcopy(expression);mutate(data);invoke(name,run_recipe(template['analyses'][1],data),2)
    data=copy.deepcopy(expression);data['class0']=[0,1,2];data['class1']=list(range(3,len(data['samples'])))
    recipe=run_recipe(template['analyses'][1],data);recipe['analyses'][0]['randomization']='BALANCE_CLASS1';_,failed=invoke('impossible-source-randomizer',recipe,2)
    assert (failed/'results/case-0000/partial/real-ranking.tsv').is_file()
    for field in ['maximum_dense_cells','maximum_null_cells','maximum_work_per_analysis','maximum_output_bytes','maximum_files']:
        recipe=run_recipe();recipe['limits'][field]=1;invoke('capacity-'+field,recipe,2)
    recipe=run_recipe();recipe['analyses'][0]['permutations']=10001;invoke('permutation-capacity',recipe,2)
    # A completed earlier analysis must not turn a later failed batch into PASS.
    recipe=run_recipe();bad=copy.deepcopy(expression);bad['expression'][0][0]='NaN';save(root/'bad-expression.json',bad)
    a=copy.deepcopy(template['analyses'][1]);a['input']=convert(root/'bad-expression.json');a['permutations']=127;recipe['analyses'].append(a)
    _,failed=invoke('partial-batch-failure',recipe,2);assert (failed/'results/case-0000/result.bin').is_file()
    assert json.loads((failed/'worker/status.json').read_bytes())['complete_analyses']==1
    # The unrelated sentinel belongs to this test, not to the native worker.
    sentinel=subprocess.Popen([sys.executable,'-c','import time; time.sleep(120)'],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    try:
        recipe=run_recipe(template['analyses'][1],copy.deepcopy(expression));recipe['limits'].update(timeout_seconds=1,maximum_permutations=1000000,maximum_null_cells=100000000,maximum_work_per_analysis=10000000000000,heap_mib=256)
        recipe['analyses'][0]['permutations']=1000000;_,failed=invoke('owned-timeout-cleanup',recipe,2)
        process=json.loads((failed/'process.json').read_bytes());assert 'timeout_seconds' in process['error']
        assert process.get('owned_process_cleanup') and all(not h['alive_after_cleanup'] for h in process['owned_process_cleanup']);assert sentinel.poll() is None
    finally:sentinel.terminate();sentinel.wait(timeout=15)
    data=copy.deepcopy(expression);data['genes']=['large-'+str(i) for i in range(1000)];data['samples']=['sample-'+str(i) for i in range(1000)];data['expression']=[[1.0]*1000 for _ in range(1000)];data['class0']=list(range(500));data['class1']=list(range(500,1000));data['gene_sets']=[dict(name='large-set',members=data['genes'][:100])]
    recipe=run_recipe(template['analyses'][1],data);recipe['limits'].update(heap_mib=64,maximum_dense_cells=2000000)
    _,failed=invoke('owned-heap-exhaustion',recipe,2);assert 'OutOfMemoryError' in (failed/'worker/stderr.log').read_text(errors='replace')
    def control(parent,out='analysis',mode='VERIFY'):
        return dict(schema_version=1,mode=mode,analysis=convert(parent),out=out,limits=copy.deepcopy(limits))
    def tamper(name,change,seal=True):
        parent=root/(name+'-parent');shutil.copytree(golden,parent);change(parent)
        if seal:reseal(parent)
        return parent
    def flip_result(p):
        path=p/'results/case-0000/result.bin';raw=bytearray(path.read_bytes());raw[-1]^=1;path.write_bytes(raw)
    parent=tamper('unsealed-result',flip_result,False);invoke('changed-result-hash',control(parent),2)
    parent=tamper('resealed-result',flip_result);_,failed=invoke('resealed-false-result',control(parent),2);assert 'differ from recomputation' in json.loads((failed/'process.json').read_bytes())['error']
    def change_input(p):
        path=p/'inputs/case-0000.json';data=json.loads(path.read_bytes());data['ranking_scores'][0]*=1.125;save(path,data)
        bindings=json.loads((p/'input-bindings.json').read_bytes());bindings['inputs/case-0000.json']['captured']=pin(path);save(p/'input-bindings.json',bindings)
    parent=tamper('resealed-input',change_input);_,failed=invoke('resealed-input-with-old-result',control(parent),2);assert 'differ from recomputation' in json.loads((failed/'process.json').read_bytes())['error']
    def change_request(p):
        path=p/'original-request.json';r=json.loads(path.read_bytes());r['analyses'][0]['seed']='12346';save(path,r)
    parent=tamper('recipe-disagreement',change_request);invoke('original-effective-recipe-disagreement',control(parent),2)
    def change_producer(p):
        path=p/'producer.json';r=json.loads(path.read_bytes());first=next(iter(r['owned_class_payloads']));r['owned_class_payloads'][first]['sha256']='0'*64;save(path,r)
    parent=tamper('producer-disagreement',change_producer);invoke('changed-owned-producer',control(parent),2)
    def move_member(p):(p/'results/case-0000/result.bin').rename(root/'retained-removed-test-member.bin')
    parent=tamper('missing-member',move_member,False);invoke('missing-sealed-member-is-failure',control(parent),2)
    parent=tamper('extra-member',lambda p:(p/'extra.bin').write_bytes(b'undeclared'))
    invoke('resealed-extra-member',control(parent),2)
    parent=tamper('extra-directory',lambda p:(p/'extra-directory').mkdir())
    invoke('extra-empty-directory',control(parent),2)
    invoke('verify-output-inside-parent',control(golden,convert(golden/'forbidden-child')),2)
    recipe=run_recipe();recipe['out']=convert(golden/'forbidden-run');invoke('run-output-inside-parent',recipe,2)
    alias=root/'parent-alias'
    if host=='linux-java21':
        command=['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--exec','/bin/ln','-s',linux(golden),linux(alias)]
    else:
        script=root/'create-junction.ps1';script.write_text('param([string]$AliasPath,[string]$TargetPath)\nNew-Item -ItemType Junction -Path $AliasPath -Value $TargetPath -ErrorAction Stop | Out-Null\n',encoding='utf-8',newline='\n')
        command=['C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe','-NoProfile','-NonInteractive','-File',str(script),str(alias),str(golden)]
    p=subprocess.run(command,capture_output=True);(root/'alias.stdout').write_bytes(p.stdout);(root/'alias.stderr').write_bytes(p.stderr);assert p.returncode==0,'Actual alias control prerequisite failed'
    invoke('aliased-parent-output',control(golden,convert(alias/'forbidden-alias-child')),2)
    assert snapshot(golden)==before,'Golden parent changed during controls'
    # A complete fresh replay is also a valid parent; the original host paths are provenance only.
    _,replayed=invoke('replay-positive',control(golden,mode='REPLAY'),0);invoke('verify-replay-positive',control(replayed),0)
    if host!='linux-java21':
        environment=dict(os.environ,JAVA_TOOL_OPTIONS='-Domicsmatic.gsea.test_injected=one',JDK_JAVA_OPTIONS='-Domicsmatic.gsea.test_injected2=two',_JAVA_OPTIONS='-Domicsmatic.gsea.test_injected3=three')
        _,capture=invoke('owned-java-environment-sanitized',run_recipe(),0,environment)
        assert 'test_injected' not in (capture/'worker/stderr.log').read_text()
    assert snapshot(golden)==before
    result=dict(host=host,status='PASS_NATIVE_GSEA_FILE_WORKFLOW_CONTROLS',controls=rows,expected_refusals=sum(r['expected_exit']!=0 for r in rows),positive_runs=sum(r['expected_exit']==0 for r in rows),parent_preserved=True,timeout_owned_cleanup=True,unrelated_sentinel_preserved=True,heap_exhaustion_explicit_failure=True,actual_alias_refused=True)
    save(root/'COMPLETED.json',result);print('PASS native GSEA controls',host,'refusals',result['expected_refusals'],'positive',result['positive_runs'],flush=True);return host,result
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=dict(pool.map(task,['windows-java21','windows-java25','linux-java21']))
save(O/'COMPLETED.json',dict(status='PASS_NATIVE_GSEA_FILE_WORKFLOW_CONTROLS_THREE_JVMS',results=results))
