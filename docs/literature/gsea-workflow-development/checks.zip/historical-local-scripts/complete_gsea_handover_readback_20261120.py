from pathlib import Path
import hashlib,json,shutil
R=Path('D:/projects/JLinAlg');G=R/'build/gs-1';K=R/'build/edg-3';B=G/'build/gsea-high-impact-1'
O=B/'handover-readback-1';Q=G/'docs/literature/gsea-handover-20261120'
def pin(p):
    with Path(p).open('rb') as f:return dict(bytes=Path(p).stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
def save(p,v):
    with Path(p).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
record=json.loads((O/'catalog-owned-PROCESS.json').read_bytes());assert record['exit_code']==0
catalog=K/'build/gsea-handover-20261120-catalog-2/COMPLETED.json'
for label,source in [('EDGER-GLOBAL-READBACK.json',O/'global/READBACK.json'),('EDGER-CATALOG-READBACK.json',catalog)]:
    assert not (Q/label).exists();shutil.copyfile(source,Q/label)
canonical=json.loads((Q/'CANONICAL-BASELINE.json').read_bytes())
for name,wanted in canonical['files'].items():assert pin(G/name)==wanted==pin(K/name),name
build=json.loads((Q/'BUILD44-COMPLETED.json').read_bytes());profile=json.loads((Q/'RUNTIME44-PROFILE.json').read_bytes())
readbacks={name:json.loads((O/(name+'-PROCESS.json')).read_bytes()) for name in ['global','old-overlays']}
readbacks['catalog']=record
assert all(r['exit_code']==0 for r in readbacks.values())
save(Q/'READBACK.json',dict(status='PASS_UNCHANGED_CANONICAL_SOURCE_INTAKES_BUILD_RUNTIME_AND_SAVED_EDGER_PROOF',
    base=canonical['base'],papers_rehashed=250,source_files_rehashed={'4.4.0':698,'4.3.2':711},source_archives_rehashed=2,
    source_jar_rehashed=build['producer'],runtime_files_rehashed=len(profile['files']),source_modified=False,catalog_modified=False,
    new_family_credit=0,new_GSEA_reviews=0,GSEA_statistical_execution_qualified=False,
    help_preflight=[dict(operation=n,exit_code=1,disposition='UNSUPPORTED_HELP_FLAG_NOT_A_STATISTICAL_ANALYSIS',statistical_analysis_run=False)
        for n in ['GSEA','GSEAPreranked']],readbacks=readbacks,
    retained_failed_check=dict(process=str(O/'catalog-PROCESS.json'),exit_code=2,
        reason='Owner guard refused output outside its checkout build directory; NEW owned output passes.',scientific_analysis_attempted=False),
    handover_packaging_correction='The saved global reader writes READBACK.json, not COMPLETED.json; no reader/source/evidence changed.',
    fresh_scientific_fit=False,whole_goal_complete=False))
save(O/'COMPLETED.json',dict(status='PASS_CURRENT_HANDOVER_SOURCE_AND_SAVED_PROOF_READBACK',public_packet=str(Q),
    canonical_files_unchanged=len(canonical['files']),catalog_rerun_output=str(catalog.parent),first_refusal_retained=True))
manifest=''.join(pin(p)['sha256']+'  '+p.relative_to(Q).as_posix()+'\n' for p in sorted(Q.rglob('*')) if p.is_file() and p.name!='SHA256SUMS')
with (Q/'SHA256SUMS').open('x',encoding='utf-8',newline='\n') as f:f.write(manifest)
print('PASS completed readback metadata and froze complete public packet',flush=True)
