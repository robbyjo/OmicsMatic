from pathlib import Path
import json,subprocess
R=Path('D:/projects/JLinAlg');O=R/'build/gs-4/build/gsea-high-impact-4/linux-preflight-1';O.mkdir(exist_ok=False)
commands={
 'inventory':['C:/Windows/System32/wsl.exe','--list','--verbose'],
 'pymol-java':['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','--exec','/usr/bin/java','-version']}
def decode(b):return b.decode('utf-16-le' if b'\0' in b[:100] else 'utf-8',errors='replace')
for name,command in commands.items():
    p=subprocess.run(command,capture_output=True,stdin=subprocess.DEVNULL,timeout=45)
    (O/(name+'.stdout')).write_bytes(p.stdout);(O/(name+'.stderr')).write_bytes(p.stderr)
    (O/(name+'.PROCESS.json')).write_text(json.dumps(dict(command=command,exit_code=p.returncode),indent=2)+'\n',encoding='utf-8')
    print(name,'exit',p.returncode,decode(p.stdout)[-1300:],decode(p.stderr)[-1000:],flush=True)
