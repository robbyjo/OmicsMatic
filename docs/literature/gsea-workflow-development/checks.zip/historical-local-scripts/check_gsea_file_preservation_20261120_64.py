from pathlib import Path
import hashlib,importlib.util,json,subprocess,sys
R=Path('D:/projects/JLinAlg');T=R/'build/gs-4';K=R/'build/edg-3';P=R/'build/git-publish/20261120-gsea-handover-63'
O=R/'build/git-publish/20261120-gsea-files-64';O.mkdir(exist_ok=False)
def save(n,v):
    with (O/n).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
spec=importlib.util.spec_from_file_location('inventory',O.parent/'20261115-all-main-3/inventory.py');inv=importlib.util.module_from_spec(spec);spec.loader.exec_module(inv)
prior=json.loads((P/'WORKTREES-EXPECTED.json').read_bytes());assert len(prior)==31
roots={Path(b.splitlines()[0][9:]).resolve() for b in subprocess.check_output(['git','worktree','list','--porcelain'],cwd=T).decode().strip().split('\n\n')}
assert roots=={Path(row['root']).resolve() for row in prior}|{T.resolve()}
for row in prior:assert inv.snapshot(Path(row['root']))==row,row['root']
save('WORKTREES-BEFORE.json',prior+[inv.snapshot(T)]);print('PASS all 31 historical worktrees exact; active total 32',flush=True)
for name,command,cwd in [
 ('historical-overlays',[sys.executable,'-B',str(T/'docs/literature/handover-20261119/verify.py')],T),
 ('saved-native-arithmetic',[sys.executable,'-B',str(T/'tools/literature/verify_broad_gsea_native.py'),'--out',str(T/'build/gsea-high-impact-4/predecessor-arithmetic-readback-1')],T),
 ('saved-native-engine',[sys.executable,'-B',str(T/'tools/literature/verify_broad_gsea_engine_checkpoint.py')],T),
 ('catalog',[sys.executable,'-B',str(K/'tools/literature/close_edger_catalog.py'),'--verify','--primary-cache',str(R/'build/literature-review/xml'),'--out',str(K/'build/gsea-file-workflow-catalog-readback-1')],K)]:
    with (O/(name+'.stdout')).open('xb') as stdout,(O/(name+'.stderr')).open('xb') as stderr:
        p=subprocess.run(command,cwd=cwd,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=1200)
    save(name+'.PROCESS.json',dict(command=command,exit_code=p.returncode));assert p.returncode==0,'Inspect '+name+' logs'
    print('PASS fresh predecessor/current readback',name,flush=True)
canonical=json.loads((P/'CANONICAL-AFTER.json').read_bytes());assert len(canonical)==15
for n,w in canonical.items():
    raw=(T/n).read_bytes();assert dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())==w,n
save('CANONICAL-BEFORE.json',canonical);save('CANONICAL-AFTER.json',canonical)
save('READBACKS-COMPLETED.json',dict(status='PASS_31_PRIOR_WORKTREES_AND_FRESH_OVERLAY_NATIVE_ENGINE_AND_CATALOG_READBACKS',prior_worktrees=31,total_worktrees=32,canonical_files_unchanged=15))
