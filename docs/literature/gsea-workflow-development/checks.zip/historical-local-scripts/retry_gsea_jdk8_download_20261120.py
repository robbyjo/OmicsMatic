from pathlib import Path,PurePosixPath
import hashlib,json,re,stat,traceback,urllib.request,uuid,zipfile
B=Path('D:/projects/JLinAlg/build/gs-2/build/gsea-high-impact-2');P=B/'legacy-build-prereqs-1/jdk8-windows';O=B/'legacy-build-jdk8-2';O.mkdir(exist_ok=False)
def save(n,v):(O/n).write_bytes((json.dumps(v,indent=2)+'\n').encode())
def pin(p):
    with p.open('rb') as f:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
try:
    row=json.loads((P/'official-api.json').read_bytes())[0];package=row['binary']['package'];expected=package['checksum']
    assert (P/'official.sha256').read_text().split()[0]==expected
    previous=(P/'original.zip').read_bytes();title=re.search(br'<title>(.*?)</title>',previous,re.I|re.S)
    save('PREVIOUS-FAILED-INTAKE.json',dict(archive=pin(P/'original.zip'),expected_bytes=package['size'],expected_sha256=expected,
        valid_zip=zipfile.is_zipfile(P/'original.zip'),html_title=title[1].decode(errors='replace') if title else None,retained=True))
    url=package['link']+'?omicsmatic_private_intake='+uuid.uuid4().hex
    req=urllib.request.Request(url,headers={'User-Agent':'OmicsMatic-original-GSEA-private-build-intake','Cache-Control':'no-cache'})
    archive=O/'original.zip'
    with urllib.request.urlopen(req,timeout=90) as response,archive.open('xb') as f:
        save('HTTP-RESPONSE.json',dict(requested_url=url,status=response.status,headers=dict(response.headers)))
        size=0
        while chunk:=response.read(1024*1024):
            size+=len(chunk);assert size<=300000000;f.write(chunk)
    assert pin(archive)==dict(bytes=package['size'],sha256=expected),'Official exact size/hash mismatch; do not use the file.'
    files={};folder=O/'extracted';folder.mkdir()
    with zipfile.ZipFile(archive) as z:
        infos=z.infolist();assert len(infos)==len({i.filename for i in infos}) and len(infos)<50000 and sum(i.file_size for i in infos)<1500000000
        for i in infos:
            p=PurePosixPath(i.filename);assert not p.is_absolute() and '\\' not in i.filename and ':' not in i.filename and all(x not in ['.','..'] for x in p.parts)
            assert not stat.S_ISLNK(i.external_attr>>16)
            if i.is_dir():continue
            target=folder/p.as_posix();target.parent.mkdir(parents=True,exist_ok=True);raw=z.read(i);target.write_bytes(raw)
            files[p.as_posix()]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
    save('COMPLETED.json',dict(status='PASS_EXACT_OFFICIAL_PRIVATE_JDK8_INTAKE',api_source=pin(P/'official-api.json'),archive=pin(archive),
        package=package,files=files,system_install=False,global_environment_changed=False,previous_failed_attempt_preserved=True))
    print('PASS exact official JDK8 private intake',pin(archive),'files',len(files),flush=True)
except Exception as error:
    save('FAILURE.json',dict(error=repr(error),detail=traceback.format_exc()));raise
