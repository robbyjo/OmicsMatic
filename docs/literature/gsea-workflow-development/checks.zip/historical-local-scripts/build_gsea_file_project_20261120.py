from pathlib import Path
R=Path('D:/projects/JLinAlg')
s=(R/'build/build_native_gsea_project_20261120.py').read_text()
s=s.replace("H=R/'build/gs-2';B=H/'build/gsea-high-impact-2'","H=R/'build/gs-4';B=H/'build/gsea-high-impact-4'")
s=s.replace("'org.jlinalg.enrichment.BroadGseaStatisticsTest']","'org.jlinalg.enrichment.BroadGseaStatisticsTest','--tests','org.jlinalg.enrichment.BroadGseaEngineTest','--tests','org.jlinalg.cli.BroadGseaRecipeTest']")
exec(compile(s,str(Path(__file__)),'exec'))
