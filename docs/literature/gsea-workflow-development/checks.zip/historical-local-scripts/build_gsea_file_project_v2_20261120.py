from pathlib import Path
R=Path('D:/projects/JLinAlg');T=R/'build/gs-4';B=T/'build/gsea-high-impact-4'
import shutil
snapshot=B/'source-output-cap-correction-2';snapshot.mkdir(exist_ok=False)
for p in sorted((T/'src/main/java/org/jlinalg/cli').glob('BroadGsea*.java')):shutil.copyfile(p,snapshot/p.name)
shutil.copyfile(T/'src/test/java/org/jlinalg/cli/BroadGseaRecipeTest.java',snapshot/'BroadGseaRecipeTest.java')
s=(R/'build/build_native_gsea_project_20261120.py').read_text()
s=s.replace("H=R/'build/gs-2';B=H/'build/gsea-high-impact-2';O=B/'native-gradle-1'","H=R/'build/gs-4';B=H/'build/gsea-high-impact-4';O=B/'native-gradle-2'")
s=s.replace("'org.jlinalg.enrichment.BroadGseaStatisticsTest']","'org.jlinalg.enrichment.BroadGseaStatisticsTest','--tests','org.jlinalg.enrichment.BroadGseaEngineTest','--tests','org.jlinalg.cli.BroadGseaRecipeTest']")
exec(compile(s,str(Path(__file__)),'exec'))
