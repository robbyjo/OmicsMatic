from pathlib import Path
R=Path('D:/projects/JLinAlg')
s=(R/'build/publish_native_gsea_20261120_62.py').read_text()
changes={
"G=R/'build/gs-2';O=R/'build/git-publish/20261120-gsea-native-62'":"G=R/'build/gs-3';O=R/'build/git-publish/20261120-gsea-handover-63'",
"P=R/'build/git-publish/20261120-gsea-handover-61'":"P=R/'build/git-publish/20261120-gsea-native-62'",
"7a50e4a18d27e0bccd82d70b9a5632062abb3fc3":"7f4cc3185a642c61c7ab42b8b84a2630fac1fec7",
"=={'.gitattributes','docs/literature/HANDOVER_CURRENT.md'}":"=={'docs/literature/HANDOVER_CURRENT.md'}",
"len(trees)==30":"len(trees)==31",
"==345727":"==389663",
"inherited_artifacts=345727":"inherited_artifacts=389663",
"worktrees=30":"worktrees=31",
"worktrees_preserved=30":"worktrees_preserved=31",
"PASS_30_WORKTREES_AND_PROTECTED_ARTIFACTS":"PASS_31_WORKTREES_AND_PROTECTED_ARTIFACTS",
"NATIVE_BROAD_GSEA_ARITHMETIC":"NATIVE_GSEA_ENGINE_HANDOVER",
"native_Broad_GSEA_arithmetic_qualified=True,exact_field_checks_per_JVM=356286,source_bound_refusals_per_JVM=1701,JVMs=3,unchanged_predecessor_JAR_payloads=23485":"native_Broad_GSEA_arithmetic_qualified=True,native_Broad_GSEA_engine_qualified=True,exact_field_checks_per_JVM=668739,source_bound_refusals_per_JVM=201,JVMs=3,unchanged_predecessor_JAR_payloads=23490",
}
for old,new in changes.items():
    assert old in s,old
    s=s.replace(old,new)
path=R/'build/publish_gsea_engine_handover_20261120_63.py'
with path.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Prepared scoped no-force main publisher',path,flush=True)
