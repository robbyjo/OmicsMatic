from pathlib import Path
import json
R=Path('D:/projects/JLinAlg');B=R/'build/gs-4/build/gsea-high-impact-4'
reason=dict(previous='file-controls-1',reason='The intended heap-exhaustion fixture exceeded its separate input-byte limit before the worker launched; that correct FAIL2 is retained. Raise only this test input-byte limit to 32 MB so the declared 64 MiB worker heap is exercised. Preserve all previous controls. Linux uses the independently preflighted existing PyMOL Java21 environment after the original distribution compaction blocked launch. No production code changed.')
(B/'CONTROLS-RETRY-REASON.json').write_text(json.dumps(reason,indent=2)+'\n',encoding='utf-8')
s=(R/'build/qualify_gsea_file_controls_20261120.py').read_text().replace("O=B/'file-controls-1'","O=B/'file-controls-2'").replace('JLinAlg-Omics-SAIGE-20261026','JLinAlg-Omics-PyMOL-20261026')
s=s.replace("recipe['limits'].update(heap_mib=64,maximum_dense_cells=2000000)","recipe['limits'].update(heap_mib=64,maximum_dense_cells=2000000,maximum_input_bytes=32000000)")
exec(compile(s,str(Path(__file__)),'exec'))
