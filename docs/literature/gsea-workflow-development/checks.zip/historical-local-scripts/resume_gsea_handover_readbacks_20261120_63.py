from pathlib import Path
import hashlib,json,subprocess,sys
R=Path('D:/projects/JLinAlg');T=R/'build/gs-3';K=R/'build/edg-3';O=R/'build/git-publish/20261120-gsea-handover-63'
P=R/'build/git-publish/20261120-gsea-native-62'
def save(n,v):
    with (O/n).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert json.loads((O/'saved-native.PROCESS.json').read_bytes())['exit_code']==2
save('SAVED-NATIVE-RETRY-REASON.json',dict(previous='saved-native.PROCESS.json',reason='First invocation omitted the required --out argument; no scientific computation or evidence change occurred. Preserve the usage error and supply a NEW output directory.'))
for name,command,cwd in [
    ('saved-native-2',[sys.executable,'-B',str(T/'tools/literature/verify_broad_gsea_native.py'),'--out',str(T/'build/gsea-high-impact-3/predecessor-native-readback-1')],T),
    ('catalog',[sys.executable,'-B',str(K/'tools/literature/close_edger_catalog.py'),'--verify','--primary-cache',str(R/'build/literature-review/xml'),'--out',str(K/'build/gsea-engine-handover-catalog-readback-1')],K)]:
    with (O/(name+'.stdout')).open('xb') as stdout,(O/(name+'.stderr')).open('xb') as stderr:
        p=subprocess.run(command,cwd=cwd,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=1200)
    save(name+'.PROCESS.json',dict(command=command,exit_code=p.returncode));assert p.returncode==0,'Inspect '+name+' logs'
    print('PASS fresh readback',name,flush=True)
canonical=json.loads((P/'CANONICAL-AFTER.json').read_bytes());assert len(canonical)==15
for name,w in canonical.items():
    raw=(T/name).read_bytes();assert dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())==w,name
save('CANONICAL-BEFORE.json',canonical);save('CANONICAL-AFTER.json',canonical)
save('READBACKS-COMPLETED.json',dict(status='PASS_30_PRIOR_WORKTREES_OVERLAYS_NATIVE_AND_CATALOG_READBACKS',prior_worktrees=30,total_worktrees=31,canonical_files_unchanged=15,prior_reader_usage_error_retained_and_corrected=True))
