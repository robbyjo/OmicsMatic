from pathlib import Path
import json,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/gs-4';O=T/'examples/native-gsea';O.mkdir(exist_ok=False)
archive=R/'build/gs-3/docs/literature/gsea-engine-development/complete-null-references.zip'
with zipfile.ZipFile(archive) as z:files={n:z.read(n).decode() for n in z.namelist() if n.startswith('inputs/')}
def save(name,value):(O/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
gct=[line.split('\t') for line in files['inputs/expression.gct'].splitlines()];rnk=[line.split('\t') for line in files['inputs/ranks.rnk'].splitlines()]
sets=[dict(name=r[0],members=r[2:]) for line in files['inputs/sets.gmt'].splitlines() for r in [line.split('\t')]]
provenance=dict(organism='Synthetic source-counterpart fixture; no organism assigned',identifier_namespace='Literal synthetic G-prefixed gene identifiers',expression_units='Synthetic prepared float32 expression',universe_description='All 300 explicitly provided genes; no inferred background',gene_set_source='Five synthetic gene sets from the original-source qualification fixture',preparation_note='Synthetic validation only; no author data, identifier mapping or biological interpretation')
expression=dict(schema_version=1,genes=[r[0] for r in gct[3:]],samples=gct[2][2:],expression=[[float(x) for x in r[2:]] for r in gct[3:]],gene_sets=sets,provenance=provenance)
labels=files['inputs/groups.cls'].splitlines()[2].split();expression['class0']=[i for i,x in enumerate(labels) if x=='A'];expression['class1']=[i for i,x in enumerate(labels) if x=='B'];assert len(expression['class0'])==len(expression['class1'])==8
save('expression.json',expression)
save('preranked.json',dict(schema_version=1,genes=[r[0] for r in rnk],ranking_scores=[float(r[1]) for r in rnk],gene_sets=sets,provenance=dict(provenance,expression_units='Synthetic explicitly ordered float32 rank scores')))
limits=dict(maximum_input_bytes=10_000_000,maximum_output_bytes=1_000_000_000,maximum_files=1024,timeout_seconds=180,heap_mib=1024,maximum_dense_cells=1_000_000,maximum_null_cells=1_000_000,maximum_work_per_analysis=2_000_000_000,maximum_permutations=10000)
analyses=[]
for edition in ['4.4.0','4.3.2','4.3.3']:
    for form in ['PRERANKED','EXPRESSION_PHENOTYPE','EXPRESSION_GENE_SET']:
        a=dict(id=edition+'/'+form,input='preranked.json' if form=='PRERANKED' else 'expression.json',form=form,edition=edition,normalization='meandiv',permutations=10000,seed='12345',minimum_size=15,maximum_size=100,weight='WEIGHTED')
        if form!='PRERANKED':a['ranking']=dict(metric='SIGNAL_TO_NOISE',median=False,biased_variance=False,fix_low_variance=True,absolute_sort=False,ascending=False,class_of_interest=0)
        if form=='EXPRESSION_PHENOTYPE':a['randomization']='NO_BALANCE'
        analyses.append(a)
save('run.json',dict(schema_version=1,mode='RUN',engine='native-broad-gsea-source-core',out='run-out',limits=limits,analyses=analyses))
for mode in ['VERIFY','REPLAY']:save(mode.lower()+'.json',dict(schema_version=1,mode=mode,analysis='run-out',out=mode.lower()+'-out',limits=limits))
print('Prepared nine original-source counterpart examples',O,flush=True)
