from pathlib import Path
import json,subprocess,sys,traceback
R=Path('D:/projects/JLinAlg');B=R/'build/gs-2/build/gsea-high-impact-2';P=B/'original-synthetic-4.4.0-1'
O=B/'original-workflow-forms-4.4.0-2';O.mkdir(exist_ok=False)
# Preserve the first attempt verbatim; build a separate larger synthetic input.
source=(R/'build/run_gsea44_synthetic_20261120.py').read_text()
source=source.replace("O=B/'original-synthetic-4.4.0-1';O.mkdir(exist_ok=False);I=O/'inputs';I.mkdir()", "O=B/'original-workflow-forms-4.4.0-2';I=O/'inputs';I.mkdir()")
source=source.replace('range(50)','range(300)').replace('(25-i)*.375','(150-i)*.0375')
source=source.replace("list(range(8))","list(range(30))").replace('list(range(42,50))','list(range(270,300))')
source=source.replace('list(range(20,28))','list(range(130,170))').replace('list(range(0,50,5))','list(range(0,300,6))').replace('list(range(8,20))','list(range(30,75))')
source=source.replace("sample_names=['A1','A2','A3','B1','B2','B3']", "sample_names=['A'+str(i+1) for i in range(8)]+['B'+str(i+1) for i in range(8)]")
source=source.replace("'50\\t6'", "'300\\t16'").replace('j<3','j<8').replace('(24.5-i)*.16','(149.5-i)*.016').replace('range(6)','range(16)')
source=source.replace("'6 2 1\\n# A B\\nA A A B B B\\n'", "'16 2 1\\n# A B\\nA A A A A A A A B B B B B B B B\\n'")
source=source.replace("'-nperm','200'", "'-nperm','10000'").replace("'-set_min','5','-set_max','20'", "'-set_min','15','-set_max','100'")
source=source.replace("OBSERVED_THREE_ORIGINAL_GSEA44_SYNTHETIC_EXECUTIONS", "OBSERVED_THREE_ORIGINAL_GSEA44_TEN_THOUSAND_PERMUTATION_WORKFLOW_FORMS")
generated=O/'original_synthetic_driver.py';generated.write_text(source,encoding='utf-8',newline='\n')
(O/'CHANGE-REASON.json').write_text(json.dumps(dict(previous=str(P),previous_retained=True,
    reason='The original phenotype test requires numMarkers <= dataset rows. The first 50-row synthetic test requested 100 markers and failed. This independent 300-row, 16-sample synthetic request retains 100 markers and tests 10000 permutations explicitly.',
    paper_data=False,paper_options_inferred=False,source_modified=False),indent=2)+'\n',encoding='utf-8',newline='\n')
p=subprocess.run([sys.executable,'-X','utf8','-B',str(generated)],stdin=subprocess.DEVNULL)
assert p.returncode==0
