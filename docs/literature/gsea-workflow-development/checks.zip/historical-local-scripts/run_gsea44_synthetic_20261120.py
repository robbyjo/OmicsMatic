from pathlib import Path
import hashlib,json,subprocess,time,traceback,xml.etree.ElementTree as ET
R=Path('D:/projects/JLinAlg');H=R/'build/gs-2';B=H/'build/gsea-high-impact-2'
F=R/'build/gs-1/build/gsea-high-impact-1/runtime-source-4.4.0-1'
O=B/'original-synthetic-4.4.0-1';O.mkdir(exist_ok=False);I=O/'inputs';I.mkdir()
JAVA='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe'
def enc(v):return (json.dumps(v,indent=2)+'\n').encode()
def save(p,v):p.write_bytes(enc(v))
def pin(p):
    with p.open('rb') as f:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
try:
    profile=json.loads((F/'PROFILE.json').read_bytes())
    for name,wanted in profile['files'].items():assert pin(F/name)==wanted,name
    names=['G'+str(i).zfill(3) for i in range(50)]
    (I/'ranks.rnk').write_text(''.join(g+'\t'+format((25-i)*.375+(i%3)*.0001,'.8f')+'\n' for i,g in enumerate(names)),encoding='utf-8',newline='\n')
    sets={'UP':list(range(8)),'DOWN':list(range(42,50)),'MIDDLE':list(range(20,28)),
          'MIXED':list(range(0,50,5)),'SHIFT':list(range(8,20))}
    (I/'sets.gmt').write_text(''.join(k+'\tsynthetic\t'+'\t'.join(names[i] for i in indices)+'\n' for k,indices in sets.items()),encoding='utf-8',newline='\n')
    sample_names=['A1','A2','A3','B1','B2','B3']
    gct=['#1.2','50\t6','NAME\tDESCRIPTION\t'+'\t'.join(sample_names)]
    for i,g in enumerate(names):
        expression=[5+(i%7)*.1+(.5 if j<3 else -.5)*(24.5-i)*.16+(j-2)*.03+(i%5)*j*.007 for j in range(6)]
        gct.append(g+'\tsynthetic\t'+'\t'.join(format(x,'.8f') for x in expression))
    (I/'expression.gct').write_text('\n'.join(gct)+'\n',encoding='utf-8',newline='\n')
    (I/'groups.cls').write_text('6 2 1\n# A B\nA A A B B B\n',encoding='utf-8',newline='\n')
    input_pins={p.name:pin(p) for p in I.iterdir()};save(O/'INPUTS.json',input_pins)
    results=[]
    for label,operation,options in [
        ('preranked','GSEAPreranked',['-rnk',str(I/'ranks.rnk')]),
        ('expression-phenotype','GSEA',['-res',str(I/'expression.gct'),'-cls',str(I/'groups.cls')+'#A_versus_B',
            '-permute','phenotype','-rnd_type','no_balance','-metric','Signal2Noise','-sort','real','-order','descending',
            '-median','false','-num','100','-save_rnd_lists','true','-create_gcts','false']),
        ('expression-geneset','GSEA',['-res',str(I/'expression.gct'),'-cls',str(I/'groups.cls')+'#A_versus_B',
            '-permute','gene_set','-rnd_type','no_balance','-metric','Signal2Noise','-sort','real','-order','descending',
            '-median','false','-num','100','-save_rnd_lists','true','-create_gcts','false'])]:
        folder=O/label;folder.mkdir();cwd=folder/'worker';cwd.mkdir();home=folder/'home';home.mkdir();out=folder/'reports'
        command=[JAVA,'-Xmx1g','-Djava.awt.headless=true','-Duser.home='+str(home),'-Djava.util.logging.config.file='+str(F/'logging.properties'),
            '--module-path',str(F/'modules'),'--module','org.gsea_msigdb.gsea/xapps.gsea.CLI',operation,*options,
            '-gmx',str(I/'sets.gmt'),'-nperm','200','-collapse','No_Collapse','-norm','meandiv','-scoring_scheme','weighted',
            '-set_min','5','-set_max','20','-rnd_seed','12345','-make_sets','false','-plot_top_x','0','-create_svgs','false',
            '-zip_report','false','-include_only_symbols','false','-run_as_genepattern','false','-dev_mode','true','-out',str(out),'-rpt_label','synthetic_'+label.replace('-','_')]
        save(folder/'COMMAND.json',dict(command=command,cwd=str(cwd),input_pins=input_pins,synthetic=True,paper_replication=False))
        start=time.monotonic()
        with (folder/'stdout').open('xb') as stdout,(folder/'stderr').open('xb') as stderr:
            p=subprocess.Popen(command,cwd=cwd,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr);save(folder/'PROCESS.json',dict(pid=p.pid,command=command))
            try:code=p.wait(timeout=180)
            except subprocess.TimeoutExpired:p.kill();code=p.wait();save(folder/'TIMEOUT.json',dict(timeout_seconds=180,exit_code=code));raise
        save(folder/'PROCESS-EXIT.json',dict(exit_code=code,seconds=time.monotonic()-start))
        print(label,'original exit',code,flush=True)
        for name,wanted in input_pins.items():assert pin(I/name)==wanted,name
        for name,wanted in profile['files'].items():assert pin(F/name)==wanted,name
        edbs=list(out.rglob('results.edb')) if out.exists() else []
        summary=[]
        for edb in edbs:
            tree=ET.fromstring(edb.read_bytes())
            summary.extend(dict(row.attrib) for row in tree.findall('DTG'))
        save(folder/'OUTPUT-OBSERVATIONS.json',dict(exit_code=code,edb_count=len(edbs),edb_rows=len(summary),rows=summary,
            files={p.relative_to(folder).as_posix():pin(p) for p in folder.rglob('*') if p.is_file() and p.name!='OUTPUT-OBSERVATIONS.json'}))
        results.append(dict(label=label,exit_code=code,edb_count=len(edbs),edb_rows=len(summary)))
    save(O/'COMPLETED.json',dict(status='OBSERVED_THREE_ORIGINAL_GSEA44_SYNTHETIC_EXECUTIONS',results=results,
        source_and_runtime_unchanged=True,statistical_independent_validation_complete=False,new_catalog_credit=0))
    print(json.dumps(results,indent=2),flush=True)
except Exception as error:
    save(O/'FAILURE.json',dict(error=repr(error),detail=traceback.format_exc()));raise
