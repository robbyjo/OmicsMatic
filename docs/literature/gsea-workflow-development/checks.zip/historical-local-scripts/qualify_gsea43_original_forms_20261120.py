from pathlib import Path
import concurrent.futures,hashlib,json,shutil,subprocess,traceback,xml.etree.ElementTree as ET
R=Path('D:/projects/JLinAlg');H=R/'build/gs-2';B=H/'build/gsea-high-impact-2';O=B/'original-4.3-profiles-1';O.mkdir(exist_ok=False)
S=R/'build/gs-1/build/gsea-high-impact-1/source-intake-1/4.3.2/source'
J=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin');I=B/'original-workflow-forms-4.4.0-2/inputs'
def save(p,v):p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
def pin(p):
    with p.open('rb') as f:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
def run(command,folder):
    folder.mkdir();home=folder/'home';home.mkdir();cwd=folder/'worker';cwd.mkdir()
    command=[str(J/'java.exe'),'-Xmx1g','-Djava.awt.headless=true','-Duser.home='+str(home),'-DMAKE_GSEA_UPDATE_CHECK=false',*command]
    save(folder/'COMMAND.json',dict(command=command,cwd=str(cwd)))
    with (folder/'stdout').open('xb') as stdout,(folder/'stderr').open('xb') as stderr:
        p=subprocess.Popen(command,cwd=cwd,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr);save(folder/'PROCESS.json',dict(pid=p.pid))
        try:code=p.wait(timeout=240)
        except subprocess.TimeoutExpired:p.kill();p.wait();save(folder/'TIMEOUT.json',dict(limit_seconds=240));raise
    save(folder/'PROCESS-EXIT.json',dict(exit_code=code));assert code==0,'Inspect retained process stderr: '+str(folder)
def task(version):
    folder=O/version;folder.mkdir();runtime=folder/'runtime';runtime.mkdir()
    for name in ['modules','lib']:
        (runtime/name).mkdir()
        for path in (S/name).glob('*.jar'):shutil.copyfile(path,runtime/name/path.name)
    jar=B/'original-build-4.3-source-1'/version/('project-build/libs/gsea-minimal-'+version+'.jar')
    (runtime/'producer').mkdir();shutil.copyfile(jar,runtime/'producer'/jar.name)
    for name in ['LICENSE.txt','LICENSE-3RD-PARTY.txt']:shutil.copyfile(S/name,runtime/name)
    profile=dict(source_commit='e1ae61cd83ddb14878ece6388b9c1da92594a4c1',source_tag='v'+version,local_source_build=True,
        vendor_binary=False,files={p.relative_to(runtime).as_posix():pin(p) for p in runtime.rglob('*') if p.is_file()},
        build_JDK='Linux cached OpenJDK11',build_Gradle='4.10.2',execution_JDK='Windows21',qualified_project_workflow=False)
    save(folder/'PROFILE.json',profile)
    cp=';'.join(str(runtime/(name+'/*')) for name in ['modules','lib','producer'])
    classes=folder/'classes';classes.mkdir()
    sources=[H/'tools/literature/gsea_original'/name for name in ['OriginalGseaProbe.java','OriginalPrimitiveProbe.java']]
    command=[str(J/'javac.exe'),'--release','17','-cp',cp,'-d',str(classes),*[str(p) for p in sources]]
    p=subprocess.run(command,capture_output=True);(folder/'javac.stdout').write_bytes(p.stdout);(folder/'javac.stderr').write_bytes(p.stderr);assert p.returncode==0
    for source in sources:shutil.copyfile(source,folder/source.name)
    results=[]
    for mode in ['preranked','expression-phenotype','expression-geneset']:
        cli=folder/('cli-'+mode)
        old=json.loads((B/'original-workflow-forms-4.4.0-2'/mode/'COMMAND.json').read_bytes())['command']
        op='GSEAPreranked' if mode=='preranked' else 'GSEA';options=old[old.index(op)+1:]
        options[options.index('-out')+1]=str(cli/'reports')
        run(['-cp',cp,'xapps.gsea.CLI',op,*options],cli)
        api=folder/('api-'+mode)
        run(['-Dprobe.output='+str(api/'original.tsv'),'-cp',cp+';'+str(classes),'OriginalGseaProbe',mode,
            str(I/('ranks.rnk' if mode=='preranked' else 'expression.gct')),str(I/'groups.cls')+'#A_versus_B',
            str(I/'sets.gmt'),'10000','12345','15','100'],api)
        lines=[x.split('\t') for x in (api/'original.tsv').read_text().splitlines()]
        scores={x[1]:x[2:] for x in lines if x[0]=='SCORE'}
        root=ET.fromstring(next((cli/'reports').rglob('results.edb')).read_bytes());comparisons=[]
        for row in root.findall('DTG'):
            name=row.get('GENESET').split('#')[-1]
            for i,field in enumerate(['ES','NES','NP','FDR','FWER']):
                assert abs(float(scores[name][i])-float(row.get(field)))<=.0000501,(version,mode,name,field)
                comparisons.append(dict(set=name,field=field,full_float=scores[name][i],cli_four_decimals=row.get(field)))
        save(api/'CLI-COMPARISONS.json',dict(status='PASS_ORIGINAL_API_AND_CLI_AT_SOURCE_EXPORT_PRECISION',comparisons=comparisons))
        results.append(dict(mode=mode,sets=len(scores),cli_fields=len(comparisons),original=pin(api/'original.tsv')))
        print('PASS original',version,mode,'10000 perms/full API/CLI',flush=True)
    run(['-cp',cp+';'+str(classes),'OriginalPrimitiveProbe',str(folder/'primitives/original-primitives.tsv')],folder/'primitives')
    for name,w in profile['files'].items():assert pin(runtime/name)==w,name
    save(folder/'COMPLETED.json',dict(status='PASS_THREE_ORIGINAL_TEN_THOUSAND_PERMUTATION_FORMS_AND_API_CLI_COUNTERPARTS',
        results=results,source_and_runtime_unchanged=True,project_adapter_qualified=False))
    return version,results
try:
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=dict(pool.map(task,['4.3.2','4.3.3']))
    save(O/'COMPLETED.json',dict(status='PASS_ORIGINAL_GSEA43_SOURCE_PROFILES_AND_WORKFLOW_FORMS',results=results,new_catalog_credit=0))
except Exception as error:
    save(O/'FAILURE.json',dict(error=repr(error),detail=traceback.format_exc()));raise
