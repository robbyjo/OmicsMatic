from pathlib import Path
R=Path('D:/projects/JLinAlg')
for source,target in [
 ('qualify_gsea_file_hosts_20261120.py','qualify_gsea_file_final_hosts_20261120.py'),
 ('qualify_gsea_file_controls_20261120.py','qualify_gsea_file_final_controls_20261120.py'),
 ('qualify_gsea_file_transport_20261120.py','qualify_gsea_file_final_transport_20261120.py')]:
    s=(R/'build'/source).read_text().replace('native-gradle-2','native-gradle-3').replace('JLinAlg-Omics-SAIGE-20261026','JLinAlg-Omics-PyMOL-20261026')
    s=s.replace("O=B/'file-hosts-qualification-1'","O=B/'file-hosts-qualification-3'").replace("O=B/'file-controls-1'","O=B/'file-controls-3'").replace("O=B/'file-transport-1'","O=B/'file-transport-3'").replace("B/'file-controls-2", "B/'file-controls-3")
    s=s.replace("recipe['limits'].update(heap_mib=64,maximum_dense_cells=2000000)","recipe['limits'].update(heap_mib=64,maximum_dense_cells=2000000,maximum_input_bytes=32000000)")
    with (R/'build'/target).open('x',encoding='utf-8',newline='\n') as f:f.write(s)
    print('Prepared final-producer qualifier',target,flush=True)
