from pathlib import Path
import hashlib, json, shutil, subprocess, sys
R = Path('D:/projects/JLinAlg'); G = R/'build/gs-1'; K = R/'build/edg-3'
B = G/'build/gsea-high-impact-1'; O = B/'handover-readback-1'; Q = G/'docs/literature/gsea-handover-20261120'
OUT = K/'build/gsea-handover-20261120-catalog-2'
def pin(p):
    with Path(p).open('rb') as f:return dict(bytes=Path(p).stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
def save(p,v):
    with Path(p).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
command=[sys.executable,'-B',str(K/'tools/literature/close_edger_catalog.py'),'--verify','--primary-cache',
    str(R/'build/literature-review/xml'),'--out',str(OUT)]
with (O/'catalog-owned.stdout').open('xb') as stdout,(O/'catalog-owned.stderr').open('xb') as stderr:
    p=subprocess.run(command,cwd=K,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=900)
record=dict(command=command,exit_code=p.returncode,stdout=pin(O/'catalog-owned.stdout'),stderr=pin(O/'catalog-owned.stderr'),fresh_scientific_fit=False)
save(O/'catalog-owned-PROCESS.json',record)
assert p.returncode==0,'Inspect retained catalog-owned.stderr'
for name in ['global','old-overlays']:
    assert json.loads((O/(name+'-PROCESS.json')).read_bytes())['exit_code']==0
canonical=json.loads((Q/'CANONICAL-BASELINE.json').read_bytes())
for name,wanted in canonical['files'].items():assert pin(G/name)==wanted==pin(K/name),name
build=json.loads((Q/'BUILD44-COMPLETED.json').read_bytes())
profile=json.loads((Q/'RUNTIME44-PROFILE.json').read_bytes())
readbacks={name:json.loads((O/(name+'-PROCESS.json')).read_bytes()) for name in ['global','old-overlays']}
readbacks['catalog']=record
for label,source in [('EDGER-GLOBAL-READBACK.json',O/'global/COMPLETED.json'),('EDGER-CATALOG-READBACK.json',OUT/'COMPLETED.json')]:
    shutil.copyfile(source,Q/label)
save(Q/'READBACK.json',dict(status='PASS_UNCHANGED_CANONICAL_SOURCE_INTAKES_BUILD_RUNTIME_AND_SAVED_EDGER_PROOF',
    base=canonical['base'],papers_rehashed=250,source_files_rehashed={'4.4.0':698,'4.3.2':711},source_archives_rehashed=2,
    source_jar_rehashed=build['producer'],runtime_files_rehashed=len(profile['files']),source_modified=False,catalog_modified=False,
    new_family_credit=0,new_GSEA_reviews=0,GSEA_statistical_execution_qualified=False,
    help_preflight=[dict(operation=n,exit_code=1,disposition='UNSUPPORTED_HELP_FLAG_NOT_A_STATISTICAL_ANALYSIS',statistical_analysis_run=False)
        for n in ['GSEA','GSEAPreranked']],
    readbacks=readbacks,retained_failed_check=dict(process=str(O/'catalog-PROCESS.json'),exit_code=2,
        reason='Guard refused output outside exact owning checkout build directory; rerun uses a NEW owned output.',
        scientific_analysis_attempted=False),fresh_scientific_fit=False,whole_goal_complete=False))
save(O/'COMPLETED.json',dict(status='PASS_CURRENT_HANDOVER_SOURCE_AND_SAVED_PROOF_READBACK',public_packet=str(Q),
    canonical_files_unchanged=len(canonical['files']),catalog_rerun_output=str(OUT),first_refusal_retained=True))
print('PASS unchanged canonical, original source/build/runtime and saved proof readbacks',flush=True)
