from pathlib import Path
import concurrent.futures,hashlib,json,os,subprocess,zipfile
R=Path('D:/projects/JLinAlg');H=R/'build/gs-2';B=H/'build/gsea-high-impact-2';O=B/'native-packaged-qualification-1';O.mkdir(exist_ok=False)
JAR=B/'native-gradle-1/project-build/cli/omicsmatic-0.4.0.jar'
OLD=R/'build/edg-3/build/edger-admission-1/dispatch-gradle-1/project-build/cli/omicsmatic-0.4.0.jar'
J21=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin');J25=Path('C:/Program Files/Java/jdk-25/bin')
def enc(v):return (json.dumps(v,indent=2)+'\n').encode()
def save(p,v):p.write_bytes(enc(v))
def pin(p):
    with p.open('rb') as f:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
def linux(p):return '/mnt/d/'+str(p.relative_to(Path('D:/'))).replace('\\','/')
assert json.loads((B/'native-gradle-1/PROCESS-EXIT.json').read_bytes())['exit_code']==0
assert pin(OLD)['sha256']=='9bfd2d8fa5eefcf2555f4d584580779061fd83082184a79992e94f945614ab4c'
with zipfile.ZipFile(OLD) as old,zipfile.ZipFile(JAR) as new:
    old_names=set(old.namelist());new_names=set(new.namelist());assert old_names<=new_names
    changed=[]
    for name in sorted(old_names):
        if old.read(name)!=new.read(name):changed.append(name)
    assert changed==[],changed
    added=sorted(new_names-old_names)
    assert all(n.startswith('org/jlinalg/enrichment/BroadGseaStatistics') and n.endswith('.class')
        or n=='META-INF/licenses/GSEA-DESKTOP-LICENSE.txt' for n in added),added
    members={n:dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()) for n in new.namelist() for raw in [new.read(n)]}
save(O/'PRODUCER.json',dict(jar=str(JAR),producer=pin(JAR),members=members,unchanged_predecessor_members=len(old_names),
    added_members=added,prior_producer=pin(OLD),scientific_predecessor_payloads_unchanged=True))
classes=O/'checker-classes';classes.mkdir()
names=['CheckNativeBroadGsea.java','CheckNativeBroadPrimitives.java','PackagedNativeChecks.java']
command=[str(J21/'javac.exe'),'--release','17','-cp',str(JAR),'-d',str(classes),*[str(H/'tools/literature/gsea_original'/n) for n in names]]
p=subprocess.run(command,capture_output=True);(O/'javac.stdout').write_bytes(p.stdout);(O/'javac.stderr').write_bytes(p.stderr);assert p.returncode==0
assert {p.name for p in classes.rglob('*.class')}=={'CheckNativeBroadGsea.class','CheckNativeBroadPrimitives.class','PackagedNativeChecks.class'}
api=[B/'original-api-4.4.0-3'/mode/'original.tsv' for mode in ['preranked','expression-phenotype','expression-geneset']]
primitives=[B/'original-primitives-1/original-primitives.tsv']
for version in ['4.3.2','4.3.3']:
    api.extend(B/'original-4.3-profiles-1'/version/('api-'+mode)/'original.tsv' for mode in ['preranked','expression-phenotype','expression-geneset'])
    primitives.append(B/'original-4.3-profiles-1'/version/'primitives/original-primitives.tsv')
before={str(p):pin(p) for p in [JAR,*api,*primitives]}
def task(host):
    folder=O/host;folder.mkdir()
    if host=='linux-java21':
        command=['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--exec','/usr/bin/java','-Xmx1g',
            '-Domicsmatic.expected.jar='+linux(JAR),'-cp',linux(JAR)+':'+linux(classes),'PackagedNativeChecks',
            *[linux(p) for p in api],'--primitives',*[linux(p) for p in primitives]]
    else:
        java=J21 if host=='windows-java21' else J25
        command=[str(java/'java.exe'),'-Xmx1g','-Domicsmatic.expected.jar='+str(JAR),'-cp',str(JAR)+';'+str(classes),
            'PackagedNativeChecks',*[str(p) for p in api],'--primitives',*[str(p) for p in primitives]]
    with (folder/'stdout').open('xb') as stdout,(folder/'stderr').open('xb') as stderr:
        p=subprocess.run(command,cwd=folder,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=180)
    save(folder/'PROCESS.json',dict(command=command,exit_code=p.returncode,native_production_class_from_exact_normal_JAR=True))
    assert p.returncode==0,'Inspect retained qualification logs '+host
    output=(folder/'stdout').read_text()
    assert 'PASS_NATIVE_BROAD_GSEA_ORIGINAL_OBJECT_COMPARISONS\t17325' in output
    assert 'comparisons=338961\twalks=2415\tfamilies=444\twalkRefusals=1425\tfamilyRefusals=276' in output
    assert 'PASS_EXACT_NORMAL_JAR_NATIVE_ONLY_SOURCE_ORIGIN' in output
    print('PASS packaged native GSEA',host,'356286 exact field checks +1701 source-bound refusals',flush=True)
    return host,dict(exit_code=0,exact_field_checks=356286,source_bound_refusals=1701,original_runtime_on_classpath=False)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=dict(pool.map(task,['windows-java21','windows-java25','linux-java21']))
for name,wanted in before.items():assert pin(Path(name))==wanted,name
save(O/'COMPLETED.json',dict(status='PASS_NORMAL_JAR_NATIVE_BROAD_GSEA_ARITHMETIC_THREE_JVMS_AND_ORIGINAL_SOURCE_COUNTERPARTS',
    producer=pin(JAR),unchanged_predecessor_members=len(old_names),added_members=added,results=results,new_catalog_credit=0,
    original_CLI_API_comparisons=225,project_RUN_VERIFY_REPLAY_qualified=False,author_data_or_hosts_reproduced=False))
