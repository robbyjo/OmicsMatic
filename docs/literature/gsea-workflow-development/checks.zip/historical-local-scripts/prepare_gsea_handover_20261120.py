from pathlib import Path
import concurrent.futures, copy, gzip, hashlib, importlib.util, json, os, shutil, subprocess, sys

R = Path('D:/projects/JLinAlg')
G = R / 'build/gs-1'
K = R / 'build/edg-3'
B = G / 'build/gsea-high-impact-1'
P = R / 'build/git-publish/20261120-edger-admission-60'
O = B / 'handover-readback-1'
Q = G / 'docs/literature/gsea-handover-20261120'
BASE = '0de612c6182b87d42a1d574af5f06a99630a0924'
PYTHON = sys.executable
O.mkdir(exist_ok=False)
Q.mkdir(exist_ok=False)

def enc(v):
    return (json.dumps(v, indent=2, ensure_ascii=False) + '\n').encode()

def save(path, v):
    Path(path).write_bytes(enc(v))

def pin(path):
    with Path(path).open('rb') as stream:
        return dict(bytes=Path(path).stat().st_size, sha256=hashlib.file_digest(stream, 'sha256').hexdigest())

def git(root, *args):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=root)

assert git(G, 'rev-parse', 'HEAD').decode().strip() == BASE
assert not git(G, 'status', '--porcelain=v1', '-z', '--untracked-files=all')
assert git(G, 'ls-remote', 'origin', 'refs/heads/main').decode().split()[0] == BASE
canonical = json.loads((P / 'CANONICAL-AFTER.json').read_bytes())
for name, wanted in canonical.items():
    assert pin(G / name) == wanted, name
save(Q / 'CANONICAL-BASELINE.json', dict(base=BASE, files=canonical, catalog_mutated=False))

# All private source paragraphs stay local. Publish only identities and locating hashes.
intake = json.loads((B / 'source-census-intake-1/CANDIDATES.json').read_bytes())
candidate = copy.deepcopy(intake)
candidate['private_full_text_included'] = False
for row in candidate['candidates']:
    observation = row.pop('existing_observation')
    row['existing_observation_present'] = observation is not None
    for anchor in row['anchors']:
        anchor.pop('text')
save(Q / 'CANDIDATE-ANCHORS.json', candidate)
assert candidate['papers_scanned'] == 250 and len(candidate['candidates']) == 50
for identity in candidate['source_identities']:
    with gzip.open(R / 'build/literature-review/xml' / (identity['pmcid'] + '.xml.gz'), 'rb') as stream:
        raw = stream.read(64 * 1024 * 1024 + 1)
    assert len(raw) <= 64 * 1024 * 1024
    assert hashlib.sha256(raw).hexdigest() == identity['xml_sha256'], identity['paper_id']

for version, files in [('4.4.0', 698), ('4.3.2', 711)]:
    folder = B / 'source-intake-1' / version
    source = json.loads((folder / 'COMPLETED.json').read_bytes())
    assert source['source_files'] == files and len(source['files']) == files
    assert pin(folder / 'original-source.zip') == source['archive']
    for name, wanted in source['files'].items():
        assert pin(folder / 'source' / name) == wanted, (version, name)
    save(Q / ('SOURCE-' + version + '.json'), source)

build = B / 'original-build-4.4.0-1'
producer = json.loads((build / 'PRODUCER.json').read_bytes())
assert pin(producer['jar']) == producer['jar_pin']
for name in ['COMPLETED.json', 'COMMAND.json', 'PRODUCER.json', 'PROCESS-EXIT.json']:
    shutil.copyfile(build / name, Q / ('BUILD44-' + name))
for name in ['gradle.stdout', 'gradle.stderr']:
    shutil.copyfile(build / name, Q / ('BUILD44-' + name))
profile = json.loads((B / 'runtime-source-4.4.0-1/PROFILE.json').read_bytes())
assert profile['qualified_statistical_execution'] is False
for name, wanted in profile['files'].items():
    assert pin(B / 'runtime-source-4.4.0-1' / name) == wanted, name
save(Q / 'RUNTIME44-PROFILE.json', profile)
shutil.copyfile(B / 'source-intake-1/4.4.0/source/LICENSE.txt', Q / 'GSEA-LICENSE.txt')
tags = json.loads((B / 'upstream-metadata-1/tags.json').read_bytes())
save(Q / 'OFFICIAL-TAGS.json', dict(repository='https://github.com/GSEA-MSigDB/gsea-desktop',
    retrieved_metadata=pin(B / 'upstream-metadata-1/tags.json'),
    tags={row['name']: row['commit']['sha'] for row in tags},
    note='Tags v4.3.2 and v4.3.3 share a source commit; vendor binary identity is not established.'))

help_results = []
for operation in ['GSEA', 'GSEAPreranked']:
    folder = B / 'preflight-4.4.0-1' / operation
    process = json.loads((folder / 'PROCESS.json').read_bytes())
    assert process['exit_code'] == 1
    assert b'Unrecognized option: -help' in (folder / 'stderr').read_bytes() + (folder / 'stdout').read_bytes()
    for name in ['PROCESS.json', 'stdout', 'stderr']:
        shutil.copyfile(folder / name, Q / (operation + '-' + name))
    help_results.append(dict(operation=operation, exit_code=1,
        disposition='UNSUPPORTED_HELP_FLAG_NOT_A_STATISTICAL_ANALYSIS', statistical_analysis_run=False))

helpers = ['start_gsea_20261120.py', 'intake_gsea_census_20261120.py',
    'intake_gsea_metadata_20261120.py', 'intake_gsea_sources_20261120.py',
    'build_gsea44_original_20261120.py', 'preflight_gsea44_20261120.py']
(Q / 'original-helpers').mkdir()
for name in helpers:
    shutil.copyfile(R / 'build' / name, Q / 'original-helpers' / name)

checks = [
    ('global', [PYTHON, '-B', str(K / 'tools/literature/verify_edger_dispatch.py'), '--out', str(O / 'global')]),
    ('catalog', [PYTHON, '-B', str(K / 'tools/literature/close_edger_catalog.py'), '--verify', '--primary-cache',
        str(R / 'build/literature-review/xml'), '--out', str(O / 'catalog')]),
    ('old-overlays', [PYTHON, '-B', str(G / 'docs/literature/handover-20261119/verify.py')]),
]

def run_check(row):
    name, command = row
    with (O / (name + '.stdout')).open('xb') as stdout, (O / (name + '.stderr')).open('xb') as stderr:
        process = subprocess.run(command, cwd=K, stdout=stdout, stderr=stderr, stdin=subprocess.DEVNULL, timeout=900)
    record = dict(command=command, exit_code=process.returncode, stdout=pin(O / (name + '.stdout')),
        stderr=pin(O / (name + '.stderr')), fresh_scientific_fit=False)
    save(O / (name + '-PROCESS.json'), record)
    print(name, 'readback exit', process.returncode, flush=True)
    return name, record

with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    readbacks = dict(pool.map(run_check, checks))
assert all(row['exit_code'] == 0 for row in readbacks.values()), 'Inspect saved readback stderr; preserve the attempt.'
for name, wanted in canonical.items():
    assert pin(G / name) == wanted == pin(K / name), name
save(Q / 'READBACK.json', dict(status='PASS_UNCHANGED_CANONICAL_SOURCE_INTAKES_BUILD_RUNTIME_AND_SAVED_EDGER_PROOF',
    base=BASE, papers_rehashed=250, source_files_rehashed={'4.4.0': 698, '4.3.2': 711},
    source_archives_rehashed=2, source_jar_rehashed=producer['jar_pin'], runtime_files_rehashed=len(profile['files']),
    source_modified=False, catalog_modified=False, new_family_credit=0, new_GSEA_reviews=0,
    GSEA_statistical_execution_qualified=False, help_preflight=help_results, readbacks=readbacks,
    fresh_scientific_fit=False, whole_goal_complete=False))
save(O / 'COMPLETED.json', dict(status='PASS_CURRENT_HANDOVER_SOURCE_AND_SAVED_PROOF_READBACK',
    public_packet=str(Q), public_files_so_far=len(list(Q.rglob('*'))), canonical_files_unchanged=len(canonical)))
print('PASS source/build/runtime/canonical and predecessor proof readbacks', flush=True)
