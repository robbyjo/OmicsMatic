from pathlib import Path
import json,shutil,subprocess
R=Path('D:/projects/JLinAlg');T=R/'build/gs-4';B=T/'build/gsea-high-impact-4';O=B/'compile-1';O.mkdir(exist_ok=False)
J=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin')
OLD=R/'build/gs-3/build/gsea-high-impact-3/native-gradle-1/project-build/cli/omicsmatic-0.4.0.jar'
sources=sorted((T/'src/main/java/org/jlinalg/cli').glob('BroadGsea*.java'));assert len(sources)==6
for p in sources:shutil.copyfile(p,O/p.name)
classes=O/'classes';classes.mkdir()
command=[str(J/'javac.exe'),'--release','17','-cp',str(OLD),'-d',str(classes),*[str(p) for p in sources]]
p=subprocess.run(command,capture_output=True);(O/'stdout').write_bytes(p.stdout);(O/'stderr').write_bytes(p.stderr)
(O/'PROCESS.json').write_text(json.dumps(dict(command=command,exit_code=p.returncode),indent=2)+'\n',encoding='utf-8')
print(p.stderr.decode(errors='replace'),flush=True);print('Native GSEA file workflow compilation exit',p.returncode,flush=True)
assert p.returncode==0
