from pathlib import Path
import hashlib,importlib.util,json,os,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/gs-4';B=T/'build/gsea-high-impact-4';Q=T/'docs/literature/gsea-workflow-development';O=B/'public-file-proof-1';O.mkdir(exist_ok=False)
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def enc(v):return (json.dumps(v,indent=2)+'\n').encode()
files={};binaries={};mapping={}
def add(name,path):
    assert name not in files,name;files[name]=Path(path).read_bytes()
def tree(name,root):
    for directory,dirs,names in os.walk(root,followlinks=False):
        dirs[:]=[n for n in dirs if not (Path(directory)/n).is_symlink() and not (Path(directory)/n).is_junction()]
        for n in names:
            p=Path(directory)/n
            if p.is_symlink():continue
            add(name+'/'+p.relative_to(root).as_posix(),p)
def archive(path,values):
    with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for n,raw in sorted(values.items()):
            i=zipfile.ZipInfo(n,(2026,11,20,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16;z.writestr(i,raw)
hosts=B/'file-hosts-qualification-3';controls=B/'file-controls-3';transport=B/'file-transport-3';gradle=B/'native-gradle-3'
for path,status in [(hosts,'PASS_NATIVE_GSEA_FILE_WORKFLOW_ORIGINAL_COMPARISONS_THREE_JVMS'),(controls,'PASS_NATIVE_GSEA_FILE_WORKFLOW_CONTROLS_THREE_JVMS'),(transport,'PASS_NATIVE_GSEA_LITERAL_FLOAT32_AND_CROSS_HOST_TRANSPORT_THREE_JVMS')]:assert json.loads((path/'COMPLETED.json').read_bytes())['status']==status
add('producer/PRODUCER.json',hosts/'PRODUCER.json')
add('hosts/COMPLETED.json',hosts/'COMPLETED.json');add('controls/COMPLETED.json',controls/'COMPLETED.json');add('transport/COMPLETED.json',transport/'COMPLETED.json')
for n in ['COMMAND.json','stdout','stderr']:add('gradle/'+n,gradle/n)
add('gradle/PROCESS.json',gradle/'PROCESS-EXIT.json')
for n in ['BroadGseaRecipeTest','BroadGseaEngineTest','BroadGseaStatisticsTest']:add('gradle/'+n+'.xml',gradle/'project-build/test-results/test'/('TEST-org.jlinalg.'+('cli.' if n=='BroadGseaRecipeTest' else 'enrichment.')+n+'.xml'))
scientific={}
for host in ['windows-java21','windows-java25','linux-java21']:
    h=hosts/host;add('hosts/'+host+'/COMPLETED.json',h/'COMPLETED.json')
    for n in ['version.stdout','version.stderr']:add('hosts/'+host+'/'+n,h/n)
    for mode in ['run','verify','replay']:
        for source,target in [(mode+'.PROCESS.json','PROCESS.json'),(mode+'.stdout','stdout'),(mode+'.stderr','stderr')]:add('hosts/'+host+'/'+mode+'/'+target,h/source)
        capture=h/'examples'/(mode+'-out')
        for n in ['analysis-status.json','capture-files.json','process.json','WARNINGS.md','original-request.json','effective-request.json','producer.json','input-bindings.json','worker/status.json','worker/runtime.json']:add('hosts/'+host+'/'+mode+'/'+n,capture/n)
    manifest=json.loads((h/'examples/run-out/capture-files.json').read_bytes());scientific[host]={n:w for n,w in manifest.items() if n.startswith('results/')}
    for path in sorted(h.glob('batch-*.PROCESS.json')):add('hosts/'+host+'/'+path.name,path)
    tree('controls/'+host,controls/host)
    tree('transport/'+host,transport/host)
assert all(v==scientific['windows-java21'] for v in scientific.values())
files['SCIENTIFIC-OUTPUT-PINS.json']=enc(scientific)
reference=hosts/'windows-java21/corpus';batches=json.loads((reference/'BATCHES.json').read_bytes())
for batch,ids in batches.items():
    for i,id in enumerate(ids):
        name='options/'+id+'.bin';binaries[name]=(reference/(batch+'-out')/'results'/('case-%04d'%i)/'result.bin').read_bytes()
        edition,case=id.split('-case-',1);mapping[name]=dict(kind='options',reference=edition+'/case-'+case+'.tsv')
i=0
for edition in ['4.4.0','4.3.2','4.3.3']:
    for mode in ['preranked','expression-phenotype','expression-geneset']:
        name='long/'+edition+'/'+mode+'.bin';binaries[name]=(hosts/'windows-java21/examples/run-out/results'/('case-%04d'%i)/'result.bin').read_bytes();mapping[name]=dict(kind='long',reference='reference/'+edition+'/'+mode+'.tsv');i+=1
assert len(mapping)==len(binaries)==432
files['RESULT-REFERENCES.json']=enc(mapping)
for folder in ['compile-1','compile-2','compile-3','source-output-cap-correction-2','source-canonical-ledgers-3','paused-drafts-1','cross-host-newline-diagnosis-1','linux-preflight-1']:
    source=B/folder
    for p in source.iterdir():
        if p.is_file():add('retained-history/'+folder+'/'+p.name,p)
for folder in ['native-gradle-1','native-gradle-2']:
    for n in ['COMMAND.json','PROCESS-EXIT.json','stdout','stderr']:add('retained-history/'+folder+'/'+n,B/folder/n)
for folder in ['file-hosts-qualification-1','file-hosts-qualification-2']:
    for p in (B/folder).glob('linux-java21/version.*'):add('retained-history/'+folder+'/'+p.name,p)
for host in ['windows-java21','windows-java25','linux-java21']:
    source=B/'file-transport-1'/host/'cross-host-verify'
    if source.exists():tree('retained-history/file-transport-1/'+host,source)
for name in ['LINUX-HOST-RETRY-REASON.json','CONTROLS-RETRY-REASON.json']:add('retained-history/'+name,B/name)
for p in sorted((R/'build').glob('*gsea*20261120*.py')):add('historical-local-scripts/'+p.name,p)
pub=R/'build/git-publish/20261120-gsea-files-64'
assert json.loads((pub/'READBACKS-COMPLETED.json').read_bytes())['current_worktrees']==20
for n in ['READBACKS-COMPLETED.json','EXTERNAL-CLEANUP-TRANSITION.json','INITIAL-INVENTORY-REFUSAL.json','INITIAL-INVENTORY-REFUSAL-2.json','RECOVERY-MANIFEST-DIAGNOSIS.json','RECOVERY-MANIFEST-RETRY-REASON.json']:
    add('preservation/'+n,pub/n)
tree('preservation/external-cleanup',pub/'external-cleanup-2')
for prefix in ['historical-overlays','saved-native-arithmetic','saved-native-engine','catalog']:
    for suffix in ['.PROCESS.json','.stdout','.stderr']:add('preservation/'+prefix+suffix,pub/(prefix+suffix))
archive(Q/'checks.zip',files);archive(Q/'workflow-results.zip',binaries)
spec=importlib.util.spec_from_file_location('workflow_reader',T/'tools/literature/verify_broad_gsea_workflow.py');reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
archives={}
for p in [Q/'checks.zip',Q/'workflow-results.zip',T/reader.SWEEP,T/reader.LONG]:
    with zipfile.ZipFile(p) as z:archives[p.relative_to(T).as_posix()]=dict(archive=pin(p.read_bytes()),files={n:pin(z.read(n)) for n in z.namelist()})
producer=json.loads((hosts/'PRODUCER.json').read_bytes())
q=dict(schema_version=1,status=reader.STATUS,sources={n:pin((T/n).read_bytes()) for n in sorted(reader.OWN)},archives=archives,producer=producer['producer'],file_workflow_qualified=True,global_dispatch_registered=False,new_catalog_credit=0,original_fields_per_JVM=668739,expected_refusals_per_JVM=34,private_transfer_required=True)
(Q/'QUALIFICATION.json').write_bytes(enc(q))
result=reader.verify();(O/'READBACK.json').write_bytes(enc(result));(O/'COMPLETED.json').write_bytes(enc(dict(status='PASS_FROZEN_NATIVE_GSEA_FILE_WORKFLOW_PROOF_AND_SOURCE_OBJECT_READBACK',result=result,qualification=pin((Q/'QUALIFICATION.json').read_bytes()),archives={n:r['archive'] for n,r in archives.items()})))
print(json.dumps(result,indent=2),flush=True)
