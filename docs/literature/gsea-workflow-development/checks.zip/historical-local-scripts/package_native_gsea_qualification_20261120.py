from pathlib import Path
import hashlib,importlib.util,json,subprocess,zipfile
R=Path('D:/projects/JLinAlg');H=R/'build/gs-2';B=H/'build/gsea-high-impact-2';Q=H/'docs/literature/gsea-native-development'
O=B/'native-public-proof-1';O.mkdir(exist_ok=False)
def enc(v):return (json.dumps(v,indent=2)+'\n').encode()
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
files={}
def add(name,path):assert name not in files;files[name]=Path(path).read_bytes()
native=B/'native-packaged-qualification-1';gradle=B/'native-gradle-1'
for name in ['PRODUCER.json','COMPLETED.json']:add('producer/'+name,native/name)
for name in ['COMMAND.json','PROCESS-EXIT.json','stdout','stderr']:add('gradle/'+name,gradle/name)
add('gradle/TEST.xml',gradle/'project-build/test-results/test/TEST-org.jlinalg.enrichment.BroadGseaStatisticsTest.xml')
version_commands={
    'windows-java21':['C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe','-version'],
    'windows-java25':['C:/Program Files/Java/jdk-25/bin/java.exe','-version'],
    'linux-java21':['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--exec','/usr/bin/java','-version']}
for host,command in version_commands.items():
    for name in ['PROCESS.json','stdout','stderr']:add('runs/'+host+'/'+name,native/host/name)
    p=subprocess.run(command,stdin=subprocess.DEVNULL,capture_output=True);assert p.returncode==0
    files['runs/'+host+'/JAVA-VERSION.stdout']=p.stdout;files['runs/'+host+'/JAVA-VERSION.stderr']=p.stderr
    files['runs/'+host+'/JAVA-VERSION-PROCESS.json']=enc(dict(command=command,exit_code=p.returncode))
for version in ['4.3.2','4.3.3']:
    root=B/'original-build-4.3-source-1'/version
    for name in ['COMMAND.json','PROCESS-EXIT.json','stdout','stderr']:add('original-build/'+version+'/'+name,root/name)
add('original-build/COMPLETED.json',B/'original-build-4.3-source-1/COMPLETED.json')
add('original-forms/4.4.0-COMPLETED.json',B/'original-workflow-forms-4.4.0-2/COMPLETED.json')
add('original-forms/4.4.0-CHANGE-REASON.json',B/'original-workflow-forms-4.4.0-2/CHANGE-REASON.json')
add('original-forms/4.3-COMPLETED.json',B/'original-4.3-profiles-1/COMPLETED.json')
for name in ['COMMAND.json','PROCESS-EXIT.json','stdout','stderr']:
    add('retained-failures/small-phenotype/'+name,B/'original-synthetic-4.4.0-1/expression-phenotype'/name)
for attempt in [1,2]:
    root=B/('original-api-4.4.0-'+str(attempt))
    add('retained-failures/api-'+str(attempt)+'/OriginalGseaProbe.java',root/'OriginalGseaProbe.java')
    for name in ['PROCESS-EXIT.json','stdout','stderr']:add('retained-failures/api-'+str(attempt)+'/'+name,root/'preranked'/name)
for name in ['PREVIOUS-FAILED-INTAKE.json','FAILURE.json']:
    add('retained-failures/jdk8/'+name,B/'legacy-build-jdk8-2'/name)
add('retained-failures/jdk8/initial-FAILURE.json',B/'legacy-build-prereqs-1/FAILURE.json')
add('retained-failures/jdk8/official-api.json',B/'legacy-build-prereqs-1/jdk8-windows/official-api.json')
archive=Q/'checks.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,raw in sorted(files.items()):
        info=zipfile.ZipInfo(name,date_time=(2026,11,20,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,raw)
spec=importlib.util.spec_from_file_location('reader',H/'tools/literature/verify_broad_gsea_native.py');reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
producer=json.loads((native/'PRODUCER.json').read_bytes())
q=dict(schema_version=1,status=reader.STATUS,source_code={name:pin((H/name).read_bytes()) for name in reader.OWN},
    fixture=pin((H/reader.FIXTURE).read_bytes()),checks=dict(archive=pin(archive.read_bytes()),files={n:pin(v) for n,v in sorted(files.items())}),
    producer=producer['producer'],qualified_scope='Native arithmetic on prepared scores and complete supplied original null families; no project file workflow, global command or catalog admission',
    new_catalog_credit=0,private_transfer_required=True)
(Q/'QUALIFICATION.json').write_bytes(enc(q))
result,_=reader.verify();(O/'READBACK.json').write_bytes(enc(result))
(O/'COMPLETED.json').write_bytes(enc(dict(status='PASS_FROZEN_NATIVE_GSEA_SAVED_QUALIFICATION',
    archive=pin(archive.read_bytes()),qualification=pin((Q/'QUALIFICATION.json').read_bytes()),readback=result)))
print(json.dumps(result,indent=2),flush=True)
