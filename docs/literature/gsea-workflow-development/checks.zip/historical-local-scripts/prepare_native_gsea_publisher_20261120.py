from pathlib import Path
R=Path('D:/projects/JLinAlg');text=(R/'build/publish_gsea_handover_20261120_61.py').read_text()
changes={
"G=R/'build/gs-1';O=R/'build/git-publish/20261120-gsea-handover-61'":"G=R/'build/gs-2';O=R/'build/git-publish/20261120-gsea-native-62'",
"P=R/'build/git-publish/20261120-edger-admission-60'":"P=R/'build/git-publish/20261120-gsea-handover-61'",
"0de612c6182b87d42a1d574af5f06a99630a0924":"7a50e4a18d27e0bccd82d70b9a5632062abb3fc3",
"=={'docs/literature/HANDOVER_CURRENT.md'}":"=={'.gitattributes','docs/literature/HANDOVER_CURRENT.md'}",
"base,head,'--','src','site','.github','tools'":"base,head,'--','site','.github'",
"len(trees)==29":"len(trees)==30",
"342957":"345727",
"PASS_29_WORKTREES_AND_PROTECTED_ARTIFACTS":"PASS_30_WORKTREES_AND_PROTECTED_ARTIFACTS",
"worktrees=29":"worktrees=30",
"worktrees_preserved=29":"worktrees_preserved=30",
"GSEA_RESEARCH_BUILD_HANDOVER":"NATIVE_BROAD_GSEA_ARITHMETIC",
"fresh_saved_global_catalog_and_source_build_runtime_readbacks=True":"fresh_saved_native_and_cumulative_catalog_readbacks=True",
"GSEA_original_source_build_passed=True,GSEA_statistical_execution_qualified=False,new_catalog_credit=0":"GSEA_original_source_build_passed=True,native_Broad_GSEA_arithmetic_qualified=True,exact_field_checks_per_JVM=356286,source_bound_refusals_per_JVM=1701,JVMs=3,unchanged_predecessor_JAR_payloads=23485,original_source_profiles=3,original_workflow_forms=9,permutations_per_form=10000,GSEA_project_file_workflow_qualified=False,new_catalog_credit=0",
"previous=json.loads((P/'PUBLISHED.json').read_bytes());assert previous['head']==base and previous['pages_deployment_successful']":"previous=json.loads((P/'PUBLISHED.json').read_bytes());assert previous['head']==base and previous['site_changed'] is False\n    actual_deployment=R/'build/git-publish/20261120-edger-admission-60/PUBLISHED.json'\n    assert json.loads(actual_deployment.read_bytes())['pages_deployment_successful']",
"preceding_actual_deployment_receipt=pin((P/'PUBLISHED.json').read_bytes())":"preceding_actual_deployment_receipt=pin(actual_deployment.read_bytes())",
}
for old,new in changes.items():
    assert old in text,old
    text=text.replace(old,new)
target=R/'build/publish_native_gsea_20261120_62.py'
with target.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
print('Prepared scoped native GSEA main publisher',target,flush=True)
