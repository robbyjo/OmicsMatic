# FAIL2_NO_RESULT_ADMITTED

DEVELOPMENT_SCOPE: original Seurat5.6.0 unsplit RNA workflow, explicit current settings and exact identity transport. Native surrounding normalization/scaling/PCA/SNN audits do not independently refit VST, regression, SCT, clustering, UMAP or t-SNE. No historical whole-package, whole-paper, biological or installed-DLL authentication claim. No integration, WNN, transfer, Harmony, cell-type annotation or reusable UMAP projection model is supplied.

EXACT_TRANSPORT: public feature/cell/metadata identities remain captured. Only explicit f#/c#/v#/l# codes enter Seurat; public outputs restore exact IDs. No identifier repair or inferred cell-type annotation occurs.

SOURCE_FILTERS: original VST/SCT/PCA can exclude features. Read feature-disposition.tsv and diagnostics.json; exclusions are source outcomes, not negative biological findings. Whole-paper reproduction and historical author editions are not established.

CAPACITY_SCOPE: explicit input/dense/graph/work/output and wall limits are admission controls, not an operating-system RAM quota. Output may exceed its polling bound briefly before owned-process cleanup.

UNMODELED_METADATA: captured columns not used by regression: depth cov, batch

FAIL2: java.io.IOException: maximum_output_bytes exceeded by the original worker; no result admitted. Partial outputs are retained evidence, not admitted results.

Required action: Read WARNINGS.md, analysis-status.json, diagnostics.json and worker/worker-report.json/logs. SKIP3 means the affected analysis was skipped: supply the named exact permitted runtime/backend in declared private libraries, or leave it skipped. FAIL2 admits no complete result: preserve inputs, partials and diagnostics, correct the named input/model/source/process/capacity cause and retry into NEW output paths. No silent identifier repair, nonfinite replacement, population truncation or algorithm/backend substitution. VERIFY checks captured consistency and stated native arithmetic without R; it does not authenticate a coordinated fabricated capture or refit original models. REPLAY runs the original models again and needs the exact permitted runtime; stochastic/host-dependent byte equality is not promised.
