SKIP3: This original reference build requires Linux with gcc and make; native project methods remain separate
Supply/install the named permitted prerequisite; otherwise skip dependent analysis. Retry NEW output.
