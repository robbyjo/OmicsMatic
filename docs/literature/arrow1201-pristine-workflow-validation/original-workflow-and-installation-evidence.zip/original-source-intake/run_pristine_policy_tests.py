from pathlib import Path
import json,os,subprocess,sys
ROOT=Path('/mnt/d/projects/JLinAlg')
HERE=ROOT/'tools/literature/arrow1201'
sys.path.insert(0,str(HERE))
from Runtime import sources,pin,save
OUT=ROOT/'build/literature-review/monocle-runtime/arrow1201-pristine-policy-controls-1'
OUT.mkdir(exist_ok=False)
env=dict(os.environ,
    ARROW1201_RECORDING_OUT=str(OUT/'recording'),
    ARROW1201_TEST_RUNTIME='/opt/omicsmatic-arrow1201-pristine-public-install-20261114-1/provider',
    ARROW1201_PATCHED_RUNTIME='/opt/omicsmatic-arrow1201-public-offline-install-20261114-1/provider',
    ARROW1201_TEST_FIXTURES=str(ROOT/'build/literature-review/monocle-runtime/arrow1201-pristine-workflow-candidate-1/fixtures'),
    ARROW1201_PERMISSION_ROOT='/opt/omicsmatic-arrow1201-pristine-permission-controls-20261114-1')
records=[]
for name in ['test_recording.py','test_inventory_permissions.py']:
    command=[sys.executable,'-B',str(HERE/name),'-v']
    with (OUT/(name+'.stdout')).open('xb') as stdout,(OUT/(name+'.stderr')).open('xb') as stderr:
        child=subprocess.run(command,cwd=ROOT,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr)
    record=dict(command=command,exit_code=child.returncode,source=pin(HERE/name))
    save(OUT/(name+'.PROCESS.json'),record);records.append(record)
    print('PRISTINE_ARROW1201_POLICY_TEST',name,child.returncode,flush=True)
    assert child.returncode==0,name
save(OUT/'COMPLETED.json',dict(status='PASS_PRISTINE_ARROW1201_REAL_POLICY_RECORDING_AND_PERMISSION_CONTROLS',
    recording_and_policy_tests=5,real_permission_tests=1,actual_unprivileged_UID=65534,
    patched_same_edition_skips_without_R_execution=True,real_original_return_before_injected_recording_denial=True,
    failed_recording_result_admitted=False,processes=records,adapter_sources=sources(),new_family_credit=0,whole_goal_complete=False))
