from pathlib import Path
HERE=Path(__file__).resolve().parent
s=(HERE/'seal_workflow.py').read_text()
replacements={
"DATA=ROOT/'docs/literature/arrow1201-workflow-validation'":"DATA=ROOT/'docs/literature/arrow1201-pristine-workflow-validation'",
"WORKFLOW=BASE/'arrow1201-workflow-candidate-3'":"WORKFLOW=BASE/'arrow1201-pristine-workflow-candidate-1'",
"FINAL=BASE/'arrow1201-final-saved-controls-1'":"FINAL=BASE/'arrow1201-pristine-final-saved-controls-1'",
"RECORDING=BASE/'arrow1201-recording-controls-1'":"RECORDING=BASE/'arrow1201-pristine-policy-controls-1/recording'",
"/opt/omicsmatic-arrow1201-public-install-20261114-2":"/opt/omicsmatic-arrow1201-pristine-public-install-20261114-1",
"/opt/omicsmatic-arrow1201-public-offline-install-20261114-1":"/opt/omicsmatic-arrow1201-pristine-public-offline-install-20261114-1",
"BASE/'arrow1201-permission-controls-1/PROCESS.json'":"BASE/'arrow1201-pristine-policy-controls-1/test_inventory_permissions.py.PROCESS.json'",
"tree('permission-controls',BASE/'arrow1201-permission-controls-1')":"tree('policy-control-reports',BASE/'arrow1201-pristine-policy-controls-1',skip=('recording',))",
"actual_recording_and_policy_tests=4":"actual_recording_and_policy_tests=5",
"Four real policy/recording tests":"Five real policy/recording tests",
"arrow1201-workflow-seal-1.json":"arrow1201-pristine-workflow-seal-1.json",
"upstream_source_algorithms_changed=False":"adapter_changes_upstream_algorithms=False",
"PASS_ORIGINAL_ARROW1201_SCOPED_PARQUET_WORKFLOW_AND_INSTALLATION":"PASS_RECIPE_UNPATCHED_ARROW1201_SCOPED_PARQUET_WORKFLOW_AND_INSTALLATION",
}
for old,new in replacements.items():
    assert old in s,old
    s=s.replace(old,new)
extra='''
policy=load(BASE/'arrow1201-pristine-policy-controls-1/COMPLETED.json')
assert policy['recording_and_policy_tests']==5 and policy['real_permission_tests']==1
assert not (RECORDING/'same-edition-patched-cpp/LIVE.json').exists()
assert load(RECORDING/'same-edition-patched-cpp/FAILURE.json')['status']=='SKIP3_ARROW1201_PREREQUISITE_UNAVAILABLE'
cpp=load(BASE/'arrow1201-cpp-original-source-intake-1/COMPLETED.json')
assert cpp['sha256']=='3481c411393aa15c75e88d93cf8315faf7f43e180fe0790128d3840d417de858'
assert cpp['regular_files']==6889 and cpp['upstream_tag_commit']=='6af660f48472b8b45a5e01b7136b9b040b185eb1'
add('cpp-source-provenance/OFFICIAL-RELEASE-INTAKE.json',BASE/'arrow1201-cpp-original-source-intake-1/COMPLETED.json')
audit=BASE/'arrow1201-cpp-packaging-audit-1'
for file in sorted(audit.rglob('*')):
    if file.is_file() and file.suffix!='.conda':
        add('cpp-source-provenance/'+file.relative_to(audit).as_posix(),file)
for name in ['final_pristine_saved_controls.py','seal_pristine_workflow.py','make_pristine_sealer.py',
             'intake_cpp_release.py','run_pristine_policy_tests.py','setup_pristine_runtime.py']:
    add('original-source-intake/'+name,BASE/'arrow1201-intake-1'/name)
previous=ROOT/'docs/literature/arrow1201-workflow-validation'
for file in sorted(previous.iterdir()):
    if file.is_file():add('history/INVALIDATED-cpp-build50/'+file.name,file)
assert pin(previous/'original-workflow-and-installation-evidence.zip')==dict(bytes=3188493,sha256='cf9cd3815e5674fda0071b9f03281bbc0d280f8de9ec0c07f976b21b627f760c')
'''
marker='module_sources={p.name:pin(p) for p in sorted(HERE.iterdir()) if p.is_file()}'
assert marker in s
s=s.replace(marker,extra+'\n'+marker)
marker="    catalog_admission_pending=True,new_family_credit=0,native_family_credit=0,"
assert marker in s
s=s.replace(marker,"""    selected_cpp_artifact=load(HERE/'source-profile.json')['required_conda_artifacts']['libarrow'],
    cpp_recipe_declared_patches=[],cpp_source_origin=cpp['sha256'],official_cpp_source_regular_files=6889,
    actual_upstream_arrow_tag_commit=cpp['upstream_tag_commit'],
    reported_cpp_git_id=cpp['runtime_reported_git_id'],
    reported_cpp_git_id_is_feedstock_packaging_commit=True,
    original_cpp_binary_rebuilt_from_source=False,
    same_edition_patched_cpp_rejected_before_analysis=True,
    prior_cpp_build50_qualification_invalidated=True,prior_bundle_preserved_unchanged=True,
    qualification_is_recipe_and_artifact_origin_not_author_build=True,
"""+marker)
old="history='Earlier attempts remain failed and retained."
new="history='The provisional CPP build50 proof is invalidated and retained, because its recipe declares four backports. The selected build2 recipe declares none and its official Apache source archive was independently downloaded and checked. Reported C++ Git ID names the conda-forge feedstock commit, not the upstream Arrow commit. Earlier attempts remain failed and retained."
assert old in s
s=s.replace(old,new)
(HERE/'seal_pristine_workflow.py').open('x',encoding='utf-8').write(s)
print('NEW_PRISTINE_SEALER_PREPARED')
