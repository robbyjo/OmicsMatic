from pathlib import Path
import hashlib,json,tarfile,urllib.request
ROOT=Path('D:/projects/JLinAlg')
OUT=ROOT/'build/literature-review/monocle-runtime/arrow1201-cpp-original-source-intake-1'
OUT.mkdir(exist_ok=False)
url='https://archive.apache.org/dist/arrow/arrow-12.0.1/apache-arrow-12.0.1.tar.gz'
target=OUT/'apache-arrow-12.0.1.tar.gz'
request=urllib.request.Request(url,headers={'User-Agent':'OmicsMatic-original-Arrow-source-intake'})
digest=hashlib.sha256();size=0
with urllib.request.urlopen(request,timeout=90) as response,target.open('xb') as stream:
    metadata=dict(url=url,final_url=response.url,status=response.status,headers=dict(response.headers))
    while True:
        block=response.read(1048576)
        if not block:break
        stream.write(block);digest.update(block);size+=len(block)
        if size>200000000:raise ValueError('Original Apache source exceeds intake cap')
assert digest.hexdigest()=='3481c411393aa15c75e88d93cf8315faf7f43e180fe0790128d3840d417de858'
files={}
with tarfile.open(target,'r:gz') as archive:
    for member in archive.getmembers():
        if member.isfile():
            raw=archive.extractfile(member).read()
            files[member.name]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
metadata.update(bytes=size,sha256=digest.hexdigest(),regular_files=len(files),files=files,
    status='PASS_OFFICIAL_APACHE_CPP_RELEASE_SOURCE_MATCHES_RECIPE_ORIGIN',
    upstream_tag_commit='6af660f48472b8b45a5e01b7136b9b040b185eb1',
    runtime_reported_git_id='752163190f2c02791addd4cc8c9f95790fab4b13',
    runtime_reported_git_id_origin='conda-forge/arrow-cpp-feedstock packaging commit, not upstream Arrow',
    original_binary_rebuilt_from_source=False,new_family_credit=0,whole_goal_complete=False)
(OUT/'COMPLETED.json').write_text(json.dumps(metadata,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in metadata.items() if k not in ['files','headers']}),flush=True)
