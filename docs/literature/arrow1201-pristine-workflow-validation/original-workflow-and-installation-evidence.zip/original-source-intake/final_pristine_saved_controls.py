from pathlib import Path
import json,os,subprocess,sys
ROOT=Path('/mnt/d/projects/JLinAlg')
HERE=ROOT/'tools/literature/arrow1201'
sys.path.insert(0,str(HERE))
from Runtime import load,save,environment,check,sources
OUT=ROOT/'build/literature-review/monocle-runtime/arrow1201-pristine-final-saved-controls-1'
OUT.mkdir(exist_ok=False)
WORKFLOW=ROOT/'build/literature-review/monocle-runtime/arrow1201-pristine-workflow-candidate-1'
PROVIDER=Path('/opt/omicsmatic-arrow1201-pristine-public-offline-install-20261114-1/provider')
ready=load(PROVIDER/'READY.json');check(ready)
for name in ['home','tmp']:(OUT/name).mkdir()
env=environment(ready,OUT);rscript=Path(ready['r_prefix'])/'bin/Rscript'
calls=[]
def run(name,args):
    cmd=[str(rscript),'--vanilla']+list(map(str,args))
    with (OUT/(name+'.stdout')).open('xb') as stdout,(OUT/(name+'.stderr')).open('xb') as stderr:
        child=subprocess.run(cmd,cwd=OUT,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr)
    save(OUT/(name+'-PROCESS.json'),dict(command=cmd,exit_code=child.returncode))
    calls.append(dict(name=name,exit_code=child.returncode))
    print('FINAL_SAVED_ARROW1201_PROCESS',name,child.returncode,flush=True)
    assert child.returncode==0,name
reports={}
for name in load(WORKFLOW/'COMPLETED.json')['cases']:
    case=WORKFLOW/name
    run(name,[HERE/'CompareWorkflow.R',case/'original-reference',case/'adapter/original',OUT/(name+'.json')])
    reports[name]=load(OUT/(name+'.json'))
run('negative-controls',[HERE/'TestSavedWorkflowRejections.R',HERE/'CompareWorkflow.R',
    WORKFLOW/'read-complete/original-reference',WORKFLOW/'query-unsupported/original-reference',
    WORKFLOW/'query-missing-column/original-reference',OUT/'negative-controls'])
run('condition-differences',[HERE/'InspectConditionDifferences.R',
    WORKFLOW/'query-missing-column/original-reference/complete-conditions.rds',
    WORKFLOW/'query-missing-column/adapter/original/complete-conditions.rds',OUT/'CONDITION-DIFFERENCES.json'])
diff=load(OUT/'CONDITION-DIFFERENCES.json')
assert diff['differing_fields']=='trace',diff
assert diff['field_names_and_order_identical'] and diff['complete_error_attributes_identical']
for name,report in reports.items():
    for key in ['complete_error_strict','complete_conditions_strict']:
        assert report[key] == (name!='query-missing-column'),(name,key)
negative=load(OUT/'negative-controls/COMPLETED.json')
assert (negative['unchanged_controls'],negative['tampered_rejections'])==(2,12)
check(ready)
save(OUT/'COMPLETED.json',dict(status='PASS_ARROW1201_COMPLETE_SAVED_RETURNS_RNG_ERROR_CONTRACT_AND_TAMPERING',
    original_controls=13,complete_returns=10,original_failures_without_result=3,unchanged_comparator_controls=2,
    tampered_comparator_rejections=12,whole_condition_identity_controls=12,
    missing_column_complete_error_difference='trace only; actual caller context retained on each side',
    no_condition_fields_deleted_or_coerced=True,live_context_identity_claimed=False,
    calls=calls,comparisons=reports,adapter_sources=sources(),new_family_credit=0,whole_goal_complete=False))
print('PASS_ARROW1201_COMPLETE_SAVED_RETURNS_RNG_ERROR_CONTRACT_AND_TAMPERING',flush=True)
