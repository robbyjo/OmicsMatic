# Snakemake benchmark scope, warnings and required actions

Native Java aggregation of the selected Snakemake 9.27.1 standard/extended TSV
format: SUM of recorded cpu_time seconds and MAXIMUM of recorded job max_rss
in MiB, separately for each explicit pipeline/replicate. Summed job wall time
is not elapsed pipeline time; maximum job RSS is not concurrent pipeline peak
memory. Source sampling and two-decimal formatting limit recorded precision.
A short job may have NA measurements; these are not zeros. Incomplete or
nonfinite required metrics, duplicate jobs/rows, omitted repeats and unlisted
benchmark files admit no aggregate. No repeat pooling or statistical test runs.

This command reads supplied benchmarks; it does not execute Snakemake,
measure processes, establish that a caller's job list covers an entire DAG,
certify successful biological jobs, or reproduce unreported author settings.
None of the six reviewed paper roles establishes engine version 9.27.1.
The separate original-engine adapter is still under development. No additional
catalog credit is claimed here. Build current source; released v0.4.0 lacks
this command. Whole-paper reproduction and the 250-paper goal remain open.

Require root COMPLETED.properties. --verify validates complete captured input,
code and output membership and independently recomputes the native summary in
NEW output. Hashes establish integrity, not authenticity. Missing/forbidden
dependencies for upstream execution require SKIP3 and skipping that dependent
analysis; this native operation needs no external Snakemake installation.
FAIL2 admits no complete result: retain raw inputs and every failed attempt,
inspect FAILURE.txt and diagnostics, correct the named cause and retry NEW
output with adequate permitted capacities. Never impute missing measurements,
substitute formats/units, drop jobs/repeats, or refresh saved code fingerprints.
Input/work capacities and cooperative wall checks are not operating-system
quotas; use a JVM/host with adequate permitted memory and filesystem capacity.
