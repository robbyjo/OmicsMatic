# Setup scope and recovery

SETUP ONLY. No user analysis or paper reproduction is admitted. Snakemake 9.27.1 is a selected upstream edition; the five paper engine versions are unresolved. Installation is separately authorized here. Missing/forbidden prerequisites skip dependent analysis; retain diagnostics, correct the named cause and retry a NEW runtime. Workflow-specific aligners, cloud services, data and dependency environments remain separate.
