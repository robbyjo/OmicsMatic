from pathlib import Path
import datetime,hashlib,json,subprocess,time,traceback,urllib.request

OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2]
PREVIOUS=Path('D:/projects/JLinAlg/build/git-publish/20261115-all-main-4/checkout/build/snakemake/source-audit-1')
RUNTIME=ROOT/'build/snakemake/runtime-1'
PIXI=Path('D:/projects/JLinAlg/build/literature-review/saige-runtime/pixi-bootstrap-1/pixi')
EXPECTED_PIXI='50571451e96f4a82cf675cd83baaf66fff9b718f0aaf153900b9faf4c29bd401'
def save(name,value):
    with (OUT/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2);f.write('\n')
def pin(path):return dict(bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
def linux(path):
    path=Path(path).resolve();return '/mnt/'+path.drive[0].lower()+path.as_posix()[2:]
def run(name,command,timeout=1800):
    begin=time.monotonic()
    with (OUT/(name+'.stdout')).open('xb') as so,(OUT/(name+'.stderr')).open('xb') as se:result=subprocess.run(command,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=timeout)
    save(name+'.process.json',dict(command=command,exit_code=result.returncode,seconds=round(time.monotonic()-begin,3)));return result.returncode
try:
    assert pin(PIXI)['sha256']==EXPECTED_PIXI
    source=json.loads((PREVIOUS/'SOURCE.json').read_bytes())
    assert source['commit']=='f79d9eb5e2b679e1191818f24335907b041578be'
    for name,expected in source['files'].items():assert pin(PREVIOUS/'source'/name)=={k:expected[k] for k in ['bytes','sha256']},name
    req=urllib.request.Request('https://pypi.org/pypi/snakemake/9.27.1/json',headers={'User-Agent':'OmicsMatic-authorized-isolated-research-setup'})
    with urllib.request.urlopen(req,timeout=60) as response:metadata=json.load(response)
    assert metadata['info']['version']=='9.27.1';save('PYPI.json',metadata)
    RUNTIME.mkdir(exist_ok=False)
    (RUNTIME/'pixi.toml').write_text('[workspace]\nname = "omicsmatic-snakemake-9271"\nchannels = ["conda-forge"]\nplatforms = ["linux-64"]\n\n[dependencies]\npython = "==3.12.12"\npip = "==25.3"\n\n[pypi-dependencies]\nsnakemake = "==9.27.1"\n',encoding='utf-8',newline='\n')
    warning='SETUP ONLY. No user analysis or paper reproduction is admitted. Snakemake 9.27.1 is a selected upstream edition; the five paper engine versions are unresolved. Installation is separately authorized here. Missing/forbidden prerequisites skip dependent analysis; retain diagnostics, correct the named cause and retry a NEW runtime. Workflow-specific aligners, cloud services, data and dependency environments remain separate.'
    (OUT/'WARNINGS.md').write_text('# Setup scope and recovery\n\n'+warning+'\n',encoding='utf-8',newline='\n')
    save('REQUEST.json',dict(runtime=str(RUNTIME),edition='9.27.1',python='3.12.12',pixi=pin(PIXI),source_audit=pin(PREVIOUS/'SOURCE.json'),source_commit=source['commit'],manifest=pin(RUNTIME/'pixi.toml'),producer=pin(Path(__file__)),user_analysis_admitted=False,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
    prefix=['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/env','PYTHONDONTWRITEBYTECODE=1','PIXI_CACHE_DIR='+linux(RUNTIME/'private-pixi-cache'),'UV_CACHE_DIR='+linux(RUNTIME/'private-uv-cache')]
    code=run('install',prefix+[linux(PIXI),'install','--manifest-path',linux(RUNTIME/'pixi.toml')]);assert code==0,'Isolated Pixi installation failed; inspect retained install stderr'
    python=linux(RUNTIME/'.pixi/envs/default/bin/python')
    check='import importlib.metadata as m,hashlib,json,pathlib,sys,snakemake.benchmark,snakemake.cli;print(json.dumps({"python":sys.version,"version":m.version("snakemake"),"sources":{n:{"path":str(pathlib.Path(x.__file__)),"sha256":hashlib.sha256(pathlib.Path(x.__file__).read_bytes()).hexdigest()} for n,x in [("benchmark",snakemake.benchmark),("cli",snakemake.cli)]}},sort_keys=True))'
    assert run('inspect',prefix+[python,'-B','-c',check],120)==0
    inspected=json.loads((OUT/'inspect.stdout').read_bytes());assert inspected['version']=='9.27.1'
    for name in ['benchmark','cli']:assert inspected['sources'][name]['sha256']==source['files']['src/snakemake/'+name+'.py']['sha256'],name
    assert run('pip-check',prefix+[python,'-B','-m','pip','check'],120)==0
    assert run('version',prefix+[python,'-B','-m','snakemake','--version'],120)==0
    assert (OUT/'version.stdout').read_text().strip()=='9.27.1'
    save('COMPLETED.json',dict(status='PINNED_ISOLATED_SNAKEMAKE_INSTALLED_NOT_YET_WORKFLOW_QUALIFIED',runtime=str(RUNTIME),source_commit=source['commit'],lock=pin(RUNTIME/'pixi.lock'),inspection=inspected,user_analysis_admitted=False,whole_goal_complete=False))
    print('PASS_ISOLATED_SNAKEMAKE_SETUP_NOT_ANALYSIS',flush=True)
except BaseException as error:
    save('FAILURE.json',dict(reason=repr(error),traceback=traceback.format_exc(),user_analysis_admitted=False,required_action='Inspect retained setup logs. Restore permitted prerequisites or skip dependent workflow execution. Preserve this attempt and retry a NEW setup path; no global package or existing scientific runtime was changed.'))
    raise
