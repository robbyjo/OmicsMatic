from pathlib import Path
import concurrent.futures,json,os,subprocess
R=Path('D:/projects/JLinAlg');B=R/'build/literature-review/mashr-runtime/workflow-development-1';O=B/'native-audits-1';O.mkdir()
jar=B/'package-1/omicsmatic-0.3.7-mashr-development.jar';classes=O/'classes';classes.mkdir()
j='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin'
cmd=[j+'/javac.exe','--release','17','-Xlint:all','-Werror','-cp',str(jar),'-d',str(classes),str(R/'tools/literature/MashWorkflowProbe.java')]
with (O/'compile.stdout').open('xb') as out,(O/'compile.stderr').open('xb') as err:p=subprocess.run(cmd,cwd=R,stdout=out,stderr=err,timeout=60)
assert p.returncode==0,(O/'compile.stderr').read_text()
controls=R/'build/literature-review/mashr-runtime/original-workflow-controls-1';record=json.loads((controls/'ORIGINAL-CONTROLS.json').read_text())
def execute(protocol):
 name=protocol['name'];folder=controls/name;cmd=[j+'/java.exe','-Xmx128m','-cp',os.pathsep.join(map(str,[classes,jar])),'org.jlinalg.cli.MashWorkflowProbe',str(folder/'inputs'),str(folder/'outputs'),str(O/(name+'.numeric.json'))]
 with (O/(name+'.stdout')).open('xb') as out,(O/(name+'.stderr')).open('xb') as err:p=subprocess.run(cmd,cwd=R,stdout=out,stderr=err,timeout=120)
 print(name,p.returncode,flush=True)
 return dict(name=name,exit_code=p.returncode,command=cmd)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:outcomes=list(pool.map(execute,[p for p in record['protocols'] if p['exit_code']==0]))
(O/'outcomes.json').write_text(json.dumps(outcomes,indent=2)+'\n')
assert all(p['exit_code']==0 for p in outcomes),outcomes
