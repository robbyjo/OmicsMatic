from pathlib import Path
import hashlib,json,shutil,zipfile,xml.etree.ElementTree as ET
from datetime import datetime,timezone
ROOT=Path('D:/projects/JLinAlg');BASE=ROOT/'build/literature-review/mashr-runtime';OUT=BASE/'workflow-development-1';DOC=ROOT/'docs/literature'
def pin(path):
 with path.open('rb') as stream:return dict(bytes=path.stat().st_size,sha256=hashlib.file_digest(stream,'sha256').hexdigest())
def write(path,value):
 with path.open('x',encoding='utf-8',newline='\n') as stream:json.dump(value,stream,indent=2);stream.write('\n')
matrix=json.loads((OUT/'packaged-tests-1/COMPLETED.json').read_text())
assert matrix['status']=='passed-actual-JAR-native-mashr-workflow-numeric-matrix' and matrix['tests_per_JVM']==220
for name,value in matrix['source_and_dependency_pins'].items():assert pin(ROOT/name)==value,name
controls=BASE/'original-workflow-controls-5';record=json.loads((controls/'ORIGINAL-CONTROLS.json').read_text())
assert len(record['protocols'])==26 and sum(p['exit_code']==0 for p in record['protocols'])==17
assert sum(p['exit_code']==2 for p in record['protocols'])==8 and sum(p['exit_code']==3 for p in record['protocols'])==1
before=json.loads((controls/'runtime-before.json').read_text());after=json.loads((controls/'runtime-after.json').read_text());assert before['files']==after['files']
assert sum(map(len,before['files'].values()))==5637
jar=ROOT/matrix['artifact']['path'];assert pin(jar)=={key:matrix['artifact'][key] for key in ('bytes','sha256')}
canonical=ROOT/'build/cli/omicsmatic-0.3.7.jar';assert pin(canonical)==matrix['canonical_artifact_unchanged'] and pin(canonical)['sha256']=='bd1a3b2448d7016ae4ded3f30a6c5ae92e05a0078ae688f4b93d046cc355eeb2'
prior=json.loads((DOC/'MASHR_NATIVE_DEVELOPMENT_VALIDATION.json').read_text());assert all(pin(ROOT/n)==p for n,p in prior['source_pins'].items()),'The previous native foundation snapshot changed'
dependency=ROOT/'build/dependencies/jdistlib-all-0.10.2.jar'
with zipfile.ZipFile(jar) as current,zipfile.ZipFile(dependency) as expected:
 members=[n for n in expected.namelist() if n.startswith('jdistlib/') and not n.endswith('/')];assert len(members)==933
 assert all(current.read(n)==expected.read(n) for n in members)
roots=ET.parse(ROOT/'build/test-results/test/TEST-org.jlinalg.cli.MashWorkflowAuditTest.xml').getroot()
assert int(roots.attrib['tests'])==39 and all(int(roots.attrib[k])==0 for k in ('failures','errors','skipped'))
comparisons=0;maximumAbsolute=0.;maximumScaled=0.
for line in (roots.findtext('system-out') or '').splitlines():
 if '\tchecked=' in line:
  fields=dict(item.split('=',1) for item in line.split('\t')[1:]);comparisons+=int(fields['checked']);maximumAbsolute=max(maximumAbsolute,float(fields['maximum_absolute_error']));maximumScaled=max(maximumScaled,float(fields['maximum_scaled_error']))
assert comparisons==138625
assert sum(p['expected_training_rows'] for p in record['protocols'] if p['exit_code']==0)==1700
assert sum(p['expected_target_rows'] for p in record['protocols'] if p['exit_code']==0)==440
for name in ['windows21','windows25','linux21']:
 text=(OUT/'singleton-native-1'/(name+'.log')).read_text();assert 'SYNTHETIC: one feature, two conditions;' in text and 'fitted_null=0.900000000' in text and 'fitted_nonnull=0.100000000' in text
paths=[DOC/'MASHR_WORKFLOW_DEVELOPMENT.md',ROOT/'src/main/java/org/jlinalg/cli/MashWorkflowAudit.java',ROOT/'src/test/java/org/jlinalg/cli/MashWorkflowAuditTest.java',
 ROOT/'src/main/resources/org/jlinalg/omics/mashr-workflow/analysis.R',ROOT/'src/test/resources/org/jlinalg/cli/mashr-workflow/.gitattributes',ROOT/'src/test/resources/org/jlinalg/cli/mashr-workflow/original-controls.zip',
 ROOT/'examples/mashr-native/MashSingletonExample.java']
for name in ['collect_mashr_workflow_controls.py','freeze_mashr_workflow_controls.py','validate_mashr_workflow.py','MashWorkflowProbe.java','validate_mashr_native.py','mashr-development.init.gradle']:paths.append(ROOT/'tools/literature'/name)
sourcePins={p.relative_to(ROOT).as_posix():pin(p) for p in paths}
evidence={}
for path in paths:evidence['source/'+path.relative_to(ROOT).as_posix()]=path.read_bytes()
for name in ['src/main/java/org/jlinalg/shrinkage/MashGaussian.java','src/main/java/org/jlinalg/shrinkage/MashMixtureWeights.java','src/main/resources/org/jlinalg/omics/mashr-BSD-NOTICE.txt']:
 evidence['source/'+name]=(ROOT/name).read_bytes()
for path in (ROOT/'src/test/resources/org/jlinalg/shrinkage/mashr-original').glob('*.zip'):evidence['native-foundation-fixtures/'+path.name]=path.read_bytes()
for path in (ROOT/'src/test/java/org/jlinalg/shrinkage').glob('*.java'):evidence['source/'+path.relative_to(ROOT).as_posix()]=path.read_bytes()
for name in ['MASHR_NATIVE_DEVELOPMENT_VALIDATION.json','MASHR_PAPER_ROLE_DRAFT.json']:evidence['previous-milestone/'+name]=(DOC/name).read_bytes()
for path in (OUT/'packaged-tests-1').rglob('*'):
 if path.is_file():evidence['matrix/'+path.relative_to(OUT/'packaged-tests-1').as_posix()]=path.read_bytes()
for path in (ROOT/'build/test-results/test').glob('TEST-*Mash*.xml'):evidence['gradle/'+path.name]=path.read_bytes()
for name in ['tests-and-package-2.log','tests-and-package-3.log','tests-and-package-4.log','native-audits-1.log','run-audits.py','packaged-tests-1.log','finalize.py']:
 evidence['development/'+name]=(OUT/name).read_bytes()
for path in (OUT/'singleton-native-1').rglob('*'):
 if path.is_file():evidence['native-singleton-example/'+path.relative_to(OUT/'singleton-native-1').as_posix()]=path.read_bytes()
for path in (OUT/'native-audits-1').glob('*.numeric.json'):evidence['earlier-native-audit/'+path.name]=path.read_bytes()
for attempt in range(1,6):
 parent=BASE/('original-workflow-controls-'+str(attempt))
 for name in ['analysis.R','collector.py','FAILURE.json','WARNINGS.md','outcomes.json']:
  if (parent/name).is_file():evidence['retained-control-attempts/'+parent.name+'/'+name]=(parent/name).read_bytes()
 log=BASE/('original-workflow-controls-'+str(attempt)+'.log')
 evidence['retained-control-attempts/'+log.name]=log.read_bytes()
with zipfile.ZipFile(jar) as current:
 for name,value in matrix['packaged_owned_classes'].items():
  raw=current.read(name);assert dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())==value;evidence['packaged-owned-classes/'+name]=raw
evidence['README.txt']=b'Original mashr learning-workflow DEVELOPMENT evidence. Complete original corpus, all focused test results, three actual-JAR JVM runs, native singleton analytic example and exact current source. Public runtime/bundle admission, integrated native singleton orchestration and full paper curation remain pending. No whole-tool, whole-paper, source-to-binary rebuild or goal-completion claim.\n'
inventory={n:dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()) for n,raw in sorted(evidence.items())};evidence['inventory.json']=(json.dumps(inventory,indent=2)+'\n').encode()
archive=DOC/'mashr-workflow-development-controls.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as target:
 for name,raw in sorted(evidence.items()):
  item=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));item.create_system=3;item.external_attr=0o100644<<16;item.compress_type=zipfile.ZIP_DEFLATED;target.writestr(item,raw)
proof=dict(schema_version=1,status='passed-original-mashr-learning-and-native-numeric-development-validation',recorded_utc=datetime.now(timezone.utc).isoformat(),
 scope='Typed original PCA/ED, residual correlation and representative-population fit, followed by independent complete training-likelihood/target-posterior checks. Development only.',
 source_pins=sourcePins,artifact=matrix['artifact'],evidence_archive=dict(path=archive.relative_to(ROOT).as_posix(),**pin(archive)),
 original_controls=dict(protocols=26,completed_original_workflows=17,expected_FAIL2=8,expected_dependency_SKIP3=1,unchanged_Rhome_and_private_package_files=5637,
  target_population_leakage_control='passed; learned model files byte-identical after target-only alterations',native_training_rows=1700,native_target_rows=440,numeric_comparisons=comparisons,maximum_absolute_error=maximumAbsolute,maximum_scaled_error=maximumScaled),
 tests=dict(focused_Gradle=220,actual_JAR_per_JVM=220,JVMs=['Windows Java21','Windows Java25','Linux Java21'],heap_mib=128,failures=0,skips=0,full_project_suite_rerun=False),
 standalone_native_singleton_example=dict(analytic_fit_and_posterior_passed=True,JVMs=['Windows Java21','Windows Java25','Linux Java21'],padding_or_engine_substitution=False,integrated_native_workflow_available=False),
 warnings=[dict(code='ORIGINAL_SINGLE_FEATURE_FAILURES',action='Retain the Rcpp native abort and R dimension failures. The driver reports these rather than padding/rerouting data. Use the tested native Java API; integrated singleton execution remains pending.'),
  dict(code='ED_AND_RESIDUAL_EM_SOURCE_STOPPING',action='Inspect original logs and exact returned candidates/models. ED exposes no convergence flag; residual EM can roll back and has legacy counter/history indexing. A limit is not promoted to convergence.'),
  dict(code='DEVELOPMENT_ONLY',action='Complete managed runtime admission, native singleton orchestration, typed public CLI, full study bundles and final eight-paper semantic curation before promoting mashr.')],
 jdistlib_dependency=dict(**pin(dependency),unchanged_packaged_members=len(members)),canonical_artifact_unchanged=matrix['canonical_artifact_unchanged'],
 previous_native_foundation_source_pins_still_exact=True,source_to_upstream_binary_rebuild_verified=False,public_runtime_or_bundle_admitted=False,
 whole_mashr_integrated=False,whole_paper_reproduced=False,whole_goal_achieved=False,released_or_deployed=False,new_work_pushed=False,
 catalog_counts_unchanged=dict(new_scoped_integrations=61,native=13,upstream=48,missing_named_tools=259,mashr_status='missing'))
proofPath=DOC/'MASHR_WORKFLOW_DEVELOPMENT_VALIDATION.json';write(proofPath,proof)
checkpoint=BASE/'current-checkpoint.json';assert not (OUT/'previous-native-checkpoint.json').exists();shutil.copyfile(checkpoint,OUT/'previous-native-checkpoint.json')
checkpoint.write_text(json.dumps(dict(status=proof['status'],proof_path=proofPath.relative_to(ROOT).as_posix(),proof_pin=pin(proofPath),artifact=proof['artifact'],
 source_pins=sourcePins,goal_achieved=False,next_work=proof['warnings'][2]['action'],catalog_counts_unchanged=proof['catalog_counts_unchanged']),indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(status=proof['status'],source_files=len(sourcePins),evidence_files=len(inventory),evidence_archive=proof['evidence_archive'],original_controls=proof['original_controls'],tests=proof['tests']),indent=2))
