# FAIL2: original workflow validation incomplete

Original workflow outcomes differ from expected: [{"name": "single-target", "exit_code": 3221226505, "expected_exit_code": 0, "scientific_result_admitted": false, "expected_training_rows": 100, "expected_target_rows": 1, "expected_components": 41}]

Required action: preserve all attempts and original outputs. Inspect each process and source-status file. Correct the failure and repeat into a NEW directory. No study analysis is admitted.
