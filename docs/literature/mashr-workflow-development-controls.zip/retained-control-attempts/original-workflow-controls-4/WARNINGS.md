# FAIL2: original workflow validation incomplete

Original workflow outcomes differ from expected: [{"name": "single-target", "exit_code": 2, "expected_exit_code": 0, "scientific_result_admitted": false, "expected_training_rows": 100, "expected_target_rows": 1, "expected_components": 41}, {"name": "single-training", "exit_code": 2, "expected_exit_code": 0, "scientific_result_admitted": false, "expected_training_rows": 1, "expected_target_rows": 20, "expected_components": 41}]

Required action: preserve all attempts and original outputs. Inspect each process and source-status file. Correct the failure and repeat into a NEW directory. No study analysis is admitted.
