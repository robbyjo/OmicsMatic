import java.io.PrintWriter;
import org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder;
import org.junit.platform.launcher.core.LauncherFactory;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;
public final class RunFastpPublicChecks {
 private RunFastpPublicChecks() { }
 public static void main(String[] args) {
  var request=LauncherDiscoveryRequestBuilder.request().selectors(selectClass("org.jlinalg.sequence.FastpReadFilterTest"),selectClass("org.jlinalg.cli.FastpFastqTest"),selectClass("org.jlinalg.cli.FastpJoinTest"),selectClass("org.jlinalg.cli.FastpMetricsTest"),selectClass("org.jlinalg.cli.FastpOutputAuditTest"),selectClass("org.jlinalg.cli.FastpParametersTest"),selectClass("org.jlinalg.cli.FastpProcessTest"),selectClass("org.jlinalg.cli.FastpRecipeTest"),selectClass("org.jlinalg.cli.FastpRuntimeTest"),selectClass("org.jlinalg.cli.FastpSortTest"),selectClass("org.jlinalg.cli.FastpToolsCliTest")).build();
  var listener=new SummaryGeneratingListener();LauncherFactory.create().execute(request,listener);
  listener.getSummary().printTo(new PrintWriter(System.out));listener.getSummary().printFailuresTo(new PrintWriter(System.out));
  if(listener.getSummary().getTestsFailedCount()>0||listener.getSummary().getTestsFoundCount()!=415)System.exit(1);
 }
}
