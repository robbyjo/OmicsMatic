from pathlib import Path
import datetime,hashlib,json,zipfile,xml.etree.ElementTree as ET
R=Path('D:/projects/JLinAlg');W=R/'build/literature-review/fastp-runtime/public-workflow-development-1';D=R/'docs/literature';load=lambda p:json.loads(p.read_bytes());sha=lambda raw:hashlib.sha256(raw).hexdigest()
def pin(p):
 with p.open('rb') as stream:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(stream,'sha256').hexdigest())
paths=set();history=[]
for name in ['FASTP_NATIVE_DEVELOPMENT_VALIDATION.json','FASTP_ORIGINAL_STAGE_DEVELOPMENT_VALIDATION.json','FASTP_OUTPUT_AUDIT_DEVELOPMENT_VALIDATION.json']:
 old=load(D/name);paths.update(old['source_pins']);changes=[]
 for path,expected in old['source_pins'].items():
  if pin(R/path)!=expected:
   assert path=='src/main/java/org/jlinalg/cli/FastpOutputAudit.java' and pin(W/'FastpOutputAudit-before-large-capture-fix.java.txt')==expected
   changes.append(dict(path=path,before=expected,after=pin(R/path),reason='Use declared FASTQ input capacity rather than the small executable/setup fingerprint ceiling;new84.3MB original/public/portable regression validates the change.'))
 history.append(dict(report=name,unchanged_sources=len(old['source_pins'])-len(changes),scientific_changes=changes,historical_archive_preserved=True))
for folder,pattern in [('src/main/java/org/jlinalg/cli','Fastp*.java'),('src/test/java/org/jlinalg/cli','Fastp*Test.java')]:paths.update(p.relative_to(R).as_posix() for p in (R/folder).glob(pattern))
paths.update(['src/main/java/org/jlinalg/cli/JLinAlgCli.java','src/main/resources/org/jlinalg/omics/fastp-runtime-setup/install_fastp.py','src/test/resources/org/jlinalg/cli/fastp-workflow/public-controls.zip','docs/literature/FASTP_WORKFLOW.md','tools/literature/curate_fastp_uses.py','tools/literature/fastp-use-reviews.json','tools/literature/fastp_workflow_validation.py','tools/literature/test_fastp_workflow_validation.py','tools/literature/fastp_catalog.py'])
source={p:pin(R/p) for p in sorted(paths)};matrix=load(W/'packaged-tests-1/summary.json');assert matrix['tests_found_per_JVM']==415 and all(r['exit_code']==0 for r in matrix['runs']);jar=R/matrix['artifact'];assert pin(jar)['sha256']==matrix['artifact_sha256']=='723c5a322775cba5d279c92bd0bfe9e059d8308159c0b309e56e997eafc6d619'
assert pin(W/'package-2/omicsmatic-0.3.7-fastp-development.jar')==pin(jar);assert load(W/'large-portable-windows-1/observed.json')['exit_code']==0
independent=load(W/'independent-case-audit-1.json');assert independent['cases']==58 and independent['counts']['input_reads']==301560
tests={};total=skipped=0
for p in sorted((R/'build/test-results/test').glob('TEST-*Fastp*.xml')):
 a=ET.fromstring(p.read_bytes()).attrib;assert int(a['failures'])+int(a['errors'])==0;total+=int(a['tests']);skipped+=int(a['skipped']);tests[p.name]=dict(tests=int(a['tests']),skipped=int(a['skipped']))
assert (total,skipped)==(548,150)
for name in ['export-install-analysis-chain-1.json','guide-example-1.json']:assert all(r['exit_code']==0 for r in load(W/name)['records'])
payload={}
def add(name,p):assert name not in payload;payload[name]=p.read_bytes()
for name in source:add('source/'+name,R/name)
for name in ['public-workflow-controls-1.zip','large-workflow-control-1.zip','export-install-analysis-chain-1.zip','guide-example-1.zip','failed-smoke-1.zip','export-install-analysis-chain-1.json','guide-example-1.json','independent-case-audit-1.json']:add('validation/'+name,W/name)
for p in sorted((W/'packaged-tests-1').rglob('*')):
 if p.is_file() and 'classes' not in p.relative_to(W/'packaged-tests-1').parts:add('validation/'+p.relative_to(W).as_posix(),p)
for name in ['observed.json','stdout','stderr']:add('validation/large-portable-windows-1/'+name,W/'large-portable-windows-1'/name)
for p in sorted((R/'build/test-results/test').glob('TEST-*Fastp*.xml')):add('validation/final-gradle-tests/'+p.name,p)
for p in sorted(W.iterdir()):
 if p.is_file() and p.suffix in ['.py','.log','.txt']:add('development/'+p.name,p)
manifest={name:dict(bytes=len(raw),sha256=sha(raw)) for name,raw in sorted(payload.items())};payload['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode();target=D/'fastp-workflow-development-controls.zip';assert not target.exists()
with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,raw in sorted(payload.items()):z.writestr(name,raw)
proof=dict(schema_version=1,status='passed-scoped-fastp-public-workflow-and-portable-verification',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),artifact=dict(path=target.name,**pin(target)),source_pins=source,previous_checkpoint_sources=history,packaged_candidate=matrix['artifact'],packaged_candidate_sha256=matrix['artifact_sha256'],profiles=['linux-x86_64-fastp-'+v for v in ['0.22.0','0.23.2','0.25.0','1.0.1']],counts=independent['counts'],public_original_workflows=58,small_public_controls=57,large_input_bytes=84300000,large_input_reads=300000,large_portable_Windows_verified=True,packaged_tests=matrix,gradle_tests=dict(total=548,passed=398,skipped=150,failed=0,suites=tests),export_install_analysis_verify_chain=True,beginner_emitted_recipe_executed=True,initial_finalization_failure_preserved_without_completion=True,whole_paper_reproduced=False,biological_accuracy_certified=False,source_to_binary_reproduction_verified=False,released_or_deployed=False,scope='Complete captured input/output populations,source summary/cycle/five-mer statistics and conservative transformation/conservation envelopes;upstream adapter/overlap/poly-tail/Bloom decisions remain upstream. Portable verification does not rerun processing or readmit/authenticate the producer host.',catalog_promotion_pending=True)
p=D/'FASTP_WORKFLOW_DEVELOPMENT_VALIDATION.json';assert not p.exists();p.write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(dict(status=proof['status'],source_pins=len(source),artifact=proof['artifact'],counts=proof['counts'])))
