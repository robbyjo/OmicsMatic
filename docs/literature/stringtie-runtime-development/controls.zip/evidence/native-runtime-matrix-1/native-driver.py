
import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
base,cp,out=sys.argv[1:];base=Path(base);out=Path(out);assert not base.exists();base.mkdir(mode=0o755)
old=Path('/var/tmp/omicsmatic-stringtie-setup-20261103-1');versions=['1.3.0','1.3.6','2.1.2','2.1.7','2.2.1','3.0.0','3.0.3'];records=[]
def run(label,mode,version,home,report,uid=None):
 work=base/('work-'+label)
 command=['/usr/bin/java','-Xmx512m','-XX:ActiveProcessorCount=2','-cp',cp,'org.jlinalg.cli.StringTieRuntimeChecks',mode,'linux-x86_64-stringtie-'+version,str(home),str(report),str(work)]
 if uid:command=['/usr/bin/setpriv','--reuid='+str(uid),'--regid='+str(uid),'--clear-groups',*command]
 with (out/(label+'.stdout')).open('xb') as stdout,(out/(label+'.stderr')).open('xb') as stderr:
  result=subprocess.run(command,env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C'},stdout=stdout,stderr=stderr,timeout=160,check=False)
 record=dict(label=label,mode=mode,command=command,exit_code=result.returncode,work=str(work));records.append(record)
 (out/(label+'.process.json')).write_text(json.dumps(record,indent=2)+'\n');assert result.returncode==0,(label,result.returncode)
 if mode=='admit':shutil.copytree(work,out/'native-evidence'/label)
for version in versions:run('health-'+version,'admit',version,old/('home-'+version),old/('install-'+version))
run('changed-admission','tamper','3.0.3',old/'home-3.0.3',old/'recheck-3.0.3')
run('missing-home','missing-home','3.0.3',base/'not-installed',old/'install-3.0.3')
run('wrong-setup','wrong-setup','3.0.3',old/'home-3.0.3',old/'install-1.3.0')
run('capacity','capacity','3.0.3',old/'home-3.0.3',old/'install-3.0.3')
run('cancel','cancel','3.0.3',old/'home-3.0.3',old/'install-3.0.3')
# Real permission denial by an unprivileged UID, with a writable owned work parent.
permitted=base/'permission-work';permitted.mkdir(mode=0o700);os.chown(permitted,65534,65534)
protected=base/'forbidden-home';protected.mkdir(mode=0o700)
saved=base;base=permitted
run('forbidden-home','forbidden-home','3.0.3',protected,old/'install-3.0.3',65534)
base=saved
for record in records:
 if record['mode']!='admit':shutil.copytree(record['work'],out/'native-evidence'/record['label'])
(out/'NATIVE.json').write_text(json.dumps(dict(status='passed-seven-edition-fresh-supervised-health-and-retained-negative-controls',linux_root=str(base),fresh_original_health_fits=8,all_seven_editions=True,actual_permission_skip_uid=65534,records=records,user_analysis_admitted=False),indent=2)+'\n')
