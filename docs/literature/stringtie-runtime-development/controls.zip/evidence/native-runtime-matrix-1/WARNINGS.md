# FAIL2: StringTie native validation failed

('native-original-health', 1)

Preserve this attempt. Read FAILURE.json and retained process logs; correct the cause and rerun into NEW paths. No user analysis is admitted.
