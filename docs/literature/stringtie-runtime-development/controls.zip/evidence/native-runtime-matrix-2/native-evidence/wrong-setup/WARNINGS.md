# StringTie FAIL2_NO_RUNTIME_OR_RESULT_ADMITTED

java.io.IOException: Setup receipt does not bind this exact managed StringTie home/edition

Read WARNINGS.md, FAILURE.json and retained process stdout/stderr/ledgers. SKIP3 means a required permitted Linux runtime, helper, library or capability is unavailable: skip dependent analysis and complete permitted setup. FAIL2 means invalid or changed input/evidence, failed process/audit, cancellation or capacity failure: preserve the attempt, correct the cause and use NEW paths. No installation or download occurs during admission. Synthetic health alone does not admit a user fit or certify biological accuracy.
