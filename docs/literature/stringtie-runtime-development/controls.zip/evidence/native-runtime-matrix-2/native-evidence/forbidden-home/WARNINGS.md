# StringTie SKIP3_DEPENDENT_ANALYSIS_SKIPPED

org.jlinalg.cli.StringTieRuntime$Unavailable: Exact managed StringTie runtime home is missing or forbidden; run permitted setup or skip dependent analysis

Read WARNINGS.md, FAILURE.json and retained process stdout/stderr/ledgers. SKIP3 means a required permitted Linux runtime, helper, library or capability is unavailable: skip dependent analysis and complete permitted setup. FAIL2 means invalid or changed input/evidence, failed process/audit, cancellation or capacity failure: preserve the attempt, correct the cause and use NEW paths. No installation or download occurs during admission. Synthetic health alone does not admit a user fit or certify biological accuracy.
