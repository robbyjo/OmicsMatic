from pathlib import Path
import datetime,hashlib,json,subprocess,time,zipfile
ROOT=Path(__file__).resolve().parents[2];BASE=ROOT/'build/pops-workflow';OUT=BASE/'linux-driver-2';OUT.mkdir()
def pin(p):raw=p.read_bytes();return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def linux(p):s=p.resolve().as_posix();return '/mnt/'+s[0].lower()+s[2:]
prior=json.loads((ROOT/'build/pops/linux-replay-driver-2/PROCESS.json').read_bytes())['command'];cp=prior[prior.index('-cp')+1].split(':')
cp[0]=linux(BASE/'java-workflow-2/candidate.jar')
source=ROOT/'tools/literature/pops_workflow/PopsWorkflowJUnitReplay.java'
pins={source.relative_to(ROOT).as_posix():pin(source)}
for p in sorted((ROOT/'build/classes/java/test/org/jlinalg').glob('**/Pops*.class')):pins[p.relative_to(ROOT).as_posix()]=pin(p)
pins['build/pops-workflow/java-workflow-2/candidate.jar']=pin(BASE/'java-workflow-2/candidate.jar')
(OUT/'SOURCE-BEFORE.json').write_text(json.dumps(pins,indent=2)+'\n',encoding='utf-8')
with zipfile.ZipFile(OUT/'as-run-test-classes.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
 for name in pins:
  if name.endswith('.class'):z.write(ROOT/name,name)
command=['wsl','-d','JLinAlg-Omics-SAIGE-20261026','--exec','/usr/bin/java','-Xmx1024m','-cp',':'.join(cp),linux(source),linux(BASE/'linux-tests-2')]
start=time.monotonic()
with (OUT/'stdout').open('xb') as so,(OUT/'stderr').open('xb') as se:r=subprocess.run(command,cwd=ROOT,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=900)
record=dict(command=command,exit_code=r.returncode,seconds=round(time.monotonic()-start,3),sources_unchanged=all(pin(ROOT/n)==v for n,v in pins.items()),utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(OUT/'PROCESS.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8');print(json.dumps(record),flush=True)
print((OUT/'stdout').read_text(errors='replace')[-10000:],flush=True);print((OUT/'stderr').read_text(errors='replace')[-10000:],flush=True)
assert record['sources_unchanged'];raise SystemExit(r.returncode)
