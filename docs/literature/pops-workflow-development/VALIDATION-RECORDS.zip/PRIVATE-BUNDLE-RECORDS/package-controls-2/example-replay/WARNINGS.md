# Warnings and required actions

DEVELOPMENT: native PoPS 0.2 prepared inputs, ridge or minimum-norm OLS,
portable Java CPU. This is not PoPS 0.1 or LassoCV. No paper reproduction
or catalog integration credit follows from a completed software control.
Build current source; the released v0.4.0 download lacks this workflow.

Gene IDs are literal. Genome build, feature-set and target-source labels
are caller declarations, not validated biological provenance. No ID repair,
imputation, covariance repair, feature thinning or score scaling is done.
MAGMA covariance alone receives the source's uniform diagonal adjustment.
HLA removal follows chromosome string 6 and inclusive TSS 20-40 Mb.
The source ignores covariance between chromosomes; inspect warnings.tsv.
NaN marginal diagnostics are retained. An accepted prediction/coefficient
must be finite. A gene without a target retains NA target fields.

java_heap_mb bounds the worker JVM heap, not the parent or total process
memory. wall_ms and work bytes/entries are monitored, not OS disk quotas.
Feature batching does not bound covariance or selected-training storage.
Cancel normally to stop owned children. Hard-killing a Windows parent
has no process-job guarantee; stop its recorded worker if necessary.

Missing or forbidden prerequisites: SKIP3, dependent analysis skipped.
Supply the named permitted Java 17+ prerequisite or skip this analysis.
No runtime is installed during analysis. Other failures: FAIL2, no accepted
result. Retain inputs, consoles and FAILURE.txt; resolve the named cause
and retry NEW output. Never drop genes/features to satisfy capacity.

Only the root COMPLETED.properties admits this bundle. WORKER_DONE alone
does not. --verify hashes the full source bundle, then actually refits from
captured inputs into NEW output and compares all scientific result bytes.
Use the matching original artifact/profile; do not refresh saved hashes
to force a pass. Hashes establish integrity, not authenticity or signature.
