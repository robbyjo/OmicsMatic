from pathlib import Path
import datetime,hashlib,importlib.util,io,json,subprocess,zipfile

ROOT=Path(__file__).resolve().parents[2];BASE=ROOT/'build/pops-workflow';OUT=BASE/'closure-1';OUT.mkdir()
DOC=ROOT/'docs/literature/pops-workflow-development';DOC.mkdir()
def rawpin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def pin(p):
 size=0;h=hashlib.sha256()
 with p.open('rb') as stream:
  for raw in iter(lambda:stream.read(1048576),b''):size+=len(raw);h.update(raw)
 return dict(bytes=size,sha256=h.hexdigest())
def save(p,v):
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
spec=importlib.util.spec_from_file_location('pops_records',(ROOT/'tools/literature/pops_workflow/records.py'));r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()==r.BASE
science=json.loads((BASE/'java-workflow-1/VALIDATION.json').read_bytes());assert science['totals']==dict(tests=219,failures=0,errors=0,skipped=0)
tutorial=json.loads((BASE/'full-tutorial-1/COMPLETED.json').read_bytes());assert tutorial['all_three_scientific_result_inventories_identical'] and not tutorial['subsampled']
JAR=BASE/'java-workflow-1/candidate.jar';assert pin(JAR)==science['jar']
OLD=ROOT.parent.parent/'20261116-all-main-3/validation-2/candidate.jar'
assert OLD.is_file(),OLD
with zipfile.ZipFile(JAR) as a,zipfile.ZipFile(OLD) as b:
 aa=set(a.namelist());bb=set(b.namelist());assert bb<=aa
 modified=sorted(n for n in bb if a.read(n)!=b.read(n));added=sorted(aa-bb)
 assert modified==['org/jlinalg/cli/JLinAlgCli.class','org/jlinalg/cli/PopsWorkflowInputs.class'],modified
 assert all(n.startswith('org/jlinalg/cli/PopsWorkflow') and n.endswith('.class') for n in added)
 continuity=dict(status='PASS_ONLY_REVIEWED_MAIN_AND_INPUT_BINDING_CLASS_CHANGES',baseline_artifact=pin(OLD),candidate_artifact=pin(JAR),modified_existing_classes=modified,new_classes=added,unchanged_existing_members=len(bb)-len(modified))
save(BASE/'CLASS-CONTINUITY.json',continuity)
named=['inputs-reference-1','java-workflow-1','linux-driver-1','linux-tests-1','full-tutorial-1','package-controls-1']
drivers=['qualify-1.py','linux-1.py','tutorial-1.py','package-controls-1.py','package-records-1.py','CLASS-CONTINUITY.json']
private={}
for top in named:
 for p in sorted((BASE/top).rglob('*')):
  assert not p.is_symlink(),p
  if p.is_file():private[p.relative_to(BASE).as_posix()]=pin(p)
for name in drivers:private[name]=pin(BASE/name)
save(DOC/'PRIVATE-RECORDS.json',dict(scope='Complete bytes and membership of the explicitly named run directories and drivers only. Other build folders, the historical PoPS records, installed original runtime and closure outputs are outside this named inventory.',included_directories=named,included_driver_files=drivers,files=private,file_count=len(private),total_bytes=sum(v['bytes'] for v in private.values())))
public={}
def include(name,p=None):
 p=BASE/name if p is None else p;assert name not in public;public[name]=p.read_bytes()
for name in ['CLASS-CONTINUITY.json',*drivers]:
 if name not in public:include(name)
for folder in ['java-workflow-1','linux-driver-1','linux-tests-1','full-tutorial-1','package-controls-1']:
 for p in sorted((BASE/folder).iterdir()):
  if p.is_file() and p.name!='candidate.jar':include(p.relative_to(BASE).as_posix(),p)
for name in ['COMPLETED.json','MEMBERS.json','files/SOURCE.json']:include('inputs-reference-1/'+name)
for p in sorted((BASE/'inputs-reference-1/files').glob('format-*/*')):
 if p.is_file() and p.name in ['PROCESS.json','original.stdout','original.stderr']:include(p.relative_to(BASE).as_posix(),p)
# Bundle-record excerpts are metadata, not exported analysis bundles. Matrices stay private.
for top in ['full-tutorial-1/windows-batch-128','full-tutorial-1/windows-batch-1','full-tutorial-1/linux-replay','package-controls-1/example','package-controls-1/example-replay',*['package-controls-1/insufficient-'+n for n in ['max_input_bytes','max_work_bytes','max_files','java_heap_mb']]]:
 for p in sorted((BASE/top).iterdir()):
  if p.is_file():include('PRIVATE-BUNDLE-RECORDS/'+p.relative_to(BASE).as_posix(),p)
 for p in sorted((BASE/top/'results').glob('*')):
  if p.is_file() and p.name not in ['predictions.tsv','coefficients.tsv','marginals.tsv']:include('PRIVATE-BUNDLE-RECORDS/'+p.relative_to(BASE).as_posix(),p)
include('HISTORICAL-BASELINE/COMPLETED.json',ROOT.parent.parent/'20261116-all-main-3/frozen-record-readback-1/COMPLETED.json')
include('HISTORICAL-BASELINE/PROCESS.json',ROOT.parent.parent/'20261116-all-main-3/frozen-record-readback.process.json')
with zipfile.ZipFile(DOC/'VALIDATION-RECORDS.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,raw in sorted(public.items()):z.writestr(name,raw)
review={}
reasons={
 'src/main/java/org/jlinalg/cli/JLinAlgCli.java':'Only the explicit pops-tools dispatcher and help example are added; all existing branches remain byte-equivalent source.',
 'src/main/java/org/jlinalg/cli/PopsWorkflowInputs.java':'Complete declared-input duplicate-role checks; separate non-covariance parent layout audit; preserve source forward-selection overrides and arbitrary two MAGMA header lines; prevent sparse-pointer/entry limit overflow. The earlier file was explicitly unqualified scaffolding. All original prepared-file controls now execute.',
 'docs/literature/POPS_WORKFLOW_DEVELOPMENT.md':'Replace the earlier scaffolding-only availability statement with the qualified source workflow, exact controls and remaining scope.'}
for name in sorted(r.MODIFIED):
 old=subprocess.check_output(['git','show',r.BASE+':'+name],cwd=ROOT);review[name]=dict(before=rawpin(old),after=pin(ROOT/name),reason=reasons[name])
save(DOC/'CHANGE-REVIEW.json',dict(status='PASS_EXPLICIT_POPS_WORKFLOW_SOURCE_EXTENSION',baseline_commit=r.BASE,modified_existing_files=review,numerical_library_sources_changed=False,historical_evidence_sources_or_hashes_refreshed=False,catalog_metadata_changed=False,new_catalog_credit=0,main_dispatch_and_help_additions_only=True))
(DOC/'.gitattributes').write_bytes(b'* -text\n')
notice='''# Warnings and required actions

Qualified scope: native PoPS 0.2 prepared-file ridge/OLS and genuine replay.
Original v0.1, LassoCV runtime adapters, source paper parameters and catalog
admission remain open. No whole-paper or whole-goal completion is claimed.

Run pops-tools --help and read POPS_WORKFLOWS.md before using results. Only a
root COMPLETED.properties admits a workflow bundle. SKIP3 skips dependent
analysis when prerequisites are missing or forbidden. Supply the named permitted
Java prerequisite or leave it skipped. FAIL2 admits no result: retain all raw
records, correct the named cause and retry NEW output. Never thin genes/features,
repair covariance or refresh old hashes to obtain a pass.

VALIDATION-RECORDS.zip is a saved-record archive, not a complete analysis bundle
and not fresh analysis. PRIVATE-BUNDLE-RECORDS contains clearly named metadata
excerpts; captured matrices and full result tables remain in the complete named
private inventory. Original runtime installation bytes are not adopted here.
Use --private-base for exact named-file readback when those originals are present.
Hashes establish integrity, not signature or authenticity.

The earlier native checkpoint reader remains unchanged and is read on its real
clean commit 284dc02002305073136158ade28b48beb64e2721. This extension separately
reviews all current files relative to bcf69fcdf773682ff4920dbc484622ddc1bf0fca.
No scientific source overlay, Git identity substitution or historical hash refresh
is used. The literature source pages remain excluded from website deployment.
'''
(DOC/'WARNINGS.md').write_text(notice,encoding='utf-8',newline='\n')
sources={n:pin(ROOT/n) for n in sorted(r.SOURCES)};save(DOC/'SOURCE-PINS.json',dict(baseline_commit=r.BASE,files=sources))
evidence={p.relative_to(ROOT).as_posix():pin(p) for p in sorted(DOC.iterdir()) if p.is_file() and p.name not in ['SOURCE-PINS.json']}
save(DOC/'EVIDENCE-PINS.json',dict(files=evidence,archive_members={n:rawpin(raw) for n,raw in sorted(public.items())}))
save(DOC/'STATUS.json',dict(status='PASS_NATIVE_POPS_PREPARED_WORKFLOW_AND_COMPLETE_CROSS_OS_REPLAY',baseline_commit=r.BASE,source_pins=pin(DOC/'SOURCE-PINS.json'),evidence_pins=pin(DOC/'EVIDENCE-PINS.json'),candidate_jar=science['jar'],tests_each_platform=219,npy_matrix_format_cases=132,saved_original_cases=13,fresh_original_format_cases=6,original_successes=17,expected_original_failures=2,full_tutorial=tutorial,private_files=len(private),private_bytes=sum(v['bytes'] for v in private.values()),public_archive_bytes=(DOC/'VALIDATION-RECORDS.zip').stat().st_size,canonical_workflow_available=True,normal_dispatch_available=True,original_runtime_adapter_available=False,v01_qualified=False,lasso_qualified=False,new_catalog_credit=0,whole_goal_complete=False))
save(OUT/'PREPARED.json',dict(status='PASS_NATIVE_POPS_WORKFLOW_RECORDS_PREPARED',sources=len(sources),public_records=len(public),named_private_files=len(private),named_private_bytes=sum(v['bytes'] for v in private.values()),archive_bytes=(DOC/'VALIDATION-RECORDS.zip').stat().st_size))
print((OUT/'PREPARED.json').read_text(),flush=True)
