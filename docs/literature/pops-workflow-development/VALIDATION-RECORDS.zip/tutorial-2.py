from pathlib import Path
import csv,datetime,hashlib,json,os,subprocess,time

ROOT=Path(__file__).resolve().parents[2];BASE=ROOT/'build/pops-workflow';OUT=BASE/'full-tutorial-2';OUT.mkdir()
JAR=BASE/'java-workflow-2/candidate.jar';JAVA='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe'
def pin(p):raw=p.read_bytes();return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(p,v):
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def linux(p):s=p.resolve().as_posix();return '/mnt/'+s[0].lower()+s[2:]
qualified=json.loads((BASE/'java-workflow-2/VALIDATION.json').read_bytes());assert qualified['totals']==dict(tests=219,failures=0,errors=0,skipped=0);assert pin(JAR)==qualified['jar']
UP=ROOT/'build/pops/source-audit-1/upstream';DATA=UP/'example/data';files=[DATA/'utils/gene_annot_jun10.txt',DATA/'utils/features_jul17_control.txt',DATA/'features_munged/pops_features.rows.txt',DATA/'magma_scores/PASS_Schizophrenia.genes.raw',DATA/'magma_scores/PASS_Schizophrenia.genes.out']
for i in range(2):files.extend([DATA/f'features_munged/pops_features.cols.{i}.txt',DATA/f'features_munged/pops_features.mat.{i}.npy'])
manifest=json.loads((ROOT/'build/pops/source-audit-1/MANIFEST.json').read_bytes()) if (ROOT/'build/pops/source-audit-1/MANIFEST.json').exists() else json.loads((ROOT/'build/pops/tutorial-original-1/INPUT-IDENTITY.json').read_bytes())['manifest']
before={p.relative_to(UP).as_posix():pin(p) for p in files}
for name,identity in before.items():assert identity==manifest['files'][name],name
save(OUT/'INPUTS-BEFORE.json',before)
settings=dict(profile='pops-native-prepared-v1',edition='0.2',method='ridge',target_type='magma',gene_annotation=str(files[0]),control_features=str(files[1]),feature_prefix=str(DATA/'features_munged/pops_features'),feature_chunks='2',magma_prefix=str(DATA/'magma_scores/PASS_Schizophrenia'),genome_build='upstream-supplied-annotation-not-independently-validated',feature_set_id='official-pops-76eb86c-example-508-features',target_source_id='official-schizophrenia-example',java_heap_mb='8192',wall_ms='900000',max_input_bytes='536870912',max_work_bytes='2147483648',max_files='1000')
def request(batch):
 p=OUT/f'batch-{batch}.properties'
 with p.open('x',encoding='utf-8',newline='\n') as f:
  for k,v in sorted(dict(settings,batch_columns=str(batch)).items()):f.write(k+'='+v.replace('\\','/').replace(':','\\:')+'\n')
 return p
def execute(name,command):
 start=time.monotonic();print(json.dumps(dict(stage=name,status='STARTED')),flush=True)
 with (OUT/(name+'.stdout')).open('xb') as so,(OUT/(name+'.stderr')).open('xb') as se:r=subprocess.run(command,cwd=ROOT,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=1200)
 record=dict(command=command,exit_code=r.returncode,seconds=round(time.monotonic()-start,3),utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save(OUT/(name+'.process.json'),record)
 print(json.dumps(dict(stage=name,**record)),flush=True)
 assert r.returncode==0,(name,(OUT/(name+'.stderr')).read_text(errors='replace')[-5000:])
def rows(path):
 with path.open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f,delimiter='\t'))
def inventory(folder):return {p.relative_to(folder).as_posix():pin(p) for p in sorted(folder.rglob('*')) if p.is_file()}
a=OUT/'windows-batch-128';execute('windows-batch-128',[JAVA,'-Xmx1024m','-jar',str(JAR),'pops-tools','--request',str(request(128)),'--out',str(a)])
b=OUT/'windows-batch-1';execute('windows-batch-1',[JAVA,'-Xmx1024m','-jar',str(JAR),'pops-tools','--request',str(request(1)),'--out',str(b)])
assert inventory(a/'results')==inventory(b/'results'),'Scientific tables depend on batching'
c=OUT/'linux-replay';execute('linux-replay',['wsl','-d','JLinAlg-Omics-SAIGE-20261026','--exec','/usr/bin/java','-Xmx1024m','-jar',linux(JAR),'pops-tools','--verify',linux(a),'--out',linux(c)])
assert inventory(a/'results')==inventory(c/'results'),'Cross-OS genuine replay scientific bytes differ'
original=ROOT/'build/pops/tutorial-original-1';gold=rows(original/'original.preds');actual=rows(a/'results/predictions.tsv');assert len(gold)==len(actual)==18383
pred_error=0
for x,y in zip(gold,actual):assert x['ENSGID']==y['ENSGID'];pred_error=max(pred_error,abs(float(x['PoPS_Score'])-float(y['PoPS_Score'])))
oldm=rows(original/'original.marginals');newm=rows(a/'results/marginals.tsv');assert len(oldm)==len(newm)==508
import math
marg_error=0;selected=0
for x,y in zip(oldm,newm):
 assert x['']==y['feature'] and (x['selected']=='True')==(y['selected']=='1')
 selected+=y['selected']=='1'
 for oldkey,newkey in [('beta','beta'),('se','se'),('pval','pval'),('r2','r2')]:
  u=float(x[oldkey]) if x[oldkey] else float('nan');v=float(y[newkey])
  if math.isnan(u):assert math.isnan(v)
  else:marg_error=max(marg_error,abs(u-v))
assert selected==258
oldcoef={r['parameter']:r['beta'] for r in rows(original/'original.coefs')};coef_error=0
for row in rows(a/'results/coefficients.tsv'):coef_error=max(coef_error,abs(float(row['coefficient'])-float(oldcoef.get(row['feature'],'0'))))
assert max(pred_error,marg_error,coef_error)<5e-8
after={p.relative_to(UP).as_posix():pin(p) for p in files};assert before==after and pin(JAR)==qualified['jar']
save(OUT/'COMPLETED.json',dict(status='PASS_COMPLETE_OFFICIAL_POPS_TUTORIAL_TWO_BATCH_WIDTHS_AND_CROSS_OS_GENUINE_REPLAY',prediction_genes=18383,target_genes=16980,training_genes=16752,features=508,selected_features=258,batch_widths=[128,1],worker_heap_mb=8192,parent_heap_mb=1024,maximum_absolute_prediction_error=pred_error,maximum_absolute_marginal_error=marg_error,maximum_absolute_coefficient_error=coef_error,all_three_scientific_result_inventories_identical=True,original_source_and_inputs_unchanged=True,subsampled=False,artifact=qualified['jar'],whole_goal_complete=False))
print((OUT/'COMPLETED.json').read_text(),flush=True)
