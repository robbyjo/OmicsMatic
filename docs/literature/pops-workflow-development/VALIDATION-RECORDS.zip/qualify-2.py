from pathlib import Path
import datetime,hashlib,json,os,subprocess,time,zipfile,xml.etree.ElementTree as E

ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'build/pops-workflow/java-workflow-2';OUT.mkdir()
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
sources=sorted(ROOT.glob('src/main/java/org/jlinalg/**/Pops*.java'))+sorted(ROOT.glob('src/test/java/org/jlinalg/**/Pops*.java'))+[ROOT/'src/main/java/org/jlinalg/cli/JLinAlgCli.java',ROOT/'tools/literature/pops_workflow/reference_inputs.py',ROOT/'src/test/resources/org/jlinalg/cli/pops-workflow-inputs.zip']
def pins():return {p.relative_to(ROOT).as_posix():pin(p.read_bytes()) for p in sources}
before=pins();(OUT/'SOURCE-BEFORE.json').write_text(json.dumps(before,indent=2)+'\n',encoding='utf-8')
with zipfile.ZipFile(OUT/'as-run-sources.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
 for p in sources:z.write(p,p.relative_to(ROOT).as_posix())
env=os.environ.copy();env['JAVA_HOME']='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot';env['PATH']=env['JAVA_HOME']+'/bin'+os.pathsep+env['PATH']
command=[str(ROOT/'gradlew.bat'),':test','--tests','org.jlinalg.genetics.Pops*','--tests','org.jlinalg.cli.PopsWorkflow*','executableJar','checkWebsite','--no-daemon','--max-workers=2','--console=plain']
started=time.monotonic()
with (OUT/'stdout').open('xb') as so,(OUT/'stderr').open('xb') as se:r=subprocess.run(command,cwd=ROOT,env=env,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=1800)
record=dict(command=command,exit_code=r.returncode,seconds=round(time.monotonic()-started,3),sources_unchanged=before==pins(),utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(OUT/'PROCESS.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8');print(json.dumps(record),flush=True)
print((OUT/'stdout').read_text(errors='replace')[-15000:],flush=True);print((OUT/'stderr').read_text(errors='replace')[-15000:],flush=True)
assert record['sources_unchanged']
if r.returncode:raise SystemExit(r.returncode)
totals=dict(tests=0,failures=0,errors=0,skipped=0);suites=[]
with zipfile.ZipFile(OUT/'test-results.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
 for p in sorted((ROOT/'build/test-results/test').glob('TEST-*.xml')):
  raw=p.read_bytes();x=E.fromstring(raw);row=dict(name=x.get('name'))
  for k in totals:row[k]=int(x.get(k));totals[k]+=row[k]
  suites.append(row);z.writestr(p.name,raw)
jar=(ROOT/'build/cli/omicsmatic-0.4.0.jar').read_bytes();(OUT/'candidate.jar').write_bytes(jar)
(OUT/'VALIDATION.json').write_text(json.dumps(dict(status='PASS_CURRENT_POPS_WORKFLOW_TESTS',totals=totals,suites=suites,jar=pin(jar)),indent=2)+'\n',encoding='utf-8');print(json.dumps(totals),flush=True)
