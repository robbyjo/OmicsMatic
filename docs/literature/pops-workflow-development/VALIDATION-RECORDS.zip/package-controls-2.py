from pathlib import Path
import datetime,hashlib,io,json,subprocess,time,zipfile
ROOT=Path(__file__).resolve().parents[2];BASE=ROOT/'build/pops-workflow';OUT=BASE/'package-controls-2';OUT.mkdir()
JAR=BASE/'java-workflow-2/candidate.jar';JAVA='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe'
def save(p,v):
 with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2);f.write('\n')
example=ROOT/'examples/pops-workflow/synthetic-inputs.zip';inputs=OUT/'inputs';inputs.mkdir()
with zipfile.ZipFile(example) as z:z.extractall(inputs)
command=[JAVA,'-Xmx512m','-jar',str(JAR),'pops-tools'];records=[]
def execute(name,flags,expected):
 start=time.monotonic()
 with (OUT/(name+'.stdout')).open('xb') as so,(OUT/(name+'.stderr')).open('xb') as se:r=subprocess.run(command+flags,cwd=ROOT,stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=180)
 row=dict(name=name,command=command+flags,exit_code=r.returncode,expected=expected,seconds=round(time.monotonic()-start,3));save(OUT/(name+'.process.json'),row);records.append(row)
 assert r.returncode==expected,(name,(OUT/(name+'.stderr')).read_text(errors='replace')[-3000:])
 if expected:assert not (OUT/name/'COMPLETED.properties').exists() and (OUT/name/'FAILURE.txt').is_file()
execute('help',['--help'],0)
execute('example',['--request',str(inputs/'request.properties'),'--out',str(OUT/'example')],0)
execute('example-replay',['--verify',str(OUT/'example'),'--out',str(OUT/'example-replay')],0)
for field,value in [('max_input_bytes','1'),('max_work_bytes','1'),('max_files','1'),('java_heap_mb','1')]:
 name='insufficient-'+field;request=OUT/(name+'.properties');text=(inputs/'request.properties').read_text()
 # Preserve the actual synthetic inputs; request-relative paths become explicit.
 replacements=dict(gene_annotation=str(inputs/'annotation.tsv'),feature_prefix=str(inputs/'features'),scores=str(inputs/'scores.tsv'),**{field:value})
 for key,v in replacements.items():
  lines=text.splitlines();text='\n'.join(key+'='+v.replace('\\','/').replace(':','\\:') if line.startswith(key+'=') else line for line in lines)+'\n'
 request.write_text(text,encoding='utf-8');execute(name,['--request',str(request),'--out',str(OUT/name)],2)
 assert ('max_' in field and field in (OUT/name/'FAILURE.txt').read_text()) or field=='java_heap_mb'
 if field=='java_heap_mb':
  error=(OUT/(name+'.stderr')).read_text();assert 'Cause from worker.stdout' in error and 'Too small maximum heap' in error and 'adjust java_heap_mb' in error,error
save(OUT/'COMPLETED.json',dict(status='PASS_PACKAGED_POPS_EXAMPLE_REPLAY_AND_RESOURCE_REFUSALS',controls=records,artifact_sha256=hashlib.sha256(JAR.read_bytes()).hexdigest(),whole_goal_complete=False))
print(json.dumps(dict(status='PASS_PACKAGED_POPS_EXAMPLE_REPLAY_AND_RESOURCE_REFUSALS',controls=len(records))),flush=True)
