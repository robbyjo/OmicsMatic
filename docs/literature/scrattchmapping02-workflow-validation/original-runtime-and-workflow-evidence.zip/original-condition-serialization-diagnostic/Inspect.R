args <- commandArgs(TRUE);base <- args[[1L]];out <- args[[2L]]
paths <- c(original=file.path(base,"scrattch02-workflow-references-2/references/no_cells/complete-conditions.rds"),
 repeat_original=file.path(base,"scrattch02-original-no-cells-repeat-1/original/complete-conditions.rds"),
 adapter=file.path(base,"scrattch02-workflow-check-2/no_cells/analysis/original/complete-conditions.rds"))
objects <- lapply(paths,readRDS)
encoded <- lapply(objects,function(x)serialize(x$error,NULL,version=3))
for(name in names(encoded))writeBin(encoded[[name]],file.path(out,paste0(name,"-complete-error.r-serialization")))
strict <- function(x,y)identical(x,y,num.eq=FALSE,single.NA=FALSE,attrib.as.set=FALSE,ignore.bytecode=FALSE,ignore.environment=FALSE,ignore.srcref=FALSE,extptr.as.ref=TRUE)
report <- list(status="COMPLETE_NATIVE_R_SERIALIZATION_DIAGNOSTIC_NOT_QUALIFICATION",
 original_repeat_strict_object_identical=strict(objects$original$error,objects$repeat_original$error),
 adapter_strict_object_identical=strict(objects$original$error,objects$adapter$error),
 original_repeat_complete_serialization_identical=identical(encoded$original,encoded$repeat_original),
 adapter_complete_serialization_identical=identical(encoded$original,encoded$adapter),
 serialized_bytes=lapply(encoded,length),fields_deleted_or_coerced=FALSE,
 live_external_pointer_address_identity_claimed=FALSE,new_family_credit=0L,whole_goal_complete=FALSE)
jsonlite::write_json(report,file.path(out,"DIAGNOSTIC.json"),pretty=TRUE,auto_unbox=TRUE,null="null")
print(report)
