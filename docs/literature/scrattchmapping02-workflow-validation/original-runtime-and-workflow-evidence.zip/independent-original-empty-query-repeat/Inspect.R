args <- commandArgs(TRUE);base <- args[[1L]];out <- args[[2L]]
ref <- readRDS(file.path(base,"scrattch02-workflow-references-2/references/no_cells/complete-conditions.rds"))$error
repeat.original <- readRDS(file.path(out,"original/complete-conditions.rds"))$error
adapter <- readRDS(file.path(base,"scrattch02-workflow-check-2/no_cells/analysis/original/complete-conditions.rds"))$error
strict <- function(a,b)identical(a,b,num.eq=FALSE,single.NA=FALSE,attrib.as.set=FALSE,ignore.bytecode=FALSE,ignore.environment=FALSE,ignore.srcref=FALSE,extptr.as.ref=TRUE)
report <- list(status="ORIGINAL_ERROR_IDENTITY_DIAGNOSTIC_NOT_QUALIFICATION",
 original_repeat_strict_identical=strict(ref,repeat.original),adapter_strict_identical=strict(ref,adapter),
 original_repeat_same_message=identical(conditionMessage(ref),conditionMessage(repeat.original)),
 adapter_same_message=identical(conditionMessage(ref),conditionMessage(adapter)),
 original_repeat_same_class=identical(class(ref),class(repeat.original)),adapter_same_class=identical(class(ref),class(adapter)),
 call_head_types=vapply(list(ref,repeat.original,adapter),function(x)typeof(conditionCall(x)[[1L]]),character(1)),
 new_family_credit=0L,whole_goal_complete=FALSE)
heads <- lapply(list(ref,repeat.original,adapter),function(x)conditionCall(x)[[1L]])
if(all(vapply(heads,is.function,logical(1)))) {
 report$original_repeat_same_call_function_body <- strict(body(heads[[1L]]),body(heads[[2L]]))
 report$adapter_same_call_function_body <- strict(body(heads[[1L]]),body(heads[[3L]]))
 report$original_repeat_same_call_function_environment <- strict(environment(heads[[1L]]),environment(heads[[2L]]))
 report$adapter_same_call_function_environment <- strict(environment(heads[[1L]]),environment(heads[[3L]]))
 report$call_function_environment_bindings <- lapply(heads,function(x)ls(environment(x),all.names=TRUE))
 report$call_function_environment_binding_types <- lapply(heads,function(x) {
  e <- environment(x);setNames(vapply(ls(e,all.names=TRUE),function(name)typeof(get(name,e,inherits=FALSE)),character(1)),ls(e,all.names=TRUE))
 })
}
jsonlite::write_json(report,file.path(out,"DIAGNOSTIC.json"),pretty=TRUE,auto_unbox=TRUE,null="null")
print(report)
