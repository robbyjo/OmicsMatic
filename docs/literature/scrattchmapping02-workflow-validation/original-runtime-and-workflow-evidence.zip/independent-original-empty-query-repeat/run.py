from pathlib import Path
import sys,subprocess,shutil
sys.dont_write_bytecode=True
R=Path('/mnt/d/projects/JLinAlg');M=R/'tools/literature/scrattchmapping02';sys.path.insert(0,str(M))
from Runtime import load,save,environment,pin
B=R/'build/literature-review/monocle-runtime';O=B/'scrattch02-original-no-cells-repeat-1'
D=O/'original';D.mkdir(exist_ok=False)
for name in ['home','tmp']:(D/name).mkdir()
ready=load(B/'scrattch02-upstream-provider-3/READY.json')
request=B/'scrattch02-workflow-references-2/requests/no_cells.rds'
cmd=[str(Path(ready['r_prefix'])/'bin/Rscript'),'--vanilla',str(M/'DirectWorkflow.R'),str(request),str(D)]
with (O/'original.stdout').open('xb') as so,(O/'original.stderr').open('xb') as se:
 child=subprocess.run(cmd,cwd=D,env=environment(ready,D),stdin=subprocess.DEVNULL,stdout=so,stderr=se)
save(O/'PROCESS.json',dict(command=cmd,exit_code=child.returncode,direct_source=pin(M/'DirectWorkflow.R')))
if child.returncode:raise SystemExit(child.returncode)
cmd=[str(Path(ready['r_prefix'])/'bin/Rscript'),'--vanilla',str(O/'Inspect.R'),str(B),str(O)]
with (O/'inspection.stdout').open('xb') as so,(O/'inspection.stderr').open('xb') as se:
 child=subprocess.run(cmd,cwd=D,env=environment(ready,D),stdin=subprocess.DEVNULL,stdout=so,stderr=se)
save(O/'INSPECTION-PROCESS.json',dict(command=cmd,exit_code=child.returncode))
print('ORIGINAL_REPEAT_INSPECTION_EXIT',child.returncode,flush=True)
