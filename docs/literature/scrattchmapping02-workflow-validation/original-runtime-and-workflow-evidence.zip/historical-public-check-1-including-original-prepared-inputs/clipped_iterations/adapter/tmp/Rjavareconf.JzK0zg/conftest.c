#include <jni.h>

int main(void) {
    JNI_CreateJavaVM(0, 0, 0);
    return 0;
}
