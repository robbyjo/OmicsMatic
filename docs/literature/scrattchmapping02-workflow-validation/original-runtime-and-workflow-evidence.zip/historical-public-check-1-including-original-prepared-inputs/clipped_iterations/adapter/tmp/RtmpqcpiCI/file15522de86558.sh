. /opt/omicsmatic-scrattchmapping02-public-install-20261114-1/conda-manager/.pixi/envs/default/bin/activate
conda activate '/opt/omicsmatic-scrattchmapping02-public-install-20261114-1/runtime/.pixi/envs/default'
'python' -c "import os; print(os.environ['PATH'])"
