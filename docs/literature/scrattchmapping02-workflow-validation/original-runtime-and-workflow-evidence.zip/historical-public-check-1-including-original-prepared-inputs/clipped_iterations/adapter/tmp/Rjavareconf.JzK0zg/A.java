public class A { }
