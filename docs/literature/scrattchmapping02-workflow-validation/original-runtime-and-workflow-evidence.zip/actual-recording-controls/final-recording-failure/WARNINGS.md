# FAIL2_FINAL_RECORDING_UNAVAILABLE: PermissionError('TEST: final manifest recording unavailable after actual original analysis'); PASS_ORIGINAL_MAPPING02_COMPLETE_R_OBJECT

**WARNING REVIEW REQUIRED. Complete result admitted: False.**

Original R handler totals: {'warning': 16, 'message': 72, 'error': 0}. Raw/native diagnostic totals are unavailable, never zero.

**Original warning x 1**

    replacing previous import ‘MatrixGenerics::rowMedians’ by ‘mfishtools::rowMedians’ when loading ‘scrattch.mapping’

**Original warning x 1**

    replacing previous import ‘mfishtools::map_dend’ by ‘scrattch.hicat::map_dend’ when loading ‘scrattch.mapping’

**Original warning x 1**

    replacing previous import ‘dendextend::pvclust_show_signif_gradient’ by ‘scrattch.hicat::pvclust_show_signif_gradient’ when loading ‘scrattch.mapping’

**Original warning x 1**

    replacing previous import ‘mfishtools::resolve_cl’ by ‘scrattch.hicat::resolve_cl’ when loading ‘scrattch.mapping’

**Original warning x 6**

    'length(x) = 24 > 1' in coercion to 'logical(1)'

**Original warning x 6**

    'length(x) = 8 > 1' in coercion to 'logical(1)'

Review WARNINGS.md, every raw console, and the complete original R conditions. Missing or forbidden requirements SKIP3 skip dependent analysis. FAIL2 admits no complete result. Resolve the named cause and retry NEW writable output paths, retaining original inputs and all partial files. Use trusted RDS requests and a complete prepared reference/index asset directory. This adapter does not retrieve Allen private taxonomies or infer paper parameters. Use unchanged scrattch.mapping 0.2 with the selected private Linux/WSL R 4.2.3 profile; this is not a recovered author environment. Analysis does not install or download. The scrattch.io and scrattch.vis dependencies restrict commercial redistribution; keep the private runtime separate from distributable project artifacts. Do not repair identifiers, NA/NaN/Inf, source behavior, or historical evidence hashes. All original warnings require review; raw/native diagnostic totals are unavailable, never zero. No whole-package, biological, paper-reproduction, or full-250-paper completion claim is made.
