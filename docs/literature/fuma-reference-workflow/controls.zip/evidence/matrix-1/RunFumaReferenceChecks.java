import java.io.File;
import java.io.PrintWriter;
import org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder;
import org.junit.platform.launcher.core.LauncherFactory;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;
public final class RunFumaReferenceChecks {
 private RunFumaReferenceChecks() { }
 public static void main(String[] args)throws Exception {
  System.out.println("java.version="+System.getProperty("java.version"));System.out.println("os.name="+System.getProperty("os.name"));
  if(!System.getProperty("java.specification.version").equals(args[1]))throw new AssertionError("Wrong JVM");
  for(String name:new String[]{"org.jlinalg.genetics.FumaReferencePreparation","org.jlinalg.genetics.HardcallLd","org.jlinalg.genetics.FumaLocusDefinition","org.jlinalg.cli.FumaReferenceCli","org.jlinalg.cli.FumaLociCli","org.jlinalg.cli.FumaWorkflowCli"})
   if(!Class.forName(name).getProtectionDomain().getCodeSource().getLocation().toURI().equals(new File(args[0]).toURI()))throw new AssertionError("Wrong artifact: "+name);
  var listener=new SummaryGeneratingListener();LauncherFactory.create().execute(LauncherDiscoveryRequestBuilder.request().selectors(selectClass("org.jlinalg.genetics.HardcallLdTest"),selectClass("org.jlinalg.genetics.HardcallLdOriginalTest"),selectClass("org.jlinalg.genetics.FumaLdWindowTest"),selectClass("org.jlinalg.genetics.FumaLocusDefinitionTest"),selectClass("org.jlinalg.genetics.FumaReferencePreparationTest"),selectClass("org.jlinalg.genetics.FumaReferenceOriginalTest"),selectClass("org.jlinalg.cli.FumaReferenceCliTest"),selectClass("org.jlinalg.cli.FumaLociCliTest")).build(),listener);var s=listener.getSummary();s.printTo(new PrintWriter(System.out));s.printFailuresTo(new PrintWriter(System.out));
  if(s.getTestsFoundCount()!=104||s.getTestsSucceededCount()!=104||s.getTestsSkippedCount()!=0||s.getTestsAbortedCount()!=0||s.getTestsFailedCount()!=0||s.getContainersFailedCount()!=0)throw new AssertionError("Incomplete reference workflow validation");
 }
}
