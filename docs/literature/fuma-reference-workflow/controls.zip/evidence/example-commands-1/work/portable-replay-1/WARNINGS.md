# FUMA REFERENCE WARNINGS REQUIRE REVIEW

LOCAL AUTOSOMAL DIPLOID REFERENCE ONLY. The supplied assembly/population/release and FAM founder flags are declarations, not independently established ancestry, ploidy or provenance. Numeric chromosomes 1..22 only. No reference download, imputation, phased LD, sex-chromosome model or historical hosted FUMA reconstruction. Required action: review all selections, exclusions, pair coverage and resource identities before downstream use.

WINDOW COVERAGE: rank is genomic order AFTER the recorded MAF/constant-call exclusions. Both distance and index-gap limits are inclusive. Pairs outside either limit are uncomputed, not observed zero/weak LD. Inside-window omitted pairs are assessed and strictly below the inclusive storage floor. Required action: carry reference-bundle.json and the entire payload into the locus command; do not copy the sparse LD table alone and assert unbounded coverage.

VARIANT EXCLUSIONS: 3 requested variants were excluded; every requested row remains captured in genotypes.bin and variant-audit.tsv. Unobserved calls, fewer than two observed calls, zero MAF, constant observed genotypes (including all-heterozygous rows), and below-minimum MAF are separate decisions. Required action: inspect each exclusion and sample-selection.tsv; these decisions change the reference rank/window family.
