"""Freeze the validated, local FUMA reference workflow milestone without catalog promotion."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
import zipfile

ROOT=Path('D:/projects/JLinAlg')
RUN=ROOT/'build/literature-review/fuma-runtime/reference-workflow-development-1'
DEST=ROOT/'docs/literature/fuma-reference-workflow'

def pin(p):
    raw=p.read_bytes()
    return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,j):p.write_text(json.dumps(j,indent=2)+'\n',encoding='utf-8',newline='\n')
def census(p):return {q.relative_to(p).as_posix():pin(q) for q in sorted(p.rglob('*')) if q.is_file()}

matrix=read(RUN/'matrix-1/COMPLETED.json')
commands=read(RUN/'example-commands-1/COMPLETED.json')
family=read(RUN/'family-tests-3-summary.json')
prior_path=ROOT/'docs/literature/fuma-ld-core/VALIDATION.json'
prior=read(prior_path)
assert matrix['status']=='passed-three-JVM-packaged-FUMA-reference-workflow' and matrix['tests_per_JVM']==104 and len(matrix['runs'])==3
assert commands['status']=='passed-packaged-reference-commands-and-portable-replay' and len(commands['calls'])==6
assert family['tests']==619 and family['failed']==family['skipped']==family['errors']==0
sources=dict(matrix['source_pins'])
for n,v in commands['source_pins'].items():
    if n in sources:assert sources[n]==v,n
    sources[n]=v
for name in ['tools/literature/validate_mashr_native.py','src/main/java/org/jlinalg/cli/FollowupSupport.java','src/main/java/org/jlinalg/cli/AdmixtureInputs.java','src/main/java/org/jlinalg/cli/SimpleJson.java','src/main/java/org/jlinalg/cli/RegenieRuntime.java','src/main/java/org/jlinalg/cli/RnaToolRuntime.java']:
    sources[name]=pin(ROOT/name)
assert all(pin(ROOT/n)==v for n,v in sources.items())
artifact={k:matrix['artifact'][k] for k in ['bytes','sha256']}
assert matrix['artifact']==commands['artifact'] and pin(ROOT/matrix['artifact']['path'])==artifact
canonical=matrix['canonical_executable_unchanged']
assert canonical==commands['canonical_executable_unchanged']==prior['canonical_executable_unchanged']==pin(ROOT/'build/cli/omicsmatic-0.3.7.jar')
assert all(pin(ROOT/n)==v for n,v in prior['source_pins'].items())
assert pin(ROOT/'build/omics-magma/magma.exe')['sha256']==family['runtime_sha256']
assert not DEST.exists(),'Preserve the existing milestone; choose a new evidence directory'
DEST.mkdir()
(DEST/'.gitattributes').write_text('* -text\n',encoding='ascii',newline='\n')
sources[(DEST/'.gitattributes').relative_to(ROOT).as_posix()]=pin(DEST/'.gitattributes')
items={};graphs={}
def add(name,p):
    assert name not in items and p.is_file(),name
    items[name]=(p,pin(p))
def tree(prefix,p,record=None):
    graph=census(p);graphs[p]=graph
    if record is not None:assert {n:v for n,v in graph.items() if n!='COMPLETED.json'}==record['files']
    for n in graph:add(prefix+'/'+n,p/n)
tree('evidence/matrix-1',RUN/'matrix-1',matrix)
tree('evidence/example-commands-1',RUN/'example-commands-1',commands)
tree('evidence/family-tests-3-results',RUN/'family-tests-3-results')
tree('evidence/example-classes-1',RUN/'example-classes-1')
for folder in ['tests-1-snapshot','tests-2-snapshot','original-tests-1-snapshot','family-tests-2-snapshot']:tree('history/'+folder,RUN/folder)
for name in ['compile-1.log','tests-1.log','tests-2.log','cli-tests-3.log','original-tests-1.log','family-tests-1.log','family-tests-2.log','family-tests-3.log','family-tests-3-summary.json','build-1.log','matrix-1.log','example-compile-1.log','example-commands-1.log']:add('logs/'+name,RUN/name)
for n in sources:add('source/'+n,ROOT/n)
add('source/record-checkpoint.py',Path(__file__))
add('prior/ld-core-VALIDATION.json',prior_path)
add('prior/ld-core-controls.zip',prior_path.parent/'controls.zip')
libraries={p.relative_to(ROOT).as_posix():pin(p) for p in sorted((ROOT/'build/literature-review/shapeit-runtime/owned-common-native-matrix-4/lib').glob('*.jar'))}
assert len(libraries)==9
with zipfile.ZipFile(DEST/'controls.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for n,(p,v) in sorted(items.items()):
        assert pin(p)==v,n
        entry=zipfile.ZipInfo(n,(1980,1,1,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED;entry.external_attr=0o100644<<16;archive.writestr(entry,p.read_bytes())
assert all(census(p)==g for p,g in graphs.items()) and all(pin(ROOT/n)==v for n,v in sources.items())
proof=dict(schema_version=1,status='passed-local-native-FUMA-reference-preparation-capture-replay-and-locus-handoff',recorded_utc=datetime.now(timezone.utc).isoformat(),scope='Explicit selected autosomal diploid hardcalls -> audited marginal exclusions and bounded-window LD -> portable complete capture/replay -> validated locus admission and optional typed workflow reference_prepare stage. No hosted/historical FUMA or whole-tool claim.',artifact=matrix['artifact'],tests_per_JVM=104,new_reference_tests_per_JVM=40,prior_core_and_locus_tests_per_JVM=64,heap_mib=128,platforms=[r['name'] for r in matrix['runs']],family_tests=family,example_commands=commands['calls'],payload_byte_comparisons=24,original_evidence=dict(reused_original_PLINK_fixture='src/test/resources/org/jlinalg/genetics/hardcall-ld/original-controls.zip',underlying_core_binary_values_per_JVM=7568,underlying_core_frequency_rows_per_JVM=228,preparation_cases_per_JVM=9,preparation_positive_cases=8,source_undefined_case='explicit-keep: actual original NaN is retained; complete preparation must fail rather than produce a false sparse omission',new_original_download_or_install=False),source_pins=sources,test_dependency_pins=libraries,prior_checkpoint=dict(path=prior_path.relative_to(ROOT).as_posix(),**pin(prior_path)),unchanged_prior_packaged_classes=matrix['unchanged_prior_packaged_classes'],changed_prior_packaged_classes=matrix['changed_prior_packaged_classes'],new_packaged_classes=matrix['new_packaged_classes'],owned_classes=matrix['owned_classes'],canonical_executable_unchanged=canonical,archive=dict(path='controls.zip',**pin(DEST/'controls.zip'),entries=len(items)),archive_files={n:v for n,(_,v) in sorted(items.items())},retained_failed_attempts=['tests-1: early admission failures lacked an empty partial/ directory; added that diagnostic path. One test incorrectly expected original five-sample packed size instead of selected four-sample capture size. No numerical formula changed.','tests-2: a test substring matched 1100 as if it were 100; changed to an exact row prefix.','original-tests-1: test assumed every original control pair was defined. Actual explicit-keep binary NaN is now tested as a mandatory complete-request failure; no filtering was widened.','family-tests-1: ambiguous boxed Double::isNaN test method reference failed compilation; replaced with an explicit lambda.','family-tests-2: two test-harness assertions accepted only ANALYSIS FAILED, while the existing workflow correctly emits WORKFLOW FAILED. Corrected harness. Two optional MAGMA tests initially skipped; configured existing checksum-verified runtime and all619 passed in family-tests-3.','Two attempted copies of earlier Gradle XML reports found that later Gradle runs had already replaced them. Complete terminal logs and corresponding test source snapshots are retained; no claim is made that those missing XML files were archived.'],claims=dict(native_reference_preparation_available_in_candidate=True,all_requested_selected_genotypes_captured=True,complete_resource_replay_available=True,locus_handoff_replays_before_admission=True,typed_reference_prepare_workflow_available=True,autosomes_only=True,full_FUMA_reproduced=False,paper_historical_reference_reconstructed=False,catalog_promoted=False,whole_goal_complete=False,released_or_deployed=False,pushed=False),required_action='Use FUMA_REFERENCE_WORKFLOW.md and the identified candidate. Declare sample/variant selection, founder policy, assembly/population/release, MAF floor and windows. Inspect all variant exclusions and assessed pairs. Outside-window LD is uncomputed, not observed zero/weak LD; undefined eligible LD fails the entire request. Keep the complete capture bundle for portable replay/handoff. Correct named failure/capacity causes and rerun to a new directory; preserve failed evidence. FUMA remains catalog-missing while additional roles are reviewed.')
write(DEST/'VALIDATION.json',proof)
with zipfile.ZipFile(DEST/'controls.zip') as archive:
    assert len(archive.infolist())==len(items)==len({e.filename for e in archive.infolist()})
    for n,v in proof['archive_files'].items():
        raw=archive.read(n);assert len(raw)==v['bytes'] and hashlib.sha256(raw).hexdigest()==v['sha256'],n
write(RUN/'CHECKPOINT.json',dict(status=proof['status'],proof=DEST.relative_to(ROOT).as_posix()+'/VALIDATION.json',artifact=proof['artifact'],tests_per_JVM=104,family_tests=619,goal_active=True,catalog_new_integrations=62,catalog_native=14,catalog_upstream_adapters=48,catalog_preexisting_adapters=3,catalog_missing=258,Cell_Ranger='excluded-by-user',catalog_promoted=False,next_work='Review the remaining14-paper FUMA roles against the now-available reference workflow and other scoped modules; implement actual missing methods/resources or promote only the supported roles with prominent explicit gaps. Preserve current proofs and unrelated fastp/mashr work. No new push/release authorization inferred.'))
print(json.dumps(dict(status=proof['status'],tests_per_JVM=104,family_tests=619,artifact=matrix['artifact'],unchanged_prior_classes=proof['unchanged_prior_packaged_classes'],changed_classes=len(proof['changed_prior_packaged_classes']),new_classes=len(proof['new_packaged_classes']),archive=proof['archive'],catalog_promoted=False)))
