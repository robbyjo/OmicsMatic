from pathlib import Path
import hashlib,json,os,shutil,subprocess

INTAKE=Path(__file__).resolve().parent;BASE=INTAKE.parent
OUT=BASE/'idep244-windows-runtime-setup-2';OUT.mkdir(exist_ok=False)
def pin(path):
    with path.open('rb') as handle:return dict(bytes=path.stat().st_size,sha256=hashlib.file_digest(handle,'sha256').hexdigest())
def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
source=INTAKE/'current-original-source';profile=json.loads((INTAKE/'CURRENT-SOURCE.json').read_bytes())
for name,identity in profile['members'].items():assert pin(source/name)=={key:identity[key] for key in ['bytes','sha256']},name
bases=[BASE/'idep244-windows-runtime-setup-1/R-lib']+[Path(line) for line in (INTAKE/'windows-runtime-readiness-1/LIBRARIES.txt').read_text().splitlines() if line]
def inventory():
    excluded={'doc','html','help','include','tests','testthat','demo','examples','man','figures'}
    result={};seen=0
    for folder in bases:
        items={}
        for directory,dirs,files in os.walk(folder,followlinks=False):
            dirs[:]=[name for name in dirs if name.lower() not in excluded]
            for name in files:
                path=Path(directory)/name
                if path.is_file():
                    items[path.relative_to(folder).as_posix()]=pin(path);seen+=1
                    if seen%250==0:write(OUT/'INVENTORY-PROGRESS.json',dict(files=seen,library=str(folder),latest=str(path)))
        result[str(folder)]=items
    return result
write(OUT/'LIVE.json',dict(phase='inventory existing runtime code metadata and data',python_pid=os.getpid()))
before=inventory();write(OUT/'BASES-BEFORE.json',before)
(OUT/'BASE-LIBRARIES.txt').write_text('\n'.join(str(folder) for folder in bases)+'\n')
shutil.copyfile(INTAKE/'InstallCurrent2.R',OUT/'InstallCurrent2.R');shutil.copyfile(__file__,OUT/'install_runtime2.py')
compiler=BASE/'rtools-intake-1/toolchain-3/x86_64-w64-mingw32.static.posix'
host=BASE/'build-host-4/host/usr/bin'
write(OUT/'SOURCE.json',dict(original_commit=profile['commit'],source_archive=profile['archive'],DESCRIPTION_version=profile['DESCRIPTION_version_literal'],
    source_profile=pin(INTAKE/'CURRENT-SOURCE.json'),installer=pin(OUT/'InstallCurrent2.R'),
    compiler=str(compiler),compiler_executable=pin(compiler/'bin/g++.exe'),make=str(host/'make.exe'),make_executable=pin(host/'make.exe'),
    toolchain_origin=pin(BASE/'rtools-intake-1/SOURCE.json'),build_host_profile=pin(BASE/'build-host-4/COMPLETED.json'),
    intended_use='Authorized academic noncommercial research; user selected newest iDEP.',
    selected_iDEP_version_is_not_paper_iDEP96=True,original_algorithms_or_metadata_patched=False))
(OUT/'tmp').mkdir();(OUT/'empty-user-library').mkdir()
command=['C:/Program Files/R/R-4.6.1/bin/Rscript.exe','--vanilla',str(OUT/'InstallCurrent2.R'),str(source),str(OUT),str(OUT/'BASE-LIBRARIES.txt'),'allow']
env=dict(os.environ)
for name in list(env):
    if name.startswith('R_') or name.startswith('LC_') or name in ['LANG','LANGUAGE']:env.pop(name,None)
env.update(HOME=str(OUT),R_USER=str(OUT),R_LIBS_USER=str(OUT/'empty-user-library'),R_LIBS_SITE=str(OUT/'empty-user-library'),
    TMP=str(OUT/'tmp'),TEMP=str(OUT/'tmp'),TMPDIR=str(OUT/'tmp'),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',
    R_CUSTOM_TOOLS_SOFT=compiler.as_posix(),R_CUSTOM_TOOLS_PATH=(compiler/'bin').as_posix()+';'+host.as_posix(),
    PATH=str(compiler/'bin')+';'+str(host)+';'+env.get('PATH',''))
with (OUT/'installer.stdout').open('xb') as so,(OUT/'installer.stderr').open('xb') as se:
    child=subprocess.Popen(command,env=env,cwd=OUT,stdin=subprocess.DEVNULL,stdout=so,stderr=se)
    write(OUT/'LIVE.json',dict(phase='actual permitted private dependency setup',pid=child.pid,python_pid=os.getpid(),command=command))
    try:code=child.wait(timeout=7200)
    except subprocess.TimeoutExpired:child.kill();child.wait();raise RuntimeError('Owned installer exceeded wall bound; preserve partials. No replacement started.')
write(OUT/'PROCESS.json',dict(pid=child.pid,command=command,exit_code=code))
after=inventory();write(OUT/'BASES-AFTER.json',after);preserved=before==after
write(OUT/'BASE-PRESERVATION.json',dict(all_selected_existing_runtime_files_unchanged=preserved,
    scope='Runtime code metadata and data; documentation headers and test/example trees excluded. All installations target only the new private library.',
    bases=len(bases),files=sum(map(len,before.values()))))
write(OUT/'DOWNLOADS.json',{path.relative_to(OUT).as_posix():pin(path) for path in (OUT/'downloads').rglob('*') if path.is_file()})
result=json.loads((OUT/'R-RESULT.json').read_bytes()) if (OUT/'R-RESULT.json').exists() else dict(status='SKIP3_CURRENT_IDEP_RUNTIME_UNAVAILABLE',detail='Installer ended without a complete R report; read complete consoles.')
result.update(process_exit_code=code,existing_selected_runtime_files_unchanged=preserved,source_commit=profile['commit'],analysis_admitted=False)
if not preserved:result.update(status='FAIL2_EXISTING_RUNTIME_STATE_CHANGED_DURING_SETUP',detail='An existing runtime byte inventory changed; preserve evidence and inspect before/after. No current iDEP runtime admitted.')
write(OUT/('COMPLETED.json' if code==0 and preserved else 'FAILURE.json'),result);print(json.dumps(result,indent=2))
raise SystemExit(0 if code==0 and preserved else 3)
