from pathlib import Path
import datetime,hashlib,json,urllib.error,urllib.request

OUT=Path(__file__).resolve().parent
API='https://api.github.com/repos/gexijin/idepGolem'
def fetch(url,name,allowed=(200,)):
    request=urllib.request.Request(url,headers={'User-Agent':'OmicsMatic-user-selected-current-iDEP-assessment','Accept':'application/vnd.github+json'})
    try:
        with urllib.request.urlopen(request,timeout=45) as response:raw=response.read();status=response.status;headers=dict(response.headers)
    except urllib.error.HTTPError as response:raw=response.read();status=response.code;headers=dict(response.headers)
    with (OUT/(name+'.response')).open('xb') as handle:handle.write(raw)
    (OUT/(name+'.json')).write_text(json.dumps(dict(url=url,status=status,headers=headers,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()),indent=2)+'\n')
    if status not in allowed:raise RuntimeError((name,status))
    return json.loads(raw)

repo=fetch(API,'repository')
branch=repo['default_branch'];head=fetch(API+'/commits/'+branch,'head')
tags=fetch(API+'/tags?per_page=100','tags')
release=fetch(API+'/releases/latest','latest-release',(200,404))
tree=fetch(API+'/git/trees/'+head['sha']+'?recursive=1','tree')
names=[row for row in tree['tree'] if any(word in row['path'].lower() for word in ['description','license','licence','readme','dockerfile','renv.lock','dependencies','namespace'])]
result=dict(status='CURRENT_IDEP_USER_SELECTED_SOURCE_DISCOVERY_NO_INSTALL_OR_ANALYSIS',checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    repository=repo['full_name'],default_branch=branch,observed_current_commit=head['sha'],commit_date=head['commit']['committer']['date'],
    latest_release=release.get('tag_name'),tags=[dict(name=row['name'],commit=row['commit']['sha']) for row in tags],
    tree_truncated=tree.get('truncated'),selected_metadata_paths=names,
    target_selection='User requested newest iDEP instead of legacy iDEP.96; preserve paper literal and unknown author commit.',
    implementation_credit_added=0,analysis_started=False)
(OUT/'DISCOVERY.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
