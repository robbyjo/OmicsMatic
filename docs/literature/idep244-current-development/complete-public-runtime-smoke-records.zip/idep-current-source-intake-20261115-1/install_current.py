from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess

INTAKE=Path(__file__).resolve().parent
BASE=INTAKE.parent
OUT=BASE/'idep244-windows-runtime-setup-1';OUT.mkdir(exist_ok=False)
def pin(path):
    with path.open('rb') as handle:return dict(bytes=path.stat().st_size,sha256=hashlib.file_digest(handle,'sha256').hexdigest())
def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
source=INTAKE/'current-original-source';profile=json.loads((INTAKE/'CURRENT-SOURCE.json').read_bytes())
for name,identity in profile['members'].items():assert pin(source/name)=={key:identity[key] for key in ['bytes','sha256']},name
bases=[Path(line) for line in (INTAKE/'windows-runtime-readiness-1/LIBRARIES.txt').read_text().splitlines() if line]
def inventory():
    return {str(folder):{path.relative_to(folder).as_posix():pin(path) for path in folder.rglob('*') if path.is_file()} for folder in bases}
write(OUT/'LIVE.json',dict(phase='inventory existing read-only libraries',python_pid=os.getpid(),checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
before=inventory();write(OUT/'BASES-BEFORE.json',before)
(OUT/'BASE-LIBRARIES.txt').write_text('\n'.join(str(folder) for folder in bases)+'\n')
shutil.copyfile(INTAKE/'InstallCurrent.R',OUT/'InstallCurrent.R');shutil.copyfile(__file__,OUT/'install_current.py')
write(OUT/'SOURCE.json',dict(original_commit=profile['commit'],source_archive=profile['archive'],DESCRIPTION_version=profile['DESCRIPTION_version_literal'],
    source_profile=pin(INTAKE/'CURRENT-SOURCE.json'),installer=pin(OUT/'InstallCurrent.R'),
    intended_use='Previously authorized academic noncommercial research; user explicitly selected newest iDEP.',
    license_statement_source='README.md of selected original source; CC BY-NC3.0 and local-installation conditions retained. DESCRIPTION still contains its original placeholder License field.',
    iDEP96_author_snapshot_inferred=False,original_algorithms_or_package_metadata_patched=False))
(OUT/'tmp').mkdir();(OUT/'empty-user-library').mkdir()
command=['C:/Program Files/R/R-4.6.1/bin/Rscript.exe','--vanilla',str(OUT/'InstallCurrent.R'),str(source),str(OUT),str(OUT/'BASE-LIBRARIES.txt'),'allow']
env=dict(os.environ)
for name in list(env):
    if name.startswith('R_') or name.startswith('LC_') or name in ['LANG','LANGUAGE']:env.pop(name,None)
env.update(HOME=str(OUT),R_USER=str(OUT),R_LIBS_USER=str(OUT/'empty-user-library'),R_LIBS_SITE=str(OUT/'empty-user-library'),
    TMP=str(OUT/'tmp'),TEMP=str(OUT/'tmp'),TMPDIR=str(OUT/'tmp'),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
with (OUT/'installer.stdout').open('xb') as so,(OUT/'installer.stderr').open('xb') as se:
    child=subprocess.Popen(command,env=env,cwd=OUT,stdin=subprocess.DEVNULL,stdout=so,stderr=se)
    write(OUT/'LIVE.json',dict(phase='actual permitted private dependency setup',pid=child.pid,python_pid=os.getpid(),command=command))
    try:code=child.wait(timeout=7200)
    except subprocess.TimeoutExpired:
        child.kill();child.wait();raise RuntimeError('Owned installer exceeded declared wall bound; retain partials. No replacement started.')
write(OUT/'PROCESS.json',dict(pid=child.pid,command=command,exit_code=code))
after=inventory();write(OUT/'BASES-AFTER.json',after)
preserved=before==after
write(OUT/'BASE-PRESERVATION.json',dict(all_existing_library_file_bytes_unchanged=preserved,bases=len(bases),files=sum(map(len,before.values()))))
downloads={path.relative_to(OUT).as_posix():pin(path) for path in (OUT/'downloads').rglob('*') if path.is_file()}
write(OUT/'DOWNLOADS.json',downloads)
result=json.loads((OUT/'R-RESULT.json').read_bytes()) if (OUT/'R-RESULT.json').exists() else dict(status='SKIP3_CURRENT_IDEP_RUNTIME_UNAVAILABLE',detail='Installer ended without a complete R report; read complete consoles.')
result.update(process_exit_code=code,existing_libraries_unchanged=preserved,source_commit=profile['commit'],analysis_admitted=False)
if not preserved:result.update(status='FAIL2_EXISTING_LIBRARY_STATE_CHANGED_DURING_SETUP',detail='Existing library byte inventory changed; preserve all evidence and inspect before/after. No current iDEP runtime admitted.')
write(OUT/('COMPLETED.json' if code==0 and preserved else 'FAILURE.json'),result)
print(json.dumps(result,indent=2))
raise SystemExit(0 if code==0 and preserved else 3)
