from pathlib import Path
import json

OUT=Path(__file__).resolve().parent
old=OUT.parent/'idep244-windows-runtime-setup-1'
assert not (old/'R-lib').exists() and not (old/'PROCESS.json').exists()
(old/'STOPPED-BEFORE-INSTALL.json').write_text(json.dumps(dict(status='OWN_READ_ONLY_BASELINE_STOPPED_BEFORE_R_OR_PACKAGE_INSTALLATION',
    stopped_python_pid=77880,no_R_installer_child_was_present=True,analysis_started=False,
    reason='Full library inventory included extensive documentation/header trees. New attempt inventories runtime code, metadata and data, while setup writes only to its new private library.',
    previous_scripts_and_evidence_preserved=True),indent=2)+'\n')
source=(OUT/'install_current.py').read_text()
source=source.replace("OUT=BASE/'idep244-windows-runtime-setup-1'","OUT=BASE/'idep244-windows-runtime-setup-2'")
before="""def inventory():
    return {str(folder):{path.relative_to(folder).as_posix():pin(path) for path in folder.rglob('*') if path.is_file()} for folder in bases}
"""
after="""def inventory():
    excluded={'doc','html','help','include','tests','testthat','demo','examples','man','figures'}
    result={};seen=0
    for folder in bases:
        items={}
        for directory,dirs,files in os.walk(folder,followlinks=False):
            dirs[:]=[name for name in dirs if name.lower() not in excluded]
            for name in files:
                path=Path(directory)/name
                if path.is_file():
                    items[path.relative_to(folder).as_posix()]=pin(path);seen+=1
                    if seen%250==0:write(OUT/'INVENTORY-PROGRESS.json',dict(files=seen,library=str(folder),latest=str(path)))
        result[str(folder)]=items
    return result
"""
assert source.count(before)==1
source=source.replace(before,after)
source=source.replace('all_existing_library_file_bytes_unchanged','all_selected_existing_runtime_code_metadata_and_data_bytes_unchanged')
source=source.replace('existing_libraries_unchanged','existing_selected_runtime_files_unchanged')
source=source.replace("bases=len(bases),files=sum(map(len,before.values()))","bases=len(bases),files=sum(map(len,before.values())),scope='Runtime code, metadata and data; exclude documentation, headers and test/example trees. Installer writes only to a new private library.'")
source=source.replace("print(json.dumps(result,indent=2))","print(json.dumps(result,indent=2))")
with (OUT/'install_current_2.py').open('x') as handle:handle.write(source)
print('Prepared a new isolated setup attempt; the original attempt remains intact.')
