from pathlib import Path
import json,os,shutil,subprocess

INTAKE=Path(__file__).resolve().parent;BASE=INTAKE.parent
setup=BASE/'idep244-windows-runtime-setup-2'
status=json.loads((setup/'COMPLETED.json').read_bytes());assert status['process_exit_code']==0 and status['existing_selected_runtime_files_unchanged']
out=BASE/'idep244-original-smoke-2';out.mkdir(exist_ok=False)
libs=[str(setup/'R-lib')]+(setup/'BASE-LIBRARIES.txt').read_text().splitlines()
(out/'LIBRARIES.txt').write_text('\n'.join(libs)+'\n');shutil.copyfile(INTAKE/'OriginalSmoke2.R',out/'OriginalSmoke2.R')
command=['C:/Program Files/R/R-4.6.1/bin/Rscript.exe','--vanilla',str(out/'OriginalSmoke2.R'),str(INTAKE/'current-original-source'),str(out),str(out/'LIBRARIES.txt')]
env=dict(os.environ)
for name in list(env):
 if name.startswith('R_') or name.startswith('LC_') or name in ['LANG','LANGUAGE']:env.pop(name,None)
(out/'tmp').mkdir();(out/'empty-library').mkdir()
env.update(HOME=str(out),R_USER=str(out),R_LIBS_USER=str(out/'empty-library'),R_LIBS_SITE=str(out/'empty-library'),
 TMP=str(out/'tmp'),TEMP=str(out/'tmp'),TMPDIR=str(out/'tmp'),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
with (out/'process.stdout').open('xb') as so,(out/'process.stderr').open('xb') as se:
 child=subprocess.Popen(command,cwd=out,env=env,stdin=subprocess.DEVNULL,stdout=so,stderr=se)
 (out/'LIVE.json').write_text(json.dumps(dict(pid=child.pid,command=command),indent=2)+'\n')
 try:code=child.wait(timeout=600)
 except subprocess.TimeoutExpired:child.kill();child.wait();raise RuntimeError('Owned original smoke exceeded deadline; retain partials, no replacement started')
(out/'PROCESS.json').write_text(json.dumps(dict(pid=child.pid,command=command,exit_code=code),indent=2)+'\n')
result=json.loads((out/'R-RESULT.json').read_bytes()) if (out/'R-RESULT.json').exists() else dict(status='FAIL2_SMOKE_PREPARATION_UNADMITTED',detail='No full original return; read original stderr.')
(out/('COMPLETED.json' if code==0 else 'FAILURE.json')).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2));raise SystemExit(code)
