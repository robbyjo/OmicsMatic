from pathlib import Path
import json,os,shutil,subprocess

INTAKE=Path(__file__).resolve().parent;BASE=INTAKE.parent
out=BASE/'idep244-runtime-supplement-1';out.mkdir(exist_ok=False)
setup=BASE/'idep244-windows-runtime-setup-2'
libs=[str(setup/'R-lib')]+(setup/'BASE-LIBRARIES.txt').read_text().splitlines()
(out/'LIBRARIES.txt').write_text('\n'.join(libs)+'\n');shutil.copyfile(INTAKE/'Supplement.R',out/'Supplement.R')
command=['C:/Program Files/R/R-4.6.1/bin/Rscript.exe','--vanilla',str(out/'Supplement.R'),str(out),str(out/'LIBRARIES.txt')]
env=dict(os.environ)
for name in list(env):
 if name.startswith('R_') or name.startswith('LC_') or name in ['LANG','LANGUAGE']:env.pop(name,None)
(out/'tmp').mkdir();env.update(TMP=str(out/'tmp'),TEMP=str(out/'tmp'),TMPDIR=str(out/'tmp'),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
with (out/'process.stdout').open('xb') as so,(out/'process.stderr').open('xb') as se:
 child=subprocess.Popen(command,cwd=out,env=env,stdin=subprocess.DEVNULL,stdout=so,stderr=se)
 (out/'LIVE.json').write_text(json.dumps(dict(pid=child.pid,command=command),indent=2)+'\n')
 try:code=child.wait(timeout=300)
 except subprocess.TimeoutExpired:child.kill();child.wait();raise RuntimeError('Owned supplement setup timed out; no replacement started')
(out/'PROCESS.json').write_text(json.dumps(dict(pid=child.pid,command=command,exit_code=code),indent=2)+'\n')
if code:raise RuntimeError('Supplement unavailable; iDEP analysis stays skipped. Read complete setup consoles.')
source=(INTAKE/'OriginalSmoke3.R').read_text();(INTAKE/'OriginalSmoke4.R').write_text(source)
runner=(INTAKE/'run_original_smoke3.py').read_text().replace('idep244-original-smoke-3','idep244-original-smoke-4').replace('OriginalSmoke3.R','OriginalSmoke4.R')
runner=runner.replace("libs=[str(setup/'R-lib')]+", "libs=[str(BASE/'idep244-runtime-supplement-1/R-lib'),str(setup/'R-lib')]+")
(INTAKE/'run_original_smoke4.py').write_text(runner)
print('BiocManager installed only in the new private overlay; original returned-error evidence remains intact.')
