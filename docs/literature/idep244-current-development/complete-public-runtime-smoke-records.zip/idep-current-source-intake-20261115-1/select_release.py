from pathlib import Path
import hashlib,io,json,tarfile,urllib.request

OUT=Path(__file__).resolve().parent
release=json.loads((OUT/'latest-release.response').read_bytes())
tags=json.loads((OUT/'tags.response').read_bytes())
assert not release['draft'] and not release['prerelease']
tag=release['tag_name'];sha=next(row['commit']['sha'] for row in tags if row['name']==tag)
url='https://codeload.github.com/gexijin/idepGolem/tar.gz/'+sha
request=urllib.request.Request(url,headers={'User-Agent':'OmicsMatic-user-selected-current-iDEP-intake'})
with urllib.request.urlopen(request,timeout=90) as response:
    raw=response.read(209715201);status=response.status
if len(raw)>209715200:raise RuntimeError('Original source archive exceeds intake capacity')
with (OUT/'selected-original-source.tar.gz').open('xb') as handle:handle.write(raw)
dest=OUT/'selected-original-source';dest.mkdir(exist_ok=False)
members={}
with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as archive:
    top=None
    for member in archive:
        path=Path(member.name)
        if path.is_absolute() or '..' in path.parts:raise ValueError('Unsafe source archive member')
        if top is None:top=path.parts[0]
        if path.parts[0]!=top:raise ValueError('Multiple original archive roots')
        relative=Path(*path.parts[1:])
        if str(relative)=='.':continue
        target=dest/relative
        if member.isdir():target.mkdir(parents=True,exist_ok=True);continue
        if not member.isfile():raise ValueError('Nonregular source member: '+member.name)
        content=archive.extractfile(member).read()
        if len(content)!=member.size:raise ValueError('Truncated original archive member')
        target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as handle:handle.write(content)
        members[relative.as_posix()]=dict(bytes=len(content),sha256=hashlib.sha256(content).hexdigest(),git_blob_sha=hashlib.sha1(b'blob '+str(len(content)).encode()+b'\0'+content).hexdigest())
description=(dest/'DESCRIPTION').read_text()
version=next(line.split(':',1)[1].strip() for line in description.splitlines() if line.startswith('Version:'))
result=dict(status='LATEST_PUBLISHED_NONPRERELEASE_IDEP_SELECTED_ORIGINAL_ARCHIVE_CAPTURED',
    tag=tag,commit=sha,DESCRIPTION_version_literal=version,release_published_at=release['published_at'],
    url=url,status_code=status,archive=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()),members=members,
    choice='Newest published non-prerelease according to the maintainers latest-release endpoint, not numeric sorting or an untagged default branch.',
    user_selected_current_iDEP=True,author_iDEP96_snapshot_inferred=False,original_algorithms_modified=False,analysis_started=False,implementation_credit_added=0)
(OUT/'SELECTED-SOURCE.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='members'},indent=2))
