from pathlib import Path
import hashlib,io,json,tarfile,urllib.request

OUT=Path(__file__).resolve().parent/'ggalt-current-intake-1';OUT.mkdir(exist_ok=False)
def fetch(url,name):
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'OmicsMatic-current-iDEP-dependency-intake'}),timeout=90) as response:raw=response.read();status=response.status
    (OUT/name).write_bytes(raw)
    return raw,dict(url=url,status=status,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
raw,meta=fetch('https://api.github.com/repos/hrbrmstr/ggalt/commits/master','head.response')
sha=json.loads(raw)['sha'];raw,archive_info=fetch('https://codeload.github.com/hrbrmstr/ggalt/tar.gz/'+sha,'original-source.tar.gz')
folder=OUT/'original-source';folder.mkdir();members={};top=None
with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as archive:
    for member in archive:
        path=Path(member.name)
        if path.is_absolute() or '..' in path.parts:raise ValueError('Unsafe dependency member')
        if top is None:top=path.parts[0]
        if path.parts[0]!=top:raise ValueError('Unexpected dependency roots')
        relative=Path(*path.parts[1:])
        if str(relative)=='.':continue
        target=folder/relative
        if member.isdir():target.mkdir(parents=True,exist_ok=True);continue
        if not member.isfile():raise ValueError('Nonregular dependency member')
        content=archive.extractfile(member).read();target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as handle:handle.write(content)
        members[relative.as_posix()]=dict(bytes=len(content),sha256=hashlib.sha256(content).hexdigest())
version=next(line.split(':',1)[1].strip() for line in (folder/'DESCRIPTION').read_text().splitlines() if line.startswith('Version:'))
result=dict(status='CURRENT_MAINTAINER_GGALT_DEPENDENCY_ORIGINAL_SOURCE_INTAKE',commit=sha,version=version,metadata=meta,archive=archive_info,members=members,
    reason='Current maintainer source supports ggplot2 4 and removes the archived PROJ4 dependency. This is an explicit current iDEP runtime dependency selection, not an author historical version.',original_algorithms_patched=False)
(OUT/'SOURCE.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='members'},indent=2))
