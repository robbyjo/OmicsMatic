p <- commandArgs(TRUE)
stopifnot(length(p)==4L,p[[4]]=='allow')
source <- p[[1]];report <- p[[2]];bases <- readLines(p[[3]],warn=FALSE)
lib <- file.path(report,'R-lib');stopifnot(!dir.exists(lib),dir.create(lib))
.libPaths(unique(c(lib,bases[dir.exists(bases)],.Library)),include.site=FALSE)
options(timeout=180,Ncpus=2)
repos <- c(BioCsoft='https://bioconductor.org/packages/3.23/bioc',
 BioCann='https://bioconductor.org/packages/3.23/data/annotation',
 BioCexp='https://bioconductor.org/packages/3.23/data/experiment',CRAN='https://cloud.r-project.org')
options(repos=repos)
downloads <- file.path(report,'downloads');dir.create(downloads)
warnings_seen <- character();errors_seen <- character()
description <- read.dcf(file.path(source,'DESCRIPTION'))
imports <- unique(trimws(sub('\\s*\\(.*','',strsplit(description[[1,'Imports']],',')[[1]])))
missing <- function()imports[!vapply(imports,function(package)length(find.package(package,quiet=TRUE))>0L,logical(1))]
writeLines(capture.output(dput(repos)),file.path(report,'REPOSITORIES.R'))
writeLines(missing(),file.path(report,'MISSING-BEFORE.txt'))
phase <- 'repository metadata'
status <- 'SKIP3_CURRENT_IDEP_RUNTIME_UNAVAILABLE'
detail <- ''
tryCatch(withCallingHandlers({
 cat('BEGIN_BINARY_DEPENDENCY_SETUP\n');flush.console()
 binary <- available.packages(repos=repos,type='win.binary')
 saveRDS(binary,file.path(report,'AVAILABLE-BINARY.rds'))
 wanted <- intersect(missing(),rownames(binary))
 phase <- 'binary dependencies'
 if(length(wanted))install.packages(wanted,lib=lib,repos=repos,type='binary',
   dependencies=c('Depends','Imports','LinkingTo'),destdir=downloads,available=binary)
 cat('BINARY_PHASE_MISSING',paste(missing(),collapse=','),'\n');flush.console()
 phase <- 'source-only interpreted dependencies'
 if(length(missing())) {
  src <- available.packages(repos=repos,type='source')
  saveRDS(src,file.path(report,'AVAILABLE-SOURCE.rds'))
  wanted <- intersect(missing(),rownames(src))
  if('NeedsCompilation'%in%colnames(src))wanted <- wanted[is.na(src[wanted,'NeedsCompilation'])|src[wanted,'NeedsCompilation']!='yes']
  if(length(wanted))install.packages(wanted,lib=lib,repos=repos,type='source',
    dependencies=c('Depends','Imports','LinkingTo'),destdir=downloads,available=src)
 }
 if(length(missing()))stop('Required imports still unavailable: ',paste(missing(),collapse=', '))
 phase <- 'unmodified current iDEP source installation'
 cat('BEGIN_ORIGINAL_IDEP_PACKAGE_INSTALL\n');flush.console()
 install.packages(source,lib=lib,repos=NULL,type='source')
 phase <- 'original namespace loading'
 stopifnot(requireNamespace('idepGolem',quietly=TRUE),as.character(packageVersion('idepGolem'))=='2.4.4')
 stopifnot(is.function(getExportedValue('idepGolem','input_data')),is.function(getExportedValue('idepGolem','pre_process')),
   is.function(getExportedValue('idepGolem','convert_data')),is.function(getExportedValue('idepGolem','deg_deseq2')))
 status <- 'CURRENT_IDEP244_RUNTIME_LOADED_NO_ANALYSIS_ADMITTED'
},warning=function(w){warnings_seen<<-c(warnings_seen,conditionMessage(w));cat('ORIGINAL_SETUP_WARNING:',conditionMessage(w),'\n');flush.console()}),
error=function(e){detail<<-conditionMessage(e);cat('SKIP3_CURRENT_IDEP_RUNTIME_UNAVAILABLE:',detail,'\n')})
writeLines(missing(),file.path(report,'MISSING-AFTER.txt'))
installed <- installed.packages(lib.loc=.libPaths(),noCache=TRUE)
write.table(installed[,intersect(c('Package','Version','LibPath','Built'),colnames(installed)),drop=FALSE],file.path(report,'INSTALLED-PACKAGES.tsv'),sep='\t',quote=TRUE,row.names=FALSE)
writeLines(capture.output(sessionInfo()),file.path(report,'SESSION.txt'))
jsonlite::write_json(list(status=status,phase=phase,detail=detail,warnings=warnings_seen,
 missing=missing(),new_library=lib,R_version=R.version.string,source_version='2.4.4',analysis_admitted=FALSE,
 required_action='Supply the named permitted exact runtime dependencies in a NEW private library. If installation/access is forbidden, skip iDEP analysis. Preserve complete installer streams and partials; do not consume setup as an analysis.'),
 file.path(report,'R-RESULT.json'),auto_unbox=TRUE,pretty=TRUE,null='null')
quit(status=if(status=='CURRENT_IDEP244_RUNTIME_LOADED_NO_ANALYSIS_ADMITTED')0L else 3L)
