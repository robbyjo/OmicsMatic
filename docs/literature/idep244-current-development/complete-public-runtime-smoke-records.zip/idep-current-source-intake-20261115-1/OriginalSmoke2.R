p <- commandArgs(TRUE)
stopifnot(length(p)==3L)
source <- p[[1]];out <- p[[2]];libs <- readLines(p[[3]],warn=FALSE)
.libPaths(unique(c(libs,.Library)),include.site=FALSE)
stopifnot(as.character(packageVersion('idepGolem'))=='2.4.4')
ns <- asNamespace('idepGolem')
canon <- function(x)paste(deparse(x,width.cutoff=500L,control='keepNA'),collapse='\n')
checks <- list()
for(file in sort(list.files(file.path(source,'R'),pattern='[.]R$',full.names=TRUE))) {
 connection <- base::file(file,open='rt',encoding='UTF-8-BOM')
 parsed <- parse(connection,keep.source=FALSE,encoding='UTF-8');close(connection)
 for(expression in parsed) {
  if(!is.call(expression)||length(expression)!=3L||!is.symbol(expression[[1]])||!as.character(expression[[1]])%in%c('<-','='))next
  if(!is.symbol(expression[[2]])||!is.call(expression[[3]])||!identical(expression[[3]][[1]],as.name('function')))next
  name <- as.character(expression[[2]])
  if(!exists(name,envir=ns,inherits=FALSE))stop('Missing original namespace function: ',name)
  fun <- get(name,envir=ns,inherits=FALSE)
  same <- identical(canon(formals(fun)),canon(expression[[3]][[2]]))&&identical(canon(body(fun)),canon(expression[[3]][[3]]))
  checks[[length(checks)+1L]] <- data.frame(file=basename(file),function_name=name,body_and_formals_match=same)
 }
}
checks <- do.call(rbind,checks)
write.table(checks,file.path(out,'LOADED-ORIGINAL-FUNCTIONS.tsv'),sep='\t',quote=TRUE,row.names=FALSE)
if(!all(checks$body_and_formals_match))stop('Loaded original function body/formals differ from pinned upstream source')
set.seed(24405L)
before <- .Random.seed
conditions <- list();returns <- list();phase <- 'input_data';failure <- NULL
tryCatch(withCallingHandlers({
 fixture <- list.files(file.path(source,'tests'),pattern='^counts_collinear[.]csv$',recursive=TRUE,full.names=TRUE)
 stopifnot(length(fixture)==1L)
 file.copy(fixture,file.path(out,'expression.csv'),overwrite=FALSE)
 returns$input_data <- idepGolem::input_data(expression_file=list(datapath=file.path(out,'expression.csv')),
   experiment_file=NULL,go_button=0,demo_data_file=NULL,demo_metadata_file=NULL,max_group_name_length=30)
 stopifnot(is.list(returns$input_data),!is.null(returns$input_data$data))
 phase <- 'convert_data'
 returns$convert_data <- idepGolem::convert_data(converted=NULL,data=returns$input_data$data,no_id_conversion=TRUE,multiple_map='max_sd')
 phase <- 'pre_process'
 returns$pre_process <- idepGolem::pre_process(data=returns$convert_data$data,missing_value='geneMedian',data_file_format=1,
   low_filter_fpkm=1,n_min_samples_fpkm=1,log_transform_fpkm=TRUE,log_start_fpkm=1,
   min_counts=0.5,n_min_samples_count=1,counts_transform=1,counts_log_start=4,no_fdr=FALSE)
 stopifnot(!is.null(returns$pre_process$raw_counts))
 phase <- 'limma_value_DESeq2'
 returns$limma_value <- idepGolem::limma_value(data_file_format=1,counts_deg_method=3,raw_counts=returns$pre_process$raw_counts,
   limma_p_val=0.05,limma_fc=2,select_model_comprions=NULL,sample_info=returns$input_data$sample_info,
   select_factors_model=NULL,select_interactions=NULL,select_block_factors_model=NULL,factor_reference_levels=NULL,
   processed_data=returns$pre_process$data,counts_log_start=4,p_vals=returns$pre_process$p_vals,
   threshold_wald_test=FALSE,independent_filtering=TRUE,descr=returns$pre_process$descr)
 stopifnot(is.list(returns$limma_value),!is.null(returns$limma_value$results),nrow(returns$limma_value$results)>0)
},warning=function(w){conditions[[length(conditions)+1L]]<<-list(kind='warning',class=class(w),message=conditionMessage(w),call=conditionCall(w))},
message=function(m){conditions[[length(conditions)+1L]]<<-list(kind='message',class=class(m),message=conditionMessage(m),call=conditionCall(m))}),
error=function(e){failure<<-e})
saveRDS(list(original_returns=returns,original_conditions=conditions,error=failure,RNG_before=before,RNG_after=.Random.seed),
 file.path(out,'complete-original-returns.rds'),compress=FALSE,version=3)
writeLines(capture.output(sessionInfo()),file.path(out,'SESSION.txt'))
jsonlite::write_json(list(status=if(is.null(failure))'PASS_ACTUAL_IDEP244_ORIGINAL_COUNT_PIPELINE_SMOKE_NOT_WORKFLOW_QUALIFICATION' else 'FAIL2_ORIGINAL_IDEP_SMOKE_UNADMITTED',
 phase=phase,error=if(is.null(failure))NULL else conditionMessage(failure),source_functions_checked=nrow(checks),
 input_dimensions=dim(returns$input_data$data),processed_dimensions=dim(returns$pre_process$raw_counts),
 result_dimensions=if(is.list(returns$limma_value))dim(returns$limma_value$results) else NULL,
 comparisons=if(is.list(returns$limma_value))returns$limma_value$comparisons else NULL,
 original_return_class=class(returns$limma_value),original_condition_count=length(conditions),
 original_ID_conversion_explicitly_disabled_for_this_synthetic_fixture=TRUE,
 full_mapping_or_database_workflow_qualified=FALSE,analysis_admitted=FALSE,catalog_credit_added=0,paper_reproduced=FALSE),
 file.path(out,'R-RESULT.json'),auto_unbox=TRUE,pretty=TRUE,null='null')
quit(status=if(is.null(failure))0L else 2L)
