p <- commandArgs(TRUE)
stopifnot(length(p)==2L)
out <- p[[1]];bases <- readLines(p[[2]],warn=FALSE)
lib <- file.path(out,'R-lib');stopifnot(!dir.exists(lib),dir.create(lib))
.libPaths(c(lib,bases),include.site=FALSE)
options(repos=c(CRAN='https://cloud.r-project.org'),timeout=120)
dir.create(file.path(out,'downloads'))
install.packages('BiocManager',lib=lib,type='binary',dependencies=FALSE,destdir=file.path(out,'downloads'))
stopifnot(requireNamespace('BiocManager',quietly=TRUE))
jsonlite::write_json(list(status='BIOCMANAGER_SUPPLEMENT_LOADED',version=as.character(packageVersion('BiocManager')),
    required_by='Actual current iDEP scientific path despite absence from its direct Imports declaration',analysis_admitted=FALSE),
    file.path(out,'COMPLETED.json'),auto_unbox=TRUE,pretty=TRUE)
