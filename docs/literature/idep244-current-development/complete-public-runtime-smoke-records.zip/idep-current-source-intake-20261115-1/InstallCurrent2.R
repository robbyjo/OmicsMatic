p <- commandArgs(TRUE)
stopifnot(length(p)==4L,p[[4]]=='allow')
source <- p[[1]];report <- p[[2]];bases <- readLines(p[[3]],warn=FALSE)
lib <- file.path(report,'R-lib');stopifnot(!dir.exists(lib),dir.create(lib))
.libPaths(unique(c(lib,bases[dir.exists(bases)],.Library)),include.site=FALSE)
options(timeout=180,Ncpus=1)
repos <- c(BioCsoft='https://bioconductor.org/packages/3.23/bioc',BioCann='https://bioconductor.org/packages/3.23/data/annotation',CRAN='https://cloud.r-project.org')
options(repos=repos)
downloads <- file.path(report,'downloads');dir.create(downloads)
intake <- dirname(source)
previous <- file.path(dirname(intake),'idep244-windows-runtime-setup-1')
description <- read.dcf(file.path(source,'DESCRIPTION'))
required <- function(d){
 fields <- intersect(c('Depends','Imports','LinkingTo'),colnames(d))
 unique(setdiff(trimws(sub('\\s*\\(.*','',unlist(strsplit(paste(d[1,fields],collapse=','),',')))),'R'))
}
imports <- required(description)
ggalt <- file.path(intake,'ggalt-current-intake-1/original-source')
biclust <- file.path(intake,'dependency-source-intake-1/biclust_2.0.3.1.tar.gz')
addons <- c('GO.db','org.Hs.eg.db','hgu133plus2.db','flexclust','additivityTests',required(read.dcf(file.path(ggalt,'DESCRIPTION'))))
present <- function(package)length(find.package(package,quiet=TRUE))>0L
need <- unique(c(imports,addons));missing <- function()need[!vapply(need,present,logical(1))]
status <- 'SKIP3_CURRENT_IDEP_RUNTIME_UNAVAILABLE';detail <- '';phase <- 'binary dependency closure';warnings_seen <- character()
tryCatch(withCallingHandlers({
 binary <- readRDS(file.path(previous,'AVAILABLE-BINARY.rds'))
 src <- readRDS(file.path(previous,'AVAILABLE-SOURCE.rds'))
 wanted <- intersect(missing(),rownames(binary))
 if(present('ggplot2')&&packageVersion('ggplot2')<'4.0.0')wanted<-unique(c(wanted,'ggplot2'))
 cat('BINARY_INSTALL',paste(wanted,collapse=','),'\n');flush.console()
 if(length(wanted))install.packages(wanted,lib=lib,repos=repos,type='binary',available=binary,
   dependencies=c('Depends','Imports','LinkingTo'),destdir=downloads)
 phase <- 'source annotation dependencies'
 for(package in c('GO.db','org.Hs.eg.db','hgu133plus2.db'))if(!present(package)) {
   cat('SOURCE_ANNOTATION_INSTALL',package,'\n');flush.console()
   install.packages(package,lib=lib,repos=repos,type='source',available=src,
      dependencies=c('Depends','Imports','LinkingTo'),destdir=downloads)
 }
 phase <- 'other dependency closure'
 wanted <- intersect(missing(),rownames(src))
 if(length(wanted))install.packages(wanted,lib=lib,repos=repos,type='source',available=src,
    dependencies=c('Depends','Imports','LinkingTo'),destdir=downloads)
 phase <- 'original archived biclust source'
 if(!present('biclust'))install.packages(biclust,lib=lib,repos=NULL,type='source')
 phase <- 'original current ggalt dependency source'
 if(!present('ggalt'))install.packages(ggalt,lib=lib,repos=NULL,type='source')
 if(length(missing()))stop('Required dependencies remain missing: ',paste(missing(),collapse=', '))
 phase <- 'unmodified current iDEP source'
 install.packages(source,lib=lib,repos=NULL,type='source')
 phase <- 'original namespace loading'
 stopifnot(requireNamespace('idepGolem',quietly=TRUE),as.character(packageVersion('idepGolem'))=='2.4.4')
 for(name in c('input_data','pre_process','convert_data','deg_deseq2'))stopifnot(is.function(getExportedValue('idepGolem',name)))
 status <- 'CURRENT_IDEP244_RUNTIME_LOADED_NO_ANALYSIS_ADMITTED'
},warning=function(w){warnings_seen<<-c(warnings_seen,conditionMessage(w));cat('ORIGINAL_SETUP_WARNING:',conditionMessage(w),'\n');flush.console()}),
error=function(e){detail<<-conditionMessage(e);cat('SKIP3_CURRENT_IDEP_RUNTIME_UNAVAILABLE:',detail,'\n')})
writeLines(missing(),file.path(report,'MISSING-AFTER.txt'))
installed <- installed.packages(lib.loc=.libPaths(),noCache=TRUE)
write.table(installed[,intersect(c('Package','Version','LibPath','Built'),colnames(installed)),drop=FALSE],file.path(report,'INSTALLED-PACKAGES.tsv'),sep='\t',quote=TRUE,row.names=FALSE)
writeLines(capture.output(sessionInfo()),file.path(report,'SESSION.txt'))
jsonlite::write_json(list(status=status,phase=phase,detail=detail,warnings=warnings_seen,missing=missing(),
    new_library=lib,R_version=R.version.string,source_version='2.4.4',analysis_admitted=FALSE,
    required_action='Supply the named permitted exact runtime dependencies in a NEW private library. If installation/access is forbidden, skip iDEP analysis. Preserve complete installer streams and partials; setup is not an analysis.'),
    file.path(report,'R-RESULT.json'),auto_unbox=TRUE,pretty=TRUE,null='null')
quit(status=if(status=='CURRENT_IDEP244_RUNTIME_LOADED_NO_ANALYSIS_ADMITTED')0L else 3L)
