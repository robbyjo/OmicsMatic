from pathlib import Path
import hashlib,io,json,tarfile,urllib.request

OUT=Path(__file__).resolve().parent
discovery=json.loads((OUT/'DISCOVERY.json').read_bytes())
tree=json.loads((OUT/'tree.response').read_bytes())
assert not tree['truncated']
expected={row['path']:row for row in tree['tree'] if row['type']=='blob'}
sha=discovery['observed_current_commit']
url='https://codeload.github.com/gexijin/idepGolem/tar.gz/'+sha
request=urllib.request.Request(url,headers={'User-Agent':'OmicsMatic-user-selected-newest-iDEP-intake'})
with urllib.request.urlopen(request,timeout=90) as response:raw=response.read(209715201);status=response.status
assert len(raw)<=209715200
with (OUT/'current-original-source.tar.gz').open('xb') as handle:handle.write(raw)
dest=OUT/'current-original-source';dest.mkdir(exist_ok=False)
members={};top=None
with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as archive:
    for member in archive:
        path=Path(member.name)
        if path.is_absolute() or '..' in path.parts:raise ValueError('Unsafe original archive member')
        if top is None:top=path.parts[0]
        if path.parts[0]!=top:raise ValueError('Multiple original archive roots')
        relative=Path(*path.parts[1:])
        if str(relative)=='.':continue
        target=dest/relative
        if member.isdir():target.mkdir(parents=True,exist_ok=True);continue
        if not member.isfile():raise ValueError('Nonregular original archive member: '+member.name)
        content=archive.extractfile(member).read();name=relative.as_posix()
        row=expected[name]
        blob=hashlib.sha1(b'blob '+str(len(content)).encode()+b'\0'+content).hexdigest()
        if len(content)!=row['size'] or blob!=row['sha']:raise ValueError('Original source archive differs from official Git tree: '+name)
        target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as handle:handle.write(content)
        members[name]=dict(bytes=len(content),sha256=hashlib.sha256(content).hexdigest(),git_blob_sha=blob,git_mode=row['mode'])
if set(members)!=set(expected):raise ValueError('Complete original Git source population differs')
version=next(line.split(':',1)[1].strip() for line in (dest/'DESCRIPTION').read_text().splitlines() if line.startswith('Version:'))
result=dict(status='CURRENT_DEFAULT_BRANCH_IDEP_COMPLETE_ORIGINAL_ARCHIVE_VERIFIED_AGAINST_OFFICIAL_GIT_TREE',
    commit=sha,DESCRIPTION_version_literal=version,source_commit_date=discovery['commit_date'],
    latest_published_release=discovery['latest_release'],latest_release_assessed_separately=True,
    url=url,status_code=status,archive=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()),members=members,
    choice='User requested newest iDEP. Select the current default-branch source, which is newer than the latest published release; retain both identities without numeric-version normalization.',
    user_selected_current_iDEP=True,author_iDEP96_snapshot_inferred=False,original_algorithms_modified=False,
    source_is_not_a_signed_authorship_attestation=True,analysis_started=False,implementation_credit_added=0)
(OUT/'CURRENT-SOURCE.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='members'},indent=2))
