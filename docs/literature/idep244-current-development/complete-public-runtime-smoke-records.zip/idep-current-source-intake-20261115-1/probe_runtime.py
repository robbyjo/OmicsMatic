from pathlib import Path
import csv,json,os,subprocess

OUT=Path(__file__).resolve().parent
ROOT=Path('D:/projects/JLinAlg')
report=OUT/'windows-runtime-readiness-1';report.mkdir(exist_ok=False)
base=ROOT/'build/literature-review/deseq2-runtime'
libs=[]
for pattern in ['*/R-lib','*/*/R-lib','*/library']:
    libs += sorted(base.glob(pattern))
libs += [ROOT/'build/literature-review/signac-runtime/motif-reference-setup-1/R-lib',ROOT/'build/literature-review/signac-runtime/reference-setup-1/R-lib',ROOT/'build/omics-sctransform-r']
libraries=report/'CANDIDATE-LIBRARIES.txt';libraries.write_text('\n'.join(str(path) for path in libs if path.is_dir())+'\n')
(report/'tmp').mkdir()
command=['C:/Program Files/R/R-4.6.1/bin/Rscript.exe','--vanilla',str(OUT/'RuntimeReadiness.R'),str(OUT/'current-original-source/DESCRIPTION'),str(libraries),str(report)]
env=dict(os.environ)
for name in list(env):
    if name.startswith('R_') or name.startswith('LC_') or name in ['LANG','LANGUAGE']:env.pop(name,None)
env.update(TMP=str(report/'tmp'),TEMP=str(report/'tmp'),TMPDIR=str(report/'tmp'),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
with (report/'process.stdout').open('xb') as so,(report/'process.stderr').open('xb') as se:
    child=subprocess.Popen(command,env=env,stdin=subprocess.DEVNULL,stdout=so,stderr=se)
    (report/'LIVE.json').write_text(json.dumps(dict(pid=child.pid,command=command),indent=2)+'\n')
    try:code=child.wait(timeout=120)
    except subprocess.TimeoutExpired:child.kill();child.wait();raise RuntimeError('Owned package-readiness probe timed out; no replacement started')
(report/'PROCESS.json').write_text(json.dumps(dict(pid=child.pid,command=command,exit_code=code),indent=2)+'\n')
if code:raise RuntimeError('Read-only runtime readiness probe failed; see full consoles')
with (report/'DIRECT-IMPORTS.tsv').open(newline='') as handle:rows=list(csv.DictReader(handle,delimiter='\t'))
result=dict(status='EXISTING_LIBRARY_READINESS_ONLY_NO_IDEP_INSTALL_OR_ANALYSIS',direct_imports=len(rows),available=sum(row['available']=='TRUE' for row in rows),missing=[row['package'] for row in rows if row['available']=='FALSE'],iDEP_installed=False,analysis_started=False)
(report/'COMPLETED.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
