c(BioCsoft = "https://bioconductor.org/packages/3.23/bioc", BioCann = "https://bioconductor.org/packages/3.23/data/annotation", 
BioCexp = "https://bioconductor.org/packages/3.23/data/experiment", 
CRAN = "https://cloud.r-project.org")
