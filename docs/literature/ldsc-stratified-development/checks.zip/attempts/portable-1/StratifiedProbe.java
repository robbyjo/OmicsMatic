package org.jlinalg.xwas;
import java.nio.file.*;import java.util.*;import java.nio.charset.StandardCharsets;
public class StratifiedProbe {
 public static void main(String[] args)throws Exception {
  Path dest=Path.of(args[0]);Files.createDirectory(dest);
  for(var model:StratifiedLdscTest.models()){
   var fit=model.fit();var overlap=StratifiedLdsc.overlap(fit,model.overlap(),model.universe());var flat=new TreeMap<String,Object>();StratifiedLdscTest.flatten("fit",fit,flat);StratifiedLdscTest.flatten("overlap",overlap,flat);
   var rows=new StringBuilder("field\tvalue\n");for(var e:flat.entrySet())if(e.getValue()==null||e.getValue() instanceof Number)rows.append(e.getKey()).append('\t').append(e.getValue()==null?"NA":e.getValue()).append('\n');
   Files.writeString(dest.resolve(model.id()+".tsv"),rows.toString(),StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW);
  }
 }
}
