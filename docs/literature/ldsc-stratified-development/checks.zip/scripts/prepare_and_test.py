import hashlib,json,os,shutil,subprocess,time,traceback,xml.etree.ElementTree as ET
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];out=b/'native-test-1';out.mkdir()
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
try:
 dest=r/'src/test/resources/org/jlinalg/xwas/ldsc-stratified';dest.mkdir()
 shutil.copyfile(b/'reference-1/result/reference-fixtures.zip',dest/'reference-fixtures.zip');shutil.copyfile(b/'generate_reference.py',dest/'generate_reference.py')
 names=['src/main/java/org/jlinalg/xwas/StratifiedLdsc.java','src/test/java/org/jlinalg/xwas/StratifiedLdscTest.java']+[p.relative_to(r).as_posix() for p in dest.iterdir()]
 save(out/'SOURCES.json',{n:pin(r/n) for n in names})
 for name in names:
  p=out/'sources'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/name,p)
 rel=out.relative_to(r).as_posix();init=out/'private.gradle';init.write_text("gradle.projectsEvaluated { rootProject.tasks.named('test') { reports.junitXml.outputLocation.set(rootProject.layout.projectDirectory.dir('"+rel+"/test-results')); reports.html.outputLocation.set(rootProject.layout.projectDirectory.dir('"+rel+"/test-report')) } }\n",newline='\n')
 cmd=[str(r/'gradlew.bat'),'--no-daemon','--console=plain','-I',str(init),':test','--tests','org.jlinalg.xwas.StratifiedLdscTest'];save(out/'command.json',cmd);env=dict(os.environ,JAVA_HOME='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot');start=time.monotonic()
 with (out/'stdout').open('xb') as so,(out/'stderr').open('xb') as se:p=subprocess.run(cmd,cwd=r,env=env,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=900)
 save(out/'PROCESS.json',dict(exit_code=p.returncode,seconds=time.monotonic()-start));assert p.returncode==0
 trees=[ET.parse(p).getroot() for p in (out/'test-results').glob('TEST-*.xml')];counts={k:sum(int(t.attrib.get(k,0)) for t in trees) for k in ['tests','errors','failures','skipped']};assert counts==dict(tests=9,errors=0,failures=0,skipped=0),counts
 save(out/'COMPLETED.json',dict(status='PASS_NATIVE_PARTITIONED_ORIGINAL_REFERENCE_TESTS',junit=counts));print('PASS',counts,flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc()));print(traceback.format_exc(),flush=True);raise
