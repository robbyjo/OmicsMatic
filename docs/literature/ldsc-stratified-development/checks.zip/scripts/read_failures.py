from pathlib import Path
import xml.etree.ElementTree as ET
r=Path(__file__).resolve().parent
for p in (r/'native-test-1/test-results').glob('TEST-*.xml'):
 t=ET.parse(p).getroot();print(t.attrib)
 for c in t.findall('testcase'):
  f=c.find('failure')
  if f is not None:print(c.attrib['name'],f.attrib.get('message'),(f.text or '')[:1600])
 print('STDOUT',(t.findtext('system-out') or '')[:800])
