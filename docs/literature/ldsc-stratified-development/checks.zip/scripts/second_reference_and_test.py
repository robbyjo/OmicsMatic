import json,os,shutil,subprocess,sys,time,traceback,xml.etree.ElementTree as ET
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];out=b/'native-test-2';out.mkdir()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def run(tag,cmd,env=None):
 save(out/(tag+'-command.json'),cmd);start=time.monotonic()
 with (out/(tag+'.stdout')).open('xb') as so,(out/(tag+'.stderr')).open('xb') as se:p=subprocess.run(cmd,cwd=r,env=env,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=900)
 save(out/(tag+'-PROCESS.json'),dict(exit_code=p.returncode,seconds=time.monotonic()-start));assert p.returncode==0
try:
 old=b/'reference-1';shutil.copyfile(r/'src/test/resources/org/jlinalg/xwas/ldsc-stratified/generate_reference.py',old/'generator.py')
 # Reuse the same immutable provider/runtime audit with a NEW output directory.
 original=(b/'run_reference.py').read_text();runner=b/'run_reference2.py';runner.write_text(original.replace("out=b/'reference-1'","out=b/'reference-2'"),newline='\n');run('reference',[sys.executable,'-X','utf8','-B',str(runner)])
 dest=r/'src/test/resources/org/jlinalg/xwas/ldsc-stratified';shutil.copyfile(b/'reference-2/result/reference-fixtures.zip',dest/'reference-fixtures.zip');shutil.copyfile(b/'generate_reference.py',dest/'generate_reference.py')
 for name in ['src/main/java/org/jlinalg/xwas/StratifiedLdsc.java','src/test/java/org/jlinalg/xwas/StratifiedLdscTest.java',*[p.relative_to(r).as_posix() for p in dest.iterdir()]]:
  p=out/'sources'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/name,p)
 rel=out.relative_to(r).as_posix();init=out/'private.gradle';init.write_text("gradle.projectsEvaluated { rootProject.tasks.named('test') { reports.junitXml.outputLocation.set(rootProject.layout.projectDirectory.dir('"+rel+"/test-results')); reports.html.outputLocation.set(rootProject.layout.projectDirectory.dir('"+rel+"/test-report')) } }\n",newline='\n')
 run('java',[str(r/'gradlew.bat'),'--no-daemon','--console=plain','-I',str(init),':test','--tests','org.jlinalg.xwas.StratifiedLdscTest'],dict(os.environ,JAVA_HOME='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot'))
 trees=[ET.parse(p).getroot() for p in (out/'test-results').glob('TEST-*.xml')];counts={k:sum(int(t.attrib.get(k,0)) for t in trees) for k in ['tests','errors','failures','skipped']};assert counts==dict(tests=9,errors=0,failures=0,skipped=0),counts
 save(out/'COMPLETED.json',dict(status='PASS_EXTREME_AND_ORDINARY_ORIGINAL_PARTITIONED_REFERENCES',junit=counts,original_models=48,reference_fields=22596));print('PASS',counts,flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc()));print(traceback.format_exc(),flush=True);raise
