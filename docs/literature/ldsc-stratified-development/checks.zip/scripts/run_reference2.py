import hashlib,json,subprocess,time,traceback
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];previous=r/'build/ldsc-high-impact-1';out=b/'reference-2';out.mkdir()
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
try:
 runtime=previous/'reference-runtime-1/python';manifest=json.loads((previous/'reference-runtime-1/INSTALLED-FILES.json').read_bytes());assert {p.relative_to(runtime).as_posix() for p in runtime.rglob('*') if p.is_file()}==set(manifest)
 assert all(pin(runtime/n)==expected for n,expected in manifest.items());save(out/'RUNTIME-INTAKE.json',dict(status='PASS_COMPLETE_SAVED_RUNTIME_POPULATION_AND_BYTES',files=len(manifest),manifest=pin(previous/'reference-runtime-1/INSTALLED-FILES.json')))
 cmd=[str(runtime/'python.exe'),'-B',str(b/'generate_reference.py'),'--source',str(previous/'upstream-1/cbiit'),'--out',str(out/'result')];save(out/'command.json',cmd);start=time.monotonic()
 with (out/'stdout').open('xb') as so,(out/'stderr').open('xb') as se:p=subprocess.run(cmd,cwd=b,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=180)
 save(out/'PROCESS.json',dict(exit_code=p.returncode,seconds=time.monotonic()-start));assert p.returncode==0
 assert all(pin(runtime/n)==expected for n,expected in manifest.items());save(out/'COMPLETED.json',dict(status='PASS_ORIGINAL_PARTITIONED_REFERENCE_AND_UNCHANGED_RUNTIME',models=48,runtime_files=len(manifest)));print('PASS original partitioned reference',flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc()));print(traceback.format_exc(),flush=True);raise
