import hashlib,json,os,re,subprocess,sys,time,traceback,zipfile
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];out=b/'closure-1';out.mkdir();evidence=r/'docs/literature/ldsc-stratified-development'
def rawpin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def pin(p):return rawpin(p.read_bytes())
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
def run(tag,cmd):
 save(out/(tag+'-command.json'),cmd);start=time.monotonic()
 with (out/(tag+'.stdout')).open('xb') as so,(out/(tag+'.stderr')).open('xb') as se:p=subprocess.run(cmd,cwd=r,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=300)
 save(out/(tag+'-PROCESS.json'),dict(exit_code=p.returncode,seconds=time.monotonic()-start));assert p.returncode==0,(tag,p.returncode)
try:
 portable=json.loads((b/'portable-1/COMPLETED.json').read_bytes());assert portable['status']=='PASS_PACKAGED_PARTITIONED_API_WINDOWS_AND_LINUX'
 reference=json.loads((b/'reference-2/result/reference.json').read_bytes());assert reference['models']==48 and reference['fields']==22596 and not reference['errors']
 assert min(c['expected']['totalH2'] for c in reference['cases'])<0 and max(c['expected']['totalH2'] for c in reference['cases'])>1
 for n,v in portable['source_guards'].items():assert pin(r/n)==v,n
 source=r/'build/ldsc-high-impact-1/upstream-1/cbiit'
 for n,v in reference['source_guards'].items():assert pin(source/n)==v,n
 runtime=r/'build/ldsc-high-impact-1/reference-runtime-1/python';runtime_manifest=r/'build/ldsc-high-impact-1/reference-runtime-1/INSTALLED-FILES.json';installed=json.loads(runtime_manifest.read_bytes());assert all(pin(runtime/n)==v for n,v in installed.items())
 # Compile/run the exact public API examples against the packaged library.
 guide=r/'docs/vignettes/stratified-ldsc.md';snippets=re.findall(r'```java\n(.*?)```',guide.read_text(),re.S);assert len(snippets)==2
 java=out/'DocumentedExample.java';body='\n'.join(snippets);imports='\n'.join(line for line in body.splitlines() if line.startswith('import '));body='\n'.join(line for line in body.splitlines() if not line.startswith('import '))
 java.write_text(imports+'\npublic class DocumentedExample { public static void main(String[] args)throws Exception {\n'+body+'\nSystem.out.println("Documented overlap categories: "+overlap.enrichments().length);\n} }\n',encoding='utf8',newline='\n')
 artifact=b/'portable-1/jar/omicsmatic-0.4.0.jar';jdk=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin');classes=out/'example-classes';classes.mkdir();run('example-compile',[str(jdk/'javac.exe'),'--release','17','-cp',str(artifact),'-d',str(classes),str(java)]);run('example-run',[str(jdk/'java.exe'),'-cp',os.pathsep.join(map(str,[classes,artifact])),'DocumentedExample'])
 # Confirm that new sources preserve the current catalog and prior qualifications.
 run('catalog',[sys.executable,'-X','utf8','-B',str(r/'tools/literature/ldsc_hsq/catalog.py'),'--verify','--primary-cache','D:/projects/JLinAlg/build/literature-review/xml','--out',str(out/'catalog-current')])
 source_names=['src/main/java/org/jlinalg/xwas/StratifiedLdsc.java','src/main/java/org/jlinalg/xwas/LdscHeritability.java','src/test/java/org/jlinalg/xwas/StratifiedLdscTest.java','docs/vignettes/stratified-ldsc.md','docs/literature/IMPLEMENTATION_PRIORITY.md','tools/literature/ldsc_stratified/verify.py','build.gradle']+[p.relative_to(r).as_posix() for p in (r/'src/test/resources/org/jlinalg/xwas/ldsc-stratified').iterdir() if p.is_file()]+[p.relative_to(r).as_posix() for p in evidence.iterdir() if p.is_file()]
 guards={name:pin(r/name) for name in source_names};payload={}
 for folder in ['reference-1','reference-2','native-test-1','native-test-2','portable-1']:
  for p in (b/folder).rglob('*'):
   if p.is_file() and 'jar' not in p.relative_to(b/folder).parts:payload['attempts/'+p.relative_to(b).as_posix()]=p.read_bytes()
 for p in b.glob('*.py'):
  if p.name!='inspect_runtime.py':payload['scripts/'+p.name]=p.read_bytes()
 for n in source_names:payload['snapshot/'+n]=(r/n).read_bytes()
 for n in reference['source_guards']:payload['original-cbiit/'+n]=(source/n).read_bytes()
 payload['reference-runtime/INSTALLED-FILES.json']=runtime_manifest.read_bytes()
 for p in out.rglob('*'):
  if p.is_file():payload['closure/'+p.relative_to(out).as_posix()]=p.read_bytes()
 index={n:rawpin(raw) for n,raw in sorted(payload.items())};payload['ENTRY-MANIFEST.json']=(json.dumps(dict(payloads=index),indent=2)+'\n').encode();archive=evidence/'checks.zip'
 with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for n,raw in sorted(payload.items()):z.writestr(n,raw)
 with zipfile.ZipFile(archive) as z:
  assert len(z.namelist())==len(set(z.namelist()))==len(index)+1 and set(z.namelist())==set(index)|{'ENTRY-MANIFEST.json'} and z.testzip() is None
  for n,v in index.items():assert rawpin(z.read(n))==v,n
 validation=dict(status='PASS_NATIVE_PREPARED_PARTITIONED_LDSC_API',profile='native-partitioned-ldsc-cbiit302-fixed-initial-v1',original_commit='6c673952cee74bd5c57aef1555a03b1c015399a0',original_models=48,reference_fields=22596,windows_tests=dict(tests=9,errors=0,failures=0,skipped=0),linux_same_tests=dict(tests=9,errors=0,failures=0,skipped=0),byte_identical_complete_model_payloads=48,all_prior_jar_members_unchanged=True,artifact=portable['artifact'],source_guards=guards,original_source_guards=reference['source_guards'],reference_runtime_files=len(installed),source_namespace_initializer_bypassed=True,original_functions_replaced=False,initial_failed_tests_retained=True,initial_reference_retained=True,guide_examples_compiled_and_executed=True,current_catalog_verified=True,historical_fingerprints_refreshed=False,indexed_payloads=len(index),all_archive_payloads_read_back=True,archive=pin(archive),new_family_credit=0,new_scoped_integration_count=128,missing_families=260,whole_tool_qualified=False,whole_goal_complete=False,CLI_scope='Java API; prepared-data workflow command remains open',website_deployed=False,released=False,pushed=False)
 save(evidence/'VALIDATION.json',validation)
 run('retained-verifier',[sys.executable,'-X','utf8','-B',str(r/'tools/literature/ldsc_stratified/verify.py'),'--out',str(out/'retained-recheck')])
 save(out/'COMPLETED.json',validation);print(json.dumps({k:validation[k] for k in ['status','original_models','reference_fields','indexed_payloads','archive']}),flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc()));print(traceback.format_exc(),flush=True);raise
