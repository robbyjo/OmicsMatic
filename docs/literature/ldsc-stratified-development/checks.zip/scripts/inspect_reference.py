from pathlib import Path
import json
p=Path(__file__).resolve().parent/'reference-1/result/reference.json';x=json.loads(p.read_bytes())
print('models',x['models'],'fields',x['fields'])
for key in ['totalH2','initialH2']:
 v=[c['expected'][key] for c in x['cases']];print(key,min(v),max(v),sum(a<0 for a in v),sum(a>1 for a in v))
print('model profiles',[(c['id'],c['expected']['totalH2']) for c in x['cases'] if c['id'][-1] in '89'])
