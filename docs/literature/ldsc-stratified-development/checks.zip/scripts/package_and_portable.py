import hashlib,json,os,shutil,subprocess,time,traceback,xml.etree.ElementTree as ET,zipfile
from pathlib import Path
b=Path(__file__).resolve().parent;r=b.parents[1];out=b/'portable-1';out.mkdir()
jdk=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin');junit=r/'build/nfcore-atacseq121-1/linux-test-runtime-1/junit-platform-console-standalone-1.13.4.jar';distro='JLinAlg-Omics-SAIGE-20261026'
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def run(tag,cmd,env=None):
 save(out/(tag+'-command.json'),cmd);start=time.monotonic()
 with (out/(tag+'.stdout')).open('xb') as so,(out/(tag+'.stderr')).open('xb') as se:p=subprocess.run(cmd,cwd=r,env=env,stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=900)
 save(out/(tag+'-PROCESS.json'),dict(exit_code=p.returncode,seconds=time.monotonic()-start));assert p.returncode==0,(tag,p.returncode)
def linux(p):p=Path(p).resolve();return '/mnt/'+p.drive[0].lower()+'/'+p.as_posix()[3:]
try:
 assert (b/'native-test-2/COMPLETED.json').exists()
 guards={n:pin(r/n) for n in ['src/main/java/org/jlinalg/xwas/StratifiedLdsc.java','src/test/java/org/jlinalg/xwas/StratifiedLdscTest.java',*[p.relative_to(r).as_posix() for p in (r/'src/test/resources/org/jlinalg/xwas/ldsc-stratified').iterdir()]]};save(out/'SOURCES.json',guards)
 rel=out.relative_to(r).as_posix();init=out/'private.gradle';init.write_text("gradle.projectsEvaluated { rootProject.tasks.named('executableJar') { destinationDirectory.set(rootProject.layout.projectDirectory.dir('"+rel+"/jar')) } }\n",newline='\n')
 run('package',[str(r/'gradlew.bat'),'--no-daemon','--console=plain','-I',str(init),':executableJar'],dict(os.environ,JAVA_HOME=str(jdk.parent)))
 artifact=out/'jar/omicsmatic-0.4.0.jar';baseline=r/'build/ldsc-rg-high-impact-1/build-2/jar/omicsmatic-0.4.0.jar';new=[]
 with zipfile.ZipFile(baseline) as old,zipfile.ZipFile(artifact) as current:
  assert set(old.namelist())<=set(current.namelist())
  for name in old.namelist():assert old.read(name)==current.read(name),'Changed prior member: '+name
  new=sorted(set(current.namelist())-set(old.namelist()));assert all(name.startswith('org/jlinalg/xwas/StratifiedLdsc') for name in new),new
 save(out/'PRIOR-JAR-MEMBERS.json',dict(status='PASS_ALL_PRIOR_JAR_MEMBERS_UNCHANGED',new_members=new,baseline=pin(baseline),artifact=pin(artifact)))
 classes=out/'test-classes';classes.mkdir();cp=os.pathsep.join(map(str,[artifact,junit]));run('compile-tests',[str(jdk/'javac.exe'),'--release','17','-cp',cp,'-d',str(classes),str(r/'src/test/java/org/jlinalg/xwas/StratifiedLdscTest.java')])
 resources=r/'src/test/resources'
 for platform in ['windows','linux']:
  report=out/(platform+'-junit');report.mkdir();pathsep=';' if platform=='windows' else ':';paths=[artifact,classes,resources];testcp=pathsep.join(str(p) if platform=='windows' else linux(p) for p in paths)
  args=['execute','--class-path',testcp,'--select-class','org.jlinalg.xwas.StratifiedLdscTest','--reports-dir',str(report) if platform=='windows' else linux(report),'--details','summary','--disable-ansi-colors']
  cmd=[str(jdk/'java.exe'),'-jar',str(junit),*args] if platform=='windows' else ['wsl.exe','-d',distro,'--','java','-jar',linux(junit),*args];run(platform+'-tests',cmd)
  trees=[ET.parse(p).getroot() for p in report.glob('TEST-*.xml')];counts={k:sum(int(t.attrib.get(k,0)) for t in trees) for k in ['tests','errors','failures','skipped']};assert counts==dict(tests=9,errors=0,failures=0,skipped=0),counts
  save(out/(platform+'-COUNTS.json'),counts)
 probe=out/'StratifiedProbe.java';probe.write_text('''package org.jlinalg.xwas;
import java.nio.file.*;import java.util.*;import java.nio.charset.StandardCharsets;
public class StratifiedProbe {
 public static void main(String[] args)throws Exception {
  Path dest=Path.of(args[0]);Files.createDirectory(dest);
  for(var model:StratifiedLdscTest.models()){
   var fit=model.fit();var overlap=StratifiedLdsc.overlap(fit,model.overlap(),model.universe());var flat=new TreeMap<String,Object>();StratifiedLdscTest.flatten("fit",fit,flat);StratifiedLdscTest.flatten("overlap",overlap,flat);
   var rows=new StringBuilder("field\\tvalue\\n");for(var e:flat.entrySet())if(e.getValue()==null||e.getValue() instanceof Number)rows.append(e.getKey()).append('\\t').append(e.getValue()==null?"NA":e.getValue()).append('\\n');
   Files.writeString(dest.resolve(model.id()+".tsv"),rows.toString(),StandardCharsets.UTF_8,StandardOpenOption.CREATE_NEW);
  }
 }
}
''',encoding='utf8',newline='\n')
 run('compile-probe',[str(jdk/'javac.exe'),'--release','17','-cp',os.pathsep.join(map(str,[artifact,junit,classes,resources])),'-d',str(classes),str(probe)])
 for platform in ['windows','linux']:
  target=out/(platform+'-payloads');parts=[artifact,junit,classes,resources]
  cmd=[str(jdk/'java.exe'),'-cp',os.pathsep.join(map(str,parts)),'org.jlinalg.xwas.StratifiedProbe',str(target)] if platform=='windows' else ['wsl.exe','-d',distro,'--','java','-cp',':'.join(linux(p) for p in parts),'org.jlinalg.xwas.StratifiedProbe',linux(target)]
  run(platform+'-probe',cmd)
 windows=out/'windows-payloads';other=out/'linux-payloads';identical=[];different=[]
 assert {p.name for p in windows.iterdir()}=={p.name for p in other.iterdir()} and len(list(windows.iterdir()))==48
 for p in sorted(windows.iterdir()):(identical if p.read_bytes()==(other/p.name).read_bytes() else different).append(p.name)
 assert not different,different
 assert all(pin(r/n)==v for n,v in guards.items())
 save(out/'COMPLETED.json',dict(status='PASS_PACKAGED_PARTITIONED_API_WINDOWS_AND_LINUX',windows_tests=9,linux_same_tests=9,reference_models=48,reference_fields=22596,byte_identical_complete_model_payloads=len(identical),all_prior_jar_members_unchanged=True,new_jar_members=new,artifact=pin(artifact),source_guards=guards));print('PASS packaged API, same9 tests Windows/Linux,48 identical complete payloads',flush=True)
except Exception as e:save(out/'FAILURE.json',dict(error=repr(e),traceback=traceback.format_exc()));print(traceback.format_exc(),flush=True);raise
