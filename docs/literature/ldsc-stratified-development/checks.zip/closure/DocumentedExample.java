import org.jlinalg.xwas.StratifiedLdsc;
public class DocumentedExample { public static void main(String[] args)throws Exception {

// Small synthetic API example; these four rows are not a study analysis.
double[] chi = {1.2, 1.3, 1.4, 1.5};
double[][] ld = {{1, 1}, {2, 1}, {1, 2}, {2, 2}};
double[] weightLd = {2, 3, 3, 4};
double[] n = {1e6, 1e6, 1e6, 1e6};
double[] annotationCounts = {1e6, 5e5};
var fit = StratifiedLdsc.fit(chi, ld, weightLd, n,
    annotationCounts, 2, 1.0);
for (String warning : fit.warnings()) System.err.println(warning);
System.out.println("Observed h2: " + fit.totalH2());
System.out.println("Jackknife SE: " + fit.totalStandardError());

double[][] intersections = {{1e6, 0}, {0, 5e5}};
var overlap = StratifiedLdsc.overlap(fit, intersections, 1.5e6);
System.out.println("Documented overlap categories: "+overlap.enrichments().length);
} }
