"""Freeze the actual native expression preparation, scoped role audit and retained discrepancies."""
import csv
import hashlib
import json
from datetime import datetime,timezone
from pathlib import Path
import zipfile

ROOT=Path('D:/projects/JLinAlg');RUN=ROOT/'build/literature-review/fuma-runtime/expression-preparation-development-1';DEST=ROOT/'docs/literature/fuma-expression-preparation-2'
def pin(p):raw=p.read_bytes();return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,j):p.write_text(json.dumps(j,indent=2)+'\n',encoding='utf-8',newline='\n')
def census(p):return {q.relative_to(p).as_posix():pin(q) for q in sorted(p.rglob('*')) if q.is_file()}

matrix=read(RUN/'matrix-3/COMPLETED.json');commands=read(RUN/'commands-3/COMPLETED.json');roles=read(RUN/'role-audit-3/coverage.json');family=read(RUN/'family-tests-3-summary.json');normalization=read(RUN/'LF-rebuild-comparison.json')
assert matrix['status']=='passed-three-JVM-packaged-FUMA-expression-preparation' and matrix['tests_per_JVM']==148 and len(matrix['runs'])==3
assert commands['status']=='passed-public-expression-preparation-workflow-and-original-MAGMA-fit' and len(commands['calls'])==5
assert roles['status']=='passed-fourteen-retained-FUMA-source-role-review' and roles['roles']==14
assert family['tests']==663 and family['failed']==family['skipped']==family['errors']==0
assert commands['original_MAGMA_gene_count']==201 and commands['original_MAGMA_tested_properties']==3
assert {k:matrix['artifact'][k] for k in ['bytes','sha256']}=={k:commands['artifact'][k] for k in ['bytes','sha256']}==pin(ROOT/matrix['artifact']['path'])==pin(ROOT/commands['artifact']['path'])
assert normalization['prior_jar_sha256']==normalization['final_jar_sha256']; correction=read(RUN/'metadata-correction-comparison.json'); assert correction['final_artifact_sha256']==matrix['artifact']['sha256']
assert (RUN/'FumaWorkflowCli-before-LF.java').read_bytes().replace(b'\r\n',b'\n')==(ROOT/'src/main/java/org/jlinalg/cli/FumaWorkflowCli.java').read_bytes()
sources=dict(matrix['source_pins'])
for group in [commands['source_pins'],roles['source_pins']]:
    for n,v in group.items():
        if n in sources:assert sources[n]==v,n
        sources[n]=v
for n in ['tools/literature/audit_fuma_preparation_roles.py','examples/fuma-expression-preparation/.gitattributes','examples/fuma-reference/.gitattributes']:sources[n]=pin(ROOT/n)
assert all(pin(ROOT/n)==v for n,v in sources.items())
canonical=matrix['canonical_executable_unchanged'];assert canonical==commands['canonical_executable_unchanged']==pin(ROOT/'build/cli/omicsmatic-0.3.7.jar')
assert pin(ROOT/'build/omics-magma/magma.exe')==commands['original_MAGMA_runtime']
assert (RUN/'independent-R-controls-2.log').read_text(encoding='utf-8').strip()=='Completed independent published-method controls:16 cases,192 gene rows'
reference_files=[];finite=0;overflow=[]
for p in sorted((RUN/'independent-R-controls-2').glob('*/expected.tsv')):
    with p.open(encoding='utf-8',newline='') as f:rows=list(csv.DictReader(f,delimiter='\t'))
    assert len(rows)==12
    for r in rows:
        for k,v in r.items():
            if k in ['gene','disposition','capped']:continue
            if v=='Inf':assert r['gene']=='ENSG7.7' and k.startswith('raw:');overflow.append(dict(case=p.parent.name,gene=r['gene'],column=k,reference='Inf',native='Double.MAX_VALUE'))
            else:assert __import__('math').isfinite(float(v));finite+=1
    reference_files.append(p)
assert len(reference_files)==16 and overflow and finite+len(overflow)==2112
assert not DEST.exists(),'Preserve the previous checkpoint'
DEST.mkdir();(DEST/'.gitattributes').write_text('* -text\n',encoding='ascii',newline='\n')
sources[(DEST/'.gitattributes').relative_to(ROOT).as_posix()]=pin(DEST/'.gitattributes')
write(DEST/'role-coverage.json',roles)
items={};graphs={}
def add(n,p):assert n not in items and p.is_file(),n;items[n]=(p,pin(p))
def tree(prefix,p,record=None):
    graph=census(p);graphs[p]=graph
    if record is not None:assert {n:v for n,v in graph.items() if n!='COMPLETED.json'}==record['files']
    for n in graph:add(prefix+'/'+n,p/n)
for name,record in [('matrix-3',matrix),('commands-3',commands)]:tree('evidence/'+name,RUN/name,record)
tree('history/matrix-1',RUN/'matrix-1',read(RUN/'matrix-1/COMPLETED.json')); tree('history/matrix-2',RUN/'matrix-2',read(RUN/'matrix-2/COMPLETED.json')); tree('history/commands-2',RUN/'commands-2',read(RUN/'commands-2/COMPLETED.json')); tree('history/metadata-correction-before',RUN/'metadata-correction-before')
for name in ['commands-1','role-audit-1','R-comparison-tests-1-snapshot','family-tests-1-snapshot']:tree('history/'+name,RUN/name)
for name in ['role-audit-3','family-tests-3-results','example-classes-1','independent-R-controls-1','independent-R-controls-2']:tree('evidence/'+name,RUN/name)
for name in ['native-tests-1.log','cli-tests-1.log','independent-R-controls-1.log','independent-R-controls-2.log','freeze-controls-1.log','R-comparison-tests-1.log','R-comparison-tests-2.log','family-tests-1.log','family-tests-2.log','family-tests-3-summary.json','build-1.log','build-2.log','example-compile-1.log','matrix-1.log','matrix-2.log','commands-1.log','commands-2.log','role-audit-1.log','role-audit-2.log','LF-rebuild-comparison.json','FumaWorkflowCli-before-LF.java']:add('logs/'+name,RUN/name)
for name in ['family-tests-3.log','family-tests-3-summary.json','build-3.log','matrix-3.log','commands-3.log','role-audit-3.log','metadata-correction-comparison.json']:add('correction/'+name,RUN/name)
for n in sources:add('source/'+n,ROOT/n)
add('source/record-checkpoint.py',Path(__file__))
prior_path=ROOT/'docs/literature/fuma-reference-workflow/VALIDATION.json';prior=read(prior_path);assert pin(prior_path.parent/'controls.zip')=={k:prior['archive'][k] for k in ['bytes','sha256']}
add('prior/reference-workflow-VALIDATION.json',prior_path);add('prior/reference-workflow-controls.zip',prior_path.parent/'controls.zip')
with zipfile.ZipFile(DEST/'controls.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for n,(p,v) in sorted(items.items()):
        assert pin(p)==v,n;entry=zipfile.ZipInfo(n,(1980,1,1,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED;entry.external_attr=0o100644<<16;archive.writestr(entry,p.read_bytes())
assert all(census(p)==g for p,g in graphs.items()) and all(pin(ROOT/n)==v for n,v in sources.items())
proof=dict(schema_version=1,status='passed-native-FUMA-sample-expression-preparation-and-typed-handoff',recorded_utc=datetime.now(timezone.utc).isoformat(),artifact=matrix['artifact'],scope='Explicit raw sample TPM/RPKM -> raw >1 gene eligibility, cap50/log2(x+1), label means, selected-sample-centered label means, unweighted label Average -> typed supplied-expression/DEG analysis and actual original MAGMA property fitting. No DEG generation, t-test, clustering or historical resource claim.',tests_per_JVM=148,new_tests_per_JVM=44,prior_reference_and_core_tests_per_JVM=104,heap_mib=128,platforms=[r['name'] for r in matrix['runs']],affected_family_tests=family,independent_reference=dict(type='independent base-R implementation of published method; NOT original FUMA preprocessing runtime',cases_per_JVM=16,gene_rows_per_JVM=192,numeric_fields_per_JVM=2112,finite_reference_comparisons_per_JVM=finite,retained_base_R_raw_mean_overflows_per_JVM=len(overflow),overflow_departures=overflow,eligibility_decisions_per_JVM=192,reported_scope='Native raw means use stable scaling; every deliberately constructed maximum-double raw row remains finite. Finite comparison tolerance absolute5e-14 plus relative1e-12. No source field is silently replaced or removed.',fixture=dict(path='src/test/resources/org/jlinalg/enrichment/fuma-expression-preparation/independent-R-controls.zip',**pin(ROOT/'src/test/resources/org/jlinalg/enrichment/fuma-expression-preparation/independent-R-controls.zip'))),public_commands=commands['calls'],original_MAGMA=dict(version=commands['original_MAGMA_version'],runtime=commands['original_MAGMA_runtime'],genes=201,tested_tissues=3,condition_hide='Average',data='wholly synthetic owned expression and sealed owned synthetic gene fit'),source_role_audit=dict(path='role-coverage.json',**pin(DEST/'role-coverage.json'),roles=14,new_preparation_relevant_papers=roles['new_preparation_relevant_papers']),source_pins=sources,prior_checkpoint=dict(path=prior_path.relative_to(ROOT).as_posix(),**pin(prior_path)),unchanged_prior_packaged_classes=matrix['unchanged_prior_packaged_classes'],changed_prior_packaged_classes=matrix['changed_prior_packaged_classes'],new_packaged_classes=matrix['new_packaged_classes'],owned_classes=matrix['owned_classes'],canonical_executable_unchanged=canonical,source_LF_normalization=normalization,metadata_correction=correction,public_command_artifact_note='Commands-3 and matrix-3 use final package-3. The earlier checkpoint is retained separately; the corrected JSON sample counts are checked directly. Every scientific table and every prior packaged class except the single CLI metadata writer are byte-identical to package-2.',archive=dict(path='controls.zip',**pin(DEST/'controls.zip'),entries=len(items)),archive_files={n:v for n,(_,v) in sorted(items.items())},retained_failed_or_warning_attempts=['Earlier docs/literature/fuma-expression-preparation checkpoint retained: numerical tables passed, but session label_sample_counts was serialized as a Java int-array identity string. Corrected to a JSON integer list; strengthened existing test and public verifier, reran663 family tests and148 tests/JVM, and compared every affected scientific output byte.','independent-R-controls-1: unsupported C.UTF-8 startup locale warnings. Reexecuted with LC_ALL=C; every scientific input/output TSV byte matched. Both runs retained.','R-comparison-tests-1: seven cases exposed actual base-R raw means Inf at constant maximum finite-double inputs. Fixture unchanged; tests now retain the exact discrepancy and require finite native Double.MAX_VALUE only for that constructed row. Native math was not changed to force reference parity.','family-tests-1: three extra parentheses in new workflow test assertions prevented test compilation. Corrected test syntax; native numerical code unchanged.','commands-1: every public command, including original MAGMA fitting, exited0; verifier expected session.json but existing MAGMA publishes session.yaml. Corrected receipt lookup and reran commands-2. A PyYAML availability probe found no module installed; the verifier reads only the two fixed plain scalar runtime receipts, so no new dependency/install was needed.','LF normalization: edited FumaWorkflowCli.java was CRLF despite repository LF policy. Preserved pre-normalization source, rebuilt to a new package, proved all19264 entry bytes and complete JAR SHA256 identical, and bound final LF source hashes to fresh148-test/JVM matrix-2. Example attributes preserve exact JSON/source bytes on later checkouts.'],claims=dict(native_expression_preparation_available_in_candidate=True,streaming_TSV_and_GCT12=True,typed_expression_prepare_handoff=True,actual_original_MAGMA_fit=True,original_FUMA_preprocessing_runtime=False,DEG_generation_available=False,heatmap_clustering_available=False,resource_ID_conversion_available=False,historical_or_whole_paper_equivalence=False,catalog_promoted=False,whole_goal_complete=False,released_or_deployed=False,pushed=False),required_action='Use FUMA_EXPRESSION_PREPARATION.md and the identified candidate. Declare raw TPM/RPKM units, sample/label selection, namespaces and resource releases. Inspect every gene exclusion and the distinction between sample-weighted centering and unweighted MAGMA Average. Review strict >1 boundaries and extreme raw-value warnings; verify units before biological use. Correct named format, selection, integrity, numerical or capacity failures and rerun the complete request to a new directory. Native commands need no external runtime; unavailable/forbidden MAGMA must SKIP3 with its stated recovery. DEG memberships remain supplied and separate; no t-test, clustering or historical reconstruction is implied. Refresh stale FUMA catalog scope next using this source-role review, without inventing historical/full-paper equivalence as a tool-availability gate.')
write(DEST/'VALIDATION.json',proof)
with zipfile.ZipFile(DEST/'controls.zip') as archive:
    assert len(archive.infolist())==len(items)==len({e.filename for e in archive.infolist()})
    for n,v in proof['archive_files'].items():raw=archive.read(n);assert len(raw)==v['bytes'] and hashlib.sha256(raw).hexdigest()==v['sha256'],n
summary=read(ROOT/'docs/literature/omics-2023-2026/summary.json');assert summary['implementation_status_counts']['native-subset-validated']==14 and summary['implementation_status_counts']['upstream-adapter-validated']==48 and summary['implementation_status_counts']['missing']==258
write(RUN/'CHECKPOINT.json',dict(status=proof['status'],proof=DEST.relative_to(ROOT).as_posix()+'/VALIDATION.json',artifact=proof['artifact'],tests_per_JVM=148,affected_family_tests=663,independent_R_cases=16,independent_R_gene_rows=192,retained_R_raw_mean_overflow_fields=len(overflow),actual_original_MAGMA_genes=201,actual_original_MAGMA_tissues=3,paper_roles_reverified=14,goal_active=True,catalog_new_integrations=62,catalog_native=14,catalog_upstream_adapters=48,catalog_missing=258,Cell_Ranger='excluded-by-user',catalog_unchanged=True,next_work=roles['next_action'],publication='Local only; preserve all existing unrelated work; no new push/release authorization inferred.'))
print(json.dumps(dict(status=proof['status'],tests_per_JVM=148,affected_family_tests=663,finite_R_comparisons=finite,R_overflow_departures=len(overflow),actual_MAGMA_genes=201,artifact=matrix['artifact'],unchanged_prior_classes=proof['unchanged_prior_packaged_classes'],archive=proof['archive'],catalog_promoted=False)))
