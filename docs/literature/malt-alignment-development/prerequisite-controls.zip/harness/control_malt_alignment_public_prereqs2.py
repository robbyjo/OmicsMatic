"""Verify that missing/corrupt replay prerequisites produce no dependent analysis."""
from pathlib import Path
import hashlib,json,subprocess,sys,time
R=Path('D:/projects/JLinAlg');B=R/'build/literature-review/nfcore-runtime';O=B/'malt-alignment-public-prerequisite-controls-2';assert not O.exists();O.mkdir()
reader=B/'malt-rma-public-install-1';hts=B/'malt-alignment-htsjdk-intake-1/htsjdk-5.0.0.jar';bad=O/'bad-provider';bad.mkdir();(bad/'MALT.jar').write_bytes(b'not the pinned upstream jar\n');existing=O/'existing';existing.mkdir();(existing/'retain.txt').write_bytes(b'Retain existing output byte for byte.\n')
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
guards={str(p):pin(p) for p in [reader/'MALT.jar',reader/'data.jar',hts,existing/'retain.txt']};rows=[]
for name,code,args in [('missing-reader',3,['--reader-runtime',str(O/'missing-reader-provider'),'--htsjdk-jar',str(hts)]),('corrupt-reader',2,['--reader-runtime',str(bad),'--htsjdk-jar',str(hts)]),('missing-htsjdk',3,['--reader-runtime',str(reader),'--htsjdk-jar',str(O/'missing-dependency.jar')]),('existing',2,['--reader-runtime',str(reader),'--htsjdk-jar',str(hts)])]:
 target=O/name;command=[sys.executable,str(R/'tools/literature/verify_malt_alignment.py'),'--out',str(target),*args];p=subprocess.run(command,stdin=subprocess.DEVNULL,capture_output=True,timeout=90);(O/(name+'.stdout')).write_bytes(p.stdout);(O/(name+'.stderr')).write_bytes(p.stderr);assert p.returncode==code,(name,p.returncode)
 if name=='existing':assert sorted(x.name for x in existing.iterdir())==['retain.txt']
 else:
  doc=json.loads((target/'COMPLETED.json').read_bytes());assert doc['status'].startswith('SKIP3_' if code==3 else 'FAIL2_') and not (target/'build21').exists() and not (target/'bundles').exists() and 'Required action:' in (target/'WARNINGS.md').read_text()
 rows.append(dict(name=name,exit_code=code,command=command,dependent_compilation_or_analysis=False))
assert all(pin(Path(n))==v for n,v in guards.items());state=dict(status='PASS_FOUR_PUBLIC_MALT_ALIGNMENT_REPLAY_PREREQUISITE_INTEGRITY_AND_EXISTING_OUTPUT_CONTROLS_ONLY',results=rows,prerequisite_files_unchanged=True,whole_goal_complete=False);(O/'COMPLETED.json').write_text(json.dumps(state,indent=2)+'\n');print(state['status'],flush=True)
