# SKIP3_MALT_ALIGNMENT_REPLAY_MISSING_PREREQUISITES

Dependent complete replay skipped: Complete HTSJDK5.0.0 jar

Required action: restore the exact source/evidence checkout, provide the permitted exact MALT0.4.1 two-jar reader provider with --reader-runtime, JDK21/JDK25 and WSL Linux Java21, plus --htsjdk-jar or permitted --download-htsjdk. Retry a NEW output directory. If a prerequisite cannot be installed or used, skip this dependent replay/analysis. Retain all diagnostics. Replay checks captured software output consistency, not an alignment refit, producer authentication, full MALT/nf-core or biological result.
