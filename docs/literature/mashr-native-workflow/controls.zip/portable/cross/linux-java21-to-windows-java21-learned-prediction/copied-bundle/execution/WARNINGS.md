# Native mash development execution

DEVELOPMENT ONLY: native plain EM and explicit fully expanded models. PCA/extreme-deconvolution learning, public runtime/bundle admission and whole-paper reproduction are not provided by this executor.

- Feature gene-101: SYMMETRY_ROUNDOFF: residual covariance was symmetrized within the explicit tolerance.

- Feature gene-101: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000002 was normalized within the admitted1e-10 simplex tolerance.

- Feature gene-101: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than1.0E-10;full-mixture likelihoods retain all components.

- Feature gene-102: SYMMETRY_ROUNDOFF: residual covariance was symmetrized within the explicit tolerance.

- Feature gene-102: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000002 was normalized within the admitted1e-10 simplex tolerance.

- Feature gene-102: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than1.0E-10;full-mixture likelihoods retain all components.

- Feature gene-103: SYMMETRY_ROUNDOFF: residual covariance was symmetrized within the explicit tolerance.

- Feature gene-103: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000002 was normalized within the admitted1e-10 simplex tolerance.

- Feature gene-103: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than1.0E-10;full-mixture likelihoods retain all components.

- Feature gene-104: SYMMETRY_ROUNDOFF: residual covariance was symmetrized within the explicit tolerance.

- Feature gene-104: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000002 was normalized within the admitted1e-10 simplex tolerance.

- Feature gene-104: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than1.0E-10;full-mixture likelihoods retain all components.

- Feature gene-105: SYMMETRY_ROUNDOFF: residual covariance was symmetrized within the explicit tolerance.

- Feature gene-105: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000002 was normalized within the admitted1e-10 simplex tolerance.

- Feature gene-105: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than1.0E-10;full-mixture likelihoods retain all components.

- Feature gene-106: SYMMETRY_ROUNDOFF: residual covariance was symmetrized within the explicit tolerance.

- Feature gene-106: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000002 was normalized within the admitted1e-10 simplex tolerance.

- Feature gene-106: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than1.0E-10;full-mixture likelihoods retain all components.

- Feature gene-107: SYMMETRY_ROUNDOFF: residual covariance was symmetrized within the explicit tolerance.

- Feature gene-107: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000002 was normalized within the admitted1e-10 simplex tolerance.

- Feature gene-107: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than1.0E-10;full-mixture likelihoods retain all components.

- Feature gene-108: SYMMETRY_ROUNDOFF: residual covariance was symmetrized within the explicit tolerance.

- Feature gene-108: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000002 was normalized within the admitted1e-10 simplex tolerance.

- Feature gene-108: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than1.0E-10;full-mixture likelihoods retain all components.

- Feature gene-109: SYMMETRY_ROUNDOFF: residual covariance was symmetrized within the explicit tolerance.

- Feature gene-109: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000002 was normalized within the admitted1e-10 simplex tolerance.

- Feature gene-109: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than1.0E-10;full-mixture likelihoods retain all components.

- Feature gene-110: SYMMETRY_ROUNDOFF: residual covariance was symmetrized within the explicit tolerance.

- Feature gene-110: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000002 was normalized within the admitted1e-10 simplex tolerance.

- Feature gene-110: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than1.0E-10;full-mixture likelihoods retain all components.

- Feature gene-111: SYMMETRY_ROUNDOFF: residual covariance was symmetrized within the explicit tolerance.

- Feature gene-111: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000002 was normalized within the admitted1e-10 simplex tolerance.

- Feature gene-111: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than1.0E-10;full-mixture likelihoods retain all components.

- Feature gene-112: SYMMETRY_ROUNDOFF: residual covariance was symmetrized within the explicit tolerance.

- Feature gene-112: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000002 was normalized within the admitted1e-10 simplex tolerance.

- Feature gene-112: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than1.0E-10;full-mixture likelihoods retain all components.

- Feature gene-113: SYMMETRY_ROUNDOFF: residual covariance was symmetrized within the explicit tolerance.

- Feature gene-113: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000002 was normalized within the admitted1e-10 simplex tolerance.

- Feature gene-113: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than1.0E-10;full-mixture likelihoods retain all components.

- Feature gene-114: SYMMETRY_ROUNDOFF: residual covariance was symmetrized within the explicit tolerance.

- Feature gene-114: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000002 was normalized within the admitted1e-10 simplex tolerance.

- Feature gene-114: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than1.0E-10;full-mixture likelihoods retain all components.

- Feature gene-115: SYMMETRY_ROUNDOFF: residual covariance was symmetrized within the explicit tolerance.

- Feature gene-115: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000002 was normalized within the admitted1e-10 simplex tolerance.

- Feature gene-115: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than1.0E-10;full-mixture likelihoods retain all components.

- Feature gene-116: SYMMETRY_ROUNDOFF: residual covariance was symmetrized within the explicit tolerance.

- Feature gene-116: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000002 was normalized within the admitted1e-10 simplex tolerance.

- Feature gene-116: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than1.0E-10;full-mixture likelihoods retain all components.

- Feature gene-117: SYMMETRY_ROUNDOFF: residual covariance was symmetrized within the explicit tolerance.

- Feature gene-117: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000002 was normalized within the admitted1e-10 simplex tolerance.

- Feature gene-117: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than1.0E-10;full-mixture likelihoods retain all components.

- Feature gene-118: SYMMETRY_ROUNDOFF: residual covariance was symmetrized within the explicit tolerance.

- Feature gene-118: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000002 was normalized within the admitted1e-10 simplex tolerance.

- Feature gene-118: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than1.0E-10;full-mixture likelihoods retain all components.

- Feature gene-119: SYMMETRY_ROUNDOFF: residual covariance was symmetrized within the explicit tolerance.

- Feature gene-119: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000002 was normalized within the admitted1e-10 simplex tolerance.

- Feature gene-119: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than1.0E-10;full-mixture likelihoods retain all components.

- Feature gene-120: SYMMETRY_ROUNDOFF: residual covariance was symmetrized within the explicit tolerance.

- Feature gene-120: PROPORTION_ROUNDOFF: supplied sum=1.0000000000000002 was normalized within the admitted1e-10 simplex tolerance.

- Feature gene-120: PRIOR_PRUNING: posterior summaries use only proportions strictly greater than1.0E-10;full-mixture likelihoods retain all components.
