# Native mash development execution

DEVELOPMENT ONLY: native plain EM and explicit fully expanded models. PCA/extreme-deconvolution learning, public runtime/bundle admission and whole-paper reproduction are not provided by this executor.

## FAIL2: analysis incomplete

Require positive finite SE; no missingness or zero filling is inferred

Required action: preserve this output and its partial diagnostics. Correct the named input, numerical, convergence or capacity failure; increase only permitted limits if necessary. Retry into a NEW output directory. No partial analysis is complete.
