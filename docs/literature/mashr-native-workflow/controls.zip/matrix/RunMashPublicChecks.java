import java.io.File;
import java.io.PrintWriter;
import org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder;
import org.junit.platform.launcher.core.LauncherFactory;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;
public final class RunMashPublicChecks {
 private RunMashPublicChecks() { }
 public static void main(String[] args) throws Exception {
  System.out.println("java.version="+System.getProperty("java.version"));System.out.println("os.name="+System.getProperty("os.name"));
  if(!System.getProperty("java.specification.version").equals(args[1]))throw new AssertionError("Wrong JVM edition");
  for(String name:new String[]{"org.jlinalg.cli.JLinAlgCli","org.jlinalg.cli.MashToolsCli","org.jlinalg.cli.MashBundle","org.jlinalg.cli.MashLimits","org.jlinalg.cli.MashFiles","org.jlinalg.cli.MashJson","org.jlinalg.cli.MashNativeExecution","org.jlinalg.shrinkage.MashFit","jdistlib.accelerator.CpuComputeBackend"})
   if(!Class.forName(name).getProtectionDomain().getCodeSource().getLocation().toURI().equals(new File(args[0]).toURI()))throw new AssertionError("Wrong actual artifact: "+name);
  var listener=new SummaryGeneratingListener();LauncherFactory.create().execute(LauncherDiscoveryRequestBuilder.request().selectors(selectClass("org.jlinalg.shrinkage.MashGaussianTest"),selectClass("org.jlinalg.shrinkage.MashGaussianOriginalTest"),selectClass("org.jlinalg.shrinkage.MashMixtureWeightsTest"),selectClass("org.jlinalg.shrinkage.MashMixtureWeightsOriginalTest"),selectClass("org.jlinalg.shrinkage.MashFitTest"),selectClass("org.jlinalg.cli.MashWorkflowAuditTest"),selectClass("org.jlinalg.cli.MashNativeExecutionTest"),selectClass("org.jlinalg.cli.MashToolsCliTest")).build(),listener);var summary=listener.getSummary();
  summary.printTo(new PrintWriter(System.out));summary.printFailuresTo(new PrintWriter(System.out));
  if(summary.getTestsFoundCount()!=325||summary.getTestsSucceededCount()!=325||summary.getTestsSkippedCount()!=0||summary.getTestsAbortedCount()!=0||summary.getTestsFailedCount()!=0||summary.getContainersFailedCount()!=0)throw new AssertionError("Incomplete public native mash validation");
 }
}
