# FAIL2: checkpoint not closed

[]

Required action: preserve this attempt. Inspect the named mismatch and resolve it before producing new proof; do not refresh old hashes to imply new validation.
