import java.io.File;
import java.io.PrintWriter;
import org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder;
import org.junit.platform.launcher.core.LauncherFactory;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;
public final class RunMashExecutionChecks {
 private RunMashExecutionChecks() { }
 public static void main(String[] args) throws Exception {
  System.out.println("java.version="+System.getProperty("java.version"));
  System.out.println("os.name="+System.getProperty("os.name"));
  if(!System.getProperty("java.specification.version").equals(args[1]))throw new AssertionError("Wrong JVM edition");
  for(String name:new String[]{"org.jlinalg.cli.MashNativeExecution","org.jlinalg.cli.MashWorkflowAudit","org.jlinalg.shrinkage.MashFit","org.jlinalg.shrinkage.MashGaussian","org.jlinalg.shrinkage.MashMixtureWeights","jdistlib.accelerator.CpuComputeBackend"})
   if(!Class.forName(name).getProtectionDomain().getCodeSource().getLocation().toURI().equals(new File(args[0]).toURI()))throw new AssertionError("Wrong artifact loaded: "+name);
  var request=LauncherDiscoveryRequestBuilder.request().selectors(selectClass("org.jlinalg.shrinkage.MashGaussianTest"),selectClass("org.jlinalg.shrinkage.MashGaussianOriginalTest"),selectClass("org.jlinalg.shrinkage.MashMixtureWeightsTest"),selectClass("org.jlinalg.shrinkage.MashMixtureWeightsOriginalTest"),selectClass("org.jlinalg.shrinkage.MashFitTest"),selectClass("org.jlinalg.cli.MashWorkflowAuditTest"),selectClass("org.jlinalg.cli.MashNativeExecutionTest")).build();var listener=new SummaryGeneratingListener();
  LauncherFactory.create().execute(request,listener);var summary=listener.getSummary();
  summary.printTo(new PrintWriter(System.out));summary.printFailuresTo(new PrintWriter(System.out));
  if(summary.getTestsFoundCount()!=295||summary.getTestsSucceededCount()!=295||summary.getTestsSkippedCount()!=0||summary.getTestsAbortedCount()!=0||summary.getTestsFailedCount()!=0||summary.getContainersFailedCount()!=0)throw new AssertionError("Incomplete native execution matrix");
 }
}
