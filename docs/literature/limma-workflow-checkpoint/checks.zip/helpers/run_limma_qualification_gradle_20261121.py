from pathlib import Path
import ast,sys
R=Path('D:/projects/JLinAlg');source=(R/'build/run_limma_workflow_gradle_20261121.py').read_text(encoding='utf-8')
source=source.replace("T=R/'build/lm-3';B=T/'build/limma-workflows-1'","T=R/'build/lm-4';B=T/'build/limma-qualification-1'")
if len(sys.argv)>2 and sys.argv[2]=='producer':
    old="'limmaQualificationClasspath','executableJar',':test','--tests','org.jlinalg.cli.LimmaWorkflowTest'"
    assert old in source;source=source.replace(old,"'limmaQualificationClasspath','executableJar'")
ast.parse(source);exec(compile(source,__file__,'exec'))
