from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
R=Path('D:/projects/JLinAlg');T=R/'build/lm-4';B=T/'build/limma-qualification-1';kind=sys.argv[1];assert kind in ['legacy','fixed'];O=B/('observer-'+kind+'-1');O.mkdir()
script=R/'build/limma_observer_control_20261121.R';worker=(R/'build/lm-3' if kind=='legacy' else T)/'src/main/resources/org/jlinalg/omics/limma_workflow.R'
libs=R/'build/literature-review/monocle-runtime/idep244-adopted-provider-4/libraries-requested.txt'
for p in [script,worker,libs]:shutil.copyfile(p,O/p.name)
command=['C:/Program Files/R/R-4.6.1/bin/Rscript.exe','--vanilla',str(script),str(worker),str(libs),str(O),kind]
env={k:v for k,v in os.environ.items() if not k.startswith('R_LIBS') and k not in ['R_PROFILE','R_PROFILE_USER','R_ENVIRON','R_ENVIRON_USER','R_DEFAULT_PACKAGES','R_TESTS','LANG','LANGUAGE'] and not k.startswith('LC_')};env.update(LANG='C',LC_ALL='C',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
with (O/'stdout').open('xb') as stdout,(O/'stderr').open('xb') as stderr:p=subprocess.run(command,cwd=O,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=90)
result=json.loads((O/'RESULTS.json').read_bytes()) if (O/'RESULTS.json').exists() else None
(O/'PROCESS.json').write_text(json.dumps(dict(command=command,exit_code=p.returncode,source_worker_sha256=hashlib.sha256(worker.read_bytes()).hexdigest()),indent=2)+'\n',encoding='utf-8')
print('Observer control',kind,'exit',p.returncode,json.dumps(result) if result else (O/'stderr').read_text(errors='replace'),flush=True)
assert p.returncode==0
