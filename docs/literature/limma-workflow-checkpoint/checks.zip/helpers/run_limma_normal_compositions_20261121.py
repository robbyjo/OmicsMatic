from pathlib import Path
import concurrent.futures,csv,hashlib,io,json,random,subprocess,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/lm-4';B=T/'build/limma-qualification-1';O=B/'normal-originals-1';O.mkdir()
J='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe';jar=B/'normal-gradle-1/project-build/cli/omicsmatic-0.4.0.jar'
assert json.loads((B/'normal-gradle-1/COMPLETED.json').read_bytes())['exit_code']==0
prior=R/'build/lm-3/src/test/resources/org/jlinalg/cli/limma-workflow-originals.zip'
with zipfile.ZipFile(prior) as z:
    metadata=json.loads(z.read('FIXTURE.json'));cases=metadata['cases'];assert len(cases)==45
    for name,c in cases.items():
        folder=O/name;folder.mkdir()
        for key,pin in c['files'].items():
            if not key.startswith('inputs/') and key!='request.json':continue
            raw=z.read('blobs/'+pin['sha256']);assert len(raw)==pin['bytes'] and hashlib.sha256(raw).hexdigest()==pin['sha256'];target=folder/key;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
        request=json.loads((folder/'request.json').read_bytes());(folder/'prior-captured-request.json').write_bytes((folder/'request.json').read_bytes());request['out']=str(folder/'analysis')
        (folder/'request.json').write_text(json.dumps(request,indent=2)+'\n',encoding='utf-8',newline='\n')
folder=O/'TINY_POSITIVE_P';folder.mkdir();base=json.loads((O/'LM/request.json').read_bytes())
for key in ['matrix','design']:
    original=O/'LM'/base[key];target=folder/Path(base[key]);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(original.read_bytes())
base['out']=str(folder/'analysis');matrix=folder/base['matrix'];rows=list(csv.reader(io.StringIO(matrix.read_text(encoding='utf-8')),delimiter='\t'));design=list(csv.reader(io.StringIO((folder/base['design']).read_text(encoding='utf-8')),delimiter='\t'));rng=random.Random(731)
data=[rows[0]]
for i,row in enumerate(rows[1:]):data.append([row[0],*[5+(.9 if i%4==0 and float(design[j+1][2]) else 0)+rng.gauss(0,.1) for j in range(len(row)-1)]])
with matrix.open('w',encoding='utf-8',newline='') as f:csv.writer(f,delimiter='\t',lineterminator='\n',quoting=csv.QUOTE_NONE).writerows(data)
(folder/'request.json').write_text(json.dumps(base,indent=2)+'\n',encoding='utf-8',newline='\n')
def run(folder):
    result={}
    for mode,args in [('RUN',['--request',str(folder/'request.json')]),('VERIFY',['--verify',str(folder/'analysis')])]:
        cmd=[J,'-cp',str(jar),'org.jlinalg.cli.LimmaWorkflowCli',*args]
        with (folder/(mode+'.stdout')).open('xb') as stdout,(folder/(mode+'.stderr')).open('xb') as stderr:p=subprocess.run(cmd,cwd=T,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=180)
        result[mode]=dict(exit_code=p.returncode,command=cmd);print(folder.name,mode,p.returncode,flush=True)
        if p.returncode:print((folder/(mode+'.stderr')).read_text(errors='replace')[:600],flush=True);break
    (folder/'PROCESS.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n');return folder.name,result
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=dict(pool.map(run,sorted(p for p in O.iterdir() if p.is_dir())))
(O/'RESULTS.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8',newline='\n')
assert len(results)==46 and all(set(v)=={'RUN','VERIFY'} and all(x['exit_code']==0 for x in v.values()) for v in results.values())
tiny={}
for name in ['pvalue','padjust']:
    values=[float(v) for row in (O/'TINY_POSITIVE_P/analysis/results'/ (name+'.tsv')).read_text(encoding='utf-8').splitlines()[1:] for v in row.split('\t')[1:]];positive=[v for v in values if v>0];tiny[name]=dict(minimum_positive=min(positive),zero_count=values.count(0));assert 0<min(positive)<1e-12
(O/'TINY-POSITIVE.json').write_text(json.dumps(tiny,indent=2)+'\n',encoding='utf-8',newline='\n');print('PASS46_NORMAL_ORIGINAL_COMPOSITIONS',json.dumps(tiny),flush=True)
