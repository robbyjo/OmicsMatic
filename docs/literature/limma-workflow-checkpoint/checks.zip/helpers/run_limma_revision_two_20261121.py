from pathlib import Path
import ast,sys
R=Path('D:/projects/JLinAlg');step=sys.argv[1]
plain={
 'originals':('run_limma_normal_compositions_20261121.py',{'normal-originals-1':'normal-originals-2','normal-gradle-1':'normal-gradle-3'}),
 'fixtures':('package_limma_normal_fixtures_20261121.py',{'direct-originals-1':'direct-originals-2','normal-originals-1':'normal-originals-2','saved-fixture-1':'saved-fixture-2','39311c24e7a7f14cfe84fe06e9c81afe5515c90776b466becd22499c5d160255':'31a327fb9837597fa217c167372ac308e4686eae72251bc07fcf97effb309c7e','prior-45-originals.zip':'prior-46-revision-one-originals.zip',"R/'build/lm-3/src/test/java/org/jlinalg/cli/LimmaWorkflowTest.java'":"B/'normal-gradle-2/sources/src/test/java/org/jlinalg/cli/LimmaWorkflowTest.java'"}),
 'replays':('run_limma_replays_20261121.py',{'normal-gradle-1':'normal-gradle-3','normal-originals-1':'normal-originals-2','normal-replays-1':'normal-replays-2'}),
 'process':('run_limma_process_controls_20261121.py',{'normal-gradle-1':'normal-gradle-3','normal-originals-1':'normal-originals-2','process-controls-1':'process-controls-2'}),
 'failures':('run_limma_numerical_failures_20261121.py',{'normal-gradle-2':'normal-gradle-4','normal-originals-1':'normal-originals-2','original-failures-2':'original-failures-3'}),
 'packaged':('run_packaged_limma_workflows_20261121.py',{"G=B/'normal-gradle-2'":"G=B/'normal-gradle-4'","O=B/'packaged-tests-1'":"O=B/'packaged-tests-2'","B/'normal-gradle-1/":"B/'normal-gradle-3/"}),
}
if step=='direct':
    source=(R/'build/compare_limma_normal_originals_20261121.py').read_text(encoding='utf-8');old="ast.parse(source);exec(compile(source,__file__,'exec'))";new="source=source.replace('normal-originals-1','normal-originals-2').replace('direct-originals-1','direct-originals-2')\n"+old;assert source.count(old)==1;source=source.replace(old,new)
elif step=='examples':
    source=(R/'build/prepare_limma_examples_20261121.py').read_text(encoding='utf-8');start=source.index("for name in ['LM'");end=source.index("O=B/'executed-examples-1'");source=source[:start]+source[end:]
    for old,new in {'normal-gradle-2':'normal-gradle-4','normal-originals-1':'normal-originals-2','executed-examples-1':'executed-examples-3',"'examples.stdout'":"'examples-3.stdout'","'examples.stderr'":"'examples-3.stderr'","'EXAMPLES-COMPARISON.json'":"'EXAMPLES-COMPARISON-3.json'"}.items():source=source.replace(old,new)
else:
    name,replacements=plain[step];source=(R/'build'/name).read_text(encoding='utf-8')
    for old,new in replacements.items():assert old in source,old;source=source.replace(old,new)
ast.parse(source);exec(compile(source,__file__,'exec'))
