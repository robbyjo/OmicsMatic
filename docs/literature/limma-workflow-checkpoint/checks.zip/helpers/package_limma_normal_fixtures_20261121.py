from pathlib import Path
import hashlib,json,shutil,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/lm-4';B=T/'build/limma-qualification-1';O=B/'saved-fixture-1';O.mkdir()
direct=json.loads((B/'direct-originals-1/RESULTS.json').read_bytes());assert len(direct)==46
for name,row in direct.items():
    assert row['exit_code']==0 and row['result']['tolerance']==0 and not row['result']['adapter_worker_sourced'],name
    assert all(c['identical'] and c['all_equal'] for c in row['result']['comparisons'].values()),name
sources={p.name:p/'analysis' for p in (B/'normal-originals-1').iterdir() if p.is_dir()};assert len(sources)==46
blobs={};cases={}
for name,root in sorted(sources.items()):
    assert json.loads((root/'analysis-status.json').read_bytes())['results_admitted'];files={}
    for path in sorted(root.rglob('*')):
        if not path.is_file():continue
        raw=path.read_bytes();sha=hashlib.sha256(raw).hexdigest();assert sha not in blobs or blobs[sha]==raw;blobs[sha]=raw;files[path.relative_to(root).as_posix()]=dict(bytes=len(raw),sha256=sha)
    cases[name]=dict(files=files,operation=json.loads((root/'request.json').read_bytes())['operation'])
fixture=dict(schema_version=1,status='SYNTHETIC_NORMAL_JAR_ORIGINAL_WORKFLOW_CAPTURES_FOR_OFFLINE_VERIFICATION',case_count=46,cases=cases,qualifies_only_saved_fixture_replay_and_arithmetic=True,original_runtime_analysis_tested_separately=True,whole_tool_or_paper_qualification=False)
archive=T/'src/test/resources/org/jlinalg/cli/limma-workflow-originals.zip';old=archive.read_bytes();assert hashlib.sha256(old).hexdigest()=='39311c24e7a7f14cfe84fe06e9c81afe5515c90776b466becd22499c5d160255'
(O/'prior-45-originals.zip').write_bytes(old);shutil.copyfile(R/'build/lm-3/src/test/java/org/jlinalg/cli/LimmaWorkflowTest.java',O/'prior-LimmaWorkflowTest.java')
target=O/'new-46-originals.zip'
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED) as z:
    z.writestr('FIXTURE.json',json.dumps(fixture,indent=2)+'\n')
    for sha,raw in sorted(blobs.items()):z.writestr('blobs/'+sha,raw)
shutil.copyfile(target,archive)
with (O/'COMPLETED.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(dict(status='SAVED_46_FRESH_NORMAL_JAR_ORIGINAL_CAPTURES',cases=46,unique_blobs=len(blobs),logical_files=sum(len(c['files']) for c in cases.values()),archive=dict(bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest()),prior_archive_retained=True,old_scientific_source_hashes_overlaid=False),f,indent=2);f.write('\n')
print((O/'COMPLETED.json').read_text(),flush=True)
