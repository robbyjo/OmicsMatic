from pathlib import Path
import json,subprocess
R=Path('D:/projects/JLinAlg');T=R/'build/lm-4';BASE='f4cb923d6b5d3968cb25309e29d9608590b005f6'
assert not T.exists()
assert subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],cwd=R).decode().split()[0]==BASE
subprocess.run(['git','worktree','add','-b','codex/limma-qualification-20261121',str(T),BASE],cwd=R,check=True)
B=T/'build/limma-qualification-1';B.mkdir(parents=True)
(B/'START.json').write_text(json.dumps(dict(base=BASE,previous_goal_turn='progress',previous_evidence='Verified 54 public files, 69 focused tests, 33 worktrees and 666073 protected artifacts; saved handover without claiming full completion',task='Complete limma execution qualification using fresh original-runtime captures',whole_goal_complete=False),indent=2)+'\n',encoding='utf-8')
print('Created',T,flush=True)
