from pathlib import Path
import hashlib,json,shutil,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/lm-4';B=T/'build/limma-qualification-1';Q=T/'docs/literature/limma-workflow-checkpoint';Q.mkdir()
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
normal=json.loads((B/'normal-gradle-2/COMPLETED.json').read_bytes());assert normal['exit_code']==0 and normal['reports']['org.jlinalg.cli.LimmaWorkflowTest']['tests']==72
packaged=json.loads((B/'packaged-tests-1/COMPLETED.json').read_bytes());assert packaged['tests_per_JVM']==72 and len(packaged['hosts'])==3
direct=json.loads((B/'direct-originals-1/RESULTS.json').read_bytes());assert len(direct)==46
comparisons=0
for name,row in direct.items():
    assert row['exit_code']==0 and row['result']['tolerance']==0 and not row['result']['adapter_worker_sourced']
    for c in row['result']['comparisons'].values():assert c['identical'] and c['all_equal'];comparisons+=1
assert comparisons==169
observer=json.loads((B/'observer-fixed-1/RESULTS.json').read_bytes());assert len(observer['cases'])==7 and all(c['complete_return_identical'] for c in observer['cases'].values())
replays=json.loads((B/'normal-replays-1/COMPLETED.json').read_bytes());assert len(replays['results'])==8
process=json.loads((B/'process-controls-1/COMPLETED.json').read_bytes());assert len(process['results'])==4 and len(process['results']['timeout-owned-child']['owned_PIDs_confirmed_stopped'])==2
failures=json.loads((B/'original-failures-2/COMPLETED.json').read_bytes());assert len(failures['cases'])==2
catalog=json.loads((B/'fresh-catalog-1/COMPLETED.json').read_bytes());assert catalog['fresh_source_audit_performed'] and catalog['current_manifest']['entries']==829 and catalog['result']['integrations']==141
examples=json.loads((B/'EXAMPLES-COMPARISON-2.json').read_bytes());assert len(examples['cases'])==6
jar=Path(packaged['jar_path']);assert pin(jar.read_bytes())==packaged['jar']
source_names=['src/main/resources/org/jlinalg/omics/limma_workflow.R','src/test/java/org/jlinalg/cli/LimmaWorkflowTest.java','src/test/resources/org/jlinalg/cli/limma-workflow-originals.zip','tools/literature/verify_limma_workflow_checkpoint.py','docs/literature/LIMMA_WORKFLOWS.md']
for folder in ['src/main/resources/org/jlinalg/omics/limma-workflow','tools/literature/limma_workflow','examples/limma-workflows']:
    source_names+=sorted(p.relative_to(T).as_posix() for p in (T/folder).rglob('*') if p.is_file())
source_names+=sorted(p.relative_to(T).as_posix() for p in (T/'src/main/java/org/jlinalg/cli').glob('LimmaWorkflow*.java'))
for n,w in normal['source_inputs'].items():assert pin((T/n).read_bytes())==w,n
files={}
def add(p,name):assert name not in files;files[name]=p.read_bytes()
for folder in ['observer-legacy-1','observer-fixed-1','direct-originals-1','process-controls-1','original-failures-1','original-failures-2']:
    for p in sorted((B/folder).rglob('*')):
        if p.is_file() and p.suffix.lower()!='.exe':add(p,'evidence/'+folder+'/'+p.relative_to(B/folder).as_posix())
for folder in ['normal-gradle-1','normal-gradle-2']:
    for name in ['COMMAND.json','COMPLETED.json','stdout','stderr']:add(B/folder/name,'evidence/'+folder+'/'+name)
for name in ['normal-originals-1/RESULTS.json','normal-originals-1/TINY-POSITIVE.json','normal-replays-1/COMPLETED.json','packaged-tests-1/COMPLETED.json','packaged-tests-1/PAYLOADS.json','saved-fixture-1/COMPLETED.json','fresh-catalog-1/COMPLETED.json','EXAMPLES-COMPARISON-2.json','executed-examples-2/COMPLETED.json','examples-2.stdout','examples-2.stderr']:add(B/name,'evidence/'+name)
for host in ['windows21','windows25','linux21']:
    for suffix in ['.PROCESS.json','.stdout','.stderr']:add(B/'packaged-tests-1'/(host+suffix),'evidence/packaged-tests-1/'+host+suffix)
helpers=['start_limma_qualification_20261121.py','limma_observer_control_20261121.R','run_limma_observer_controls_20261121.py','run_limma_qualification_gradle_20261121.py','run_limma_workflow_gradle_20261121.py','run_limma_normal_compositions_20261121.py','compare_limma_normal_originals_20261121.py','compare_limma_direct_originals_20261121.py','package_limma_normal_fixtures_20261121.py','run_limma_replays_20261121.py','run_packaged_limma_workflows_20261121.py','run_limma_process_controls_20261121.py','prepare_limma_examples_20261121.py','rerun_current_limma_examples_20261121.py','run_limma_numerical_failures_20261121.py','package_limma_qualification_checkpoint_20261121.py']
for name in helpers:add(R/'build'/name,'helpers/'+name)
archive=Q/'checks.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for name,raw in sorted(files.items()):z.writestr(name,raw)
save(Q/'INVENTORY.json',dict(schema_version=1,files={n:pin(v) for n,v in sorted(files.items())},synthetic_scientific_objects=True,private_runtime_binaries_included=False,primary_paper_full_text_included=False))
checks=dict(schema_version=1,status='SAVED_NORMAL_JAR_LIMMA_EXECUTION_QUALIFICATION',source_inputs={n:pin((T/n).read_bytes()) for n in source_names},archive=pin(archive.read_bytes()),inventory=pin((Q/'INVENTORY.json').read_bytes()),producer=packaged['jar'],producer_path=packaged['jar_path'],original_compositions=46,original_object_comparisons=comparisons,packaged_tests_per_JVM=72,test_JVMs=3,actual_replays=8,observer_controls=7,transport_controls=4,original_failure_capsules=2,executed_public_examples=6,old_JAR_payloads_unchanged=23567,intentional_changed_payload='org/jlinalg/omics/limma_workflow.R',original_R_execution_host='Windows R4.6.1',Linux_original_R_execution=False,Linux_independent_compilation=False,new_catalog_credit=0,whole_goal_complete=False)
save(Q/'CHECKS.json',checks)
checkpoint=f'''# Limma normal-JAR execution checkpoint, 21 November 2026

**Current prepared-data execution controls pass; global registration,
paper-source/catalog admission and older author editions remain open.**
The full 250-paper goal is unfinished. No family or reviewed-use credit is added:
totals remain **141 families (26 native +115 upstream), 1,575 reviewed uses and
1,140 pending**, with 2,715 observations and 829 manifest entries.

Read the [workflow guide](LIMMA_WORKFLOWS.md),
[executed examples](../../examples/limma-workflows/README.md) and
[saved packet](limma-workflow-checkpoint/README.md).

## What changed and why

The statmod observer previously masked an original positive-definiteness error
with an observer metric-shape error when the original iteration failed before
creating all locals. A journal write failure could also replace a successful
return. Both were reproduced using the actual statmod1.5.2 function, preserving
the original return/error and namespace as reference.

The observer now captures incomplete locals without deriving missing metrics,
retains the original diagnostic and records observation failures separately.
Observation failures still force the enclosing workflow to refuse completion.
The original statistical function body/formals and namespace remain unchanged;
the observational prefix has an exact AST inverse. Seven actual original-runtime
controls cover incomplete iterations, negative input, empty/zero returns,
ordinary convergence and journal failures during original error/success.
All seven preserve the complete original return/error exactly.

All **46 execution captures were rerun into fresh output** with the normal JAR
and corrected worker. The earlier 45 captures, failed attempts, original worker,
fixture and producer remain preserved. No prior scientific source hash was
overlaid. A genuine tiny-positive control now reaches P=6.89e-66 and adjusted
P=1.24e-63, with no underflowed zeros; resealed replacement by zero is refused.
The historical `SMALL_P` fixture retains its original underflowed zero.

## Evidence and precise limits

| Check | Result |
| --- | --- |
| Normal-JAR original RUN + separate VERIFY | 46/46 |
| Independent stock complete-object comparisons | 169/169 identical, tolerance0 |
| Packaged R-free tests per JVM | 72/72 on Windows21, Windows25 and Linux21 |
| Real original-R REPLAY + VERIFY | 8/8; all parent files and exports unchanged |
| Process/dependency controls | Timeout, byte cap, zero-exit missing status and missing runtime refused/skipped correctly |
| Owned timeout process tree | Parent and child both independently confirmed stopped |
| Actual original-R invalid models | Nonestimable zero-weight row and rank-deficient design retain original objects and FAIL2; VERIFY refuses |
| Public runnable examples | Six executed; exported bytes match original controls |
| Predecessor JAR payloads unchanged | 23,567; only the worker R payload intentionally changed |
| Current catalog | Fresh all250 source audit, 829 clean manifest entries; no new credit |

Independent reference code does not source the adapter worker. It computes the
original pipeline first, then compares complete lmFit/voom/edgeR/moderation/
adjustment/normalization/batch/camera returns, including attributes. Source
conditions, original objects, null/partial/failed results and warnings remain
retained. The process timeout and zero-exit controls use an explicitly labeled
fault-injection helper, not a substitute original statistical runtime.

The normal producer is **{packaged['jar']['bytes']:,} bytes**, SHA-256
`{packaged['jar']['sha256']}`. It targets Java17. Packaged tests load scientific
classes and the worker from this JAR first. The producer-only and focused-test
builds have identical JAR bytes. Linux tests execute transferred Java17 classes;
Linux has no Rscript/javac in the inspected environment. No original-R Linux
fit or independent Linux compilation is claimed. Installation remains permitted
where the environment allows; absence is not an installation prohibition.

R-free VERIFY checks saved integrity, literal intake, structure and selected
exported-statistic arithmetic. It does not independently refit models, decode
RDS/journal model contents, derive every F/B output or authenticate coordinated
replacement. Source/model controls do not establish biological reproduction,
an older author edition, full-tool support or whole-paper qualification.

The sample-weight branch was inspected in original edgeR4.10.7 voomLmFit:
it supplies observational weights to limma arrayWeights, selecting the
gene-by-gene update algorithm rather than the separate iterative REML branch.
Actual sample-weight complete returns match stock originals. Other arrayWeights
entry points are outside this interface and do not inherit this result.

## Remaining work in priority order

1. Add discoverable global CLI registration and qualify routing/help compatibility
   while preserving existing method-overlap APIs and earlier source guards.
2. Resolve the 20 primary-paper source-role proposals, including P088/P183/P203,
   P059's reimplementation distinction, unresolved P228 attribution and explicit
   edgeR-only P237. Keep exact older editions separate; then perform guarded
   catalog admission, source inverses, manifest and report checks.
3. Extend genuinely required scopes/editions from that audit. Current dense
   prepared-data operations do not supply sparse/raw-read workflows, offset
   matrices, quality-weighted voom, robust regression or every F/B audit.
4. Continue higher-impact **PEER, then TwoSampleMR**, and the remaining 1,140
   source-use reviews and missing tools. Keep the original full goal intact.

## Warnings, preservation and resume paths

**SKIP3: DEPENDENT ANALYSIS SKIPPED.** Supply the named exact permitted runtime,
package, input or source and retry new output, or retain the skip. An unknown
profile may skip before creating output; read stderr. **FAIL2: NO COMPLETE
RESULT.** Preserve original inputs, models, partials, warnings and failed
attempts; fix the named numerical/design/integrity/capacity/process cause and
retry new output. Never silently repair identities, counts, versions, thresholds,
populations or estimators, clamp valid unconstrained components, or relabel
unfinished work as an executed skip. See the guide for exact status/log paths.

Preserve all **34 worktrees**. The prior `build/lm-3` handover remains immutable
at `f4cb923d`; its source-pin reader requires that version. Current source-byte
checks use the new packet, not refreshed hashes in the old packet.
The first original-failure harness looked for `status.tsv` instead of the
actual `worker-status.tsv`; its scientific failure capsule and exact harness
remain retained, followed by two fresh correctly inspected failure captures.

Current checkout: `D:/projects/JLinAlg/build/lm-4`, branch
`codex/limma-qualification-20261121`; private stage `build/limma-qualification-1`.
Keep every subdirectory, including observer legacy/fixed controls, all normal
originals, direct references, replays, process controls, both original-failure
attempts, saved fixtures, both builds, packaged tests and both example runs.
Primary role paragraphs remain in the earlier `build/lm-1` intake; proposals
are tracked. Publication receipts will be in
`D:/projects/JLinAlg/build/git-publish/20261121-limma-qualification-78`.

**Transfer ignored exact runtimes, producer JARs, primary full text and complete
private evidence separately with checksums before changing machines. GitHub is
not a complete backup.** Both literature HTML reports remain withheld from
Pages. No release or full-goal completion is claimed.
'''
(T/'docs/literature/LIMMA_WORKFLOW_QUALIFICATION_2026-11-21.md').write_text(checkpoint,encoding='utf-8',newline='\n')
(Q/'README.md').write_text('''# Saved normal-JAR limma execution qualification

Read the [checkpoint](../LIMMA_WORKFLOW_QUALIFICATION_2026-11-21.md) for precise
scope, remaining work and warnings. Run
`python -B tools/literature/verify_limma_workflow_checkpoint.py` from the repo
root to check current source, archive, inventory and every saved file without R.
This performs no new scientific fit or original namespace execution.

The archive includes exact legacy/fixed observer controls, original successful
and failed synthetic R objects, independent direct-stock reference objects,
process controls, build/packaged-test receipts and source helpers. The 46 complete
new captures are in the separately pinned test fixture ZIP. Installed runtimes,
primary paper full text and complete private working directories remain local.
Fault-injection transport helpers are clearly identified; their executables are
omitted. The first failure-harness filename assertion is retained as history.

Helpers have exact historical Windows paths and exclusive output directories.
They are provenance, not idempotent installers: inspect dependencies and use new
attempt paths before rerunning. A current saved-byte pass adds no catalog credit
and does not qualify earlier editions, every model output, whole tools or papers.
''',encoding='utf-8',newline='\n')
current=T/'docs/literature/HANDOVER_CURRENT.md';text=current.read_text(encoding='utf-8');prefix='# Current toolbox handover\n\n';assert text.startswith(prefix)
top='''**Current: [limma normal-JAR execution qualification and remaining work](LIMMA_WORKFLOW_QUALIFICATION_2026-11-21.md).**
The observer now preserves original errors/returns even with incomplete locals
or failed journal writes. Forty-six fresh normal-JAR analyses match 169 complete
stock-original returns exactly; all 72 packaged tests pass per JVM on Windows21/25
and Linux21. Eight actual replays preserve parent files and exports; owned timeout
parent/child cleanup, invalid-original-model failures and six executed examples
pass. Global registration, source-role/catalog admission and older editions remain
open. Totals stay **141 families, 1,575 reviewed uses and 1,140 pending**.
Preserve all **34 worktrees** and separately transfer ignored runtimes, exact
JARs, primary full text and complete private evidence. Both reports stay off Pages.
The full goal remains active and unfinished; lower entries retain history.

'''
current.write_text(prefix+top+text[len(prefix):],encoding='utf-8',newline='\n')
print(json.dumps({k:v for k,v in checks.items() if k not in ['source_inputs']},indent=2),flush=True)
