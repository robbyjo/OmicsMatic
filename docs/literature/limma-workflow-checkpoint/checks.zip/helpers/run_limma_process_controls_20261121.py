from pathlib import Path
import ctypes,hashlib,json,shutil,subprocess
R=Path('D:/projects/JLinAlg');T=R/'build/lm-4';B=T/'build/limma-qualification-1';O=B/'process-controls-1';O.mkdir();jar=B/'normal-gradle-1/project-build/cli/omicsmatic-0.4.0.jar';J='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe'
source='''using System; using System.Diagnostics; using System.IO; using System.Threading;
class FaultRuntime { static int Main(string[] args) {
 if(args.Length>0 && args[0]=="--owned-child") { Thread.Sleep(60000); return 0; }
 string self=Process.GetCurrentProcess().MainModule.FileName;
 if(Path.GetFileName(self).StartsWith("Zero")) return 0;
 var start=new ProcessStartInfo(self,"--owned-child");start.UseShellExecute=false;start.CreateNoWindow=true;
 var child=Process.Start(start);File.WriteAllText("fault-pids.tsv",Process.GetCurrentProcess().Id+"\\t"+child.Id+"\\n");
 Thread.Sleep(60000);return 0;
} }
'''
cs=O/'FaultRuntime.cs';cs.write_text(source,encoding='utf-8',newline='\n');exe=O/'TimeoutR.exe';compiler='C:/Windows/Microsoft.NET/Framework64/v4.0.30319/csc.exe'
p=subprocess.run([compiler,'/nologo','/target:exe','/out:'+str(exe),str(cs)],capture_output=True,timeout=30);(O/'csc.stdout').write_bytes(p.stdout);(O/'csc.stderr').write_bytes(p.stderr);assert p.returncode==0,p.stderr
shutil.copyfile(exe,O/'ZeroR.exe')
base=B/'normal-originals-1/LM';original=json.loads((base/'request.json').read_bytes())
def alive(pid):
    kernel=ctypes.WinDLL('kernel32',use_last_error=True);kernel.OpenProcess.argtypes=[ctypes.c_ulong,ctypes.c_int,ctypes.c_ulong];kernel.OpenProcess.restype=ctypes.c_void_p;kernel.GetExitCodeProcess.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_ulong)];kernel.CloseHandle.argtypes=[ctypes.c_void_p]
    handle=kernel.OpenProcess(0x1000,False,pid)
    if not handle:return False
    code=ctypes.c_ulong();assert kernel.GetExitCodeProcess(handle,ctypes.byref(code));kernel.CloseHandle(handle);return code.value==259
results={}
for name,changes,expected,cause in [('timeout-owned-child',dict(rscript=str(exe),timeout_seconds=1),2,'timed out'),('output-cap-original-R',dict(maximum_output_bytes=1),2,'maximum_output_bytes'),('zero-exit-missing-status',dict(rscript=str(O/'ZeroR.exe')),2,'status.tsv'),('missing-runtime',dict(rscript=str(O/'MissingR.exe')),3,'unavailable')]:
    folder=O/name;folder.mkdir();request=dict(original);request.update(changes);request['out']=str(folder/'analysis')
    for key in ['matrix','design']:request[key]=str(base/request[key])
    path=folder/'request.json';path.write_text(json.dumps(request,indent=2)+'\n',encoding='utf-8');cmd=[J,'-cp',str(jar),'org.jlinalg.cli.LimmaWorkflowCli','--request',str(path)]
    with (folder/'stdout').open('xb') as stdout,(folder/'stderr').open('xb') as stderr:p=subprocess.run(cmd,cwd=T,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=30)
    analysis=folder/'analysis';manifest=json.loads((analysis/'manifest.json').read_bytes());assert p.returncode==expected and not manifest['results_admitted'],(name,p.returncode,manifest)
    assert cause in json.dumps(manifest),(name,manifest)
    row=dict(command=cmd,exit_code=p.returncode,analysis_status=manifest['analysis_status'],results_admitted=False,simulated_transport_runtime=name in ['timeout-owned-child','zero-exit-missing-status'])
    if name=='timeout-owned-child':
        pids=[int(v) for v in (analysis/'worker/fault-pids.tsv').read_text().split()];owned={v['pid']:v['alive_after_cleanup'] for v in manifest['owned_process_cleanup']};assert len(pids)==2 and all(v in owned and not owned[v] and not alive(v) for v in pids),(pids,owned);row['owned_PIDs_confirmed_stopped']=pids
    p=subprocess.run([J,'-cp',str(jar),'org.jlinalg.cli.LimmaWorkflowCli','--verify',str(analysis)],capture_output=True,timeout=30);(folder/'VERIFY.stdout').write_bytes(p.stdout);(folder/'VERIFY.stderr').write_bytes(p.stderr);assert p.returncode==2;row['failed_or_skipped_capture_VERIFY_exit']=p.returncode
    (folder/'COMPLETED.json').write_text(json.dumps(row,indent=2)+'\n',encoding='utf-8');results[name]=row;print('Process control',name,'PASS',flush=True)
(O/'COMPLETED.json').write_text(json.dumps(dict(status='PASS_NORMAL_JAR_PROCESS_REFUSALS_AND_OWNED_CHILD_CLEANUP',results=results,helper_is_fault_injection_not_original_R=True,helper_source_sha256=hashlib.sha256(cs.read_bytes()).hexdigest()),indent=2)+'\n',encoding='utf-8')
