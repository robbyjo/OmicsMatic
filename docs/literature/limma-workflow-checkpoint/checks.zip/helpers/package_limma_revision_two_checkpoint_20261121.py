from pathlib import Path
import ast,json
R=Path('D:/projects/JLinAlg');T=R/'build/lm-4';B=T/'build/limma-qualification-1';source=(R/'build/package_limma_qualification_checkpoint_20261121.py').read_text(encoding='utf-8')
fault=json.loads((B/'full-worker-journal-fault-2/FAULT-CONTROL.json').read_bytes());assert fault['status']=='PASS_FULL_R_WORKER_REFUSES_JOURNAL_FAILURE_AND_RETAINS_EXACT_ORIGINAL_FITS' and all(fault['original_complete_fits_identical'].values()) and not fault['results_admitted']
for old,new in {'normal-gradle-2':'normal-gradle-4','normal-gradle-1':'normal-gradle-3','packaged-tests-1':'packaged-tests-2','direct-originals-1':'direct-originals-2','normal-originals-1':'normal-originals-2','normal-replays-1':'normal-replays-2','process-controls-1':'process-controls-2','original-failures-2':'original-failures-3','saved-fixture-1':'saved-fixture-2','EXAMPLES-COMPARISON-2':'EXAMPLES-COMPARISON-3','executed-examples-2':'executed-examples-3','examples-2':'examples-3','observer-fixed-1':'observer-journal-fixed-1',"Q.mkdir()":"Q.mkdir(exist_ok=True)","p.open('x'":"p.open('w'","zipfile.ZipFile(archive,'x'":"zipfile.ZipFile(archive,'w'","len(observer['cases'])==7":"len(observer['cases'])==9",'observer_controls=7':'observer_controls=9,full_worker_journal_fault_controls=1','Seven actual original-runtime':'Nine actual original-runtime','All seven preserve':'All nine preserve','20261121-limma-qualification-78`':'20261121-limma-qualification-78-2`'}.items():
    assert old in source,old;source=source.replace(old,new)
old="for folder in ['observer-legacy-1','observer-journal-fixed-1','direct-originals-2'";new="for folder in ['observer-legacy-1','observer-fixed-1','observer-journal-legacy-mixed-1','observer-journal-fixed-1','full-worker-journal-fault-1','full-worker-journal-fault-2','direct-originals-2'";assert old in source;source=source.replace(old,new)
old="for name in helpers:add(R/'build'/name,'helpers/'+name)";new="helpers+=['prepare_limma_journal_revision_20261121.py','limma_observer_control_v2_20261121.R','run_limma_journal_controls_20261121.py','run_limma_revision_two_20261121.py','run_limma_full_journal_fault_20261121.py','run_limma_full_journal_fault_retry_20261121.py','package_limma_revision_two_checkpoint_20261121.py']\n"+old;assert old in source;source=source.replace(old,new)
old='All nine preserve the complete original return/error exactly.';new=old+'''
The journal recorder now retains fallback snapshots without replacing a model
return/error. A full-worker fault injection closes the journal during a blocked
LM run: it writes FAIL2 with original objects and 540 fallback snapshots,
preserves all three complete original fitted models exactly, and records the
close error separately. Finalization errors do not overwrite an existing cause.
The earlier gamma-only revision, its successful controls and unpublished
publication preflight are retained separately; final evidence uses a second set
of actual normal-JAR runs with the corrected enclosing recorder.
''';assert old in source;source=source.replace(old,new)
source=source.replace('both original-failure\nattempts','all original-failure\nattempts')
source=source.replace('both builds, packaged tests and both example runs','all four builds, both packaged-test runs and all three example runs')
source=source.replace('The first failure-harness filename assertion is retained as history.','The initial filename/JSON-output harness assertions are retained as history;\nfresh successful controls follow in separate outputs.')
# Rebuild the current entry from the last published handover, preserving the
# unpublished first-revision document in revision-one-retained.
(T/'docs/literature/HANDOVER_CURRENT.md').write_bytes((R/'build/lm-3/docs/literature/HANDOVER_CURRENT.md').read_bytes())
ast.parse(source);exec(compile(source,__file__,'exec'))
