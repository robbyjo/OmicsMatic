from pathlib import Path
import ast,sys
R=Path('D:/projects/JLinAlg');kind=sys.argv[1];assert kind in ['legacy-mixed','fixed'];source=(R/'build/run_limma_observer_controls_20261121.py').read_text(encoding='utf-8')
source=source.replace("assert kind in ['legacy','fixed']","assert kind in ['legacy-mixed','fixed']").replace("O=B/('observer-'+kind+'-1')","O=B/('observer-journal-'+kind+'-1')").replace("R/'build/limma_observer_control_20261121.R'","R/'build/limma_observer_control_v2_20261121.R'")
source=source.replace("(R/'build/lm-3' if kind=='legacy' else T)","T")
ast.parse(source);exec(compile(source,__file__,'exec'))
