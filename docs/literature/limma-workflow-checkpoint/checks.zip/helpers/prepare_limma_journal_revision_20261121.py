from pathlib import Path
import json,shutil
R=Path('D:/projects/JLinAlg');T=R/'build/lm-4';B=T/'build/limma-qualification-1';O=B/'revision-one-retained';O.mkdir()
for name in ['src/main/resources/org/jlinalg/omics/limma_workflow.R','src/test/resources/org/jlinalg/cli/limma-workflow-originals.zip','src/test/java/org/jlinalg/cli/LimmaWorkflowTest.java']:
    dst=O/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(T/name,dst)
shutil.copytree(T/'docs/literature/limma-workflow-checkpoint',O/'limma-workflow-checkpoint')
for name in ['LIMMA_WORKFLOW_QUALIFICATION_2026-11-21.md','LIMMA_WORKFLOWS.md','HANDOVER_CURRENT.md']:shutil.copyfile(T/'docs/literature'/name,O/name)
P=R/'build/git-publish/20261121-limma-qualification-78';(P/'PUBLICATION-DEFERRED.json').write_text(json.dumps(dict(status='LOCAL_VALIDATION_RETAINED_NOT_COMMITTED_OR_PUSHED',reason='Expanded journal fault review exposed an untested enclosing mixed-model recorder path; fresh worker and real captures required',earlier_sources_and_models_retained=True),indent=2)+'\n',encoding='utf-8')
source=(R/'build/limma_observer_control_20261121.R').read_text(encoding='utf-8')
source=source.replace("writeLines('index\\tlabel\\tstart\\tend','internal-model-index.tsv');", "objects<-list();object.count<-0L;dir.create('objects');writeLines('index\\tlabel\\tstart\\tend','internal-model-index.tsv');")
source=source.replace("if(!closed)close(journal)","if(!closed)close(journal);saveRDS(objects,'fallback-objects.rds',version=3)")
source=source.replace("} else if(name=='incomplete_iteration')", "} else if(expected=='legacy'&&name=='incomplete_iteration')")
point=source.index("stopifnot(identical(body(get('glmgam.fit'")
extra='''
mixed.original<-get('mixedModel2Fit',asNamespace('statmod'),inherits=FALSE);mixed.body<-body(mixed.original);mixed.formals<-formals(mixed.original)
mixed.args<-list(X=matrix(1,6L,1L),Z=model.matrix(~0+factor(rep(1:3,each=2))),only.varcomp=TRUE)
for(kind in c('error','success')) {
 name<-paste0('mixed_',kind,'_closed_journal');dir.create(name);setwd(file.path(out,name));objects<-list();object.count<-0L;dir.create('objects')
 internal.failures<-character();internal.count<-0L;gamma.count<-0L;internal.context<-list()
 writeLines('index\\tlabel\\tstart\\tend','internal-model-index.tsv');writeLines('fit_index\\tfeature_index\\titerations\\tmaximum_iterations\\ttolerance\\tscore_step\\trelative_deviance\\tdamping_ratio\\tconverged\\tscore1\\tscore2\\tstep1\\tstep2','convergence.tsv')
 journal<-file('internal-model-journal.bin',open='wb');close(journal)
 a<-c(list(y=if(kind=='error')rep(.Machine$double.xmax/2,6) else c(1,1.4,3,3.2,5,5.1)),mixed.args)
 stock<-capture(mixed.original,a)
 wrapper<-function(...) {i<-1L;M<-matrix(0,1L,6L,dimnames=list('literal_gene',NULL));observed.mixed(...)}
 observed<-capture(wrapper,a);same<-identical(stock,observed)
 saveRDS(stock,'original.rds',version=3);saveRDS(observed,'observed.rds',version=3);saveRDS(objects,'fallback-objects.rds',version=3)
 results[[name]]<-list(source_error=stock$error,observed_error=observed$error,complete_return_identical=same,observer_failures=as.list(internal.failures),fallback_snapshots=object.count,journal_closed_for_control=TRUE)
 if(expected=='fixed')stopifnot(same,length(internal.failures)>0L,object.count>0L)
 if(expected=='legacy-mixed')stopifnot(!same)
 if(kind=='error')stopifnot(!is.null(stock$error)) else stopifnot(is.null(stock$error))
 setwd(out)
}
stopifnot(identical(body(get('mixedModel2Fit',asNamespace('statmod'))),mixed.body),identical(formals(get('mixedModel2Fit',asNamespace('statmod'))),mixed.formals))
'''
source=source[:point]+extra+source[point:]
(R/'build/limma_observer_control_v2_20261121.R').write_text(source,encoding='utf-8',newline='\n')
print('Retained revision1 models, sources, packet and uncommitted publication preflight',flush=True)
