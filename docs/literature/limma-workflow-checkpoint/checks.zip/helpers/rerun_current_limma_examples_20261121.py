from pathlib import Path
import ast
R=Path('D:/projects/JLinAlg');source=(R/'build/prepare_limma_examples_20261121.py').read_text(encoding='utf-8');start=source.index("for name in ['LM'");end=source.index("O=B/'executed-examples-1'")
source=source[:start]+source[end:];source=source.replace('executed-examples-1','executed-examples-2').replace("'examples.stdout'","'examples-2.stdout'").replace("'examples.stderr'","'examples-2.stderr'").replace("'EXAMPLES-COMPARISON.json'","'EXAMPLES-COMPARISON-2.json'")
ast.parse(source);exec(compile(source,__file__,'exec'))
