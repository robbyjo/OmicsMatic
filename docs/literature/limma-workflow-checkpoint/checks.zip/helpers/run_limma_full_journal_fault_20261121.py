from pathlib import Path
import hashlib,json,os,shutil,subprocess,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/lm-4';B=T/'build/limma-qualification-1';O=B/'full-worker-journal-fault-1';O.mkdir();worker=O/'worker';worker.mkdir();(O/'results').mkdir();(O/'source/reference').mkdir(parents=True)
parent=B/'normal-originals-2/LM_BLOCK/analysis';assert json.loads((parent/'analysis-status.json').read_bytes())['results_admitted']
for name in ['parameters.json','matrix.tsv','design.tsv','block.tsv','runtime-paths.txt']:shutil.copyfile(parent/'worker'/name,worker/name)
jar=B/'normal-gradle-3/project-build/cli/omicsmatic-0.4.0.jar'
with zipfile.ZipFile(jar) as z:
    raw=z.read('org/jlinalg/omics/limma_workflow.R');assert raw==(T/'src/main/resources/org/jlinalg/omics/limma_workflow.R').read_bytes();(O/'source/limma_workflow.R').write_bytes(raw)
    for name in ['source.zip','SOURCE-PROFILE.json']:(O/'source/reference'/name).write_bytes(z.read('org/jlinalg/omics/limma-workflow/'+name))
script=T/'tools/literature/limma_workflow/journal_failure_control.R';shutil.copyfile(script,O/script.name)
command=['C:/Program Files/R/R-4.6.1/bin/Rscript.exe','--vanilla',str(script),str(O/'source/limma_workflow.R'),str(parent/'worker/objects.rds')]
env={k:v for k,v in os.environ.items() if not k.startswith('R_LIBS') and k not in ['R_PROFILE','R_PROFILE_USER','R_ENVIRON','R_ENVIRON_USER','R_DEFAULT_PACKAGES','R_TESTS','LANG','LANGUAGE'] and not k.startswith('LC_')};env.update(LANG='C',LC_ALL='C',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
with (O/'stdout').open('xb') as stdout,(O/'stderr').open('xb') as stderr:p=subprocess.run(command,cwd=worker,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=90)
(O/'PROCESS.json').write_text(json.dumps(dict(command=command,control_exit_code=p.returncode,worker_source_sha256=hashlib.sha256(raw).hexdigest()),indent=2)+'\n',encoding='utf-8')
assert p.returncode==0,(O/'stderr').read_text(errors='replace');print((O/'FAULT-CONTROL.json').read_text(),flush=True)
