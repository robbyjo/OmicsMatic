from pathlib import Path
import ast
R=Path('D:/projects/JLinAlg');source=(R/'build/compare_limma_direct_originals_20261121.py').read_text(encoding='utf-8')
source=source.replace("T=R/'build/lm-3';B=T/'build/limma-workflows-1';O=B/'direct-originals-1'","T=R/'build/lm-4';B=T/'build/limma-qualification-1';O=B/'direct-originals-1'")
start=source.index('sources={');end=source.index('\nenv=',start)
source=source[:start]+"sources={p.name:p/'analysis' for p in (B/'normal-originals-1').iterdir() if p.is_dir()};assert len(sources)==46\nassert all(json.loads((p/'analysis-status.json').read_bytes())['results_admitted'] for p in sources.values())"+source[end:]
ast.parse(source);exec(compile(source,__file__,'exec'))
