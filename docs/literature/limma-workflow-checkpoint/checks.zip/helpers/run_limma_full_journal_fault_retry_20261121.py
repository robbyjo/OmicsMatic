from pathlib import Path
import ast
R=Path('D:/projects/JLinAlg');source=(R/'build/run_limma_full_journal_fault_20261121.py').read_text(encoding='utf-8');assert "O=B/'full-worker-journal-fault-1'" in source;source=source.replace("O=B/'full-worker-journal-fault-1'","O=B/'full-worker-journal-fault-2'");ast.parse(source);exec(compile(source,__file__,'exec'))
