from pathlib import Path
import hashlib,json,subprocess
R=Path('D:/projects/JLinAlg');T=R/'build/lm-4';B=T/'build/limma-qualification-1';E=T/'examples/limma-workflows'
for name in ['LM','VOOM','EDGER_VOOM_LMFIT','BATCH','NORMALIZE','CAMERAPR']:
    prior=B/'normal-originals-1'/name;folder=E/name;folder.mkdir();request=json.loads((prior/'request.json').read_bytes())
    for key in ['matrix','design','weights','libraries','norm_factors','block','batch','batch2','covariates','trend_covariate','statistics','gene_sets']:
        if key not in request:continue
        raw=(prior/request[key]).read_bytes();(folder/(key+'.tsv')).write_bytes(raw);request[key]=key+'.tsv'
    request.update(out='NEW_ANALYSIS_OUTPUT',rscript='PATH_TO_R_4.6.1_Rscript',r_libraries=['PATH_TO_EXACT_PACKAGE_LIBRARY'])
    (folder/'request-template.json').write_text(json.dumps(request,indent=2)+'\n',encoding='utf-8',newline='\n')
O=B/'executed-examples-1';command=['C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe','-X','utf8','-B',str(E/'run_examples.py'),'--jar',str(B/'normal-gradle-2/project-build/cli/omicsmatic-0.4.0.jar'),'--java','C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe','--rscript','C:/Program Files/R/R-4.6.1/bin/Rscript.exe','--r-libraries',str(R/'build/literature-review/monocle-runtime/idep244-adopted-provider-4/libraries-requested.txt'),'--out',str(O)]
p=subprocess.run(command,cwd=T,stdin=subprocess.DEVNULL,capture_output=True,timeout=180);(B/'examples.stdout').write_bytes(p.stdout);(B/'examples.stderr').write_bytes(p.stderr);print(p.stdout.decode(errors='replace'),flush=True);assert p.returncode==0,p.stderr.decode(errors='replace')
def pins(root):return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.iterdir() if p.is_file()}
rows=json.loads((O/'COMPLETED.json').read_bytes());assert len(rows)==6 and all(v['exit_code']==0 and v['VERIFY_exit_code']==0 for v in rows.values())
for name in rows:assert pins(O/name/'analysis/results')==pins(B/'normal-originals-1'/name/'analysis/results'),name
(B/'EXAMPLES-COMPARISON.json').write_text(json.dumps(dict(status='PASS_SIX_EXECUTED_PUBLIC_EXAMPLES_AND_IDENTICAL_ORIGINAL_EXPORTS',command=command,exit_code=p.returncode,cases=list(rows)),indent=2)+'\n',encoding='utf-8')
