from pathlib import Path
import concurrent.futures,hashlib,json,shutil,subprocess,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/lm-4';B=T/'build/limma-qualification-1';G=B/'normal-gradle-2';O=B/'packaged-tests-1';O.mkdir()
def pin(p):
    with p.open('rb') as f:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
def save(n,v):
    with (O/n).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
normal=json.loads((G/'COMPLETED.json').read_bytes());assert normal['exit_code']==0 and normal['reports']['org.jlinalg.cli.LimmaWorkflowTest']['tests']==72
assert not any(r['failures'] or r['errors'] or r['skipped'] for r in normal['reports'].values())
jar=G/'project-build/cli/omicsmatic-0.4.0.jar';assert pin(jar)==pin(B/'normal-gradle-1/project-build/cli/omicsmatic-0.4.0.jar')
old=R/'build/lm-3/build/limma-workflows-1/normal-gradle-2/project-build/cli/omicsmatic-0.4.0.jar'
with zipfile.ZipFile(old) as a,zipfile.ZipFile(jar) as b:
    assert set(a.namelist())==set(b.namelist());changed=[n for n in a.namelist() if a.read(n)!=b.read(n)];assert changed==['org/jlinalg/omics/limma_workflow.R'],changed
    payloads=dict(predecessor_payloads_unchanged=len(a.namelist())-1,changed=changed,removed=[],added=[])
save('PAYLOADS.json',payloads)
deps=O/'junit';shutil.copytree(R/'build/lm-2/build/limma-native-1/packaged-tests-2/junit',deps)
classes=O/'test-classes';classes.mkdir();testroot=G/'project-build/classes/java/test'
for p in (testroot/'org/jlinalg/cli').glob('LimmaWorkflowTest*.class'):
    dst=classes/p.relative_to(testroot);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst)
assert not (classes/'org/jlinalg/cli/LimmaWorkflowCli.class').exists()
resources=O/'resources/org/jlinalg/cli';resources.mkdir(parents=True);shutil.copyfile(T/'src/test/resources/org/jlinalg/cli/limma-workflow-originals.zip',resources/'limma-workflow-originals.zip')
launcher=O/'launcher-classes';launcher.mkdir();J=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin')
cmd=[str(J/'javac.exe'),'--release','17','-Xlint:all','-Werror','-cp',str(jar)+';'+str(deps/'*'),'-d',str(launcher),str(T/'tools/literature/limma_workflow/PackagedWorkflowTests.java')]
p=subprocess.run(cmd,capture_output=True,timeout=60);(O/'javac.stdout').write_bytes(p.stdout);(O/'javac.stderr').write_bytes(p.stderr);assert p.returncode==0,p.stderr.decode(errors='replace')
def linux(p):return '/mnt/d/'+p.relative_to(Path('D:/')).as_posix()
elements=[jar,launcher,classes,O/'resources',deps/'*']
def run(host):
    output=O/('output-'+host);output.mkdir()
    if host=='linux21':cmd=['wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','--exec','/usr/bin/java','-Djlinalg.limma.testOutput='+linux(output),'-cp',':'.join(linux(p) for p in elements),'PackagedWorkflowTests']
    else:cmd=[str(J/'java.exe') if host=='windows21' else 'C:/Program Files/Java/jdk-25/bin/java.exe','-Djlinalg.limma.testOutput='+str(output),'-cp',';'.join(map(str,elements)),'PackagedWorkflowTests']
    with (O/(host+'.stdout')).open('xb') as stdout,(O/(host+'.stderr')).open('xb') as stderr:p=subprocess.run(cmd,cwd=O,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=180)
    row=dict(command=cmd,exit_code=p.returncode,stdout=pin(O/(host+'.stdout')),stderr=pin(O/(host+'.stderr')));save(host+'.PROCESS.json',row)
    assert p.returncode==0,(host,(O/(host+'.stderr')).read_text(errors='replace')[-2500:])
    assert 'LIMMA_WORKFLOW_PACKAGED_PASS tests=72 original_cases=46 origin=' in (O/(host+'.stdout')).read_text(errors='replace')
    print('Packaged workflow',host,'PASS72',flush=True);return host,row
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=dict(pool.map(run,['windows21','windows25','linux21']))
save('COMPLETED.json',dict(status='PASS_72_NORMAL_JAR_WORKFLOW_TESTS_ON_THREE_JVMS',tests_per_JVM=72,original_captures_per_JVM=46,hosts=results,jar=pin(jar),jar_path=str(jar),scientific_classes_and_worker_from_JAR=True,payloads=payloads,source_target='Java17',independent_Linux_compilation=False,Linux_original_R_execution=False,whole_goal_complete=False))
