from pathlib import Path
import concurrent.futures,hashlib,json,subprocess
R=Path('D:/projects/JLinAlg');T=R/'build/lm-4';B=T/'build/limma-qualification-1';O=B/'normal-replays-1';O.mkdir();jar=B/'normal-gradle-1/project-build/cli/omicsmatic-0.4.0.jar';J='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe'
def pins(root):return {p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.rglob('*')) if p.is_file()}
def run(name):
    parent=B/'normal-originals-1'/name/'analysis';before=pins(parent);folder=O/name;folder.mkdir();output=folder/'analysis';request=folder/'replay.json';request.write_text(json.dumps(dict(schema_version=1,mode='REPLAY',analysis=str(parent),out=str(output)),indent=2)+'\n',encoding='utf-8');rows={}
    for mode,args in [('REPLAY',['--request',str(request)]),('VERIFY',['--verify',str(output)])]:
        command=[J,'-cp',str(jar),'org.jlinalg.cli.LimmaWorkflowCli',*args]
        with (folder/(mode+'.stdout')).open('xb') as stdout,(folder/(mode+'.stderr')).open('xb') as stderr:p=subprocess.run(command,cwd=T,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=180)
        rows[mode]=dict(command=command,exit_code=p.returncode);assert p.returncode==0,(name,mode,(folder/(mode+'.stderr')).read_text(errors='replace'))
    assert pins(parent)==before,name;assert pins(parent/'results')==pins(output/'results'),name
    row=dict(processes=rows,parent_files_unchanged=len(before),exported_files_identical=len(pins(output/'results')));(folder/'COMPLETED.json').write_text(json.dumps(row,indent=2)+'\n',encoding='utf-8');print('Normal replay',name,'PASS',flush=True);return name,row
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=dict(pool.map(run,['LM','VOOM','EDGER_VOOM_LMFIT','BATCH','NORMALIZE','CAMERAPR','LM_BLOCK','VOOM_BLOCK2']))
(O/'COMPLETED.json').write_text(json.dumps(dict(status='PASS_EIGHT_NORMAL_JAR_REPLAYS_AND_IMMUTABLE_PARENTS',results=results),indent=2)+'\n',encoding='utf-8')
