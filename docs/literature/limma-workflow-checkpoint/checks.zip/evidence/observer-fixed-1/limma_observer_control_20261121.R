# Original-runtime comparison of observational error paths, without statistical rewrites.
args<-commandArgs(TRUE);stopifnot(length(args)==4L)
worker<-normalizePath(args[1],winslash='/',mustWork=TRUE);libraries<-readLines(args[2],warn=FALSE);out<-normalizePath(args[3],winslash='/',mustWork=TRUE);expected<-args[4]
setwd(out);writeLines(libraries,'runtime-paths.txt',useBytes=TRUE)
expressions<-parse(worker,keep.source=FALSE)
for(e in expressions) {
 if(is.call(e)&&identical(e[[1]],as.name('<-'))&&identical(e[[2]],as.name('main')))break
 eval(e,envir=.GlobalEnv)
}
stopifnot(requireNamespace('jsonlite',quietly=TRUE),requireNamespace('statmod',quietly=TRUE))
original<-get('glmgam.fit',asNamespace('statmod'),inherits=FALSE);before.body<-body(original);before.formals<-formals(original)
specs<-list(incomplete_iteration=list(X=matrix(0,4L,2L),y=rep(1,4L),coef.start=c(1,1)),negative_input=list(X=cbind(1,1:4),y=c(-1,1,2,3)),empty_return=list(X=matrix(numeric(),0L,0L),y=numeric()),zero_return=list(X=cbind(1,1:4),y=rep(0,4L)),converged=list(X=cbind(1,1:6),y=c(1,2,1.8,3,2.5,4)),journal_failure_during_original_error=list(X=matrix(0,4L,2L),y=rep(1,4L),coef.start=c(1,1)),journal_failure_after_original_success=list(X=cbind(1,1:6),y=c(1,2,1.8,3,2.5,4)))
results<-list()
capture<-function(fn,a)tryCatch(list(value=do.call(fn,a),error=NULL),error=function(e)list(value=NULL,error=conditionMessage(e)))
for(name in names(specs)) {
 dir.create(name);setwd(file.path(out,name));internal.failures<-character();internal.count<-0L;gamma.count<-0L;internal.context<-list(feature_index=1L,feature_id='literal_\u00e9')
 writeLines('index\tlabel\tstart\tend','internal-model-index.tsv');writeLines('fit_index\tfeature_index\titerations\tmaximum_iterations\ttolerance\tscore_step\trelative_deviance\tdamping_ratio\tconverged\tscore1\tscore2\tstep1\tstep2','convergence.tsv')
 journal<-file('internal-model-journal.bin',open='wb');closed<-startsWith(name,'journal_failure_');if(closed)close(journal)
 copy<-original;env<-new.env(parent=asNamespace('statmod'));env$.omics_observe<-gamma.observer
 prefix<-quote(on.exit(.omics_observe(environment()),add=TRUE));body(copy)<-as.call(list(as.name('{'),prefix,body(original)));environment(copy)<-env
 stopifnot(identical(body(copy)[[3]],body(original)),identical(formals(copy),formals(original)))
 stock<-capture(original,specs[[name]]);observed<-capture(copy,specs[[name]])
 saveRDS(stock,'original.rds',version=3);saveRDS(observed,'observed.rds',version=3)
 if(!closed)close(journal)
 same<-identical(stock,observed)
 results[[name]]<-list(source_error=stock$error,observed_error=observed$error,complete_return_identical=same,observer_failures=as.list(internal.failures),iterative_observations=gamma.count,journal_closed_for_control=closed)
 if(expected=='fixed') {
  stopifnot(same)
  if(name=='incomplete_iteration'||closed)stopifnot(length(internal.failures)>0L)
 } else if(name=='incomplete_iteration')stopifnot(!same,!identical(stock$error,observed$error))
 setwd(out)
}
stopifnot(identical(body(get('glmgam.fit',asNamespace('statmod'))),before.body),identical(formals(get('glmgam.fit',asNamespace('statmod'))),before.formals))
jsonlite::write_json(list(status=if(expected=='fixed')'PASS_ORIGINAL_ERRORS_RETURNS_AND_NAMESPACE_PRESERVED' else 'REPRODUCED_LEGACY_OBSERVER_MASKING',R=as.character(getRversion()),statmod=as.character(packageVersion('statmod')),cases=results),file.path(out,'RESULTS.json'),auto_unbox=TRUE,pretty=TRUE,null='null')
