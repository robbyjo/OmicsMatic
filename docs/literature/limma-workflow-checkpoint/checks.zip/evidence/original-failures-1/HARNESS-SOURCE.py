from pathlib import Path
import csv,io,json,subprocess
R=Path('D:/projects/JLinAlg');T=R/'build/lm-4';B=T/'build/limma-qualification-1';O=B/'original-failures-1';O.mkdir();jar=B/'normal-gradle-2/project-build/cli/omicsmatic-0.4.0.jar';J='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe';base=B/'normal-originals-1/LM';original=json.loads((base/'request.json').read_bytes())
rows={}
for name in ['nonestimable-zero-weight-row','rank-deficient-design']:
    folder=O/name;folder.mkdir();request=dict(original);request['out']=str(folder/'analysis')
    for key in ['matrix','design']:request[key]=str(base/request[key])
    matrix=list(csv.reader(io.StringIO(Path(request['matrix']).read_text(encoding='utf-8')),delimiter='\t'))
    if name=='nonestimable-zero-weight-row':
        path=folder/'weights.tsv';data=[matrix[0]]+[[row[0],*([0 if i==0 else 1]*(len(row)-1))] for i,row in enumerate(matrix[1:])];request['weights']=str(path)
    else:
        path=folder/'design.tsv';data=list(csv.reader(io.StringIO(Path(request['design']).read_text(encoding='utf-8')),delimiter='\t'))
        for row in data[1:]:row[2]=row[1]
        request['design']=str(path)
    with path.open('x',encoding='utf-8',newline='') as f:csv.writer(f,delimiter='\t',lineterminator='\n',quoting=csv.QUOTE_NONE).writerows(data)
    source=folder/'request.json';source.write_text(json.dumps(request,indent=2)+'\n',encoding='utf-8');cmd=[J,'-cp',str(jar),'org.jlinalg.cli.LimmaWorkflowCli','--request',str(source)]
    with (folder/'stdout').open('xb') as stdout,(folder/'stderr').open('xb') as stderr:p=subprocess.run(cmd,cwd=T,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=60)
    root=folder/'analysis';manifest=json.loads((root/'manifest.json').read_bytes());assert p.returncode==2 and not manifest['results_admitted'] and 'owned_worker_pid' in manifest,(name,p.returncode,manifest)
    assert (root/'worker/status.tsv').is_file() and (root/'worker/objects.rds').is_file()
    p=subprocess.run([J,'-cp',str(jar),'org.jlinalg.cli.LimmaWorkflowCli','--verify',str(root)],capture_output=True,timeout=30);(folder/'VERIFY.stdout').write_bytes(p.stdout);(folder/'VERIFY.stderr').write_bytes(p.stderr);assert p.returncode==2
    row=dict(original_worker_started=True,worker_status=(root/'worker/status.tsv').read_text(encoding='utf-8'),manifest_error=manifest['error'],analysis_status=manifest['analysis_status'],VERIFY_exit=p.returncode,immutable_original_snapshots=len(list((root/'worker/objects').glob('*.rds'))),original_objects_retained=True)
    rows[name]=row;print(name,json.dumps(row),flush=True)
(O/'COMPLETED.json').write_text(json.dumps(dict(status='PASS_TWO_ORIGINAL_R_NUMERICAL_DESIGN_FAILURE_CAPSULES',cases=rows),indent=2)+'\n',encoding='utf-8')
