# limma warnings and required actions

Status: FAIL2_NO_COMPLETE_RESULT

java.io.IOException: Original limma/edgeR/statmod worker timed out; owned process tree cleanup was requested

Read WARNINGS.md, analysis-status.json, worker/report.json, worker/warnings.txt and logs. SKIP3: dependent analysis skipped; restore the named exact permitted input/runtime/package or retain the skip. FAIL2: no complete result; preserve inputs, original model objects, partials and diagnostics, correct data/design, convergence, integrity, capacity or process failures and retry NEW output. No silent identity, count rounding, version, threshold, population, nonfinite or algorithm repair. DEVELOPMENT_SCOPE: original limma3.68.5/edgeR4.10.7/statmod1.5.2 on R4.6.1. Prepared dense LM, voom, explicit edgeR voomLmFit, eBayes/TREAT with source modern/legacy/trend/robust options, batch/covariate removal, matrix normalization and cameraPR. Original namespaces stay unchanged; observational call bindings retain original models. A read-only statmod glmgam.fit on.exit prefix preserves the complete original statistical body with an exact AST inverse and records convergence, including source-suppressed conditions. VERIFY audits saved integrity, literal intake, exported structure and variance/t/P/adjustment/batch arithmetic without R; it does not independently refit original models, parse binary RDS/journal contents or authenticate coordinated replacements. No generic inference fallback, different author edition or whole-paper claim. Capacities are logical/monitored, not OS-enforced quotas.

## Original and adapter warnings

No complete upstream warning ledger is available; inspect partials/logs.
