using System; using System.Diagnostics; using System.IO; using System.Threading;
class FaultRuntime { static int Main(string[] args) {
 if(args.Length>0 && args[0]=="--owned-child") { Thread.Sleep(60000); return 0; }
 string self=Process.GetCurrentProcess().MainModule.FileName;
 if(Path.GetFileName(self).StartsWith("Zero")) return 0;
 var start=new ProcessStartInfo(self,"--owned-child");start.UseShellExecute=false;start.CreateNoWindow=true;
 var child=Process.Start(start);File.WriteAllText("fault-pids.tsv",Process.GetCurrentProcess().Id+"\t"+child.Id+"\n");
 Thread.Sleep(60000);return 0;
} }
