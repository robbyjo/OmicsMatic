from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');B=A/'build/susie-catalog-admission-1';O=B/'controls-3';O.mkdir(exist_ok=False)
sys.dont_write_bytecode=True;sys.path.insert(0,str(A/'tools/literature'))
from susie_catalog.model import META
def pin(path):return dict(bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
def encoded(value):return (json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode()
before={n:pin(A/n) for n in META};env=dict(os.environ,PYTHONPATH=str(A/'tools/literature'));results=[]
inputs=['--primary-cache','D:/projects/JLinAlg/build/literature-review/xml','--supplement-pdf',str(A/'build/seurat-catalog-1/supplement-P160-2/SUPPLEMENT.pdf'),
    '--author-archive',str(A/'build/plink-high-impact-1/P114-author-code-1/EAS_SCZ_rCNV_analysis.zip'),
    '--historical-checkout','D:/projects/JLinAlg/build/sc-susie-1','--enrichr-checkout','D:/projects/JLinAlg/build/sc-enrichr-1',
    '--coloc-checkout',str(A/'build/enrichr-catalog-admission-1/coloc-predecessor-checkout')]
def control(name,args,expected,out=None):
    out=O/name if out is None else out
    p=subprocess.run([sys.executable,'-B','-m','susie_catalog.catalog',*args,'--out',str(out)],cwd=A,env=env,capture_output=True,timeout=180)
    (O/(name+'.stdout')).write_bytes(p.stdout);(O/(name+'.stderr')).write_bytes(p.stderr)
    assert p.returncode==expected,(name,p.returncode,p.stderr[-2000:])
    assert {n:pin(A/n) for n in META}==before,'Control changed canonical metadata'
    results.append(dict(control=name,exit_code=p.returncode));print(name,p.returncode,flush=True)
missing=list(inputs);missing[missing.index('--historical-checkout')+1]=str(O/'not-installed')
control('missing-checkout',['--plan',*missing],3)
wrong=list(inputs);wrong[wrong.index('--historical-checkout')+1]='D:/projects/JLinAlg/build/sc-enrichr-1'
control('wrong-checkout',['--plan',*wrong],2)
existing=O/'existing-output';existing.mkdir();marker=existing/'KEEP';marker.write_bytes(b'preserve original bytes\n');marker_pin=pin(marker)
control('existing-output',['--plan',*inputs],2,existing);assert list(existing.iterdir())==[marker] and pin(marker)==marker_pin
plan=B/'formal-3/plan-1';assert (plan/'PLAN.json').is_file()
for label in ['source-record-mismatch','resealed-preview']:
    target=O/(label+'-plan');shutil.copytree(plan,target)
    record=json.loads((target/'PLAN.json').read_bytes())
    if label=='source-record-mismatch':
        name=next(iter(record['source_code']));record['source_code'][name]['sha256']='0'*64
    else:
        name=META[0];path=target/'preview'/name;papers=json.loads(path.read_bytes())
        next(p for p in papers if p['paper_id']=='P073')['doi']='changed-but-resealed'
        path.write_bytes(encoded(papers));record['after'][name]=pin(path);record['files']['preview/'+name]=pin(path)
    (target/'PLAN.json').write_bytes(encoded(record))
    control(label,['--inspect','--plan-dir',str(target)],2)
(O/'COMPLETED.json').write_bytes(encoded(dict(status='PASS_SUSIE_ADMISSION_CLI_REFUSALS_NO_METADATA_MUTATION',
    controls=results,canonical_before=before,canonical_after={n:pin(A/n) for n in META})))
