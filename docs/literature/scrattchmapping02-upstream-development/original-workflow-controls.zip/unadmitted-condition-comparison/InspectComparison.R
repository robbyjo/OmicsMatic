root <- commandArgs(TRUE)[[1L]]
ref <- readRDS(file.path(root,"scrattch02-workflow-references-1/references/depth_1/complete-conditions.rds"))$conditions
got <- readRDS(file.path(root,"scrattch02-workflow-check-1/depth_1/analysis/original/complete-conditions.rds"))$conditions
got <- lapply(Filter(function(x)identical(x$phase,"ORIGINAL_ANALYSIS"),got),function(x)list(kind=x$kind,condition=x$condition))
cat("LENGTH",length(ref),length(got),"\n")
for(label in c("ref","got")) {
 cat(label,"\n")
 for(x in get(label))cat(x$kind,paste(class(x$condition),collapse="|"),conditionMessage(x$condition),"CALL:",paste(deparse(conditionCall(x$condition)),collapse=" "),"\n")
}
print(all.equal(ref,got,check.environment=TRUE))
