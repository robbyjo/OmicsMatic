root <- commandArgs(TRUE)[[1L]]
ref <- readRDS(file.path(root,"scrattch02-workflow-references-2/references/no_cells/complete-conditions.rds"))
got <- readRDS(file.path(root,"scrattch02-workflow-check-2/no_cells/analysis/original/complete-conditions.rds"))
str(ref$error);str(got$error)
print(all.equal(ref$error,got$error,check.environment=TRUE))
for(label in c("ref","got")) {
 cat(label,"\n")
 value <- get(label)$error
 print(attributes(value));dput(value)
}
