from pathlib import Path
import sys,subprocess
sys.dont_write_bytecode=True
R=Path('/mnt/d/projects/JLinAlg');M=R/'tools/literature/scrattchmapping02';sys.path.insert(0,str(M))
from Runtime import load,save,environment,pin
B=R/'build/literature-review/monocle-runtime';O=B/'scrattch02-zero-expression-control-1';O.mkdir(exist_ok=False)
for name in ['home','tmp']:(O/name).mkdir()
provider=B/'scrattch02-upstream-provider-3';ready=load(provider/'READY.json');reference=B/'scrattch02-workflow-references-2'
command=[sys.executable,'-B',str(M/'run.py'),'--runtime',str(provider),'--request',str(reference/'requests/zero_expression.rds'),'--assets',str(reference/'assets'),'--out',str(O/'analysis')]
with (O/'adapter.stdout').open('xb') as so,(O/'adapter.stderr').open('xb') as se:
 child=subprocess.run(command,cwd=O,stdin=subprocess.DEVNULL,stdout=so,stderr=se)
save(O/'PROCESS.json',dict(command=command,exit_code=child.returncode))
if child.returncode:raise SystemExit(child.returncode)
command=[str(Path(ready['r_prefix'])/'bin/Rscript'),'--vanilla',str(M/'CompareWorkflow.R'),str(reference/'references/zero_expression'),str(O/'analysis/original'),str(O/'COMPARISON.json')]
with (O/'comparison.stdout').open('xb') as so,(O/'comparison.stderr').open('xb') as se:
 child=subprocess.run(command,cwd=O,env=environment(ready,O),stdin=subprocess.DEVNULL,stdout=so,stderr=se)
save(O/'COMPARISON-PROCESS.json',dict(command=command,exit_code=child.returncode))
if child.returncode:raise SystemExit(child.returncode)
save(O/'COMPLETED.json',dict(status='PASS_ORIGINAL_ZERO_EXPRESSION_FULL_RETURN_RNG_AND_ANALYSIS_CONDITIONS',
 comparison=load(O/'COMPARISON.json'),provider=pin(provider/'READY.json'),comparison_source=pin(M/'CompareWorkflow.R'),
 new_family_credit=0,whole_goal_complete=False))
print('PASS_ORIGINAL_ZERO_EXPRESSION_FULL_RETURN_RNG_AND_ANALYSIS_CONDITIONS',flush=True)
