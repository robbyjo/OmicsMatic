from pathlib import Path
import sys,subprocess
sys.dont_write_bytecode=True
R=Path('/mnt/d/projects/JLinAlg');M=R/'tools/literature/scrattchmapping02'
sys.path.insert(0,str(M))
from Runtime import load,save,environment,pin
B=R/'build/literature-review/monocle-runtime'
O=B/'scrattch02-workflow-reference-driver-2';O.mkdir(exist_ok=False)
for n in ['home','tmp']:(O/n).mkdir()
F=B/'scrattch02-workflow-references-2';F.mkdir(exist_ok=False)
ready=load(B/'scrattch02-upstream-provider-3/READY.json')
command=[str(Path(ready['r_prefix'])/'bin/Rscript'),'--vanilla',str(M/'GenerateWorkflowReferences.R'),str(F)]
with (O/'preparation.stdout').open('xb') as so,(O/'preparation.stderr').open('xb') as se:
 child=subprocess.run(command,env=environment(ready,O),cwd=O,stdin=subprocess.DEVNULL,stdout=so,stderr=se)
save(O/'PREPARATION-PROCESS.json',dict(command=command,exit_code=child.returncode))
if child.returncode:raise SystemExit(child.returncode)
results={}
for name,value in load(F/'PREPARED-REQUESTS.json')['cases'].items():
 D=F/'references'/name;D.mkdir(exist_ok=False)
 for n in ['home','tmp']:(D/n).mkdir()
 command=[str(Path(ready['r_prefix'])/'bin/Rscript'),'--vanilla',str(M/'DirectWorkflow.R'),value['request'],str(D)]
 print('FRESH_ORIGINAL',name,flush=True)
 with (D/'original.stdout').open('xb') as so,(D/'original.stderr').open('xb') as se:
  child=subprocess.run(command,env=environment(ready,D),cwd=D,stdin=subprocess.DEVNULL,stdout=so,stderr=se)
 save(D/'PROCESS.json',dict(command=command,exit_code=child.returncode))
 if child.returncode:raise SystemExit(child.returncode)
 results[name]=load(D/'ORIGINAL-CASE.json')
save(F/'ORIGINAL-CONTROLS.json',dict(status='FRESH_ORIGINAL_CONTROLS_CAPTURED_PENDING_COMPARISON',cases=results,
 controls=len(results),source_scripts={name:pin(M/name) for name in ['GenerateWorkflowReferences.R','DirectWorkflow.R']},
 new_family_credit=0,whole_goal_complete=False))
print('FRESH_ORIGINAL_CONTROLS_CAPTURED',len(results),flush=True)
