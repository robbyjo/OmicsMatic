from pathlib import Path
import sys,json,zipfile,hashlib
sys.dont_write_bytecode=True
root=Path(__file__).resolve().parents[3]
module=root/'tools/literature/scrattchmapping02';sys.path.insert(0,str(module))
from Runtime import load,pin,save,CORE,sources
base=root/'build/literature-review/monocle-runtime';check=base/'scrattch02-workflow-check-2'
assert load(check/'FAILURE.json')['status']=='FAIL2_WORKFLOW_COMPARISON_UNADMITTED'
cases={}
for directory in sorted(check.iterdir()):
 if directory.is_dir():
  report=load(directory/'COMPARISON.json');cases[directory.name]=report
assert len(cases)==10 and cases['no_cells']['status']=='FAIL2_ORIGINAL_WORKFLOW_DIFFERS'
assert all(report['status']=='PASS_COMPLETE_ORIGINAL_WORKFLOW_OBJECTS' for name,report in cases.items() if name!='no_cells')
zero=base/'scrattch02-zero-expression-control-1'
assert load(zero/'COMPLETED.json')['status']=='PASS_ORIGINAL_ZERO_EXPRESSION_FULL_RETURN_RNG_AND_ANALYSIS_CONDITIONS'
cases['zero_expression']=load(zero/'COMPARISON.json')
provider=base/'scrattch02-upstream-provider-3';ready=load(provider/'READY.json')
assert sources()==ready['runner_sources']
reference=base/'scrattch02-workflow-references-2'
for name,identity in load(reference/'ORIGINAL-CONTROLS.json')['source_scripts'].items():assert pin(module/name)==identity,name
recording=base/'scrattch02-workflow-recording-controls-1'
assert load(recording/'COMPLETED.json')['test_source']==pin(module/'test_workflow_recording.py')
repeat=base/'scrattch02-original-no-cells-repeat-1'
diagnostic=load(repeat/'DIAGNOSTIC.json')
assert diagnostic['original_repeat_strict_identical'] is False and diagnostic['adapter_strict_identical'] is False
assert diagnostic['original_repeat_same_call_function_body'] and diagnostic['adapter_same_call_function_body']
assert diagnostic['call_function_environment_binding_types']==['externalptr','externalptr','externalptr']
dest=root/'docs/literature/scrattchmapping02-upstream-development';assert dest.is_dir()
assert not (dest/'original-workflow-controls.zip').exists()
files={};folded=set()
def add(name,path):
 assert name.casefold() not in folded,name
 files[name]=path;folded.add(name.casefold())
def tree(label,folder):
 for path in sorted(folder.rglob('*')):
  assert not path.is_symlink(),path
  if path.is_file():add(label+'/'+path.relative_to(folder).as_posix(),path)
for label,folder in [('runtime-audit',provider),('original-controls',reference),
 ('adapter-controls-overall-failed',check),('zero-expression-control',zero),('recording-controls',recording),
 ('independent-original-empty-query-repeat',repeat),('reference-driver',base/'scrattch02-workflow-reference-driver-2'),
 ('unadmitted-same-session-reference',base/'scrattch02-workflow-references-1'),
 ('unadmitted-condition-comparison',base/'scrattch02-workflow-check-1')]:tree(label,folder)
for name in CORE+['GenerateWorkflowReferences.R','DirectWorkflow.R','CompareWorkflow.R','verify_workflow.py','test_workflow_recording.py','README.md']:
 add('adapter-sources/'+name,module/name)
add('documentation/SCRATTCH_MAPPING02_UPSTREAM_DEVELOPMENT.md',root/'docs/literature/SCRATTCH_MAPPING02_UPSTREAM_DEVELOPMENT.md')
add('documentation/README.md',dest/'README.md')
for path in [base/'scrattch02-workflow-reference-driver-2.py',base/'scrattch02-zero-expression-control-1.py',Path(__file__)]:add('development-drivers/'+path.name,path)
archive=base/'scrattch-reported-edition-intake-1/scrattch.mapping/source.tar.gz'
assert pin(archive)==load(module/'upstream-source-profile.json')['archive']
add('original-source/scrattch.mapping-v0.2.tar.gz',archive)
manifest={name:pin(path) for name,path in files.items()}
summary=dict(status='DEVELOPMENT_CHECKPOINT_FULL_WORKFLOW_QUALIFICATION_FAILED',
 strict_comparisons_passed=10,strict_comparisons_failed=1,controls=11,
 complete_original_returns_strictly_compared=7,complete_original_failures_strictly_compared=3,
 empty_query_strict_identity_failed=True,independent_original_repeat_strict_identity_also_failed=True,
 no_condition_fields_waived=True,cases=cases,empty_query_diagnostic=diagnostic,
 recording_controls=load(recording/'COMPLETED.json'),runner_sources=ready['runner_sources'],
 verifier_sources={name:pin(module/name) for name in ['GenerateWorkflowReferences.R','DirectWorkflow.R','CompareWorkflow.R','verify_workflow.py','test_workflow_recording.py']},
 public_installer_qualified=False,new_family_credit=0,catalog_family_still_missing=True,
 whole_tool_qualified=False,whole_goal_complete=False)
bundle=dest/'original-workflow-controls.zip'
with zipfile.ZipFile(bundle,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,path in files.items():
  assert pin(path)==manifest[name],name
  z.write(path,name)
 z.writestr('DEVELOPMENT-STATUS.json',json.dumps(summary,indent=2)+'\n')
 z.writestr('BUNDLE-MANIFEST.json',json.dumps(dict(status=summary['status'],files=manifest,
  private_runtime_payloads_included=False,complete_mapping_GPL_source_archive_included=True,
  selected_author_environment_recovered=False,new_family_credit=0,whole_goal_complete=False),indent=2)+'\n')
with zipfile.ZipFile(bundle) as z:
 assert z.testzip() is None
 assert len(z.namelist())==len(set(x.casefold() for x in z.namelist()))
 for name,identity in manifest.items():
  data=z.read(name)
  assert dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())==identity,name
summary.update(evidence_bundle=pin(bundle),regular_bundle_members=len(manifest)+2)
save(dest/'VALIDATION.json',summary)
print('FROZEN_UNQUALIFIED_DEVELOPMENT_EVIDENCE',len(manifest)+2,pin(bundle),flush=True)
