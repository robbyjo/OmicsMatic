import java.io.*;
import org.junit.platform.launcher.core.*;
import org.junit.platform.launcher.listeners.*;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;
public class SalmonSetupChecks {
 public static void main(String[] args)throws Exception {
  for(String name:new String[]{"org.jlinalg.cli.SalmonSetupEvidence","org.jlinalg.sequence.SalmonQuantification","org.jlinalg.sequence.SalmonInferentialReplicates"})if(!Class.forName(name).getProtectionDomain().getCodeSource().getLocation().toURI().equals(new File(args[0]).toURI()))throw new AssertionError("Wrong actual JAR");
  var listener=new SummaryGeneratingListener();LauncherFactory.create().execute(LauncherDiscoveryRequestBuilder.request().selectors(selectClass("org.jlinalg.cli.SalmonSetupEvidenceTest"),selectClass("org.jlinalg.sequence.SalmonQuantificationTest"),selectClass("org.jlinalg.sequence.SalmonInferentialReplicatesTest")).build(),listener);
  var s=listener.getSummary();s.printTo(new PrintWriter(System.out));s.printFailuresTo(new PrintWriter(System.out));
  if(s.getTestsFoundCount()!=139||s.getTestsSucceededCount()!=139||s.getTestsSkippedCount()!=0||s.getTestsAbortedCount()!=0||s.getTestsFailedCount()!=0||s.getContainersFailedCount()!=0)throw new AssertionError("Incomplete native Salmon setup checks");
  System.out.println("COMPLETE_ORIGINAL_SETUP_REPORTS 6 HEALTH_ROWS 480 BOOTSTRAP_VALUES 36000 NATIVE_CASES 139");
 }
}
