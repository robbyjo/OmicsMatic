# Salmon SKIP3 — SETUP/ANALYSIS SKIPPED

Exact private Salmon home is absent and installation is not authorized; use permitted --allow-install or an admitted existing home

Required action: inspect WARNINGS.md, FAILURE.json when present, all launch/process receipts and original stdout/stderr. This is synthetic runtime setup only; it does not admit a user analysis. SKIP3 means a required permitted host/runtime/resource is unavailable: skip dependent analysis and complete permitted setup. FAIL2 means input, integrity, process, numerical, capacity or finalization failure: no result is admitted. Preserve every partial home/report/download and use NEW paths after correction. Install only with --allow-install; download only with --allow-download or supply complete --archive-dir files. Use Linux x86_64 Python 3.12+ with -I -B and a filesystem that preserves the declared modes. Hashes prove integrity, not authenticity. Cell Ranger remains excluded.
