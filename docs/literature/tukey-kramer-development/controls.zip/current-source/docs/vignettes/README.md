# OmicsMatic vignettes

The source-build [250-paper omics/GWAS toolbox review](../literature/omics-2023-2026/README.md)
includes a searchable paper/tool catalog, native signature/interval workflows,
optional upstream cell representations, an implementation queue and prominent
dependency warnings with recovery steps.

The source-build [Tukey–Kramer post-hoc guide](posthoc-comparisons.md) adds
native all-pairs comparisons after an ordinary one-way fit, with adjusted
probabilities, simultaneous intervals and explicit model/recovery instructions.

## Featured: three degrees of AI collaboration

Start with **[your first study.yaml](study-getting-started.md)** for the minimum
contract, file placement and complete/partial/resumed execution. Continue with
the [field guide](study-yaml-reference.md), [AI connections](ai-connections.md)
and [literature, tools and finding priorities](study-tools-literature.md).

- [No AI: deterministic analysis](ai-no-ai.md) — execute and verify a complete local study.
- [AI as a scientific advisor](ai-advisor.md) — bounded, audited browser/API advice.
- [AI as an external workflow driver](ai-driver.md) — coordinate existing CLI commands with separate scientist approval and enforced access controls.

Use the current source build's [first-login helper](ai-login.md) for OpenAI/Gemini browser authorization, guided Claude/Grok key setup, and SSH callbacks.

Saved AI credentials can use [password-encrypted files and supported automatic renewal](ai-credentials.md), with setup for OpenAI, Claude, Grok and Gemini.

These expanded walkthroughs target the current source build. The three collaboration patterns are available in v0.3.7; newer completed-analysis and publication features require the source build. Each guide identifies its patient-data boundary.


New RNA workflows: [replicated single-cell analysis](single-cell.md) and
[physical spatial analysis](spatial-analysis.md), with complete CLI examples and
[independent validation](../cell-spatial-validation.md).

New source-build follow-up workflows: [project configuration](project-configuration.md),
[variant annotation and scoring](variant-followup.md), and
[networks and candidate regulators](network-followup.md). Each includes runnable
CLI examples, references, data contracts and validation boundaries.

The [analysis pipeline specification](analysis-pipeline-specification.md) describes
the end-to-end scientific workflow, improved pseudocode, decision rules,
GWAS QC/rare variants, functional/structural follow-up, AI selection of 3–5
principal findings, an 8,000-word manuscript budget and implementation gaps.
The [completed-study guide](study-pipeline-tutorial.md#completed-analyses-through-manuscript)
shows how to reuse completed analyses, fill missing module GO and continue to
principal-finding discussions with linked supplements.

The source-build [auditable omics research pipeline](auditable-omics-pipeline.md)
implements the minimal `study.yaml`, deterministic plan approval and execution,
materialized project status, immutable amendments, evidence lineage, research
notebook, unusual-result capture, and guarded attribution for opt-in LLM assistance.
The companion [hands-on tutorial](study-pipeline-tutorial.md) runs the checked-in
two-cohort example end to end and specifies a default-deny, independently
verifiable patient-data boundary for local execution and optional remote LLM assistance.
The [questions and decisions subsystem](study-questions-and-decisions.md)
implements the first deterministic question rules, a local inbox, checked batch
answers, answer-linked amendments, and exact question/answer notebooks. The
broader design describes future LLM proposals and interactive review.

These worked examples start with small in-memory arrays so the statistical
model is visible. Replace those arrays with your own columnar or file-backed
data preparation; the fitting APIs consume primitive Java arrays and do not
require a dataframe runtime.

Every vignette ends with method-specific primary sources. The complete bibliography is
available in the [scientific citation index](../CITATIONS.md) and on the
[searchable website](https://robbyjo.github.io/OmicsMatic/citations.html).

Run the complete verification suite before adapting an example:

```powershell
.\gradlew.bat check
```

## Choose a vignette

The v0.3.7 executable includes the study/question subsystem, opt-in AI
assistance, plotting and cohort sensitivity, variant/network follow-up,
single-cell/spatial commands and the earlier v0.3.6 inference methods. Some
methods require separately installed R packages, reference resources or declared
scientific inputs. External-agent orchestration remains a supervised integration
pattern; autonomous orchestration and certified privacy isolation are not bundled.

| Vignette | Features covered |
| --- | --- |
| [Analysis pipeline specification](analysis-pipeline-specification.md) | End-to-end pseudocode, GWAS QC/MAC and rare-set testing, discovery/validation, meta-analysis, enrichment/networks, scores, ANNOVAR/AlphaGenome, AlphaFold, MR/colocalization, AI ranking of 3–5 findings and 8,000-word manuscript; current support versus extensions |
| [Auditable omics research pipeline](auditable-omics-pipeline.md) | Implemented minimal study contract, matrix/result-first planning, approvals, resumable execution, `project-status.yaml`, `amendment-XXX.yaml`, provenance, evidence index, unusual-result capture, and future LLM-assisted drafting |
| [Auditable study pipeline tutorial](study-pipeline-tutorial.md) | Runnable result-first project, contract and plan review, approval, execution, resume, verification, amendments, unusual-result capture, and patient-level LLM non-egress assurance design |
| [Bioinformatics evidence workflow](bioinformatics-evidence.md) | Public-source discovery, reviewed regional genetics, protein and reference sequence investigation, non-LLM literature search, auditable AI proposals and evidence archives |
| [Study questions and decisions design](study-questions-and-decisions.md) | Implemented deterministic questions, audited batch answers and amendment proposals; broader routing, LLM, authorization, and resume roadmap |
| [Censored and ordinal regression](censored-ordinal.md) | Tobit; Weibull, lognormal and exponential AFT; ordered logit/probit ML (source build) |
| [Rare-event and survey inference](sampling-models.md) | King-Zeng/prior corrections and stratified PSU Taylor covariance (source build) |
| [LDSC genetic architecture](ldsc.md) | observed-scale heritability/genetic correlation, shared block jackknife, S/V exports (v0.3.6+) |
| [Genetically predicted TWAS/PWAS](predicted-omics.md) | prediction weights, allele/LD alignment, molecular Z tests and joint tissue/model inference (v0.3.6+) |
| [Shared genetic factors](genomic-factor.md) | full-WLS genetic measurement model and conditional SNP effects/heterogeneity (v0.3.6+) |
| [Prediction scores](prediction-scores.md) | Gaussian ridge/elastic-net training, imported polygenic weights and independent-cohort evaluation (v0.3.6+) |
| [Latent confounders and known batch effects](latent-confounders-and-batch.md) | PCA, standard SVA, AutoSVA, PEER, ComBat, CLI artifacts, source provenance and leakage boundaries (v0.3.6+) |
| [Differential, regional, multiple-testing, and imputation workflows](differential-regions-testing-imputation.md) | moderated continuous/voom/NB differential analysis, spatial EWAS regions, cross-fitted IHW, hierarchical FWER, MICE, and Rubin pooling (v0.3.6+) |
| [Expected responses, scenarios, and marginal effects](predictions-and-contrasts.md) | binomial probit, shared GLM/GEE mean predictions, scenario differences, risk ratios, average marginal effects, and joint delta-method uncertainty (v0.3.6+) |
| [Individual-level instrumental-variable regression](instrumental-variable-regression.md) | linear 2SLS, QR/SVD identification checks, robust/cluster inference, and instrument-strength diagnostics (v0.3.6+) |
| [Summary-only conditional score analysis](conditional-score-conditioning.md) | versioned score-block import, strict allele/model checks, cohort-wise Schur conditioning, and independent-cohort pooling (v0.3.6+) |
| [ACAT rare-variant tests](acat-rare-variants.md) | stable generic ACAT, ACAT-V ultra-rare collapsing, canonical ACAT-O, CLI/API workflows, R fixtures, and fused performance (v0.3.6+) |
| [GRM tutorial and Java vignette](../grm-cli.md) | worked dosage matrix, filtering, VCF input, Java/CLI construction, interpretation, and mixed-model reuse ([website](https://robbyjo.github.io/OmicsMatic/vignettes/grm.html); v0.3.6+) |
| [Progressive CLI association tutorial](cli-association-tutorial.md) | phenotype-only OLS/REML, numeric omics, common and rare-variant GWAS, pedigree IDs, GLM/GLMM, Cox, and penalized regression |
| [CLI-only mediation tutorial](cli-mediation-tutorial.md) | tabular OLS mediation, common complete-case filtering, grouped REML, pedigrees, output files, and causal interpretation limits |
| [CLI-only Mendelian-randomization tutorial](cli-mr-tutorial.md) | public or custom GWAS inputs, canonical columns, LD-panel installation, clumping, harmonization, estimation, and outputs |
| [CLI-only SuSiE tutorial](cli-susie-tutorial.md) | summary statistics plus labeled or ordered LD, fine-mapping controls, PIPs, credible sets, and diagnostics |
| [CLI-only colocalization tutorial](cli-colocalization-tutorial.md) | two SuSiE effect tables, priors, overlap trimming, H0-H4, conditional shared-variant posteriors, and sensitivity checks |
| [Command-line-only workflows](command-line.md) | phenotype-only and omics OLS/GLM, exact LMM/GLMM, pedigree/GRM matching, family-qualified and singleton IDs, genotype scans, Cox, and operational controls |
| [Basic statistical tests](basic-statistical-tests.md) | unit-safe correlation/mean/variance inference, exact/asymptotic rank tests, tables, blocked designs, and ANOVA power |
| [Nonlinear models](nonlinear-models.md) | analytic Gaussian fixed means, additive mixed effects, sparse pedigree structures |
| [Mediation](mediation.md) | deterministic Gaussian path analysis, Sobel inference, ordinary and pedigree mixed effects |
| [Beta regression](../beta-regression.md) | classical mean/precision beta ML, CLI, link options, and independent R validation |
| [Linear models and GLMs](linear-models-and-glms.md) | CLI-only phenotype/omics OLS and GLM commands, including source-build probit; Java weights, offsets, contrasts, penalized fits, and inference |
| [Regression families](regression-families.md) | multivariate OLS, multinomial logistic, supersmoother, quantile, kernel nonparametric, and partially linear semiparametric regression |
| [Advanced extensions](advanced-extensions.md) | SEM extensions, full-covariance meta-regression, sparse unstructured mixed effects, diffuse/missing time series, generalized MR, quadrature GLMM, and selection-aware penalized inference |
| [Additive, mixed, and distributional models](../additive-models.md) | GAM REML/GCV, multi-penalty te/ti, cyclic/thin-plate/MRF bases, GAMM PQL/Laplace, pedigree/GRM, GAMLSS/VGAM families, prepared scans |
| [LOESS local polynomial regression](../loess.md) | direct tricube fitting, prior weights, robust symmetric passes, prediction, leverage, R accuracy and speed |
| [REML and mixed models](reml-and-mixed-models.md) | CLI-only grouped/GRM exact REML; Java covariance components, correlated effects, prediction, refit, and comparison |
| [Pedigree and generalized mixed models](pedigree-and-glmm.md) | CLI-only pedigree LMM/GLMM; Java pedigree construction, PQL, adaptive quadrature, and ZIP/ZINB |
| [Cox and frailty survival models](cox-survival.md) | CLI-only fixed/GRM Cox; Java streamed omics, delayed entry, strata, shared frailty, and pedigree frailty |
| [Formulas and compute backends](formulas-and-backends.md) | CLI-only formula/backend preflight; Java model tables, contrasts, offsets, and nested/correlated terms |
| [Association, GWAS, and omics QTL](association-gwas-twas.md) | CLI-only numeric omics, VCF/BCF/BGEN, and GRM scans; Java prepared scans and Burden/SKAT/SKAT-O/ACAT-V/ACAT-O |
| [Omics transforms from the command line](omics-transforms.md) | exact `--transform` syntax, all built-in stages, pipeline recipes, missing values, failure conditions, and trusted plugin providers |
| [End-to-end Mendelian randomization](mr-end-to-end.md) | database installation, public/custom instruments, LD clumping, analysis, diagnostics, plotting exports, bidirectional and molecular MR |
| [Multivariable and multivariate MR](multivariate-mr.md) | distinct MVMR and correlated-outcome CLI schemas, joint IVW/Wald inference, multivariate heterogeneity and PRESSO diagnostics |
| [Parallel xWAS MR](xwas-mr-pipeline.md) | reusable clumped instruments, phenotype families, bounded parallel exposure-outcome scans, all-pairs BH/FDR, scale-safe thresholds, and two-stage diagnostics |
| [xWAS MR CLI and benchmark](../xwas-mr-cli-performance.md) | long-format CLI, output schema, reproducible R validation, timing protocol and measured speedup |
| [MR estimator reference](mendelian-randomization.md) | harmonization, IVW, MR-Egger, LD, directionality, robust/outlier, multivariable, overlap and winner's curse |
| [Meta-analysis](meta-analysis.md) | omics Java/CLI examples, fixed/random pooling, heterogeneity, meta-regression, and links to rare-variant workflows |
| [Rare-variant cohort summaries and meta-analysis](../rare-variant-meta-analysis.md) | participant score export, RAREMETAL/rvtests import, Burden, SKAT, SKAT-O, ACAT-V, ACAT-O, and calibration limits (unreleased) |
| [Time series](time-series.md) | AR/MA/ARMA/ARIMA/SARIMA, scalable exact diffuse smoothing, conditional and parameter-aware forecasts, diagnostics, and ARIMA-error LMM |
| [SuSiE, colocalization, and SEM](susie-and-sem.md) | individual/summary fine mapping, credible sets, multi-signal colocalization, and a compact SEM introduction |
| [Multi-signal colocalization](colocalization.md) | alignment, priors, posterior-overlap trimming, H0-H4, shared-variant posterior, diagnostics, and MR/xWAS follow-up |
| [Structural equation modeling](sem.md) | joint observed/latent RAM, means, ordinal PML, pattern FIML, robust inference, lavaan validation, and limitations |

## Common result pattern

OLS, GLM, REML/LMM, pedigree, GLMM, association, meta-analysis, and many
specialized fits expose coefficient-level effect size, SE, statistic, and
p-value. Where `associationStatistics()` is available:

```java
AssociationStatistics inference = fit.associationStatistics();
double[] beta = inference.effectSizes();
double[] se = inference.standardErrors();
double[] statistic = inference.statistics();
double[] p = inference.pValues();
double[] minusLog10P = inference.negativeLog10PValues();
```

Always check a result's `converged()` flag when the estimator is iterative.
The [numerical contract](../numerical-contract.md) states the likelihood,
degrees-of-freedom, approximation, and missing-data assumptions behind each
result. The [performance guide](../performance-benchmarks.md) explains how to
measure backend and sparse/dense choices on the target machine.
