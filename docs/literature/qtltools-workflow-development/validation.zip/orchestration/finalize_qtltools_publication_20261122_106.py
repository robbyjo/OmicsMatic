from pathlib import Path
import ast, hashlib, json, re, subprocess, zipfile
from prepare_qtltools_workflow_20261121_106 import R,T,O,BASE
from prepare_handover_qtltools_20261121_105 import pin,save,git,inventory

B=T/'build/qtltools-workflow-1';Q=T/'docs/literature/qtltools-workflow-development'

def load(path):return json.loads(path.read_bytes())

if __name__=='__main__':
    profile=load(Q/'PROFILE.json');index=load(Q/'INDEX.json')
    protected={**profile['source_inputs'],**profile['canonical_unchanged'],**{(Q/name).relative_to(T).as_posix():v for name,v in profile['files'].items()}}
    for name,wanted in protected.items():assert pin((T/name).read_bytes())==wanted,name
    jar=B/'normal-gradle-5/project-build/cli/omicsmatic-0.4.0.jar'
    assert pin(jar.read_bytes())==profile['producer']
    assert load(B/'normal-gradle-5/RESULT.json')['tests']==680
    packaged=load(B/'packaged-3/RESULT.json')
    assert all(v==dict(exit_code=0,tests=680) for v in packaged['hosts'].values())
    assert packaged['producer']==profile['producer']
    readers={}
    for host in ['windows','linux']:
        assert load(O/f'reader-{host}.PROCESS.json')['exit_code']==0
        readers[host]=load(B/f'packet-checks/{host}/RESULT.json')
        assert readers[host]['qualified_JAR_verified'] and readers[host]['scientific_models_executed'] is False
    a=dict(readers['windows']);b=dict(readers['linux']);assert a.pop('restored') is True and b.pop('restored') is False and a==b
    restore=B/'packet-checks/windows/captured'
    for name,wanted in index.items():assert pin((restore/name).read_bytes())==wanted,name
    assert len(index)==34052
    print('PASS:all34052 restored logical files independently read and pinned;both host readers agree',flush=True)
    controls=load(O/'PACKET-NEGATIVE-CONTROLS.json');assert len(controls)==4 and all(v['refused'] and v['exit_code']==2 for v in controls.values())
    reasons=load(O/'ACTUAL-INTEGRITY-REFUSAL-REASONS.json');assert len(reasons['reasons'])==14 and reasons['status'].startswith('PASS_')
    audit=load(Q/'PUBLICATION-DATA-AUDIT-FULL.json')
    assert audit['captured_input_files_all_verified_artificial']==4254 and audit['captured_BAM_VCF_files_all_verified_artificial']==935
    assert audit['credential_candidates']==0 and not audit['individual_or_project_cohort_data_published']
    assert audit['controls_archive']==pin((Q/'controls.zip').read_bytes()) and audit['index']==pin((Q/'INDEX.json').read_bytes())
    assert audit['audit_source']==pin((T/'tools/literature/qtltools_workflow/audit_publication.py').read_bytes())
    assert profile['catalog']==dict(papers=250,scoped_families=145,native=26,upstream=119,reviewed=1630,pending=1092)
    links=[]
    docs=[T/'docs/literature'/name for name in ['QTLTOOLS_WORKFLOWS.md','QTLTOOLS_RUNTIME.md','QTLTOOLS_FDENSITY.md','QTLTOOLS_WORKFLOW_CHECKPOINT_2026-11-21.md']]+[Q/'README.md',T/'examples/qtltools/README.md']
    for path in docs:
        for target in re.findall(r'\]\(([^)\s]+)\)',path.read_text(encoding='utf-8')):
            if target.startswith(('http:','https:','#')):continue
            actual=(path.parent/target.split('#')[0]).resolve();assert actual.is_file(),(str(path),target)
            links.append(dict(source=path.relative_to(T).as_posix(),target=target))
    py=[T/'src/main/resources/org/jlinalg/omics/qtltools-workflow/owned_worker.py',*sorted((T/'tools/literature/qtltools_workflow').glob('*.py'))]
    for path in py:ast.parse(path.read_text(encoding='utf-8'),filename=str(path))
    prepend=load(O/'HANDOVER-PREPEND.json');current=(T/'docs/literature/HANDOVER_CURRENT.md').read_bytes()
    old=git(T,'show',BASE+':docs/literature/HANDOVER_CURRENT.md');assert pin(old)==prepend['previous']
    heading=b'# Current toolbox handover\n\n';assert current.startswith(heading) and current.endswith(old[len(heading):])
    assert pin(current)==prepend['current']
    checked=subprocess.run(['git','diff','--check'],cwd=T,capture_output=True)
    assert checked.returncode==0,checked.stdout+checked.stderr
    inv=inventory();before=load(O/'WORKTREES-BEFORE.json');assert len(before)==62
    for n,state in enumerate(before,1):
        assert inv.snapshot(Path(state['root']))==state,state['root']
        if n%10==0:print('Prior owners unchanged',n,'/62',flush=True)
    assert len(git(T,'worktree','list','--porcelain').decode().strip().split('\n\n'))==63
    save(O/'PRESERVATION-FINAL.json',dict(status='PASS_ALL62_PRECEDING_OWNERS_EXACT',owners=62,current_owner=63,source_inputs_exact=len(profile['source_inputs']),canonical_unchanged=len(profile['canonical_unchanged']),qualified_jar=profile['producer']))
    save(O/'PACKET-RESTORE-INDEPENDENT.json',dict(status='PASS_ALL_RESTORED_LOGICAL_BYTES_INDEPENDENTLY_READ',logical_files=len(index),windows_linux_reader_results_equal_except_restore=True,readers=readers,profile=pin((Q/'PROFILE.json').read_bytes())))
    save(O/'DOCUMENTATION-AND-SYNTAX.json',dict(relative_links=links,python_files=[p.relative_to(T).as_posix() for p in py],python_syntax=True,git_diff_check=True,previous_handover_retained_exact=True))
    members={}
    scripts=['run_qtltools_packet_reader_20261121_106.py','control_qtltools_packet_20261121_106.py',Path(__file__).name]
    for name in scripts:members['orchestration/'+name]=(R/'build'/name).read_bytes()
    for name in ['PACKET-NEGATIVE-CONTROLS.json','ACTUAL-INTEGRITY-REFUSAL-REASONS.json','PRESERVATION-FINAL.json','PACKET-RESTORE-INDEPENDENT.json','DOCUMENTATION-AND-SYNTAX.json']:
        members['receipts/'+name]=(O/name).read_bytes()
    for host in ['windows','linux']:
        for suffix in ['STARTED.json','PROCESS.json','stdout','stderr']:
            name=f'reader-{host}.{suffix}';members['receipts/'+name]=(O/name).read_bytes()
        members[f'reader-{host}/RESULT.json']=(B/f'packet-checks/{host}/RESULT.json').read_bytes()
    for label in controls:
        folder=B/'packet-controls-1'/label
        for name in ['STARTED.json','PROCESS.json','stdout','stderr','result/FAILURE.txt']:members[f'packet-controls/{label}/{name}']=(folder/name).read_bytes()
    with zipfile.ZipFile(Q/'validation.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,raw in sorted(members.items()):z.writestr(name,raw)
    result=dict(status='PASS_CURRENT_QTLTOOLS_WORKFLOWS_AND_PORTABLE_HANDOVER',baseline=BASE,profile=pin((Q/'PROFILE.json').read_bytes()),validation_archive=pin((Q/'validation.zip').read_bytes()),validation_members={k:pin(v) for k,v in sorted(members.items())},qualification=load(Q/'QUALIFICATION.json'),packet_readers=readers,independently_read_restored_files=len(index),packet_negative_controls=controls,actual_integrity_refusals_all_hit_intended_guard=True,all62_prior_owners_exact=True,canonical_catalog_files_exact=len(profile['canonical_unchanged']),source_inputs_exact=len(profile['source_inputs']),catalog=profile['catalog'],catalog_admitted=False,new_catalog_credit=0,whole_goal_complete=False,private_transfer_completed=False,private_transfer_inventory='PRIVATE-TRANSFER.json',scope='Prepared-input original/native execution is qualified by designated saved actual controls. Packet readers run no model. Nine source-bound paper reviews and catalog admission remain next. Historical failures/nulls/private artifacts are retained. No release or Pages deployment.')
    save(Q/'VALIDATION.json',result);save(O/'VALIDATION.json',result)
    raw=git(T,'status','--porcelain=v1','-z','--untracked-files=all');names=[]
    for field in raw.split(b'\0'):
        if not field:continue
        assert field[:2] in [b' M',b'??'],field
        names.append(field[3:].decode('utf-8'))
    expected=set(profile['source_inputs'])|{(Q/name).relative_to(T).as_posix() for name in profile['files']}|{(Q/name).relative_to(T).as_posix() for name in ['PROFILE.json','VALIDATION.json','validation.zip']}
    assert set(names)==expected,(sorted(set(names)-expected),sorted(expected-set(names)))
    pins={name:pin((T/name).read_bytes()) for name in sorted(names)}
    assert all(not name.startswith(('build/','docs/site/','.github/')) for name in pins)
    save(O/'PUBLICATION-FILES.json',pins)
    (O/'PUBLICATION-PATHS.nul').write_bytes(b'\0'.join(name.encode('utf-8') for name in pins)+b'\0')
    print('PASS:publication ready;',len(pins),'explicit source/doc/evidence files;all62 prior owners preserved;catalog unchanged;goal unfinished',flush=True)
