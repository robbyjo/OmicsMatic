from pathlib import Path
import json,subprocess,sys
from prepare_qtltools_workflow_20261121_106 import R,T,O
from prepare_handover_qtltools_20261121_105 import save
host=sys.argv[1];assert host in {'windows','linux'};out=T/'build/qtltools-workflow-1/packet-checks'/host;jar=T/'build/qtltools-workflow-1/normal-gradle-5/project-build/cli/omicsmatic-0.4.0.jar';reader=T/'tools/literature/qtltools_workflow/verify.py'
def mount(path):return '/mnt/d/'+path.resolve().relative_to(Path('D:/')).as_posix()
if host=='windows':command=['C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe','-X','utf8','-B',str(reader),'--out',str(out),'--restore','--jar',str(jar)]
else:command=['wsl.exe','-d','JLinAlg-Omics-PyMOL-20261026','-u','root','--','python3','-B',mount(reader),'--out',mount(out),'--jar',mount(jar)]
save(O/('reader-'+host+'.STARTED.json'),dict(command=command,scope='saved source/control bytes and declared scope only;no model'))
with (O/('reader-'+host+'.stdout')).open('xb') as stdout,(O/('reader-'+host+'.stderr')).open('xb') as stderr:p=subprocess.run(command,cwd=T,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=900)
save(O/('reader-'+host+'.PROCESS.json'),dict(exit_code=p.returncode));print(host,'reader exit',p.returncode,flush=True)
print(((out/'RESULT.json') if p.returncode==0 else (O/('reader-'+host+'.stderr'))).read_text()[:2500]);raise SystemExit(p.returncode)
