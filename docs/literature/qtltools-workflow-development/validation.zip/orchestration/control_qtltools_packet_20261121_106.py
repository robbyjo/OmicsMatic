from pathlib import Path
import copy,json,shutil,subprocess
from prepare_qtltools_workflow_20261121_106 import R,T,O
from prepare_handover_qtltools_20261121_105 import JAR as PREVIOUS,pin,save
B=T/'build/qtltools-workflow-1';F=Path('docs/literature/qtltools-workflow-development');Q=T/F;C=B/'packet-controls-1';C.mkdir();profile=json.loads((Q/'PROFILE.json').read_bytes());results={}
protected={name:pin((T/name).read_bytes()) for name in [*profile['source_inputs'],*profile['canonical_unchanged'],*[str(F/name) for name in profile['files']],str(F/'PROFILE.json')]}
for label in ['changed-archive','changed-source','promoted-catalog-credit','wrong-producer']:
    folder=C/label;folder.mkdir()
    if label=='wrong-producer':root=T
    else:
        root=folder/'checkout';root.mkdir()
        for name in protected:
            target=root/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(T/name,target)
        if label=='changed-archive':
            path=root/F/'controls.zip';raw=bytearray(path.read_bytes());raw[len(raw)//2]^=1;path.write_bytes(raw)
        elif label=='changed-source':
            with (root/'src/main/java/org/jlinalg/cli/QtltoolsWorkflowRuntime.java').open('ab') as stream:stream.write(b'\n// deliberately changed source\n')
        else:
            changed=copy.deepcopy(profile);changed['new_catalog_credit']=1;changed['catalog_admitted']=True;(root/F/'PROFILE.json').write_text(json.dumps(changed)+'\n',encoding='utf-8')
    command=['C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe','-X','utf8','-B',str(T/'tools/literature/qtltools_workflow/verify.py'),'--root',str(root),'--out',str(folder/'result')]
    if label=='wrong-producer':command+=['--jar',str(PREVIOUS)]
    save(folder/'STARTED.json',dict(command=command,expected_exit_code=2))
    with (folder/'stdout').open('xb') as stdout,(folder/'stderr').open('xb') as stderr:p=subprocess.run(command,cwd=T,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=180)
    reason=(folder/'result/FAILURE.txt').read_text().strip();expected={'changed-archive':'Changed packet file: controls.zip','changed-source':'Changed source/canonical','promoted-catalog-credit':'Different admission/test scope','wrong-producer':'Supply the exact qualified normal JAR'}[label]
    assert p.returncode==2 and expected in reason,(label,p.returncode,reason);results[label]=dict(exit_code=p.returncode,refused=True,reason=reason);save(folder/'PROCESS.json',dict(exit_code=p.returncode))
for name,wanted in protected.items():assert pin((T/name).read_bytes())==wanted,name
save(C/'RESULT.json',results);save(O/'PACKET-NEGATIVE-CONTROLS.json',results)
reasons={
'child-exit':'Original child wait/exit record contradicts','child-wait':'Original child wait/exit record contradicts','foreign-parent':'Owned child,parent,closure or working-directory binding differs','foreign-closure-group':'Owned child,parent,closure or working-directory binding differs','locale':'Original declared locale/thread environment differs','executable-hash':'Original binary differs from selected profile','scientific-library-hash':'Missing qualified scientific-library identity','arguments':'Original arguments differ from typed request','source-worker':'Changed captured QTLtools source resource','effective-seed':'Effective request differs','null-kind':'Null/model result-kind classification differs','nonfinite-fitted-p':'Nonfinite original fitted result','incomplete-quan-stats':'Incomplete or undeclared edition-specific quan statistics','fdensity-count':'fdensity output differs from complete native recomputation'}
for label,expected in reasons.items():
    message=(B/'current-integrity-controls-1/refusals'/label/'stderr').read_text();assert expected in message,(label,message[-2200:])
save(O/'ACTUAL-INTEGRITY-REFUSAL-REASONS.json',dict(status='PASS_ALL14_ACTUAL_REFUSALS_HIT_THE_INTENDED_GUARDS',reasons=reasons))
print('PASS:four real source/archive/admission/producer packet refusals;all14 actual CLI refusals hit intended guards;current bytes unchanged',flush=True)
