from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,http.server,json,os,subprocess,threading,time
R=Path('/mnt/d/projects/JLinAlg');B=R/'build/literature-review/rsem-runtime'
p=argparse.ArgumentParser();p.add_argument('--name',required=True);p.add_argument('--versions',nargs='+',default=['1.3.3','1.2.28','1.3.0','1.3.1','1.3.2']);args=p.parse_args()
assert __import__('re').fullmatch(r'input-audit-original-[a-z0-9-]+',args.name)
assert set(args.versions)<=set(['1.2.28','1.3.0','1.3.1','1.3.2','1.3.3']) and len(set(args.versions))==len(args.versions)
O=B/args.name;O.mkdir(exist_ok=False)
BASE=Path('/opt')/('omicsmatic-rsem-'+args.name+'-20261101-1');BASE.mkdir(exist_ok=False)
for v in args.versions:(BASE/v).mkdir(exist_ok=False)
old=json.loads((B/'source-built-original-matrix-4/observed.json').read_text());native=json.loads((B/'input-audit-native-matrix-1/observed.json').read_text())
CANDIDATE=B/'input-audit-native-matrix-1/omicsmatic-0.3.7.jar';CLASSES=B/'input-audit-protocol-classes-1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,value):p.write_text(json.dumps(value,indent=2)+'\n')
assert sha(CANDIDATE)==native['candidate_sha256'];assert old['status']=='passed-five-exact-source-builds-and-bound-original-controls'
frozen=dict(native['source_sha256']);frozen['tools/literature/rsem-reference/InputAuditProtocol.java']=sha(R/'tools/literature/rsem-reference/InputAuditProtocol.java')
events=[]
class Handler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        events.append(dict(path=self.path,time_utc=datetime.now(timezone.utc).isoformat()))
        write(O/'unexpected-reference-requests.json',events)
        self.send_response(404);self.end_headers();self.wfile.write(b'No reference is served by this controlled monitor')
    def log_message(self,*unused):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
uri='http://127.0.0.1:'+str(server.server_port)+'/reference-must-not-be-fetched'
pending=list(args.versions);active={};finished={};failed=False
def state():
    write(O/'running.json',dict(controller_Linux_pid=os.getpid(),single_WSL_session=True,candidate_sha256=native['candidate_sha256'],controlled_uri=uri,unexpected_reference_requests=len(events),
        active={v:dict(Linux_pid=x['process'].pid,confirmed_running=x['process'].poll() is None,root=str(x['root'])) for v,x in active.items()},pending=pending,terminal=finished,failed=failed,source_sha256=frozen))
try:
    while pending or active:
        while pending and len(active)<2 and not failed:
            v=pending.pop(0);row=old['versions'][v];root=BASE/v
            command=['/usr/bin/java','-Xmx1024m','-cp',str(CANDIDATE)+':'+str(CLASSES),'org.jlinalg.cli.InputAuditProtocol',v,row['build_home'],row['build_receipt_sha256'],'/opt/jlinalg-saige-dev-1/source/.pixi/envs/default/lib',row['runtime_home']+'/prepare/reference',str(root),uri]
            stream=(O/(v+'.log')).open('wb');child=subprocess.Popen(command,cwd=R,stdout=stream,stderr=subprocess.STDOUT)
            active[v]=dict(process=child,stream=stream,root=root,started=time.monotonic());print('START',v,'LinuxPID',child.pid,flush=True);state()
        for v,item in list(active.items()):
            code=item['process'].poll()
            if code is None:continue
            item['stream'].close();result=dict(exit_code=code,seconds=time.monotonic()-item['started'],root=str(item['root']))
            if code==0:
                raw=(item['root']/'observed.json').read_bytes();(O/(v+'-observed.json')).write_bytes(raw);report=json.loads(raw)
                assert report['candidate_sha256']==native['candidate_sha256'] and len(report['positive'])==9 and len(report['negative'])==6
                assert not report['fresh_compilation_performed'] and not report['fitted_result_admitted'] and not report['public_fitting_workflow_available']
                result.update(status=report['status'],physical_records=report['physical_records'],groups=report['groups'],expected_original_files_compared=report['expected_original_files_compared'])
            else:failed=True;result['status']='failed-retained-no-completion'
            finished[v]=result;del active[v];print('TERMINAL',v,'EXIT',code,flush=True);write(O/'terminal.json',finished);state()
        if failed and not active:break
        state()
        if active:time.sleep(5)
    assert not failed and set(finished)==set(args.versions),finished
    assert not events,events
    for name,expected in frozen.items():assert sha(R/name)==expected,name
    reports=[json.loads((O/(v+'-observed.json')).read_text()) for v in args.versions]
    write(O/'observed.json',dict(status='passed-bound-original-header-decoder-parser-and-lookup-controls',recorded_utc=datetime.now(timezone.utc).isoformat(),candidate_sha256=native['candidate_sha256'],versions=finished,
        positive_cases=9*len(reports),negative_cases=6*len(reports),physical_records=sum(x['physical_records'] for x in reports),groups=sum(x['groups'] for x in reports),expected_original_files_compared=sum(x['expected_original_files_compared'] for x in reports),
        unexpected_reference_requests=0,controlled_uri=uri,single_WSL_session=True,source_sha256=frozen,reopened_prior_source_builds=True,fresh_compilation_performed=False,public_fitting_workflow_available=False,whole_goal_complete=False))
    print('PASS actual original input/lookup/projection controls',len(reports),'profiles',flush=True)
finally:
    server.shutdown();server.server_close();thread.join();state()
