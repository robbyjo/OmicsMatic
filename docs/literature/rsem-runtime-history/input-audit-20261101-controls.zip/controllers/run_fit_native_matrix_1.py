from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess,time,zipfile
R=Path('D:/projects/JLinAlg');B=R/'build/literature-review/rsem-runtime';O=B/'fit-native-matrix-1';O.mkdir(exist_ok=False)
def sha(p):
    with p.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
prod=sorted((R/'src/main/java/org/jlinalg/sequence').glob('Rsem*.java'))+sorted((R/'src/main/java/org/jlinalg/cli').glob('Rsem*.java'));tests=sorted((R/'src/test/java/org/jlinalg/sequence').glob('Rsem*Test.java'))+sorted((R/'src/test/java/org/jlinalg/cli').glob('Rsem*Test.java'));resources=sorted(p for p in (R/'src/test/resources/org/jlinalg/sequence/rsem-reference').glob('*') if p.is_file())+[R/'src/main/resources/META-INF/licenses/RSEM-GPL-3.0.txt',R/'src/main/resources/org/jlinalg/omics/rsem-source-profiles.json',R/'src/main/resources/org/jlinalg/omics/rsem-health/inputs.zip',R/'src/main/resources/org/jlinalg/omics/rsem-setup/decode.cpp'];sources={p.relative_to(R).as_posix():sha(p) for p in [*prod,*tests,*resources]}
candidate=O/'omicsmatic-0.3.7.jar';shutil.copyfile(R/'build/cli/omicsmatic-0.3.7.jar',candidate);candidate_hash=sha(candidate);jdk=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin');runs=[]
with zipfile.ZipFile(B/'source-setup-candidate-5/omicsmatic-0.3.7.jar') as old,zipfile.ZipFile(candidate) as new:
    changed=[n for n in old.namelist() if n not in new.namelist() or old.read(n)!=new.read(n)]
    added=sorted(set(new.namelist())-set(old.namelist()))
    assert not changed,changed
    assert added and all(n.startswith(('org/jlinalg/cli/RsemInputs','org/jlinalg/cli/RsemCramReference','org/jlinalg/cli/RsemAlignmentProjection','org/jlinalg/cli/RsemInputAudit','org/jlinalg/cli/RsemFit')) for n in added),added
    payload=dict(previous_members=len(old.namelist()),changed_existing_members=changed,added_members=added,all_other_predecessor_payload_preserved=True,existing_scientific_payload_unchanged=True)

def run(label,cmd):
    write(O/'running.json',dict(controller_pid=os.getpid(),phase=label,command=cmd));start=time.monotonic()
    with (O/(label+'.stdout')).open('wb') as out,(O/(label+'.stderr')).open('wb') as err:child=subprocess.run(cmd,cwd=R,stdout=out,stderr=err)
    runs.append(dict(label=label,exit_code=child.returncode,seconds=time.monotonic()-start));write(O/'runs.json',runs);print(label,child.returncode,flush=True)
    if child.returncode:raise SystemExit(child.returncode)
strict=O/'strict-classes';strict.mkdir();classes=O/'test-classes';classes.mkdir();run('strict-Java17-compile',[str(jdk/'javac.exe'),'--release','17','-Xlint:all','-Werror','-encoding','UTF-8','-cp',str(candidate),'-d',str(strict),*map(str,prod)]);run('strict-javadoc',[str(jdk/'javadoc.exe'),'--release','17','-Xdoclint:all,-missing','-Werror','-private','-quiet','-encoding','UTF-8','-classpath',str(candidate),'-d',str(O/'javadoc'),*map(str,prod)])
cache=Path('C:/Users/User/.gradle/caches/modules-2/files-2.1');deps=[]
for group,name,version in [('org.junit.jupiter','junit-jupiter-api','5.13.4'),('org.junit.jupiter','junit-jupiter-engine','5.13.4'),('org.junit.platform','junit-platform-commons','1.13.4'),('org.junit.platform','junit-platform-engine','1.13.4'),('org.junit.platform','junit-platform-launcher','1.13.4'),('org.opentest4j','opentest4j','1.3.0'),('org.apiguardian','apiguardian-api','1.1.2')]:
    found=list((cache/group/name/version).glob('*/*.jar'));assert len(found)==1;deps.append(found[0])
names=['org.jlinalg.'+p.relative_to(R/'src/test/java/org/jlinalg').as_posix()[:-5].replace('/','.') for p in tests]
runner='''import java.io.PrintWriter;
import org.junit.platform.engine.discovery.DiscoverySelectors;
import org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder;
import org.junit.platform.launcher.core.LauncherFactory;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;
public final class RsemJUnit {public static void main(String[] args){var listener=new SummaryGeneratingListener();var launcher=LauncherFactory.create();launcher.registerTestExecutionListeners(listener);var request=LauncherDiscoveryRequestBuilder.request();for(String name:new String[]{NAMES})request.selectors(DiscoverySelectors.selectClass(name));launcher.execute(request.build());var s=listener.getSummary();s.printTo(new PrintWriter(System.out,true));s.printFailuresTo(new PrintWriter(System.err,true));if(s.getTestsFoundCount()!=228||s.getTestsFailedCount()!=0||s.getTestsAbortedCount()!=0||s.getTestsSucceededCount()!=228-Long.parseLong(args[0])||s.getTestsSkippedCount()!=Long.parseLong(args[0]))System.exit(1);}}
'''.replace('NAMES',','.join(json.dumps(n) for n in names));(O/'RsemJUnit.java').write_text(runner,encoding='utf-8')
run('compile-exact-package-tests',[str(jdk/'javac.exe'),'--release','17','-Xlint:all','-Werror','-encoding','UTF-8','-cp',';'.join(map(str,[candidate,*deps])),'-d',str(classes),*map(str,tests),str(O/'RsemJUnit.java')])
for p in prod:assert not (classes/'org/jlinalg/sequence'/(p.stem+'.class')).exists()
def linux(p):s=str(p).replace('\\','/');return '/mnt/'+s[0].lower()+s[2:]
profiles={}
for label,prefix,separator,convert in [('Windows21',[str(jdk/'java.exe')],';',str),('Windows25',['C:/Program Files/Common Files/Oracle/Java/javapath/java.exe'],';',str),('Linux21',['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/java'],':',linux)]:
    cp=separator.join(convert(p) for p in [candidate,classes,R/'src/test/resources',*deps]);skips=0 if label=='Linux21' else 19;run(label+'-unit',[*prefix,'-Xmx256m','-cp',cp,'RsemJUnit',str(skips)]);profiles[label]=dict(found=228,passed=228-skips,skipped=skips,existing_sequence_science_tests=111)
for n,h in sources.items():assert sha(R/n)==h,n
assert sha(candidate)==candidate_hash
write(O/'observed.json',dict(status='passed228exact-package-tests-three-JVMs-and-strict-Java17-javadoc',recorded_utc=datetime.now(timezone.utc).isoformat(),candidate_sha256=candidate_hash,source_sha256=sources,runs=runs,profiles=profiles,payload_delta=payload,original_wrappers_separately_validated=True,new_input_decoder_or_fitting_validated=False,protected_input_snapshot_tests_per_JVM=19,CRAM_reference_tests_per_JVM=19,streamed_projection_tests_per_JVM=4,complete_original_parser_populations_compared_per_JVM=478,typed_fit_request_tests_per_JVM=8,complete_fit_output_tests_per_JVM=7,original_complete_fits_audited_per_JVM=22,original_scientific_files_per_JVM=364,public_quantification_CLI_available=False,original_function_vectors_per_JVM=668,full_toolbox_goal_complete=False))
print('PASS228tests;Win209passed19platformskips,Linux228passed0skips;111scienceallpassed;strict17Javadoc;allpriorJARpayloadpreserved;publicfittingunfinished',flush=True)
