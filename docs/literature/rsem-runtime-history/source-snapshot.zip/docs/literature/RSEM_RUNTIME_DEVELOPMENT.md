# RSEM original runtime development

The development source now stages exact original script profiles, captures declared Linux host dependencies and executes the original reference/fitting wrappers through an owned, bounded process context. **There is still no public RSEM fitting command, portable installer, source-to-binary build-provenance verifier or completed scientific runtime-admission workflow. RSEM remains missing in the toolbox inventory.** These are internal components for completing that workflow.

The [runtime validation record](RSEM_RUNTIME_VALIDATION.json) identifies the candidate and evidence. The [alignment/count audit](RSEM_ALIGNMENT_ADMISSION.md), [result audit](RSEM_RESULT_AUDIT.md) and [Java-only result example](../../examples/rsem-native-audit/README.md) remain separate capabilities. Reading an existing result does not run a fit.

## Source identity comes before the version diagnostic

`RsemPayload` has exact original archive/commit identities and script checksums for releases 1.2.28, 1.3.0, 1.3.1, 1.3.2 and 1.3.3. It copies only the declared programs into a NEW payload directory and retains every copied file's hash and the complete payload tree, including modes and empty directories. Additional or altered payload members fail verification.

Original 1.3.2 and 1.3.3 report `RSEM v1.3.1`, as does 1.3.1. This is the original diagnostic, not a substituted release: see the pinned [1.3.3 utility source](https://github.com/deweylab/RSEM/blob/e4dda70e90fb5eb9b831306f1c381f8bbf71ef0e/rsem_perl_utils.pm). The context checks the diagnostic against the selected source profile; the diagnostic alone cannot select or admit a runtime.

**Staging is not proof of compilation provenance.** The tests use the previously built, unmodified original sources and their actual executables. This API does not yet independently establish that an arbitrary supplied binary was compiled from those sources. Its payload and binding records explicitly keep `source_to_build_provenance_verified`, `scientific_runtime_admitted` and `public_fitting_workflow_available` false. Neither record is an admission ticket. Portable setup must establish the source/build chain and the completed scientific admission contract before a public fitting operation is provided.

## Declared host and loader dependencies

`RsemHost` records the actual default Perl import order and complete declared module trees; helpers, configurations and absence states; CPU/kernel/user identity; ELF interpreters and required-library names; RPATH/RUNPATH metadata; declared SONAME search candidates and their absence states; and every accepted `ldd` binding. It retains original reported provider spelling and resolves filesystem aliases before collapsing paths. The copied payload, host files, aliases, permissions, module membership and candidate states are rechecked before and after execution.

The declared library search order is explicit. A new file in an earlier search directory can change a binding even if the previous provider's hash is unchanged. The controls add such a shadow candidate, verify refusal before launch, retain the injected file in the control evidence, and recheck the restored positive context. No global compiler or provider installation is changed.

`RsemElf` bounds ELF headers, program segments, dynamic tables and strings. It preserves RPATH separately from RUNPATH. Reviewed absolute paths and origin-relative paths are supported. Current-directory searches, unknown expansion tokens and unresolved symlink-sensitive dot expressions are refused. Unsupported provider layouts require a reviewed extension; they are not guessed or replaced. This declared capture is not an operating-system sandbox or a claim that arbitrary plugins, configurations or hosts are admitted.

The original whole-compiler-prefix capture exceeded its explicit metadata reservation and remains retained as a failed attempt. The current capture follows declared loader candidates and required providers, alongside complete Perl module populations. New discovery roots may extend the scope; every pre-existing module tree, file and path state must remain identical, and the final expanded population is independently re-read.

## Process execution and required actions

`RsemProcess` owns Linux process groups and retains commands, actual exits, stdout/stderr, observed identities, cleanup status and warnings. It sets per-process address-space, CPU, file-size, open-file and zero-core-dump limits. Wall time, logical workspace bytes/members, process/thread counts and periodically sampled RSS are checked. Sampled RSS is not a hard aggregate memory limit. `RsemRuntime` also supplies an explicit whole-operation deadline covering file/provider checks.

The internal wrapper context accepts declared reference-preparation and alignment-quantification options. Fitting requires an explicit seed/thread count, retained intermediates and disabled BAM generation. Unknown options, shell metacharacters and undeclared aligner/provider modes fail before launch. Typed, persistent scientific input/reference/alignment/output admission remains the next required layer. There is no arbitrary-command public CLI.

**A zero exit admits process execution only.** Complete reference, count, model, theta, alignment and result populations still need their scientific audits. Original validators' exit-zero invalid-input diagnostics remain unsafe to treat as success. A runtime binding does not prove convergence, biological accuracy or whole-paper reproduction.

**Missing or forbidden dependencies: skip dependent fitting.** The original process layer requires Linux Java 17+ and the declared Perl/process/loader helpers, exact original build, matching source-linked decoder and reviewed library providers. Windows Java continues to support the native Java audits; it does not run this original Linux workflow. Use a permitted Linux host or Linux Java within an available WSL installation. Supply the exact source profile and its required providers where installation is permitted. If installation or execution is forbidden, retain the dependency diagnostic and keep dependent fitting skipped. Do not substitute another release or accept the shared version string as proof.

**Changed inputs/providers, invalid options, exceeded budgets or nonzero exits: retain the failed run and use NEW paths.** Read the named exception and process ledger, correct the cause and rerun. Existing outputs are refused and their bytes are preserved. No failed run receives a scientific completion marker. The development protocol retains its intentional changed-payload and injected-library evidence separately from the positive fitting populations.

## Original scientific controls

The packaged fixed synthetic inputs contain six transcripts, four genes, 32 alignable fragments and two unalignable fragments. `expected-science.json` records complete independently captured original file populations, not only selected output columns. The archive and each member are checksummed. The controls are deliberately small method checks, not inferred study sizes or biological calibration.

The checked-in [BoundRuntimeProtocol.java](../../tools/literature/rsem-reference/BoundRuntimeProtocol.java) runs actual original wrappers through the packaged context for all five source releases. There are 35 principal original commands: five version diagnostics, five reference preparations and 25 fitting attempts. Twenty-two fits complete and match all 364 original scientific files byte for byte; preparation matches all 30 reference files. Native readers independently audit the complete gene/isoform tables, counts, models and theta vectors. Three older no-alignment failures remain failures; the 1.3.2/1.3.3 zero-alignment fallback is not backported.

The cases include paired and reverse-stranded alignments, single-end fragment priors, posterior means/credibility intervals/read-start estimation, and no-alignment inputs. Each profile also refuses an undeclared aligner mode, changed scientific-input check, new earlier library candidate and altered payload script. The positive contexts are reverified afterwards. All owned original processes and probes are terminal when the protocol succeeds.

The current exact candidate is tested on Windows Java 21/25 and Linux Java 21. The existing 111 native science tests still pass on every profile. The expanded suite has 153 tests: Windows passes 147 with six explicit Linux-only skips; Linux passes all 153 with zero skips. Strict Java 17 compilation/private Javadoc and preservation of all predecessor JAR members are checked separately. Host-probe counts and repeated ELF inspections describe this declared test host, not universally required software counts.

## Remaining implementation

Complete the source-to-build setup/provenance contract, persistent protected reference/alignment admission, typed fitting requests and complete output/completion verification. Then provide the public command, permitted installation/skip workflow and runnable fitting examples, and validate them end to end against the originals. Genome/annotation preparation, aligner invocation, BAM generation, allele-specific and pRSEM capabilities need their own complete declared provider and scientific controls. The broader 250-paper implementation and semantic-review work remains open.
