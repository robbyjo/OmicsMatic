from pathlib import Path
p=Path('D:/projects/JLinAlg/build/gradle_enrichr_workflow_20261119.py');code=p.read_text()
for old,new in [('build/enrichr-high-impact-1','build/scanpy-high-impact-1'),('workflow-gradle-1','native-gradle-2')]:
 assert old in code;code=code.replace(old,new)
exec(compile(code,str(p)+'-SCANPY-NATIVE-V2','exec'))
