from pathlib import Path
import os,sys,subprocess,json,hashlib,traceback
A=Path('/mnt/d/projects/JLinAlg/build/high-impact-stats-1');R=Path('/mnt/d/projects/JLinAlg');B=A/'build/scanpy-high-impact-1';O=B/'reference-captures-2';O.mkdir(exist_ok=False)
old=Path('/var/tmp/omicsmatic-scdrs-reference-2/environment');modern=json.loads((B/'runtime-current-1/COMPLETED.json').read_bytes());assert modern['status']=='PASS_SCANPY_1130_ISOLATED_CPU_RUNTIME_IMPORTS_ONLY'
def inventory(root):
 result={}
 for parent,dirs,files in os.walk(root,followlinks=False):
  for name in list(dirs)+files:
   p=Path(parent)/name;relative=p.relative_to(root).as_posix()
   if p.is_symlink():result[relative]=dict(link=os.readlink(p));continue
   if p.is_file():
    with p.open('rb') as f:result[relative]=dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
 return result
def save(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
before=inventory(old);save('old-before.json',before);print('Old runtime inventory',len(before),flush=True)
try:
 for version,python in [('1.9.3',str(old/'bin/python')),('1.13.0',modern['python'])]:
  cache=O/('private-'+version);cache.mkdir()
  env=dict(modern['clean_environment'],HOME=str(cache),TMPDIR=str(cache),XDG_CACHE_HOME=str(cache/'cache'),XDG_CONFIG_HOME=str(cache/'config'),NUMBA_CACHE_DIR=str(cache/'numba'),MPLCONFIGDIR=str(cache/'matplotlib'),PYTHONHASHSEED='0')
  for n in ['cache','config','numba','matplotlib']:(cache/n).mkdir()
  p=subprocess.run([python,'-I','-B','/mnt/d/projects/JLinAlg/build/capture_scanpy_primitive_cases_v2_20261119.py',str(O/version),version],cwd=O,env=env,capture_output=True,timeout=600)
  (O/(version+'.stdout')).write_bytes(p.stdout);(O/(version+'.stderr')).write_bytes(p.stderr);print(version,p.returncode,p.stdout.decode(errors='replace')[-1000:],p.stderr.decode(errors='replace')[-1000:],flush=True);assert p.returncode==0
finally:
 after=inventory(old);save('old-after.json',after);assert before==after,'Read-only historical runtime changed; do not refresh old hashes'
save('COMPLETED.json',dict(status='PASS_TWO_ORIGINAL_SCANPY_PRIMITIVE_REFERENCE_CAPTURES',old_runtime_files_unchanged=len(before),profiles={v:json.loads((O/v/'REFERENCE.json').read_bytes())['case_count'] for v in ['1.9.3','1.13.0']},author_runtime_executed=False,whole_goal_complete=False));print('PASS TWO ORIGINAL REFERENCES',flush=True)
