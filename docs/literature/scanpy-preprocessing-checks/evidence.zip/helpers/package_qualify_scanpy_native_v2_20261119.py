from pathlib import Path
import subprocess,zipfile,json,hashlib,shutil,xml.etree.ElementTree as ET
R=Path('D:/projects/JLinAlg');A=R/'build/high-impact-stats-1';B=A/'build/scanpy-high-impact-1';O=B/'native-package-2';O.mkdir(exist_ok=False)
normal=B/'native-gradle-2/project-build/cli/omicsmatic-0.4.0.jar';base=A/'build/enrichr-high-impact-1/workflow-gradle-2/project-build/cli/omicsmatic-0.4.0.jar';assert normal.is_file()
def pinraw(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def pin(p):
 with p.open('rb') as f:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
def save(n,v):(O/n).write_bytes((json.dumps(v,indent=2)+'\n').encode())
payload={};oldclasses={};newclasses={};helpers={}
with zipfile.ZipFile(base) as before,zipfile.ZipFile(normal) as after:
 oldnames={n for n in before.namelist() if n.endswith('.class')};newnames={n for n in after.namelist() if n.endswith('.class')};assert oldnames<=newnames
 for name in sorted(oldnames):
  assert before.read(name)==after.read(name),'Existing class payload changed: '+name
  if name.startswith('org/jlinalg/sequence/SeuratPreprocessing'):payload[name]=after.read(name);oldclasses[name]=pinraw(payload[name])
 for name in sorted(newnames-oldnames):
  assert name.startswith('org/jlinalg/singlecell/ScanpyPreprocessing'),name
  payload[name]=after.read(name);newclasses[name]=pinraw(payload[name])
 for name in after.namelist():
  lower=name.lower()
  if name.startswith('org/jlinalg/omics/scanpy-preprocessing/licenses/') or ('seurat' in lower and ('license' in lower or 'notice' in lower) and not name.endswith('/')):
   payload[name]=after.read(name)
  if name.startswith('org/jlinalg/cli/SimpleJson') and name.endswith('.class'):helpers[name]=after.read(name)
 print('Retained license files',[n for n in payload if not n.endswith('.class')],flush=True)
 assert any('seurat' in n.lower() and ('license' in n.lower() or 'notice' in n.lower()) for n in payload),'Need the existing Seurat MIT notices before export'
payload['META-INF/LICENSE-OmicsMatic-GPL-3.0.txt']=(A/'LICENSE').read_bytes();payload['META-INF/MANIFEST.MF']=b'Manifest-Version: 1.0\nImplementation-Title: OmicsMatic Scanpy preprocessing development component\nImplementation-Version: 0.4.0-development\n\n'
component=O/'omicsmatic-scanpy-preprocessing-development.jar'
with zipfile.ZipFile(component,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,raw in sorted(payload.items()):
  info=zipfile.ZipInfo(n,date_time=(2026,11,19,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,raw)
only=O/'test-only'
for p in (B/'native-build-2/classes/org/jlinalg/cli').glob('ScanpyPreprocessingTest*.class'):
 t=only/'org/jlinalg/cli'/p.name;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(p.read_bytes())
for n,raw in helpers.items():p=only/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
fixture=A/'src/test/resources/org/jlinalg/singlecell/scanpy-preprocessing/reference-20261119.zip';target=only/'org/jlinalg/singlecell/scanpy-preprocessing/reference-20261119.zip';target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(fixture.read_bytes())
range_fixture=A/'src/test/resources/org/jlinalg/singlecell/scanpy-preprocessing/range-boundaries-20261119.zip';(target.parent/range_fixture.name).write_bytes(range_fixture.read_bytes())
assert not list(only.rglob('ScanpyPreprocessing.class')) and not list(only.rglob('SeuratPreprocessing*.class'))
def run(label,args):
 p=subprocess.run([str(x) for x in args],cwd=A,capture_output=True);(O/(label+'.stdout')).write_bytes(p.stdout);(O/(label+'.stderr')).write_bytes(p.stderr);print(label,p.returncode,p.stdout.decode(errors='replace')[-300:],p.stderr.decode(errors='replace')[-2000:],flush=True);assert p.returncode==0,label
jdk=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin');java25=Path('C:/Program Files/Java/jdk-25/bin/java.exe');junit=A/'build/nfcore-atacseq121-1/linux-test-runtime-1/junit-platform-console-standalone-1.13.4.jar'
def linux(p):return '/mnt/d/'+str(p).replace('\\','/').split('D:/',1)[1]
tests=[]
for label,prefix,jarpath,cp,report in [
 ('windows21',[jdk/'java.exe'],junit,str(component)+';'+str(only),O/'reports-windows21'),
 ('windows25',[java25],junit,str(component)+';'+str(only),O/'reports-windows25'),
 ('linux21',['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/java'],linux(junit),linux(component)+':'+linux(only),linux(O/'reports-linux21'))]:
 run('junit-'+label,prefix+['-jar',jarpath,'execute','--class-path',cp,'--select-class','org.jlinalg.cli.ScanpyPreprocessingTest','--details','summary','--disable-ansi-colors','--reports-dir',report])
 totals={k:0 for k in ['tests','failures','errors','skipped']}
 for p in (O/('reports-'+label)).glob('TEST-*.xml'):
  x=ET.parse(p).getroot()
  for k in totals:totals[k]+=int(x.get(k,'0'))
 assert totals==dict(tests=426,failures=0,errors=0,skipped=0),(label,totals);tests.append(dict(host=label,**totals))
example=A/'examples/scanpy-native/ScanpyNativeExample.java';run('example-javac',[jdk/'javac.exe','--release','17','-encoding','UTF-8','-cp',component,'-d',O/'example-classes',example])
for label,prefix,cp in [('windows21',[jdk/'java.exe'],str(O/'example-classes')+';'+str(component)),('windows25',[java25],str(O/'example-classes')+';'+str(component)),('linux21',['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/java'],linux(O/'example-classes')+':'+linux(component))]:
 for version in ['1.9.3','1.13.0']:run('example-'+label+'-'+version,prefix+['-cp',cp,'ScanpyNativeExample',version])
assert json.loads((B/'source-census-1/CENSUS.json').read_bytes())==json.loads((B/'source-census-linux-1/CENSUS.json').read_bytes())
sources=[A/'src/main/java/org/jlinalg/singlecell/ScanpyPreprocessing.java',A/'src/test/java/org/jlinalg/cli/ScanpyPreprocessingTest.java',A/'tools/literature/scanpy_source_roles.py',example,A/'examples/scanpy-native/README.md']
save('COMPLETED.json',dict(status='PASS_SCANPY_NATIVE_418_ORIGINAL_CASES_THREE_JVMS_AND_ISOLATED_PACKAGE',normal_candidate=pin(normal),component=pin(component),tests=tests,original_reference_cases=418,old_one_cell_source_errors_retained=10,production_fallback_classpath=False,existing_class_payloads_unchanged=len(oldnames),added_class_payloads=newclasses,shared_container_class_payloads=oldclasses,component_payloads={n:pinraw(b) for n,b in payload.items()},sources={p.relative_to(A).as_posix():pin(p) for p in sources},source_census_windows_linux_identical=True,example_executions=6,catalog_admitted=False,new_family_credit=0,whole_goal_complete=False))
print('PASS SCANPY QUALIFIED',pin(component),'existing classes unchanged',len(oldnames),'added',len(newclasses),flush=True)
