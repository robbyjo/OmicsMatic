from pathlib import Path
import json,hashlib,zipfile,numpy as np
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');B=A/'build/scanpy-high-impact-1';O=B/'fixture-1';O.mkdir(exist_ok=False)
target=A/'src/test/resources/org/jlinalg/singlecell/scanpy-preprocessing';target.mkdir(parents=True,exist_ok=True);(target/'.gitattributes').write_bytes(b'*.zip -text\n')
payload={};expectations={}
def finite(v):
 if isinstance(v,(list,tuple)):return all(finite(x) for x in v)
 if isinstance(v,dict):return all(finite(x) for x in v.values())
 return v not in ['NaN','Infinity','-Infinity'] if isinstance(v,str) else True
with np.errstate(all='ignore'):
 for version in ['1.9.3','1.13.0']:
  path=B/'reference-captures-2'/version/'REFERENCE.json';raw=path.read_bytes();source=json.loads(raw);assert source['case_count']==201 and source['source_errors']==(10 if version=='1.9.3' else 0);payload[version+'/REFERENCE.json']=raw
  for i,c in enumerate(source['cases']):
   admissible=c['status']=='RETURNED' and finite(c.get('result',{}));detail={}
   if c['operation']=='normalize_total':
    assert c['actual_evaluated_dtype']=='float64'
    dense=np.zeros(c['shape'],dtype=np.float64)
    for row in range(c['shape'][0]):
     for k in range(c['indptr'][row],c['indptr'][row+1]):dense[row,c['indices'][k]]=float(c['data'][k])
    totals=dense.sum(axis=1);subset=np.ones(c['shape'][1],dtype=bool)
    if c['options'].get('exclude_highly_expressed',False):subset=(dense>totals[:,None]*c['options']['max_fraction']).sum(axis=0)==0
    denom=dense[:,subset].sum(axis=1);given=c['options'].get('target_sum');effective=np.median(denom[denom>0]) if given is None else given
    admissible=admissible and bool(np.isfinite(denom).all()) and bool(np.isfinite(effective)) and effective>0
    detail=dict(excluded_features=(~subset).tolist(),effective_target=float(effective) if np.isfinite(effective) else 'NaN' if np.isnan(effective) else 'Infinity')
   expectations[version+'/'+str(i)]=dict(analysis_admissible=bool(admissible),**detail)
payload['CONTRACT-EXPECTATIONS.json']=(json.dumps(expectations,indent=2,allow_nan=False)+'\n').encode()
for version,prefix in [('1.9.3',B/'arithmetic-source-intake-1'),('1.13.0',B/'runtime-current-1/wheels')]:
 if version=='1.9.3':wheels=list(prefix.glob('scanpy-1.9.3-*.whl'))
 else:wheels=list(prefix.glob('scanpy-1.13.0-*.whl'))+list(prefix.glob('fast_array_utils-*.whl'))
 for wheel in wheels:
  with zipfile.ZipFile(wheel) as z:
   licenses=[n for n in z.namelist() if not n.endswith('/') and (n.lower().endswith('/license') or '/licenses/' in n.lower())]
   assert licenses,wheel
   for name in licenses:
    raw=z.read(name);dest=A/'src/main/resources/org/jlinalg/omics/scanpy-preprocessing/licenses'/version/wheel.stem/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
    payload['licenses/'+version+'/'+wheel.stem+'/'+name]=raw
with zipfile.ZipFile(target/'reference-20261119.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,raw in sorted(payload.items()):
  info=zipfile.ZipInfo(name,date_time=(2026,11,19,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,raw)
proof=dict(status='PASS402_ORIGINAL_SCANPY_CASES_AND_INDEPENDENT_ADMISSION_EXPECTATIONS_FROZEN',profiles=['1.9.3','1.13.0'],cases=402,payloads={n:dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()) for n,raw in payload.items()},native_qualified=False,new_family_credit=0)
(O/'COMPLETED.json').write_bytes((json.dumps(proof,indent=2)+'\n').encode());print('PASS fixture',len(payload),'payloads',len(expectations),'expectations',flush=True)
