from pathlib import Path
import os,subprocess,json,hashlib
A=Path('/mnt/d/projects/JLinAlg/build/high-impact-stats-1');B=A/'build/scanpy-high-impact-1';O=B/'range-reference-1';O.mkdir(exist_ok=False)
modern=json.loads((B/'runtime-current-1/COMPLETED.json').read_bytes());old=Path('/var/tmp/omicsmatic-scdrs-reference-2/environment')
def inventory():
 d={}
 for parent,dirs,files in os.walk(old,followlinks=False):
  for name in list(dirs)+files:
   p=Path(parent)/name;relative=p.relative_to(old).as_posix()
   if p.is_symlink():d[relative]=dict(link=os.readlink(p));continue
   if p.is_file():
    with p.open('rb') as f:d[relative]=dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
 return d
before=inventory();assert before==json.loads((B/'reference-captures-2/old-after.json').read_bytes());print('Range baseline old runtime unchanged',len(before),flush=True)
for v,python in [('1.9.3',old/'bin/python'),('1.13.0',Path(modern['python']))]:
 cache=O/('cache-'+v);cache.mkdir();env=dict(modern['clean_environment'],HOME=str(cache),TMPDIR=str(cache),NUMBA_CACHE_DIR=str(cache/'numba'),MPLCONFIGDIR=str(cache/'matplotlib'),XDG_CACHE_HOME=str(cache/'cache'),XDG_CONFIG_HOME=str(cache/'config'))
 for n in ['numba','matplotlib','cache','config']:(cache/n).mkdir()
 p=subprocess.run([str(python),'-I','-B','/mnt/d/projects/JLinAlg/build/capture_scanpy_range_cases_20261119.py',str(O/v),v],cwd=O,env=env,capture_output=True,timeout=300);(O/(v+'.stdout')).write_bytes(p.stdout);(O/(v+'.stderr')).write_bytes(p.stderr);print(v,p.returncode,p.stdout.decode(errors='replace')[-300:],p.stderr.decode(errors='replace')[-1000:],flush=True);assert p.returncode==0
after=inventory();assert after==before
(O/'COMPLETED.json').write_text(json.dumps(dict(status='PASS16_ORIGINAL_SCANPY_RANGE_BOUNDARIES',old_runtime_entries_unchanged=len(after),profiles=['1.9.3','1.13.0'],cases=16,original_source_patched=False),indent=2)+'\n');print('PASS ORIGINAL RANGE BOUNDARIES',flush=True)
