from pathlib import Path
import sys,json,warnings,contextlib,io,hashlib,importlib.metadata as md,inspect
import numpy as np
import scipy.sparse as sp
import scanpy as sc
from anndata import AnnData
out=Path(sys.argv[1]);version=sys.argv[2];assert not out.exists();out.mkdir();assert sc.__version__==version
def encode(x):
 if isinstance(x,np.ndarray):return encode(x.tolist())
 if sp.issparse(x):return encode(x.toarray())
 if isinstance(x,(list,tuple)):return [encode(v) for v in x]
 if isinstance(x,dict):return {str(k):encode(v) for k,v in x.items()}
 if isinstance(x,(np.floating,float)) and not np.isfinite(x):return 'NaN' if np.isnan(x) else 'Infinity' if x>0 else '-Infinity'
 if isinstance(x,np.generic):return x.item()
 return x
matrices={
 'mixed':[[1,0,3,4,0,2,7],[4,2,1,1,0,2,7],[0,0,0,0,0,0,0],[3,1,2,0,0,2,7],[2,4,6,2,0,2,7],[0,0,0,0,0,0,0]],
 'all-zero':[[0,0,0],[0,0,0],[0,0,0]],
 'singleton':[[1,2,0]],
 'signed': [[-10,0,4],[1,0,4],[1,0,4],[1,0,4],[1,0,4]],
 'overflow':[[1e308,1e308,0],[1e308,0,1e308],[0,1e308,1e308]],
 'tiny':[[1e-300,2e-300,0],[0,3e-300,1e-300],[2e-300,0,1e-300]],
 'large-offset':[[1e16,2,1],[1e16+2,2,0],[1e16+4,2,3],[1e16+8,2,2]],
 'log-domain': [[-1,-2,-.5],[0,1,3],[.25,.5,1]],
}
cases=[]
def capture(name,storage,op,opts,values,explicit=False):
 dense=np.array(values,dtype=np.float64)
 if storage=='csr':
  if explicit:
   x=sp.csr_matrix((dense.ravel(),np.tile(np.arange(dense.shape[1]),dense.shape[0]),np.arange(0,dense.size+1,dense.shape[1])),shape=dense.shape)
  else:x=sp.csr_matrix(dense)
 else:x=dense.copy()
 original=x.copy();before=original.toarray().copy() if sp.issparse(original) else original.copy()
 input_csr=original if sp.issparse(original) else sp.csr_matrix((dense.ravel(),np.tile(np.arange(dense.shape[1]),dense.shape[0]),np.arange(0,dense.size+1,dense.shape[1])),shape=dense.shape)
 record=dict(name=name,storage=storage,operation=op,options=opts,shape=list(dense.shape),indptr=input_csr.indptr.tolist(),indices=input_csr.indices.tolist(),data=encode(input_csr.data),explicit_zeros=explicit,input_dtype='float64')
 stream=io.StringIO()
 with warnings.catch_warnings(record=True) as ws,contextlib.redirect_stdout(stream),np.errstate(all='warn'):
  warnings.simplefilter('always')
  try:
   if op=='normalize_total':
    a=AnnData(x.copy(),dtype=np.float64) if version=='1.9.3' else AnnData(x.copy());assert a.X.dtype==np.float64;record['actual_evaluated_dtype']=str(a.X.dtype)
    if version=='1.13.0':res=sc.pp.normalize_total(a,out=True,**opts);result=dict(values=res.normalized,norm_factor=res.norm_factor)
    else:res=sc.pp.normalize_total(a,inplace=False,**opts);result=dict(values=res['X'],norm_factor=res['norm_factor'])
   elif op=='log1p':result=dict(values=sc.pp.log1p(x,copy=True,**opts))
   elif op=='scale':
    if version=='1.13.0':
     a=AnnData(x.copy());assert a.X.dtype==np.float64;res=sc.pp.scale(a,out=True,**opts);result=dict(values=res.scaled,mean=res.mean,std=res.std)
    else:
     y,mean,std=sc.pp.scale(x,copy=True,return_mean_std=True,**opts);result=dict(values=y,mean=mean,std=std)
   elif op=='filter_cells':
    mask,metric=sc.pp.filter_cells(x,inplace=False,**opts);result=dict(mask=mask,metric=metric)
   elif op=='filter_genes':
    mask,metric=sc.pp.filter_genes(x,inplace=False,**opts);result=dict(mask=mask,metric=metric)
   record.update(status='RETURNED',result=encode(result))
  except Exception as e:record.update(status='ERROR',error_class=type(e).__name__,error=str(e))
  record['warnings']=[dict(category=w.category.__name__,message=str(w.message)) for w in ws]
 record['stdout']=stream.getvalue();assert np.array_equal(before,original.toarray() if sp.issparse(original) else original,equal_nan=True)
 cases.append(record)
for name,values in matrices.items():
 for storage in ['dense','csr']:
  if name not in ['signed','log-domain','large-offset']:
   for opts in [dict(target_sum=None),dict(target_sum=10000.0),dict(target_sum=1000.0,exclude_highly_expressed=True,max_fraction=.4),dict(target_sum=10.0,exclude_highly_expressed=True,max_fraction=0.0)]:capture(name,storage,'normalize_total',opts,values)
  if name not in ['signed','overflow','large-offset']:
   for base in [None,2.0,10.0,.5]:capture(name,storage,'log1p',dict(base=base),values)
  if name not in ['log-domain']:
   for center,cap in [(True,None),(True,1.0),(False,1.0),(False,-.5),(True,-.5)]:capture(name,storage,'scale',dict(zero_center=center,max_value=cap),values)
  if name in ['mixed','all-zero','singleton']:
   for opts in [dict(min_counts=3.0),dict(max_counts=3.0),dict(min_genes=2),dict(max_genes=2)]:capture(name,storage,'filter_cells',opts,values)
   for opts in [dict(min_counts=3.0),dict(max_counts=3.0),dict(min_cells=2),dict(max_cells=2)]:capture(name,storage,'filter_genes',opts,values)
for op,opts in [('normalize_total',dict(target_sum=10.0)),('log1p',dict(base=2.0)),('scale',dict(zero_center=False,max_value=-.5))]:capture('explicit-zero','csr',op,opts,matrices['mixed'],True)
modules={}
import scanpy.preprocessing._normalization as normalization
for mod in [normalization,sc.pp.log1p,sc.pp.scale]:
 p=Path(inspect.getsourcefile(mod));modules[str(p)]=dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
if version=='1.13.0':
 import fast_array_utils.stats as stats
 functions={}
 for p in Path(stats.__file__).parent.rglob('*.py'):
  relative=p.relative_to(Path(stats.__file__).parent).as_posix();target=out/'fast-array-utils-stats'/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes());functions[relative]=dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 (out/'FAST-ARRAY-UTILS-SOURCES.json').write_text(json.dumps(dict(version=md.version('fast-array-utils'),sources=functions),indent=2)+'\n')
versions={p:md.version(p) for p in ['scanpy','numpy','scipy','anndata','numba','pandas','scikit-learn']}
payload=dict(status='PASS_ORIGINAL_SCANPY_PRIMITIVE_REFERENCE_CAPTURES_ONLY',version=version,versions=versions,source_modules=modules,cases=cases,case_count=len(cases),source_errors=sum(c['status']=='ERROR' for c in cases),author_runtime_executed=False,whole_goal_complete=False)
(out/'REFERENCE.json').write_text(json.dumps(payload,indent=2,allow_nan=False)+'\n');print(json.dumps(dict(version=version,cases=len(cases),source_errors=payload['source_errors'])),flush=True)
