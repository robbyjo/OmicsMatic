from pathlib import Path
import sys,json,warnings,contextlib,io
import numpy as np,scipy.sparse as sp,scanpy as sc
from anndata import AnnData
O=Path(sys.argv[1]);version=sys.argv[2];O.mkdir(exist_ok=False)
def encode(v):
 if isinstance(v,np.ndarray):return encode(v.tolist())
 if isinstance(v,(list,tuple)):return [encode(x) for x in v]
 if isinstance(v,dict):return {k:encode(x) for k,x in v.items()}
 if isinstance(v,(np.floating,float)) and not np.isfinite(v):return 'NaN' if np.isnan(v) else 'Infinity' if v>0 else '-Infinity'
 if isinstance(v,np.generic):return v.item()
 return v
cases=[];expect={}
for name,data,target in [('reciprocal-overflow',[[.01,.02],[.03,.01]],1e307),('tiny-target',[[1.,2.],[2.,1.]],float(np.nextafter(0.,1.))),('positive-factor-underflow',[[1e-300,2e-300],[3e-300,1e-300]],1e308),('large-valid-target',[[1.,2.],[3.,4.]],1e308)]:
 for storage in ['dense','csr']:
  dense=np.array(data,dtype=np.float64);x=sp.csr_matrix(dense) if storage=='csr' else dense.copy();a=AnnData(x.copy(),dtype=np.float64) if version=='1.9.3' else AnnData(x.copy());assert a.X.dtype==np.float64
  stream=io.StringIO()
  with warnings.catch_warnings(record=True) as ws,contextlib.redirect_stdout(stream),np.errstate(all='warn'):
   warnings.simplefilter('always')
   if version=='1.9.3':r=sc.pp.normalize_total(a,target_sum=target,inplace=False);values=r['X'];factors=r['norm_factor']
   else:r=sc.pp.normalize_total(a,target_sum=target,out=True);values=r.normalized;factors=r.norm_factor
  csr=sp.csr_matrix(dense);i=len(cases)
  cases.append(dict(name=name,storage=storage,operation='normalize_total',options=dict(target_sum=target),shape=list(dense.shape),indptr=csr.indptr.tolist(),indices=csr.indices.tolist(),data=csr.data.tolist(),input_dtype='float64',actual_evaluated_dtype=str(a.X.dtype),status='RETURNED',result=encode(dict(values=values.toarray() if sp.issparse(values) else values,norm_factor=factors)),warnings=[dict(category=w.category.__name__,message=str(w.message)) for w in ws],stdout=stream.getvalue()))
  with np.errstate(all='ignore'):
   totals=dense.sum(axis=1);raw_divisor=(totals+(totals==0))/target if version=='1.9.3' else totals/target;effective=np.where(raw_divisor==0,1,raw_divisor) if version=='1.13.0' else raw_divisor
   values_dense=values.toarray() if sp.issparse(values) else values
   lost=(totals>0)&(raw_divisor==0);admissible=bool(np.isfinite(values_dense).all() and np.isfinite(factors).all() and np.isfinite(effective).all() and not lost.any())
  expect[version+'/'+str(i)]=dict(analysis_admissible=admissible,excluded_features=[False,False],effective_target=target,source_divisor_diagnostics=encode(effective),positive_factor_lost=lost.tolist())
(O/'REFERENCE.json').write_text(json.dumps(dict(version=version,cases=cases,case_count=len(cases),source_errors=0,upstream_scientific_functions_patched=False),indent=2,allow_nan=False)+'\n');(O/'EXPECTATIONS.json').write_text(json.dumps(expect,indent=2,allow_nan=False)+'\n');print('PASS RANGE SOURCE',version,len(cases),flush=True)
