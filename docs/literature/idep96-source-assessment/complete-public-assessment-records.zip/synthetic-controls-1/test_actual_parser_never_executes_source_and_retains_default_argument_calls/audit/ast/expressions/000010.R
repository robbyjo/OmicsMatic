function(x) {
    stop("different standalone helper")
    x
}
