reactive({
    stop("must not execute")
    matrix(1)[, ]
})
