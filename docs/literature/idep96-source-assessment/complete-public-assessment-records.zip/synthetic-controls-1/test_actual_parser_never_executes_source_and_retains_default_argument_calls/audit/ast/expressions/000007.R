function(x, y = source("NEVER_READ_DEFAULT.R")) {
    stop("must not execute")
    x
}
