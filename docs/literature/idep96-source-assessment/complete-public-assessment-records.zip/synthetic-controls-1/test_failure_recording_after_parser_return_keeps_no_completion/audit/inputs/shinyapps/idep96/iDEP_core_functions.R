writeLines("SOURCE MUST NOT EXECUTE", "D:/projects/JLinAlg/build/literature-review/monocle-runtime/idep96-static-parser-controls-1/test_failure_recording_after_parser_return_keeps_no_completion/SOURCE-EXECUTION-WOULD-BE-AN-ERROR.txt")

install.packages("NEVER_INSTALL_THIS_AUDIT_CANARY")
detectGroups <- function(x) x
DEG.DESeq2 <- function(x) {stop("different standalone helper");x}
