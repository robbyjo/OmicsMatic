writeLines("SOURCE MUST NOT EXECUTE", "D:/projects/JLinAlg/build/literature-review/monocle-runtime/idep96-static-parser-controls-1/test_failure_after_completion_promotion_revokes_completion/SOURCE-EXECUTION-WOULD-BE-AN-ERROR.txt")

install.packages("NEVER_INSTALL_THIS_AUDIT_CANARY")
detectGroups <- function(x) x
DEG.DESeq2 <- function(x) {stop("different standalone helper");x}
