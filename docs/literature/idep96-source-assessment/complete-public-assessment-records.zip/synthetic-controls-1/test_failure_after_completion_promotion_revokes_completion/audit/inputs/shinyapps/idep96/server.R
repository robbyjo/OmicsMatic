writeLines("SOURCE MUST NOT EXECUTE", "D:/projects/JLinAlg/build/literature-review/monocle-runtime/idep96-static-parser-controls-1/test_failure_after_completion_promotion_revokes_completion/SOURCE-EXECUTION-WOULD-BE-AN-ERROR.txt")

iDEPversion="iDEP 0.96"
maxSamples=200;maxSamplesDefault=30;maxComparisons=50;maxFactors=6
detectGroups <- function(x,sampleInfo=NULL) {stop("must not execute");x}
DEG.DESeq2 <- function(x, y=source("NEVER_READ_DEFAULT.R")) {stop("must not execute");x}
shinyServer(function(input,output,session) {
 readData <- reactive({stop("must not execute");matrix(1)[,]})
})
