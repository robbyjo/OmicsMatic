writeLines("SOURCE MUST NOT EXECUTE", "D:/projects/JLinAlg/build/literature-review/monocle-runtime/idep96-static-parser-controls-1/test_existing_output_is_preserved/SOURCE-EXECUTION-WOULD-BE-AN-ERROR.txt")

iDEPversion="iDEP.96"
numericInput("minCounts",label="CPM",value=0.5)
checkboxInput("noIDConversion",label="ID conversion",value=FALSE)
