writeLines("SOURCE MUST NOT EXECUTE", "D:/projects/JLinAlg/build/literature-review/monocle-runtime/idep96-static-parser-controls-2/test_failure_after_completion_promotion_revokes_completion/SOURCE-EXECUTION-WOULD-BE-AN-ERROR.txt")

iDEPversion="iDEP.96"
numericInput("minCounts",label="CPM",value=0.5)
checkboxInput("noIDConversion",label="ID conversion",value=FALSE)
