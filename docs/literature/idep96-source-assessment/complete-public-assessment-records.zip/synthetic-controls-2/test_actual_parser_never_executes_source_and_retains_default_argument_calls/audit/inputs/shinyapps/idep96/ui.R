writeLines("SOURCE MUST NOT EXECUTE", "D:/projects/JLinAlg/build/literature-review/monocle-runtime/idep96-static-parser-controls-2/test_actual_parser_never_executes_source_and_retains_default_argument_calls/SOURCE-EXECUTION-WOULD-BE-AN-ERROR.txt")

iDEPversion="iDEP.96"
numericInput("minCounts",label="CPM",value=0.5)
checkboxInput("noIDConversion",label="ID conversion",value=FALSE)
