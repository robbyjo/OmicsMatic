writeLines("SOURCE MUST NOT EXECUTE", "D:/projects/JLinAlg/build/literature-review/monocle-runtime/idep96-static-parser-controls-2/test_malformed_R_preserves_actual_parse_error_and_admits_nothing/SOURCE-EXECUTION-WOULD-BE-AN-ERROR.txt")

install.packages("NEVER_INSTALL_THIS_AUDIT_CANARY")
detectGroups <- function(x) x
DEG.DESeq2 <- function(x) {stop("different standalone helper");x}
