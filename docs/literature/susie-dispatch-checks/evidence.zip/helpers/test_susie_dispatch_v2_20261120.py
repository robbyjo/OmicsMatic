from pathlib import Path
p=Path('D:/projects/JLinAlg/build/test_susie_dispatch_20261120.py');source=p.read_text()
source=source.replace("O=B/'tests-1'","O=B/'tests-2'").replace('/tmp/omicsmatic-susie-dispatch-20261120-1','/tmp/omicsmatic-susie-dispatch-20261120-2')
needle="root,jar,classes,junit,resources,reports,archive,*selected=sys.argv[1:]"
assert needle in source;source=source.replace(needle,"root,jar,classes,junit,resources,reports,archive,bundle,*selected=sys.argv[1:]")
needle="'-Domicsmatic.susie.dispatch.test_root='+root,'-jar'"
assert needle in source;source=source.replace(needle,"'-Domicsmatic.susie.dispatch.test_root='+root,'-Djlinalg.scanpy.test.bundle='+bundle,'-jar'")
needle="linux(reports),linux(O/'linux21-test-root.tar'),*selected]"
assert needle in source;source=source.replace(needle,"linux(reports),linux(O/'linux21-test-root.tar'),'/mnt/d/projects/JLinAlg/build/sd-1/build/susie-global-scanpy-reference-1/capture',*selected]")
needle="'-Domicsmatic.susie.dispatch.test_root='+str(O/label),'-jar'"
assert needle in source;source=source.replace(needle,"'-Domicsmatic.susie.dispatch.test_root='+str(O/label),'-Djlinalg.scanpy.test.bundle=D:/projects/JLinAlg/build/sd-1/build/susie-global-scanpy-reference-1/capture','-jar'")
exec(compile(source,__file__+'-ACTUAL-REFERENCE-BUNDLE-SUPPLIED','exec'))
