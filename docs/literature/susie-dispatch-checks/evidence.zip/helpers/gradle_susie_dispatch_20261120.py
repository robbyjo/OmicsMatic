from pathlib import Path
p=Path('D:/projects/JLinAlg/build/gradle_enrichr_workflow_20261119.py');source=p.read_text()
source=source.replace('build/enrichr-high-impact-1','build/susie-dispatch-1')
exec(compile(source,__file__+'-NORMAL-SUSIE-GLOBAL-JAR','exec'))
