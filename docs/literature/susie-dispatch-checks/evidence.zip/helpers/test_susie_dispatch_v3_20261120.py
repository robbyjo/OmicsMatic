from pathlib import Path
p=Path('D:/projects/JLinAlg/build/test_susie_dispatch_20261120.py');source=p.read_text()
changes=[
 ("O=B/'tests-1'","O=B/'tests-3'"),('workflow-gradle-1','workflow-gradle-2'),
 ("'EnrichrWorkflowTest']]","'EnrichrWorkflowTest','SusieWorkflowTest']]"),
 ("selected=['--select-class','org.jlinalg.cli.SusieToolsDispatchTest'","selected=['--select-class','org.jlinalg.cli.SusieWorkflowTest','--select-class','org.jlinalg.cli.SusieToolsDispatchTest'"),
 ('/tmp/omicsmatic-susie-dispatch-20261120-1','/tmp/omicsmatic-susie-dispatch-20261120-3'),
 ("root,jar,classes,junit,resources,reports,archive,*selected=sys.argv[1:]","root,jar,classes,junit,resources,reports,archive,bundle,*selected=sys.argv[1:]"),
 ("'-Domicsmatic.susie.dispatch.test_root='+root,'-jar'","'-Domicsmatic.susie.dispatch.test_root='+root,'-Domicsmatic.susie.workflow.test_root='+root+'/workflow','-Djlinalg.scanpy.test.bundle='+bundle,'-jar'"),
 ("linux(reports),linux(O/'linux21-test-root.tar'),*selected]","linux(reports),linux(O/'linux21-test-root.tar'),'/mnt/d/projects/JLinAlg/build/sd-1/build/susie-global-scanpy-reference-1/capture',*selected]"),
 ("'-Domicsmatic.susie.dispatch.test_root='+str(O/label),'-jar'","'-Domicsmatic.susie.dispatch.test_root='+str(O/label),'-Domicsmatic.susie.workflow.test_root='+str(O/label/'workflow'),'-Djlinalg.scanpy.test.bundle=D:/projects/JLinAlg/build/sd-1/build/susie-global-scanpy-reference-1/capture','-jar'"),
 ("assert changed==['org/jlinalg/cli/JLinAlgCli.class'],changed","assert set(changed)=={'org/jlinalg/cli/JLinAlgCli.class','org/jlinalg/cli/SusieWorkflowCli.class'},changed"),
 ("(O/'JLinAlgCli.before.class').write_bytes(before.read(changed[0]));(O/'JLinAlgCli.after.class').write_bytes(after.read(changed[0]))",
  "\n    for member in changed:\n        (O/(Path(member).stem+'.before.class')).write_bytes(before.read(member));(O/(Path(member).stem+'.after.class')).write_bytes(after.read(member))"),
 ("r['totals']['tests']>=49","r['totals']['tests']==173"),
 ('scientific_worker_bytecode_changed=False','model_fitting_worker_changed=False,replay_control_bytecode_changed=True')]
for old,new in changes:
    assert old in source,old;source=source.replace(old,new)
exec(compile(source,__file__+'-QUALIFIED-REPLAY-GUARD-AND-ORIGINAL-CONTRACTS','exec'))
