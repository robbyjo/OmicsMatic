from pathlib import Path
import concurrent.futures,hashlib,importlib.util,json,os,subprocess,sys
R=Path('D:/projects/JLinAlg');A=R/'build/high-impact-stats-1';B=A/'build/susie-dispatch-1';O=B/'predecessor-1';O.mkdir(exist_ok=False)
H=R/'build/sd-1';BASE='05a3b132447c60b93fd0c51401c4e17a79405f30'
def git(root,*args):return subprocess.check_output(['git','--no-replace-objects',*args],cwd=root)
assert git(H,'rev-parse','HEAD').decode().strip()==BASE and not git(H,'status','--porcelain=v1','-z','--untracked-files=all')
spec=importlib.util.spec_from_file_location('inv',R/'build/git-publish/20261115-all-main-3/inventory.py');inv=importlib.util.module_from_spec(spec);spec.loader.exec_module(inv)
expected=json.loads((R/'build/git-publish/20261120-susie-catalog-54/WORKTREES-EXPECTED.json').read_bytes())
for row in expected:
    if Path(row['root']).resolve()!=A.resolve():assert inv.snapshot(Path(row['root']))==row,row['root']
expected.append(inv.snapshot(H));assert len(expected)==25
(B/'WORKTREES-EXPECTED.json').write_text(json.dumps(expected,indent=2)+'\n')
inputs=['--primary-cache',str(R/'build/literature-review/xml'),'--supplement-pdf',str(A/'build/seurat-catalog-1/supplement-P160-2/SUPPLEMENT.pdf'),
    '--author-archive',str(A/'build/plink-high-impact-1/P114-author-code-1/EAS_SCZ_rCNV_analysis.zip'),
    '--historical-checkout',str(R/'build/sc-susie-1'),'--enrichr-checkout',str(R/'build/sc-enrichr-1'),
    '--coloc-checkout',str(A/'build/enrichr-catalog-admission-1/coloc-predecessor-checkout')]
def run(label):
    target=H/'build'/('susie-dispatch-predecessor-'+label+'-1');assert not target.exists()
    if label=='owner':cmd=[sys.executable,'-B','-m','susie_catalog.catalog','--verify',*inputs,'--out',str(target)];env=dict(os.environ,PYTHONPATH=str(H/'tools/literature'))
    else:cmd=[sys.executable,'-B',str(H/'tools/literature/verify_susie_catalog.py'),'--out',str(target)];env=dict(os.environ,PATH='',PYTHONPATH=str(H/'tools/literature'))
    with (O/(label+'.stdout')).open('xb') as so,(O/(label+'.stderr')).open('xb') as se:
        p=subprocess.Popen(cmd,cwd=H,env=env,stdin=subprocess.DEVNULL,stdout=so,stderr=se)
        (O/(label+'.PROCESS.json')).write_text(json.dumps(dict(pid=p.pid,command=cmd))+'\n');code=p.wait(timeout=900)
    print('Historical',label,code,flush=True)
    if code:print((O/(label+'.stderr')).read_text(errors='replace')[-4000:],flush=True)
    assert code==0
    result=json.loads((target/'COMPLETED.json').read_bytes());assert result['new_scoped_integrations']==138 and result['reviewed_uses']==1503
    (O/(label+'-COMPLETED.json')).write_text(json.dumps(result,indent=2)+'\n')
    return label,dict(exit_code=code,status=result['status'])
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=dict(pool.map(run,['owner','portable']))
assert not git(H,'status','--porcelain=v1','-z','--untracked-files=all')
(O/'COMPLETED.json').write_text(json.dumps(dict(status='PASS_UNCHANGED_SUSIE_CATALOG_OWNER_AND_PORTABLE_READER_IN_EXACT_HISTORICAL_CHECKOUT',
    historical_commit=BASE,results=results,portable_reader_without_git=True,source_overlay=False,
    old_fingerprints_refreshed=False,total_worktrees=25),indent=2)+'\n')
