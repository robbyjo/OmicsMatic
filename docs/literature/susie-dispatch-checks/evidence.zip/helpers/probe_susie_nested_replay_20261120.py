from pathlib import Path
import hashlib,json,shutil,subprocess
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');B=A/'build/susie-dispatch-1';O=B/'nested-replay-before-1';O.mkdir(exist_ok=False)
jar=B/'workflow-gradle-1/project-build/cli/omicsmatic-0.4.0.jar';java='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe'
original=B/'original-global-1/captures/0.14.2-sufficient-base';parent=O/'parent';shutil.copytree(original,parent)
source=A/'src/main/java/org/jlinalg/cli/SusieWorkflowCli.java';(O/'SusieWorkflowCli.before.java').write_bytes(source.read_bytes())
def run(name,args):
    p=subprocess.run([java,'-Xmx2g','-jar',str(jar),'susie-tools',*args],cwd=A,capture_output=True,timeout=120)
    (O/(name+'.stdout')).write_bytes(p.stdout);(O/(name+'.stderr')).write_bytes(p.stderr);return p.returncode
assert run('parent-before',['--verify',str(parent)])==0
request=dict(schema_version=1,mode='REPLAY',analysis=str(parent),out=str(parent/'nested-output'),
    rscript=str(O/'missing-rscript'),r_libraries=[str(O)])
(O/'replay.json').write_text(json.dumps(request,indent=2)+'\n')
replay=run('nested-replay',['--request',str(O/'replay.json')]);after=run('parent-after',['--verify',str(parent)])
assert replay==3 and after==2 and (parent/'nested-output').is_dir(),(replay,after)
assert run('original-unmodified',['--verify',str(original)])==0
(O/'CONFIRMED.json').write_text(json.dumps(dict(status='CONFIRMED_NESTED_REPLAY_INVALIDATES_COPIED_PARENT_BEFORE_GUARD',
    producer=dict(bytes=jar.stat().st_size,sha256=hashlib.sha256(jar.read_bytes()).hexdigest()),
    parent_before_exit=0,replay_exit=replay,parent_after_exit=after,original_capture_exit=0,
    original_capture_modified=False,upstream_models_run=False,
    required_fix='Refuse replay destinations inside the original analysis, including existing-path aliases, before creating any output.'),indent=2)+'\n')
print('Confirmed on a disposable copied capture: nested output invalidates parent; original capture preserved',flush=True)
