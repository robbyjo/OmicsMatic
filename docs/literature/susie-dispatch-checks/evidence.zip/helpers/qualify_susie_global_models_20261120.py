from pathlib import Path
import hashlib,json,os,subprocess
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');B=A/'build/susie-dispatch-1';O=B/'original-global-1';O.mkdir(exist_ok=False)
Q=A/'build/susie-high-impact-1/original-model-qualification-2';jar=B/'workflow-gradle-1/project-build/cli/omicsmatic-0.4.0.jar'
java='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe'
rows=json.loads((Q/'RUNS.json').read_bytes())
selected=[next(r for r in rows if r['name']==name) for name in ['0.11.92-individual-base','0.12.35-beta-base','0.14.2-sufficient-base']]
selected.append(next(r for r in rows if r['version']=='0.14.2' and not r['original_converged']))
def pin(path):
    path=Path(path)
    with path.open('rb') as f:return dict(bytes=path.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
processes=[];comparisons=[]
def run(name,command,expected):
    p=subprocess.run(command,cwd=A,capture_output=True,timeout=180)
    (O/(name+'.stdout')).write_bytes(p.stdout);(O/(name+'.stderr')).write_bytes(p.stderr)
    processes.append(dict(name=name,command=command,exit_code=p.returncode,expected=expected))
    print(name,p.returncode,flush=True)
    assert p.returncode==expected,(name,p.returncode,p.stderr[-3000:])
for row in selected:
    name=row['name'];request=json.loads((Q/(name+'.json')).read_bytes());target=O/'captures'/name;request['out']=str(target)
    path=O/(name+'.json');path.write_text(json.dumps(request,indent=2)+'\n')
    original=Q/'reference'/name/'original-fit.rds';wanted=pin(original)
    run('run-'+name,[java,'-Xmx2g','-jar',str(jar),'susie-tools','--request',str(path)],row['project_exit'])
    assert pin(original)==wanted
    comparisons.append(dict(name=name,original=str(original),actual=str(target/'worker/original-fit.rds'),original_pin=wanted))
    for host,command in [('windows',[java,'-Xmx2g','-jar',str(jar),'susie-tools','--verify',str(target)]),
        ('linux',['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/java','-Xmx2g','-jar',
            '/mnt/d/projects/JLinAlg/build/high-impact-stats-1/build/susie-dispatch-1/workflow-gradle-1/project-build/cli/omicsmatic-0.4.0.jar',
            'susie-tools','--verify','/mnt/d/projects/JLinAlg/build/high-impact-stats-1/build/susie-dispatch-1/original-global-1/captures/'+name])]:
        run('verify-'+host+'-'+name,command,row['project_exit'])
parent=O/'captures/0.14.2-sufficient-base';target=O/'replay';path=O/'replay.json'
path.write_text(json.dumps(dict(schema_version=1,mode='REPLAY',analysis=str(parent),out=str(target)),indent=2)+'\n')
run('actual-replay',[java,'-Xmx2g','-jar',str(jar),'susie-tools','--request',str(path)],0)
original=Q/'reference/0.14.2-sufficient-base/original-fit.rds'
comparisons.append(dict(name='replay-0.14.2-sufficient-base',original=str(original),actual=str(target/'worker/original-fit.rds'),original_pin=pin(original)))
(O/'COMPARISON-INPUTS.json').write_text(json.dumps(comparisons,indent=2)+'\n')
script=O/'compare.R';script.write_text(r'''
args<-commandArgs(TRUE);.libPaths(c(args[1],args[2],.Library),include.site=FALSE)
rows<-jsonlite::fromJSON(args[3]);results<-list();passed<-TRUE
for(i in seq_len(nrow(rows))){
 a<-readRDS(rows$original[i]);b<-readRDS(rows$actual[i]);fields<-setdiff(union(names(a),names(b)),'call');different<-character();maxerr<-0
 for(f in fields){
  x<-a[[f]];y<-b[[f]];ok<-if(f %in% c('niter','converged'))identical(x,y) else isTRUE(all.equal(x,y,tolerance=1e-11,check.attributes=TRUE))
  if(!ok)different<-c(different,f)
  if(is.numeric(x)&&is.numeric(y)&&length(x)==length(y)){
   if(!identical(is.na(x),is.na(y))||!identical(is.nan(x),is.nan(y))||!identical(is.infinite(x),is.infinite(y)))different<-unique(c(different,f))
   finite<-is.finite(x)&is.finite(y);if(any(finite))maxerr<-max(maxerr,max(abs(x[finite]-y[finite])))
  }
 }
 if(!identical(a$sets$cs,b$sets$cs)||!identical(a$sets$cs_index,b$sets$cs_index))different<-unique(c(different,'credible-set-membership-or-order'))
 ok<-length(different)==0;passed<-passed&&ok
 results[[rows$name[i]]]<-list(passed=ok,fields_compared=as.list(fields),differences=as.list(different),maximum_numeric_absolute_error=maxerr,
   converged=isTRUE(a$converged),original_object_modified=FALSE,actual_object_modified=FALSE)
 cat(rows$name[i],if(ok)'MATCH' else 'DIFFERENT',maxerr,'
')
}
jsonlite::write_json(list(status=if(passed)'PASS_ROOT_COMMAND_AGAINST_UNMODIFIED_ORIGINAL_MODELS' else 'FAIL2_ORIGINAL_MODEL_DIFFERENCE',
 comparisons=results,models=length(results),numeric_tolerance=1e-11,excluded_field='call provenance only',scientific_source_overlay=FALSE),args[4],pretty=TRUE,auto_unbox=TRUE,digits=NA)
if(!passed)quit(save='no',status=2L)
''',encoding='utf-8')
run('independent-object-comparison',['C:/Program Files/R/R-4.6.1/bin/Rscript.exe','--vanilla',str(script),
    str(A/'build/susie-high-impact-1/runtime-profile-1/library'),str(A/'build/coloc-high-impact-1/runtime-coloc603-1/library'),
    str(O/'COMPARISON-INPUTS.json'),str(O/'COMPARISONS.json')],0)
result=json.loads((O/'COMPARISONS.json').read_bytes())
assert result['models']==5 and all(r['passed'] and r['maximum_numeric_absolute_error']==0 for r in result['comparisons'].values())
for row in comparisons:assert pin(row['original'])==row['original_pin']
(O/'COMPLETED.json').write_text(json.dumps(dict(status='PASS_NORMAL_ROOT_SUSIE_RUN_VERIFY_REPLAY_AND_ORIGINAL_COMPARISONS',
    producer=pin(jar),processes=processes,models_compared=5,converged_RUNs=3,nonconverged_RUNs_refused=1,replays=1,
    original_model_maximum_numeric_absolute_error=0,original_objects_modified=False,scientific_source_overlay=False,
    Windows_R_scientific_runs=True,Linux_R_scientific_runs=False,Linux_offline_verify=True),indent=2)+'\n')
