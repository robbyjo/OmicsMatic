from pathlib import Path
import json,os,subprocess,sys
R=Path('D:/projects/JLinAlg');H=R/'build/sd-1';A=R/'build/high-impact-stats-1';B=A/'build/susie-dispatch-1';O=B/'scanpy-reference-1';O.mkdir(exist_ok=False)
target=H/'build/susie-global-scanpy-reference-1';assert not target.exists()
env=dict(os.environ,PYTHONPATH=str(H/'tools/literature'),PATH='')
p=subprocess.run([sys.executable,'-B',str(H/'tools/literature/verify_scanpy_dispatch.py'),'--restore-capture','--out',str(target)],
    cwd=H,env=env,capture_output=True,timeout=180)
(O/'restore.stdout').write_bytes(p.stdout);(O/'restore.stderr').write_bytes(p.stderr)
print(p.returncode,p.stdout.decode(errors='replace'),p.stderr.decode(errors='replace')[-3000:],flush=True);assert p.returncode==0
result=json.loads((target/'COMPLETED.json').read_bytes());assert result['capture_restored']
assert (target/'capture/capture-files.json').is_file()
(O/'COMPLETED.json').write_text(json.dumps(dict(status='PASS_UNCHANGED_HISTORICAL_READER_RESTORED_SCANPY_REFERENCE',
    historical_commit='05a3b132447c60b93fd0c51401c4e17a79405f30',source_lookup_overlay=False,
    capture=str(target/'capture'),result=result),indent=2)+'\n')
