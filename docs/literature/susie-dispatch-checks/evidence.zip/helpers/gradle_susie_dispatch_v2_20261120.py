from pathlib import Path
p=Path('D:/projects/JLinAlg/build/gradle_susie_dispatch_20261120.py')
base=Path('D:/projects/JLinAlg/build/gradle_enrichr_workflow_20261119.py').read_text()
base=base.replace('build/enrichr-high-impact-1','build/susie-dispatch-1').replace('workflow-gradle-1','workflow-gradle-2')
exec(compile(base,__file__+'-REPLAY-PARENT-GUARD','exec'))
