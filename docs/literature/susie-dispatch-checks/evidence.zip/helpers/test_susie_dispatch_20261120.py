from pathlib import Path
import concurrent.futures,hashlib,json,os,subprocess,sys,xml.etree.ElementTree as ET,zipfile
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');B=A/'build/susie-dispatch-1';O=B/'tests-1';O.mkdir(exist_ok=False)
jar=B/'workflow-gradle-1/project-build/cli/omicsmatic-0.4.0.jar';old=A/'build/susie-high-impact-1/workflow-gradle-2/project-build/cli/omicsmatic-0.4.0.jar'
assert json.loads((B/'workflow-gradle-1/PROCESS-EXIT.json').read_bytes())['exit_code']==0
classes=O/'classes';classes.mkdir();junit=A/'build/nfcore-atacseq121-1/linux-test-runtime-1/junit-platform-console-standalone-1.13.4.jar'
jdk=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin')
sources=[A/('src/test/java/org/jlinalg/cli/'+n+'.java') for n in ['SusieToolsDispatchTest','FineMappingCliTest','RunLogTest','ScanpyWorkflowTest','EnrichrWorkflowTest']]
p=subprocess.run([str(jdk/'javac.exe'),'--release','17','-g','-Xlint:all','-Werror','-sourcepath','','-cp',str(jar)+';'+str(junit),'-d',str(classes),*map(str,sources)],cwd=A,capture_output=True)
(O/'javac.stdout').write_bytes(p.stdout);(O/'javac.stderr').write_bytes(p.stderr);assert p.returncode==0,p.stderr[-5000:]
with zipfile.ZipFile(old) as before,zipfile.ZipFile(jar) as after:
    assert len(before.namelist())==len(set(before.namelist())) and len(after.namelist())==len(set(after.namelist()))
    assert set(before.namelist())==set(after.namelist())
    payloads={n:dict(before=dict(bytes=len(before.read(n)),sha256=hashlib.sha256(before.read(n)).hexdigest()),
                    after=dict(bytes=len(after.read(n)),sha256=hashlib.sha256(after.read(n)).hexdigest())) for n in before.namelist()}
    changed=[n for n,v in payloads.items() if v['before']!=v['after']]
    assert changed==['org/jlinalg/cli/JLinAlgCli.class'],changed
    (O/'JAR-PAYLOADS.json').write_text(json.dumps(payloads,indent=2)+'\n')
    (O/'JLinAlgCli.before.class').write_bytes(before.read(changed[0]));(O/'JLinAlgCli.after.class').write_bytes(after.read(changed[0]))
    print('All JAR payloads unchanged except main dispatcher:',len(payloads),flush=True)
def linux(path):return '/mnt/d/'+str(path).replace('\\','/').split('D:/',1)[1]
selected=['--select-class','org.jlinalg.cli.SusieToolsDispatchTest','--select-class','org.jlinalg.cli.FineMappingCliTest',
          '--select-class','org.jlinalg.cli.ScanpyWorkflowTest','--select-class','org.jlinalg.cli.EnrichrWorkflowTest',
          '--details','summary','--disable-ansi-colors']
def test(label):
    reports=O/('reports-'+label)
    if label=='linux21':
        code='''import pathlib,subprocess,sys,tarfile
root,jar,classes,junit,resources,reports,archive,*selected=sys.argv[1:]
p=subprocess.run(['/usr/bin/java','-Xmx2g','-Domicsmatic.susie.dispatch.test_root='+root,'-jar',junit,'execute','--class-path',jar+':'+classes+':'+resources,*selected,'--reports-dir',reports])
if pathlib.Path(root).is_dir():
 with tarfile.open(archive,'x') as t:t.add(root,arcname=pathlib.Path(root).name)
sys.exit(p.returncode)
'''
        command=['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/python3','-c',code,
            '/tmp/omicsmatic-susie-dispatch-20261120-1',linux(jar),linux(classes),linux(junit),linux(A/'src/test/resources'),
            linux(reports),linux(O/'linux21-test-root.tar'),*selected]
    else:
        java=jdk/'java.exe' if label=='windows21' else Path('C:/Program Files/Java/jdk-25/bin/java.exe')
        command=[str(java),'-Xmx2g','-Domicsmatic.susie.dispatch.test_root='+str(O/label),'-jar',str(junit),'execute',
            '--class-path',str(jar)+';'+str(classes)+';'+str(A/'src/test/resources'),*selected,'--reports-dir',str(reports)]
    p=subprocess.run(command,cwd=A,capture_output=True,timeout=600)
    (O/(label+'.stdout')).write_bytes(p.stdout);(O/(label+'.stderr')).write_bytes(p.stderr)
    totals={k:0 for k in ['tests','errors','failures','skipped']}
    for path in reports.glob('TEST-*.xml'):
        s=ET.parse(path).getroot()
        for k in totals:totals[k]+=int(s.get(k,0))
    print(label,p.returncode,totals,flush=True)
    if p.returncode:print(p.stdout.decode(errors='replace')[-5000:]+p.stderr.decode(errors='replace')[-2000:],flush=True)
    return label,dict(exit_code=p.returncode,totals=totals)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=dict(pool.map(test,['windows21','windows25','linux21']))
(O/'RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
assert all(r['exit_code']==0 and r['totals']['tests']>=49 and not any(r['totals'][k] for k in ['errors','failures','skipped']) for r in results.values()),results
(O/'COMPLETED.json').write_text(json.dumps(dict(status='PASS_NORMAL_GLOBAL_SUSIE_COMMAND_AND_NATIVE_SCANPY_ENRICHR_REGRESSIONS',
    results=results,changed_JAR_payloads=changed,unchanged_JAR_payloads=len(payloads)-1,
    scientific_worker_bytecode_changed=False,linux_test_root_archived_immediately=True),indent=2)+'\n')
