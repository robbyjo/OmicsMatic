from pathlib import Path
import json,shutil,subprocess,sys
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');B=A/'build/susie-dispatch-1';O=B/'replay-guard-controls-1';O.mkdir(exist_ok=False)
jar=B/'workflow-gradle-2/project-build/cli/omicsmatic-0.4.0.jar';java='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe'
original=B/'original-global-1/captures/0.14.2-sufficient-base';rows=[]
def run(name,command,expected):
    p=subprocess.run(command,cwd=A,capture_output=True,timeout=120)
    (O/(name+'.stdout')).write_bytes(p.stdout);(O/(name+'.stderr')).write_bytes(p.stderr)
    assert p.returncode==expected,(name,p.returncode,p.stderr[-3000:]);return p
for mode in ['direct','junction']:
    parent=O/(mode+'-parent');shutil.copytree(original,parent)
    run(mode+'-before',[java,'-jar',str(jar),'susie-tools','--verify',str(parent)],0)
    if mode=='junction':
        alias=O/'windows-alias';assert not alias.exists() and parent.resolve().is_relative_to(B.resolve()) and alias.parent.resolve()==O.resolve()
        script=O/'make-junction.ps1';script.write_text("param([string]$AliasPath,[string]$TargetPath)\nif (Test-Path -LiteralPath $AliasPath) { throw 'Preserve existing alias' }\nNew-Item -ItemType Junction -Path $AliasPath -Target $TargetPath -ErrorAction Stop | Out-Null\n",encoding='utf-8')
        run('make-junction',['C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe','-NoProfile','-NonInteractive','-File',str(script),'-AliasPath',str(alias),'-TargetPath',str(parent)],0)
        assert alias.is_junction();destination=alias/'nested/new-output'
    else:destination=parent/'nested/new-output'
    path=O/(mode+'.json');path.write_text(json.dumps(dict(schema_version=1,mode='REPLAY',analysis=str(parent),out=str(destination),
        rscript=str(O/'missing-rscript'),r_libraries=[str(O)]),indent=2)+'\n')
    result=run(mode+'-replay',[java,'-jar',str(jar),'susie-tools','--request',str(path)],2)
    assert b'outside the original analysis' in result.stderr and not (parent/'nested').exists()
    run(mode+'-after',[java,'-jar',str(jar),'susie-tools','--verify',str(parent)],0)
    rows.append(dict(control='Windows-'+mode,exit_code=2,parent_before_exit=0,parent_after_exit=0,output_created=False))
parent=O/'linux-parent';shutil.copytree(original,parent)
code='''import json,pathlib,subprocess,sys
jar,parent,output=sys.argv[1:];root=pathlib.Path('/tmp/omicsmatic-susie-replay-alias-20261120-1');root.mkdir(exist_ok=False)
alias=root/'alias';alias.symlink_to(parent,target_is_directory=True)
def run(args):return subprocess.run(['/usr/bin/java','-jar',jar,'susie-tools',*args],capture_output=True)
assert run(['--verify',parent]).returncode==0
request=pathlib.Path(output)/'linux.json';request.write_text(json.dumps(dict(schema_version=1,mode='REPLAY',analysis=parent,out=str(alias/'nested/new-output'),rscript=str(root/'missing-rscript'),r_libraries=[str(root)])))
r=run(['--request',str(request)]);(pathlib.Path(output)/'linux-replay.stdout').write_bytes(r.stdout);(pathlib.Path(output)/'linux-replay.stderr').write_bytes(r.stderr)
assert r.returncode==2 and b'outside the original analysis' in r.stderr and not (pathlib.Path(parent)/'nested').exists()
assert run(['--verify',parent]).returncode==0
print(json.dumps(dict(control='Linux-symlink',exit_code=2,parent_before_exit=0,parent_after_exit=0,output_created=False)))
'''
def linux(p):return '/mnt/d/'+str(p).replace('\\','/').split('D:/',1)[1]
p=run('linux-control',['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/python3','-c',code,linux(jar),linux(parent),linux(O)],0)
rows.append(json.loads(p.stdout))
(O/'COMPLETED.json').write_text(json.dumps(dict(status='PASS_REPLAY_PARENT_PROTECTION_DIRECT_WINDOWS_JUNCTION_LINUX_SYMLINK',
    controls=rows,original_capture_modified=False,upstream_models_run=False),indent=2)+'\n')
print(json.dumps(rows),flush=True)
