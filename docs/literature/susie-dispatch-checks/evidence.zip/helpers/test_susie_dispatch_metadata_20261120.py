from pathlib import Path
import concurrent.futures,json,os,subprocess,sys
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');B=A/'build/susie-dispatch-1';O=B/'metadata-tests-1';O.mkdir(exist_ok=False)
def test(label):
    names=['test_susie_dispatch_transition','test_susie_dispatch_catalog']
    if label=='windows':command=[sys.executable,'-B','-m','unittest',*names];env=dict(os.environ,PYTHONPATH=str(A/'tools/literature'))
    else:
        command=['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','env',
            'GIT_DIR=/mnt/d/projects/JLinAlg/.git/worktrees/high-impact-stats-1','GIT_COMMON_DIR=/mnt/d/projects/JLinAlg/.git',
            'GIT_WORK_TREE=/mnt/d/projects/JLinAlg/build/high-impact-stats-1','GIT_CONFIG_GLOBAL=/dev/null','GIT_CONFIG_SYSTEM=/dev/null',
            '/usr/bin/python3','-I','-B','-c',"import sys,runpy;sys.path.insert(0,'/mnt/d/projects/JLinAlg/build/high-impact-stats-1/tools/literature');runpy.run_module('unittest',run_name='__main__')",*names];env=os.environ.copy()
    p=subprocess.run(command,cwd=A,env=env,capture_output=True,timeout=180)
    (O/(label+'.stdout')).write_bytes(p.stdout);(O/(label+'.stderr')).write_bytes(p.stderr)
    print(label,p.returncode,p.stderr.decode(errors='replace')[-3000:],flush=True)
    return label,dict(exit_code=p.returncode)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=dict(pool.map(test,['windows','linux']))
(O/'RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
assert all(r['exit_code']==0 for r in results.values())
(O/'COMPLETED.json').write_text(json.dumps(dict(status='PASS_ROOT_INVERSE_AND_COMMAND_METADATA_CONTROLS_WINDOWS_LINUX',results=results),indent=2)+'\n')
