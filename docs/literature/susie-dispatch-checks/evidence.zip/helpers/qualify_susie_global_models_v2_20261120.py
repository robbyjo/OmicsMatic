from pathlib import Path
p=Path('D:/projects/JLinAlg/build/qualify_susie_global_models_20261120.py');source=p.read_text()
for old,new in [('original-global-1','original-global-2'),('workflow-gradle-1','workflow-gradle-2')]:
    assert old in source;source=source.replace(old,new)
exec(compile(source,__file__+'-REPLAY-PARENT-GUARD-PRODUCER','exec'))
