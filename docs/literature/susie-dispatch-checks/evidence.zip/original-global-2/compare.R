
args<-commandArgs(TRUE);.libPaths(c(args[1],args[2],.Library),include.site=FALSE)
rows<-jsonlite::fromJSON(args[3]);results<-list();passed<-TRUE
for(i in seq_len(nrow(rows))){
 a<-readRDS(rows$original[i]);b<-readRDS(rows$actual[i]);fields<-setdiff(union(names(a),names(b)),'call');different<-character();maxerr<-0
 for(f in fields){
  x<-a[[f]];y<-b[[f]];ok<-if(f %in% c('niter','converged'))identical(x,y) else isTRUE(all.equal(x,y,tolerance=1e-11,check.attributes=TRUE))
  if(!ok)different<-c(different,f)
  if(is.numeric(x)&&is.numeric(y)&&length(x)==length(y)){
   if(!identical(is.na(x),is.na(y))||!identical(is.nan(x),is.nan(y))||!identical(is.infinite(x),is.infinite(y)))different<-unique(c(different,f))
   finite<-is.finite(x)&is.finite(y);if(any(finite))maxerr<-max(maxerr,max(abs(x[finite]-y[finite])))
  }
 }
 if(!identical(a$sets$cs,b$sets$cs)||!identical(a$sets$cs_index,b$sets$cs_index))different<-unique(c(different,'credible-set-membership-or-order'))
 ok<-length(different)==0;passed<-passed&&ok
 results[[rows$name[i]]]<-list(passed=ok,fields_compared=as.list(fields),differences=as.list(different),maximum_numeric_absolute_error=maxerr,
   converged=isTRUE(a$converged),original_object_modified=FALSE,actual_object_modified=FALSE)
 cat(rows$name[i],if(ok)'MATCH' else 'DIFFERENT',maxerr,'
')
}
jsonlite::write_json(list(status=if(passed)'PASS_ROOT_COMMAND_AGAINST_UNMODIFIED_ORIGINAL_MODELS' else 'FAIL2_ORIGINAL_MODEL_DIFFERENCE',
 comparisons=results,models=length(results),numeric_tolerance=1e-11,excluded_field='call provenance only',scientific_source_overlay=FALSE),args[4],pretty=TRUE,auto_unbox=TRUE,digits=NA)
if(!passed)quit(save='no',status=2L)
