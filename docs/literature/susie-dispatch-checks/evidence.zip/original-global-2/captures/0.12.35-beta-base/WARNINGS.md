# SuSiE warnings and required actions

Status: completed-with-warnings

Read WARNINGS.md, analysis-status.json, worker/report.json, worker/warnings.txt and logs. SKIP3: dependent analysis skipped; restore the named exact permitted input/runtime/package or retain the skip. FAIL2: no complete result; preserve inputs, original objects, partials and diagnostics, correct input/model, convergence, integrity, capacity or process failures and retry NEW output. No silent ID, allele, dtype, threshold, population, nonfinite or algorithm repair. DEVELOPMENT_SCOPE: explicit original susieR0.11.92/0.12.35/0.14.2 on exact R4.6.1/package profiles. No native fitting fallback, allele harmonization, phenotype/variant filtering, PolyFun/tensorQTL hosting or complete author workflow. VERIFY checks captured integrity, deterministic intake and exported model structure without R; it does not independently refit the model or authenticate coordinated replacement. REPLAY needs the exact permitted runtime.

## Original and adapter warnings

Original summary fit has no identifiable intercept without supplied means; source NA is retained as typed metadata, never replaced by zero.
