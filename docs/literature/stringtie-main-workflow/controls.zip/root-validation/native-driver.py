
import hashlib,json,shutil,subprocess,sys
from pathlib import Path
base,jar,out=map(Path,sys.argv[1:]);assert not base.exists();base.mkdir(mode=0o700);native_jar=base/'candidate.jar';shutil.copyfile(jar,native_jar)
def pin(p):
 with p.open('rb') as stream:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(stream,'sha256').hexdigest())
assert pin(jar)==pin(native_jar);example=Path('/var/tmp/omicsmatic-stringtie-example-20261103-1/example');home=Path('/var/tmp/omicsmatic-stringtie-setup-20261103-1/home-3.0.3');setup=home.parent/'install-3.0.3';records=[]
def run(label,options):
 command=['/usr/bin/java','-Xmx512m','-XX:ActiveProcessorCount=2','-jar',str(native_jar),'stringtie-tools',*map(str,options)]
 with (out/(label+'.stdout')).open('xb') as stdout,(out/(label+'.stderr')).open('xb') as stderr:r=subprocess.run(command,env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C'},stdout=stdout,stderr=stderr,timeout=180,check=False)
 row=dict(label=label,command=command,exit_code=r.returncode);records.append(row);(out/(label+'.process.json')).write_text(json.dumps(row,indent=2)+'\n');assert r.returncode==0,(label,r.returncode)
for request,label in [('assemble','assembly'),('estimate','estimation'),('merge','merged')]:
 document=json.loads((example/(request+'.json')).read_bytes())
 if request=='merge':document['merge_inputs']=[str(base/'assembly/fit/transcripts.gtf')]
 source=base/(request+'.json');source.write_text(json.dumps(document,indent=2)+'\n');bundle=base/label
 run(label,['--recipe',source,'--home',home,'--setup-report',setup,'--out',bundle]);run(label+'-verify',['--verify',bundle])
 science=lambda p:b''.join(row for row in p.read_bytes().splitlines(keepends=True) if not row.startswith(b'#'))
 assert science(bundle/'fit/transcripts.gtf')==science(example/label/'fit/transcripts.gtf')
 if request=='estimate':
  for name in ['gene-abundance.tsv','t_data.ctab','e_data.ctab','i_data.ctab','e2t.ctab','i2t.ctab']:assert (bundle/'fit'/name).read_bytes()==(example/label/'fit'/name).read_bytes()
 shutil.copytree(bundle,out/'bundles'/label)
assert pin(jar)==pin(native_jar)
(out/'NATIVE.json').write_text(json.dumps(dict(status='passed-three-actual-root-fits-and-verifies-matching-prior-standalone-results',linux_root=str(base),byte_identical_native_JAR=pin(native_jar),records=records),indent=2)+'\n')
