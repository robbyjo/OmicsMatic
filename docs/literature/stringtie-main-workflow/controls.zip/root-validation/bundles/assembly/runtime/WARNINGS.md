# StringTie runtime health only

One tiny synthetic population was fitted with the exact selected original edition, with complete native BAM, GTF, table and normalization audits. Original paths and decimal values are retained. Gene-reduction residuals remain diagnostic; hidden fit denominators and biological accuracy are not recovered or certified. A user fit requires its own explicit input/output checks.

Read WARNINGS.md, FAILURE.json and retained process stdout/stderr/ledgers. SKIP3 means a required permitted Linux runtime, helper, library or capability is unavailable: skip dependent analysis and complete permitted setup. FAIL2 means invalid or changed input/evidence, failed process/audit, cancellation or capacity failure: preserve the attempt, correct the cause and use NEW paths. No installation or download occurs during admission. Synthetic health alone does not admit a user fit or certify biological accuracy.
