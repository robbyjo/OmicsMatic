from pathlib import Path
import importlib.util,json,subprocess
R=Path('D:/projects/JLinAlg');H=R/'build/gs-2';T=R/'build/gs-3';P=R/'build/git-publish/20261120-gsea-native-62'
O=R/'build/gsea-engine-start-20261120-1';O.mkdir(exist_ok=False);BASE='7f4cc3185a642c61c7ab42b8b84a2630fac1fec7'
def git(root,*args):return subprocess.check_output(['git','--no-replace-objects',*args],cwd=root)
def save(n,v):(O/n).write_bytes((json.dumps(v,indent=2)+'\n').encode())
assert git(H,'rev-parse','HEAD').decode().strip()==BASE and git(H,'ls-remote','origin','refs/heads/main').decode().split()[0]==BASE
previous=json.loads((P/'WORKTREES-EXPECTED.json').read_bytes());assert len(previous)==30
spec=importlib.util.spec_from_file_location('inv',P.parent/'20261115-all-main-3/inventory.py');inv=importlib.util.module_from_spec(spec);spec.loader.exec_module(inv)
for row in previous:assert inv.snapshot(Path(row['root']))==row,row['root']
save('WORKTREES-BEFORE.json',previous);assert not T.exists()
p=subprocess.run(['git','worktree','add','-b','codex/gsea-engine-20261120',str(T),BASE],cwd=R,capture_output=True)
(O/'worktree.stdout').write_bytes(p.stdout);(O/'worktree.stderr').write_bytes(p.stderr);assert p.returncode==0
assert git(T,'rev-parse','HEAD').decode().strip()==BASE and not git(T,'status','--porcelain=v1','-z','--untracked-files=all')
(T/'build/gsea-high-impact-3').mkdir(parents=True)
save('COMPLETED.json',dict(status='PASS_NATIVE_CHECKPOINT_AND_NEW_GSEA_ENGINE_WORKTREE',base=BASE,root=str(T),worktrees=31))
print('PASS all30 prior worktrees exact; new GSEA engine checkout',T,flush=True)
