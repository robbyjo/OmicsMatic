from pathlib import Path
import concurrent.futures,hashlib,json,shutil,subprocess,traceback
R=Path('D:/projects/JLinAlg');T=R/'build/gs-3';B=T/'build/gsea-high-impact-3';P=R/'build/gs-2/build/gsea-high-impact-2'
O=B/'original-engine-sweep-2';O.mkdir(exist_ok=False);J=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin')
S=T/'tools/literature/gsea_engine/OriginalEngineProbe.java'
def save(path,v):path.write_bytes((json.dumps(v,indent=2)+'\n').encode())
def pin(path):
    with path.open('rb') as stream:return dict(bytes=path.stat().st_size,sha256=hashlib.file_digest(stream,'sha256').hexdigest())
def task(edition):
    folder=O/edition;folder.mkdir();classes=folder/'classes';classes.mkdir();home=folder/'home';home.mkdir();cwd=folder/'worker';cwd.mkdir()
    if edition=='4.4.0':
        runtime=R/'build/gs-1/build/gsea-high-impact-1/runtime-source-4.4.0-1';profile=json.loads((runtime/'PROFILE.json').read_bytes());cp=str(runtime/'modules/*')
    else:
        root=P/'original-4.3-profiles-1'/edition;runtime=root/'runtime';profile=json.loads((root/'PROFILE.json').read_bytes())
        cp=';'.join(str(runtime/(name+'/*')) for name in ['modules','lib','producer'])
    for name,wanted in profile['files'].items():assert pin(runtime/name)==wanted,(edition,name)
    shutil.copyfile(S,folder/S.name)
    compile_command=[str(J/'javac.exe'),'--release','17','-cp',cp,'-d',str(classes),str(S)]
    proc=subprocess.run(compile_command,capture_output=True);(folder/'javac.stdout').write_bytes(proc.stdout);(folder/'javac.stderr').write_bytes(proc.stderr)
    save(folder/'COMPILE.json',dict(command=compile_command,exit_code=proc.returncode,source=pin(S)))
    assert proc.returncode==0,'Inspect retained compile diagnostics: '+edition
    command=[str(J/'java.exe'),'-Xmx1g','-Djava.awt.headless=true','-Duser.home='+str(home),'-DMAKE_GSEA_UPDATE_CHECK=false',
        '-cp',cp+';'+str(classes),'edu.mit.broad.genome.objects.OriginalEngineProbe',str(folder/'cases'),edition]
    save(folder/'COMMAND.json',dict(command=command,cwd=str(cwd),original_runtime_profile=profile))
    with (folder/'stdout').open('xb') as stdout,(folder/'stderr').open('xb') as stderr:
        proc=subprocess.Popen(command,cwd=cwd,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr);save(folder/'PROCESS.json',dict(pid=proc.pid))
        try:code=proc.wait(timeout=300)
        except subprocess.TimeoutExpired:proc.kill();proc.wait();save(folder/'TIMEOUT.json',dict(seconds=300));raise
    save(folder/'PROCESS-EXIT.json',dict(exit_code=code));assert code==0,'Inspect retained original source sweep diagnostics: '+edition
    for name,wanted in profile['files'].items():assert pin(runtime/name)==wanted,(edition,name)
    files={path.name:pin(path) for path in (folder/'cases').iterdir() if path.is_file()};assert len(files)==209
    save(folder/'COMPLETED.json',dict(status='PASS_UNCHANGED_ORIGINAL_ENGINE_OPTION_AND_BOUNDARY_REFERENCE_EXPORT',edition=edition,
        cases=208,files=files,source=pin(S),source_and_runtime_unchanged=True))
    print('PASS original engine sweep',edition,(folder/'cases/COUNTS.tsv').read_text().strip().splitlines()[-1],flush=True)
    return edition,dict(cases=208,files=files)
try:
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=dict(pool.map(task,['4.4.0','4.3.2','4.3.3']))
    save(O/'COMPLETED.json',dict(status='PASS_THREE_ORIGINAL_GSEA_ENGINE_SOURCE_SWEEPS',results=results))
except Exception as error:
    save(O/'FAILURE.json',dict(error=repr(error),detail=traceback.format_exc()));raise
