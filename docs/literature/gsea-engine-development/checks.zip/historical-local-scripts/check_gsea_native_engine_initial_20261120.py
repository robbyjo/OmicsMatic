from pathlib import Path
import json,shutil,subprocess
R=Path('D:/projects/JLinAlg');T=R/'build/gs-3';B=T/'build/gsea-high-impact-3';P=R/'build/gs-2/build/gsea-high-impact-2'
O=B/'native-engine-initial-1';O.mkdir(exist_ok=False);classes=O/'classes';classes.mkdir()
J=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin')
sources=[T/'src/main/java/org/jlinalg/enrichment'/n for n in ['BroadGseaStatistics.java','BroadGseaEngine.java']]+[T/'tools/literature/gsea_engine/CheckNativeEngine.java']
for s in sources:shutil.copyfile(s,O/s.name)
command=[str(J/'javac.exe'),'--release','17','-d',str(classes),*[str(s) for s in sources]]
p=subprocess.run(command,capture_output=True);(O/'javac.stdout').write_bytes(p.stdout);(O/'javac.stderr').write_bytes(p.stderr);assert p.returncode==0,'Inspect javac.stderr'
command=[str(J/'java.exe'),'-Xmx1g','-cp',str(classes),'CheckNativeEngine',str(P/'original-workflow-forms-4.4.0-2/inputs')]
for version in ['4.4.0','4.3.2','4.3.3']:
    for mode in ['preranked','expression-phenotype','expression-geneset']:
        path=P/'original-api-4.4.0-3'/mode/'original.tsv' if version=='4.4.0' else P/'original-4.3-profiles-1'/version/('api-'+mode)/'original.tsv'
        command += [version,mode,str(path)]
p=subprocess.run(command,capture_output=True,stdin=subprocess.DEVNULL,timeout=180)
(O/'stdout').write_bytes(p.stdout);(O/'stderr').write_bytes(p.stderr);(O/'PROCESS.json').write_text(json.dumps(dict(command=command,exit_code=p.returncode),indent=2)+'\n',encoding='utf-8')
print(p.stdout.decode(errors='replace'),flush=True);print(p.stderr.decode(errors='replace'),flush=True);assert p.returncode==0
