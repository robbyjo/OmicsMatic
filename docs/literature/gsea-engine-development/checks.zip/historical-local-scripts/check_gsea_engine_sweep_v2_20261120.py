from pathlib import Path
import json,shutil,subprocess
R=Path('D:/projects/JLinAlg');T=R/'build/gs-3';B=T/'build/gsea-high-impact-3';O=B/'native-engine-sweep-2';O.mkdir(exist_ok=False)
J=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin');classes=O/'classes';classes.mkdir()
sources=[T/'src/main/java/org/jlinalg/enrichment'/n for n in ['BroadGseaStatistics.java','BroadGseaEngine.java']]+[T/'tools/literature/gsea_engine/CheckEngineSweep.java']
for source in sources:shutil.copyfile(source,O/source.name)
command=[str(J/'javac.exe'),'--release','17','-d',str(classes),*[str(p) for p in sources]]
p=subprocess.run(command,capture_output=True);(O/'javac.stdout').write_bytes(p.stdout);(O/'javac.stderr').write_bytes(p.stderr);assert p.returncode==0
command=[str(J/'java.exe'),'-Xmx1g','-cp',str(classes),'CheckEngineSweep',*[str(B/'original-engine-sweep-2'/v/'cases') for v in ['4.4.0','4.3.2','4.3.3']]]
p=subprocess.run(command,capture_output=True,timeout=180);(O/'stdout').write_bytes(p.stdout);(O/'stderr').write_bytes(p.stderr)
(O/'PROCESS.json').write_text(json.dumps(dict(command=command,exit_code=p.returncode),indent=2)+'\n',encoding='utf-8')
print(p.stdout.decode(errors='replace'),flush=True);print(p.stderr.decode(errors='replace'),flush=True);assert p.returncode==0
