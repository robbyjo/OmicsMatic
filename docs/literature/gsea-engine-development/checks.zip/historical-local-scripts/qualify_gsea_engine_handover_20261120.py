from pathlib import Path
import concurrent.futures,hashlib,json,subprocess,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/gs-3';B=T/'build/gsea-high-impact-3'
O=B/'packaged-engine-qualification-1';O.mkdir(exist_ok=False)
JAR=B/'native-gradle-1/project-build/cli/omicsmatic-0.4.0.jar'
OLD=R/'build/gs-2/build/gsea-high-impact-2/native-gradle-1/project-build/cli/omicsmatic-0.4.0.jar'
J21=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin');J25=Path('C:/Program Files/Java/jdk-25/bin')
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
def pin(p):
    with p.open('rb') as f:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
def linux(p):return '/mnt/d/'+p.relative_to(Path('D:/')).as_posix()
assert json.loads((B/'native-gradle-1/PROCESS-EXIT.json').read_bytes())['exit_code']==0
assert pin(OLD)['sha256']=='f701b3b92a67871119c1c9096eb0f7d74f23a3cc0dfad95823bd5f4eba5d13cd'
with zipfile.ZipFile(OLD) as old,zipfile.ZipFile(JAR) as new:
    before=set(old.namelist());after=set(new.namelist());assert before<=after
    for n in sorted(before):assert old.read(n)==new.read(n),n
    added=sorted(after-before)
    assert added and all(n.startswith('org/jlinalg/enrichment/BroadGseaEngine') and n.endswith('.class') for n in added),added
    members={n:dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest()) for n in new.namelist() for b in [new.read(n)]}
save(O/'PRODUCER.json',dict(producer=pin(JAR),jar=str(JAR),prior_producer=pin(OLD),unchanged_predecessor_members=len(before),added_members=added,members=members))
classes=O/'checker-classes';classes.mkdir()
sources=[T/'tools/literature/gsea_engine'/n for n in ['CheckNativeEngine.java','CheckEngineSweep.java','PackagedEngineChecks.java']]
command=[str(J21/'javac.exe'),'--release','17','-cp',str(JAR),'-d',str(classes),*[str(p) for p in sources]]
p=subprocess.run(command,capture_output=True);(O/'javac.stdout').write_bytes(p.stdout);(O/'javac.stderr').write_bytes(p.stderr);assert p.returncode==0
assert all(not q.relative_to(classes).as_posix().startswith('org/jlinalg/') for q in classes.rglob('*.class'))
reference=O/'reference';reference.mkdir()
with zipfile.ZipFile(T/'docs/literature/gsea-engine-development/complete-null-references.zip') as z:
    for name in z.namelist():
        path=reference/name;assert path.resolve().is_relative_to(reference.resolve()) and not name.startswith('/') and '..' not in Path(name).parts
        path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(z.read(name))
inputdir=reference/'inputs'
nullargs=[inputdir]
for v in ['4.4.0','4.3.2','4.3.3']:
    for mode in ['preranked','expression-phenotype','expression-geneset']:nullargs.extend([v,mode,reference/'reference'/v/(mode+'.tsv')])
sweepargs=[B/'original-engine-sweep-2'/v/'cases' for v in ['4.4.0','4.3.2','4.3.3']]
def task(host):
    root=O/host;root.mkdir()
    java=J21/'java.exe' if host=='windows-java21' else J25/'java.exe'
    if host=='linux-java21':
        prefix=['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--exec','/usr/bin/java']
        jar=linux(JAR);classpath=jar+':'+linux(classes);convert=lambda a:linux(a) if isinstance(a,Path) else a
    else:prefix=[str(java)];jar=str(JAR);classpath=jar+';'+str(classes);convert=str
    version=subprocess.run(prefix+['-version'],capture_output=True,stdin=subprocess.DEVNULL,timeout=30)
    (root/'version.stdout').write_bytes(version.stdout);(root/'version.stderr').write_bytes(version.stderr);assert version.returncode==0
    for form,args,wanted in [('sweep',sweepargs,'admitted=423\trefused=201\texactFields=200469'),('complete-nulls',nullargs,'PASS_NATIVE_ENGINE_EXACT_FIELDS\t468270')]:
        folder=root/form;folder.mkdir()
        command=prefix+['-Xmx1g','-Domicsmatic.expected.jar='+jar,'-cp',classpath,'PackagedEngineChecks',form,*[convert(a) for a in args]]
        with (folder/'stdout').open('xb') as stdout,(folder/'stderr').open('xb') as stderr:
            p=subprocess.run(command,cwd=folder,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=240)
        save(folder/'PROCESS.json',dict(command=command,exit_code=p.returncode));assert p.returncode==0,host+'/'+form
        output=(folder/'stdout').read_text();assert wanted in output and 'PASS_EXACT_NORMAL_JAR_NATIVE_ENGINE_SOURCE_ORIGIN' in output
        print('PASS exact normal JAR',host,form,wanted,flush=True)
    return host,dict(exit_code=0,complete_null_exact_fields=468270,sweep_exact_fields=200469,sweep_admitted=423,sweep_refused=201,upstream_runtime_on_classpath=False)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=dict(pool.map(task,['windows-java21','windows-java25','linux-java21']))
save(O/'COMPLETED.json',dict(status='PASS_PACKAGED_NATIVE_GSEA_ENGINE_THREE_JVMS',producer=pin(JAR),unchanged_predecessor_members=len(before),added_members=added,results=results,exact_fields_per_JVM=668739,strict_refusals_per_JVM=201,project_RUN_VERIFY_REPLAY_qualified=False,new_catalog_credit=0))
