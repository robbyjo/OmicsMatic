from pathlib import Path
import hashlib,json,zipfile
R=Path('D:/projects/JLinAlg');T=R/'build/gs-3';B=T/'build/gsea-high-impact-3'
Q=T/'docs/literature/gsea-engine-development';Q.mkdir(exist_ok=False)
def enc(v):return (json.dumps(v,indent=2)+'\n').encode()
def pin(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def archive(path,files):
    with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for n,b in sorted(files.items()):
            i=zipfile.ZipInfo(n,(2026,11,20,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16;z.writestr(i,b)
files={}
for v in ['4.4.0','4.3.2','4.3.3']:
    folder=B/'original-engine-sweep-2'/v/'cases'
    for p in sorted(folder.glob('case-*.tsv')):files[v+'/'+p.name]=p.read_bytes()
assert len(files)==624
files['SHA256SUMS']=''.join(pin(b)['sha256']+'  '+n+'\n' for n,b in sorted(files.items())).encode()
fixture=T/'src/test/resources/org/jlinalg/enrichment/broad-gsea-engine-originals.zip'
archive(fixture,files)
source=(T/'tools/literature/gsea_engine/CheckEngineSweep.java').read_text()
source='package org.jlinalg.enrichment;\n\n'+source
source=source.replace('public final class CheckEngineSweep {','class BroadGseaEngineTest {')
start=source.index('    public static void main(');end=source.index('    private static void check(',start)
source=source[:start]+'''    @org.junit.jupiter.api.Test void matchesOriginalOptionAndBoundaryCorpus() throws Exception {
        fields = 0; admitted = 0; refused = 0;
        Map<String, byte[]> files = new LinkedHashMap<>();
        try (var stream = getClass().getResourceAsStream("broad-gsea-engine-originals.zip")) {
            org.junit.jupiter.api.Assertions.assertNotNull(stream);
            try (var zip = new java.util.zip.ZipInputStream(stream)) {
                for (var e = zip.getNextEntry(); e != null; e = zip.getNextEntry()) {
                    org.junit.jupiter.api.Assertions.assertNull(files.put(e.getName(), zip.readAllBytes()));
                }
            }
        }
        String manifest = new String(files.remove("SHA256SUMS"), java.nio.charset.StandardCharsets.UTF_8);
        int entries = 0;
        for (String line : manifest.lines().toList()) {
            String[] p = line.split("  ", 2);
            byte[] bytes = files.get(p[1]); org.junit.jupiter.api.Assertions.assertNotNull(bytes, p[1]);
            org.junit.jupiter.api.Assertions.assertEquals(p[0], java.util.HexFormat.of().formatHex(
                java.security.MessageDigest.getInstance("SHA-256").digest(bytes)), p[1]); entries++;
        }
        org.junit.jupiter.api.Assertions.assertEquals(624, entries);
        org.junit.jupiter.api.Assertions.assertEquals(entries, files.size());
        for (var e : files.entrySet()) check(new String(e.getValue(), java.nio.charset.StandardCharsets.UTF_8).lines().toList(), e.getKey());
        org.junit.jupiter.api.Assertions.assertEquals(423, admitted);
        org.junit.jupiter.api.Assertions.assertEquals(201, refused);
        org.junit.jupiter.api.Assertions.assertEquals(200469, fields);
    }
''' + source[end:]
source=source.replace('private static void check(Path path) throws Exception {\n        List<String[]> rows = Files.readAllLines(path).stream()',
    'private static void check(List<String> lines, String path) throws Exception {\n        List<String[]> rows = lines.stream()')
source=source.replace('path.toString()', 'path')
(T/'src/test/java/org/jlinalg/enrichment/BroadGseaEngineTest.java').write_text(source,encoding='utf-8',newline='\n')
P=R/'build/gs-2/build/gsea-high-impact-2'
reference={}
for p in sorted((P/'original-workflow-forms-4.4.0-2/inputs').iterdir()):
    if p.is_file():reference['inputs/'+p.name]=p.read_bytes()
for v in ['4.4.0','4.3.2','4.3.3']:
    for mode in ['preranked','expression-phenotype','expression-geneset']:
        p=P/'original-api-4.4.0-3'/mode/'original.tsv' if v=='4.4.0' else P/'original-4.3-profiles-1'/v/('api-'+mode)/'original.tsv'
        reference['reference/'+v+'/'+mode+'.tsv']=p.read_bytes()
archive(Q/'complete-null-references.zip',reference)
(Q/'.gitattributes').write_bytes(b'* -text whitespace=cr-at-eol\n')
(B/'HANDOVER-FIXTURES.json').write_bytes(enc(dict(sweep_fixture=pin(fixture.read_bytes()),sweep_members=len(files),complete_null_references=pin((Q/'complete-null-references.zip').read_bytes()),reference_files={n:pin(b) for n,b in reference.items()})))
print(json.dumps(dict(status='PREPARED_EXACT_SOURCE_FIXTURES_AND_REGRESSION_TEST',sweep_fixture=pin(fixture.read_bytes()),reference_archive=pin((Q/'complete-null-references.zip').read_bytes()))),flush=True)
