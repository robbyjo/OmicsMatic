16 2 1
# A B
A A A A A A A A B B B B B B B B
