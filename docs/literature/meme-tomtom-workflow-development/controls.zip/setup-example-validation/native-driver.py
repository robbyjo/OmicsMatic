
import importlib.util,json,os,signal,subprocess,sys,time
from pathlib import Path
root,jar,checkout,archive=map(Path,sys.argv[1:]);assert not root.exists();root.mkdir(mode=0o700)
def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def run(name,command,expected=0,timeout=4000):
 with (root/(name+'.stdout')).open('xb') as out,(root/(name+'.stderr')).open('xb') as err:r=subprocess.run(list(map(str,command)),stdin=subprocess.DEVNULL,stdout=out,stderr=err,timeout=timeout)
 write(root/(name+'.json'),dict(command=list(map(str,command)),exit_code=r.returncode));assert r.returncode==expected,(name,r.returncode,expected);print(name+': exit '+str(r.returncode),flush=True)
java=['/usr/bin/java','-Xmx1024m','-XX:ActiveProcessorCount=2','-jar',jar,'tomtom-tools'];kit=root/'kit'
run('export',[*java,'--export-runtime-setup',kit]);setup=kit/'setup_tomtom.py'
run('permission-skip',['/usr/bin/python3','-I','-B',setup,'--report',root/'permission-skip'],3)
assert 'SKIP3' in (root/'permission-skip/WARNINGS.md').read_text() and not (root/'permission-skip/COMPLETED.json').exists()
(root/'bad-archive.tar.gz').write_bytes(b'not the exact source archive')
run('archive-integrity-failure',['/usr/bin/python3','-I','-B',setup,'--report',root/'archive-integrity-failure','--archive',root/'bad-archive.tar.gz','--allow-build','--research-nonprofit'],2)
assert 'FAIL2' in (root/'archive-integrity-failure/WARNINGS.md').read_text() and not (root/'archive-integrity-failure/COMPLETED.json').exists()
# Exercise the actual exported supervisor with real detached descendants, not a fake scientific runtime.
guard=root/'guard.py';guard.write_text("""import importlib.util,json,signal,sys
from pathlib import Path
spec=importlib.util.spec_from_file_location('guarded_setup',sys.argv[1]);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
def stop(sig,frame):raise module.Cancelled('controlled signal')
for sig in [signal.SIGTERM,signal.SIGINT]:signal.signal(sig,stop)
report=Path(sys.argv[2]);mode=sys.argv[3];report.mkdir(mode=0o700)
code='import json,os,subprocess,sys,time; from pathlib import Path; p=subprocess.Popen([sys.executable,"-c","import time; time.sleep(120)"],start_new_session=True); Path(sys.argv[1]).write_text(json.dumps(dict(parent=os.getpid(),child=p.pid))); '+('sys.exit(4)' if mode=='nonzero' else 'time.sleep(120)')
try:module.supervise([sys.executable,'-I','-B','-c',code,str(report/'workers.json')],report,timeout=1 if mode=='timeout' else 120)
except (Exception,KeyboardInterrupt) as error:(report/'CONTROL-ERROR.txt').write_text(str(error)+'\\n');sys.exit(2)
raise AssertionError('Control unexpectedly succeeded')
""")
guards=[]
for mode in ['cancel','timeout','nonzero']:
 report=root/('guard-'+mode)
 with (root/('guard-'+mode+'.stdout')).open('xb') as out,(root/('guard-'+mode+'.stderr')).open('xb') as err:
  command=['/usr/bin/python3','-I','-B',str(guard),str(setup),str(report),mode];process=subprocess.Popen(command,stdout=out,stderr=err,start_new_session=True)
  deadline=time.monotonic()+30
  while not (report/'workers.json').exists():
   assert process.poll() is None and time.monotonic()<deadline,'Owned-worker control failed before launch';time.sleep(.02)
  workers=json.loads((report/'workers.json').read_bytes())
  if mode=='cancel':process.send_signal(signal.SIGTERM)
  assert process.wait(timeout=30)==2
 assert all(not Path('/proc',str(pid)).exists() for pid in workers.values()),('owned worker survived',mode,workers)
 receipt=json.loads((report/'process.json').read_bytes());assert receipt['owned_live_after_cleanup']==[];guards.append(dict(mode=mode,workers=workers,owned_live_after_cleanup=[]));print('guard-'+mode+': owned descendants reaped',flush=True)
write(root/'GUARD-CONTROLS.json',guards)
run('source-setup',['/usr/bin/python3','-I','-B',setup,'--report',root/'source-setup','--archive',archive,'--allow-build','--research-nonprofit'])
completion=json.loads((root/'source-setup/COMPLETED.json').read_bytes());home,build=completion['home'],completion['build_evidence'];assert completion['owned_live_after_cleanup']==[]
run('documented-recipes',['/usr/bin/python3','-I','-B',checkout/'examples/tomtom/make_recipes.py','--out',root/'recipes'])
(root/'outputs').mkdir(mode=0o700)
for label in ['text','full']:
 run('documented-'+label,[*java,'--recipe',root/'recipes'/(label+'.json'),'--home',home,'--build-evidence',build,'--out',root/'outputs'/label])
 run('documented-verify-'+label,[*java,'--verify',root/'outputs'/label])
 doc=json.loads((root/'outputs'/label/'OUTPUT-AUDIT.json').read_bytes());assert doc['complete_reported_matches']==doc['complete_declared_pairs']==9
write(root/'COMPLETED.json',dict(status='PASSED_EXPORTED_SOURCE_SETUP_AND_BOTH_DOCUMENTED_PUBLIC_TOMTOM_WORKFLOWS',home=home,build_evidence=build,permission_skip=True,archive_failure=True,owned_worker_controls=guards,documented_workflows=2,public_analysis_admitted=True,biological_accuracy_certified=False))
