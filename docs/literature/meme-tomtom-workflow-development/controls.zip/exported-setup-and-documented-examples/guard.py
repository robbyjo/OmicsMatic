import importlib.util,json,signal,sys
from pathlib import Path
spec=importlib.util.spec_from_file_location('guarded_setup',sys.argv[1]);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
def stop(sig,frame):raise module.Cancelled('controlled signal')
for sig in [signal.SIGTERM,signal.SIGINT]:signal.signal(sig,stop)
report=Path(sys.argv[2]);mode=sys.argv[3];report.mkdir(mode=0o700)
code='import json,os,subprocess,sys,time; from pathlib import Path; p=subprocess.Popen([sys.executable,"-c","import time; time.sleep(120)"],start_new_session=True); Path(sys.argv[1]).write_text(json.dumps(dict(parent=os.getpid(),child=p.pid))); '+('sys.exit(4)' if mode=='nonzero' else 'time.sleep(120)')
try:module.supervise([sys.executable,'-I','-B','-c',code,str(report/'workers.json')],report,timeout=1 if mode=='timeout' else 120)
except (Exception,KeyboardInterrupt) as error:(report/'CONTROL-ERROR.txt').write_text(str(error)+'\n');sys.exit(2)
raise AssertionError('Control unexpectedly succeeded')
