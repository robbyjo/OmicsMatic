# FAIL2_SETUP_NOT_ADMITTED

Exact official archive length/hash differs; no original build launched

Required action: read WARNINGS.md, FAILURE.json when present, builder.stdout/stderr and every original build-evidence log. Setup is not runtime admission or a user analysis. SKIP3: required permission, download, compiler, Perl, library or supported host is unavailable; skip dependent analysis and complete only permitted setup. FAIL2: input/hash, build, capacity, cancellation or cleanup failure; retain every partial archive, report and native area, correct the named cause and use NEW paths. Never relocate the compiled home: original binaries embed their prefix. Require this report and build-evidence COMPLETED.json, then supply the recorded home and build_evidence to tomtom-tools; that command performs fresh runtime health and complete user-fit validation.
