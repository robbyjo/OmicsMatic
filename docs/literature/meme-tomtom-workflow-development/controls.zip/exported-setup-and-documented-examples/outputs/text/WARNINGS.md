# Tomtom warnings and required actions

WARNING: Exact original5.5.9 fitted comparisons; historical paper settings/inputs and biological accuracy are not certified. Declared native process limits do not guarantee the verifier JVM heap; use sufficient permitted Java memory for complete inputs/results.

WARNING: Original q-values use the complete tested orientation family, not only reported best matches. PAIR-LEDGER.tsv preserves unavailable numeric values as NA for unreported pairs. Printed zero can be floating-point underflow.

WARNING: Requested output mode=TEXT. Original input files are unchanged; staged command paths and producer locations are recorded explicitly. The native worker is retained for recovery; its recorded path is not opened by portable verification.

WARNING: SOURCE POPULATIONS: every declared record remains in raw files and motif-ledger.jsonl. No source exclusions are silently applied. Do not infer unreported values or recompute q-values from best-match rows.

WARNING: PATH MAPPING: safe staged filenames are command carriers; original paths remain literal producer metadata. Raw files are byte-identical. Display/database paths in newly generated output will refer to the staged carriers.

WARNING: ORIGINAL_TEXT_PRECISION: P/E/q cast to float32 before six-significant-digit printing; zero may be rounding or underflow. Preserve literal tokens and source-format envelopes; these are not confidence intervals or statistical calibration certification.

WARNING: ORIGINAL_Q_FAMILY: q-values use the original complete tested target-orientation population, not only reported best matches. Do not recalculate q-values from this table. Unreported pairs have unavailable values, never imputed zeros or biological absences.

WARNING: ORIGINAL_SMALL_DATABASE_WARNING: fewer than50 target motifs do not support accurate original P-value calibration; preserve stderr and do not infer biological significance.

WARNING: Original Tomtom emitted stderr. Read the complete process/process.stderr, including original small-database and numerical warnings; exit0 does not remove them.

Required action: read WARNINGS.md, FAILURE.json when present, metadata/producer.json, OUTPUT-AUDIT.json, PAIR-LEDGER.tsv and process/process.stderr/stdout/ledger. SKIP3 means a named exact runtime, permission, dependency or requested input capability is unavailable: supply it through permitted setup or leave the dependent analysis skipped. Analysis never installs. FAIL2 means invalid input, integrity, process, capacity, cleanup, cancellation or finalization failure: no result is admitted. Preserve the whole attempt/native worker and retry into NEW paths after correcting the named cause. Require overall COMPLETED.json plus tomtom-tools --verify; a component/runtime marker alone is insufficient. Portable verification checks complete captured contracts and integrity, not a current-host ticket, execution authenticity or biological accuracy. Do not zero-fill unreported comparisons, infer exact mathematical zero from printed zero, recalculate q-values from reported best matches or silently change source settings/output mode.
