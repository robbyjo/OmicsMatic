# FUMA WORKFLOW COMPLETED-WITH-REVIEW-WARNINGS

TYPED SUPPLIED-RESOURCE WORKFLOW ONLY. Existing native locus/mapping/GENE2FUNC modules and original MAGMA run with explicit inputs. No annotation or interaction discovery,score calculation,automatic installation,genome build inference or full hosted FUMA reconstruction. MAGMA uses separately supplied genome-wide SNP/GWAS inputs;it is never silently restricted to selected FUMA candidates. Required action: inspect every stage warning,source hash,resource-disposition and model/background choice.

STABLE MULTI-STAGE OUTPUT: this new directory is a journaled workspace,not an atomically renamed single analysis. Stage bundles keep their actual execution paths. A running/interrupted/failed/partially-skipped journal is not a completed workflow. Require both completed final manifest and analysis-status markers. Completed independent stage outputs remain retained;review their own hashes and warnings before any independent use.

expression-preparation: completed; exit=0. Read expression-preparation/WARNINGS.md and logs/expression-preparation.stderr.

expression: completed; exit=0. Read expression/WARNINGS.md and logs/expression.stderr.

Required action: review every stage/input/resource/namespace/model/background choice. For missing or forbidden MAGMA software,skip dependent analyses and use the exact installation/recovery named by its warning. Correct failed data/identity/budget contracts and rerun to a NEW workflow directory;no automatic retry,installation or candidate/score synthesis occurs. Cell Ranger remains excluded.
