# ANALYSIS WARNINGS

SUPPLIED PRECOMPUTED EXPRESSION AND DEG SETS ONLY. Exact resolved Ensembl IDs are required. Matrix values, row order and independent log2/norm labels come from your files. No ID conversion, expression normalization, DEG generation, heatmap clustering, cell-type MAGMA or hosted FUMA analysis is performed. Required action: supply the intended genome/annotation/expression/DEG releases and complete background; inspect every warning, source hash, gate and test family before interpreting results.
