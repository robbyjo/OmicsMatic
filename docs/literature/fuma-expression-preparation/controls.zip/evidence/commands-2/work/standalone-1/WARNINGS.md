# FUMA EXPRESSION PREPARATION WARNINGS REQUIRE REVIEW

NATIVE EXPRESSION PREPARATION ONLY: documented raw mean >1 eligibility, cap50, log2(x+1), sample centering and label averages. No DEG generation, t-tests, heatmap clustering, identifier conversion, ancestry/build inference, count-to-TPM normalization, batch correction or historical-resource reconstruction. Required action: supply correctly quantified TPM/RPKM, exact sample/label selections and namespace/release declarations; inspect all gene/sample decisions and threshold boundaries before downstream use.

TWO DIFFERENT AVERAGES: norm.tsv centers each gene over SELECTED SAMPLES before averaging by label. gene-covariates.tsv Average is the UNWEIGHTED mean of LABEL means, as in the documented MAGMA model. These differ for unequal label sample sizes. Required action: retain label-samples.tsv and do not substitute a sample-weighted center as the MAGMA Average covariate.

GENE ELIGIBILITY AND NAMESPACE: 2 of 4 genes passed strict RAW mean >1 in at least one selected label. The criterion precedes capping/logging; excluded genes remain in gene-audit.tsv. Version suffixes and case are preserved. IDs in gene-covariates.tsv must match the separately fitted MAGMA gene bundle; no Ensembl/Entrez conversion or historical gene universe is inferred. Required action: inspect exclusions and provide the intended annotation/namespace mapping before fitting.

RAW-MEAN BOUNDARY REVIEW: 1 gene rows have a label mean within1e-12 of1. Arithmetic uses stable scaled means; a rounding difference from a historical preprocessing implementation can alter a strict >1 decision. Required action: inspect gene-audit.tsv and compare the intended exact resource before claiming historical membership parity; do not reinterpret >1 as >=1.
