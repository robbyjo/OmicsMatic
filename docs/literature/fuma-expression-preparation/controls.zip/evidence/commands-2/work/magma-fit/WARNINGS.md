# MAGMA ANALYSIS WARNINGS

HIDDEN CONDITIONING VARIABLES: Average are included as covariates in upstream models and excluded from published coefficients. No output rows are silently filtered. Required action: inspect the declared target/model population, native logs, effective NGENES and hidden versus ordinary conditioning. Ordinary conditioning coefficients may still be reported per model; do not count them as independent target hypotheses. Declare the intended tissue/dataset correction family separately; --correct controls technical covariates, not multiple-test adjustment.

GENE-LEVEL MODEL REVIEW: competitive background is the input MAGMA gene-analysis universe after explicit property/missingness choices. Default technical corrections and outlier truncation remain upstream; inspect effective NGENES, coefficients, native logs and gsa.genes outputs. Positive set tests and two-sided property tests are defaults unless explicitly changed. Raw P-values are not automatically corrected across traits/analyses.

Required action: Inspect native logs, every input/annotation/gene/set status, LD ancestry, sample-size/model and missingness/correction choices before interpretation. Annotation alone is not statistical association and a gene Z score is unsigned evidence, not an allele effect. Reconcile historical tool versions and paper-specific preprocessing separately.
