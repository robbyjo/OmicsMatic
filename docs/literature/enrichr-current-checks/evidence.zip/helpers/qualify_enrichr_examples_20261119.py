from pathlib import Path
import subprocess,shutil,json,hashlib
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');B=A/'build/enrichr-high-impact-1';O=B/'workflow-examples-1';O.mkdir(exist_ok=False);stage=O/'stage';stage.mkdir();source=A/'examples/enrichr-workflow';target=stage/'examples/enrichr-workflow';shutil.copytree(source,target)
jar=B/'workflow-gradle-2/project-build/cli/omicsmatic-0.4.0.jar';copy=stage/'build/cli/omicsmatic-0.4.0.jar';copy.parent.mkdir(parents=True);shutil.copyfile(jar,copy)
def pin(p):
 with p.open('rb') as f:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(f,'sha256').hexdigest())
assert pin(copy)==pin(jar)
java='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe';cases=[]
for name in ['run-standard','run-custom','run-library','verify','replay','verify-replayed']:
 args=['-jar',str(copy),'enrichr-tools']+(['--verify','build/enrichr-example-replayed'] if name=='verify-replayed' else ['--request','examples/enrichr-workflow/'+name+'.json'])
 p=subprocess.run([java,*args],cwd=stage,capture_output=True);(O/(name+'.stdout')).write_bytes(p.stdout);(O/(name+'.stderr')).write_bytes(p.stderr)
 cases.append(dict(case=name,arguments=args,exit_code=p.returncode));print(name,p.returncode,flush=True)
 assert p.returncode==0,p.stderr.decode(errors='replace')
for name in ['terms.tsv','hits.tsv','query-ledger.tsv','server-query.tsv','memberships.tsv','library-terms.tsv','results/001.json','libraries/001.gmt']:
 assert (stage/'build/enrichr-example-standard'/name).read_bytes()==(stage/'build/enrichr-example-replayed'/name).read_bytes(),name
for p in source.iterdir():assert pin(p)==pin(target/p.name)
result=dict(status='PASS_DOCUMENTED_ENRICHR_EXAMPLES_NORMAL_GRADLE_JAR',candidate=pin(jar),sources={p.relative_to(A).as_posix():pin(p) for p in source.iterdir()},processes=cases,standard_replayed_tables_exact=True,synthetic_only=True,background_biologically_justified=False,whole_paper_reproduced=False)
(O/'COMPLETED.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print('PASS EXAMPLES',flush=True)
