from pathlib import Path
import subprocess,json,hashlib,csv
R=Path('D:/projects/JLinAlg');A=R/'build/high-impact-stats-1';B=A/'build/enrichr-high-impact-1';O=B/'workflow-normal-live-1';O.mkdir(exist_ok=False)
build=B/'workflow-gradle-validation-1';candidate=B/'workflow-gradle-2/project-build/cli/omicsmatic-0.4.0.jar';proof=json.loads((build/'BUILD.json').read_bytes());tests=json.loads((B/'workflow-handover-validation-2/COMPLETED.json').read_bytes())
def pin(p):return dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def encoded(v):return (json.dumps(v,indent=2)+'\n').encode()
def check_sources():
 for n,w in proof['sources'].items():assert pin(A/n)==w,n
 assert pin(candidate)==proof['candidate']==tests['candidate']
check_sources()
def run(label,args,expected=0):
 p=subprocess.run([str(x) for x in args],cwd=A,capture_output=True);(O/(label+'.stdout')).write_bytes(p.stdout);(O/(label+'.stderr')).write_bytes(p.stderr)
 if p.returncode!=expected:
  (O/'FAILURE.json').write_bytes(encoded(dict(case=label,exit_code=p.returncode,expected=expected)));print(p.stdout.decode(errors='replace')[-1000:]);print(p.stderr.decode(errors='replace')[-2500:]);raise RuntimeError((label,p.returncode,expected))
 print('PASS',label,p.returncode,flush=True);return p
java=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe');java25=Path('C:/Program Files/Java/jdk-25/bin/java.exe')
def linux(p):return '/mnt/d/'+str(p).replace('\\','/').split('D:/',1)[1]
wsl=['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--']
query=json.loads((B/'api-reference-4/query.json').read_bytes());background=json.loads((B/'api-reference-4/background.json').read_bytes())
live=O/'live';live.mkdir();(live/'query.txt').write_text('\n'.join(query)+'\n');(live/'background.txt').write_text('\n'.join(background)+'\n')
request=dict(schema_version=1,mode='RUN',out='standard',service_profile='enrichr-current-human-mouse-workflow-v1',operation='enrichment',allow_upload=True,libraries=['MSigDB_Hallmark_2020','GO_Biological_Process_2023'],query=dict(file='query.txt',format='lines'),background=dict(kind='server-default'),description='OmicsMatic synthetic normal source-build qualification; no participant data')
(live/'run-standard.json').write_bytes(encoded(request));run('live-standard-windows21',[java,'-Xmx2g','-jar',candidate,'enrichr-tools','--request',live/'run-standard.json'])
custom=dict(request,out='custom',background=dict(kind='explicit',file='background.txt',format='lines'),allow_unobserved_custom_normalization=True)
(live/'run-custom.json').write_bytes(encoded(custom));run('live-custom-windows21',[java,'-Xmx2g','-jar',candidate,'enrichr-tools','--request',live/'run-custom.json'])
resource={k:v for k,v in request.items() if k not in ['query','background','description']};resource.update(out='libraries',operation='library-download',allow_upload=False,libraries=['MSigDB_Hallmark_2020'])
(live/'run-libraries.json').write_bytes(encoded(resource));run('live-library-windows21',[java,'-Xmx2g','-jar',candidate,'enrichr-tools','--request',live/'run-libraries.json'])
for name in ['standard','custom','libraries']:
 run('offline-verify-windows25-'+name,[java25,'-Xmx2g','-jar',candidate,'enrichr-tools','--verify',live/name])
 run('offline-verify-linux21-'+name,wsl+['/usr/bin/java','-Xmx2g','-jar',linux(candidate),'enrichr-tools','--verify',linux(live/name)])
control=dict(schema_version=1,mode='REPLAY',analysis='standard',out='standard-replayed-linux');(live/'replay-linux.json').write_bytes(encoded(control))
run('offline-replay-linux21',wsl+['/usr/bin/java','-Xmx2g','-jar',linux(candidate),'enrichr-tools','--request',linux(live/'replay-linux.json')])
run('replayed-verify-windows25',[java25,'-Xmx2g','-jar',candidate,'enrichr-tools','--verify',live/'standard-replayed-linux'])
for file in ['terms.tsv','hits.tsv','library-terms.tsv','memberships.tsv','query-ledger.tsv','server-query.tsv','libraries/001.gmt','libraries/002.gmt','results/001.json','results/002.json']:
 assert (live/'standard'/file).read_bytes()==(live/'standard-replayed-linux'/file).read_bytes(),file
comparisons=[]
for mode in ['standard','custom']:
 root=live/mode;index=json.loads((root/'libraries.json').read_bytes())['libraries'];total=0
 with (root/'terms.tsv').open(encoding='utf-8',newline='') as stream:terms=list(csv.DictReader(stream,delimiter='\t'))
 with (root/'hits.tsv').open(encoding='utf-8',newline='') as stream:hits=list(csv.DictReader(stream,delimiter='\t'))
 for info in index:
  source=root/('wire/%04d.response'%info['results_wire_index']);original=json.loads(source.read_bytes(),parse_float=str,parse_int=str,parse_constant=str)[info['library']]
  expected=[];expected_terms=[];expected_hits=[]
  for r in original:
   expected.append(dict(rank=int(r[0]),term=r[1],p_value_token=r[2],odds_ratio_token=r[3],combined_score_token=r[4],hit_genes=r[5],adjusted_p_value_token=r[6],old_p_value_token=r[7],old_adjusted_p_value_token=r[8]))
   expected_terms.append(dict(library_index=str(info['library_index']),library=info['library'],rank=str(int(r[0])),term=r[1],p_value_token=r[2],odds_ratio_token=r[3],combined_score_token=r[4],adjusted_p_value_token=r[6],old_p_value_token=r[7],old_adjusted_p_value_token=r[8],reported_hit_entries=str(len(r[5]))))
   expected_hits.extend(dict(library_index=str(info['library_index']),library=info['library'],rank=str(int(r[0])),hit_index=str(i+1),gene=g) for i,g in enumerate(r[5]))
  generated=json.loads((root/('results/%03d.json'%info['library_index'])).read_bytes());assert generated['rows']==expected
  assert [r for r in terms if r['library']==info['library']]==expected_terms
  assert [r for r in hits if r['library']==info['library']]==expected_hits
  total+=len(expected);comparisons.append(dict(mode=mode,library=info['library'],rows=len(expected),hit_entries=len(expected_hits),all_nine_result_fields_compared=True,exact_numeric_tokens=True,source=pin(source),generated=pin(root/('results/%03d.json'%info['library_index']))))
 assert len(terms)==total
check_sources()
(O/'COMPLETED.json').write_bytes(encoded(dict(status='PASS_NORMAL_GRADLE_ENRICHR_LIVE_AND_CROSS_HOST_OFFLINE',candidate=pin(candidate),prior_tests=tests['tests'],tests_not_rerun=True,live_profiles=['standard-two-libraries','custom-background-two-libraries','library-resource-only'],offline_windows_linux_verify=True,offline_linux_replay_windows_verify=True,comparisons=comparisons,sources_unchanged=True,catalog_admitted=False,new_family_credit=0,whole_goal_complete=False)))
print('PASS NORMAL LIVE QUALIFICATION',sum(r['rows'] for r in comparisons),flush=True)
