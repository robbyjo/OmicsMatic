# completed-with-warnings

Single-causal-variant native ABF, pinned coloc 6.0.3 behavior. Supplied regional summary statistics only. No allele harmonization, GWAS/QTL fit, LD generation, multi-causal fit, historical-edition parity, whole-paper reproduction or biological validation.

NO_P_BELOW_1E_6_TRAIT_2: check that variance, not SE, was supplied

Required action: Read WARNINGS.md and analysis-status.json. SKIP3: the dependent analysis was skipped; restore the named exact permitted prerequisite and retry a NEW output. FAIL2: no complete result admitted; retain original inputs, partials and errors, correct the stated cause and retry a NEW output. Never silently repair IDs/alleles/probabilities/NaN/Inf or substitute algorithms. VERIFY rederives the native calculation from captured inputs; hashes are integrity checks, not signatures or authentication against coordinated fabrication. REPLAY first verifies, then recomputes into a NEW output.
