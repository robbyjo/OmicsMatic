from pathlib import Path
import json,os,subprocess,xml.etree.ElementTree as ET
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');B=A/'build/coloc-high-impact-1';O=B/'workflow-tests-3';O.mkdir();classes=O/'classes';classes.mkdir()
jar=B/'workflow-build-4/omicsmatic-0.4.0.jar';junit=A/'build/nfcore-atacseq121-1/linux-test-runtime-1/junit-platform-console-standalone-1.13.4.jar'
jdk=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin')
sources=[A/'src/test/java/org/jlinalg/cli/ColocAbfWorkflowTest.java']
cmd=[str(jdk/'javac.exe'),'--release','17','-encoding','UTF-8','-cp',os.pathsep.join(map(str,[jar,junit])),'-d',str(classes),*map(str,sources)]
r=subprocess.run(cmd,cwd=A,capture_output=True,timeout=120);(O/'javac.stdout').write_bytes(r.stdout);(O/'javac.stderr').write_bytes(r.stderr)
if r.returncode:print(r.stderr.decode(errors='replace'));raise SystemExit(r.returncode)
cmd=[str(jdk/'java.exe'),'-Xmx768m','-jar',str(junit),'execute','--class-path',os.pathsep.join(map(str,[classes,jar,A/'src/test/resources'])),'--select-class','org.jlinalg.cli.ColocAbfWorkflowTest','--reports-dir',str(O/'windows21-reports'),'--details','summary','--fail-if-no-tests']
with (O/'windows21.stdout').open('xb') as so,(O/'windows21.stderr').open('xb') as se:r=subprocess.run(cmd,cwd=A,stdout=so,stderr=se,timeout=300)
print((O/'windows21.stdout').read_text(encoding='utf-8',errors='replace')[-7000:]);print((O/'windows21.stderr').read_text(encoding='utf-8',errors='replace')[-1500:])
report=O/'windows21-reports/TEST-junit-jupiter.xml';counts=ET.parse(report).getroot().attrib if report.exists() else {}
result=dict(status='PASS_WINDOWS21_NATIVE_ABF_WORKFLOW_TESTS' if r.returncode==0 else 'FAILED_RETAINED',exit_code=r.returncode,counts=counts)
(O/'COMPLETED.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result));raise SystemExit(r.returncode)
