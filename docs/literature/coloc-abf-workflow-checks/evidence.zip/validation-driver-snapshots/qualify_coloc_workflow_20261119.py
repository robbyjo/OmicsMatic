from pathlib import Path
import hashlib,json,os,shutil,subprocess,xml.etree.ElementTree as ET
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');B=A/'build/coloc-high-impact-1';O=B/'workflow-qualification-1';O.mkdir()
jar=B/'workflow-build-4/omicsmatic-0.4.0.jar';test=B/'workflow-tests-3';classes=test/'classes';junit=A/'build/nfcore-atacseq121-1/linux-test-runtime-1/junit-platform-console-standalone-1.13.4.jar'
java21=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe');java25=Path('C:/Program Files/Java/jdk-25/bin/java.exe')
def linux(p):return '/mnt/d/'+str(p).replace('\\','/').split(':/',1)[1]
def pin(p):
 with p.open('rb') as s:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(s,'sha256').hexdigest())
def run(name,cmd,code=0):
 with (O/(name+'.stdout')).open('xb') as so,(O/(name+'.stderr')).open('xb') as se:r=subprocess.run(cmd,cwd=A,stdout=so,stderr=se,timeout=240)
 if r.returncode!=code:print((O/(name+'.stdout')).read_text(errors='replace')[-4000:]);print((O/(name+'.stderr')).read_text(errors='replace')[-2000:])
 assert r.returncode==code,(name,r.returncode,code)
 print(name,r.returncode,flush=True);return dict(case=name,exit_code=r.returncode,expected_exit=code)
rows=[];tests=[]
prior=json.loads((test/'COMPLETED.json').read_bytes());assert prior['exit_code']==0 and prior['counts']['tests']=='62';tests.append(dict(host='windows21',**prior))
for host,prefix,cp in [('windows25',[str(java25)],os.pathsep.join(map(str,[classes,jar,A/'src/test/resources']))),('linux21',['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/java'],':'.join(linux(p) for p in [classes,jar,A/'src/test/resources']))]:
 report=O/(host+'-reports');jpath=str(junit) if host=='windows25' else linux(junit);rpath=str(report) if host=='windows25' else linux(report)
 rows.append(run(host+'-junit',prefix+['-Xmx768m','-jar',jpath,'execute','--class-path',cp,'--select-class','org.jlinalg.cli.ColocAbfWorkflowTest','--reports-dir',rpath,'--details','summary','--fail-if-no-tests']))
 counts=ET.parse(report/'TEST-junit-jupiter.xml').getroot().attrib;assert counts['tests']=='62' and all(counts[k]=='0' for k in ['skipped','failures','errors']);tests.append(dict(host=host,exit_code=0,counts=counts))
example=A/'examples/coloc-abf-workflow';pilots={}
for host,prefix in [('windows21',[str(java21)]),('windows25',[str(java25)]),('linux21',['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/java'])]:
 home=O/(host+'-packaged');home.mkdir();pilots[host]=home
 for n in ['trait1.tsv','trait2.tsv']:shutil.copyfile(example/n,home/n)
 request=json.loads((example/'run.json').read_bytes());request['out']='analysis';(home/'run.json').write_text(json.dumps(request,indent=2)+'\n',encoding='utf-8')
 for mode in ['VERIFY','REPLAY']:
  v=dict(schema_version=1,mode=mode,analysis='analysis')
  if mode=='REPLAY':v['out']='replayed'
  (home/(mode.lower()+'.json')).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
 native=lambda p:str(p) if host!='linux21' else linux(p)
 for mode in ['run','verify','replay']:rows.append(run(host+'-packaged-'+mode,prefix+['-Xmx512m','-jar',native(jar),'coloc-abf','--request',native(home/(mode+'.json'))]))
 assert (home/'analysis/COMPLETED.json').exists() and (home/'replayed/COMPLETED.json').exists()
home=pilots['windows21'];cross=O/'linux-cross-host';cross.mkdir();before={p.relative_to(home/'analysis').as_posix():pin(p) for p in (home/'analysis').rglob('*') if p.is_file()}
rows.append(run('linux-verify-windows-bundle',['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/java','-Xmx512m','-jar',linux(jar),'coloc-abf','--verify',linux(home/'analysis')]))
request=dict(schema_version=1,mode='REPLAY',analysis=linux(home/'analysis'),out='analysis');(cross/'replay.json').write_text(json.dumps(request,indent=2)+'\n',encoding='utf-8')
rows.append(run('linux-replay-windows-bundle',['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/java','-Xmx512m','-jar',linux(jar),'coloc-abf','--request',linux(cross/'replay.json')]))
after={p.relative_to(home/'analysis').as_posix():pin(p) for p in (home/'analysis').rglob('*') if p.is_file()};assert before==after
result=dict(status='PASS_NATIVE_ABF_WORKFLOW_THREE_JVMS_PACKAGED_AND_CROSS_HOST',candidate=pin(jar),tests=tests,processes=rows,windows_bundle_preserved=True,new_family_credit=0,whole_goal_complete=False)
(O/'COMPLETED.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(result['status'],flush=True)
