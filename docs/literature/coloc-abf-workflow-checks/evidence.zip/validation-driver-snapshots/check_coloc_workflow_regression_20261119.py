from pathlib import Path
import json,os,subprocess,xml.etree.ElementTree as ET
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');B=A/'build/coloc-high-impact-1';O=B/'workflow-regression-2';O.mkdir();classes=O/'classes';classes.mkdir();tmp=O/'tmp';tmp.mkdir()
jar=B/'workflow-build-4/omicsmatic-0.4.0.jar';junit=A/'build/nfcore-atacseq121-1/linux-test-runtime-1/junit-platform-console-standalone-1.13.4.jar';jdk=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin')
def run(name,cmd,code=0):
 with (O/(name+'.stdout')).open('xb') as so,(O/(name+'.stderr')).open('xb') as se:r=subprocess.run(cmd,cwd=A,stdout=so,stderr=se,timeout=180)
 if r.returncode!=code:print((O/(name+'.stdout')).read_text(errors='replace')[-2000:]);print((O/(name+'.stderr')).read_text(errors='replace')[-2000:])
 assert r.returncode==code,(name,r.returncode,code);print(name,r.returncode,flush=True);return dict(case=name,exit_code=r.returncode)
rows=[run('compile',[str(jdk/'javac.exe'),'--release','17','-encoding','UTF-8','-cp',os.pathsep.join(map(str,[jar,junit])),'-d',str(classes),str(A/'src/test/java/org/jlinalg/cli/FineMappingCliTest.java'),str(A/'src/test/java/org/jlinalg/cli/RunLogTest.java')])]
rows.append(run('old-susie-coloc',[str(jdk/'java.exe'),'-Xmx768m','-Djava.io.tmpdir='+str(tmp),'-Djunit.jupiter.tempdir.cleanup.mode.default=NEVER','-jar',str(junit),'execute','--class-path',os.pathsep.join(map(str,[classes,jar,A/'src/test/resources'])),'--select-class','org.jlinalg.cli.FineMappingCliTest','--reports-dir',str(O/'reports'),'--details','summary','--fail-if-no-tests']))
counts=ET.parse(O/'reports/TEST-junit-jupiter.xml').getroot().attrib;assert counts['tests']=='4' and all(counts[k]=='0' for k in ['skipped','failures','errors'])
py='C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
rows.append(run('previous-component-readback',[py,'-X','utf8','-B',str(A/'tools/literature/verify_coloc_abf_handover.py'),'--out',str(O/'previous-component-readback')]))
linux=lambda p:'/mnt/d/'+str(p).replace('\\','/').split(':/',1)[1]
link=O/'linux-symlink-control';link.mkdir();example=A/'examples/coloc-abf-workflow';r=json.loads((example/'run.json').read_bytes());r['out']='analysis';(link/'run.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
for n in ['trait1-real.tsv','trait2.tsv']:(link/n).write_bytes((example/('trait1.tsv' if n.startswith('trait1') else n)).read_bytes())
code="from pathlib import Path; p=Path("+repr(linux(link))+ "); (p/'trait1.tsv').symlink_to('trait1-real.tsv')"
rows.append(run('create-owned-linux-symlink',['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/python3','-c',code]))
rows.append(run('linux-refuse-symlink-input',['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/java','-jar',linux(jar),'coloc-abf','--request',linux(link/'run.json')],2))
assert not (link/'analysis/COMPLETED.json').exists();assert json.loads((link/'analysis/analysis-status.json').read_bytes())['results_admitted'] is False
result=dict(status='PASS_OLD_SUSIE_COLOC_REGRESSION_PREDECESSOR_AND_SYMLINK_CONTROL',records=rows,old_tests=counts,whole_goal_complete=False,new_family_credit=0)
(O/'COMPLETED.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(result['status'],flush=True)
