from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,sys,time

root=Path('/mnt/d/projects/JLinAlg');base=root/'build/literature-review/shapeit-runtime';out=base/'source-install-attempt-2'
paths=[root/'tools/literature/build_shapeit_runtime.py',root/'tools/literature/test_build_shapeit_runtime.py',*sorted((root/'tools/literature/shapeit-source-build').iterdir())]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
records=[]
for p in paths:
    name=p.relative_to(root).as_posix();target=out/'source'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
    records.append(dict(path=name,bytes=p.stat().st_size,sha256=sha(p)))
(out/'source-manifest.json').write_text(json.dumps(records,indent=2)+'\n')
command=[sys.executable,str(root/'tools/literature/build_shapeit_runtime.py'),'--work','/opt/omicsmatic-shapeit-source-install-attempt-2','--home','/opt/omicsmatic-shapeit-source-runtime-attempt-2','--cache',str(base/'source-download-pins-1'),'--report',str(out/'report.json'),'--allow-download','--allow-source-build','--allow-install']
started=time.monotonic()
with (out/'stdout').open('xb') as stdout,(out/'stderr').open('xb') as stderr:
    child=subprocess.Popen(command,cwd=root,stdout=stdout,stderr=stderr)
    (out/'running.json').write_text(json.dumps(dict(controller_pid=os.getpid(),child_pid=child.pid,command=command,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n')
    code=child.wait()
for item in records:assert sha(root/item['path'])==item['sha256'],item['path']
report=json.loads((out/'report.json').read_bytes())
observed=dict(status='completed-source-installer-control' if code==0 else 'retained-failed-source-installer-control',exit_code=code,elapsed_seconds=time.monotonic()-started,source_unchanged=True,report_sha256=sha(out/'report.json'),runtime_home=report.get('home'),builder_status=report['status'])
(out/'observed.json').write_text(json.dumps(observed,indent=2)+'\n');print(json.dumps(observed,indent=2));print((out/'stderr').read_text()[-2000:]);raise SystemExit(code)
