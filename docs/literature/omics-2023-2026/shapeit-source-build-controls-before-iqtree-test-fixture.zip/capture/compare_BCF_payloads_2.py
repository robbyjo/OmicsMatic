from pathlib import Path
import difflib,gzip,hashlib,json,struct

root=Path('/mnt/d/projects/JLinAlg');base=root/'build/literature-review/shapeit-runtime'
current=Path('/opt/omicsmatic-shapeit-source-built-runtime-controls-2');prior=Path('/opt/omicsmatic-shapeit-dev-1')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def decode(path):
    assert path.stat().st_size<2097152
    with gzip.open(path,'rb') as source:
        raw=source.read(8388609);assert len(raw)<=8388608 and not source.read(1)
    assert raw[:5]==b'BCF\x02\x02';length=struct.unpack_from('<I',raw,5)[0];assert 0<length<=1048576
    header,records=raw[9:9+length].decode(),raw[9+length:];offset=rows=0
    while offset<len(records):
        assert offset+8<=len(records);shared,individual=struct.unpack_from('<II',records,offset);assert shared>=24
        offset+=8+shared+individual;assert offset<=len(records);rows+=1
    assert offset==len(records)
    return header,records,rows

cases=[]
for group,previous_group in [('common','owned-public-cli-controls-3'),('policies','owned-common-policy-controls-3')]:
    for directory in sorted((current/group).iterdir()):
        path=directory/'analysis/phased.bcf'
        if not path.exists():continue
        previous=prior/previous_group/directory.name/'analysis/phased.bcf'
        a,ar,an=decode(previous);c,cr,cn=decode(path)
        old_dates=[x for x in a.splitlines() if x.startswith('##fileDate=')]
        new_dates=[x for x in c.splitlines() if x.startswith('##fileDate=')]
        assert len(old_dates)==len(new_dates)==1
        assert [x for x in a.splitlines() if not x.startswith('##fileDate=')]==[x for x in c.splitlines() if not x.startswith('##fileDate=')]
        assert ar==cr and an==cn
        cases.append(dict(group=group,name=directory.name,selected_rows=cn,record_bytes=len(cr),record_payload_exact=True,
            old_record_sha256=sha(ar),new_record_sha256=sha(cr),old_file_sha256=sha(previous.read_bytes()),new_file_sha256=sha(path.read_bytes()),
            header_only_fileDate_diff=True,old_fileDate=old_dates[0],new_fileDate=new_dates[0],
            header_diff=list(difflib.unified_diff(a.splitlines(),c.splitlines(),fromfile='prior',tofile='source-built',lineterm=''))))
assert len(cases)==9 and sum(x['selected_rows'] for x in cases)==1131
record=dict(status='passed-nine-complete-BCF-record-payload-parity-controls',fits=9,selected_rows=1131,
    identical_record_payloads=9,whole_files_retagged=False,only_header_fileDate_diff=True,cases=cases,
    scope='Exact complete raw BCF record-byte parity on these retained seeded ordinary-GT controls. Timestamp headers and original complete files are preserved; biological phase accuracy and whole-paper reproduction are not certified.')
out=base/'source-built-runtime-controls-2/BCF-record-parity-complete.json'
with out.open('x') as output:output.write(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='cases'}))
