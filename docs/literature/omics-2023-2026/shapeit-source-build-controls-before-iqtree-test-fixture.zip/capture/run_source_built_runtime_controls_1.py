from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time

root=Path('/mnt/d/projects/JLinAlg');base=root/'build/literature-review/shapeit-runtime'
report=base/'source-built-runtime-controls-1';report.mkdir(exist_ok=False)
work=Path('/opt/omicsmatic-shapeit-source-built-runtime-controls-1');work.mkdir(exist_ok=False)
runtime=Path('/opt/omicsmatic-shapeit-source-runtime-attempt-2')
candidate=base/'owned-public-cli-3/omicsmatic-candidate.jar';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(candidate)=='480e6257e5ad500d3e3f33df661e21c3bada6c68e8eacb44bafd6b5ab82a75e2'
setup=json.loads((base/'source-install-attempt-2/report.json').read_bytes())
assert setup['status']=='installed-exact-source-built-runtime-only' and setup['scientific_analysis_admitted'] is False
assert setup['builder_sha256']==sha(root/'tools/literature/build_shapeit_runtime.py')
lock=json.loads((root/'tools/literature/shapeit-runtime-lock.json').read_bytes())
for name,expected in lock['files'].items():assert sha(runtime/name)==expected['sha256'] and (runtime/name).stat().st_size==expected['bytes']
marker_before=sha(runtime/'.omicsmatic-shapeit.json');runs=[]
for name,old_report,old_work,source_path in [
 ('common','owned-public-cli-3','/opt/omicsmatic-shapeit-dev-1/owned-public-cli-controls-3',base/'owned-public-cli-3/controls.py'),
 ('policies','owned-common-policy-controls-3','/opt/omicsmatic-shapeit-dev-1/owned-common-policy-controls-3',base/'owned-common-policy-controls-3/controls.py'),
 ('transport','owned-public-transport-2','/opt/omicsmatic-shapeit-dev-1/owned-public-transport-controls-2',base/'owned-public-transport-2/controls.py')]:
 text=source_path.read_text();text=text.replace("report=root/'build/literature-review/shapeit-runtime/"+old_report+"'", "report=root/'build/literature-review/shapeit-runtime/source-built-runtime-controls-1/"+name+"'")
 text=text.replace("report=r/'build/literature-review/shapeit-runtime/"+old_report+"'", "report=r/'build/literature-review/shapeit-runtime/source-built-runtime-controls-1/"+name+"'")
 text=text.replace("work=Path('"+old_work+"')", "work=Path('"+str(work/name)+"')")
 text=text.replace('/opt/omicsmatic-shapeit-dev-1/managed-common-runtime-2',str(runtime))
 if name=='common':text=text.replace("candidate=report/'omicsmatic-candidate.jar'", "candidate=Path('"+str(candidate)+"')")
 # Policy/transport controls reuse previously frozen synthetic inputs and patcher by hash.
 target=report/(name+'.py');target.write_text(text)
 started=time.monotonic()
 with (report/(name+'.stdout')).open('xb') as stdout,(report/(name+'.stderr')).open('xb') as stderr:
  command=[sys.executable,str(target)];child=subprocess.Popen(command,cwd=root,stdout=stdout,stderr=stderr)
  (report/'running.json').write_text(json.dumps(dict(controller_pid=os.getpid(),child_pid=child.pid,name=name,command=command),indent=2)+'\n');code=child.wait()
 runs.append(dict(name=name,exit_code=code,elapsed_seconds=time.monotonic()-started,source_controller_sha256=sha(source_path),controller_sha256=sha(target)))
 (report/'runs.json').write_text(json.dumps(runs,indent=2)+'\n')
 assert code==0,(name,(report/(name+'.stderr')).read_text()[-2500:]);print(name,'PASSED',flush=True)
 assert sha(runtime/'.omicsmatic-shapeit.json')==marker_before

protocols=successful=0;rows=targets=refs=constraints=source_an=0;tables=raw_bcf_equal=0
for group in ['common','policies','transport']:
 for destination in sorted((work/group).iterdir()):
  if not destination.is_dir():continue
  manifest_path=destination/'manifest.json'
  if not manifest_path.exists():continue
  manifest=json.loads(manifest_path.read_bytes());session=json.loads((destination/'session.json').read_bytes());protocols+=1
  for name,expected in manifest['files'].items():
   p=destination/name;assert p.is_file() and not p.is_symlink() and p.stat().st_size==expected['bytes'] and sha(p)==expected['sha256'],str(p)
  actual_files={p.relative_to(destination).as_posix() for p in destination.rglob('*') if p.is_file()}
  assert actual_files==set(manifest['files'])|{'manifest.json','COMPLETED.json'} if (destination/'COMPLETED.json').exists() else actual_files==set(manifest['files'])|{'manifest.json'}
  if not (destination/'COMPLETED.json').exists():assert session['scientific_result_admitted'] is False;continue
  complete=json.loads((destination/'COMPLETED.json').read_bytes());assert complete['manifest_sha256']==sha(manifest_path) and complete['scientific_result_admitted'] is True and complete['phase_accuracy_certified'] is False
  successful+=1;data=json.loads((destination/'analysis/analysis.json').read_bytes());admission=data['admission']
  rows+=admission['selectedRows'];targets+=admission['selectedTargetCells'];refs+=2*admission['selectedReferenceCells'];constraints+=admission['appliedScaffoldConstraints'];source_an+=data['source_AN_includes_reference_rows']
  prior=Path('/opt/omicsmatic-shapeit-dev-1')/('owned-public-cli-controls-3' if group=='common' else 'owned-common-policy-controls-3')/destination.name
  for name in ['input-count-review.tsv','output-audit/target-allele-counts.tsv']:
   assert (destination/'analysis'/name).read_bytes()==(prior/'analysis'/name).read_bytes();tables+=1
  if (destination/'analysis/phased.bcf').read_bytes()==(prior/'analysis/phased.bcf').read_bytes():raw_bcf_equal+=1
  for role in ['join-process','fit-process']:
   for suffix in ['', '.loader-check']:
    ledger=json.loads((destination/'analysis'/(role+suffix)/'process.json').read_bytes());assert ledger['owned_live_after_cleanup']==[] and ledger['status']=='completed-process-only'
assert (protocols,successful,rows,targets,refs,constraints,source_an,tables)==(20,9,1131,41470,30160,573,377,18)
assert sha(runtime/'.omicsmatic-shapeit.json')==marker_before
for name,expected in lock['files'].items():assert sha(runtime/name)==expected['sha256']
observed=dict(status='passed-source-built-runtime-twenty-public-protocols',candidate_sha256=sha(candidate),setup_report_sha256=sha(base/'source-install-attempt-2/report.json'),
 runtime_marker_sha256=marker_before,protocols=protocols,actual_successful_fits=successful,pre_fit_policy_refusals=6,unsupported_transport_skips=4,malformed_compression_failures=1,
 selected_rows=rows,target_cells=targets,reference_haplotype_cells=refs,applied_scaffold_constraints=constraints,source_AN_includes_reference_rows=source_an,
 byte_equal_count_tables=tables,byte_equal_original_fitting_BCFs=raw_bcf_equal,runtime_unchanged=True,runs=runs,phase_accuracy_certified=False,whole_paper_reproduced=False)
(report/'observed.json').write_text(json.dumps(observed,indent=2)+'\n');print(json.dumps(observed,indent=2))
