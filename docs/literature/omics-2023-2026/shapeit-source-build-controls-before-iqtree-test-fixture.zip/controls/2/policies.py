from pathlib import Path
import hashlib,json,os,subprocess
r=Path('/mnt/d/projects/JLinAlg');report=r/'build/literature-review/shapeit-runtime/source-built-runtime-controls-2/policies';work=Path('/opt/omicsmatic-shapeit-source-built-runtime-controls-2/policies');work.mkdir();prefix=Path('/opt/omicsmatic-shapeit-dev-1/.pixi/envs/default');candidate=r/'build/literature-review/shapeit-runtime/owned-public-cli-3/omicsmatic-candidate.jar';source=r/'build/literature-review/shapeit-runtime/PatchCommonCounts.cpp';records=[]
env=dict(PATH=str(prefix/'bin')+':/usr/bin:/bin',LD_LIBRARY_PATH=str(prefix/'lib'),LC_ALL='C');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(name,command):
 with (work/(name+'.stdout')).open('wb') as stdout,(work/(name+'.stderr')).open('wb') as stderr:result=subprocess.run(list(map(str,command)),env=env,stdout=stdout,stderr=stderr,timeout=180)
 records.append(dict(name=name,command=list(map(str,command)),exit_code=result.returncode));return result.returncode
program=Path('/opt/omicsmatic-shapeit-dev-1/owned-common-policy-controls-1/patch-counts');original=Path('/opt/omicsmatic-shapeit-dev-1/owned-common-controls-1/input-cohort-default/panel-0.bcf');patched=Path('/opt/omicsmatic-shapeit-dev-1/owned-common-policy-controls-1/counts-mismatch.bcf');previous=json.loads(Path('/opt/omicsmatic-shapeit-dev-1/owned-common-policy-controls-1/observed.json').read_bytes());assert sha(source)==previous['source_sha256'] and sha(program)==previous['patcher_sha256'] and sha(patched)==previous['patched_sha256'];records.append(dict(name='reuse-verified-completed-fixture-build',original_report='/opt/omicsmatic-shapeit-dev-1/owned-common-policy-controls-1/observed.json',fixture_sha256=sha(patched)))
base=json.loads(Path('/opt/omicsmatic-shapeit-dev-1/owned-public-cli-controls-3/cohort-default.recipe.json').read_bytes());outcomes=[]
for name,counts,missing,target,expected,code in [
 ('count-strict','REQUIRE_SAMPLE_COUNTS','SOURCE_WHOLE_GENOTYPE_IMPUTATION',patched,'Declared AC/AN differs',2),
 ('count-declared','USE_DECLARED_COUNTS','SOURCE_WHOLE_GENOTYPE_IMPUTATION',patched,None,0),
 ('missing-complete','REQUIRE_SAMPLE_COUNTS','REQUIRE_COMPLETE',original,'Target missing GT violates REQUIRE_COMPLETE',2)]:
 recipe=json.loads(json.dumps(base));recipe['target']=str(target);recipe['parameters']['count_policy']=counts;recipe['parameters']['missing_policy']=missing;path=work/(name+'.recipe.json');path.write_text(json.dumps(recipe,indent=2)+'\n');dest=work/name
 command=['/usr/bin/java','-Xmx128m','-Dsamjdk.use_libdeflate=false','-jar',candidate,'shapeit-tools','--recipe',path,'--home','/opt/omicsmatic-shapeit-source-runtime-attempt-3','--out',dest];actual=run(name,command);assert actual==code,(name,actual)
 session=json.loads((dest/'session.json').read_bytes())
 if expected:assert expected in session['error'] and not (dest/'COMPLETED.json').exists() and not (dest/'analysis/fit-process').exists()
 else:
  complete=json.loads((dest/'COMPLETED.json').read_bytes());assert complete['manifest_sha256']==sha(dest/'manifest.json');native=json.loads((dest/'analysis/analysis.json').read_bytes());assert native['admission']['declaredCountMismatchRows']==1 and native['admission']['selectedRows']==126;assert 'DECLARED COUNT FILTERING' in (dest/'WARNINGS.md').read_text();assert sha(dest/'analysis/staged/target.bcf')==sha(patched);assert native['source_AN_includes_reference_rows']==0
  table=(dest/'analysis/input-count-review.tsv').read_text().splitlines();assert len(table)==127 and sum(line.endswith('false') for line in table[1:])==1
 outcomes.append(dict(name=name,exit_code=actual,expected_refusal=expected,manifest_sha256=sha(dest/'manifest.json')));print(name,'PASS',flush=True)
observed=dict(status='passed-packaged-common-count-and-missing-policies',source_sha256=sha(source),candidate_sha256=sha(candidate),original_sha256=sha(original),patched_sha256=sha(patched),patcher_sha256=sha(program),htslib_sha256=sha((prefix/'lib/libhts.so.3').resolve()),runs=records,outcomes=outcomes)
(work/'observed.json').write_text(json.dumps(observed,indent=2)+'\n');print('POLICY CONTROLS PASSED',flush=True)
