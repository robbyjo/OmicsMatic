from pathlib import Path
import gzip,hashlib,json,subprocess,zipfile
root=Path('/mnt/d/projects/JLinAlg');report=root/'build/literature-review/shapeit-runtime/source-built-runtime-controls-1/transport';work=Path('/opt/omicsmatic-shapeit-source-built-runtime-controls-1/transport');work.mkdir();candidate=root/'build/literature-review/shapeit-runtime/owned-public-cli-3/omicsmatic-candidate.jar';runtime='/opt/omicsmatic-shapeit-source-runtime-attempt-2';base=json.loads(Path('/opt/omicsmatic-shapeit-dev-1/owned-public-cli-controls-3/cohort-default.recipe.json').read_bytes());records=[]
original=Path('/opt/omicsmatic-shapeit-dev-1/owned-common-controls-1/input-cohort-default/panel-0.bcf');bare=work/'bare.bcf';bare.write_bytes(gzip.decompress(original.read_bytes()))
vcf=work/'plain.vcf';vcf.write_text('##fileformat=VCFv4.3\n##contig=<ID=20,length=1000000>\n##FORMAT=<ID=GT,Number=1,Type=String,Description=Genotype>\n#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS0\n20\t1000\tv1\tA\tG\t.\tPASS\t.\tGT\t0/1\n');compressed=work/'plain.vcf.gz';compressed.write_bytes(gzip.compress(vcf.read_bytes(),mtime=0));invalid=work/'invalid.bcf';invalid.write_bytes(bytes([31,139,8]))
fixture=root/'src/test/resources/org/jlinalg/cli/shapeit-joined/original-controls.zip'
with zipfile.ZipFile(fixture) as z:
 case=next(c for c in json.loads(z.read('cases.json')) if c['name']=='selection-binary-main-formats');binary=work/'binary.bcf'
 for b in case['bindings']:
  if b['kind'] in ['B','I']:(binary if b['kind']=='B' else work/'binary.bcf.csi').write_bytes(z.read(b['member']))
for name,input,expected,reason in [('bare-bcf',bare,3,'bare BCF and VCF'),('plain-vcf',vcf,3,'bare BCF and VCF'),('gzip-vcf',compressed,3,'VCF staging'),('binary-xcf',binary,3,'XCF binary genotype'),('malformed-gzip',invalid,2,'Compressed input header is truncated or invalid')]:
 request=json.loads(json.dumps(base));request['target']=str(input);recipe=work/(name+'.recipe.json');recipe.write_text(json.dumps(request,indent=2)+'\n');destination=work/name;command=['/usr/bin/java','-Xmx128m','-Dsamjdk.use_libdeflate=false','-jar',str(candidate),'shapeit-tools','--recipe',str(recipe),'--home',runtime,'--out',str(destination)]
 with (work/(name+'.stdout')).open('wb') as stdout,(work/(name+'.stderr')).open('wb') as stderr:result=subprocess.run(command,stdout=stdout,stderr=stderr,timeout=60)
 assert result.returncode==expected,(name,result.returncode);session=json.loads((destination/'session.json').read_bytes());assert session['scientific_result_admitted'] is False
 if reason:assert reason in session['error'],session['error']
 assert not (destination/'COMPLETED.json').exists() and not (destination/'analysis/join-process').exists() and not (destination/'analysis/fit-process').exists();assert 'Required action' in (destination/'WARNINGS.md').read_text();records.append(dict(name=name,expected_exit=expected,actual_exit=result.returncode,error=session['error'],command=command));print(name,'PASS',flush=True)
(work/'observed.json').write_text(json.dumps(dict(status='passed-packaged-transport-skip-and-invalid-input-controls',candidate_sha256=hashlib.sha256(candidate.read_bytes()).hexdigest(),binary_fixture_scope='Only existing indexed BCF XCF-header transport is read before capability refusal. Empty .bin/.fam are not consumed, and binary genotype decoding is not claimed.',controls=records),indent=2)+'\n')
