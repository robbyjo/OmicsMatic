# SHAPEIT FAIL2 ANALYSIS FAILED

ANALYSIS FAILED: SHAPEIT common analysis failed; no result is admitted: Declared AC/AN differs from called selected TARGET genotypes; review metadata or use an appropriate explicit declared-count policy

Required action: inspect WARNINGS.md, session.json and the retained preparation/process/output-audit records. A public result requires COMPLETED.json with the matching manifest hash. Missing or forbidden runtime/capability requires SKIP3; invalid input, integrity, execution or capacity requires FAIL2. Preserve failed/provisional output, correct the stated cause and rerun to a NEW directory. Analysis never installs or substitutes source profiles. Export setup with shapeit-tools --export-runtime-setup NEW_DIRECTORY; the current adopter needs existing permitted exact build members and does not download or compile. Use Linux x86_64 Python3.11+ and Linux Java (WSL on Windows).
