# SHAPEIT analysis warnings

UPSTREAM PARTIAL-MISSING POLICY: 1 supplied observed alleles occur in calls the original reader treats as wholly missing. Required action: review those original calls and the source imputation policy; dosage preservation is guaranteed only for reader-defined observed calls.

SCIENTIFIC REVIEW REQUIRED: complete selected-variant/sample, raw output EOF, source-defined dosage, AC/AN and applied-scaffold checks passed. Runtime/process admission, pedigree/haploid adjustments, rare/ligation/posterior contracts and biological phase accuracy require their own verification.

DECLARED COUNT FILTERING: 1 selected panel records have AC/AN different from physical called genotypes. The source scanner used the original declared counts under USE_DECLARED_COUNTS. Review input-count-review.tsv before interpreting filtering; original metadata were not retagged.

UNIFORM GENETIC MAP: original 1 cM/Mb default was used. Genome-build and study suitability require investigator review.

SCOPE: original c34d ordinary diploid-GT common stage only, before optional pedigree/haploid processing. Binary genotypes, phase-set/pedigree/haploid options, rare phasing, ligation and historical singleton-posterior workflows are not admitted. Genotype preservation is not phase-accuracy or convergence validation.

Required action: preserve original output and use the verified target-count table for target-specific allele frequencies. Review all warnings before interpretation. Correct a failed analysis and rerun to a fresh output directory.
