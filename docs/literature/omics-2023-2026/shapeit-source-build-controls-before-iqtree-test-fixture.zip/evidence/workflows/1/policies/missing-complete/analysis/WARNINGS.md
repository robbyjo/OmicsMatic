# FAIL2 no scientific result is admitted
java.io.IOException: Target missing GT violates REQUIRE_COMPLETE; choose an appropriate explicit missing-call policy or correct the input
Required action: preserve original inputs, failed state and logs. Supply the permitted exact runtime or correct the named input/capacity/integrity cause, then rerun to a fresh output directory. Never admit a partial output.
