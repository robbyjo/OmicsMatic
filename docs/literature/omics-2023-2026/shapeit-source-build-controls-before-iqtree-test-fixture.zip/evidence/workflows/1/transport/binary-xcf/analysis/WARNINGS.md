# SKIP3 runtime unavailable
org.jlinalg.cli.ShapeitRuntime$Unavailable: XCF binary genotype transport requires a separately validated workflow; dependent fitting is skipped
Required action: preserve original inputs, failed state and logs. Supply the permitted exact runtime or correct the named input/capacity/integrity cause, then rerun to a fresh output directory. Never admit a partial output.
