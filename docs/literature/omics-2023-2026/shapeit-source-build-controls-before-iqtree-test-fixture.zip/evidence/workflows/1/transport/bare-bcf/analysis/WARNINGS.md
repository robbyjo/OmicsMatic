# SKIP3 runtime unavailable
org.jlinalg.cli.ShapeitRuntime$Unavailable: Indexed BGZF BCF is required by this fitting transport; bare BCF and VCF need separately verified staging and are not silently converted
Required action: preserve original inputs, failed state and logs. Supply the permitted exact runtime or correct the named input/capacity/integrity cause, then rerun to a fresh output directory. Never admit a partial output.
