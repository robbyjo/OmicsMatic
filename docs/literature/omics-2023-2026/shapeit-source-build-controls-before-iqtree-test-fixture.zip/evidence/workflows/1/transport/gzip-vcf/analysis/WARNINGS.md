# SKIP3 runtime unavailable
org.jlinalg.cli.ShapeitRuntime$Unavailable: VCF staging and non-BCF2.2 transport require a separately validated workflow; the dependent analysis is skipped without conversion
Required action: preserve original inputs, failed state and logs. Supply the permitted exact runtime or correct the named input/capacity/integrity cause, then rerun to a fresh output directory. Never admit a partial output.
