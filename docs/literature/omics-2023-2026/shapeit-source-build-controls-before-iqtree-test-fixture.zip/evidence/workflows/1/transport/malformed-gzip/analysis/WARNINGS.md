# FAIL2 no scientific result is admitted
java.io.IOException: Compressed input header is truncated or invalid; supply a complete BGZF BCF2.2 file and matching CSI, then rerun to a fresh directory
Required action: preserve original inputs, failed state and logs. Supply the permitted exact runtime or correct the named input/capacity/integrity cause, then rerun to a fresh output directory. Never admit a partial output.
