# FAIL2 no scientific result is admitted
java.io.IOException: SHAPEIT common-data preparation failed; no fitting result is admitted: REFERENCE_LITERAL_MISSING: original common reader rejects literal-zero missing reference GT; supply complete phased reference genotypes
Required action: preserve original inputs, failed state and logs. Supply the permitted exact runtime or correct the named input/capacity/integrity cause, then rerun to a fresh output directory. Never admit a partial output.
