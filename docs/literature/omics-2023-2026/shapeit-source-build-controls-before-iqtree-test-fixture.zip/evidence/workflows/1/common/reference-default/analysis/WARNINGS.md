# SHAPEIT analysis warnings

SOURCE AN INCLUDES REFERENCE HAPLOTYPES: 125 rows report combined target-plus-reference AN while AC counts target haplotypes only. Required action: use the verified target_AC/target_AN columns in target-allele-counts.tsv for target frequencies, or create and verify a separately retagged copy. Preserve the untouched original BCF; do not use its source AC/AN ratio as target frequency.

UPSTREAM PARTIAL-MISSING POLICY: 1 supplied observed alleles occur in calls the original reader treats as wholly missing. Required action: review those original calls and the source imputation policy; dosage preservation is guaranteed only for reader-defined observed calls.

SCIENTIFIC REVIEW REQUIRED: complete selected-variant/sample, raw output EOF, source-defined dosage, AC/AN and applied-scaffold checks passed. Runtime/process admission, pedigree/haploid adjustments, rare/ligation/posterior contracts and biological phase accuracy require their own verification.

UNIFORM GENETIC MAP: original 1 cM/Mb default was used. Genome-build and study suitability require investigator review.

SCOPE: original c34d ordinary diploid-GT common stage only, before optional pedigree/haploid processing. Binary genotypes, phase-set/pedigree/haploid options, rare phasing, ligation and historical singleton-posterior workflows are not admitted. Genotype preservation is not phase-accuracy or convergence validation.

Required action: preserve original output and use the verified target-count table for target-specific allele frequencies. Review all warnings before interpretation. Correct a failed analysis and rerun to a fresh output directory.
