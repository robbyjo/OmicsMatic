# FAIL2 no scientific result is admitted
java.io.IOException: Common input has unadmitted missingness/ploidy encoding: [TARGET_PHASE_MARKED_MISSING_READ_AS_REFERENCE, OBSERVED_ALLELES_IGNORED_IN_TARGET_MISSING_CALL]
Required action: preserve original inputs, failed state and logs. Supply the permitted exact runtime or correct the named input/capacity/integrity cause, then rerun to a fresh output directory. Never admit a partial output.
