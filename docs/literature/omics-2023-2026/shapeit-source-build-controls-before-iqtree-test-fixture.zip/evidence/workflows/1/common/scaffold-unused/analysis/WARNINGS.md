# FAIL2 no scientific result is admitted
java.io.IOException: Configured scaffold applies zero constraints; correct sample/site/phase compatibility before scaffold-assisted fitting
Required action: preserve original inputs, failed state and logs. Supply the permitted exact runtime or correct the named input/capacity/integrity cause, then rerun to a fresh output directory. Never admit a partial output.
