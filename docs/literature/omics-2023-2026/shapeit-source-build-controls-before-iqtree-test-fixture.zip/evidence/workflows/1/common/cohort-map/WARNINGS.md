# SHAPEIT WARNINGS REQUIRE REVIEW

UPSTREAM PARTIAL-MISSING POLICY: 1 supplied observed alleles occur in calls the original reader treats as wholly missing. Required action: review those original calls and the source imputation policy; dosage preservation is guaranteed only for reader-defined observed calls.

SCIENTIFIC REVIEW REQUIRED: complete selected-variant/sample, raw output EOF, source-defined dosage, AC/AN and applied-scaffold checks passed. Runtime/process admission, pedigree/haploid adjustments, rare/ligation/posterior contracts and biological phase accuracy require their own verification.

SCOPE: original c34d ordinary diploid-GT common stage only, before optional pedigree/haploid processing. Binary genotypes, phase-set/pedigree/haploid options, rare phasing, ligation and historical singleton-posterior workflows are not admitted. Genotype preservation is not phase-accuracy or convergence validation.

Required action: inspect WARNINGS.md, session.json and the retained preparation/process/output-audit records. A public result requires COMPLETED.json with the matching manifest hash. Missing or forbidden runtime/capability requires SKIP3; invalid input, integrity, execution or capacity requires FAIL2. Preserve failed/provisional output, correct the stated cause and rerun to a NEW directory. Analysis never installs or substitutes source profiles. Export setup with shapeit-tools --export-runtime-setup NEW_DIRECTORY; the current adopter needs existing permitted exact build members and does not download or compile. Use Linux x86_64 Python3.11+ and Linux Java (WSL on Windows).
