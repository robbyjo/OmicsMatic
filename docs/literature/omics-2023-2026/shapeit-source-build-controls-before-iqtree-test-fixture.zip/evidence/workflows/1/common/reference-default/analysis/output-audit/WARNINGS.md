SOURCE AN INCLUDES REFERENCE HAPLOTYPES: 125 rows report combined target-plus-reference AN while AC counts target haplotypes only. Required action: use the verified target_AC/target_AN columns in target-allele-counts.tsv for target frequencies, or create and verify a separately retagged copy. Preserve the untouched original BCF; do not use its source AC/AN ratio as target frequency.

UPSTREAM PARTIAL-MISSING POLICY: 1 supplied observed alleles occur in calls the original reader treats as wholly missing. Required action: review those original calls and the source imputation policy; dosage preservation is guaranteed only for reader-defined observed calls.

SCIENTIFIC REVIEW REQUIRED: complete selected-variant/sample, raw output EOF, source-defined dosage, AC/AN and applied-scaffold checks passed. Runtime/process admission, pedigree/haploid adjustments, rare/ligation/posterior contracts and biological phase accuracy require their own verification.
