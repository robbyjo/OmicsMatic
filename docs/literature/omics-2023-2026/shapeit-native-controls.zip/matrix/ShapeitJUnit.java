import java.io.PrintWriter;
import java.nio.file.Path;
import org.junit.platform.engine.discovery.DiscoverySelectors;
import org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder;
import org.junit.platform.launcher.core.LauncherFactory;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;
public final class ShapeitJUnit {
 public static void main(String[] args) throws Exception {
  var actual=Path.of(org.jlinalg.genetics.ShapeitGenotypes.class.getProtectionDomain().getCodeSource().getLocation().toURI()).toRealPath();
  if(!actual.equals(Path.of(args[0]).toRealPath()))throw new IllegalStateException("Native class did not load from the exact tested JAR");
  var listener=new SummaryGeneratingListener();
  var request=LauncherDiscoveryRequestBuilder.request().selectors(DiscoverySelectors.selectClass("org.jlinalg.genetics.ShapeitGenotypesTest")).build();
  var launcher=LauncherFactory.create();launcher.registerTestExecutionListeners(listener);launcher.execute(request);
  var summary=listener.getSummary();summary.printTo(new PrintWriter(System.out,true));summary.printFailuresTo(new PrintWriter(System.out,true));
  if(summary.getTestsFoundCount()!=15||summary.getTestsSucceededCount()!=15||summary.getTestsSkippedCount()!=0||summary.getTotalFailureCount()!=0)System.exit(1);
 }
}
