from pathlib import Path
import datetime, hashlib, json, os, subprocess, time

work = Path('/opt/omicsmatic-shapeit-dev-1')
base = Path('/mnt/d/projects/JLinAlg/build/literature-review/shapeit-runtime')
upstream = base / 'upstream'
report = base / 'original-build-attempt-1'
report.mkdir(exist_ok=False)
prefix = work / '.pixi/envs/default'
environment = dict(os.environ, PATH=str(prefix / 'bin') + ':/usr/bin:/bin', LD_LIBRARY_PATH=str(prefix / 'lib'), CONDA_PREFIX=str(prefix))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
records = []

def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

for profile, manifest_name, destination, standard, goals in [
    ('4.1.3', '4.1.3-selected-source.json', 'source4-attempt-1', 'c++11', []),
    ('5-c34d', '5-c34d-selected-source.json', 'source5-attempt-1', 'c++20', ['phase_common', 'phase_rare', 'ligate', 'switch', 'simulate']),
]:
    manifest = json.loads((upstream / manifest_name).read_bytes())
    source = work / destination
    source.mkdir(exist_ok=False)
    links = []
    for item in manifest['files']:
        raw = (upstream / manifest['source'] / item['path']).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == item['sha256'], item['path']
        assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == item['git_blob_sha1']
        target = source / item['path']
        target.parent.mkdir(parents=True, exist_ok=True)
        if item['mode'] == '120000':
            links.append((target, raw.decode('utf-8')))
        else:
            target.write_bytes(raw)
            target.chmod(0o755 if item['mode'] == '100755' else 0o644)
    for target, link in links:
        assert not Path(link).is_absolute()
        target.symlink_to(link)
    for target, _ in links:
        target.resolve(strict=True).relative_to(source)
    (source / 'bin').mkdir(exist_ok=True)
    (source / 'obj').mkdir(exist_ok=True)
    command = [str(prefix / 'bin/make'), '-j2', 'CXX=' + str(prefix / 'bin/x86_64-conda-linux-gnu-g++') + ' -std=' + standard,
               'HTSLIB_INC=' + str(prefix / 'include'), 'HTSLIB_LIB=' + str(prefix / 'lib/libhts.so'),
               'BOOST_INC=' + str(prefix / 'include'), 'BOOST_LIB_IO=' + str(prefix / 'lib/libboost_iostreams.so'),
               'BOOST_LIB_PO=' + str(prefix / 'lib/libboost_program_options.so'), 'BOOST_LIB_SE=' + str(prefix / 'lib/libboost_serialization.so'),
               'LDFLAG=-O3 -L' + str(prefix / 'lib') + ' -Wl,-rpath,' + str(prefix / 'lib'),
               'COMMIT_VERS=' + ('ca896a2' if profile == '4.1.3' else 'c34d4db'),
               'COMMIT_DATE=' + ('2020-02-28' if profile == '4.1.3' else '2026-05-19'), *goals]
    start = time.monotonic()
    with (report / (profile + '.stdout')).open('wb') as stdout, (report / (profile + '.stderr')).open('wb') as stderr:
        child = subprocess.Popen(command, cwd=source, env=environment, stdout=stdout, stderr=stderr)
        write(report / 'running.json', {'controller_linux_pid': os.getpid(), 'child_linux_pid': child.pid, 'profile': profile, 'command': command})
        code = child.wait()
    changed = []
    for item in manifest['files']:
        path = source / item['path']
        actual = hashlib.sha256(path.readlink().as_posix().encode()).hexdigest() if item['mode'] == '120000' else sha(path)
        if actual != item['sha256']: changed.append(item['path'])
    assert not changed, changed
    binaries = [source / 'bin/shapeit4'] if profile == '4.1.3' else [source / name / 'bin' / name for name in goals]
    record = {'profile': profile, 'exit_code': code, 'elapsed_seconds': time.monotonic() - start, 'source': str(source), 'command': command, 'selected_source_files': len(manifest['files']), 'source_bytes_unchanged': True,
              'libraries': 'Declared private shared HTSlib1.18 and Boost1.85; no static-build or historical binary identity claim.',
              'binaries': [{'path': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size} for path in binaries if path.is_file()]}
    records.append(record)
    write(report / 'observed.json', {'status': 'original-source-builds-running' if code == 0 else 'source-build-failed', 'profiles': records})
    print(profile, 'BUILD EXIT', code, 'seconds', round(record['elapsed_seconds'], 2), flush=True)
    if code:
        print((report / (profile + '.stderr')).read_text(errors='replace')[-4000:], flush=True)
        raise SystemExit(code)
write(report / 'observed.json', {'status': 'completed-two-unchanged-original-source-builds', 'profiles': records, 'scientific_analysis_completed': False, 'public_adapter_available': False})
print('BOTH ORIGINAL SOURCE BUILDS COMPLETED; scientific controls and public adapter remain required.', flush=True)
