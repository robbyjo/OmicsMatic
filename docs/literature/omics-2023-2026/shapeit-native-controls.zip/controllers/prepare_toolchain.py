from pathlib import Path
import datetime, hashlib, json, os, shutil, subprocess

root = Path('/opt/omicsmatic-shapeit-dev-1')
report = Path('/mnt/d/projects/JLinAlg/build/literature-review/shapeit-runtime/toolchain-attempt-1')
report.mkdir(exist_ok=False)
assert not root.exists(), 'Preserve existing private installations; select a NEW destination.'
root.mkdir()
manifest = '''[workspace]
name = "omicsmatic-shapeit-development"
version = "0.1.0"
channels = ["conda-forge", "bioconda"]
platforms = ["linux-64"]

[dependencies]
gxx_linux-64 = "14.*"
make = "4.4.*"
libboost-devel = "1.85.*"
libboost-headers = "1.85.*"
htslib = "1.18.*"
bcftools = "1.18.*"
pkg-config = "0.29.*"
'''
(root / 'pixi.toml').write_text(manifest)
command = ['/opt/jlinalg-saige-dev-1/bin/pixi', 'install', '--manifest-path', str(root / 'pixi.toml')]
with (report / 'install.log').open('wb') as log:
    child = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, env=dict(os.environ, NO_COLOR='1'), cwd=root)
    (report / 'running.json').write_text(json.dumps({'controller_linux_pid': os.getpid(), 'child_linux_pid': child.pid, 'command': command, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}, indent=2) + '\n')
    code = child.wait()
record = {'status': 'installed-private-build-dependencies' if code == 0 else 'SKIPPED-build-dependencies-unavailable', 'exit_code': code, 'root': str(root), 'global_installation_modified': False, 'required_action': 'Inspect install.log. Preserve the failed destination; supply permitted compiler, Boost and HTSlib dependencies at a NEW private destination before retrying source compilation. Skip dependent original analyses while unavailable.'}
if code == 0:
    for name in ['pixi.toml', 'pixi.lock']:
        raw = (root / name).read_bytes()
        (report / name).write_bytes(raw)
        record[name + '_sha256'] = hashlib.sha256(raw).hexdigest()
    prefix = root / '.pixi/envs/default'
    record['libraries'] = sorted(str(p.relative_to(prefix)) for p in (prefix / 'lib').glob('libboost*'))
    record['htslib'] = sorted(str(p.relative_to(prefix)) for p in (prefix / 'lib').glob('libhts*'))
(report / 'observed.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2), flush=True)
raise SystemExit(code)
