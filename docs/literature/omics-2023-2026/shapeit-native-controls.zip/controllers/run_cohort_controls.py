from pathlib import Path
import datetime, gzip, hashlib, json, os, subprocess

work = Path('/opt/omicsmatic-shapeit-dev-1')
base = Path('/mnt/d/projects/JLinAlg/build/literature-review/shapeit-runtime')
prefix = work / '.pixi/envs/default'
private = work / 'cohort-controls-attempt-1'
private.mkdir(exist_ok=False)
report = base / 'cohort-controls-attempt-1'
report.mkdir(exist_ok=False)
environment = dict(os.environ, PATH=str(prefix / 'bin') + ':/usr/bin:/bin', LD_LIBRARY_PATH=str(prefix / 'lib'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
map_file = private / 'chr20.gmap'
map_file.write_text('pos rate cM\n1 1 0\n1000000 1 1\n')
runs, cases = [], []

def write(name, value):
    (report / name).write_text(json.dumps(value, indent=2) + '\n')

def run(name, command, cwd):
    with (report / (name + '.stdout')).open('wb') as stdout, (report / (name + '.stderr')).open('wb') as stderr:
        child = subprocess.Popen([str(x) for x in command], cwd=cwd, env=environment, stdout=stdout, stderr=stderr)
        write('running.json', {'controller_linux_pid': os.getpid(), 'child_linux_pid': child.pid, 'phase': name})
        code = child.wait()
    runs.append({'name': name, 'command': [str(x) for x in command], 'exit_code': code})
    write('runs.json', runs)
    print(name, 'EXIT', code, flush=True)
    if code:
        print((report / (name + '.stdout')).read_text(errors='replace')[-2500:], flush=True)
        print((report / (name + '.stderr')).read_text(errors='replace')[-2500:], flush=True)
        raise SystemExit(code)

for profile, program in [('4.1.3', work / 'source4-attempt-1/bin/shapeit4'), ('5-c34d', work / 'source5-attempt-1/phase_common/bin/phase_common')]:
    for fmt, filename in [('bcf', 'wire.bcf'), ('vcf', 'wire.vcf.gz')]:
        case = profile + '-' + fmt
        directory = private / case
        directory.mkdir()
        source = work / 'reader-protocol-attempt-1' / filename
        before = sha(source)
        output = directory / 'phased.bcf'
        command = [program, '--input', source, '--region', '20', '--map', map_file, '--output', output, '--seed', '42', '--thread', '1', '--pbwt-mdr', '1', '--pbwt-modulo', '0.001', '--log', directory / 'original.log']
        run(case, command, directory)
        assert sha(source) == before
        decoded = report / (case + '.phased.vcf')
        run(case + '-decode', [prefix / 'bin/bcftools', 'view', '-Ov', '-o', decoded, output], directory)
        lines = decoded.read_text().splitlines()
        header = next(line for line in lines if line.startswith('#CHROM')).split('\t')
        rows = [line.split('\t') for line in lines if not line.startswith('#')]
        assert len(header[9:]) == 50 and len(rows) == 4
        assert all(len(row) == 59 for row in rows)
        for row in rows:
            formats = row[8].split(':'); gt = formats.index('GT')
            assert all(sample.split(':')[gt] in ['0|0', '0|1', '1|0', '1|1'] for sample in row[9:])
        (report / (case + '.original.log')).write_bytes((directory / 'original.log').read_bytes())
        (report / (case + '.phased.bcf')).write_bytes(output.read_bytes())
        cases.append({'profile': profile, 'format': fmt, 'samples': 50, 'variants': 4, 'cells': 200, 'source_sha256': before,
                      'output_sha256': sha(output), 'decoded_sha256': sha(decoded), 'program_sha256': sha(program), 'command': [str(x) for x in command]})
write('observed.json', {'status': 'completed-four-fresh-original-cohort-phasing-controls', 'cases': cases, 'cells': 800, 'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'scope': 'Synthetic diploid-storage reader-boundary controls, including wire missing and vector-end representations. PBWT missing-rate and storage-modulo settings are explicitly declared for these stress inputs; the default MCMC schedule is retained. These controls do not establish phase accuracy, study suitability, reference/scaffold/haploid/rare/ligation workflows or a public adapter.'})
print('ALL FOUR ORIGINAL COHORT PHASING CONTROLS COMPLETED', flush=True)
