from pathlib import Path
import csv, hashlib, json, os, subprocess, time

base = Path('/mnt/d/projects/JLinAlg/build/literature-review/shapeit-runtime')
repository = base.parents[2]
work = Path('/opt/omicsmatic-shapeit-dev-1')
prefix = work / '.pixi/envs/default'
report = base / 'reader-protocol-attempt-1'
report.mkdir(exist_ok=False)
private = work / 'reader-protocol-attempt-1'
private.mkdir(exist_ok=False)
environment = dict(os.environ, PATH=str(prefix / 'bin') + ':/usr/bin:/bin', LD_LIBRARY_PATH=str(prefix / 'lib'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
runs = []

def write(name, value):
    (report / name).write_text(json.dumps(value, indent=2) + '\n')

def run(name, command, cwd=private, allowed=(0,)):
    start = time.monotonic()
    with (report / (name + '.stdout')).open('wb') as stdout, (report / (name + '.stderr')).open('wb') as stderr:
        child = subprocess.Popen([str(x) for x in command], cwd=cwd, env=environment, stdout=stdout, stderr=stderr)
        write('running.json', {'controller_linux_pid': os.getpid(), 'child_linux_pid': child.pid, 'phase': name})
        code = child.wait()
    runs.append({'name': name, 'command': [str(x) for x in command], 'exit_code': code, 'seconds': time.monotonic() - start})
    write('runs.json', runs)
    print(name, 'EXIT', code, flush=True)
    if code not in allowed:
        print((report / (name + '.stderr')).read_text(errors='replace')[-4000:], flush=True)
        raise SystemExit(code or 1)

# Reconcile only the explicitly declared pre-existing build output. Do not recompile.
manifest = json.loads((base / 'upstream/5-c34d-selected-source.json').read_bytes())
source5 = work / 'source5-attempt-1'
changed = []
for item in manifest['files']:
    path = source5 / item['path']
    actual = hashlib.sha256(path.readlink().as_posix().encode()).hexdigest() if item['mode'] == '120000' else sha(path)
    if actual != item['sha256']: changed.append({'path': item['path'], 'before': item['sha256'], 'after': actual})
assert [item['path'] for item in changed] == ['ligate/bin/ligate'], changed
configuration = json.loads((base / 'original-build-attempt-1/running.json').read_bytes())['command'][2:-5]
assert configuration[0].startswith('CXX=')
programs = ['phase_common', 'phase_rare', 'ligate', 'switch', 'simulate']
for name in programs:
    run('make-query-' + name, [prefix / 'bin/make', '-q', 'bin/' + name, *configuration], cwd=source5 / name)
    run('help-' + name, [source5 / name / 'bin' / name, '--help'])
write('build-reconciliation.json', {'status': 'passed-current-target-and-help-revalidation', 'original_controller': 'original-build-attempt-1', 'original_make_exit_code_not_retained': True,
      'original_controller_failure': 'Guard compared an explicitly rebuilt tracked executable with its original prebuilt bytes.', 'allowed_changed_original_member': changed,
      'all_original_algorithm_and_makefile_bytes_unchanged': True, 'make_queries_up_to_date': 5, 'working_help_probes': 5,
      'binaries': [{'program': name, 'path': str(source5 / name / 'bin' / name), 'sha256': sha(source5 / name / 'bin' / name)} for name in programs], 'scientific_analysis_completed_by_help': False})

compiler = prefix / 'bin/x86_64-conda-linux-gnu-g++'
common = ['-O2', '-I' + str(prefix / 'include'), '-L' + str(prefix / 'lib'), '-Wl,-rpath,' + str(prefix / 'lib')]
fixture_source = repository / 'tools/literature/shapeit-reference/MakeWireFixture.cpp'
reader_source = repository / 'tools/literature/shapeit-reference/ReaderProtocol.cpp'
run('compile-fixture', [compiler, '-std=c++17', *common, fixture_source, '-lhts', '-o', private / 'make-fixture'])
run('make-fixture', [private / 'make-fixture', private / 'wire.bcf'])
run('index-bcf', [prefix / 'bin/bcftools', 'index', private / 'wire.bcf'])
run('convert-vcf', [prefix / 'bin/bcftools', 'view', '-Oz', '-o', private / 'wire.vcf.gz', private / 'wire.bcf'])
run('index-vcf', [prefix / 'bin/bcftools', 'index', private / 'wire.vcf.gz'])
observed = []
for profile, source, standard, defines in [('4.1.3', work / 'source4-attempt-1', 'c++11', ['-DSHAPEIT_FOUR']), ('5-c34d', source5 / 'phase_common', 'c++20', [])]:
    objects = sorted(p for p in (source / 'obj').glob('*.o') if p.name != 'main.o')
    assert len(objects) > 10
    program = private / ('reader-' + profile)
    run('compile-reader-' + profile, [compiler, '-std=' + standard, *common, '-I' + str(source / 'src'), *defines, reader_source, *objects,
                                      '-lhts', '-lboost_iostreams', '-lboost_program_options', '-lz', '-lbz2', '-lm', '-lpthread', '-llzma', '-lcurl', '-lcrypto', '-ldeflate', '-o', program])
    for fmt, filename in [('bcf', 'wire.bcf'), ('vcf', 'wire.vcf.gz')]:
        result = report / ('reader-' + profile + '-' + fmt + '.tsv')
        run('reader-' + profile + '-' + fmt, [program, private / filename, result])
        with result.open() as stream: rows = list(csv.DictReader(stream, delimiter='\t'))
        assert len(rows) == 200 and len({(row['variant'], row['sample']) for row in rows}) == 200
        observed.append({'profile': profile, 'format': fmt, 'rows': 4, 'samples': 50, 'cells': len(rows), 'result': result.name, 'sha256': sha(result), 'program_sha256': sha(program)})
for name in ['wire.bcf', 'wire.bcf.csi', 'wire.vcf.gz', 'wire.vcf.gz.csi']:
    (report / name).write_bytes((private / name).read_bytes())
write('observed.json', {'status': 'passed-800-initial-target-reader-cells-from-two-original-source-profiles', 'cases': observed, 'cells': 800,
      'reader_protocol_sha256': sha(reader_source), 'fixture_generator_sha256': sha(fixture_source), 'build_reconciliation': 'build-reconciliation.json',
      'whole_phasing_adapter_available': False, 'scientific_inference_validated_by_reader_protocol': False})
print('ALL 800 ORIGINAL READER CELLS RETAINED', flush=True)
