import gzip,hashlib,json,sys,zipfile
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path('D:/projects/JLinAlg');sys.path.insert(0,str(ROOT/'tools/literature'))
from mashr_original_runtime import pin
from mashr_catalog_evidence import verify as scientific_verify
from catalog_source_integrity import reverse_delta
DATA=ROOT/'docs/literature/omics-2023-2026';RUN=ROOT/'build/literature-review/mashr-runtime/proxy-command-development-1';HERE=RUN/'catalog-integration-1'
assert __debug__
science=scientific_verify(emit=False)
ui=json.loads((HERE/'ui-3/ui-validation.json').read_text(encoding='utf-8'));generic=json.loads((HERE/'generic-ui-4/ui-validation.json').read_text(encoding='utf-8'));assert ui['status']==generic['status']=='passed'
roles=json.loads((DATA/'mashr-role-coverage.json').read_text(encoding='utf-8'));assert roles['applied'] and roles['reviewed_roles']==8 and roles['unrelated_prior_reviews_preserved']==767 and roles['total_reviews']==775
papers=json.loads((DATA/'papers.json').read_text(encoding='utf-8'));before=json.loads(gzip.decompress((RUN/'role-curation-apply-1/before-papers.json.gz').read_bytes()));assert len(papers)==len(before)==250 and sum(len(p['tools']) for p in papers)==2430
for a,b in zip(before,papers):
    assert {k:v for k,v in a.items() if k!='tools'}=={k:v for k,v in b.items() if k!='tools'}
    assert [t for t in a['tools'] if t['tool_id']!='mashr']==[t for t in b['tools'] if t['tool_id']!='mashr']
old_reviews=json.loads(gzip.decompress((RUN/'role-curation-apply-1/before-reviewed-uses.json.gz').read_bytes()));reviews=json.loads((ROOT/'tools/literature/reviewed-uses.json').read_text(encoding='utf-8'));assert reviews['reviews'][:767]==old_reviews['reviews'] and len(reviews['reviews'])==775 and sum(len(r.get('supporting_evidence',[])) for r in reviews['reviews'])==230
summary=json.loads((DATA/'summary.json').read_text(encoding='utf-8'));assert summary['papers']==250 and summary['paper_tool_observations']==2430 and summary['distinct_named_tools']==380
for k,v in [('native-subset-validated',14),('upstream-adapter-validated',48),('missing',258)]:assert summary['implementation_status_counts'][k]==v
inventory=json.loads((DATA/'tool-inventory.json').read_text(encoding='utf-8'));mash=next(t for t in inventory if t['id']=='mashr');assert mash['implementation_status']=='native-subset-validated' and mash['source_roles_reviewed']==8 and mash['project_adapter_available'] and not mash['canonical_adapter_available'] and '477' in mash['validation_note'] and 'mashr-tools' in mash['implementation_scope']
source_names=['tools/literature/mashr_catalog.py','tools/literature/mashr_catalog_evidence.py','tools/literature/curate_mashr_uses.py','tools/literature/mashr-use-reviews.json','tools/literature/check_mashr_review_ui.cjs','tools/literature/render_review.py','tools/literature/check_review_ui.cjs','tools/literature/reviewed-uses.json']
sources={n:pin(ROOT/n) for n in source_names}
artifacts=['papers.json','tool-inventory.json','summary.json','catalog.md','WARNINGS.md','implementation-plan.md','catalog-enrichment.json','mashr-role-coverage.json','mashr-use-shared-source-compatibility.json','mashr-catalog-shared-source-compatibility.json','mashr-catalog-correction-shared-source-compatibility.json','mashr-native-filter-shared-source-compatibility.json']
artifact_pins={str((DATA/n).relative_to(ROOT).as_posix()):pin(DATA/n) for n in artifacts}
for name in ['site/literature-review.html','site/literature-warnings.html']:artifact_pins[name]=pin(ROOT/name)
items={}
def add(path,name):assert name not in items;items[name]=(path,pin(path))
for path in sorted((HERE/'ui-3').iterdir()):
    if path.is_file():add(path,'ui/mashr/'+path.name)
add(HERE/'generic-ui-4/ui-validation.json','ui/generic/ui-validation.json')
for name in ['render-1.log','render-2.log','render-3.log','ui-1.log','ui-2.log','ui-3.log','generic-ui-1.log','generic-ui-2.log','generic-ui-3.log','generic-ui-4.log','before-render_review.py','before-check_review_ui.cjs','renderer-at-ui-2-failure.py','generic-ui-at-ui-2-failure.cjs','generic-ui-at-ui-3-failure.cjs']:add(HERE/name,'history/'+name)
for folder in ['ui-2','generic-ui-2','generic-ui-3']:
    for p in (HERE/folder).glob('*FAILURE*.json'):add(p,'history/'+folder+'/'+p.name)
for name in ['before-papers.json.gz','before-reviewed-uses.json.gz','before-catalog-enrichment.json.gz','verification.json']:add(RUN/'role-curation-apply-1'/name,'roles/'+name)
add(RUN/'role-curation-dry-run-2/verification.json','roles/dry-run-verification.json')
for name in ['role-curation-dry-run-1.log','role-curation-dry-run-2.log','role-curation-apply-1.log','curator-at-import-failure-1.py']:add(RUN/name,'roles/history/'+name)
for n in sources:add(ROOT/n,'source/'+n)
for n in artifact_pins:add(ROOT/n,'snapshot/'+n)
add(Path(__file__),'source/record-checkpoint.py')
target=DATA/'mashr-catalog-support.zip';proof_path=DATA/'mashr-catalog-validation.json';assert not target.exists() and not proof_path.exists()
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,(p,value) in sorted(items.items()):
        raw=p.read_bytes();assert pin(p)==value,name
        e=zipfile.ZipInfo(name,(1980,1,1,0,0,0));e.compress_type=zipfile.ZIP_DEFLATED;e.external_attr=0o100644<<16;archive.writestr(e,raw)
assert all(pin(ROOT/n)==v for n,v in sources.items()) and all(pin(ROOT/n)==v for n,v in artifact_pins.items())
dependencies={}
for name in ['docs/literature/mashr-proxy-command/VALIDATION.json','docs/literature/mashr-proxy-command/controls.zip','docs/literature/mashr-composite/role-audit.json']:dependencies[name]=pin(ROOT/name)
proof=dict(schema_version=1,status='passed-scoped-native-mashr-catalog-integration',recorded_utc=datetime.now(timezone.utc).isoformat(),scope='Eight source-reviewed mashr uses and validated native fit/prediction/sharing/composite subset, with optional managed original-source covariance preparation. Prominent SKIP3/FAIL2 recovery; current-source candidate only.',papers=250,named_tools=380,observations=2430,reviewed_uses=775,supporting_pointers=230,new_scoped_integrations=62,new_native_scopes=14,new_upstream_adapters=48,including_preexisting_adapters=65,missing=258,source_roles=8,unrelated_prior_reviews_preserved=767,unrelated_tool_observations_preserved=2422,scientific_validation=science,source_pins=sources,catalog_artifact_snapshot=artifact_pins,dependencies=dependencies,candidate=dict(path=mash['development_candidate'],sha256=mash['development_candidate_sha256']),archive=dict(path=target.name,**pin(target),entries=len(items)),archive_files={n:v for n,(_,v) in sorted(items.items())},browser=dict(executable='C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',focused_checks=ui['checks'],generic_checks=len(generic['checks']),screenshots_visually_reviewed=['mashr-card-desktop.png','mashr-warnings-actions-mobile-dark.png']),claims=dict(catalog_promoted_as_native_subset=True,canonical_adapter_available=False,whole_paper_reproduced=False,full_dreamlet_package_validated=False,whole_goal_complete=False,released_or_deployed=False),required_action='Use MASHR_PROXY_COMMAND.md and the identified candidate. Require exit0, COMPLETED.json and --verify; inspect complete warnings and numeric/selector diagnostics. Native Java needs no R; optional exact original preparation requires permitted managed Windows R. Unsupported/unavailable methods SKIP3; invalid, integrity, convergence, resource and cancellation failures FAIL2 without admission. The inherited catalog summary in the scientific checkpoint is explicitly archived historical context, not a scientific input. Every scientific binding remains exact. This catalog snapshot is historical when unrelated later tools are added.')
proof_path.write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
# Verify the retained archive once without rerunning completed analyses/UI.
with zipfile.ZipFile(target) as archive:
    assert len(archive.infolist())==len(items)==len({e.filename for e in archive.infolist()})
    for n,v in proof['archive_files'].items():
        raw=archive.read(n);assert len(raw)==v['bytes'] and hashlib.sha256(raw).hexdigest()==v['sha256'],n
print(json.dumps(dict(status=proof['status'],new_scoped_integrations=62,new_native_scopes=14,new_upstream_adapters=48,missing=258,reviewed_uses=775,supporting_pointers=230,archive=proof['archive'])))
