# Iqtree process FAIL2 failed

java.io.IOException: Iqtree wall-time capacity exceeded

Required action: preserve this directory, stdout, stderr and process ledger. Admit results only after the complete scientific output audit. Correct any failure and rerun to a new output directory.
