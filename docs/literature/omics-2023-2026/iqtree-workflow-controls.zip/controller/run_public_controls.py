from pathlib import Path
import json,subprocess,hashlib,shutil,os
ROOT=Path('/mnt/d/projects/JLinAlg');BASE=ROOT/'build/literature-review/iqtree-runtime';OUT=BASE/'push-public-controls-1';OUT.mkdir(exist_ok=False)
WORK=Path('/opt/omicsmatic-iqtree-setup-dev-1/push-public-controls-1');WORK.mkdir(exist_ok=False)
JAR=ROOT/'build/cli/omicsmatic-0.3.7.jar'
datasets=json.loads((BASE/'inference-original-controls-1/synthetic-data.json').read_bytes())['sequences']
names=['sample one α',"sample's two, β"]+['sample '+str(i+1) for i in range(2,12)]
data={kind:dict(zip(names,seqs.values())) for kind,seqs in datasets.items()}
def base(kind='DNA'):
    return dict(schema_version=1,profile='linux-x86_64-iqtree-2.3.6',operation='INFER',alignment=dict(path='alignment.fasta',format='FASTA',kind=dict(DNA='DNA',AA='AMINO_ACID',CODON='CODON_STANDARD')[kind],header_policy='WHOLE_HEADER'),
        model=dict(selection='FIXED',name=dict(DNA='JC',AA='LG+F+R10',CODON='MG+F1X4')[kind]),
        support=dict(bootstrap='NONE',replicates=0,sh_alrt_replicates=0,bnni=False,write_branch_lengths=False),
        parameters=dict(seed=61129,threads=1,identical_sequences='KEEP',safe_mode=False,outgroup=[]),
        limits=dict(process=dict(wallMillis=180000,cpuSeconds=120,addressSpaceBytes=4294967296,sampledRssBytes=2147483648)))
cases=[('DNA-JC','DNA',0),('DNA-ModelFinder','DNA',0),('AA','AA',0),('CODON','CODON',0),('UFB-SHalrt','DNA',0),('standard-100','DNA',0),('fixed-JC','DNA',0),('sequential-PHYLIP','DNA',0),('missing-home','DNA',3),('invalid-state','DNA',2),('wall-capacity','DNA',2),('unsupported-partition','DNA',3)]
cases += [('edition-'+v,'DNA',0) for v in ['1.6.12','2.1.2','2.1.4-beta','2.2.0.3','2.3.1','2.3.5','2.4.0']]
cases += [('duplicates-'+v,'DNA',0) for v in ['1.6.12','2.4.0']]
records=[]
for name,kind,expected in cases:
    directory=WORK/name;directory.mkdir();recipe=base(kind);sequences=data[kind]
    (directory/'alignment.fasta').write_text(''.join('>'+k+'\n'+s+'\n' for k,s in sequences.items()))
    home=Path('/opt/omicsmatic-iqtree-setup-dev-1/formal-matrix-1/homes/2.3.6')
    if name.startswith(('edition-','duplicates-')):
        version=name.split('-',1)[1];recipe['profile']='linux-x86_64-iqtree-'+version
        home=Path('/opt/omicsmatic-iqtree-setup-dev-1/formal-matrix-1/homes')/version
    if name.startswith('duplicates-'):
        sequences=dict(sequences)
        for i,(taxon,seq) in enumerate(list(sequences.items())):
            sequences['copy one '+str(i)]=seq
        for i,(taxon,seq) in enumerate(list(data[kind].items())):
            sequences['copy two '+str(i)]=seq
        recipe['parameters']['identical_sequences']='SOURCE_REMOVE_RESTORE'
        (directory/'alignment.fasta').write_text(''.join('>'+k+'\n'+s+'\n' for k,s in sequences.items()))
    if name=='DNA-ModelFinder':recipe['model']=dict(selection='MODEL_FINDER',criterion='BIC')
    if name=='UFB-SHalrt':recipe['support']=dict(bootstrap='ULTRAFAST',replicates=1000,sh_alrt_replicates=1000,bnni=True,write_branch_lengths=True)
    if name=='standard-100':recipe['support']=dict(bootstrap='STANDARD',replicates=100,sh_alrt_replicates=0,bnni=False,write_branch_lengths=True)
    if name=='fixed-JC':
        sequences=dict(zip(names[:4],['ACGTACGTACGT','ACGTACGTTCGT','TCGTACGTTCGT','TCGTTCGTTCGT']))
        (directory/'alignment.fasta').write_text(''.join('>'+k+'\n'+s+'\n' for k,s in sequences.items()))
        tree="(('sample one α':.1,'sample''s two, β':.2):.3,'sample 3':.4,'sample 4':.5);\n"
        (directory/'tree.nwk').write_text(tree);recipe['operation']='EVALUATE';recipe['tree']=dict(path='tree.nwk',mode='FIX_TOPOLOGY_AND_LENGTHS')
    if name=='sequential-PHYLIP':
        sequences=dict(zip(['A','B','C','D'],['ACGTACGTACGT','ACGTACGTTCGT','TCGTACGTTCGT','TCGTTCGTTCGT']))
        (directory/'alignment.phy').write_text('4 12\n'+''.join(k+' '+s[:6]+'\n'+s[6:]+'\n' for k,s in sequences.items()))
        recipe['alignment']=dict(path='alignment.phy',format='PHYLIP',kind='DNA',layout='SEQUENTIAL',name_field='RELAXED',named_continuations=False)
    if name=='missing-home':home=directory/'absent'
    if name=='invalid-state':(directory/'alignment.fasta').write_text('>A\nACG*\n>B\nACGT\n>C\nACGT\n>D\nTCGT\n')
    if name=='wall-capacity':recipe['limits']['process']['wallMillis']=50
    if name=='unsupported-partition':recipe['partitions']=dict(path='not-implemented.nex')
    request=directory/'recipe.json';request.write_text(json.dumps(recipe,indent=2)+'\n');out=directory/'bundle'
    command=['/usr/bin/java','-Xmx128m','-jar',str(JAR),'iqtree-tools','--recipe',str(request),'--home',str(home),'--out',str(out)]
    with (directory/'cli.stdout').open('xb') as stdout,(directory/'cli.stderr').open('xb') as stderr:
        child=subprocess.Popen(command,cwd=directory,stdout=stdout,stderr=stderr)
        (OUT/'running.json').write_text(json.dumps(dict(status='running',controller_pid=os.getpid(),pid=child.pid,case=name,command=command),indent=2)+'\n');code=child.wait(timeout=240)
    completed=(out/'COMPLETED.json').exists();error=None
    if code!=expected or completed!=(expected==0):error='Unexpected exit/completion state'
    if code==0:
        verify=subprocess.run(['/usr/bin/java','-Xmx128m','-jar',str(JAR),'iqtree-tools','--verify',str(out)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=60)
        (directory/'verify.stdout').write_bytes(verify.stdout)
        if verify.returncode:error='Portable bundle verification failed'
    record=dict(name=name,kind=kind,expected_exit=expected,exit_code=code,completed=completed,error=error,command=command,
                original_sequences=sequences,files={p.relative_to(directory).as_posix():dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in directory.rglob('*') if p.is_file()})
    records.append(record);(OUT/'observed.json').write_text(json.dumps(records,indent=2)+'\n');print(name,'exit',code,'expected',expected,'completed',completed,'error',error,flush=True)
    if code!=expected:print((directory/'cli.stderr').read_text(errors='replace')[-1800:],flush=True)
shutil.copytree(WORK,OUT/'linux');(OUT/'running.json').write_text(json.dumps(dict(status='terminal',protocols=len(records),all_expected=all(p['error'] is None for p in records)),indent=2)+'\n')
if any(p['error'] for p in records):raise SystemExit(1)
