from pathlib import Path
import hashlib,importlib.util,json,subprocess,sys,zipfile
root=Path('D:/projects/JLinAlg');base=root/'build/literature-review/shapeit-runtime';matrix=base/'raw-link-native-matrix-2';data=base/'raw-link-proof-candidate-3';data.mkdir(exist_ok=False)
sys.path.insert(0,str(root/'tools/literature'));import shapeit_joined_validation as validation
sha=lambda raw:hashlib.sha256(raw).hexdigest();observed=json.loads((matrix/'observed.json').read_bytes())
assert observed['status']=='passed-native-raw-linkage-matrix' and observed['tests_per_JVM']==171
for path,digest in observed['source_sha256'].items():assert sha((root/path).read_bytes())==digest,path
versions={}
for profile,command,major in [
    ('windows-java21',['C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe','--version'],21),
    ('windows-java25',['C:/Program Files/Common Files/Oracle/Java/javapath/java.exe','--version'],25),
    ('linux-java21',['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/java','--version'],21)]:
    result=subprocess.run(command,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=subprocess.CREATE_NO_WINDOW)
    text=result.stdout.decode()+result.stderr.decode();assert result.returncode==0 and (' '+str(major)+'.' in text or ' '+str(major)+' ' in text),(profile,text)
    versions[profile]=dict(major=major,command=command,output=text,exit_code=0)
members={}
def add(name,raw):assert name not in members;members[name]=raw
source_pins={}
for path in sorted(validation.SCIENCE):raw=(root/path).read_bytes();source_pins[path]=sha(raw);add('source/'+path,raw)
for path in sorted(matrix.rglob('*')):
    if not path.is_file():continue
    relative=path.relative_to(matrix).as_posix()
    if relative.startswith(('javadoc/','main-classes/')) or relative=='running.json':continue
    add('matrix/'+relative,path.read_bytes())
add('matrix/runtime-versions.json',(json.dumps(versions,indent=2)+'\n').encode())
add('capture/freeze_raw_link_candidate_3.py',Path(__file__).read_bytes())
add('capture/run_raw_link_matrix_2.py',(base/'run_raw_link_matrix_2.py').read_bytes())
add('README.txt',b'Native raw BCF disk indexing and original-join record linkage only. Candidate JAR, all tested classes/dependencies, original controls, current byte-pinned sources, compiler/JVM commands and notices are retained. This is not an admitted public phasing workflow or proof of phase accuracy.\n')
add('SHA256SUMS',''.join(sha(raw)+'  '+name+'\n' for name,raw in sorted(members.items())).encode())
artifact=data/'shapeit-joined-native-controls.zip'
with artifact.open('xb') as stream:
    with zipfile.ZipFile(stream,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for name,raw in sorted(members.items()):
            info=zipfile.ZipInfo(name,(1980,1,1,0,0,0));info.external_attr=0o100644<<16;info.compress_type=zipfile.ZIP_DEFLATED;archive.writestr(info,raw)
record=dict(status='validated-native-SHAPEIT-original-join-raw-record-linkage',
            source_sha256=source_pins,artifact=dict(path=artifact.name,sha256=sha(artifact.read_bytes()),bytes=artifact.stat().st_size),
            original_fixture_sha256='fc63451afeb22f5c0c45d8a46af7634687ea85f6c25eb431d73e609cc6baad79',
            native_candidate_sha256=observed['candidate_sha256'],native_tests_per_JVM=171,JVM_profiles=3,heap='128m',
            original_complete_streams=27,original_expected_failures=2,original_joined_events=181,
            public_phasing_adapter_available=False,runtime_admission_certified=False,binary_genotype_payloads_validated=False,phase_accuracy_certified=False,
            dependency_source_notices=json.loads((matrix/'dependency-sources/provenance.json').read_bytes()),
            scope='Complete raw-record linkage to bound original captures and native selector events only. No upstream execution authentication, admitted phasing command, XCF genotype decoding, fitting/output audit or phase-accuracy claim.',
            required_action='Skip dependent phasing while admission/fitting contracts remain unfinished. On integrity, census, metadata or capacity failure, preserve original input and failed state; correct the stated cause and use fresh spool/link directories with sufficient complete-population limits, disk and Java heap.')
(data/'shapeit-joined-validation.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
validation.verify(root,data)
print(json.dumps(dict(artifact_sha256=record['artifact']['sha256'],artifact_bytes=artifact.stat().st_size,members=len(members),decoded_bytes=sum(map(len,members.values()))),indent=2))
