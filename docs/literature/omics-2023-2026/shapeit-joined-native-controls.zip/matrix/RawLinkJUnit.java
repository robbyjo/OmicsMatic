import org.junit.platform.launcher.core.*;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;
public class RawLinkJUnit {
 public static void main(String[] args) throws Exception {
  for(String name:new String[]{"org.jlinalg.cli.ShapeitBcf","org.jlinalg.cli.ShapeitRawIndex","org.jlinalg.cli.ShapeitJoinedRecords","org.jlinalg.genetics.ShapeitCommonVariants"})
   if(!Class.forName(name).getProtectionDomain().getCodeSource().getLocation().toURI().equals(new java.io.File(args[0]).toURI()))throw new AssertionError("Wrong candidate loaded: "+name);
  var listener=new SummaryGeneratingListener();var request=LauncherDiscoveryRequestBuilder.request().selectors(selectClass("org.jlinalg.cli.ShapeitBcfTest"),selectClass("org.jlinalg.cli.ShapeitRawIndexTest"),selectClass("org.jlinalg.cli.ShapeitJoinedRecordsTest"),selectClass("org.jlinalg.genetics.ShapeitCommonVariantsTest")).build();
  var launcher=LauncherFactory.create();launcher.registerTestExecutionListeners(listener);launcher.execute(request);var summary=listener.getSummary();summary.printTo(new java.io.PrintWriter(System.out));summary.printFailuresTo(new java.io.PrintWriter(System.out));
  if(summary.getTestsFoundCount()!=171||summary.getTestsSucceededCount()!=171||summary.getTestsSkippedCount()!=0||summary.getTestsFailedCount()!=0||summary.getContainersFailedCount()!=0)throw new AssertionError("Incomplete raw linkage controls");
 }
}
