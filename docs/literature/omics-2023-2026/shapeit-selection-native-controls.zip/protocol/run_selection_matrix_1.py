from pathlib import Path
import datetime, hashlib, json, subprocess, time, zipfile

root = Path('D:/projects/JLinAlg')
base = root / 'build/literature-review/shapeit-runtime'
out = base / 'selection-native-matrix-1'
out.mkdir(exist_ok=False)
jdk = Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin')
java25 = 'C:/Program Files/Common Files/Oracle/Java/javapath/java.exe'
source = root / 'src/main/java/org/jlinalg/genetics/ShapeitCommonVariants.java'
test = root / 'src/test/java/org/jlinalg/genetics/ShapeitCommonVariantsTest.java'
fixture = root / 'src/test/resources/org/jlinalg/genetics/shapeit-selection/original-controls.zip'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
frozen = {p.relative_to(root).as_posix(): sha(p) for p in [source, test, fixture]}
runs = []

def run(label, command):
    start = time.monotonic()
    with (out / (label + '.stdout')).open('wb') as stdout, (out / (label + '.stderr')).open('wb') as stderr:
        child = subprocess.Popen([str(x) for x in command], cwd=root, stdout=stdout, stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
        (out / 'running.json').write_text(json.dumps({'controller_Windows_pid': __import__('os').getpid(), 'child_pid': child.pid, 'phase': label}, indent=2) + '\n')
        code = child.wait()
    runs.append({'label': label, 'exit_code': code, 'seconds': time.monotonic() - start})
    (out / 'runs.json').write_text(json.dumps(runs, indent=2) + '\n')
    print(label, 'EXIT', code, flush=True)
    if code:
        print((out / (label + '.stdout')).read_text(errors='replace')[-4000:], flush=True)
        print((out / (label + '.stderr')).read_text(errors='replace')[-4000:], flush=True)
        raise SystemExit(code)

classes, testclasses = out / 'classes', out / 'test-classes'
classes.mkdir(); testclasses.mkdir()
run('strict-Java17', [jdk / 'javac.exe', '--release', '17', '-encoding', 'UTF-8', '-Xlint:all', '-Werror', '-d', classes, source])
run('strict-javadoc', [jdk / 'javadoc.exe', '--release', '17', '-encoding', 'UTF-8', '-quiet', '-Xdoclint:all', '-Werror', '-d', out / 'javadoc', source])
candidate = out / 'shapeit-native-selection.jar'
with zipfile.ZipFile(candidate, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(classes.rglob('*.class')):
        raw = path.read_bytes(); assert int.from_bytes(raw[6:8], 'big') == 61
        archive.writestr(path.relative_to(classes).as_posix(), raw)
    for name in ['SHAPEIT4-MIT.txt', 'SHAPEIT5-MIT.txt', 'SHAPEIT5-XCF-MIT.txt']:
        path = root / 'src/main/resources/META-INF/licenses' / name
        frozen[path.relative_to(root).as_posix()] = sha(path)
        archive.writestr('META-INF/licenses/' + name, path.read_bytes())
cache = Path('C:/Users/User/.gradle/caches/modules-2/files-2.1')
dependencies = []
for group, name, version in [('org.junit.jupiter','junit-jupiter-api','5.13.4'),('org.junit.jupiter','junit-jupiter-engine','5.13.4'),('org.junit.jupiter','junit-jupiter-params','5.13.4'),('org.junit.platform','junit-platform-commons','1.13.4'),('org.junit.platform','junit-platform-engine','1.13.4'),('org.junit.platform','junit-platform-launcher','1.13.4'),('org.opentest4j','opentest4j','1.3.0'),('org.apiguardian','apiguardian-api','1.1.2')]:
    matches = list((cache / group / name / version).glob('*/*.jar')); assert len(matches) == 1
    dependencies.append(matches[0])
runner = out / 'ShapeitJUnit.java'
runner.write_text('''import java.io.PrintWriter;
import java.nio.file.Path;
import org.junit.platform.engine.discovery.DiscoverySelectors;
import org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder;
import org.junit.platform.launcher.core.LauncherFactory;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;
public final class ShapeitJUnit {
 public static void main(String[] args) throws Exception {
  var actual=Path.of(org.jlinalg.genetics.ShapeitCommonVariants.class.getProtectionDomain().getCodeSource().getLocation().toURI()).toRealPath();
  if(!actual.equals(Path.of(args[0]).toRealPath()))throw new IllegalStateException("Native class did not load from the exact tested JAR");
  var listener=new SummaryGeneratingListener();
  var request=LauncherDiscoveryRequestBuilder.request().selectors(DiscoverySelectors.selectClass("org.jlinalg.genetics.ShapeitCommonVariantsTest")).build();
  var launcher=LauncherFactory.create();launcher.registerTestExecutionListeners(listener);launcher.execute(request);
  var summary=listener.getSummary();summary.printTo(new PrintWriter(System.out,true));summary.printFailuresTo(new PrintWriter(System.out,true));
  if(summary.getTestsFoundCount()!=57||summary.getTestsSucceededCount()!=57||summary.getTestsSkippedCount()!=0||summary.getTotalFailureCount()!=0)System.exit(1);
 }
}
''', encoding='utf-8')
run('compile-package-tests', [jdk / 'javac.exe', '--release', '17', '-encoding', 'UTF-8', '-Xlint:all', '-Werror', '-cp', ';'.join(map(str, [candidate, *dependencies])), '-d', testclasses, test, runner])
classpath = [candidate, testclasses, root / 'src/test/resources', *dependencies]
for label, java in [('Windows21', jdk / 'java.exe'), ('Windows25', java25)]:
    run(label, [java, '-Xmx256m', '-cp', ';'.join(map(str, classpath)), 'ShapeitJUnit', candidate])
def linux(path):
    text = str(path).replace('\\', '/')
    return '/mnt/' + text[0].lower() + text[2:]
run('Linux21', ['wsl.exe', '-d', 'JLinAlg-Omics-SAIGE-20261026', '--', '/usr/bin/java', '-Xmx256m', '-cp', ':'.join(linux(p) for p in classpath), 'ShapeitJUnit', linux(candidate)])
for name, expected in frozen.items(): assert sha(root / name) == expected, name
record = {'status': 'passed57exact-native-package-tests-three-JVMs-and-strict17-javadoc', 'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'profiles': {name: {'tests': 57, 'passed': 57, 'skipped': 0} for name in ['Windows21','Windows25','Linux21']}, 'candidate_sha256': sha(candidate), 'source_sha256': frozen, 'runs': runs, 'original_scanner_controls_per_JVM': 50, 'complete_original_scanner_masks_per_JVM': 36, 'expected_source_failure_controls_per_JVM': 14, 'additional_original_checked_boundary_controls': 1, 'native_join_reconstruction_available': False, 'public_upstream_adapter_available': False}
(out / 'observed.json').write_text(json.dumps(record, indent=2) + '\n')
print('ALL THREE NATIVE JVM PROFILES PASSED', flush=True)
