from pathlib import Path
import hashlib,json,sys,zipfile

root=Path('D:/projects/JLinAlg');base=root/'build/literature-review/shapeit-runtime';data=root/'docs/literature/omics-2023-2026';matrix=base/'selection-native-matrix-2'
sys.path.insert(0,str(root/'tools/literature'));from shapeit_selection_validation import SOURCE_PATHS
digest=lambda raw:hashlib.sha256(raw).hexdigest()
pins=[{'path':name,'sha256':digest((root/name).read_bytes())} for name in sorted(SOURCE_PATHS)]
members={'source/'+item['path']:(root/item['path']).read_bytes() for item in pins}
members['artifacts/shapeit-native-selection.jar']=(matrix/'shapeit-native-selection.jar').read_bytes()
members['artifacts/original-selection-controls.zip']=(root/'src/test/resources/org/jlinalg/genetics/shapeit-selection/original-controls.zip').read_bytes()
observed=json.loads((matrix/'observed.json').read_bytes());assert observed['status']=='passed57exact-native-package-tests-three-JVMs-and-strict17-javadoc'
for path,expected in observed['source_sha256'].items():assert digest((root/path).read_bytes())==expected,path
for path in matrix.iterdir():
    if path.is_file() and path.name!='running.json':members['matrix/'+path.name]=path.read_bytes()
for path in (matrix/'test-classes').rglob('*.class'):members['tests/classes/'+path.relative_to(matrix/'test-classes').as_posix()]=path.read_bytes()
for name in ['run_selection_matrix_1.py','selection-native-matrix-controller-1.log','run_selection_matrix_2.py','selection-native-matrix-controller-2.log']:
    members['protocol/'+name]=(base/name).read_bytes()
members['protocol/freeze_selection_candidate_2.py']=Path(__file__).read_bytes()
members['history/proof-before-counter-clarification.json']=(base/'selection-proof-before-counter-clarification-1/shapeit-selection-validation.json').read_bytes()
members['SHA256SUMS']=''.join(digest(raw)+'  '+name+'\n' for name,raw in sorted(members.items())).encode()
destination=data/'shapeit-selection-native-controls.zip'
with destination.open('wb') as stream,zipfile.ZipFile(stream,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,raw in sorted(members.items()):
        entry=zipfile.ZipInfo(name,(2026,11,1,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED;entry.external_attr=0o100644<<16;archive.writestr(entry,raw)
proof={'schema_version':1,'status':'passed-native-common-selection-on-original-joined-streams','source_commit':'c34d4db3e99a2f7e23deb727671ae260901a5886',
       'native_controls':{'path':destination.name,'bytes':destination.stat().st_size,'sha256':digest(destination.read_bytes())},
       'native_candidate_sha256':digest(members['artifacts/shapeit-native-selection.jar']),
       'original_controls_sha256':digest(members['artifacts/original-selection-controls.zip']),
       'original_scanner_calls':50,'complete_scanner_results':36,'expected_original_failures':14,'additional_checked_source_boundary_calls':1,
       'synchronized_events':641,'selected_sites':336,'native_tests_per_JVM':57,'JVM_profiles':3,
       'public_phasing_adapter_available':False,'whole_paper_reproduced':False,'native_join_reconstruction_available':False,
       'XCF_binary_payloads_validated':False,'new_tool_integrations':0,'source_evidence':pins,
       'warnings':[{'code':'VOID_HEADER_GAP','cause':'An ordinary sites-only file before a data-bearing file misaligns the original XCF sample-name vectors. The original empty-target/reference control crashed; a checked build confirmed the vector access.','action':'Skip dependent phasing. Supply appropriate nonempty target/panel inputs or separately validate an upstream header-handling fix.'},
                   {'code':'SCANNER_SUCCESS_IS_NOT_GENOTYPE_ADMISSION','cause':'Original selection can keep a site with an unsupported scaffold type or an ordinary-GT record with no GT field. The scaffold removed counter does not imply site exclusion.','action':'Validate actual genotype payloads and supported, non-missing, phased scaffold data before dependent fitting. Do not count a successful scanner mask as successful phasing.'},
                   {'code':'AC_AN_SOURCE_METADATA','cause':'The original checks singleton integer getter results before exclusions and uses declared signed-to-uint32 counts with Float32 comparisons. Invalid biological counts can remain source-visible.','action':'Inspect count-conversion and non-finite warnings, preserve the declared inputs and perform any correction only as explicit source-verified preprocessing. Do not silently derive replacement counts from GT.'},
                   {'code':'PUBLIC_PHASER_UNFINISHED','cause':'The native method consumes already synchronized original events; protected file/runtime and full fitting/output admission are unfinished.','action':'Complete raw-record linkage, EOF/source identity and reference/scaffold/common/rare/ligation audits before reporting an integrated phasing analysis.'}],
       'scope':'Original common-stage source masks, order and counters only. No native HTSlib join reconstruction, binary genotype decoding, protected phasing runtime, convergence or phase-accuracy certification.'}
target=data/'shapeit-selection-validation.json';target.write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'native_bundle_sha256':proof['native_controls']['sha256'],'native_candidate_sha256':proof['native_candidate_sha256'],'bytes':destination.stat().st_size,'members':len(members),'source_pins':len(pins)},indent=2))
