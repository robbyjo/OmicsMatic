from pathlib import Path
import hashlib,json,shutil,subprocess,time,zipfile
R=Path('D:/projects/JLinAlg');W=R/'build/literature-review/fastp-runtime/public-workflow-development-1';O=W/'large-portable-windows-1';O.mkdir();root=O/'result';root.mkdir();assert shutil.disk_usage(O).free>3<<30
with zipfile.ZipFile(W/'large-workflow-control-1.zip') as z:
 prefix='large-single-end-above-64MiB/result/'
 for e in z.infolist():
  if not e.filename.startswith(prefix):continue
  member=e.filename[len(prefix):];assert member and '\\' not in member and ':' not in member and all(part not in ['','.','..'] for part in member.split('/'));p=root/member;p.parent.mkdir(parents=True,exist_ok=True)
  with z.open(e) as source,p.open('xb') as out:shutil.copyfileobj(source,out)
jar=W/'package-3/omicsmatic-0.3.7-fastp-development.jar';cmd=['C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe','-Xmx128m','-XX:ActiveProcessorCount=2','-jar',str(jar),'fastp-tools','--verify',str(root)];started=time.monotonic()
with (O/'stdout').open('xb') as out,(O/'stderr').open('xb') as err:p=subprocess.run(cmd,cwd=R,stdout=out,stderr=err,timeout=1800)
record=dict(status='passed-large-portable-Windows-replay' if p.returncode==0 else 'failed-large-portable-Windows-replay',command=cmd,exit_code=p.returncode,elapsed_seconds=time.monotonic()-started,artifact_sha256=hashlib.sha256(jar.read_bytes()).hexdigest(),input_bytes=84300000,input_reads=300000,original_runtime_accessed=False,original_processing_rerun=False)
(O/'observed.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));assert p.returncode==0,(O/'stderr').read_text()[:4000]
