from pathlib import Path
import concurrent.futures,hashlib,json,os,re,subprocess,xml.etree.ElementTree as ET
R=Path('D:/projects/JLinAlg');B=R/'build/literature-review/fastp-runtime/public-workflow-development-1';O=B/'packaged-tests-1';O.mkdir();jar=B/'package-3/omicsmatic-0.3.7-fastp-development.jar';libs=sorted((R/'build/literature-review/shapeit-runtime/owned-common-native-matrix-4/lib').glob('*.jar'));assert len(libs)==9
names=['org.jlinalg.sequence.FastpReadFilterTest',*[p.stem for p in []]]
names+=['org.jlinalg.cli.'+p.stem for p in sorted((R/'src/test/java/org/jlinalg/cli').glob('Fastp*Test.java')) if p.stem!='FastpOriginalStageTest'];assert len(names)==11
counts={name:ET.fromstring((R/'build/test-results/test'/('TEST-'+name+'.xml')).read_bytes()).attrib for name in names};total=sum(int(a['tests']) for a in counts.values());assert total==415 and sum(int(a['failures'])+int(a['errors']) for a in counts.values())==0
runner=O/'RunFastpPublicChecks.java';runner.write_text('''import java.io.PrintWriter;
import org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder;
import org.junit.platform.launcher.core.LauncherFactory;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;
public final class RunFastpPublicChecks {
 private RunFastpPublicChecks() { }
 public static void main(String[] args) {
  var request=LauncherDiscoveryRequestBuilder.request().selectors(SELECTORS).build();
  var listener=new SummaryGeneratingListener();LauncherFactory.create().execute(request,listener);
  listener.getSummary().printTo(new PrintWriter(System.out));listener.getSummary().printFailuresTo(new PrintWriter(System.out));
  if(listener.getSummary().getTestsFailedCount()>0||listener.getSummary().getTestsFoundCount()!=415)System.exit(1);
 }
}
'''.replace('SELECTORS',','.join(f'selectClass("{name}")' for name in names)))
classes=O/'classes';classes.mkdir();j='C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin';sources=[runner,*sorted((R/'src/test/java/org/jlinalg/cli').glob('Fastp*Test.java')),R/'src/test/java/org/jlinalg/sequence/FastpReadFilterTest.java'];cmd=[j+'/javac.exe','--release','17','-Xlint:all','-Werror','-cp',os.pathsep.join(map(str,[jar,*libs])),'-d',str(classes),*map(str,sources)]
with (O/'compile.stdout').open('xb') as out,(O/'compile.stderr').open('xb') as err:p=subprocess.run(cmd,cwd=R,stdout=out,stderr=err,timeout=120)
assert p.returncode==0,(O/'compile.stderr').read_text()
linux=lambda p:'/mnt/d/'+p.relative_to(Path('D:/')).as_posix();entries=[classes,jar,R/'src/test/resources',*libs];windows_cp=os.pathsep.join(map(str,entries));runs=[('windows-java21',[j+'/java.exe','-Xmx128m','-XX:ActiveProcessorCount=2','-cp',windows_cp,'RunFastpPublicChecks'],398,17),('windows-java25',['C:/Program Files/Common Files/Oracle/Java/javapath/java.exe','-Xmx128m','-XX:ActiveProcessorCount=2','-cp',windows_cp,'RunFastpPublicChecks'],398,17),('linux-java21',['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','env','JLINALG_FASTP_MANAGED_ROOT=/opt/omicsmatic-fastp-managed-1','/usr/bin/java','-Xmx128m','-XX:ActiveProcessorCount=2','-cp',':'.join(map(linux,entries)),'RunFastpPublicChecks'],415,0)]
def execute(row):
 name,cmd,passed,aborted=row
 with (O/(name+'.stdout')).open('xb') as out,(O/(name+'.stderr')).open('xb') as err:p=subprocess.run(cmd,cwd=R,stdout=out,stderr=err,timeout=1800)
 record=dict(name=name,command=cmd,exit_code=p.returncode,tests_found=total,expected_passed=passed,expected_aborted_platform_controls=aborted);(O/(name+'.observed.json')).write_text(json.dumps(record,indent=2)+'\n');text=(O/(name+'.stdout')).read_text(errors='replace');assert p.returncode==0,(name,text[-4000:])
 for count,label in [(total,'tests found'),(passed,'tests successful'),(0,'tests failed'),(aborted,'tests aborted')]:assert re.search(r'\[\s*'+str(count)+' '+label+r'\s*\]',text),(name,label,text[-4000:])
 print(name,'passed',passed,'platform-aborted',aborted,flush=True);return record
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:observed=list(pool.map(execute,runs))
record=dict(status='passed-actual-JAR-fastp-public-workflow-and-portable-replay-matrix',tests_found_per_JVM=total,runs=observed,artifact=jar.relative_to(R).as_posix(),artifact_sha256=hashlib.sha256(jar.read_bytes()).hexdigest(),heap_mib=128,strict_Java_release=17,scientific_originals_rerun_by_this_matrix=False,public_original_cases_replayed_per_JVM=57)
(O/'summary.json').write_text(json.dumps(record,indent=2)+'\n');print(record['status'])
