from pathlib import Path
import hashlib,json,subprocess,sys
R=Path('D:/projects/JLinAlg');sys.path.insert(0,str(R/'tools/literature'))
from curate_shapeit_uses import inverse
from catalog_source_integrity import reverse_delta,verify_source
p='src/main/java/org/jlinalg/cli/JLinAlgCli.java';before=subprocess.run(['git','show','HEAD:'+p],cwd=R,capture_output=True,check=True).stdout;after=(R/p).read_bytes();row=inverse(before,after);row['path']=p
assert len(row['edits'])==2 and reverse_delta(after,row)==before
D=R/'docs/literature/omics-2023-2026';document=dict(schema_version=1,status='passed-dispatch-catalog-only-source-deltas',tool_id='fastp',scope='Adds only the fixed fastp dispatch branch and help example. The integration remains development-only in the catalog until its public workflow gates pass. All pre-existing dispatch/scientific code reconstructs byte-for-byte.',paths=[row]);target=D/'fastp-dispatch-shared-source-compatibility.json';assert not target.exists();target.write_text(json.dumps(document,indent=2)+'\n',encoding='utf-8',newline='\n')
verify_source(R,D,p,hashlib.sha256(before).hexdigest());manifest=D/'SHA256SUMS';(R/'build/literature-review/fastp-runtime/public-workflow-development-1/SHA256SUMS-before-dispatch').write_bytes(manifest.read_bytes());lines=manifest.read_text().splitlines();assert not any(line.endswith('  '+target.name) for line in lines);lines.append(hashlib.sha256(target.read_bytes()).hexdigest()+'  '+target.name);manifest.write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\n');print('exact inverse verified;metadata-only dispatcher support recorded')
