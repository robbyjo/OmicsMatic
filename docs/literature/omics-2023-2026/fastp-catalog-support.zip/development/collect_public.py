from pathlib import Path
import hashlib,json,os,subprocess,sys,time,zipfile
R=Path('/mnt/d/projects/JLinAlg');W=R/'build/literature-review/fastp-runtime/public-workflow-development-1';O=Path('/opt/omicsmatic-fastp-public-workflow-controls-1');JAR=W/'package-2/omicsmatic-0.3.7-fastp-development.jar'
RESUME=sys.argv[1:]==['--resume'];assert not sys.argv[1:] or RESUME
if RESUME:assert O.is_dir() and O.resolve()==O
else:O.mkdir(mode=0o700)
SHA=lambda b:hashlib.sha256(b).hexdigest();PIN=lambda p:dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(p.open('rb'),'sha256').hexdigest())
def dump(p,value):
 with p.open('x') as out:json.dump(value,out,indent=2);out.write('\n')
def audit_limits(large=False):return dict(statistics=dict(cycles=10000,maximumResidentBytes=2097152),sorting=dict(memoryBytes=8388608,lineCharacters=100000,records=1000000 if large else 100000,maximumParts=2000 if large else 128),matching=dict(familyRecords=4096,familyBytes=8388608,matchingOperations=100000000000 if large else 100000000,solverSteps=10000000),jsonBytes=4194304)
def census(root):
 result={}
 for path in sorted(root.rglob('*')):
  assert not path.is_symlink()
  if path.is_file():result[path.relative_to(root).as_posix()]=PIN(path)
  else:assert path.is_dir()
 return result
def validate(root):
 manifest=json.loads((root/'manifest.json').read_bytes());marker=json.loads((root/'COMPLETED.json').read_bytes());assert marker['manifest']==PIN(root/'manifest.json') and marker['scoped_result_admitted']
 found=census(root);assert set(found)==set(manifest['files'])|{'manifest.json','COMPLETED.json'} and all(found[k]==v for k,v in manifest['files'].items());return found
def run_case(name,recipe,raw_inputs):
 root=O/name;root.parent.mkdir(parents=True,exist_ok=True)
 if root.exists():
  assert RESUME and (root/'observed.json').is_file();receipt=json.loads((root/'observed.json').read_bytes());assert receipt['exit_code']==0 and receipt['jar']==PIN(JAR);validate(root/'result');assert json.loads((root/'recipe.json').read_bytes())==recipe
  for member,raw in raw_inputs.items():assert (root/member).read_bytes()==raw
  print(name,'verified-retained-without-original-rerun',flush=True);return
 root.mkdir(mode=0o700)
 for member,raw in raw_inputs.items():(root/member).write_bytes(raw)
 dump(root/'recipe.json',recipe)
 if name=='p054-reported-options':
  available=int(next(s.split()[1] for s in Path('/proc/meminfo').read_text().splitlines() if s.startswith('MemAvailable:')))*1024
  assert available>=28<<30,'P054 accuracy6 needs permitted adequate resources;do not lower settings';dump(root/'memory-preflight.json',dict(mem_available_bytes=available,minimum_available_bytes=28<<30,accuracy=6,bloom_bytes=24<<30))
 version=recipe['profile'].split('fastp-')[-1];cmd=['/usr/bin/java','-Xmx128m','-XX:ActiveProcessorCount=2','-jar',str(JAR),'fastp-tools','--recipe',str(root/'recipe.json'),'--home','/opt/omicsmatic-fastp-managed-1/homes/'+version,'--setup-report','/opt/omicsmatic-fastp-managed-1/reports/'+version,'--out',str(root/'result')];started=time.monotonic()
 with (root/'stdout').open('xb') as out,(root/'stderr').open('xb') as err:p=subprocess.run(cmd,stdout=out,stderr=err,timeout=1200)
 record=dict(command=cmd,exit_code=p.returncode,elapsed_seconds=time.monotonic()-started,jar=PIN(JAR));dump(root/'observed.json',record);print(name,'exit',p.returncode,'seconds',round(record['elapsed_seconds'],2),flush=True)
 assert p.returncode==0,(name,(root/'stderr').read_text()[:2500]);validate(root/'result')
def archive(target,selected):
 assert not target.exists();files={}
 with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name in selected:
   root=O/name
   for p in sorted(root.rglob('*')):
    assert not p.is_symlink()
    if p.is_file():member=name+'/'+p.relative_to(root).as_posix();z.write(p,member);files[member]=PIN(p)
  z.writestr('MANIFEST.json',json.dumps(files,indent=2)+'\n');z.writestr('CASES.json',json.dumps(dict(cases=selected,jar=PIN(JAR),all_owned_processes_terminal=True),indent=2)+'\n')
 return dict(path=target.name,**PIN(target),files=len(files))
with zipfile.ZipFile(R/'src/test/resources/org/jlinalg/cli/fastp-output/original-output-controls.zip') as z:
 cases=json.loads(z.read('CASES.json'))['cases'];assert len(cases)==57
 for case in cases:
  name=case['path'];prefix=name+'/result/';request=json.loads(z.read(prefix+'request.json'));captures=json.loads(z.read(prefix+'input-captures.json'));inputs={};payload={}
  for i,c in enumerate(captures,1):member=f'read{i}.original';inputs[f'read{i}']=member;payload[member]=z.read(prefix+c['snapshot'])
  recipe=dict(schema_version=1,profile=request['profile'],inputs=inputs,policies=dict(encoding=request['encoding'],alphabet=request['alphabet'],plus=request['plus_policy'],pairing=request['pairing_policy']),options=request['options'],limits=dict(stage=request['limits'],audit=audit_limits()))
  run_case(name,recipe,payload)
 small=archive(W/'public-workflow-controls-1.zip',[c['path'] for c in cases]);dump(W/'public-workflow-controls-1.json',dict(status='captured-completed-public-workflow-matrix',cases=57,artifact=small,all_owned_processes_terminal=True))
 # Regression: raw FASTQ exceeds the executable/setup fingerprint's old64MiB ceiling.
 name='large-single-end-above-64MiB';root=O/name
 if not root.exists():
  preparation=O/'large-input-preparation';preparation.mkdir();input_path=preparation/'read1.original';sequence='ACGTTGCAAGCTTAGCCTAGGATCGACATGCTAGCTACGATCGTTGACCTAGCATGTCGACTAGCGATGCTACGTAGCTACGTTAGCATGCTAGCTAGGCTAACGTAGCTAGCATGACCTAGGCTAGCTAGCA'[:130]
  with input_path.open('xb') as out:
   for i in range(300000):out.write((f'@large:{i:09d}\n'+sequence+'\n+\n'+'I'*len(sequence)+'\n').encode())
  assert input_path.stat().st_size>67108864;raw=input_path.read_bytes()
 else:assert RESUME;raw=(root/'read1.original').read_bytes()
 request=json.loads(z.read('0.23.2/se-default/result/request.json'));options=request['options'];options['polyG']='DISABLE';stage=request['limits'];stage.update(bundleBytes=2<<30,bundleFiles=10000);stage['fastq'].update(encodedBytes=128<<20,decodedCharacters=256<<20,reads=400000,bases=100000000);stage['process'].update(wallMillis=600000,cpuSeconds=600,fileBytes=128<<20,workspaceBytes=512<<20,fileCount=512)
 recipe=dict(schema_version=1,profile=request['profile'],inputs=dict(read1='read1.original'),policies=dict(encoding='PHRED33',alphabet='UPPER_ACGTN',plus='EMPTY_ONLY',pairing='EXACT_FIRST_TOKEN'),options=options,limits=dict(stage=stage,audit=audit_limits(True)))
 run_case(name,recipe,{'read1.original':raw});large=archive(W/'large-workflow-control-1.zip',[name]);dump(W/'large-workflow-control-1.json',dict(status='captured-completed-large-public-workflow',input_bytes=len(raw),input_reads=300000,artifact=large,all_owned_processes_terminal=True));print('all58 public workflows captured',flush=True)
