from pathlib import Path
import hashlib,json,re,sys
R=Path('D:/projects/JLinAlg');D=R/'docs/literature/omics-2023-2026';W=R/'build/literature-review/fastp-runtime/public-workflow-development-1';sys.path.insert(0,str(R/'tools/literature'))
from curate_shapeit_uses import inverse
from catalog_source_integrity import reverse_delta,verify_source
path='tools/literature/check_review_ui.cjs';p=R/path;before=p.read_bytes();text=before.decode();lines=[];changes=0
for line in text.splitlines(keepends=True):
 old=line
 if "implementation_status==='upstream-adapter-validated'" in line:line=re.sub(r'(\.length,\s*)47(\))',r'\g<1>48\2',line)
 if "implementation_status==='missing'" in line:line=re.sub(r'(\.length,\s*)260(\))',r'\g<1>259\2',line)
 if line!=old:changes+=1
 lines.append(line)
after=''.join(lines).encode();assert changes>0;row=inverse(before,after);row['path']=path;assert reverse_delta(after,row)==before;(W/'check_review_ui-before-spaced-counts.cjs.txt').write_bytes(before);p.write_bytes(after)
document=dict(schema_version=1,status='passed-dispatch-catalog-only-source-deltas',tool_id='fastp',scope='Updates only the previously spaced generic inventory-count assertions for48 upstream adapters and259 missing tools. All scientific checks reconstruct exactly through the reviewed inverse chain.',paths=[row]);target=D/'fastp-ui-counter-shared-source-compatibility.json';assert not target.exists();target.write_text(json.dumps(document,indent=2)+'\n',encoding='utf-8',newline='\n');verify_source(R,D,path,row['before_sha256'])
manifest=D/'SHA256SUMS';prior=[line.split('  ',1)[1] for line in manifest.read_text().splitlines()];files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in D.iterdir() if p.is_file() and p.name!='SHA256SUMS'};order=[name for name in prior if name in files]+[name for name in sorted(files) if name not in prior];manifest.write_text(''.join(files[name]+'  '+name+'\n' for name in order),encoding='utf-8',newline='\n');print('current inventory-only spaced assertions updated:',changes)
