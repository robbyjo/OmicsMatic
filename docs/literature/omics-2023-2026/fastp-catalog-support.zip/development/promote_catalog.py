from pathlib import Path
import hashlib,json,subprocess,sys
R=Path('D:/projects/JLinAlg');W=R/'build/literature-review/fastp-runtime/public-workflow-development-1';D=R/'docs/literature/omics-2023-2026';sys.path.insert(0,str(R/'tools/literature'))
from curate_shapeit_uses import inverse
from catalog_source_integrity import reverse_delta,verify_source
assert json.loads((W/'packaged-tests-1/summary.json').read_bytes())['tests_found_per_JVM']==415
assert 'Ran 4 tests' in (W/'python-fastp-1.log').read_text() and '\nOK' in (W/'python-fastp-1.log').read_text()
documents=[]
path='tools/literature/render_review.py';p=R/path;before=p.read_bytes();(W/'render_review-before-fastp.py.txt').write_bytes(before);after=before
changes=[(b'from pal2nal_catalog import pal2nal_metadata, PAL2NAL_WARNING, PAL2NAL_ACTIONS\n',b'from pal2nal_catalog import pal2nal_metadata, PAL2NAL_WARNING, PAL2NAL_ACTIONS\nfrom fastp_catalog import fastp_metadata, FASTP_WARNING, FASTP_ACTIONS\n',1),
(b'        elif tool_id == "pal2nal":\n            tool.update(pal2nal_metadata(ROOT, DATA))\n',b'        elif tool_id == "pal2nal":\n            tool.update(pal2nal_metadata(ROOT, DATA))\n        elif tool_id == "fastp":\n            tool.update(fastp_metadata(ROOT, DATA))\n',1),
(b'"mafft", "pal2nal", "favor"',b'"mafft", "pal2nal", "fastp", "favor"',1),
(b'+ PAL2NAL_WARNING +',b'+ PAL2NAL_WARNING + FASTP_WARNING +',1),
(b'+ PAL2NAL_ACTIONS +',b'+ PAL2NAL_ACTIONS + FASTP_ACTIONS +',2)]
for old,new,count in changes:assert after.count(old)==count,(old,after.count(old));after=after.replace(old,new)
row=inverse(before,after);row['path']=path;assert reverse_delta(after,row)==before;documents.append(row);p.write_bytes(after)
path='tools/literature/check_review_ui.cjs';p=R/path;before=p.read_bytes();(W/'check_review_ui-before-fastp.cjs.txt').write_bytes(before);after=before
for old,new in [(b'.length,47)',b'.length,48)'),(b'.length,260)',b'.length,259)'),(b'60new',b'61new'),(b'63includingExisting',b'64includingExisting'),(b'63withExisting',b'64withExisting'),(b'260missing',b'259missing')]:
 assert old in after,old;after=after.replace(old,new)
row=inverse(before,after);row['path']=path;assert reverse_delta(after,row)==before;documents.append(row);p.write_bytes(after)
document=dict(schema_version=1,status='passed-dispatch-catalog-only-source-deltas',tool_id='fastp',scope='Adds only the verified fastp metadata import/branch,warnings/actions and updates current inventory-count assertions/labels in the generic browser check. Exact inverse preserves all pre-existing rendering/scientific code and UI checks.',paths=documents)
target=D/'fastp-catalog-shared-source-compatibility.json';assert not target.exists();target.write_text(json.dumps(document,indent=2)+'\n',encoding='utf-8',newline='\n')
for row in documents:verify_source(R,D,row['path'],row['before_sha256'])
print('verified exact inverses for fastp catalog/UI additions;running complete renderer',flush=True)
with (W/'render-1.stdout').open('xb') as out,(W/'render-1.stderr').open('xb') as err:p=subprocess.run([sys.executable,'-X','utf8','tools/literature/render_review.py'],cwd=R,stdout=out,stderr=err)
assert p.returncode==0,(W/'render-1.stderr').read_text()[-4000:]
summary=json.loads((D/'summary.json').read_bytes());assert summary['papers']==250 and summary['distinct_named_tools']==380 and summary['paper_tool_observations']==2430 and summary['implementation_status_counts']['upstream-adapter-validated']==48 and summary['implementation_status_counts']['native-subset-validated']==13 and summary['implementation_status_counts']['missing']==259
tools=json.loads((D/'tool-inventory.json').read_bytes());item=next(t for t in tools if t['id']=='fastp');assert item['implementation_status']=='upstream-adapter-validated' and item['source_roles_reviewed']==7 and item['development_adapter_cli']=='fastp-tools';report=dict(status='passed-scoped-fastp-catalog-integration',new_scoped_integrations=61,native_scopes=13,upstream_adapters=48,including_preexisting_adapters=64,named_tools_missing=259,source_papers=250,named_tools=380,observations=2430,reviewed_uses=767,reviewed_fastp_roles=7,whole_goal_complete=False,released_or_deployed=False)
(W/'catalog-promotion-1.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
