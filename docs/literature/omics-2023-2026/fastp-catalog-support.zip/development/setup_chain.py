from pathlib import Path
import json,shutil,subprocess,zipfile
R=Path('/mnt/d/projects/JLinAlg');W=R/'build/literature-review/fastp-runtime/public-workflow-development-1';O=Path('/opt/omicsmatic-fastp-public-setup-chain-1');O.mkdir(mode=0o700);JAR=W/'package-3/omicsmatic-0.3.7-fastp-development.jar';base=['/usr/bin/java','-Xmx128m','-XX:ActiveProcessorCount=2','-jar',str(JAR),'fastp-tools'];records=[]
def run(name,cmd,cwd):
 with (O/(name+'.stdout')).open('xb') as out,(O/(name+'.stderr')).open('xb') as err:p=subprocess.run(cmd,cwd=cwd,stdout=out,stderr=err,timeout=240)
 record=dict(name=name,command=cmd,exit_code=p.returncode);(O/(name+'.observed.json')).write_text(json.dumps(record,indent=2)+'\n');records.append(record);assert p.returncode==0,(name,(O/(name+'.stderr')).read_text()[:4000])
run('export',base+['--export-runtime-setup',str(O/'exported')],O);(O/'cache').mkdir();shutil.copyfile('/opt/omicsmatic-fastp-managed-1/homes/0.23.2/fastp',O/'cache/fastp.0.23.2')
run('setup',['/usr/bin/python3','tools/literature/install_fastp.py','--profile','linux-x86_64-fastp-0.23.2','--home',str(O/'home'),'--report',str(O/'setup-report'),'--cache',str(O/'cache'),'--allow-install'],O/'exported')
recipe=json.loads(Path('/opt/omicsmatic-fastp-public-smoke-2/recipe.json').read_bytes());recipe['inputs']={key:'/opt/omicsmatic-fastp-public-smoke-2/'+value for key,value in recipe['inputs'].items()};(O/'recipe.json').write_text(json.dumps(recipe,indent=2)+'\n')
run('analysis',base+['--recipe',str(O/'recipe.json'),'--home',str(O/'home'),'--setup-report',str(O/'setup-report'),'--out',str(O/'result')],O);run('verify',base+['--verify',str(O/'result')],O)
target=W/'export-install-analysis-chain-1.zip';assert not target.exists()
with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(O.rglob('*')):
  if p.is_file() and not p.is_relative_to(O/'cache') and not p.is_relative_to(O/'home'):z.write(p,p.relative_to(O).as_posix())
(W/'export-install-analysis-chain-1.json').write_text(json.dumps(dict(status='passed-export-offline-install-user-analysis-portable-verify-chain',records=records,download_performed=False,global_install_performed=False,archive=target.name),indent=2)+'\n');print('complete exported setup/user analysis chain passed')
