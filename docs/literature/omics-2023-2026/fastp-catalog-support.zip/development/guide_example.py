from pathlib import Path
import json,subprocess,zipfile
R=Path('/mnt/d/projects/JLinAlg');W=R/'build/literature-review/fastp-runtime/public-workflow-development-1';O=Path('/opt/omicsmatic-fastp-public-guide-example-1');O.mkdir(mode=0o700);jar=W/'package-3/omicsmatic-0.3.7-fastp-development.jar';base=['/usr/bin/java','-Xmx128m','-XX:ActiveProcessorCount=2','-jar',str(jar),'fastp-tools'];records=[]
seq='ACGTTGCAAGCTTAGCCGAT'*4;mate=seq.translate(str.maketrans('ACGT','TGCA'))[::-1]
for number,bases in [(1,seq),(2,mate)]:(O/f'read{number}.fastq').write_text(f'@example:1/{number}\n{bases}\n+\n'+('I'*len(bases))+'\n')
with (O/'recipe.json').open('xb') as out,(O/'example.stderr').open('xb') as err:p=subprocess.run(base+['--example'],stdout=out,stderr=err,cwd=O,timeout=30)
assert p.returncode==0
for name,cmd in [('analysis',base+['--recipe',str(O/'recipe.json'),'--home','/opt/omicsmatic-fastp-public-setup-chain-1/home','--setup-report','/opt/omicsmatic-fastp-public-setup-chain-1/setup-report','--out',str(O/'result')]),('verify',base+['--verify',str(O/'result')])]:
 with (O/(name+'.stdout')).open('xb') as out,(O/(name+'.stderr')).open('xb') as err:p=subprocess.run(cmd,stdout=out,stderr=err,cwd=O,timeout=240)
 record=dict(command=cmd,exit_code=p.returncode);records.append(record);assert p.returncode==0,(O/(name+'.stderr')).read_text()[:4000]
with zipfile.ZipFile(W/'guide-example-1.zip','x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(O.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(O).as_posix())
(W/'guide-example-1.json').write_text(json.dumps(dict(status='passed-exact-beginner-example-inputs-and-emitted-recipe',records=records,reads=2,bases=160),indent=2)+'\n');print('guide example passed')
# Retain the failed original finalization attempt without changing its marker state.
failed=Path('/opt/omicsmatic-fastp-public-smoke-1');assert not (failed/'result/COMPLETED.json').exists()
with zipfile.ZipFile(W/'failed-smoke-1.zip','x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(failed.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(failed).as_posix())
print('initial failed finalization captured without promotion')
