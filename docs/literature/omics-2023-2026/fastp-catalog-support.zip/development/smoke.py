from pathlib import Path
import json,subprocess,zipfile
R=Path('/mnt/d/projects/JLinAlg'); W=R/'build/literature-review/fastp-runtime/public-workflow-development-1'; O=Path('/opt/omicsmatic-fastp-public-smoke-2');O.mkdir(mode=0o700)
with zipfile.ZipFile(R/'src/test/resources/org/jlinalg/cli/fastp-output/original-output-controls.zip') as z:
 prefix='0.23.2/pe-store-orphans/result/';request=json.loads(z.read(prefix+'request.json'));captures=json.loads(z.read(prefix+'input-captures.json'));inputs={}
 for i,c in enumerate(captures,1):p=O/f'read{i}.original';p.write_bytes(z.read(prefix+c['snapshot']));inputs[f'read{i}']=p.name
recipe=dict(schema_version=1,profile=request['profile'],inputs=inputs,policies=dict(encoding=request['encoding'],alphabet=request['alphabet'],plus=request['plus_policy'],pairing=request['pairing_policy']),options=request['options'])
recipe['limits']=dict(stage=request['limits'],audit=dict(statistics=dict(cycles=10000,maximumResidentBytes=2097152),sorting=dict(memoryBytes=8388608,lineCharacters=100000,records=100000,maximumParts=128),matching=dict(familyRecords=4096,familyBytes=8388608,matchingOperations=100000000,solverSteps=10000000),jsonBytes=4194304))
(O/'recipe.json').write_text(json.dumps(recipe,indent=2)+'\n');jar=W/'package-2/omicsmatic-0.3.7-fastp-development.jar';cmd=['/usr/bin/java','-Xmx128m','-XX:ActiveProcessorCount=2','-jar',str(jar),'fastp-tools','--recipe',str(O/'recipe.json'),'--home','/opt/omicsmatic-fastp-managed-1/homes/0.23.2','--setup-report','/opt/omicsmatic-fastp-managed-1/reports/0.23.2','--out',str(O/'result')]
with (W/'smoke-2.stdout').open('xb') as out,(W/'smoke-2.stderr').open('xb') as err:p=subprocess.run(cmd,stdout=out,stderr=err,timeout=240)
(W/'smoke-2.observed.json').write_text(json.dumps(dict(command=cmd,exit_code=p.returncode,root=str(O)),indent=2)+'\n');print('original public workflow exit',p.returncode);raise SystemExit(p.returncode)
