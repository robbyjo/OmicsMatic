from pathlib import Path
import datetime,gzip,hashlib,json,subprocess,sys,zipfile,xml.etree.ElementTree as ET
R=Path('D:/projects/JLinAlg');W=R/'build/literature-review/fastp-runtime/public-workflow-development-1';D=R/'docs/literature/omics-2023-2026';sys.path.insert(0,str(R/'tools/literature'))
from collect_omics_review import paragraphs
from catalog_source_integrity import verify_source
sha=lambda raw:hashlib.sha256(raw).hexdigest();load=lambda p:json.loads(p.read_bytes())
def pin(p):
 with p.open('rb') as stream:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(stream,'sha256').hexdigest())
assert 'Ran 623 tests' in (W/'python-full-2.log').read_text() and 'OK (skipped=46)' in (W/'python-full-2.log').read_text();assert 'BUILD SUCCESSFUL' in (W/'check-website-1.log').read_text()
browser=load(W/'browser-summary-2.json');assert len(browser['runs'])==2 and all(r['exit_code']==0 for r in browser['runs'])
for label in ['fastp','complete']:assert load(W/f'browser-{label}-2/ui-validation.json')['status']=='passed'
workflow_path=R/'docs/literature/FASTP_WORKFLOW_DEVELOPMENT_VALIDATION.json';workflow=load(workflow_path)
for path,expected in workflow['source_pins'].items():verify_source(R,D,path,expected['sha256'])
assert pin(R/'docs/literature'/workflow['artifact']['path'])=={k:v for k,v in workflow['artifact'].items() if k!='path'}
assert pin(R/'build/cli/omicsmatic-0.3.7.jar')['sha256']=='bd1a3b2448d7016ae4ded3f30a6c5ae92e05a0078ae688f4b93d046cc355eeb2'
summary=load(D/'summary.json');counts=summary['implementation_status_counts'];assert summary['papers']==250 and summary['distinct_named_tools']==380 and summary['paper_tool_observations']==2430 and counts['upstream-adapter-validated']==48 and counts['native-subset-validated']==13 and counts['missing']==259
roles=load(D/'fastp-role-coverage.json');assert roles['total_reviews']==767 and roles['reviewed_roles']==7 and roles['unrelated_prior_reviews_preserved']==760
payload={}
def add(name,p):assert name not in payload;payload[name]=p.read_bytes()
sources=['tools/literature/fastp_catalog.py','tools/literature/fastp_workflow_validation.py','tools/literature/test_fastp_workflow_validation.py','tools/literature/curate_fastp_uses.py','tools/literature/fastp-use-reviews.json','tools/literature/check_fastp_review_ui.cjs','tools/literature/check_review_ui.cjs','tools/literature/render_review.py']
for name in sources:add('source/'+name,R/name)
for name in ['fastp-role-coverage.json','fastp-dispatch-shared-source-compatibility.json','fastp-use-shared-source-compatibility.json','fastp-catalog-shared-source-compatibility.json','fastp-ui-text-shared-source-compatibility.json']:add('catalog/'+name,D/name)
for row in roles['source_proof']:
 raw=gzip.decompress((R/'build/literature-review/xml'/(row['pmcid']+'.xml.gz')).read_bytes());assert sha(raw)==row['xml_sha256'];p=next(p for p in paragraphs(ET.fromstring(raw)) if p['paragraph_index']==row['paragraph_index']);assert sha(p['text'].encode())==row['paragraph_sha256'];payload['primary-source/'+row['paper_id']+'.json']=(json.dumps(dict(row,section=p['section'],paragraph=p['text']),ensure_ascii=False,indent=2)+'\n').encode()
for p in sorted((W/'role-review-1').rglob('*')):
 if p.is_file():add('curation/'+p.relative_to(W/'role-review-1').as_posix(),p)
for label in ['fastp','complete']:
 for attempt in [1,2]:
  root=W/f'browser-{label}-{attempt}'
  for p in sorted(root.rglob('*')):
   if p.is_file():add('browser/'+p.relative_to(W).as_posix(),p)
for p in sorted(W.iterdir()):
 if p.is_file() and p.suffix in ['.py','.log','.txt'] and not p.name.startswith('freeze_workflow'):add('development/'+p.name,p)
manifest={name:dict(bytes=len(raw),sha256=sha(raw)) for name,raw in sorted(payload.items())};payload['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode();target=D/'fastp-catalog-support.zip';assert not target.exists()
with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,raw in sorted(payload.items()):z.writestr(name,raw)
with zipfile.ZipFile(target) as z:
 assert len(z.namelist())==len(set(z.namelist()))==len(manifest)+1
 for name,expected in manifest.items():raw=z.read(name);assert dict(bytes=len(raw),sha256=sha(raw))==expected
record=dict(schema_version=1,status='passed-scoped-fastp-catalog-integration',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),artifact=dict(path=target.name,**pin(target)),workflow_validation=dict(path='../FASTP_WORKFLOW_DEVELOPMENT_VALIDATION.json',**pin(workflow_path)),workflow_gate_recorded_before_catalog_promotion=True,source_pins={name:pin(R/name) for name in sources},paper_roles=roles,public_original_workflows=58,counts=workflow['counts'],packaged_tests=workflow['packaged_tests'],python_tests=dict(total=623,passed=577,skipped=46,failed=0),website_structure_passed=True,browser_checks=dict(fastp=load(W/'browser-fastp-2/ui-validation.json'),complete_check_count=len(load(W/'browser-complete-2/ui-validation.json')['checks']),complete_screenshot_count=len(load(W/'browser-complete-2/ui-validation.json')['screenshots']),desktop_and_390px_dark=True,page_errors=0),prior_failures_retained=True,source_papers=250,named_tools=380,observations=2430,reviewed_uses=767,new_scoped_integrations=61,native_scopes=13,upstream_adapters=48,including_preexisting_adapters=64,named_tools_missing=259,canonical_executable_unchanged=True,whole_goal_complete=False,released_or_deployed=False)
report=D/'fastp-catalog-validation.json';assert not report.exists();report.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
manifest_file=D/'SHA256SUMS';prior=[line.split('  ',1)[1] for line in manifest_file.read_text().splitlines()];files={p.name:pin(p)['sha256'] for p in D.iterdir() if p.is_file() and p.name!='SHA256SUMS'};order=[name for name in prior if name in files]+[name for name in sorted(files) if name not in prior];manifest_file.write_text(''.join(files[name]+'  '+name+'\n' for name in order),encoding='utf-8',newline='\n')
checksum_counts={}
for manifest in sorted((R/'docs').rglob('SHA256SUMS'))+sorted((R/'src/test/resources').rglob('SHA256SUMS')):
 lines=manifest.read_text().splitlines()
 for line in lines:
  expected,name=line.split('  ',1);p=(manifest.parent/name).resolve();assert p.is_relative_to(R.resolve()) and pin(p)['sha256']==expected,str(p)
 checksum_counts[manifest.relative_to(R).as_posix()]=len(lines)
assert len(checksum_counts)==8
diff=subprocess.run(['git','diff','--check'],cwd=R,capture_output=True);assert diff.returncode==0,diff.stdout.decode(errors='replace')
final=dict(status=record['status'],workflow_source_pins=len(workflow['source_pins']),catalog_source_pins=len(sources),checksum_manifests=len(checksum_counts),checksum_files=sum(checksum_counts.values()),catalog=record['artifact'],paper_roles_reviewed=7,total_reviewed_uses=767,current_new_scoped_integrations=61,including_preexisting_adapters=64,named_tools_missing=259,public_original_workflows=58,full_input_reads=301560,independently_recomputed_report_values=388551,packaged_checks_Linux=415,packaged_checks_Windows=398,Windows_platform_aborted=17,Python=record['python_tests'],complete_browser_checks=record['browser_checks']['complete_check_count'],all_owned_processes_terminal=True,whole_goal_complete=False,released_or_deployed=False)
(W/'final-audit.json').write_text(json.dumps(final,indent=2)+'\n',encoding='utf-8',newline='\n')
checkpoint=R/'build/literature-review/fastp-runtime/current-checkpoint.json';(W/'checkpoint-before-catalog-finalization.json').write_bytes(checkpoint.read_bytes());state=load(checkpoint);state.pop('retained_original_runs',None);state.update(status=record['status'],previous_goal_turn_classification='progress',validation='docs/literature/FASTP_WORKFLOW_DEVELOPMENT_VALIDATION.json',catalog_validation='docs/literature/omics-2023-2026/fastp-catalog-validation.json',current_guide='docs/literature/FASTP_WORKFLOW.md',latest_evidence='build/literature-review/fastp-runtime/public-workflow-development-1/final-audit.json',current_changes_uncommitted=True,new_scoped_integrations=61,native_scopes=13,upstream_adapters=48,including_preexisting_adapters=64,named_tools_missing=259,typed_fastp_CLI_pending=False,scientific_output_admission_pending=False,fastp_scoped_output_admission_available=True,whole_goal_complete=False,released_or_deployed=False,source_artifact=workflow['packaged_candidate'],source_artifact_sha256=workflow['packaged_candidate_sha256'],retained_prior_development_stage_runs=189,latest_original_corpus_runs=58,retained_raw_controls='/opt/omicsmatic-fastp-public-workflow-controls-1',all_owned_processes_terminal=True,next_actions=['Select the next genuinely missing capability from the259 named-tool backlog,checking existing project source before implementation.','Continue source-paper semantic completeness review beyond the767 reviewed uses;retain the fixed250-paper cohort and exact source/provenance boundaries.','Preserve Cell Ranger exclusion,requested upstream settings,failed attempts and prominent SKIP3/FAIL2 recovery actions.'])
checkpoint.write_text(json.dumps(state,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(final))
