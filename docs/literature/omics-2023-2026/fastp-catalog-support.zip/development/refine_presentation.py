from pathlib import Path
import json,sys
R=Path('D:/projects/JLinAlg');D=R/'docs/literature/omics-2023-2026';W=R/'build/literature-review/fastp-runtime/public-workflow-development-1';sys.path.insert(0,str(R/'tools/literature'))
from curate_shapeit_uses import inverse
from catalog_source_integrity import reverse_delta,verify_source
rows=[]
path='tools/literature/render_review.py';p=R/path;before=p.read_bytes();(W/'render_review-before-readable-fastp.py.txt').write_bytes(before);after=before
anchor=b'import json\nfrom pathlib import Path\n';assert after.count(anchor)==1;after=after.replace(anchor,b'import json\nimport re\nfrom pathlib import Path\n')
anchor=b'DATA = ROOT / "docs/literature/omics-2023-2026"\n';assert after.count(anchor)==1
helper='''

def _readable_fastp(text):
    """Present only whitespace changes; keep HTML attributes and scientific values exact."""
    parts = re.split(r"(<[^>]*>)", text)
    for i in range(0, len(parts), 2):
        value = re.sub(r"\\b([A-Za-z]{2,})(?=\\d)", lambda m: m[0] if m[0].isupper() else m[0] + " ", parts[i])
        value = re.sub(r"(\\d)(GiB|MiB|RSS)\\b", r"\\1 \\2", value)
        value = re.sub(r",(?=[^\\s\\d])", ", ", value)
        value = re.sub(r";(?=\\S)", "; ", value)
        value = re.sub(r"(?<=[A-Za-z0-9])\\.(?=[A-Z])", ". ", value)
        parts[i] = value.replace("sampledRSS", "sampled RSS")
    result = "".join(parts)
    assert re.sub(r"\\s", "", result) == re.sub(r"\\s", "", text)
    return result


FASTP_WARNING = _readable_fastp(FASTP_WARNING)
FASTP_ACTIONS = _readable_fastp(FASTP_ACTIONS)
'''.encode()
after=after.replace(anchor,anchor+helper);anchor=b'        elif tool_id == "fastp":\n            tool.update(fastp_metadata(ROOT, DATA))\n';assert after.count(anchor)==1;after=after.replace(anchor,anchor+b'            for field in ("coverage_note", "implementation_scope", "validation_note"):\n                tool[field] = _readable_fastp(tool[field])\n')
row=inverse(before,after);row['path']=path;assert reverse_delta(after,row)==before;rows.append(row);p.write_bytes(after)
path='tools/literature/check_review_ui.cjs';p=R/path;before=p.read_bytes();(W/'check_review_ui-before-DOM-count-fix.cjs.txt').write_bytes(before);old=b"    assert.equal(await page.locator('#results article').count(), 47);";new=old.replace(b'47',b'48');assert before.count(old)==1;after=before.replace(old,new);row=inverse(before,after);row['path']=path;assert reverse_delta(after,row)==before;rows.append(row);p.write_bytes(after)
doc=dict(schema_version=1,status='passed-dispatch-catalog-only-source-deltas',tool_id='fastp',scope='Adds fastp-only display whitespace without changing any non-whitespace text,HTML attributes,source constants or scientific values. Corrects only the generic DOM adapter-card count from47 to48. Every previous renderer/check byte reconstructs through the exact inverse chain.',paths=rows);target=D/'fastp-ui-text-shared-source-compatibility.json';assert not target.exists();target.write_text(json.dumps(doc,indent=2)+'\n',encoding='utf-8',newline='\n')
for row in rows:verify_source(R,D,row['path'],row['before_sha256'])
p=R/'tools/literature/check_fastp_review_ui.cjs';before=p.read_bytes();(W/'check_fastp_review_ui-before-readable-format.cjs.txt').write_bytes(before);after=before.replace(b'/thread0/',b'/thread\\s?0/').replace(b'/24GiB/',b'/24\\s?GiB/').replace(b'.screenshot({path:',b".screenshot({style:'header, .skip-link { visibility:hidden !important; }',path:");assert after!=before;p.write_bytes(after)
print('presentation-only whitespace and DOM inventory count refined;exact inverses verified')
