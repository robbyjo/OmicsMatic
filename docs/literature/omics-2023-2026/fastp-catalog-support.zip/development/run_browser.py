from pathlib import Path
import functools,http.server,json,subprocess,threading
R=Path('D:/projects/JLinAlg');W=R/'build/literature-review/fastp-runtime/public-workflow-development-1';node='C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe';modules='C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules';edge='C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'
class Handler(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',8768),functools.partial(Handler,directory=str(R/'site')));thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();records=[]
try:
 for label,script in [('fastp','tools/literature/check_fastp_review_ui.cjs'),('complete','tools/literature/check_review_ui.cjs')]:
  out=W/('browser-'+label+'-2');out.mkdir();env=__import__('os').environ.copy();env['JLINALG_REVIEW_UI_OUT']=str(out);cmd=[node,script,modules,edge]
  with (out/'stdout').open('xb') as stdout,(out/'stderr').open('xb') as stderr:p=subprocess.run(cmd,cwd=R,env=env,stdout=stdout,stderr=stderr,timeout=1800)
  record=dict(label=label,command=cmd,exit_code=p.returncode);records.append(record);(out/'observed.json').write_text(json.dumps(record,indent=2)+'\n');print(label,'browser exit',p.returncode,flush=True);assert p.returncode==0,(out/'stderr').read_text()[-5000:]
 (W/'browser-summary-2.json').write_text(json.dumps(dict(status='passed-fastp-and-complete-catalog-browser-checks',runs=records),indent=2)+'\n')
finally:server.shutdown();server.server_close();thread.join()
