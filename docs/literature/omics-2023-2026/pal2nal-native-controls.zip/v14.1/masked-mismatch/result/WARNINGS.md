# PAL2NAL NATIVE — WARNINGS REQUIRE REVIEW

UNPLACED_DNA_FLANKS: p1 retains 3 leading and 3 trailing input bases outside the codon alignment; no biological role is inferred

RELAXED_V14_ANCHORS: p2 uses wildcard anchors; inspect verification counts and every mismatch

MISMATCHED_CODONS: p2 has 1 disagreeing residues; inspect every recorded cell before downstream analysis

UNPLACED_DNA_FLANKS: p2 retains 3 leading and 3 trailing input bases outside the codon alignment; no biological role is inferred

Required action: inspect WARNINGS.md, rows.ndjson, cells.tsv, triplets.tsv, capture-receipts.json and the complete raw inputs. Require a valid COMPLETED.json and pal2nal-tools --verify DIRECTORY before downstream use. This is a native v14-matching contract, not a full original PAL2NAL executable or biological-accuracy certificate. Source table10 retains TGA=stop and tables3/11/13 retain historical initiation differences. V14_NOGAP uses uppercase universal stops; SELECTED_V14_TABLE_NOGAP is an explicit native filtering departure that retains original table10. Choose pairing, matching, placement, normalization, filters and verification thresholds explicitly. Relaxed success alone does not establish correspondence; review every mismatch, wildcard, unplaced DNA flank, multiple placement and filtered triplet. SKIP3 means an unavailable edition/code/capability or empty filtered alignment: skip dependent analysis and resolve the named cause. FAIL2 means invalid input, integrity, capacity, cancellation or finalization failure: no completed result is admitted. Preserve all partials, correct the cause and retry to a NEW directory; increase -Xmx and explicit capacities when needed. No external analysis executable, download or installation is required. Paper-exact builds and omitted author settings remain unresolved; do not guess paper-exact execution. Hashes prove integrity, not authenticity. Cell Ranger remains excluded.
