from pathlib import Path
root=Path('D:/projects/JLinAlg');base=root/'build/literature-review/shapeit-runtime'
source=(base/'run_common_fit_controls_1.py').read_text()
old="report=base/'common-fit-controls-1';report.mkdir(exist_ok=False);work=private/'common-fit-controls-1';work.mkdir(exist_ok=False)"
assert old in source
source=source.replace(old,"report=base/'common-fit-controls-2';report.mkdir(exist_ok=False);work=private/'common-fit-controls-1';assert work.is_dir()\nprevious=base/'common-fit-controls-1';completed=json.loads((previous/'runs.json').read_bytes())")
needle='    invocation=[\'/usr/bin/timeout\''
replacement="""    if name.startswith('compile-'):
        prior=next(r for r in completed if r['name']==name);assert prior['exit_code']==0 and prior['command']==list(map(str,command))
        executable=Path(command[-1]);assert executable.is_file()
        for suffix in ['stdout','stderr']:(report/(name+'.'+suffix)).write_bytes((previous/(name+'.'+suffix)).read_bytes())
        runs.append(dict(prior,reused_completed_build_from=str(previous),binary_sha256=sha(executable)))
        (report/'runs.json').write_text(json.dumps(runs,indent=2)+'\\n');print(name,'REUSED COMPLETED BUILD',flush=True);return 0
    invocation=['/usr/bin/timeout'"""
assert needle in source;source=source.replace(needle,replacement)
old="path=report/(key+'.bcf');run('fixture-'+key,[generator,path,role,n,main,mode]);run('index-'+key,[prefix/'bin/bcftools','index',path]);run('wire-'+key,[wire,path])"
new="""path=report/(key+'.bcf')
    if key=='target-50-main50-base':
        path=previous/(key+'.bcf');assert path.is_file() and Path(str(path)+'.csi').is_file()
        for step in ['fixture-','index-']:
            prior=next(r for r in completed if r['name']==step+key);assert prior['exit_code']==0
            runs.append(dict(prior,reused_completed_fixture_from=str(previous)))
    else:
        run('fixture-'+key,[generator,path,role,n,main,mode]);run('index-'+key,[prefix/'bin/bcftools','index',path])
    run('wire-'+key,[wire,path,report/(key+'.wire.tsv')])"""
assert old in source;source=source.replace(old,new).replace("wire_oracle='wire-'+key+'.stdout'","wire_oracle=key+'.wire.tsv'")
source=source.replace("run('output-wire-'+name,[wire,output])","run('output-wire-'+name,[wire,output,report/(name+'.output-wire.tsv')])")
(base/'run_common_fit_controls_2.py').write_text(source,encoding='utf-8')
print('PREPARED RECOVERY; COMPLETED BUILDS AND FIXTURE ARE REUSED')
