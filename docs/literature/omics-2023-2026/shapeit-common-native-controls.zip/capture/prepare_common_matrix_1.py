from pathlib import Path
import json
root=Path('D:/projects/JLinAlg');base=root/'build/literature-review/shapeit-runtime';source=(base/'run_raw_link_matrix_2.py').read_text()
old="main_paths=['src/main/java/org/jlinalg/cli/ShapeitBcf.java','src/main/java/org/jlinalg/cli/ShapeitRawIndex.java','src/main/java/org/jlinalg/cli/ShapeitJoinedRecords.java','src/main/java/org/jlinalg/genetics/ShapeitCommonVariants.java']"
mains=['src/main/java/org/jlinalg/cli/'+name+'.java' for name in ['ShapeitBcf','ShapeitRawIndex','ShapeitJoinedRecords','ShapeitCommonCalls','ShapeitCommonData','ShapeitCommonOutputs']]+['src/main/java/org/jlinalg/genetics/'+name+'.java' for name in ['ShapeitCommonVariants','ShapeitGeneticMap','ShapeitGenotypes']]
assert old in source;source=source.replace(old,'main_paths='+json.dumps(mains))
old="test_paths=['src/test/java/org/jlinalg/cli/ShapeitBcfTest.java','src/test/java/org/jlinalg/cli/ShapeitRawIndexTest.java','src/test/java/org/jlinalg/cli/ShapeitJoinedRecordsTest.java','src/test/java/org/jlinalg/genetics/ShapeitCommonVariantsTest.java','src/main/java/org/jlinalg/cli/SimpleJson.java']"
tests=['src/test/java/org/jlinalg/cli/'+name+'Test.java' for name in ['ShapeitBcf','ShapeitRawIndex','ShapeitJoinedRecords','ShapeitCommonCalls','ShapeitCommonData']]+['src/test/java/org/jlinalg/genetics/'+name+'Test.java' for name in ['ShapeitCommonVariants','ShapeitGeneticMap','ShapeitGenotypes']]+['src/main/java/org/jlinalg/cli/SimpleJson.java']
assert old in source;source=source.replace(old,'test_paths='+json.dumps(tests))
old='"org.jlinalg.cli.ShapeitBcf","org.jlinalg.cli.ShapeitRawIndex","org.jlinalg.cli.ShapeitJoinedRecords","org.jlinalg.genetics.ShapeitCommonVariants"'
new=','.join(json.dumps(p.removeprefix('src/main/java/').removesuffix('.java').replace('/','.')) for p in mains)
assert old in source;source=source.replace(old,new)
old='selectClass("org.jlinalg.cli.ShapeitBcfTest"),selectClass("org.jlinalg.cli.ShapeitRawIndexTest"),selectClass("org.jlinalg.cli.ShapeitJoinedRecordsTest"),selectClass("org.jlinalg.genetics.ShapeitCommonVariantsTest")'
new=','.join('selectClass('+json.dumps(p.removeprefix('src/test/java/').removesuffix('.java').replace('/','.'))+')' for p in tests if p.startswith('src/test/'))
assert old in source;source=source.replace(old,new)
source=source.replace('raw-link-native-matrix-2','common-data-native-matrix-1').replace('shapeit-native-joined.jar','shapeit-native-common-data.jar').replace('RawLinkJUnit','CommonFitJUnit').replace('!=171','!=349').replace('tests_per_JVM=171','tests_per_JVM=349').replace('passed-native-raw-linkage-matrix','passed-native-common-data-matrix').replace('RAW LINKAGE MATRIX PASSED','COMMON DATA MATRIX PASSED')
(base/'run_common_matrix_1.py').write_text(source,encoding='utf-8');print('PREPARED THREE-JVM COMMON DATA MATRIX')
