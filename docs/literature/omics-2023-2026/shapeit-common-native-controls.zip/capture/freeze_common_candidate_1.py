from pathlib import Path
import hashlib,json,shutil,subprocess,sys,zipfile
root=Path('D:/projects/JLinAlg');base=root/'build/literature-review/shapeit-runtime';matrix=base/'common-data-native-matrix-1';data=base/'common-data-proof-candidate-1';data.mkdir(exist_ok=False)
sys.path.insert(0,str(root/'tools/literature'));import shapeit_common_validation as validation
sha=lambda raw:hashlib.sha256(raw).hexdigest();observed=json.loads((matrix/'observed.json').read_bytes())
assert observed['status']=='passed-native-common-data-matrix' and observed['tests_per_JVM']==349
for path,digest in observed['source_sha256'].items():assert sha((root/path).read_bytes())==digest,path
shutil.copytree(base/'raw-link-native-matrix-2/dependency-sources',matrix/'dependency-sources')
versions={}
for profile,command,major in [
    ('windows-java21',['C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe','--version'],21),
    ('windows-java25',['C:/Program Files/Common Files/Oracle/Java/javapath/java.exe','--version'],25),
    ('linux-java21',['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/java','--version'],21)]:
    result=subprocess.run(command,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=subprocess.CREATE_NO_WINDOW,timeout=30)
    text=result.stdout.decode()+result.stderr.decode();assert result.returncode==0 and (' '+str(major)+'.' in text or ' '+str(major)+' ' in text),(profile,text)
    versions[profile]=dict(major=major,command=command,output=text,exit_code=0)
members={}
def add(name,raw):assert name not in members;members[name]=raw
source_pins={}
for path in sorted(validation.SCIENCE):raw=(root/path).read_bytes();source_pins[path]=sha(raw);add('source/'+path,raw)
for path in sorted(matrix.rglob('*')):
    if not path.is_file():continue
    relative=path.relative_to(matrix).as_posix()
    if relative.startswith(('javadoc/','main-classes/')) or relative=='running.json':continue
    add('matrix/'+relative,path.read_bytes())
add('matrix/runtime-versions.json',(json.dumps(versions,indent=2)+'\n').encode())
for name in ['freeze_common_candidate_1.py','run_common_matrix_1.py','prepare_common_matrix_1.py','run_common_fit_controls_1.py','run_common_fit_controls_2.py','prepare_common_fit_recovery_2.py','analyze_common_fit_1.py']:
    add('capture/'+name,(base/name).read_bytes())
add('capture/common-data-tests-1.log',(base/'common-data-tests-1.log').read_bytes())
add('capture/common-data-tests-2.log',(base/'common-data-tests-2.log').read_bytes())
add('README.txt',b'Native common-stage ordinary GT preparation and complete actual fitting-output audits for SHAPEIT5 c34d only. Ten original fits and two expected reference failures are retained, alongside the earlier failed argument invocation and test-parser correction history. Source reference-assisted output AN includes target plus reference haplotypes although GT and AC contain targets only. Preserve original output and use independently verified target allele counts. Runtime/process admission, binary/pedigree/haploid/rare/ligation/posterior contracts and phase accuracy remain unvalidated. No public phasing workflow or new completed integration is claimed.\n')
add('SHA256SUMS',''.join(sha(raw)+'  '+name+'\n' for name,raw in sorted(members.items())).encode())
artifact=data/'shapeit-common-native-controls.zip'
with artifact.open('xb') as stream:
    with zipfile.ZipFile(stream,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for name,raw in sorted(members.items()):
            info=zipfile.ZipInfo(name,(1980,1,1,0,0,0));info.external_attr=0o100644<<16;info.compress_type=zipfile.ZIP_DEFLATED;archive.writestr(info,raw)
record=dict(status='validated-native-SHAPEIT-common-data-and-output-contracts',
    source_sha256=source_pins,artifact=dict(path=artifact.name,sha256=sha(artifact.read_bytes()),bytes=artifact.stat().st_size),
    original_fixture_sha256='81523e3096bf076dea54138f56db752fb51b463e4b9810ee47ba8756fa35bff4',
    native_candidate_sha256=observed['candidate_sha256'],native_tests_per_JVM=349,JVM_profiles=3,heap='128m',
    original_complete_fits=10,expected_original_failures=2,selected_rows=1257,target_cells=47770,reference_haplotype_cells=30160,
    applied_scaffold_constraints=573,source_AN_includes_reference_rows=377,
    public_phasing_adapter_available=False,managed_runtime_admission_certified=False,binary_genotype_payloads_validated=False,haploid_pedigree_contracts_validated=False,phase_accuracy_certified=False,
    dependency_source_notices=json.loads((matrix/'dependency-sources/provenance.json').read_bytes()),
    scope='Complete native ordinary-GT reader preparation, original join/selection/map integration and actual original fitting-output audits for source c34d only, before haploid and pedigree processing. This is not a managed runtime, public phasing command, binary decoder or phase-accuracy benchmark.',
    warnings=['Reference-assisted original AN includes reference haplotypes while output GT and AC contain target samples only. The verified target-allele-counts.tsv uses actual target slots; original output remains unchanged.','Source scaffold counters and successful exit do not prove any scaffold constraint was applied. Inspect the complete applied-constraint census.','Literal-zero missingness, phase-marked missing values and vector-end padding retain original-reader departures and require separate study admission.'],
    required_action='Skip dependent phasing until protected runtime/process admission and the required study-specific contracts exist. Preserve original inputs and outputs. On integrity, census, dosage, scaffold, source metadata or capacity failure, retain failed state, correct the cause and use fresh directories with sufficient complete-population capacity. Do not silently retag original reference-assisted AN or treat it as target AN.')
(data/'shapeit-common-validation.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
validation.verify(root,data)
print(json.dumps(dict(artifact_sha256=record['artifact']['sha256'],artifact_bytes=artifact.stat().st_size,members=len(members),decoded_bytes=sum(map(len,members.values()))),indent=2))
