from pathlib import Path
import json
base=Path('D:/projects/JLinAlg/build/literature-review/shapeit-runtime/common-fit-controls-2');record=json.loads((base/'observed.json').read_bytes());reports=[]
for case in record['cases']:
    if not case['complete']:continue
    lines=[line.split('\t') for line in (base/case['original_initial']).read_text().splitlines()];header=next(f for f in lines if f[0]=='H');target,reference,variants=map(int,header[1:])
    sites=[f for f in lines if f[0]=='R'];states={(int(f[1]),int(f[2])):int(f[3]) for f in lines if f[0]=='G'}
    output=[line.split('\t') for line in (base/('output-query-'+case['name']+'.stdout')).read_text().splitlines()]
    assert len(output)==len(sites)==variants and len(states)==variants*target
    checked=constraints=matching=flipped=0;orientations={};an=set();physical=set()
    for v,(site,row) in enumerate(zip(sites,output)):
        assert site[2:7]==row[:5] and len(row)==7+target
        dosage=0
        for i,gt in enumerate(row[7:]):
            values=gt.split('|');assert len(values)==2 and all(v in ['0','1'] for v in values)
            a,b=map(int,values);dosage+=a+b;state=states[v,i]
            if state&3!=1:assert a+b==((state>>2)&1)+((state>>3)&1);checked+=1
            if state&3==3:
                constraints+=1;expected=((state>>2)&1,(state>>3)&1)
                if (a,b)==expected:matching+=1;orientations.setdefault(i,set()).add(0)
                else:assert (b,a)==expected;flipped+=1;orientations.setdefault(i,set()).add(1)
        assert int(row[5])==dosage
        assert int(row[6])==2*(target+reference)
        an.add(int(row[6]));physical.add(2*target)
    counters=next(f for f in lines if f[0]=='C');assert constraints==int(counters[5])
    reports.append(dict(name=case['name'],target=target,reference=reference,variants=variants,observed_dosage_cells_checked=checked,scaffold_constraints=constraints,
                        scaffold_order_matches=matching,scaffold_order_swaps=flipped,per_sample_scaffold_orientations={str(k):sorted(v) for k,v in orientations.items()},
                        output_declared_AN=sorted(an),physical_target_allele_slots=sorted(physical)))
result=dict(status='passed-complete-original-common-fit-output-checks',cases=reports,scope='Independent source-reader nibble/dosage, selected-site/sample order, output AC/AN and scaffold-orientation observations on complete original runs; not a phase-accuracy benchmark or admitted runtime.')
(base/'output-observations.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps([{k:r[k] for k in ['name','variants','scaffold_constraints','scaffold_order_matches','scaffold_order_swaps','output_declared_AN','physical_target_allele_slots']} for r in reports],indent=2))
