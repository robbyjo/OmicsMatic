from pathlib import Path
import hashlib,json,os,subprocess,time,zipfile
root=Path('/mnt/d/projects/JLinAlg');base=root/'build/literature-review/shapeit-runtime';private=Path('/opt/omicsmatic-shapeit-dev-1');prefix=private/'.pixi/envs/default'
report=base/'common-fit-controls-1';report.mkdir(exist_ok=False);work=private/'common-fit-controls-1';work.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();runs=[]
env=dict(PATH=str(prefix/'bin')+':/usr/bin:/bin',HOME=str(work),TMPDIR=str(work),LC_ALL='C',LANG='C',LD_LIBRARY_PATH=str(prefix/'lib'),OMP_NUM_THREADS='1')
def run(name,command,expected=(0,)):
    invocation=['/usr/bin/timeout','--kill-after=5s','180s','/usr/bin/prlimit','--as=2147483648','--cpu=120','--fsize=134217728','--nofile=256','--core=0','--',*map(str,command)]
    start=time.monotonic()
    with (report/(name+'.stdout')).open('xb') as stdout,(report/(name+'.stderr')).open('xb') as stderr:
        child=subprocess.Popen(invocation,cwd=work,env=env,stdout=stdout,stderr=stderr)
        (report/'running.json').write_text(json.dumps(dict(controller_pid=os.getpid(),child_pid=child.pid,phase=name),indent=2)+'\n');code=child.wait()
    runs.append(dict(name=name,command=list(map(str,command)),bounded_invocation=invocation,exit_code=code,seconds=time.monotonic()-start));(report/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(name,code,flush=True)
    if expected is not None and code not in expected:
        print((report/(name+'.stdout')).read_text(errors='replace')[-4000:],flush=True);print((report/(name+'.stderr')).read_text(errors='replace')[-4000:],flush=True);raise SystemExit(code or 1)
    return code
source=private/'source5-attempt-1';closure=root/'src/test/resources/org/jlinalg/genetics/shapeit-reference/initial-reader.zip';sources={}
with zipfile.ZipFile(closure) as z:
    for name in z.namelist():
        if not name.startswith('upstream/5-c34d/'):continue
        relative=name.removeprefix('upstream/5-c34d/');path=source/relative;raw=os.readlink(path).encode() if path.is_symlink() else path.read_bytes();assert raw==z.read(name),relative;sources[relative]=hashlib.sha256(raw).hexdigest()
assert len(sources)>200
program=source/'phase_common/bin/phase_common';assert sha(program)=='74d6f951f6103e709ee3e754397a86b6b2cb4e0ab0bf543c1378cb4b7d894689'
compiler=prefix/'bin/x86_64-conda-linux-gnu-g++';includes=['-I'+str(source/'phase_common/src'),'-I'+str(prefix/'include')];link=['-L'+str(prefix/'lib'),'-Wl,-rpath,'+str(prefix/'lib')]
generator=work/'make-fixture';data=work/'original-common-data';wire=work/'original-bcf-wire';joined=private/'joined-wire-controls-2/joined-wire'
run('compile-fixture',[compiler,'-std=c++20','-O2',*includes,*link,root/'tools/literature/shapeit-reference/MakeCommonFitFixture.cpp','-lhts','-o',generator])
objects=sorted(p for p in (source/'phase_common/obj').glob('*.o') if p.name!='main.o')
run('compile-data',[compiler,'-std=c++20','-O2',*includes,*link,root/'tools/literature/shapeit-reference/CommonDataProtocol.cpp',*objects,'-lhts','-lboost_iostreams','-lboost_program_options','-lz','-lbz2','-lm','-lpthread','-llzma','-lcurl','-lcrypto','-ldeflate','-o',data])
run('compile-wire',[compiler,'-std=c++20','-O2',*includes,*link,root/'tools/literature/shapeit-reference/BcfWireProtocol.cpp','-lhts','-o',wire])
map_file=report/'complete.map.tsv';map_file.write_text('position rate cM\n0 1 0\n100000 1 0.1\n200000 1 0.2\n')
fixtures={}
def fixture(role,n,main,mode):
    key=f'{role}-{n}-main{main}-{mode}'
    if key in fixtures:return Path(fixtures[key]['path'])
    path=report/(key+'.bcf');run('fixture-'+key,[generator,path,role,n,main,mode]);run('index-'+key,[prefix/'bin/bcftools','index',path]);run('wire-'+key,[wire,path])
    fixtures[key]=dict(path=str(path),role=role,samples=n,main_samples=main,mode=mode,sha256=sha(path),wire_oracle='wire-'+key+'.stdout');return path
definitions=[
    ('cohort-default',50,False,False,'base',False,False,'default'),
    ('cohort-map',50,False,False,'base',True,False,'default'),
    ('reference-default',10,True,False,'base',False,False,'default'),
    ('scaffold-default',50,False,True,'base',False,False,'default'),
    ('reference-scaffold-map',10,True,True,'base',True,False,'default'),
    ('cohort-filters',50,False,False,'base',False,True,'0.1'),
    ('cohort-duplicates',50,False,False,'duplicates',False,False,'default'),
    ('reference-duplicates',10,True,False,'duplicates',False,False,'default'),
    ('cohort-wire-departures',50,False,False,'wire-departures',False,False,'default'),
    ('reference-missing',10,True,False,'missing-reference',False,False,'default'),
    ('reference-unphased',10,True,False,'unphased-reference',False,False,'default'),
    ('scaffold-unused',50,False,True,'unused-scaffold',False,False,'default'),
]
cases=[]
for name,n,reference,scaffold,mode,mapped,snp,maf in definitions:
    target=fixture('target',n,n,mode);ref=fixture('reference',40,n,mode) if reference else None;scaf=fixture('scaffold',5,n,mode) if scaffold else None
    inputs=[target]+([ref] if ref else [])+([scaf] if scaf else [])
    expected_failure=mode in ['missing-reference','unphased-reference']
    join=report/(name+'.join.tsv');run('join-'+name,[joined,'20',join,*inputs])
    initial=report/(name+'.initial.tsv');initial_code=run('initial-'+name,[data,target,initial,'20',ref or '-',scaf or '-',int(snp),maf],None)
    assert (initial_code!=0)==expected_failure
    output=report/(name+'.phased.bcf');command=[program,'--input',target,'--region','20','--output',output,'--seed','15052011']
    if ref:command+=['--reference',ref]
    if scaf:command+=['--scaffold',scaf]
    if mapped:command+=['--map',map_file]
    if snp:command+=['--filter-snp']
    if maf!='default':command+=['--filter-maf',maf]
    code=run('fit-'+name,command,None);assert (code!=0)==expected_failure
    if code==0:
        assert output.is_file();run('output-wire-'+name,[wire,output]);run('output-query-'+name,[prefix/'bin/bcftools','query','-f','%CHROM\t%POS\t%ID\t%REF\t%ALT\t%INFO/AC\t%INFO/AN[\t%GT]\n',output])
    cases.append(dict(name=name,target=str(target),reference=str(ref) if ref else None,scaffold=str(scaf) if scaf else None,region='20',map=str(map_file) if mapped else None,snp=snp,maf=maf,
                      original_join=join.name,original_initial=initial.name if initial.exists() else None,initial_exit_code=initial_code,fit_exit_code=code,complete=code==0,
                      output=output.name if output.exists() else None,output_sha256=sha(output) if output.exists() else None,expected_source_failure=mode if expected_failure else None))
record=dict(status='captured-original-common-fitting-controls',source_commit='c34d4db3e99a2f7e23deb727671ae260901a5886',program_sha256=sha(program),
            source_sha256=sources,protocol_sha256={name:sha(root/'tools/literature/shapeit-reference'/name) for name in ['MakeCommonFitFixture.cpp','CommonDataProtocol.cpp','BcfWireProtocol.cpp','JoinedWireProtocol.cpp']},
            htslib_library_sha256=sha(prefix/'lib/libhts.so'),fixtures=fixtures,cases=cases,public_phasing_adapter_available=False,runtime_admission_certified=False)
(report/'observed.json').write_text(json.dumps(record,indent=2)+'\n');print('ORIGINAL COMMON FIT CONTROLS CAPTURED',len(cases),sum(c['complete'] for c in cases),flush=True)
