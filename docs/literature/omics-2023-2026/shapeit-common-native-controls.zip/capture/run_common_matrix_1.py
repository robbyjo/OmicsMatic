from pathlib import Path
import hashlib,json,os,shutil,subprocess,zipfile
root=Path('D:/projects/JLinAlg');out=root/'build/literature-review/shapeit-runtime/common-data-native-matrix-1';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cache=Path('C:/Users/User/.gradle/caches/modules-2/files-2.1');lib=out/'lib';lib.mkdir();deps=[]
coordinates=[('org.junit.jupiter','junit-jupiter-api','5.13.4'),('org.junit.jupiter','junit-jupiter-engine','5.13.4'),('org.junit.jupiter','junit-jupiter-params','5.13.4'),('org.junit.platform','junit-platform-commons','1.13.4'),('org.junit.platform','junit-platform-engine','1.13.4'),('org.junit.platform','junit-platform-launcher','1.13.4'),('org.opentest4j','opentest4j','1.3.0'),('org.apiguardian','apiguardian-api','1.1.2'),('com.github.samtools','htsjdk','5.0.0')]
for group,name,version in coordinates:
    files=list((cache/group/name/version).glob('*/*.jar'));assert len(files)==1;target=lib/files[0].name;shutil.copyfile(files[0],target);deps.append(target)
main_paths=["src/main/java/org/jlinalg/cli/ShapeitBcf.java", "src/main/java/org/jlinalg/cli/ShapeitRawIndex.java", "src/main/java/org/jlinalg/cli/ShapeitJoinedRecords.java", "src/main/java/org/jlinalg/cli/ShapeitCommonCalls.java", "src/main/java/org/jlinalg/cli/ShapeitCommonData.java", "src/main/java/org/jlinalg/cli/ShapeitCommonOutputs.java", "src/main/java/org/jlinalg/genetics/ShapeitCommonVariants.java", "src/main/java/org/jlinalg/genetics/ShapeitGeneticMap.java", "src/main/java/org/jlinalg/genetics/ShapeitGenotypes.java"]
test_paths=["src/test/java/org/jlinalg/cli/ShapeitBcfTest.java", "src/test/java/org/jlinalg/cli/ShapeitRawIndexTest.java", "src/test/java/org/jlinalg/cli/ShapeitJoinedRecordsTest.java", "src/test/java/org/jlinalg/cli/ShapeitCommonCallsTest.java", "src/test/java/org/jlinalg/cli/ShapeitCommonDataTest.java", "src/test/java/org/jlinalg/genetics/ShapeitCommonVariantsTest.java", "src/test/java/org/jlinalg/genetics/ShapeitGeneticMapTest.java", "src/test/java/org/jlinalg/genetics/ShapeitGenotypesTest.java", "src/main/java/org/jlinalg/cli/SimpleJson.java"]
source_pins={p:sha(root/p) for p in main_paths+test_paths};jdk=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin');classes=out/'main-classes';classes.mkdir();tests=out/'test-classes';tests.mkdir();runs=[]
def run(name,command):
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
        child=subprocess.Popen(list(map(str,command)),cwd=root,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
        (out/'running.json').write_text(json.dumps(dict(pid=child.pid,phase=name),indent=2)+'\n');code=child.wait()
    runs.append(dict(name=name,command=list(map(str,command)),exit_code=code));(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(name,code,flush=True)
    if code:print((out/(name+'.stdout')).read_text(errors='replace')[-10000:]);print((out/(name+'.stderr')).read_text(errors='replace')[-10000:]);raise SystemExit(code)
cp=';'.join(map(str,deps));run('javac-main',[jdk/'javac.exe','--release','17','-Xlint:all','-Werror','-cp',cp,'-d',classes,*[root/p for p in main_paths]])
candidate=out/'shapeit-native-common-data.jar'
with zipfile.ZipFile(candidate,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as jar:
    for p in sorted(classes.rglob('*.class')):
        raw=p.read_bytes();assert int.from_bytes(raw[6:8],'big')==61
        info=zipfile.ZipInfo(p.relative_to(classes).as_posix(),(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;jar.writestr(info,raw)
    for name in ['SHAPEIT4-MIT.txt','SHAPEIT5-MIT.txt','SHAPEIT5-XCF-MIT.txt']:
        info=zipfile.ZipInfo('META-INF/licenses/'+name,(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;jar.writestr(info,(root/'LICENSES'/name).read_bytes())
launcher=out/'CommonFitJUnit.java';launcher.write_text('''import org.junit.platform.launcher.core.*;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;
public class CommonFitJUnit {
 public static void main(String[] args) throws Exception {
  for(String name:new String[]{"org.jlinalg.cli.ShapeitBcf","org.jlinalg.cli.ShapeitRawIndex","org.jlinalg.cli.ShapeitJoinedRecords","org.jlinalg.cli.ShapeitCommonCalls","org.jlinalg.cli.ShapeitCommonData","org.jlinalg.cli.ShapeitCommonOutputs","org.jlinalg.genetics.ShapeitCommonVariants","org.jlinalg.genetics.ShapeitGeneticMap","org.jlinalg.genetics.ShapeitGenotypes"})
   if(!Class.forName(name).getProtectionDomain().getCodeSource().getLocation().toURI().equals(new java.io.File(args[0]).toURI()))throw new AssertionError("Wrong candidate loaded: "+name);
  var listener=new SummaryGeneratingListener();var request=LauncherDiscoveryRequestBuilder.request().selectors(selectClass("org.jlinalg.cli.ShapeitBcfTest"),selectClass("org.jlinalg.cli.ShapeitRawIndexTest"),selectClass("org.jlinalg.cli.ShapeitJoinedRecordsTest"),selectClass("org.jlinalg.cli.ShapeitCommonCallsTest"),selectClass("org.jlinalg.cli.ShapeitCommonDataTest"),selectClass("org.jlinalg.genetics.ShapeitCommonVariantsTest"),selectClass("org.jlinalg.genetics.ShapeitGeneticMapTest"),selectClass("org.jlinalg.genetics.ShapeitGenotypesTest")).build();
  var launcher=LauncherFactory.create();launcher.registerTestExecutionListeners(listener);launcher.execute(request);var summary=listener.getSummary();summary.printTo(new java.io.PrintWriter(System.out));summary.printFailuresTo(new java.io.PrintWriter(System.out));
  if(summary.getTestsFoundCount()!=349||summary.getTestsSucceededCount()!=349||summary.getTestsSkippedCount()!=0||summary.getTestsFailedCount()!=0||summary.getContainersFailedCount()!=0)throw new AssertionError("Incomplete raw linkage controls");
 }
}
''',encoding='utf-8')
run('javac-tests',[jdk/'javac.exe','--release','17','-Xlint:all','-Werror','-cp',';'.join(map(str,[candidate,*deps])),'-d',tests,*[root/p for p in test_paths],launcher])
run('javadoc',[jdk/'javadoc.exe','--release','17','-Xdoclint:all','-Werror','-quiet','-classpath',cp,'-d',out/'javadoc',*[root/p for p in main_paths]])
runtime=[candidate,tests,root/'src/test/resources',*deps]
for name,java in [('windows-java21',jdk/'java.exe'),('windows-java25',Path('C:/Program Files/Common Files/Oracle/Java/javapath/java.exe'))]:
    run(name,[java,'-Xmx128m','-cp',';'.join(map(str,runtime)),'CommonFitJUnit',candidate])
def peer(path):return '/mnt/'+str(path)[0].lower()+str(path)[2:].replace('\\','/')
run('linux-java21',['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/java','-Xmx128m','-cp',':'.join(peer(p) for p in runtime),'CommonFitJUnit',peer(candidate)])
assert source_pins=={p:sha(root/p) for p in source_pins}
record=dict(status='passed-native-common-data-matrix',candidate_sha256=sha(candidate),tests_per_JVM=349,JVM_profiles=3,skipped=0,heap='128m',source_sha256=source_pins,dependency_sha256={p.name:sha(p) for p in deps},runs=runs,public_phasing_adapter_available=False)
(out/'observed.json').write_text(json.dumps(record,indent=2)+'\n');print('COMMON DATA MATRIX PASSED',flush=True)
