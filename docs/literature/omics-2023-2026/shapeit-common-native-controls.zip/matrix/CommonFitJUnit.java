import org.junit.platform.launcher.core.*;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;
public class CommonFitJUnit {
 public static void main(String[] args) throws Exception {
  for(String name:new String[]{"org.jlinalg.cli.ShapeitBcf","org.jlinalg.cli.ShapeitRawIndex","org.jlinalg.cli.ShapeitJoinedRecords","org.jlinalg.cli.ShapeitCommonCalls","org.jlinalg.cli.ShapeitCommonData","org.jlinalg.cli.ShapeitCommonOutputs","org.jlinalg.genetics.ShapeitCommonVariants","org.jlinalg.genetics.ShapeitGeneticMap","org.jlinalg.genetics.ShapeitGenotypes"})
   if(!Class.forName(name).getProtectionDomain().getCodeSource().getLocation().toURI().equals(new java.io.File(args[0]).toURI()))throw new AssertionError("Wrong candidate loaded: "+name);
  var listener=new SummaryGeneratingListener();var request=LauncherDiscoveryRequestBuilder.request().selectors(selectClass("org.jlinalg.cli.ShapeitBcfTest"),selectClass("org.jlinalg.cli.ShapeitRawIndexTest"),selectClass("org.jlinalg.cli.ShapeitJoinedRecordsTest"),selectClass("org.jlinalg.cli.ShapeitCommonCallsTest"),selectClass("org.jlinalg.cli.ShapeitCommonDataTest"),selectClass("org.jlinalg.genetics.ShapeitCommonVariantsTest"),selectClass("org.jlinalg.genetics.ShapeitGeneticMapTest"),selectClass("org.jlinalg.genetics.ShapeitGenotypesTest")).build();
  var launcher=LauncherFactory.create();launcher.registerTestExecutionListeners(listener);launcher.execute(request);var summary=listener.getSummary();summary.printTo(new java.io.PrintWriter(System.out));summary.printFailuresTo(new java.io.PrintWriter(System.out));
  if(summary.getTestsFoundCount()!=349||summary.getTestsSucceededCount()!=349||summary.getTestsSkippedCount()!=0||summary.getTestsFailedCount()!=0||summary.getContainersFailedCount()!=0)throw new AssertionError("Incomplete raw linkage controls");
 }
}
