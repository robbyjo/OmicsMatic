# Shapeit FAIL2 interrupted phasing

shutdown-owned-processes-terminal

Required action: keep the provisional directory, shutdown ledger and logs. Inspect any recorded nonterminal owned process before rerunning to a NEW output. Never admit interrupted results.
