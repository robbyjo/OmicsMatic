# Shapeit process FAIL2 failed

java.io.IOException: Original SHAPEIT launcher exited with live owned workers; retain logs and do not admit a result

Required action: preserve this directory, stdout, stderr and process ledger. Admit results only after the complete scientific output audit. Correct any failure and rerun to a new output directory.
