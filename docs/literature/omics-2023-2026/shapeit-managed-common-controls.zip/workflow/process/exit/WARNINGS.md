# Shapeit process FAIL2 failed

java.io.IOException: Original Shapeit process failed, exit 7

Required action: preserve this directory, stdout, stderr and process ledger. Admit results only after the complete scientific output audit. Correct any failure and rerun to a new output directory.
