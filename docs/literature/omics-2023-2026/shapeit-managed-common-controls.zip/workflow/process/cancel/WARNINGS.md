# Shapeit process FAIL2 failed

java.io.IOException: Shapeit process cancelled or invalid; no result is admitted

Required action: preserve this directory, stdout, stderr and process ledger. Admit results only after the complete scientific output audit. Correct any failure and rerun to a new output directory.
