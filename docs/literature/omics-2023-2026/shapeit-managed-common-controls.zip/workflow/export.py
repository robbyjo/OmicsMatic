from pathlib import Path
import hashlib,json,shutil
root=Path('/mnt/d/projects/JLinAlg');report=root/'build/literature-review/shapeit-runtime/owned-workflow-evidence-4';sources={
 'public-cli':'/opt/omicsmatic-shapeit-dev-1/owned-public-cli-controls-3',
 'policies':'/opt/omicsmatic-shapeit-dev-1/owned-common-policy-controls-3',
 'process':'/opt/omicsmatic-shapeit-dev-1/owned-process-controls-3',
 'shutdown':'/opt/omicsmatic-shapeit-dev-1/owned-shutdown-control-1',
 'runtime-tamper':'/opt/omicsmatic-shapeit-dev-1/runtime-tamper-controls-1',
 'transport':'/opt/omicsmatic-shapeit-dev-1/owned-public-transport-controls-2'}
records={};link_records=[]
for name,original in sources.items():
 source=Path(original);dest=report/name;dest.mkdir();total=0;count=0
 for path in sorted(source.rglob('*')):
  relative=path.relative_to(source)
  if name=='runtime-tamper' and relative.parts[0]=='home':continue
  if name=='policies' and relative.as_posix()=='patch-counts':continue
  if path.is_symlink():
   assert name=='process' and relative.as_posix()=='symlink/linked' and str(path.readlink())=='/tmp'
   link_records.append(dict(group=name,path=relative.as_posix(),literal_target=str(path.readlink()),materialized=False));continue
  assert path.is_file() or path.is_dir(),str(path)
  target=dest/relative
  if path.is_dir():target.mkdir(exist_ok=False)
  else:
   total+=path.stat().st_size;count+=1;assert total<67108864;shutil.copyfile(path,target)
 records[name]=dict(files=count,bytes=total,source=original)
runtime=Path('/opt/omicsmatic-shapeit-dev-1/managed-common-runtime-2');shutil.copyfile(runtime/'.omicsmatic-shapeit.json',report/'installed-runtime-marker.json')
initial=root/'build/literature-review/shapeit-runtime/runtime-adoption-2/install-report.json';assert (runtime/'.omicsmatic-shapeit.json').read_bytes()==initial.read_bytes()
(report/'retained-negative-fixture-links.json').write_text(json.dumps(link_records,indent=2)+'\n')
native=json.loads((report/'public-cli/cohort-default/analysis/analysis.json').read_bytes());assert native['runtime']['marker']['sha256']==hashlib.sha256(initial.read_bytes()).hexdigest()
(report/'export-observed.json').write_text(json.dumps(dict(status='exported-complete-owned-workflow-controls',sources=records,initial_runtime_marker_unchanged=True,scientific_runtime_binaries_and_libraries_not_redistributed=True),indent=2)+'\n');print(json.dumps(records))
