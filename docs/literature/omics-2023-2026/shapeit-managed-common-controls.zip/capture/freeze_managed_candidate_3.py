from pathlib import Path
import hashlib,io,json,shutil,subprocess,sys,zipfile
root=Path('D:/projects/JLinAlg');base=root/'build/literature-review/shapeit-runtime';matrix=base/'owned-common-native-matrix-4';data=base/'managed-proof-candidate-3';data.mkdir(exist_ok=False)
sys.path.insert(0,str(root/'tools/literature'));import shapeit_managed_validation as validation
sha=lambda raw:hashlib.sha256(raw).hexdigest();observed=json.loads((matrix/'observed.json').read_bytes());assert observed['tests_per_JVM']==380
for path,expected in observed['source_sha256'].items():assert sha((root/path).read_bytes())==expected,path
if not (matrix/'dependency-sources').exists():shutil.copytree(base/'raw-link-native-matrix-2/dependency-sources',matrix/'dependency-sources')
for p in (base/'raw-link-native-matrix-2/dependency-sources').iterdir():assert p.read_bytes()==(matrix/'dependency-sources'/p.name).read_bytes()
versions={}
for profile,command,major in [('windows-java21',['C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe','--version'],21),('windows-java25',['C:/Program Files/Common Files/Oracle/Java/javapath/java.exe','--version'],25),('linux-java21',['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/java','--version'],21)]:
 c=subprocess.run(command,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=subprocess.CREATE_NO_WINDOW,timeout=30);text=c.stdout.decode()+c.stderr.decode();assert c.returncode==0 and (' '+str(major)+'.' in text or ' '+str(major)+' ' in text);versions[profile]=dict(major=major,command=command,output=text,exit_code=0)
members={}
def add(name,raw):assert name not in members;members[name]=raw
pins={}
for path in sorted(validation.SCIENCE):raw=(root/path).read_bytes();pins[path]=sha(raw);add('source/'+path,raw)
for path in sorted(matrix.rglob('*')):
 if not path.is_file():continue
 relative=path.relative_to(matrix).as_posix()
 if relative.startswith(('javadoc/','main-classes/')) or relative=='running.json':continue
 add('matrix/'+relative,path.read_bytes())
add('matrix/runtime-versions.json',(json.dumps(versions,indent=2)+'\n').encode())
for path in sorted((base/'owned-workflow-evidence-4').rglob('*')):
 if path.is_file():add('workflow/'+path.relative_to(base/'owned-workflow-evidence-4').as_posix(),path.read_bytes())
for name,path in {
 'shutdown-observed.json':base/'owned-shutdown-1/observed.json',
 'prior-process-candidate.jar':base/'owned-process-native-3/shapeit-owned-runtime.jar',
 'ShapeitOwnedProcessControls.java':base/'ShapeitOwnedProcessControls.java',
 'ShapeitShutdownChild.java':base/'ShapeitShutdownChild.java',
 'ShapeitRuntimeTamperControls.java':base/'ShapeitRuntimeTamperControls.java',
 'PatchCommonCounts.cpp':base/'PatchCommonCounts.cpp',
 'run_public_common_cli_3.py':base/'run_public_common_cli_3.py',
 'run_owned_matrix_4.py':base/'run_owned_matrix_4.py',
 'public-controls.py':base/'owned-public-cli-3/controls.py',
 'policy-controls.py':base/'owned-common-policy-controls-3/controls.py',
 'original-fixture-generation-controls.py':base/'owned-common-policy-controls-1/controls.py',
 'original-fixture-generation-observed.json':base/'owned-workflow-evidence-2/policies/observed.json',
 'transport-controls.py':base/'owned-public-transport-2/controls.py',
 'shutdown-controller.py':base/'owned-shutdown-1/control.py',
 'runtime-tamper-run.json':base/'owned-runtime-tamper-1/run.json',
 'process-run.json':base/'owned-process-native-3/run.json',
 'freeze_managed_candidate_3.py':Path(__file__),
 'managed-replay-tests-1.log':base/'managed-replay-tests-1.log',
 'managed-replay-tests-2.log':base/'managed-replay-tests-2.log',
 }.items():add('capture/'+name,path.read_bytes())
tested=io.BytesIO()
with zipfile.ZipFile(base/'owned-public-cli-3/omicsmatic-candidate.jar') as original,zipfile.ZipFile(tested,'w',compression=zipfile.ZIP_DEFLATED) as jar:
 for name in sorted(original.namelist()):
  if not name.endswith('/') and name.startswith(('org/jlinalg/cli/Shapeit','org/jlinalg/genetics/Shapeit','org/jlinalg/cli/SimpleJson','org/jlinalg/cli/JLinAlgCli','org/jlinalg/omics/shapeit-runtime','META-INF/licenses/SHAPEIT')):
   jar.writestr(name,original.read(name))
add('packaged/shapeit-tested-classes.jar',tested.getvalue())
add('README.txt',b'Exact-source controlled SHAPEIT5 common-stage workflow only. Nine actual packaged fits, six pre-fitting policy/data refusals, four unsupported-transport skips and one malformed-compression failure are retained with complete public manifests. Native portable replay checks every selected genotype, source-defined dosage, applied scaffold orientation and both count tables. Three JVM profiles run all380 tests under128MiB. Process14 and runtime-tamper9 controls are separate and use unchanged byte-identical supervision classes. Runtime installation adopts existing permitted exact members only; no scientific runtime binaries or shared libraries are redistributed. Source AN includes references while output GT/AC are target-only: preserve original BCF and use verified target counts. This archive is evidence and current-source verification, not a signature, live installation, phase-accuracy benchmark, released artifact or whole-paper reproduction.\n')
add('SHA256SUMS',''.join(sha(raw)+'  '+name+'\n' for name,raw in sorted(members.items())).encode())
artifact=data/'shapeit-managed-common-controls.zip'
with artifact.open('xb') as stream,zipfile.ZipFile(stream,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for name,raw in sorted(members.items()):
  info=zipfile.ZipInfo(name,(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;archive.writestr(info,raw)
record=dict(status='passed-scoped-original-SHAPEIT5-common-workflow-validation',source_sha256=pins,artifact=dict(path=artifact.name,sha256=sha(artifact.read_bytes()),bytes=artifact.stat().st_size),
 native_candidate_sha256=observed['candidate_sha256'],packaged_candidate='build/literature-review/shapeit-runtime/owned-public-cli-3/omicsmatic-candidate.jar',packaged_candidate_sha256='480e6257e5ad500d3e3f33df661e21c3bada6c68e8eacb44bafd6b5ab82a75e2',packaged_classes_sha256=sha(tested.getvalue()),
 native_tests_per_JVM=380,JVM_profiles=3,heap='128m',portable_replays=9,packaged_protocols=20,actual_successful_fits=9,input_policy_refusals=6,unsupported_transport_skips=4,invalid_compression_failures=1,selected_rows=1131,target_cells=41470,reference_haplotype_cells=30160,applied_scaffold_constraints=573,source_AN_includes_reference_rows=377,owned_process_controls=14,runtime_tamper_controls=9,
 source_current_common_command_available=True,installation_mode='existing-permitted-exact-member-copy-only',download_source_build_installer_available=False,binary_genotype_payloads_validated=False,historical_editions_reproduced=False,pedigree_haploid_rare_ligation_validated=False,phase_accuracy_certified=False,released_or_deployed=False,whole_paper_reproduced=False,
 dependency_source_notices=json.loads((matrix/'dependency-sources/provenance.json').read_bytes()),source_roles_reviewed=10,
 scope='Current development source c34d ordinary diploid-GT cohort/reference/scaffold common-stage fitting with native original-join/selection/map/genotype checks, private pinned runtime/loader, owned process limits and complete output audits. Indexed BGZF BCF2.2 only; exact-member adoption only. Historical2/4/5.0, transport conversion, binary, pedigree/haploid/phase-set, rare/ligation/posterior and paper-specific pipelines remain unfinished.',
 warnings=['Source AN counts reference haplotypes while output GT/AC contain targets only; use verified target_AC/target_AN and preserve original BCF.','Source whole-call imputation may discard an observed allele in a partially missing call.','Configured scaffold must apply constraints under this admission; original source can otherwise exit successfully without using it.','Native replay is data/output verification only. Actual runtime execution and all unsupported scopes have separate evidence and explicit limits.'],
 required_action='Read SHAPEIT_COMMON_WORKFLOW.md, WARNINGS.md and session.json. Require COMPLETED.json plus matching manifest/file hashes. Unavailable/forbidden exact runtime or unsupported capability requires SKIP3 and a skipped analysis; invalid input/integrity/execution/capacity requires FAIL2. Preserve failed state, correct the cause and rerun to a NEW output. Setup copies existing permitted exact members and does not download or build; never substitute a historical or alternative runtime.')
(data/'shapeit-managed-common-validation.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8');validation.verify(root,data)
print(json.dumps(dict(artifact_sha256=record['artifact']['sha256'],bytes=artifact.stat().st_size,members=len(members),decoded_bytes=sum(map(len,members.values())),source_paths=len(pins)),indent=2))
