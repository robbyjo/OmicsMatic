from pathlib import Path
import hashlib,json,subprocess,zipfile
root=Path('/mnt/d/projects/JLinAlg');report=root/'build/literature-review/shapeit-runtime/owned-public-cli-3';candidate=report/'omicsmatic-candidate.jar';runtime=Path('/opt/omicsmatic-shapeit-dev-1/managed-common-runtime-2');work=Path('/opt/omicsmatic-shapeit-dev-1/owned-public-cli-controls-3');work.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();records=[];success=refused=rows=targets=refs=constraints=an_departures=0
with zipfile.ZipFile(root/'src/test/resources/org/jlinalg/cli/shapeit-common/original-controls.zip') as fixture:cases=json.loads(fixture.read('cases.json'))
for case in cases:
 name=case['name'];inputs=Path('/opt/omicsmatic-shapeit-dev-1/owned-common-controls-1/input-'+name);request=dict(schema_version=1,profile='shapeit5-c34d-common-linux-x86_64',target=str(inputs/'panel-0.bcf'),contig='20',region='20',parameters=dict(snps_only=case['snp'],seed=15052011,threads=1,count_policy='REQUIRE_SAMPLE_COUNTS',missing_policy='SOURCE_WHOLE_GENOTYPE_IMPUTATION'),limits=dict(process=dict(wallMillis=180000,addressSpaceBytes=2147483648,cpuSeconds=120,fileBytes=134217728,openFiles=256,workspaceBytes=536870912,fileCount=512,processes=8,threads=64,sampledRssBytes=1073741824,monitorMillis=25),wholeWorkspaceBytes=1073741824,wholeFiles=2048,wholeWallMillis=600000))
 for i,role in enumerate(case['roles']):
  if role=='REFERENCE':request['reference']=str(inputs/('panel-'+str(i)+'.bcf'))
  if role=='SCAFFOLD':request['scaffold']=str(inputs/('panel-'+str(i)+'.bcf'))
 if case['map_member']:request['map']=str(inputs/'genetic.map.tsv')
 if case['maf']!='default':request['parameters']['minimum_maf']=float(case['maf'])
 recipe=work/(name+'.recipe.json');recipe.write_text(json.dumps(request,indent=2)+'\n');destination=work/name
 command=['/usr/bin/java','-Xmx128m','-Dsamjdk.use_libdeflate=false','-jar',str(candidate),'shapeit-tools','--recipe',str(recipe),'--home',str(runtime),'--out',str(destination)]
 with (work/(name+'.stdout')).open('wb') as stdout,(work/(name+'.stderr')).open('wb') as stderr:result=subprocess.run(command,stdout=stdout,stderr=stderr,timeout=660)
 session=json.loads((destination/'session.json').read_bytes());manifest=json.loads((destination/'manifest.json').read_bytes())
 for relative,identity in manifest['files'].items():
  p=destination/relative;assert p.is_file() and not p.is_symlink() and p.stat().st_size==identity['bytes'] and sha(p)==identity['sha256'],relative
 expected={'reference-missing':'REFERENCE_LITERAL_MISSING','reference-unphased':'REFERENCE_UNPHASED','cohort-wire-departures':'unadmitted missingness/ploidy encoding','scaffold-unused':'scaffold applies zero constraints'}.get(name)
 if expected:
  assert result.returncode==2 and expected in session['error'] and not (destination/'COMPLETED.json').exists();assert not (destination/'analysis/fit-process').exists();refused+=1
 else:
  assert result.returncode==0,(name,result.returncode,(work/(name+'.stderr')).read_text()[-3000:]);complete=json.loads((destination/'COMPLETED.json').read_bytes());assert complete['manifest_sha256']==sha(destination/'manifest.json') and complete['scientific_result_admitted'] is True and complete['phase_accuracy_certified'] is False
  native=json.loads((destination/'analysis/analysis.json').read_bytes());admission=native['admission'];rows+=admission['selectedRows'];targets+=admission['selectedTargetCells'];refs+=2*admission['selectedReferenceCells'];constraints+=admission['appliedScaffoldConstraints'];an_departures+=native['source_AN_includes_reference_rows'];success+=1
  for role in ['join-process','fit-process']:
   for suffix in ['', '.loader-check']:
    process=json.loads((destination/'analysis'/(role+suffix)/'process.json').read_bytes());assert process['status']=='completed-process-only' and process['owned_live_after_cleanup']==[] and process['exit_code']==0
 assert 'Required action' in (destination/'WARNINGS.md').read_text()
 records.append(dict(name=name,command=command,exit_code=result.returncode,expected_refusal=expected,public_manifest_sha256=sha(destination/'manifest.json'),work=str(destination)))
 (work/'partial.json').write_text(json.dumps(records,indent=2)+'\n');print(name,'PASS',flush=True)
assert (success,refused,rows,targets,refs,constraints,an_departures)==(8,4,1005,35170,30160,573,377)
observed=dict(status='passed-exact-packaged-public-common-cli-controls',candidate_sha256=sha(candidate),successful_actual_fits=success,expected_pre_fitting_refusals=refused,selected_rows=rows,target_cells=targets,reference_haplotype_cells=refs,applied_scaffold_constraints=constraints,source_AN_includes_reference_rows=an_departures,commands=records,scope='Packaged original c34d ordinary diploid-GT common stage only. Exact-build local adoption; download/source-building and other SHAPEIT profiles/stages remain unfinished. No phase-accuracy claim.')
(work/'observed.json').write_text(json.dumps(observed,indent=2)+'\n');print('PUBLIC CLI CONTROLS PASSED',flush=True)
