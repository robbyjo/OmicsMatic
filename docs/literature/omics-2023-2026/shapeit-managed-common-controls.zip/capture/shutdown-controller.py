from pathlib import Path
import json,subprocess,time
root=Path('/mnt/d/projects/JLinAlg/build/literature-review/shapeit-runtime');report=root/'owned-shutdown-1';work=Path('/opt/omicsmatic-shapeit-dev-1/owned-shutdown-control-1');command=['/usr/bin/java','-Xmx128m','-cp',str(root/'owned-public-cli-1/omicsmatic-candidate.jar')+':'+str(report),'org.jlinalg.cli.ShapeitShutdownChild',str(work)]
with (report/'child.stdout').open('wb') as stdout,(report/'child.stderr').open('wb') as stderr:
 child=subprocess.Popen(command,stdout=stdout,stderr=stderr);deadline=time.monotonic()+15
 while time.monotonic()<deadline:
  assert child.poll() is None,'Controlled JVM exited before interruption'
  if (work/'launch.json').is_file():
   launched=json.loads((work/'launch.json').read_bytes());pid=launched['owned_launcher_pid']
   if Path('/proc',str(pid)).is_dir():break
  time.sleep(0.02)
 else:
  child.terminate();child.wait(timeout=20);raise RuntimeError('No verified live owned launcher appeared')
 child.terminate();exit_code=child.wait(timeout=20)
assert exit_code!=0
shutdown=json.loads((work/'shutdown.json').read_bytes());assert shutdown['status']=='shutdown-owned-processes-terminal' and shutdown['owned_live_after_cleanup']==[]
for identity in shutdown['owned_processes']:
 p=Path('/proc',str(identity['pid']),'stat')
 try:
  t=p.read_text();fields=t[t.rindex(')')+2:].split();assert int(fields[19])!=identity['startTicks'] or fields[0] in ['Z','X']
 except FileNotFoundError:pass
assert not (work/'COMPLETED.json').exists();(report/'observed.json').write_text(json.dumps(dict(status='passed-owned-JVM-shutdown-cleanup',command=command,child_exit_code=exit_code,confirmed_live_launcher_pid=pid,shutdown=shutdown),indent=2)+'\n');print('OWNED JVM SHUTDOWN PASS')
