package org.jlinalg.cli;
import java.io.*;
import java.nio.file.*;
import java.util.*;
public final class ShapeitOwnedProcessControls {
 private static ShapeitProcess.Limits limits(long wall,long memory,long cpu,long file,long workspace,int files,int processes){return new ShapeitProcess.Limits(wall,memory,cpu,file,256,workspace,files,processes,64,1073741824,10);}
 public static void main(String[] args)throws Exception{
  Path root=Path.of(args[0]);Files.createDirectory(root);var records=new ArrayList<Map<String,Object>>();
  Process sentinel=new ProcessBuilder("/usr/bin/sleep","60").directory(Path.of("/tmp").toFile()).redirectOutput(ProcessBuilder.Redirect.DISCARD).redirectError(ProcessBuilder.Redirect.DISCARD).start();
  try{
   for(String name:List.of("success","exit","orphan","wall","cancel","input-change","symlink","files","workspace","process-count","hard-as","hard-file","hard-cpu")){
    Path work=root.resolve(name);var budget=limits(10000,2147483648L,10,134217728,536870912,512,8);var command=new ArrayList<String>(List.of("/bin/sh","-c","printf complete"));String expected=null;var env=new HashMap<>(Map.of("PATH","/usr/bin:/bin","LC_ALL","C"));ShapeitProcess.Check integrity=()->{};Runnable cancellation=()->{};
    switch(name){
     case "success"->{}case "exit"->{command.set(2,"exit 7");expected="exit 7";}
     case "orphan"->{command.set(2,"sleep 30 & printf '%s\\n' $!; exit 0");expected="live owned workers";}
     case "wall"->{command.set(2,"sleep 30 & wait");budget=limits(200,2147483648L,10,134217728,536870912,512,8);expected="wall-time";}
     case "cancel"->{command.set(2,"sleep 30 & wait");int[] calls={0};cancellation=()->{if(++calls[0]>3)throw new IllegalStateException("controlled cancellation");};expected="cancelled";}
     case "input-change"->{Path source=root.resolve("source.txt");Files.writeString(source,"original");env.put("CONTROLLED_SOURCE",source.toString());command.set(2,"printf changed > \"$CONTROLLED_SOURCE\"");integrity=()->{if(!Files.readString(source).equals("original"))throw new IOException("controlled source mutation");};expected="integrity failed";}
     case "symlink"->{command.set(2,"ln -s /tmp linked");expected="linked/nonregular";}
     case "files"->{command.set(2,"touch a b c d e f g h i");budget=limits(10000,2147483648L,10,134217728,536870912,8,8);expected="file";}
     case "workspace"->{command.set(2,"head -c 65536 /dev/zero > payload");budget=limits(10000,2147483648L,10,134217728,8192,512,8);expected="workspace";}
     case "process-count"->{command.set(2,"sleep 30 & wait");budget=limits(10000,2147483648L,10,134217728,536870912,512,1);expected="RSS/thread/process capacity";}
     case "hard-as"->{command=new ArrayList<>(List.of("/usr/bin/python3","-c","bytearray(268435456)"));budget=limits(10000,67108864,10,134217728,536870912,512,8);expected="Original Shapeit process failed";}
     case "hard-file"->{command.set(2,"head -c 1048576 /dev/zero > payload");budget=limits(10000,2147483648L,10,8192,536870912,512,8);expected="Original Shapeit process failed";}
     case "hard-cpu"->{command.set(2,"while :; do :; done");budget=limits(10000,2147483648L,1,134217728,536870912,512,8);expected="Original Shapeit process failed";}
     default->throw new AssertionError(name);
    }
    String error=null;try{var result=ShapeitProcess.executeOwned(command,env,work,budget,integrity,cancellation);if(expected!=null)throw new AssertionError("Invalid control succeeded: "+name);if(result.exitCode()!=0||!result.ownedLiveAfterCleanup().isEmpty())throw new AssertionError("Incomplete terminal success");}
    catch(IOException failure){error=failure.toString();if(expected==null||!error.contains(expected))throw failure;}
    Map<?,?> ledger=(Map<?,?>)SimpleJson.parse(Files.readString(work.resolve("process.json")));if(!List.of().equals(ledger.get("owned_live_after_cleanup")))throw new AssertionError("Owned worker survived "+name);
    if(!sentinel.isAlive())throw new AssertionError("Unrelated sentinel was killed");if(!Files.readString(work.resolve("WARNINGS.md")).contains("Required action"))throw new AssertionError("Missing recovery");
    var record=new LinkedHashMap<String,Object>();record.put("name",name);record.put("work",work);record.put("command",command);record.put("limits",budget);record.put("error",error);record.put("expected",expected);record.put("owned_live_after_cleanup",ledger.get("owned_live_after_cleanup"));records.add(record);System.out.println(name+" PASS");
   }
  }finally{sentinel.destroyForcibly();if(!sentinel.waitFor(5,java.util.concurrent.TimeUnit.SECONDS))throw new AssertionError("Controlled sentinel remains alive");}
  Files.writeString(root.resolve("observed.json"),ShapeitJson.json(Map.of("status","passed-owned-SHAPEIT-process-controls","controls",records,"tests",records.size(),"unrelated_process_preserved",true))+"\n");
 }
}
