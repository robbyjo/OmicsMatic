#include <htslib/vcf.h>
#include <iostream>
int main(int argc,char** argv){
 if(argc!=3)return 2;
 htsFile* input=bcf_open(argv[1],"r");if(!input)return 3;bcf_hdr_t* header=bcf_hdr_read(input);if(!header)return 4;
 htsFile* output=bcf_open(argv[2],"wbx");if(!output)return 5;if(bcf_hdr_write(output,header))return 6;
 bcf1_t* row=bcf_init();int32_t* values=nullptr;int capacity=0,changed=0,rows=0,code;
 while((code=bcf_read(input,header,row))==0){
  if(!changed&&row->n_allele==2){int length=bcf_get_info_int32(header,row,"AC",&values,&capacity);if(length!=1||values[0]<0)return 7;values[0]++;if(bcf_update_info_int32(header,row,"AC",values,1))return 8;changed++;}
  if(bcf_write(output,header,row))return 9;rows++;
 }
 if(code!=-1)return 10;free(values);bcf_destroy(row);bcf_hdr_destroy(header);if(bcf_close(input)||bcf_close(output))return 11;
 if(changed!=1||bcf_index_build(argv[2],14))return 12;std::cout<<"Changed one declared AC; retained "<<rows<<" records\n";return 0;
}
