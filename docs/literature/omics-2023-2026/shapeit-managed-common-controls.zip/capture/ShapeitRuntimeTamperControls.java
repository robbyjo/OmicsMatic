package org.jlinalg.cli;
import java.io.*;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;
public final class ShapeitRuntimeTamperControls {
 public static void main(String[] args)throws Exception{
  Path original=Path.of(args[0]),root=Path.of(args[1]),home=root.resolve("home");Files.createDirectory(root);
  Files.walkFileTree(original,new SimpleFileVisitor<>(){
   @Override public FileVisitResult preVisitDirectory(Path p,BasicFileAttributes a)throws IOException{Files.createDirectory(home.resolve(original.relativize(p)));return FileVisitResult.CONTINUE;}
   @Override public FileVisitResult visitFile(Path p,BasicFileAttributes a)throws IOException{Files.copy(p,home.resolve(original.relativize(p)),StandardCopyOption.COPY_ATTRIBUTES);return FileVisitResult.CONTINUE;}
  });
  Path marker=home.resolve(ShapeitRuntime.MARKER);var record=new LinkedHashMap<String,Object>();for(var e:((Map<?,?>)SimpleJson.parse(Files.readString(marker))).entrySet())record.put(e.getKey().toString(),e.getValue());record.put("home",home.toString());Files.writeString(marker,ShapeitJson.json(record));
  byte[] markerBefore=Files.readAllBytes(marker);var baseline=ShapeitRuntime.open(home);baseline.verify();var results=new ArrayList<Map<String,Object>>();
  for(String name:List.of("binary","library","lock-marker","false-analysis-claim","extra-file","extra-directory","linked-library","missing-program","old-library-fallback")){
   Path changed=null,backup=null;byte[] before=null;String error=null;
   try{
    switch(name){
     case "binary","library"->{changed=home.resolve(name.equals("binary")?"bin/phase_common":"lib/libhts.so.3");before=Files.readAllBytes(changed);byte[] mutated=before.clone();mutated[0]^=1;Files.write(changed,mutated);}
     case "lock-marker","false-analysis-claim"->{var altered=new LinkedHashMap<>(record);altered.put(name.equals("lock-marker")?"lock_sha256":"scientific_analysis_admitted",name.equals("lock-marker")?"0".repeat(64):Boolean.TRUE);Files.writeString(marker,ShapeitJson.json(altered));}
     case "extra-file"->{changed=home.resolve("lib/inject.so");Files.writeString(changed,"unmanaged");}
     case "extra-directory"->{changed=home.resolve("lib/glibc-hwcaps");Files.createDirectory(changed);}
     case "linked-library","missing-program"->{changed=home.resolve(name.equals("linked-library")?"lib/libhts.so.3":"bin/phase_common");backup=root.resolve("backup-"+name);Files.move(changed,backup);if(name.equals("linked-library"))Files.createSymbolicLink(changed,backup);}
     case "old-library-fallback"->{}default->throw new AssertionError(name);
    }
    try{if(name.equals("old-library-fallback"))baseline.checkClosure(ShapeitRuntime.Program.COMMON,Path.of(args[2]));else ShapeitRuntime.open(home);throw new AssertionError("Unmanaged runtime accepted: "+name);}catch(IOException refused){error=refused.toString();}
   }finally{
    Files.write(marker,markerBefore);
    if(before!=null)Files.write(Objects.requireNonNull(changed),before);
    else if(backup!=null){Files.deleteIfExists(Objects.requireNonNull(changed));Files.move(backup,changed);}
    else if(changed!=null)Files.delete(changed);
   }
   ShapeitRuntime.open(home).verify();results.add(Map.of("name",name,"status","passed-no-runtime-or-analysis-admitted","error",Objects.requireNonNull(error)));System.out.println(name+" PASS");
  }
  Files.writeString(root.resolve("observed.json"),ShapeitJson.json(Map.of("status","passed-private-SHAPEIT-runtime-tamper-controls","tests",results.size(),"controls",results,"original_runtime_unchanged",ShapeitRuntime.open(original).equals(ShapeitRuntime.open(original))))+"\n");
 }
}
