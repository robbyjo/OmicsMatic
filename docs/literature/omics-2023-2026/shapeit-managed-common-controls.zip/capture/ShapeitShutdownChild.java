package org.jlinalg.cli;
import java.nio.file.*;
import java.util.*;
public final class ShapeitShutdownChild {
 public static void main(String[] args)throws Exception{
  ShapeitProcess.executeOwned(List.of("/bin/sh","-c","sleep 120 & wait"),Map.of("PATH","/usr/bin:/bin","LC_ALL","C"),Path.of(args[0]),
    new ShapeitProcess.Limits(180000,2147483648L,120,134217728,256,536870912,512,8,64,1073741824,10),()->{},()->{});
  throw new AssertionError("Interrupted process cannot return a scientific result");
 }
}
