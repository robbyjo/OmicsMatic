# FAIL2_MALT_FAMILY_CURRENT_SOURCE_AUDIT

Required action: retain complete primary-source inputs and resolve any named pointer, hash, schema or prerequisite failure before a NEW audit. Missing/invalid evidence does not admit a tool or biological result. Semantic completeness and full implementation remain open.
