from pathlib import Path
import hashlib, json, zipfile

root = Path('D:/projects/JLinAlg')
base = root/'build/literature-review/shapeit-runtime'
matrix = base/'map-native-matrix-4'
data = root/'docs/literature/omics-2023-2026'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
paths = ['.gitattributes','LICENSES/SHAPEIT4-MIT.txt','LICENSES/SHAPEIT5-MIT.txt',
         'src/main/resources/META-INF/licenses/SHAPEIT4-MIT.txt','src/main/resources/META-INF/licenses/SHAPEIT5-MIT.txt',
         'src/main/java/org/jlinalg/genetics/ShapeitGeneticMap.java','src/test/java/org/jlinalg/genetics/ShapeitGeneticMapTest.java',
         'src/test/resources/org/jlinalg/genetics/shapeit-map/original-controls.zip',
         'tools/literature/shapeit-reference/MapProtocol.cpp','tools/literature/shapeit-reference/collect_map_evidence.py',
         'tools/literature/shapeit_map_validation.py','tools/literature/test_shapeit_map_validation.py',
         'tools/literature/catalog_source_integrity.py','tools/literature/shapeit_development_validation.py']
sources = [{'path':name,'sha256':sha((root/name).read_bytes())} for name in paths]
members = {'source/'+item['path']:(root/item['path']).read_bytes() for item in sources}
members['artifacts/shapeit-native-map.jar'] = (matrix/'shapeit-native-map.jar').read_bytes()
members['artifacts/original-map-controls.zip'] = (root/'src/test/resources/org/jlinalg/genetics/shapeit-map/original-controls.zip').read_bytes()
observed = json.loads((matrix/'observed.json').read_bytes())
assert observed['status']=='passed133exact-native-package-tests-three-JVMs-and-strict17-javadoc'
for path,expected in observed['source_sha256'].items(): assert sha((root/path).read_bytes())==expected,path
for path in matrix.iterdir():
    if path.is_file() and path.name!='running.json': members['matrix/'+path.name]=path.read_bytes()
for path in (matrix/'test-classes').rglob('*.class'):
    members['tests/classes/'+path.relative_to(matrix/'test-classes').as_posix()]=path.read_bytes()
for number in range(1,5):
    controller=base/f'run_map_matrix_{number}.py'; members['history/'+controller.name]=controller.read_bytes()
    log=base/f'map-native-matrix-controller-{number}.log'; members['history/'+log.name]=log.read_bytes()
    if number!=4:
        for path in (base/f'map-native-matrix-{number}').iterdir():
            if path.is_file() and path.name!='running.json': members[f'history/native-matrix-{number}/'+path.name]=path.read_bytes()
members['protocol/freeze_map_candidate_3.py'] = Path(__file__).read_bytes()
members['history/proof-before-metadata-tightening.json'] = (base/'map-proof-before-metadata-tightening-1/shapeit-map-validation.json').read_bytes()
members['history/proof-before-XCF-attribution.json'] = (base/'map-proof-before-XCF-attribution-1/shapeit-map-validation.json').read_bytes()
members['SHA256SUMS'] = ''.join(sha(raw)+'  '+name+'\n' for name,raw in sorted(members.items())).encode()
destination = data/'shapeit-map-native-controls.zip'
with destination.open('wb') as stream,zipfile.ZipFile(stream,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,raw in sorted(members.items()):
        entry=zipfile.ZipInfo(name,(2026,11,1,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED;entry.external_attr=0o100644<<16
        archive.writestr(entry,raw)
proof = {'schema_version':1,'status':'passed-native-map-and-checked-original-boundaries',
         'source_profiles':{'4.1.3':'ca896a27d7d6650c56f516f7de8d537fdf114a1d','4.2.2':'16865e593ad50689271ead985dc8f4296d2f491d','5-c34d':'c34d4db3e99a2f7e23deb727671ae260901a5886'},
         'native_controls':{'path':destination.name,'bytes':destination.stat().st_size,'sha256':sha(destination.read_bytes())},
         'native_candidate_sha256':sha(members['artifacts/shapeit-native-map.jar']),
         'original_controls_sha256':sha(members['artifacts/original-map-controls.zip']),
         'original_observations':127,'complete_original_observations':105,'expected_original_failure_observations':22,
         'compiler_rounding_difference_rows':12,'native_tests_per_JVM':133,'JVM_profiles':3,
         'public_phasing_adapter_available':False,'whole_paper_reproduced':False,'new_tool_integrations':0,
         'source_evidence':sources,
         'warnings':[{'code':'ALL_BEFORE_4_1_3','cause':'Original target-vector read outside its size when every variant precedes the map.','action':'Skip dependent phasing; supply an appropriate map covering selected variants or separately validate a corrected upstream runtime.'},
                     {'code':'RIGHT_INTERVAL_READ','cause':'Original knot-vector read outside its size during right extrapolation in all three inspected profiles.','action':'Skip dependent phasing; obtain appropriate complete map coverage through the last variant or separately validate a corrected upstream runtime.'},
                     {'code':'NATIVE_FOUNDATION_ONLY','cause':'No protected public file/runtime phasing adapter is available.','action':'Complete source identity, EOF, variant selection, panel joins and common/rare/ligation admission before reporting a phasing analysis.'}],
         'scope':'Original three-column parsing and finite map interpolation only. Duplicate knots, C numeric-prefix coercions, signed zero, NaN payload inspection and compiler-specific rounding are retained. Known original undefined accesses and unusable numerical maps cannot yield a successful analysis.'}
path=data/'shapeit-map-validation.json';path.write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'native_bundle_sha256':proof['native_controls']['sha256'],'native_candidate_sha256':proof['native_candidate_sha256'],'native_bundle_bytes':destination.stat().st_size,'members':len(members),'source_pins':len(sources)},indent=2))
