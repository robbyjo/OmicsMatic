
import json,os,subprocess,sys
from pathlib import Path
root,jar=Path(sys.argv[1]),Path(sys.argv[2]);assert not root.exists();root.mkdir(mode=0o755);root.chmod(0o755)
(root/'out').mkdir();(root/'out').chmod(0o777);(root/'no-write').mkdir();(root/'no-write').chmod(0o555)
for name in ['readable.bdg','forbidden.bdg']:(root/name).write_text('chr\t0\t1\t0.5\n');(root/name).chmod(0o644)
(root/'forbidden.bdg').chmod(0);(root/'reference.sizes').write_text('chr\t10\n');(root/'reference.sizes').chmod(0o644)
results=[]
for label,signal,out in [('forbidden-input',root/'forbidden.bdg',root/'out/read-skip'),('forbidden-output',root/'readable.bdg',root/'no-write/output-skip')]:
 command=['/usr/bin/java','-Xmx512m','-XX:ActiveProcessorCount=2','-jar',str(jar),'bigwig-tools','--input',str(signal),'--sizes',str(root/'reference.sizes'),'--genome-build','synthetic-reference','--units','synthetic scores','--float32','exact','--dictionary','used','--compression','zlib','--out',str(out)]
 with (root/(label+'.stdout')).open('xb') as stdout,(root/(label+'.stderr')).open('xb') as stderr:r=subprocess.run(command,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,user=65534,group=65534,extra_groups=(),timeout=60)
 assert r.returncode==3 and 'SKIP3' in (root/(label+'.stderr')).read_text() and not (out/'COMPLETED.json').exists(),(label,r.returncode)
 if label=='forbidden-input':assert 'SKIP3' in (out/'WARNINGS.md').read_text() and json.loads((out/'FAILURE.json').read_bytes())['status']=='SKIP3_CONVERSION_SKIPPED'
 else:assert not out.exists()
 results.append(dict(id=label,uid=65534,gid=65534,exit_code=r.returncode,command=command,overall_completion_absent=True))
(root/'COMPLETED.json').write_text(json.dumps(dict(status='PASSED_ACTUAL_NONPRIVILEGED_NATIVE_PERMISSION_SKIPS',cases=results),indent=2)+'\n');print('Two real nonprivileged permission skips passed',flush=True)
