# Native bigWig warnings and required actions

WARNING: Native Java bigWig v4 conversion of complete unchanged supplied inputs. Declared build=synthetic-reference; units=synthetic scores. These labels do not authenticate an assembly or establish signal normalization. No chromosome aliasing, clipping, overlap averaging, record filtering or missing-base zero filling occurred.

WARNING: PRECISION POLICY=exact. Input decimal tokens are interpreted as float64 and stored as float32. VALUE-LEDGER.tsv retains every token, exact hexadecimal float64/float32 value, float32 bits and underflow stage. Exact policy requires equality to the literal input decimal, including decimal information lost before float32 conversion.

WARNING: DICTIONARY POLICY=all. REFERENCE-LEDGER.tsv retains all 1 declared chromosomes, every original size token, stored/omitted disposition and binary chromosome ID. Native binary dictionary/data use unsigned UTF8 byte order; source files and input ordinals remain unchanged.

WARNING: EMPTY TRACK: no measured signal intervals are present. All-reference dictionary was explicitly requested; zero summary fields do not represent measured zero signal. The pinned original converter rejects an empty input; no original-converter equivalence is claimed.

WARNING: SOURCE METADATA: 1 initial track/browser lines are preserved raw and counted, but their display settings are not applied to signal or normalization.

WARNING: NATIVE SUMMARY ARITHMETIC: totals use stored float32 values with double products and compensated double sums. They differ from UCSC2.10 float arithmetic. Original finite raw signals can produce infinite original sums of squares; the pinned Cygwin pyBigWig0.3.26 header reader crashed on one such original file. Native summaries remain finite for this admitted bounded population. No original summary-bit or binary-layout identity is claimed.

WARNING: NO ZOOM APPROXIMATIONS: complete full-resolution chromosome/R-tree indexes and raw data are stored, with0 zoom levels. Large-range consumers may require more raw I/O; original zoom selection, approximate statistics and rendering performance are not reproduced.

WARNING: RESOURCE CAPACITIES: complete input/decoded/record/line/output/workspace limits are retained in request.json. The requested maximum output and16MiB final metadata reserve must fit alongside complete prepared evidence; capacities are never silently lowered. These limits do not guarantee Java heap availability. Preserve failures and explicitly review capacities before a NEW attempt.

WARNING: PORTABLE VERIFICATION: only captured complete inputs and outputs are opened; recorded producer paths remain opaque provenance text. Copied filesystem modes are not producer-permission certificates. Hashes prove integrity, not authenticity, biological accuracy or historical paper reproduction.

Required action: read WARNINGS.md, FAILURE.json and its named stage when present, request.json, INPUT-AUDIT.json, OUTPUT-AUDIT.json, VALUE-LEDGER.tsv and REFERENCE-LEDGER.tsv. Require overall COMPLETED.json, no INCOMPLETE.json/FAILURE.json, and successful bigwig-tools --verify before downstream use. SKIP3 means required permitted input/output access is forbidden: supply the named permitted resource or skip this dependent conversion. No installation is needed or attempted. FAIL2 means input, precision, integrity, capacity, I/O, cancellation or finalization failure: no result admitted. Preserve the whole attempt/partial track, correct the cause and use NEW paths. Never silently clip, normalize, average overlaps, alias chromosome identities or fill missing signal with zeros. Declared file/record capacities are not a JVM heap guarantee. Hashes establish integrity, not authenticity or biological accuracy. Cell Ranger remains excluded.


# INVALIDATED — NO RESULT ADMITTED

The historical candidate incorrectly treated a malformed coordinate-bearing track row as display metadata. Preserve all raw evidence; use the corrected parser and NEW paths.
