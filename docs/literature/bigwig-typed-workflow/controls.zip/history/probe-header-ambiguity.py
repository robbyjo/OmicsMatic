import json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent/'header-ambiguity-probe-1'
assert not root.exists()
root.mkdir()
(root/'input.bedGraph').write_text('track\t0\t1\t1\textra\n',encoding='utf-8')
(root/'reference.sizes').write_text('chr\t10\n',encoding='utf-8')
jar=Path(__file__).resolve().parent/'package-2/omicsmatic-0.3.7-bigwig-development.jar'
command=['C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe','-jar',str(jar),'bigwig-tools','--input',str(root/'input.bedGraph'),'--sizes',str(root/'reference.sizes'),'--genome-build','synthetic-reference','--units','synthetic scores','--float32','exact','--dictionary','all','--compression','zlib','--out',str(root/'result')]
with (root/'process.stdout').open('xb') as out,(root/'process.stderr').open('xb') as err:run=subprocess.run(command,stdout=out,stderr=err,timeout=60)
(root/'OBSERVED.json').write_text(json.dumps(dict(command=command,exit_code=run.returncode,bug='A coordinate-bearing malformed row named track must fail, even if the chromosome is absent from sizes; it must not be treated as display metadata.',source_repair_required=run.returncode==0),indent=2)+'\n')
print('Observed malformed coordinate-bearing track row exit:',run.returncode)
