# INCOMPLETE — NO RESULT ADMITTED

Required action: read WARNINGS.md, FAILURE.json and its named stage when present, request.json, INPUT-AUDIT.json, OUTPUT-AUDIT.json, VALUE-LEDGER.tsv and REFERENCE-LEDGER.tsv. Require overall COMPLETED.json, no INCOMPLETE.json/FAILURE.json, and successful bigwig-tools --verify before downstream use. SKIP3 means required permitted input/output access is forbidden: supply the named permitted resource or skip this dependent conversion. No installation is needed or attempted. FAIL2 means input, precision, integrity, capacity, I/O, cancellation or finalization failure: no result admitted. Preserve the whole attempt/partial track, correct the cause and use NEW paths. Never silently clip, normalize, average overlaps, alias chromosome identities or fill missing signal with zeros. Declared file/record capacities are not a JVM heap guarantee. Hashes establish integrity, not authenticity or biological accuracy. Cell Ranger remains excluded.


# FAIL2 — NO RESULT ADMITTED

Stage: PARSE_COMPLETE_INPUTS_AND_LEDGERS

java.io.IOException: bedGraph requires four columns at source line 1

Required action: read WARNINGS.md, FAILURE.json and its named stage when present, request.json, INPUT-AUDIT.json, OUTPUT-AUDIT.json, VALUE-LEDGER.tsv and REFERENCE-LEDGER.tsv. Require overall COMPLETED.json, no INCOMPLETE.json/FAILURE.json, and successful bigwig-tools --verify before downstream use. SKIP3 means required permitted input/output access is forbidden: supply the named permitted resource or skip this dependent conversion. No installation is needed or attempted. FAIL2 means input, precision, integrity, capacity, I/O, cancellation or finalization failure: no result admitted. Preserve the whole attempt/partial track, correct the cause and use NEW paths. Never silently clip, normalize, average overlaps, alias chromosome identities or fill missing signal with zeros. Declared file/record capacities are not a JVM heap guarantee. Hashes establish integrity, not authenticity or biological accuracy. Cell Ranger remains excluded.
