from pathlib import Path
import concurrent.futures,hashlib,json,shutil,subprocess,zipfile
R=Path('D:/projects/JLinAlg');H=R/'build/gs-2';B=H/'build/gsea-high-impact-2';O=B/'native-reader-controls-1';O.mkdir(exist_ok=False)
Q=H/'docs/literature/gsea-native-development';READER=H/'tools/literature/verify_broad_gsea_native.py'
PY=Path('C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')
JAR=B/'native-gradle-1/project-build/cli/omicsmatic-0.4.0.jar'
def enc(v):return (json.dumps(v,indent=2)+'\n').encode()
def pin(raw):return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def linux(p):return '/mnt/d/'+str(p.relative_to(Path('D:/'))).replace('\\','/')
def prepare_control(host,name):
    folder=O/host/name;folder.mkdir(parents=True);packet=folder/'packet';shutil.copytree(Q,packet)
    q=json.loads((packet/'QUALIFICATION.json').read_bytes())
    if name=='missing-archive':(packet/'checks.zip').rename(packet/'withheld-checks.zip')
    elif name=='changed-archive':
        with (packet/'checks.zip').open('ab') as f:f.write(b'changed archive')
    elif name=='missing-source-guard':
        q['source_code'].pop('src/main/java/org/jlinalg/enrichment/BroadGseaStatistics.java')
        (packet/'QUALIFICATION.json').write_bytes(enc(q))
    elif name=='resealed-failed-process':
        with zipfile.ZipFile(packet/'checks.zip') as z:files={n:z.read(n) for n in z.namelist()}
        name2='runs/windows-java21/PROCESS.json';value=json.loads(files[name2]);value['exit_code']=2;files[name2]=enc(value)
        (packet/'checks.zip').rename(packet/'before-reseal.zip')
        with zipfile.ZipFile(packet/'checks.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
            for n,raw in files.items():z.writestr(n,raw)
        q['checks']=dict(archive=pin((packet/'checks.zip').read_bytes()),files={n:pin(raw) for n,raw in files.items()})
        (packet/'QUALIFICATION.json').write_bytes(enc(q))
    return folder,packet
def task(host):
    root=O/host;root.mkdir();records=[]
    for name in ['pass','existing-output','different-jar','missing-archive','changed-archive','missing-source-guard','resealed-failed-process']:
        if name in ['pass','existing-output','different-jar']:
            folder=root/name;folder.mkdir();packet=Q
        else:folder,packet=prepare_control(host,name)
        out=folder/'readback'
        if name=='existing-output':out.mkdir();(out/'marker').write_bytes(b'preserve-existing-output')
        jar=JAR if name=='pass' else R/'build/edg-3/build/edger-admission-1/dispatch-gradle-1/project-build/cli/omicsmatic-0.4.0.jar' if name=='different-jar' else None
        arguments=['--packet',str(packet),'--out',str(out)]
        if jar is not None:arguments+=['--jar',str(jar)]
        if host=='windows':command=[str(PY),'-X','utf8','-B',str(READER),*arguments]
        else:
            arguments=['--packet',linux(packet),'--out',linux(out)]
            if jar is not None:arguments+=['--jar',linux(jar)]
            command=['C:/Windows/System32/wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--exec','/usr/bin/python3','-B',linux(READER),*arguments]
        p=subprocess.run(command,cwd=folder,stdin=subprocess.DEVNULL,capture_output=True,timeout=180)
        (folder/'stdout').write_bytes(p.stdout);(folder/'stderr').write_bytes(p.stderr)
        expected=0 if name=='pass' else 3 if name=='missing-archive' else 2
        assert p.returncode==expected,(host,name,p.returncode,p.stderr[-1000:])
        if name=='existing-output':assert (out/'marker').read_bytes()==b'preserve-existing-output' and len(list(out.iterdir()))==1
        elif name!='pass':assert not out.exists()
        record=dict(case=name,command=command,exit_code=p.returncode,expected=expected)
        (folder/'PROCESS.json').write_bytes(enc(record));records.append(record)
    (root/'COMPLETED.json').write_bytes(enc(dict(status='PASS_NATIVE_SAVED_READER_AND_SIX_REFUSALS',host=host,cases=records)))
    print('PASS native GSEA saved reader',host,'exact normal Jar + six refusals',flush=True)
    return host,records
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=dict(pool.map(task,['windows','linux']))
(O/'COMPLETED.json').write_bytes(enc(dict(status='PASS_PORTABLE_NATIVE_GSEA_SAVED_QUALIFICATION_AND_REFUSAL_CONTROLS',results=results)))
