# Warnings and required actions

DEVELOPMENT SNAPSHOT: qualification is limited to the controls and
editions documented in LDPRED2_WORKFLOWS_V2.md. Runtime adoption,
syntax checks and completion markers alone do not establish scientific
correctness. No full-paper reproduction, automatic chain selection
or new literature-catalog credit is claimed.

LDpred2 prepared-input workflow v2. Native Java implements inf and the
complete serial grid with R-compatible integer seeds, stream jumps and
source model ordering. Auto invokes the explicitly adopted original
bigsnpr 1.12.2 or selected1.12.4 runtime in a Linux x86-64 JVM. Missing or
forbidden prerequisites require SKIP3: skip dependent analysis, supply
the named permitted setup and retry NEW output. No runtime is installed
during analysis and no engine, method or edition is silently substituted.

Inputs must already agree in variant order, effect alleles, genome build,
population and effective sample-size definitions. Labels are caller
declarations, not independently established ancestry/build. No matching,
strand flipping, LD repair, thresholding or sample-size conversion occurs.
Full CSC uses both triangles, sorted unique rows and unit diagonals.
Numeric/input/work capacities are explicit in effective.properties.

A completed grid/auto collection can contain REJECTED source-divergent
candidates. Their raw diagnostics remain but no accepted effect file is
provided. Never replace missing values or average rejected chains.
Zero accepted candidates is FAIL2. Other analysis, verification or
recording failures invalidate the WHOLE collection, including any
earlier provisional files. Accept results only with this root's
COMPLETED.properties and successful genuine --verify recomputation.
WORKER_DONE.tsv alone is not an accepted workflow receipt.

Native/worker JVM heap and original R address-space bounds are distinct.
wall_ms and total work bytes/entries are monitored; work is not an OS
disk quota. Cancel the recorded worker/parent normally so owned children
can be stopped. Hard-killing a Windows parent has no process-job guarantee;
stop its recorded worker if needed. There is no filesystem/network
isolation or executable authenticity claim. Use permitted adequate
capacities or skip: never thin variants or split LD dependencies to fit.

Complete original auto R objects preserve source alpha NA values when
use_mle=false. Raw sampled coefficients are standardized, not allele
weights. No automatic chain averaging, phenotype tuning, best-score
selection, downstream prediction or full paper reproduction is claimed.
FAIL2: retain inputs, FAILURE.txt, runtime/worker consoles and original
diagnostics. Correct the named cause and retry NEW output paths; do not
refresh fingerprints to force verification. Use the original matching
profile/artifact to verify historical bundles.
