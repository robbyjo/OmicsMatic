from pathlib import Path
import json,subprocess
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');B=A/'build/coloc-high-impact-1';O=B/'susie-example-checks-1';O.mkdir();classes=O/'classes';classes.mkdir();jar=B/'susie-fixes-build-1/omicsmatic-0.4.0.jar';jdk=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin')
probe=A/'src/test/java/org/jlinalg/cli/ColocSusieSourceReferenceProbe.java';raw=probe.read_bytes();changed=b'\r\n' in raw
if changed:probe.write_bytes(raw.replace(b'\r\n',b'\n'))
def run(name,cmd):
 r=subprocess.run(cmd,cwd=A,capture_output=True,timeout=120);(O/(name+'.stdout')).write_bytes(r.stdout);(O/(name+'.stderr')).write_bytes(r.stderr)
 if r.returncode:print(r.stderr.decode(errors='replace')[-2500:])
 assert r.returncode==0,(name,r.returncode);print(name,r.returncode,flush=True);return dict(case=name,exit_code=0)
rows=[run('compile-example-and-probe',[str(jdk/'javac.exe'),'--release','17','-encoding','UTF-8','-cp',str(jar),'-d',str(classes),str(A/'examples/coloc-susie-native/NativeSusieVariantExample.java'),str(probe)])]
assert (classes/'org/jlinalg/cli/ColocSusieSourceReferenceProbe.class').read_bytes()==(B/'susie-fixes-tests-1/classes/org/jlinalg/cli/ColocSusieSourceReferenceProbe.class').read_bytes()
rows.append(run('api-example',[str(jdk/'java.exe'),'-cp',str(classes)+';'+str(jar),'NativeSusieVariantExample']))
assert 'PRIOR_WEIGHTED_CONDITIONAL_SNP_POSTERIOR' in (O/'api-example.stderr').read_text(encoding='utf-8')
rows.append(run('packaged-cli-example',[str(jdk/'java.exe'),'-jar',str(jar),'coloc','--trait1',str(A/'examples/coloc-susie-native/trait1.effects.tsv'),'--trait2',str(A/'examples/coloc-susie-native/trait2.effects.tsv'),'--minimum-overlap','1','--out',str(O/'example.tsv')]))
result=dict(status='PASS_NATIVE_SUSIE_PUBLIC_EXAMPLES_AND_PROBE_CLASS_IDENTITY',records=rows,new_helper_source_line_endings_normalized=changed,test_probe_class_payload_preserved=True,scientific_inputs_modified=False,new_family_credit=0,whole_goal_complete=False)
(O/'COMPLETED.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(result['status'],flush=True)
