from pathlib import Path
import hashlib,json,subprocess,zipfile
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');B=A/'build/coloc-high-impact-1';O=B/'susie-fixes-build-1';O.mkdir();classes=O/'classes';classes.mkdir();parent=B/'workflow-build-4/omicsmatic-0.4.0.jar'
names=['src/main/java/org/jlinalg/coloc/'+n+'.java' for n in ['ColocOptions','ColocSusieInput','ColocSusie','ColocSusieResult']]+['src/main/java/org/jlinalg/cli/FineMappingCli.java']
def pin(p):
 with p.open('rb') as s:return dict(bytes=p.stat().st_size,sha256=hashlib.file_digest(s,'sha256').hexdigest())
cmd=['C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/javac.exe','--release','17','-encoding','UTF-8','-cp',str(parent),'-d',str(classes),*[str(A/n) for n in names]]
r=subprocess.run(cmd,cwd=A,capture_output=True,timeout=120);(O/'javac.stdout').write_bytes(r.stdout);(O/'javac.stderr').write_bytes(r.stderr)
if r.returncode:print(r.stderr.decode(errors='replace'));raise SystemExit(r.returncode)
members={p.relative_to(classes).as_posix():p for p in classes.rglob('*.class')};assert len(members)==10,members
jar=O/'omicsmatic-0.4.0.jar';preserved=0;replaced=[]
with zipfile.ZipFile(parent) as src,zipfile.ZipFile(jar,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as dst:
 for entry in src.infolist():
  if entry.filename in members:replaced.append(entry.filename);continue
  dst.writestr(entry,src.read(entry.filename));preserved+=1
 for n,p in sorted(members.items()):dst.write(p,n)
assert set(replaced)==set(members)
with zipfile.ZipFile(parent) as src,zipfile.ZipFile(jar) as dst:
 for n in src.namelist():
  if n not in members:assert src.read(n)==dst.read(n),n
result=dict(status='COMPILED_UNQUALIFIED_SUSIE_BOUNDARY_AND_DISCLOSURE_FIXES',candidate=pin(jar),parent=pin(parent),parent_payloads_preserved=preserved,replaced_payloads=sorted(replaced),source_pins={n:pin(A/n) for n in names},compiled_payloads={n:pin(p) for n,p in sorted(members.items())},new_family_credit=0,whole_goal_complete=False)
(O/'COMPLETED.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(status=result['status'],candidate=result['candidate'],preserved=preserved,replaced=len(replaced))),flush=True)
