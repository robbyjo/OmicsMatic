from pathlib import Path
import csv,hashlib,json,math,subprocess
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');B=A/'build/coloc-high-impact-1';O=B/'susie-source-audit-1';O.mkdir();inputs=O/'inputs';inputs.mkdir();output=O/'original';output.mkdir()
cases=[]
def case(name,ids1,a,ids2,b,**settings):
 home=inputs/name;home.mkdir();cases.append(dict(name=name,settings=settings))
 for t,ids,rows in [(1,ids1,a),(2,ids2,b)]:
  weights=settings.get('weights'+str(t))
  with (home/('trait'+str(t)+'.tsv')).open('w',encoding='utf-8',newline='') as stream:
   writer=csv.writer(stream,delimiter='\t',lineterminator='\n');writer.writerow(['signal','snp','log_bf','weight'])
   for signal,values in enumerate(rows,1):
    assert len(ids)==len(values)
    for i,(snp,value) in enumerate(zip(ids,values)):writer.writerow([signal,snp,'-Inf' if value==-math.inf else format(value,'.17g'),'.' if weights is None else format(weights[i],'.17g')])
 scalar={k:v for k,v in settings.items() if not k.startswith('weights')}
 with (home/'settings.tsv').open('w',encoding='utf-8',newline='') as stream:
  writer=csv.writer(stream,delimiter='\t',lineterminator='\n');writer.writerow(['key','value']);writer.writerows(scalar.items())
ids=['a','b','c'];a=[[2,-1,.5]];b=[[1,.2,-.5]]
case('ordinary-single',ids,a,ids,b)
case('ordinary-multiple',ids,a+[[0,3,1]],ids,b+[[.2,0,4]])
case('partial-permuted',['a','b','c','d'],[[2,1,.5,-1]],['c','a','e'],[[1,.5,-1]],overlap=0,trim=False)
case('overlap-partial-drop',['a','b','c'],[[8,0,0],[0,8,0]],['b','c','d'],[[0,0,8],[8,0,0]])
case('overlap-all-drop',['a','b','c'],[[10,0,0]],['b','c','d'],[[0,0,10]])
case('overlap-boundary-one',ids,a,ids,b,overlap=1)
case('one-sided-weight',ids,a,ids,b,weights1=[1,2,3])
case('both-weighted',ids,a,ids,b,weights1=[1,2,3],weights2=[3,1,2])
case('weighted-partial',['a','b','c','d'],[[2,1,.5,-1]],['c','a','e'],[[1,.5,-1]],weights1=[1,2,3,4],weights2=[3,1,2],overlap=0,trim=False)
case('large-weights',ids,a,ids,b,weights1=[5e307,1e308,1.5e308],weights2=[3,1,2])
case('small-weights',ids,a,ids,b,weights1=[1e-300,2e-300,3e-300],weights2=[3,1,2])
case('dominant-shared',['a','b'],[[1000,950]],['a','b'],[[1000,950]])
case('disjoint-shared-support',['a','b'],[[100,-math.inf]],['a','b'],[[-math.inf,100]],trim=False)
case('explicit-null-last',['a','b','null'],[[2,-1,0]],['a','b','null'],[[1,.2,0]])
case('null-not-last',['a','null','b'],[[2,0,-1]],['b','a','null'],[[.2,1,0]])
case('nonzero-null-baseline',['a','b','null'],[[5.2,2.2,3.2]],['a','b','null'],[[-4,-4.8,-5]])
case('only-null',['null'],[[0]],['null'],[[0]])
case('no-common',['a'],[[1]],['b'],[[1]])
case('zero-weight',ids,a,ids,b,weights1=[1,0,3])
case('shared-prior-above-trait',ids,a,ids,b,p12=.003)
case('high-priors',ids,a,ids,b,p1=.4,p2=.3,p12=.2)
case('unicode-order',['α',' a ','😀'],a,['😀','α',' a '],b)
case('single-variant',['a'],[[2]],['a'],[[1]])
case('no-common-signal-support',['a','b','c'],[[-math.inf,-math.inf,10]],['a','b','d'],[[1,.2,0]],overlap=0,trim=False)
fixture=A/'src/test/resources/r-reference/coloc-susie-example.tsv'
with fixture.open(encoding='utf-8') as stream:rows=list(csv.DictReader((l for l in stream if not l.startswith('#')),delimiter='\t'))
oldids=[r['snp'] for r in rows]
case('bundled-D1-D2',oldids,[[float(r['D1.L1']) for r in rows]],oldids,[[float(r['D2.L1']) for r in rows]])
case('bundled-D3-D4',oldids,[[float(r['D3.L1']) for r in rows],[float(r['D3.L2']) for r in rows]],oldids,[[float(r['D4.L1']) for r in rows]])
(inputs/'cases.tsv').write_text('name\n'+''.join(c['name']+'\n' for c in cases),encoding='utf-8')
(O/'DESIGN.json').write_text(json.dumps(dict(status='ORIGINAL_SOURCE_AUDIT_DESIGN_ONLY',cases=cases,original_fits_planned=['D1-D2','D3-D4'],new_family_credit=0),indent=2)+'\n',encoding='utf-8')
script=r'''
args<-commandArgs(TRUE); input<-args[1];output<-args[2];lib<-args[3];deps<-args[4];source<-args[5]
.libPaths(c(lib,deps,.libPaths()));stopifnot(as.character(packageVersion("coloc"))=="6.0.3")
stopifnot(nzchar(Sys.setlocale("LC_CTYPE","English_United States.utf8")));Sys.setlocale("LC_COLLATE","C")
original<-new.env(parent=asNamespace("coloc"))
for(file in c("R/claudia.R","R/check.R","R/susie.R"))sys.source(file.path(source,file),envir=original,keep.source=FALSE)
functions<-c("coloc.susie","coloc.bf_bf","logbf_to_pp","combine.abf","combine_abf_weighted","runsusie","annotate_susie")
for(name in functions){
 installed<-get(name,envir=asNamespace("coloc"));expected<-get(name,envir=original)
 stopifnot(identical(deparse(body(installed)),deparse(body(expected))),identical(formals(installed),formals(expected)))
 writeLines(capture.output(dput(installed)),file.path(output,paste0("function-",name,".R")))
}
writeLines(capture.output(sessionInfo()),file.path(output,"SESSION.txt"))
tab<-function(x,p){
 for(n in names(x))if(is.numeric(x[[n]]))x[[n]]<-sprintf("%.17g",x[[n]])
 write.table(x,p,sep="\t",row.names=FALSE,quote=TRUE,na="NA",fileEncoding="UTF-8")
}
read<-function(p)read.delim(p,check.names=FALSE,stringsAsFactors=FALSE,encoding="UTF-8",comment.char="",quote="\"")
matrix_in<-function(path){
 d<-read(path);ids<-unique(enc2utf8(d$snp));signals<-unique(d$signal)
 bf<-matrix(NA_real_,length(signals),length(ids),dimnames=list(as.character(signals),ids))
 for(i in seq_len(nrow(d)))bf[match(d$signal[i],signals),match(d$snp[i],ids)]<-d$log_bf[i]
 stopifnot(!anyNA(bf));w<-if(all(d$weight=="."))NULL else as.numeric(d$weight[match(ids,d$snp)])
 list(bf=bf,w=w)
}
capture<-function(dest,fun){
 dir.create(dest);warnings<-character();error<-NULL
 result<-tryCatch(withCallingHandlers(fun(),warning=function(w){warnings<<-c(warnings,conditionMessage(w));invokeRestart("muffleWarning")}),error=function(e){error<<-conditionMessage(e);NULL})
 writeLines(warnings,file.path(dest,"warnings.txt"))
 if(is.null(result)){writeLines(c("ERROR",error),file.path(dest,"STATUS.txt"));return(invisible(NULL))}
 saveRDS(result,file.path(dest,"result.rds"),version=3)
 if(is.null(result$summary)){tab(as.data.frame(result),file.path(dest,"returned-table.tsv"));writeLines("NO_POSTERIOR_LIST",file.path(dest,"STATUS.txt"));return(invisible(result))}
 tab(as.data.frame(result$summary),file.path(dest,"pairs.tsv"))
 if(!is.null(result$results))tab(as.data.frame(result$results),file.path(dest,"variants.tsv"))
 if(!is.null(result$priors))tab(data.frame(field=names(result$priors),value=as.numeric(result$priors)),file.path(dest,"priors.tsv"))
 pp<-grep("^PP.H",names(result$summary),value=TRUE)
 finite<-length(pp)==5&&all(is.finite(as.matrix(result$summary[,..pp])))&&!is.null(result$results)&&all(is.finite(as.matrix(result$results[,setdiff(names(result$results),"snp"),with=FALSE])))
 writeLines(if(finite)"FINITE" else "NONFINITE_OR_MISSING_POSTERIOR_NO_RESULT_ADMITTED",file.path(dest,"STATUS.txt"));invisible(result)
}
cases<-read(file.path(input,"cases.tsv"))
for(name in cases$name){
 cat("CASE ",name,"\n",sep="");one<-matrix_in(file.path(input,name,"trait1.tsv"));two<-matrix_in(file.path(input,name,"trait2.tsv"))
 settings<-read(file.path(input,name,"settings.tsv"));s<-setNames(as.list(settings$value),settings$key)
 capture(file.path(output,name),function(){
  call<-list(bf1=one$bf,bf2=two$bf,prior_weights1=one$w,prior_weights2=two$w)
  for(k in c("p1","p2","p12"))if(!is.null(s[[k]]))call[[k]]<-as.numeric(s[[k]])
  if(!is.null(s$overlap))call$overlap.min<-as.numeric(s$overlap)
  if(!is.null(s$trim))call$trim_by_posterior<-identical(s$trim,"True")
  do.call(coloc::coloc.bf_bf,call)
 })
}
data("coloc_test_data",package="coloc")
for(pair in list(c("D1","D2"),c("D3","D4"))){
 name<-paste0("original-fitted-",paste(pair,collapse="-"));dest<-file.path(output,name)
 capture(dest,function(){
  fits<-lapply(pair,function(k)coloc::runsusie(coloc_test_data[[k]],maxit=500,repeat_until_convergence=FALSE,L=5,estimate_prior_variance=FALSE,prior_variance=.2,estimate_residual_variance=FALSE))
  for(t in 1:2){
   fit<-fits[[t]];saveRDS(fit,file.path(dest,paste0("fit",t,".rds")),version=3)
   idx<-fit$sets$cs_index;bf<-fit$lbf_variable[idx,,drop=FALSE]
   d<-do.call(rbind,lapply(seq_len(nrow(bf)),function(i)data.frame(signal=idx[i],snp=colnames(bf),log_bf=bf[i,],weight=".")))
   tab(d,file.path(dest,paste0("fitted-trait",t,".tsv")))
  }
  coloc::coloc.susie(fits[[1]],fits[[2]])
 })
}
writeLines("ORIGINAL_FUNCTION_AUDIT_CAPTURE_COMPLETE",file.path(output,"CAPTURE_COMPLETE.txt"))
'''
(O/'capture-original.R').write_text(script,encoding='utf-8')
cmd=['C:/Program Files/R/R-4.6.1/bin/Rscript.exe','--vanilla',str(O/'capture-original.R'),str(inputs),str(output),str(B/'runtime-coloc603-2/library'),str(B/'runtime-coloc603-1/library'),str(B/'upstream-coloc603-intake-1/source')]
with (O/'R.stdout').open('xb') as so,(O/'R.stderr').open('xb') as se:r=subprocess.run(cmd,cwd=A,stdout=so,stderr=se,timeout=300)
print('Original R audit exit',r.returncode,flush=True)
if r.returncode:print((O/'R.stderr').read_text(errors='replace')[-3500:]);raise SystemExit(r.returncode)
assert (output/'CAPTURE_COMPLETE.txt').exists();statuses={p.parent.name:p.read_text(encoding='utf-8').strip() for p in output.glob('*/STATUS.txt')}
result=dict(status='CAPTURED_PINNED_ORIGINAL_BF_BF_AND_SUSIE_FITS_FOR_AUDIT',cases=len(statuses),records=statuses,selected_installed_function_bodies_and_formals_match_exact_source=True,original_program_executed=True,project_method_qualified=False,new_family_credit=0,whole_goal_complete=False)
(O/'COMPLETED.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result),flush=True)
