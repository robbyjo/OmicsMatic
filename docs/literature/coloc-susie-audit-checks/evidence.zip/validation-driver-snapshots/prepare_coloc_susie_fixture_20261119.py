from pathlib import Path
import hashlib,json,zipfile
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');B=A/'build/coloc-high-impact-1';P=B/'susie-source-audit-1';C=B/'susie-source-compare-1';O=B/'susie-source-fixture-1';O.mkdir()
probe=(C/'LegacyColocSusieAuditProbe.java').read_text(encoding='utf-8').replace('LegacyColocSusieAuditProbe','ColocSusieSourceReferenceProbe')
old='Files.writeString(dest.resolve("STATUS.txt"),"0\\n");'
new='Files.write(dest.resolve("warnings.txt"),result.warnings(),StandardCharsets.UTF_8);Files.writeString(dest.resolve("STATUS.txt"),"0\\n");'
assert old in probe;probe=probe.replace(old,new)
public=A/'src/test/java/org/jlinalg/cli/ColocSusieSourceReferenceProbe.java';public.write_text('/* Copyright (C) 2026 JLinAlg contributors; SPDX-License-Identifier: GPL-3.0-or-later */\n'+probe,encoding='utf-8')
members={}
for folder,label in [(C/'inputs','inputs'),(P/'original','original')]:
 for p in folder.rglob('*'):
  if p.is_file():members[label+'/'+p.relative_to(folder).as_posix()]=p.read_bytes()
for p,name in [(P/'DESIGN.json','CAPTURE-DESIGN.json'),(P/'capture-original.R','capture-original.R'),(P/'COMPLETED.json','CAPTURE-COMPLETED.json'),(C/'COMPLETED.json','LEGACY-COMPARISON.json'),(B/'upstream-coloc603-intake-1/COMPLETED.json','SOURCE.json')]:members[name]=p.read_bytes()
members['README.txt']=('Synthetic original-package source audit, not blanket native parity.\n'
 'Original coloc 6.0.3 commit 27776b1bb14e19d1542798ac7477fa378fc2fc0d; GPL.\n'
 '26 supplied-BF cases plus two actual original runsusie/coloc.susie fit pairs.\n'
 'Selected seven installed function bodies and formals matched exact source.\n'
 'CAPTURE statuses describe finite fields only. The single-variant source output\n'
 'is finite but NOT a normalized hypothesis distribution; it is retained, not\n'
 'repaired or admitted as a scientific oracle. Nonfinite/no-posterior cases\n'
 'also remain unadmitted. Legacy-comparison results describe the old candidate.\n'
 'New tests explicitly distinguish source-matching profiles, documented stable\n'
 'method variants and invalid/unsupported inputs. No independent native SuSiE\n'
 'fit parity, whole-tool/historical-edition or original-paper claim.\n').encode()
target=A/'src/test/resources/org/jlinalg/coloc/susie-original603-audit.zip'
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for n,raw in sorted(members.items()):archive.writestr(n,raw)
result=dict(status='FROZEN_ORIGINAL_SUSIE_SOURCE_AUDIT_FIXTURE',members=len(members),fixture=dict(bytes=target.stat().st_size,sha256=hashlib.sha256(target.read_bytes()).hexdigest()),source_capture=str(P),whole_goal_complete=False,new_family_credit=0)
(O/'COMPLETED.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result),flush=True)
