from pathlib import Path
import csv,hashlib,json,math,shutil,subprocess
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');B=A/'build/coloc-high-impact-1';P=B/'susie-source-audit-1';O=B/'susie-source-compare-1';O.mkdir();inputs=O/'inputs';shutil.copytree(P/'inputs',inputs);dest=O/'native'
for source in (P/'original').glob('original-fitted-*'):
 home=inputs/source.name;home.mkdir()
 for t in [1,2]:shutil.copyfile(source/('fitted-trait'+str(t)+'.tsv'),home/('trait'+str(t)+'.tsv'))
 (home/'settings.tsv').write_text('key\tvalue\n',encoding='utf-8')
names=sorted(p.name for p in inputs.iterdir() if p.is_dir());(inputs/'cases.tsv').write_text('name\n'+''.join(n+'\n' for n in names),encoding='utf-8')
source=r'''
package org.jlinalg.cli;
import java.nio.file.*;import java.nio.charset.StandardCharsets;import java.util.*;import org.jlinalg.coloc.*;
public final class LegacyColocSusieAuditProbe {
 record Data(ColocSusieInput input,double[] weights){}
 static Data read(Path p)throws Exception {
  var table=DelimitedData.read(p);int signal=table.column("signal"),snp=table.column("snp"),bf=table.column("log_bf"),weight=table.column("weight");
  var rows=new LinkedHashMap<Integer,LinkedHashMap<String,Double>>();var weights=new LinkedHashMap<String,String>();
  for(var row:table.rows()){
   int idx=Integer.parseInt(row[signal]);var values=rows.computeIfAbsent(idx,k->new LinkedHashMap<>());
   if(values.put(row[snp],row[bf].equals("-Inf")?Double.NEGATIVE_INFINITY:Double.parseDouble(row[bf]))!=null)throw new IllegalArgumentException("duplicate row");
   String prior=weights.putIfAbsent(row[snp],row[weight]);if(prior!=null&&!prior.equals(row[weight]))throw new IllegalArgumentException("inconsistent weights");
  }
  var ids=List.copyOf(weights.keySet());double[] lbf=new double[rows.size()*ids.size()];int[] indices=new int[rows.size()];int k=0;
  for(var entry:rows.entrySet()){
   if(!new ArrayList<>(entry.getValue().keySet()).equals(ids))throw new IllegalArgumentException("inconsistent matrix population/order");
   indices[k]=entry.getKey()-1;for(int j=0;j<ids.size();j++)lbf[k*ids.size()+j]=entry.getValue().get(ids.get(j));k++;
  }
  double[] w=weights.values().stream().allMatch("."::equals)?null:new double[ids.size()];if(w!=null)for(int j=0;j<ids.size();j++)w[j]=Double.parseDouble(weights.get(ids.get(j)));
  return new Data(new ColocSusieInput(ids,lbf,indices),w);
 }
 public static void main(String[] args)throws Exception {
  Path input=Path.of(args[0]),out=Path.of(args[1]);Files.createDirectory(out);
  for(String name:Files.readAllLines(input.resolve("cases.tsv"),StandardCharsets.UTF_8).subList(1,Files.readAllLines(input.resolve("cases.tsv"),StandardCharsets.UTF_8).size())){
   Path home=input.resolve(name),dest=out.resolve(name);Files.createDirectory(dest);
   try{
    var s=new HashMap<String,String>();for(var row:DelimitedData.readResult(home.resolve("settings.tsv")).rows())s.put(row[0],row[1]);
    var a=read(home.resolve("trait1.tsv"));var b=read(home.resolve("trait2.tsv"));
    var options=new ColocOptions(Double.parseDouble(s.getOrDefault("p1","1e-4")),Double.parseDouble(s.getOrDefault("p2","1e-4")),Double.parseDouble(s.getOrDefault("p12","5e-6")),Double.parseDouble(s.getOrDefault("overlap","0.5")),Boolean.parseBoolean(s.getOrDefault("trim","True")),a.weights(),b.weights());
    var result=ColocSusie.analyze(a.input(),b.input(),options);
    var pairs=new StringBuilder("nsnps\thit1\thit2\tPP.H0.abf\tPP.H1.abf\tPP.H2.abf\tPP.H3.abf\tPP.H4.abf\tidx1\tidx2\n");
    for(var pair:result.signalPairs()){
     pairs.append(pair.variants()).append('\t').append(pair.trait1LeadVariant()).append('\t').append(pair.trait2LeadVariant());
     for(double pp:pair.hypothesisPosteriors())pairs.append('\t').append(pp);pairs.append('\t').append(pair.trait1EffectIndex()+1).append('\t').append(pair.trait2EffectIndex()+1).append('\n');
    }
    Files.writeString(dest.resolve("pairs.tsv"),pairs,StandardCharsets.UTF_8);
    var variants=new StringBuilder("snp");for(int k=0;k<result.signalPairs().size();k++)variants.append('\t').append(result.signalPairs().size()==1?"SNP.PP.H4.abf":"SNP.PP.H4.row"+(k+1));variants.append('\n');
    for(int j=0;j<result.commonVariants().size();j++){
     variants.append(result.commonVariants().get(j));for(int k=0;k<result.signalPairs().size();k++)variants.append('\t').append(result.sharedVariantPosterior(k)[j]);variants.append('\n');
    }
    Files.writeString(dest.resolve("variants.tsv"),variants,StandardCharsets.UTF_8);Files.writeString(dest.resolve("STATUS.txt"),"0\n");
   }catch(Exception e){Files.writeString(dest.resolve("ERROR.txt"),e.toString()+"\n");Files.writeString(dest.resolve("STATUS.txt"),"2\n");}
  }
 }
}
'''
(O/'LegacyColocSusieAuditProbe.java').write_text(source,encoding='utf-8');classes=O/'classes';classes.mkdir();jar=B/'workflow-build-4/omicsmatic-0.4.0.jar';jdk=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin')
for name,cmd in [('compile',[str(jdk/'javac.exe'),'--release','17','-encoding','UTF-8','-cp',str(jar),'-d',str(classes),str(O/'LegacyColocSusieAuditProbe.java')]),('native',[str(jdk/'java.exe'),'-Xmx512m','-cp',str(classes)+';'+str(jar),'org.jlinalg.cli.LegacyColocSusieAuditProbe',str(inputs),str(dest)])]:
 r=subprocess.run(cmd,cwd=A,capture_output=True,timeout=120);(O/(name+'.stdout')).write_bytes(r.stdout);(O/(name+'.stderr')).write_bytes(r.stderr)
 if r.returncode:print(r.stderr.decode(errors='replace'));raise SystemExit(r.returncode)
def table(p):
 with p.open(encoding='utf-8',newline='') as stream:return list(csv.DictReader(stream,delimiter='\t'))
records=[]
for name in names:
 expected=P/'original'/name;actual=dest/name;status=(expected/'STATUS.txt').read_text(encoding='utf-8').strip();code=int((actual/'STATUS.txt').read_text().strip());differences=[];count=0;maxabs=0;maxrel=0
 if status=='FINITE' and code==0:
  for filename in ['pairs.tsv','variants.tsv']:
   a=table(actual/filename);b=table(expected/filename)
   if len(a)!=len(b):differences.append(dict(file=filename,kind='row-population',native=len(a),original=len(b)));continue
   for i,(x,y) in enumerate(zip(a,b),1):
    if x.keys()!=y.keys():differences.append(dict(file=filename,kind='column-population'));break
    for key,value in y.items():
     if key in ['snp','hit1','hit2','nsnps','idx1','idx2']:
      if x[key]!=value:differences.append(dict(file=filename,row=i,column=key,kind='identity-or-count',native=x[key],original=value))
     else:
      u,v=float(x[key]),float(value);count+=1;absolute=abs(u-v);relative=absolute/max(abs(u),abs(v)) if u!=v else 0;maxabs=max(maxabs,absolute);maxrel=max(maxrel,relative)
      equal=u==v or math.isfinite(u) and math.isfinite(v) and u!=0 and v!=0 and absolute<=max(16*math.ulp(v),2e-12*abs(v))
      if not equal:differences.append(dict(file=filename,row=i,column=key,kind='zero-support' if (u==0)!=(v==0) else 'numeric',native=u,original=v))
  outcome='MATCH_WITHIN_DECLARED_NUMERIC_TOLERANCE' if not differences else 'SEMANTIC_OR_NUMERIC_DIFFERENCE_RETAINED'
 elif status.startswith('ERROR') and code==2:outcome='BOTH_REFUSED_INVALID_INPUT'
 elif status=='FINITE' and code==2:outcome='NATIVE_REJECTS_UPSTREAM_FINITE_INPUT';differences.append(dict(error=(actual/'ERROR.txt').read_text().strip()))
 else:outcome='UPSTREAM_HAS_NO_ADMISSIBLE_POSTERIOR_NATIVE_STATE_RETAINED'
 records.append(dict(case=name,outcome=outcome,original_status=status,native_exit=code,compared_numeric_fields=count,maximum_absolute_difference=maxabs,maximum_relative_difference=maxrel,difference_count=len(differences),differences=differences))
 print(name,outcome,len(differences),flush=True)
result=dict(status='COMPLETED_ORIGINAL_VS_LEGACY_NATIVE_AUDIT_NO_PARITY_ASSUMED',cases=len(records),records=records,new_family_credit=0,whole_goal_complete=False)
(O/'COMPLETED.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8');print(json.dumps(dict(cases=len(records),matched=sum(r['outcome'].startswith('MATCH') for r in records),different=sum(r['outcome']=='SEMANTIC_OR_NUMERIC_DIFFERENCE_RETAINED' for r in records))),flush=True)
