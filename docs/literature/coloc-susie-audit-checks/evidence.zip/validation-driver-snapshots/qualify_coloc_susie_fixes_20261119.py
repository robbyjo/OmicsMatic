from pathlib import Path
import csv,hashlib,json,os,subprocess,xml.etree.ElementTree as ET
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');B=A/'build/coloc-high-impact-1';O=B/'susie-fixes-qualification-1';O.mkdir();jar=B/'susie-fixes-build-1/omicsmatic-0.4.0.jar';prior=B/'susie-fixes-tests-1';classes=prior/'classes';junit=A/'build/nfcore-atacseq121-1/linux-test-runtime-1/junit-platform-console-standalone-1.13.4.jar'
java21=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin/java.exe');java25=Path('C:/Program Files/Java/jdk-25/bin/java.exe');py='C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
def linux(p):return '/mnt/d/'+str(p).replace('\\','/').split(':/',1)[1]
def run(name,cmd,code=0):
 with (O/(name+'.stdout')).open('xb') as so,(O/(name+'.stderr')).open('xb') as se:r=subprocess.run(cmd,cwd=A,stdout=so,stderr=se,timeout=240)
 if r.returncode!=code:print((O/(name+'.stdout')).read_text(errors='replace')[-3500:]);print((O/(name+'.stderr')).read_text(errors='replace')[-2000:])
 assert r.returncode==code,(name,r.returncode,code);print(name,r.returncode,flush=True);return dict(case=name,exit_code=r.returncode,expected_exit=code)
win=json.loads((prior/'COMPLETED.json').read_bytes());assert win['exit_code']==0 and win['counts']['tests']=='50';tests=[dict(host='windows21',exit_code=0,counts=win['counts'])];rows=[]
for host,prefix,cp in [('windows25',[str(java25)],os.pathsep.join(map(str,[classes,jar,A/'src/test/resources']))),('linux21',['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/java'],':'.join(linux(p) for p in [classes,jar,A/'src/test/resources']))]:
 tmp=O/(host+'-tmp');tmp.mkdir();native=lambda p:str(p) if host=='windows25' else linux(p)
 cmd=prefix+['-Xmx768m','-Djava.io.tmpdir='+native(tmp),'-Djunit.jupiter.tempdir.cleanup.mode.default=NEVER','-jar',native(junit),'execute','--class-path',cp]
 for selected in win['selected']:cmd+=['--select-class',selected]
 cmd+=['--reports-dir',native(O/(host+'-reports')),'--details','summary','--fail-if-no-tests'];rows.append(run(host+'-junit',cmd))
 counts=ET.parse(O/(host+'-reports/TEST-junit-jupiter.xml')).getroot().attrib;assert counts['tests']=='50' and all(counts[k]=='0' for k in ['skipped','failures','errors']);tests.append(dict(host=host,exit_code=0,counts=counts))
for host,prefix in [('windows21',[str(java21)]),('windows25',[str(java25)]),('linux21',['wsl.exe','-d','JLinAlg-Omics-SAIGE-20261026','--','/usr/bin/java'])]:
 home=O/(host+'-packaged');home.mkdir();native=lambda p:str(p) if host!='linux21' else linux(p)
 for t in [1,2]:(home/('trait'+str(t)+'.tsv')).write_text('effect_index\tvariant_id\tlog_bayes_factor\n1\t a \t2\n1\ta\t-1\n1\tα😀\t0.5\n',encoding='utf-8')
 cmd=prefix+['-Xmx512m','-jar',native(jar),'coloc','--trait1',native(home/'trait1.tsv'),'--trait2',native(home/'trait2.tsv'),'--minimum-overlap','1','--shared-prior','.003','--out',native(home/'pairs.tsv')]
 rows.append(run(host+'-packaged-boundary-prior-ids',cmd));assert len((home/'pairs.tsv').read_text(encoding='utf-8').splitlines())==2
 assert 'NATIVE_STABLE_COLOC_VARIANT' in (O/(host+'-packaged-boundary-prior-ids.stderr')).read_text(encoding='utf-8')
 assert '\t a \t' in (home/'pairs.tsv.variants.tsv').read_text(encoding='utf-8')
 for f,text in [('undefined1.tsv','effect_index\tvariant_id\tlog_bayes_factor\n1\ta\t100\n1\tb\t-Infinity\n'),('undefined2.tsv','effect_index\tvariant_id\tlog_bayes_factor\n1\ta\t-Infinity\n1\tb\t100\n')]: (home/f).write_text(text,encoding='utf-8')
 rows.append(run(host+'-packaged-undefined-refusal',prefix+['-jar',native(jar),'coloc','--trait1',native(home/'undefined1.tsv'),'--trait2',native(home/'undefined2.tsv'),'--no-trim','--out',native(home/'undefined.tsv')],2));assert not (home/'undefined.tsv').exists() and not (home/'undefined.tsv.variants.tsv').exists()
for script,label in [('verify_coloc_abf_handover.py','abf-component'),('verify_coloc_abf_workflow.py','abf-workflow')]:
 rows.append(run(label+'-readback',[py,'-X','utf8','-B',str(A/'tools/literature'/script),'--out',str(O/(label+'-readback'))]))
rows.append(run('old-abf-bundle-scientific-verify',[str(java21),'-jar',str(jar),'coloc-abf','--verify',str(B/'workflow-qualification-1/windows21-packaged/analysis')]))
source=B/'susie-source-audit-1/original/single-variant/pairs.tsv'
with source.open(encoding='utf-8',newline='') as stream:record=next(csv.DictReader(stream,delimiter='\t'))
single=sum(float(record['PP.H'+str(h)+'.abf']) for h in range(5));assert single>2
with jar.open('rb') as stream:jarpin=dict(bytes=jar.stat().st_size,sha256=hashlib.file_digest(stream,'sha256').hexdigest())
result=dict(status='PASS_SUSIE_SOURCE_AUDIT_FIXES_THREE_JVMS_PACKAGED_AND_ABF_COMPATIBILITY',candidate=jarpin,tests=tests,processes=rows,
 source_profiles=dict(total=28,complete_source_matching=12,weighted_regional_only=4,stable_H3_difference=1,single_variant_source_invalid_simplex=1,explicit_null_refusals=4,upstream_no_admissible_posterior_other_profiles=5,both_refuse_zero_weight=1),
 original_single_variant_hypothesis_sum=single,original_R_reexecuted_in_qualification=False,new_family_credit=0,whole_goal_complete=False)
(O/'COMPLETED.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(result['status'],flush=True)
