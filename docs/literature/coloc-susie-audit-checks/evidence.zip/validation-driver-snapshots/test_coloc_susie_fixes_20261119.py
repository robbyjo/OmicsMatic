from pathlib import Path
import json,os,subprocess,xml.etree.ElementTree as ET
A=Path('D:/projects/JLinAlg/build/high-impact-stats-1');B=A/'build/coloc-high-impact-1';O=B/'susie-fixes-tests-1';O.mkdir();classes=O/'classes';classes.mkdir();tmp=O/'tmp';tmp.mkdir()
jar=B/'susie-fixes-build-1/omicsmatic-0.4.0.jar';junit=A/'build/nfcore-atacseq121-1/linux-test-runtime-1/junit-platform-console-standalone-1.13.4.jar';jdk=Path('C:/Program Files/Eclipse Adoptium/jdk-21.0.4.7-hotspot/bin')
names=['src/test/java/org/jlinalg/cli/'+n+'.java' for n in ['ColocSusieSourceReferenceProbe','ColocSusieSourceAuditTest','FineMappingCliTest','RunLogTest']]+['src/test/java/org/jlinalg/coloc/'+n+'.java' for n in ['ColocSusieTest','ColocAuditBoundaryTest']]
cmd=[str(jdk/'javac.exe'),'--release','17','-encoding','UTF-8','-cp',os.pathsep.join(map(str,[jar,junit])),'-d',str(classes),*[str(A/n) for n in names]]
r=subprocess.run(cmd,cwd=A,capture_output=True,timeout=120);(O/'javac.stdout').write_bytes(r.stdout);(O/'javac.stderr').write_bytes(r.stderr)
if r.returncode:print(r.stderr.decode(errors='replace'));raise SystemExit(r.returncode)
selected=['org.jlinalg.cli.ColocSusieSourceAuditTest','org.jlinalg.coloc.ColocSusieTest','org.jlinalg.coloc.ColocAuditBoundaryTest','org.jlinalg.cli.FineMappingCliTest']
cmd=[str(jdk/'java.exe'),'-Xmx768m','-Djava.io.tmpdir='+str(tmp),'-Djunit.jupiter.tempdir.cleanup.mode.default=NEVER','-jar',str(junit),'execute','--class-path',os.pathsep.join(map(str,[classes,jar,A/'src/test/resources']))]
for name in selected:cmd.extend(['--select-class',name])
cmd+=['--reports-dir',str(O/'windows21-reports'),'--details','summary','--fail-if-no-tests']
with (O/'windows21.stdout').open('xb') as so,(O/'windows21.stderr').open('xb') as se:r=subprocess.run(cmd,cwd=A,stdout=so,stderr=se,timeout=240)
print((O/'windows21.stdout').read_text(encoding='utf-8',errors='replace')[-6000:]);print((O/'windows21.stderr').read_text(encoding='utf-8',errors='replace')[-1000:])
report=O/'windows21-reports/TEST-junit-jupiter.xml';counts=ET.parse(report).getroot().attrib if report.exists() else {}
result=dict(status='PASS_WINDOWS21_SUSIE_SOURCE_AUDIT_BOUNDARIES_AND_REGRESSION' if r.returncode==0 else 'FAILED_RETAINED',exit_code=r.returncode,counts=counts,selected=selected,original_R_reexecuted=False,new_family_credit=0,whole_goal_complete=False)
(O/'COMPLETED.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result));raise SystemExit(r.returncode)
