
args<-commandArgs(TRUE); input<-args[1];output<-args[2];lib<-args[3];deps<-args[4];source<-args[5]
.libPaths(c(lib,deps,.libPaths()));stopifnot(as.character(packageVersion("coloc"))=="6.0.3")
stopifnot(nzchar(Sys.setlocale("LC_CTYPE","English_United States.utf8")));Sys.setlocale("LC_COLLATE","C")
original<-new.env(parent=asNamespace("coloc"))
for(file in c("R/claudia.R","R/check.R","R/susie.R"))sys.source(file.path(source,file),envir=original,keep.source=FALSE)
functions<-c("coloc.susie","coloc.bf_bf","logbf_to_pp","combine.abf","combine_abf_weighted","runsusie","annotate_susie")
for(name in functions){
 installed<-get(name,envir=asNamespace("coloc"));expected<-get(name,envir=original)
 stopifnot(identical(deparse(body(installed)),deparse(body(expected))),identical(formals(installed),formals(expected)))
 writeLines(capture.output(dput(installed)),file.path(output,paste0("function-",name,".R")))
}
writeLines(capture.output(sessionInfo()),file.path(output,"SESSION.txt"))
tab<-function(x,p){
 for(n in names(x))if(is.numeric(x[[n]]))x[[n]]<-sprintf("%.17g",x[[n]])
 write.table(x,p,sep="\t",row.names=FALSE,quote=TRUE,na="NA",fileEncoding="UTF-8")
}
read<-function(p)read.delim(p,check.names=FALSE,stringsAsFactors=FALSE,encoding="UTF-8",comment.char="",quote="\"")
matrix_in<-function(path){
 d<-read(path);ids<-unique(enc2utf8(d$snp));signals<-unique(d$signal)
 bf<-matrix(NA_real_,length(signals),length(ids),dimnames=list(as.character(signals),ids))
 for(i in seq_len(nrow(d)))bf[match(d$signal[i],signals),match(d$snp[i],ids)]<-d$log_bf[i]
 stopifnot(!anyNA(bf));w<-if(all(d$weight=="."))NULL else as.numeric(d$weight[match(ids,d$snp)])
 list(bf=bf,w=w)
}
capture<-function(dest,fun){
 dir.create(dest);warnings<-character();error<-NULL
 result<-tryCatch(withCallingHandlers(fun(),warning=function(w){warnings<<-c(warnings,conditionMessage(w));invokeRestart("muffleWarning")}),error=function(e){error<<-conditionMessage(e);NULL})
 writeLines(warnings,file.path(dest,"warnings.txt"))
 if(is.null(result)){writeLines(c("ERROR",error),file.path(dest,"STATUS.txt"));return(invisible(NULL))}
 saveRDS(result,file.path(dest,"result.rds"),version=3)
 if(is.null(result$summary)){tab(as.data.frame(result),file.path(dest,"returned-table.tsv"));writeLines("NO_POSTERIOR_LIST",file.path(dest,"STATUS.txt"));return(invisible(result))}
 tab(as.data.frame(result$summary),file.path(dest,"pairs.tsv"))
 if(!is.null(result$results))tab(as.data.frame(result$results),file.path(dest,"variants.tsv"))
 if(!is.null(result$priors))tab(data.frame(field=names(result$priors),value=as.numeric(result$priors)),file.path(dest,"priors.tsv"))
 pp<-grep("^PP.H",names(result$summary),value=TRUE)
 finite<-length(pp)==5&&all(is.finite(as.matrix(result$summary[,..pp])))&&!is.null(result$results)&&all(is.finite(as.matrix(result$results[,setdiff(names(result$results),"snp"),with=FALSE])))
 writeLines(if(finite)"FINITE" else "NONFINITE_OR_MISSING_POSTERIOR_NO_RESULT_ADMITTED",file.path(dest,"STATUS.txt"));invisible(result)
}
cases<-read(file.path(input,"cases.tsv"))
for(name in cases$name){
 cat("CASE ",name,"\n",sep="");one<-matrix_in(file.path(input,name,"trait1.tsv"));two<-matrix_in(file.path(input,name,"trait2.tsv"))
 settings<-read(file.path(input,name,"settings.tsv"));s<-setNames(as.list(settings$value),settings$key)
 capture(file.path(output,name),function(){
  call<-list(bf1=one$bf,bf2=two$bf,prior_weights1=one$w,prior_weights2=two$w)
  for(k in c("p1","p2","p12"))if(!is.null(s[[k]]))call[[k]]<-as.numeric(s[[k]])
  if(!is.null(s$overlap))call$overlap.min<-as.numeric(s$overlap)
  if(!is.null(s$trim))call$trim_by_posterior<-identical(s$trim,"True")
  do.call(coloc::coloc.bf_bf,call)
 })
}
data("coloc_test_data",package="coloc")
for(pair in list(c("D1","D2"),c("D3","D4"))){
 name<-paste0("original-fitted-",paste(pair,collapse="-"));dest<-file.path(output,name)
 capture(dest,function(){
  fits<-lapply(pair,function(k)coloc::runsusie(coloc_test_data[[k]],maxit=500,repeat_until_convergence=FALSE,L=5,estimate_prior_variance=FALSE,prior_variance=.2,estimate_residual_variance=FALSE))
  for(t in 1:2){
   fit<-fits[[t]];saveRDS(fit,file.path(dest,paste0("fit",t,".rds")),version=3)
   idx<-fit$sets$cs_index;bf<-fit$lbf_variable[idx,,drop=FALSE]
   d<-do.call(rbind,lapply(seq_len(nrow(bf)),function(i)data.frame(signal=idx[i],snp=colnames(bf),log_bf=bf[i,],weight=".")))
   tab(d,file.path(dest,paste0("fitted-trait",t,".tsv")))
  }
  coloc::coloc.susie(fits[[1]],fits[[2]])
 })
}
writeLines("ORIGINAL_FUNCTION_AUDIT_CAPTURE_COMPLETE",file.path(output,"CAPTURE_COMPLETE.txt"))
