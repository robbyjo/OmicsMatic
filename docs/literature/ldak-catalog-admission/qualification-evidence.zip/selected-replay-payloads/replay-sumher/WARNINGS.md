# Observed original diagnostics and required review

**Warnings: 5; errors: 0; substitution messages: 2.** Original zero test statistics replaced with 1e-6: **18**; tagging values floored at one: **4**; reported ambiguous predictors ignored: **53**.

Read every original console and DIAGNOSTICS.tsv before dependent analysis. Substitutions are original program behavior, not proof that literal input values were used throughout fitting. Warnings and partial files remain; no input is silently rewritten. The declared policy controls whether original substitutions are admitted.

- sumher/original.stdout:30 [WARNING] Warning, estimates of heritability can be biased by the presence of strong-effect loci, so either identify these yourself then use "--exclude", or use "--cutoff" to specify the maximum variance explained
- sumher/original.stdout:41 [AMBIGUOUS_COUNT] In total, 53 predictors have ambiguous alleles
- sumher/original.stdout:46 [WARNING] Warning, there are usually tens of thousands of predictors (not 3289)
- sumher/original.stdout:48 [WARNING] Warning, 4 SNPs have tagging less than 1 (0 less than 0); these have been replaced with 1
- sumher/original.stdout:50 [WARNING] Warning, 18 SNPs have test statistic 0; these have been replaced with 1e-6
- sumher/original.stdout:54 [WARNING] Warning, estimates of heritability can be biased by the presence of strong-effect loci, so consider using "--cutoff" to exclude them (for example, "--cutoff 0.01" will exclude predictors which individually explain at least 1% of phenotypic variation)

# Original LDAK 5.2 profile: scope and required actions

SOURCE-BUILD PROFILE: command success and catalog qualification are separate.
This profile executes the checksum-pinned original Linux x86_64 LDAK5.2
binary, with supplied literal inputs and explicit model/deployment choices.
It does not install software during analysis. Prepare the permitted runtime
with tools/literature/ldak_original/setup.py. The original GPL notice and
executable are captured. The host Linux kernel and Java runtime are external
prerequisites; host/version metadata and matching method bytecode are recorded.

SumHer requires the complete uncompressed original tagging reference and
six-column prepared summary format. A reference/model/ancestry label is not
inferred from a filename. Supplied effective sample sizes and prevalence/
ascertainment must describe the actual analysis; binary-trait liability
conversion does not infer population prevalence. No BLD-LDAK reference or
author settings are invented. Missing/forbidden references mean SKIP3.

Kinship/REML uses exact FID/IID pairs and preserves all FAM fields literally,
including NA sex tokens. Optional original thinning is followed by an audited
retained/lost/trivial handoff. Without thinning, caller-selected predictors
and weights define the model. A unit-weight unthinned GRM is not LDAK-Thin.
Alpha values and the selection rule are explicit. The maximum-likelihood
selection uses original PRINTED alternative likelihoods, retaining the first
grid position on a printed tie, only with common reported null/sample counts.
It is not an inferred paper grid or author selection policy.

Original warnings, omissions and in-memory substitutions remain visible.
upstream_adjustments=forbid refuses completion after any reported replacement;
allow-recorded preserves and reports original behavior without rewriting input.
Original SumHer can replace zero statistics with1e-6 and floor low tagging
values at1. Ambiguous-allele exclusion and check_sums are separate explicit
choices. Raw estimates, original categories and every result-family file
remain available. Original unconstrained negative estimates are not clamped.

VERIFY requires matching method code, exact directory membership/hashes,
complete original process records and regenerated derived audits. It never
executes LDAK. Native Java independently recomputes every captured kinship
entry and checks float32 output with 2e-7 absolute plus2e-7 relative tolerance.
It verifies thinning set handoff, not the independent thinning algorithm.
SumHer/REML audits check original convergence, estimates, input counts and
declared liability conversion; they do not independently refit these models.
REPLAY actually executes the captured original pipeline in NEW output and
requires all original scientific output and native-audit bytes to agree.
Integrity and replay do not establish producer authenticity or biological truth.

Original stages use one MKL/OMP thread and LC_ALL=C; loader injection and
inherited MKL/OMP controls are removed. This 5.2 binary has no supported
seed option in the selected interface; none is fabricated. Replay tests
the selected workflows, not universal determinism of every LDAK feature.
wall_ms bounds each original stage. Workspace monitoring/capture limits
are not an OS disk/RSS quota and can overshoot between polls. Numeric and
metadata admission bounds refuse rather than truncate samples/predictors.
Retain sufficient parent JVM heap for native audits and metadata.

SKIP3: exact required runtime/reference or permitted Linux execution is
unavailable/forbidden; skip dependent analysis. Supply the named permitted
prerequisite and retry NEW output. FAIL2: invalid input, original error,
nonconvergence, timeout, audit, recording or replay discrepancy; no complete
result. Read FAILURE.txt, WARNINGS.md, DIAGNOSTICS.tsv and both original
consoles. All failed attempts remain. Do not repair bundles, refresh hashes
or change editions to force a pass. Require COMPLETED.properties and VERIFY;
preserve the matching application artifact. This profile does not establish
author-binary identity, whole-paper reproduction or full250-goal completion.
