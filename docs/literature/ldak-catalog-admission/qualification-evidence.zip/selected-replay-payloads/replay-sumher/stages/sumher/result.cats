Component Heritability SD
Cat_Base 0.729400 0.134432
