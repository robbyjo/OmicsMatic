rule count:
    input: "reads/{sample}.fa"
    output: "work/{sample}.tsv"
    benchmark: repeat("benchmarks/count-{sample}.tsv",2)
    params: python=PYTHON
    shell: "{params.python:q} scripts/runner.py count {output:q} {input:q}"
