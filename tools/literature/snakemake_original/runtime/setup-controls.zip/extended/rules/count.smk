rule count:
    input: "reads/{sample}.fa"
    output: "work/{sample}.tsv"
    benchmark: "benchmarks/count-{sample}.tsv"
    params: python=PYTHON
    shell: "{params.python:q} scripts/runner.py count {output:q} {input:q}"
