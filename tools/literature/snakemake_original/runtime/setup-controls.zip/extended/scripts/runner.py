from pathlib import Path
import hashlib,sys,time
kind,out,*inputs=sys.argv[1:]
# Keep the measured process alive long enough to be sampled; synthetic workload only.
memory=bytearray(4*1024*1024);start=time.monotonic()
while time.monotonic()-start<1.25: hashlib.sha256(memory[:65536]).digest()
target=Path(out);target.parent.mkdir(parents=True,exist_ok=True)
if kind=="count":
    rows=[line.strip() for line in Path(inputs[0]).read_text().splitlines() if line and not line.startswith(">")]
    target.write_text(Path(inputs[0]).stem+"\t"+str(sum(len(row) for row in rows))+"\n")
else: target.write_text("sample\tbases\n"+"".join(Path(p).read_text() for p in inputs))
