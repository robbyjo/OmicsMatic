# Load the stats package (if not already loaded)
library(stats)


#EA
# Define variables
N <- 20000  # Total number of genes in the background set
K <- 1642    # Number of genes in the gene set of interest
n <- 149   # Number of genes in the sample being tested
k <- 20     # Number of overlapping genes between the gene set of interest and the sample

# Perform hypergeometric test
EA_p_value <- 1 - phyper(k - 1, K, N - K, n, lower.tail = TRUE)



#IQ
# Define variables
N <- 20000  # Total number of genes in the background set
K <- 936    # Number of genes in the gene set of interest
n <- 149   # Number of genes in the sample being tested
k <- 6     # Number of overlapping genes between the gene set of interest and the sample

# Perform hypergeometric test
IQ_p_value <- 1 - phyper(k - 1, K, N - K, n, lower.tail = TRUE)


#HAR
# Define variables
N <- 20000  # Total number of genes in the background set
K <- 1476    # Number of genes in the gene set of interest
n <- 149   # Number of genes in the sample being tested
k <- 30     # Number of overlapping genes between the gene set of interest and the sample

# Perform hypergeometric test
HAR_p_value <- 1 - phyper(k - 1, K, N - K, n, lower.tail = TRUE)



df <- data.frame(EA_p_value, IQ_p_value, HAR_p_value)

write.csv(df, "/scratch/stychr009/2021/Publication/Filtered_log_normalised_analysis/Outputs/Hypergeometric_test.csv")
