#sint --account=humbio --time=50:00:00 --partition=ada --ntasks=40 --nodes=1
#module load compilers/gcc820
#module load python/anaconda-python-3.7
#conda create -y -n env_name 
#source activate env_name


#load python and activate conda env

import csv
import gzip
import os
import scipy.io
import itertools
 
samples = ["4_T1", "5_T1", "5_T2", "7_T1", "7_T2", "9_T1", "9_T2", "15_T1_B1", "15_T2_B1", "15_T3_B1", "15_T4_B1", 
"15_T5_B1", "15_T6_B1", "15_T1_B2", "20_T1", "20_T2", "24_T1", "24_T2", "26_T1", "31_T1", "31_T2", "41_T1", "50_T1"]

thresholds = [0.3, 0.27, 0.27, 0.35, 0.24, 0.35, 0.35, 0.3, 0.3, 0.31, 0.3, 0.3, 0.27, 0.34, 0.38, 0.28, 0.31, 0.35, 0.27, 0.27, 0.26, 0.36, 0.38]

iterate = [0:22]

for i in iterate:
    matrix_dir = "directory_to_cellranger_outputs/cellcount_" + samples[i] + "/filtered_feature_bc_matrix"
    mat = scipy.io.mmread(os.path.join(matrix_dir, "matrix.mtx.gz"))

    features_path = os.path.join(matrix_dir, "features.tsv.gz")
    ifile = gzip.open(features_path, mode= 'rt', compresslevel= 9)
    feature_ids = [row[0] for row in csv.reader(ifile, delimiter= "\t")]
    gene_names = [row[1] for row in csv.reader(ifile, delimiter="\t")]

    feature_types = [row[2] for row in csv.reader(ifile, delimiter="\t")]
    barcodes_path = os.path.join(matrix_dir, "barcodes.tsv.gz")
    myfile = gzip.open(barcodes_path, mode= 'rt', compresslevel= 9)

    barcodes = [row[0] for row in csv.reader(myfile, delimiter="\t")]

    #NB need to transpose matrix
    #make sure that if matrix = a x b then 'a' represents the nuclei/cells 

    mat = mat.transpose()
    mat 

    import scrublet as scr
    scrub = scr.Scrublet(mat)
    doublet_scores, predicted_doublets = scrub.scrub_doublets()

    
    #Run script twice and change thresholds according to the bimodal distribution of the simulated doublet score histogram https://github.com/swolock/scrublet
    scrub.call_doublets(threshold=thresholds[i])

    #Use the pandas library
    import pandas as pd
    df = pd.DataFrame({
    'doublet_score': scrub.doublet_scores_obs_,
    'predicted_doublet': scrub.predicted_doublets_
        })


    #Make the rownames the barcodes
    df.index = barcodes

    #change index to True in order to keep the rownames 
    df.to_csv("Doublet_removal/Scrublet/" + samples[i] +"/" + samples[i] + '_scrublet_output_table.csv', index=True)

    scrub_hist = scrub.plot_histogram()


    #save plot 

    import matplotlib.pyplot as pl
    import numpy as np
    pl.savefig("Doublet_removal/Scrublet/" + samples[i] +"/" + samples[i] + '_scrub_hist.pdf')

    print('Running UMAP...')

    scrub.set_embedding('UMAP', scr.get_umap(scrub.manifold_obs_, 10, min_dist=0.3))
    print('Done.')
    UMAP_scrub = scrub.plot_embedding('UMAP', order_points=True);
    import matplotlib.pyplot as pl
    import numpy as np
    pl.savefig("Doublet_removal/Scrublet/" + samples[i] +"/" + samples[i], '_UMAP_scrub.pdf')







