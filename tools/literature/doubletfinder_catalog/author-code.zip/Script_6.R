##Scrublet - compiling all the doublet and nondoublet outputs 

library(SingleCellExperiment)
library(Seurat)
library(tidyverse)
library(Matrix)
library(scales)
library(cowplot)
library(RCurl)
library(DeconRNASeq)
library(gplots)
library(dplyr)
library(MCL)
library(clusterProfiler)
library(mygene)
library(tidyr)
library(R.utils)
library(foreach)
library(doParallel)
library(stringr)
library(DoubletDecon)
library(dplyr)
library(stringi)

split_seurat <- c("P_4_T1", "P_5_T1", "P_5_T2", "P_7_T1", "P_7_T2", "P_9_T1", "P_9_T2", "P_15_T1_B1", "P_15_T2_B1", "P_15_T3_B1", "P_15_T4_B1", 
                      "P_15_T5_B1", "P_15_T6_B1", "P_15_T1_B2", "A_20_T1", "A_20_T2", "A_24_T1", "A_24_T2", "A_26_T1", "A_31_T1", "A_31_T2", "A_41_T1", "A_50_T1")

for (i in 1:length(split_seurat)){
  scrublet_doublets <- read.csv(paste0("Doublet_removal/Scrublet/", split_seurat[i], "/", split_seurat[i], "_scrublet_output_table.csv"))
  scrublet_doublets$X <- paste0(split_seurat[i], "_", scrublet_doublets$X)
  scrublet_output <- scrublet_doublets[1] 
  scrublet_output[,2] <- scrublet_doublets[3]
  colnames(scrublet_output) <- c("barcode", "predicted_doublet") 
  write.csv(scrublet_output, paste0("Doublet_removal/Scrublet/outputs/", split_seurat[i], "_scrublet_output_table.csv"), row.names=FALSE)
  scrublet_doublets <- subset(scrublet_output, scrublet_output$predicted_doublet == "True")
  scrublet_nondoublets <- subset(scrublet_output, scrublet_output$predicted_doublet == "False")
  write.csv(scrublet_doublets, paste0("Doublet_removal/Scrublet/outputs/", split_seurat[i], "_scrublet_doublets.csv"), row.names=FALSE)
  write.csv(scrublet_nondoublets, paste0("Doublet_removal/Scrublet/outputs/", split_seurat[i], "_scrublet_nondoublets.csv"), row.names=FALSE)
}

split_seurat <- c("P_4_T1", "P_5_T1", "P_5_T2", "P_7_T1", "P_7_T2", "P_9_T1", "P_9_T2", "P_15_T1_B1", "P_15_T2_B1", "P_15_T3_B1", "P_15_T4_B1", 
                      "P_15_T5_B1", "P_15_T6_B1", "P_15_T1_B2", "A_20_T1", "A_20_T2", "A_24_T1", "A_24_T2", "A_26_T1", "A_31_T1", "A_31_T2", "A_41_T1", "A_50_T1")

#Plot UMAPs with scrublet doublets
for (i in 1:length(split_seurat)) {
 clustered_seurat <- readRDS(paste0("Doublet_removal/Preclustering/Clustering/data/", split_seurat[i], "_clusters_seurat.rds")) 
 Scrublet_doublets <- read.csv(paste0("Doublet_removal/Scrublet/Scrublet_outputs/", split_seurat[i], "_scrublet_doublets.csv"))
 UMAP_visualise_doublets <- DimPlot(clustered_seurat, reduction = "umap", cells.highlight= as.list(Scrublet_doublets$barcode)) + NoLegend()
 ggsave(paste0("Doublet_removal/Scrublet/Scrublet_outputs/", split_seurat[i], "_scrublet_doublet_UMAP.png"), UMAP_visualise_doublets)
}
