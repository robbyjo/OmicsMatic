#Cell Ranger to generate filtered feature-barcode matrices
#In linux terminal (not R)

#!/bin/sh
#SBATCH --account=humbio
#SBATCH --partition=ada
#SBATCH --nodes=1 --ntasks=40
#SBATCH --time=10:00:00
#SBATCH --job-name='sample_id'
#SBATCH --mail-user=...@....ac.za
#SBATCH --mail-type=BEGIN,END,FAIL


cellranger count --id=cellcount_sample_id --fastqs=/directory_to_fastq_files --transcriptome=/directory_to_human_reference_transcriptome/refdata-gex-GRCh38-2020-A --include-introns 
