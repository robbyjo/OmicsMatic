
library(scater)
library(Seurat)
library(tidyverse)
library(cowplot)
library(Matrix.utils)
library(edgeR)
library(dplyr)
library(magrittr)
library(Matrix)
library(purrr)
library(reshape2)
library(S4Vectors)
library(tibble)
library(SingleCellExperiment)
library(pheatmap)
library(apeglm)
library(png)
library(DESeq2)
library(RColorBrewer)
library(ashr)
#library(DEGreport)
library(ggrepel)
library(psupertime)

seu <- readRDS("directory/seu.rds")

seu$cluster_id <- seu$MTG_annotation_log_normalised

Idents(seu) <- seu$MTG_annotation_log_normalised

seu$donor_age <- NA
seu$donor_age[which(str_detect(seu$cells, "Juvenile_4_yr_old_T1"))] <- "4"
seu$donor_age[which(str_detect(seu$cells, "Juvenile_5_yr_old_T1"))] <- "5"
seu$donor_age[which(str_detect(seu$cells, "Juvenile_5_yr_old_T2"))] <- "5"
seu$donor_age[which(str_detect(seu$cells, "Juvenile_7_yr_old_T1"))] <- "7"
seu$donor_age[which(str_detect(seu$cells, "Juvenile_7_yr_old_T2"))] <- "7"
seu$donor_age[which(str_detect(seu$cells, "Juvenile_9_yr_old_T1"))] <- "9"
seu$donor_age[which(str_detect(seu$cells, "Juvenile_9_yr_old_T2"))] <- "9"
seu$donor_age[which(str_detect(seu$cells, "Juvenile_15_yr_old_T1_B1"))] <- "15"
seu$donor_age[which(str_detect(seu$cells, "Juvenile_15_yr_old_T2_B1"))] <- "15"
seu$donor_age[which(str_detect(seu$cells, "Juvenile_15_yr_old_T3_B1"))] <- "15"
seu$donor_age[which(str_detect(seu$cells, "Juvenile_15_yr_old_T4_B1"))] <- "15"
seu$donor_age[which(str_detect(seu$cells, "Juvenile_15_yr_old_T5_B1"))] <- "15"
seu$donor_age[which(str_detect(seu$cells, "Juvenile_15_yr_old_T6_B1"))] <- "15"
seu$donor_age[which(str_detect(seu$cells, "Juvenile_15_yr_old_T1_B2"))] <- "15"
seu$donor_age[which(str_detect(seu$cells, "Adult_20_yr_old_T1"))] <- "20"
seu$donor_age[which(str_detect(seu$cells, "Adult_20_yr_old_T2"))] <- "20"
seu$donor_age[which(str_detect(seu$cells, "Adult_24_yr_old_T1"))] <- "24"
seu$donor_age[which(str_detect(seu$cells, "Adult_24_yr_old_T2"))] <- "24"
seu$donor_age[which(str_detect(seu$cells, "Adult_26_yr_old_T1"))] <- "26"
seu$donor_age[which(str_detect(seu$cells, "Adult_31_yr_old_T1"))] <- "31"
seu$donor_age[which(str_detect(seu$cells, "Adult_31_yr_old_T2"))] <- "31"
seu$donor_age[which(str_detect(seu$cells, "Adult_41_yr_old_T1"))] <- "41"
seu$donor_age[which(str_detect(seu$cells, "Adult_50_yr_old_T1"))] <- "50"

seu$donor_age <- factor(seu$donor_age, levels = c(4, 5, 7, 9, 15, 20, 24, 26, 31, 41, 50))

# Extract raw counts and metadata to create SingleCellExperiment object

seu$sample_id <- seu$Biological_replicate

clusters <- c('Exc L3-5 RORB ESR1', 'Exc L2 LAMP5 LTK', 'Exc L4-5 RORB FOLH1B', 'Exc L2-3 LINC00507 FREM3')

for (x in 1:length(clusters)){
subset <- subset(seu, idents = clusters[x]) 

counts <- subset@assays$RNA@counts
logcounts <- subset@assays$RNA@data

metadata <- subset@meta.data

# Create single cell experiment object
brain_sce <- SingleCellExperiment(assays = list(counts = counts, logcounts= logcounts), 
                            colData = metadata)


  # run psupertime
 # message('running psupertime')
  y_age       = brain_sce$donor_age
  psuper_obj  = psupertime(brain_sce, y_age, sel_genes= "all")
  psuper_obj

betas <- psuper_obj$beta_dt
write.csv(betas, paste0("directory/", clusters[x], "_beta_coefficients.csv"))

#The plot below shows how the sequential labels are distributed over the identified pseudotime (_Fig 1D_). This allows us to check how easily `psupertime` was able to order the cells.
 # message('plotting labels over psupertime')
pdf(paste0("directory/", clusters[x], "_labels_pseudotime.pdf"))
print(plot_labels_over_psupertime(psuper_obj, y_age))
dev.off()
  

#We can check the effect of different levels of regularization, $\lambda$, on classification performance and sparsity. The plot below shows training and test performance of `psupertime` used as a classifier, for the range of $\lambda$ values it was trained over (_Supp Fig 01_).

 # message('plotting psupertime training diagnostics')
pdf(paste0("directory/", clusters[x], "_diagnostic.pdf"))
 print(plot_train_results(psuper_obj))
dev.off()

#The next plot shows the profiles of genes identified by `psupertime`, plotted against the learned pseudotime values (_Supp Fig 02_).

  #message('plotting identified genes over psupertime')
pdf(paste0("directory/", clusters[x], "_genes_v_pseudotime.pdf"))
print(plot_identified_genes_over_psupertime(psuper_obj, y_age))
dev.off()

#Each of these genes has a different coefficient, indicating how strongly they affect the pseudotime values. The plot below shows the coefficients for the top 20 genes, subject to minimum absolute coefficient value of 0.05 (_Supp Fig 03_). Positive coefficients correspond to genes positively correlated with the label sequence, and vice versa for negative coefficients.

 # message('plotting identified gene coefficients')
pdf(paste0("directory/", clusters[x], "_coefficients.pdf"))
print(plot_identified_gene_coefficients(psuper_obj))
dev.off()


#Plot DESeq2 genes over pseudotime 
DE <- read.csv(paste0("directory_to_DESeq2_outputs/", clusters[x], "_Paediatric_vs_Adult_sig_genes.csv"))
DE <- DE[order(-DE$log2FoldChange), ]
extra_genes <- DE$gene

library(stringr)

#Change DESeq2 genes to match psupertime names (i.e changed hyphens to fullstops)
extra_genes <- str_replace_all(extra_genes, "-", ".")

pdf(paste0("directory/", clusters[x], "_DESeq2_v_pseudotime.pdf"))
print(plot_specified_genes_over_psupertime(
  psuper_obj,
  extra_genes=extra_genes,
  label_name = "y_age",
  palette = "RdBu",
  plot_ratio = 1.25
))
dev.off()

}




library(stringr)

clusters <- c('Exc L3-5 RORB ESR1', 'Exc L2 LAMP5 LTK', 'Exc L4-5 RORB FOLH1B', 'Exc L2-3 LINC00507 FREM3')

for (x in 1:length(clusters)){

#Import DESeq2 genes

DE <- read.csv(paste0("DESeq2_directory/", clusters[x], "_Paediatric_vs_Adult_sig_genes.csv"))

#Convert all hyphens in DE genes to fullstops
DE$gene <- str_replace_all(DE$gene, "-", ".")

#Import Psupertime results
Psup <- read.csv(paste0("directory/", clusters[x], "_beta_coefficients.csv"))

#Extract coefficients >0 
Psup <- Psup[Psup$abs_beta > 0, ]

Intersect <- intersect(DE$gene, Psup$symbol)


Extract <- Psup[Psup$symbol %in% Intersect, ]

if (nrow(Extract)>0){
write.csv(Extract, paste0("directory/", clusters[x], "_DESeq2_PSupertime_intersect.csv"))

}

}
