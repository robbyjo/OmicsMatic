# Load libraries
library(SingleCellExperiment)
library(Seurat)
library(tidyverse)
library(Matrix)
library(scales)
library(cowplot)
library(RCurl)
library(pryr)
library(RColorBrewer)
library(dplyr)
library(textclean)


#load filtered_seurat object
load("QC_directory/data/filtered_seurat_mt_genes_removed.RData")

filtered_seurat <- subset_counts

filtered_seurat$batch <- NA
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "P_4_T1"))] <- "E"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "P_5_T1"))] <- "D"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "P_5_T2"))] <- "D"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "P_7_T1"))] <- "A"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "P_7_T2"))] <- "A"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "P_9_T1"))] <- "D"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "P_9_T2"))] <- "D"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "P_15_T1_B1"))] <- "B"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "P_15_T2_B1"))] <- "B"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "P_15_T3_B1"))] <- "B"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "P_15_T4_B1"))] <- "B"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "P_15_T5_B1"))] <- "C"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "P_15_T6_B1"))] <- "C"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "P_15_T1_B2"))] <- "G"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "A_20_T1"))] <- "F"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "A_20_T2"))] <- "F"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "A_24_T1"))] <- "F"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "A_24_T2"))] <- "F"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "A_26_T1"))] <- "E"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "A_31_T1"))] <- "C"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "A_31_T2"))] <- "C"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "A_41_T1"))] <- "G"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "A_50_T1"))] <- "A"



filtered_seurat$sex <- NA
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "P_4_T1"))] <- "M"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "P_5_T1"))] <- "F"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "P_5_T2"))] <- "F"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "P_7_T1"))] <- "M"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "P_7_T2"))] <- "M"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "P_9_T1"))] <- "F"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "P_9_T2"))] <- "F"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "P_15_T1_B1"))] <- "F"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "P_15_T2_B1"))] <- "F"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "P_15_T3_B1"))] <- "F"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "P_15_T4_B1"))] <- "F"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "P_15_T5_B1"))] <- "F"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "P_15_T6_B1"))] <- "F"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "P_15_T1_B2"))] <- "M"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "A_20_T1"))] <- "F"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "A_20_T2"))] <- "F"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "A_24_T1"))] <- "F"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "A_24_T2"))] <- "F"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "A_26_T1"))] <- "M"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "A_31_T1"))] <- "M"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "A_31_T2"))] <- "M"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "A_41_T1"))] <- "F"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "A_50_T1"))] <- "F"


filtered_seurat$brain_region <- "Temporal"
       

filtered_seurat$Biological_replicate <- NA
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "P_4_T1"))] <- "P_4"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "P_5_T1"))] <- "P_5"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "P_5_T2"))] <- "P_5"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "P_7_T1"))] <- "P_7"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "P_7_T2"))] <- "P_7"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "P_9_T1"))] <- "P_9"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "P_9_T2"))] <- "P_9"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "P_15_T1_B1"))] <- "P_15_B1"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "P_15_T2_B1"))] <- "P_15_B1"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "P_15_T3_B1"))] <- "P_15_B1"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "P_15_T4_B1"))] <- "P_15_B1"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "P_15_T5_B1"))] <- "P_15_B1"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "P_15_T6_B1"))] <- "P_15_B1"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "P_15_T1_B2"))] <- "P_15_B2"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "A_20_T1"))] <- "A_20"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "A_20_T2"))] <- "A_20"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "A_24_T1"))] <- "A_24"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "A_24_T2"))] <- "A_24"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "A_26_T1"))] <- "A_26"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "A_31_T1"))] <- "A_31"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "A_31_T2"))] <- "A_31"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "A_41_T1"))] <- "A_41"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "A_50_T1"))] <- "A_50"


filtered_seurat$Age_group <- NA
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "P_4_T1"))] <- "Paediatric"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "P_5_T1"))] <- "Paediatric"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "P_5_T2"))] <- "Paediatric"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "P_7_T1"))] <- "Paediatric"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "P_7_T2"))] <- "Paediatric"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "P_9_T1"))] <- "Paediatric"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "P_9_T2"))] <- "Paediatric"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "P_15_T1_B1"))] <- "Paediatric"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "P_15_T2_B1"))] <- "Paediatric"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "P_15_T3_B1"))] <- "Paediatric"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "P_15_T4_B1"))] <- "Paediatric"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "P_15_T5_B1"))] <- "Paediatric"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "P_15_T6_B1"))] <- "Paediatric"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "P_15_T1_B2"))] <- "Paediatric"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "A_20_T1"))] <- "Adult"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "A_20_T2"))] <- "Adult"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "A_24_T1"))] <- "Adult"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "A_24_T2"))] <- "Adult"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "A_26_T1"))] <- "Adult"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "A_31_T1"))] <- "Adult"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "A_31_T2"))] <- "Adult"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "A_41_T1"))] <- "Adult"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "A_50_T1"))] <- "Adult"

filtered_seurat$single_cell_chemistry <- NA
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "P_4_T1"))] <- "10X_v3"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "P_5_T1"))] <- "10X_v3"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "P_5_T2"))] <- "10X_v3"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "P_7_T1"))] <- "10X_v2"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "P_7_T2"))] <- "10X_v2"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "P_9_T1"))] <- "10X_v3"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "P_9_T2"))] <- "10X_v3"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "P_15_T1_B1"))] <- "10X_v3"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "P_15_T2_B1"))] <- "10X_v3"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "P_15_T3_B1"))] <- "10X_v3"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "P_15_T4_B1"))] <- "10X_v3"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "P_15_T5_B1"))] <- "10X_v3"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "P_15_T6_B1"))] <- "10X_v3"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "P_15_T1_B2"))] <- "10X_v3"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "A_20_T1"))] <- "10X_v2"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "A_20_T2"))] <- "10X_v2"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "A_24_T1"))] <- "10X_v2"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "A_24_T2"))] <- "10X_v2"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "A_26_T1"))] <- "10X_v3"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "A_31_T1"))] <- "10X_v3"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "A_31_T2"))] <- "10X_v3"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "A_41_T1"))] <- "10X_v3"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "A_50_T1"))] <- "10X_v2"



filtered_seurat$Age_group <- as.factor(filtered_seurat$Age_group)
filtered_seurat$Biological_replicate <- as.factor(filtered_seurat$Biological_replicate)
filtered_seurat$brain_region <- as.factor(filtered_seurat$brain_region)
filtered_seurat$sex <- as.factor(filtered_seurat$sex)
filtered_seurat$batch <- as.factor(filtered_seurat$batch)
filtered_seurat$single_cell_chemistry <- as.factor(filtered_seurat$single_cell_chemistry)


# Normalize the counts
seurat_phase <- NormalizeData(filtered_seurat)

# Load cell cycle markers
load("SCT/data/cycle.rda")

# Score cells for cell cycle
seurat_phase <- CellCycleScoring(seurat_phase, 
                                 g2m.features = g2m_genes, 
                                 s.features = s_genes)

# Identify the most variable genes
seurat_phase <- FindVariableFeatures(seurat_phase, 
                     selection.method = "vst",
                     nfeatures = 2000, 
                     verbose = FALSE)

# Scale the counts (not regressing out anything initially
seurat_phase <- ScaleData(seurat_phase)

seurat_phase <- RunPCA(seurat_phase)

# Plot the PCA colored by cell cycle phase
PCA_cell_cycle_phase <- DimPlot(seurat_phase,
        reduction = "pca",
        group.by= "Phase",
        split.by = "Phase")
ggsave(paste0("/SCT/figures/PCA/PCA_coloured_by_cell_cycle_phase.pdf"), plot = PCA_cell_cycle_phase)

# Plot the PCA colored by batch
PCA_batch <- DimPlot(seurat_phase,
        reduction = "pca",
        group.by= "batch",
        split.by = "batch")
ggsave(paste0("/SCT/figures/PCA/PCA_coloured_by_batch.pdf"), plot = PCA_batch)


#Plot PCA coloured by mitoRatio
# Check quartile values
summary(seurat_phase@meta.data$mitoRatio)

# Turn mitoRatio into categorical factor vector based on quartile values
seurat_phase@meta.data$mitoFr <- cut(seurat_phase@meta.data$mitoRatio, 
                   breaks=c(-Inf, 0.0144, 0.0199, 0.0267, Inf), 
                   labels=c("Low","Medium","Medium high", "High"))

# Plot the PCA colored by mitoFr
DimPlot(seurat_phase,
        reduction = "pca",
        group.by= "mitoFr",
        split.by = "mitoFr")

ggsave(paste0("/SCT/figures/PCA_coloured_by_mito_fraction.pdfg"))


UMAP_unintegrated_for_comparison <- RunUMAP(seurat_phase, 
                             dims = 1:40,
			     reduction = "pca")

# Plot UMAP                             
UMAP_unintegrated_plot <- DimPlot(UMAP_unintegrated_for_comparison) +
guides(color = guide_legend(override.aes = list(size=4), ncol= 1)) +                           
theme(legend.text=element_text(size=10)) 
  
ggsave(paste0("/SCT/figures/unintegrated/UMAP_unintegrated.pdf"), plot = UMAP_unintegrated_plot)
                          

UMAP_unintegrated_split <- DimPlot(UMAP_unintegrated_for_comparison, split.by = "sample")       
ggsave(paste0("/SCT/figures/unintegrated/UMAP_unintegrated_split_by_sample.pdf"), plot = UMAP_unintegrated_split)

Idents(UMAP_unintegrated_for_comparison) <-  factor(Idents(UMAP_unintegrated_for_comparison), levels = c("P_4_T1", "P_5_T1", "P_5_T2", "P_7_T1", "P_7_T2", "P_9_T1", "P_9_T2", "P_15_T1_B1", "P_15_T2_B1", "P_15_T3_B1", "P_15_T4_B1", 
                      "P_15_T5_B1", "P_15_T6_B1", "P_15_T1_B2", "A_20_T1", "A_20_T2", "A_24_T1", "A_24_T2", "A_26_T1", "A_31_T1", "A_31_T2", "A_41_T1", "A_50_T1"))

UMAP_unintegrated_for_comparison$sample <- factor(UMAP_unintegrated_for_comparison$sample, levels = c("P_4_T1", "P_5_T1", "P_5_T2", "P_7_T1", "P_7_T2", "P_9_T1", "P_9_T2", "P_15_T1_B1", "P_15_T2_B1", "P_15_T3_B1", "P_15_T4_B1", 
                      "P_15_T5_B1", "P_15_T6_B1", "P_15_T1_B2", "A_20_T1", "A_20_T2", "A_24_T1", "A_24_T2", "A_26_T1", "A_31_T1", "A_31_T2", "A_41_T1", "A_50_T1"))

split_seurat <- SplitObject(UMAP_unintegrated_for_comparison, split.by = "sample")

split_seurat <- split_seurat[c("P_4_T1", "P_5_T1", "P_5_T2", "P_7_T1", "P_7_T2", "P_9_T1", "P_9_T2", "P_15_T1_B1", "P_15_T2_B1", "P_15_T3_B1", "P_15_T4_B1", 
                      "P_15_T5_B1", "P_15_T6_B1", "P_15_T1_B2", "A_20_T1", "A_20_T2", "A_24_T1", "A_24_T2", "A_26_T1", "A_31_T1", "A_31_T2", "A_41_T1", "A_50_T1")]

for (t in 1:length(split_seurat)) {
	UMAP_unintegrated <- DimPlot(split_seurat[[t]])
	ggsave(paste0("SCT/figures/unintegrated/UMAP_", split_seurat[[t]]@meta.data$sample[1], "_unintegrated_no_regressed_variables.pdf"), plot = UMAP_unintegrated)
}


PCA_unintegrated_for_comparison <- PCAPlot(seurat_phase,
        split.by = "sample") 
ggsave(paste0("SCT/figures/PCA/PCA_unintegrated_split_by_sample.pdf"), plot = PCA_unintegrated_for_comparison)


#SCT and integration
options(future.globals.maxSize = 4000 * 1024^2)

# Split seurat object by condition to perform cell cycle scoring and SCT on all samples
split_seurat <- SplitObject(filtered_seurat, split.by = "sample")

split_seurat <- split_seurat[c("P_4_T1", "P_5_T1", "P_5_T2", "P_7_T1", "P_7_T2", "P_9_T1", "P_9_T2", "P_15_T1_B1", "P_15_T2_B1", "P_15_T3_B1", "P_15_T4_B1", 
                      "P_15_T5_B1", "P_15_T6_B1", "P_15_T1_B2", "A_20_T1", "A_20_T2", "A_24_T1", "A_24_T2", "A_26_T1", "A_31_T1", "A_31_T2", "A_41_T1", "A_50_T1")]

for (i in 1:length(split_seurat)) {
    split_seurat[[i]] <- NormalizeData(split_seurat[[i]], verbose = TRUE)
    split_seurat[[i]] <- CellCycleScoring(split_seurat[[i]], g2m.features=g2m_genes, s.features=s_genes)
    split_seurat[[i]] <- SCTransform(split_seurat[[i]], vars.to.regress = c("mitoRatio"), variable.features.n = 3000)
    }

saveRDS(split_seurat, "SCT/data/split_seurat.rds")

# Select the most variable features to use for integration
integ_features <- SelectIntegrationFeatures(object.list = split_seurat, nfeatures = 3000) 

# Prepare the SCT list object for integration
split_seurat <- PrepSCTIntegration(object.list = split_seurat, 
                                   anchor.features = integ_features)

# Find best buddies - can take a while to run
integ_anchors <- FindIntegrationAnchors(object.list = split_seurat, 
                                        normalization.method = "SCT", 
                                        anchor.features = integ_features, reference = 1)
# Integrate across conditions
seurat_integrated <- IntegrateData(anchorset = integ_anchors, 
                                   normalization.method = "SCT")


seurat_integrated <- RunPCA(object = seurat_integrated)

# Plot PCA
PCA_plot_integrated <- PCAPlot(seurat_integrated,
        split.by = "sample")  

ggsave("SCT/figures/integrated/PCA_plot_integrated.pdf", plot = PCA_plot_integrated)

# Run UMAP
seurat_integrated <- RunUMAP(seurat_integrated, 
                             dims = 1:40,
			     reduction = "pca")


# Plot UMAP                             
Idents(seurat_integrated) <-  factor(Idents(seurat_integrated), levels = c("P_4_T1", "P_5_T1", "P_5_T2", "P_7_T1", "P_7_T2", "P_9_T1", "P_9_T2", "P_15_T1_B1", "P_15_T2_B1", "P_15_T3_B1", "P_15_T4_B1", 
                      "P_15_T5_B1", "P_15_T6_B1", "P_15_T1_B2", "A_20_T1", "A_20_T2", "A_24_T1", "A_24_T2", "A_26_T1", "A_31_T1", "A_31_T2", "A_41_T1", "A_50_T1"))


UMAP_integrated <- DimPlot(seurat_integrated)+
guides(color = guide_legend(override.aes = list(size=4), ncol= 1)) +                           
theme(legend.text=element_text(size=10)) 
                           
ggsave("SCT/figures/integrated/UMAP_integrated.png", plot = UMAP_integrated)


#UMAP split by sample  
UMAP_integrated_split_by_sample <- DimPlot(seurat_integrated,
        split.by = "sample")  

ggsave("SCT/figures/integrated/UMAP_integrated_split_by_sample.pdf", plot = UMAP_integrated_split_by_sample)



#Each sample separately

split_seurat <- SplitObject(seurat_integrated, split.by = "sample")

split_seurat <- split_seurat[c("P_4_T1", "P_5_T1", "P_5_T2", "P_7_T1", "P_7_T2", "P_9_T1", "P_9_T2", "P_15_T1_B1", "P_15_T2_B1", "P_15_T3_B1", "P_15_T4_B1", 
                      "P_15_T5_B1", "P_15_T6_B1", "P_15_T1_B2", "A_20_T1", "A_20_T2", "A_24_T1", "A_24_T2", "A_26_T1", "A_31_T1", "A_31_T2", "A_41_T1", "A_50_T1")]

for (i in 1:length(split_seurat)) {
	test <- DimPlot(split_seurat[[i]])
	ggsave(paste0("SCT/figures/integrated/", "UMAP_", split_seurat[[i]]@meta.data$sample[1], "_integrated.pdf"), plot = test)
}

saveRDS(seurat_integrated, "SCT/data/integrated_seurat.rds")

