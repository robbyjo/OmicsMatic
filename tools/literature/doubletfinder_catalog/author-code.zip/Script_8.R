# Load libraries
library(scater)
library(Seurat)
library(tidyverse)
library(cowplot)
library(Matrix.utils)
library(edgeR)
library(dplyr)
library(magrittr)
library(Matrix)
library(purrr)
library(reshape2)
library(S4Vectors)
library(tibble)
library(SingleCellExperiment)
library(pheatmap)
library(apeglm)
library(png)
library(DESeq2)
library(RColorBrewer)
library(ashr)
library(DEGreport)
library(ggplot2)
library(ggforce)


seu <- readRDS("/SCT/data/integrated_seurat.rds")

# Explore heatmap of PCs: looking for a PC where heatmap starts to look fuzzy

seu <- RunPCA(seu, verbose = FALSE)

PC_heatmap <- DimHeatmap(seu, 
           dims = 1:9, 
           cells = 500, 
           balanced = TRUE)
ggsave("Clustering/figures/PC_heatmap.pdf", plot = PC_heatmap)

# Plot the elbow plot
elbow_plot <- ElbowPlot(object = seu, 
          ndims = 40)
ggsave("Clustering/figures/elbow_plot.pdf", plot = elbow_plot)


#Cluster the cells 
#Determine the K-nearest neighbor graph
seu <- FindNeighbors(object = seu, 
                                                 dims = 1:40)


# Determine the clusters for various resolutions                                
seu <- FindClusters(object = seu, resolution = 0.8)

# Assign identity of clusters

Idents(object = seu) <- "integrated_snn_res.0.8"

seu <- RunUMAP(seu, reduction = "pca", dims = 1:40)

# Plot the UMAP
UMAP_clusters_seurat <- DimPlot(seu, reduction = "umap", label = TRUE, label.size = 6) 

ggsave("Clustering/figures/UMAP_clusters_seurat_integrated.pdf", plot = UMAP_clusters_seurat)

UMAP_clusters_seurat_group <- DimPlot(seu, reduction = "umap", label = FALSE, group.by = "sample")

ggsave("Clustering/figures/UMAP_clusters_seurat_integrated_group_by_sample.pdf", plot = UMAP_clusters_seurat_group)

#Exploration of quality control metrics
# Extract identity and sample information from seurat object to determine the number of cells per cluster per sample
library(dplyr)
n_cells <- FetchData(seu, vars = c("ident", "orig.ident"))%>% 
  dplyr::count(ident, orig.ident) %>%
  tidyr::spread(ident, n)

# Save table
write.csv(n_cells, file = "Clustering/data/number_of_nuclei_per_cluster_per_sample.csv")

# UMAP of cells in each cluster by sample
UMAP_cluster_split_by_sample <- DimPlot(seu, 
        label = TRUE, 
        split.by = "sample")  + NoLegend()

ggsave("Clustering/figures/UMAP_cluster_split_by_sample.pdf", plot = UMAP_cluster_split_by_sample)


# Explore whether clusters segregate by cell cycle phase
UMAP_cell_cycle_phase <- DimPlot(seu,
        label = TRUE, 
        split.by = "Phase")  + NoLegend()
ggsave("Clustering/figures/UMAP_cell_cycle_phase.pdf", plot = UMAP_cell_cycle_phase)


# Determine metrics to plot present in seurat_integrated@meta.data
metrics <-  c("nUMI", "nGene", "S.Score", "G2M.Score", "mitoRatio")

feature_plot <- FeaturePlot(seu, 
            reduction = "umap", 
            features = metrics,
            pt.size = 0.4, 
            sort.cell = TRUE,
            min.cutoff = 'q10',
            label = TRUE)
ggsave("Clustering/figures/feature_plot.pdf", plot = feature_plot)


PCA_group_by_sample <- PCAPlot(seu,
        group.by = "sample")  
ggsave("Clustering/figures/PCA_group_by_sample.pdf", plot = PCA_group_by_sample)


PCA_split_by_sample <- PCAPlot(seu,
        split.by = "sample")  

ggsave("Clustering/figures/PCA_split_by_sample.pdf", plot = PCA_split_by_sample)


saveRDS(seu, file = "Clustering/data/clusters_seurat_integrated.rds")
