#Cluster nuclei on the minimal marker genes
#Import the integrated seurat object (after SCT but prior to UMAP)
#Run UMAP but change the features to the minimal markers and to a random set of variable features
library(SingleCellExperiment)
library(Seurat)
library(tidyverse)
library(Matrix)
library(scales)
library(cowplot)
library(RCurl)
library(textclean)


Age <- c("Paediatric", "Adult")
Paed_names <- c("P_4_T1", "P_5_T1", "P_5_T2", "P_7_T1", "P_7_T2", "P_9_T1", "P_9_T2", "P_15_T1_B1", "P_15_T2_B1", "P_15_T3_B1", "P_15_T4_B1", "P_15_T5_B1", "P_15_T6_B1", "P_15_T1_B2")
Adult_names <- c("A_20_T1", "A_20_T2", "A_24_T1", "A_24_T2", "A_26_T1", "A_31_T1", "A_31_T2", "A_41_T1", "A_50_T1")
Split_seu_names <- list(Paed_names, Adult_names)

for (p in 1:length(Age)){

seu <- readRDS("directory_to_processed_seurat_object/seurat_object.rds")

DefaultAssay(seu) <- 'RNA'

seu <- subset(seu, subset= Age_group == Age[p])

samples <- levels(as.factor(seu$Biological_replicate))

#Import minimal markers per cell_type
import <- read.csv(paste0("NSForest/Downsampled/", Age[p], "/NSForest_v3_Final_Result_unique.csv"))

features <- import$NSForest_Markers
features <- gsub("[", "", features, fixed=TRUE)
features <- gsub("]", "", features, fixed=TRUE)
features <- gsub("'", "", features, fixed=TRUE)
features <- strsplit(features, split = ", ")
features <- unlist(features)

features_unique <- unique(features)

#Perform SCT and subsequent steps using features_unique (minimal markers) instead of the variable features (used in the original processing)
#load filtered_seurat object
#load filtered_seurat object
load("QC_directory/data/filtered_seurat_mt_genes_removed.RData")

filtered_seurat <- subset_counts

filtered_seurat$batch <- NA
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "P_4_T1"))] <- "E"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "P_5_T1"))] <- "D"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "P_5_T2"))] <- "D"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "P_7_T1"))] <- "A"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "P_7_T2"))] <- "A"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "P_9_T1"))] <- "D"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "P_9_T2"))] <- "D"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "P_15_T1_B1"))] <- "B"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "P_15_T2_B1"))] <- "B"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "P_15_T3_B1"))] <- "B"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "P_15_T4_B1"))] <- "B"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "P_15_T5_B1"))] <- "C"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "P_15_T6_B1"))] <- "C"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "P_15_T1_B2"))] <- "G"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "A_20_T1"))] <- "F"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "A_20_T2"))] <- "F"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "A_24_T1"))] <- "F"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "A_24_T2"))] <- "F"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "A_26_T1"))] <- "E"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "A_31_T1"))] <- "C"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "A_31_T2"))] <- "C"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "A_41_T1"))] <- "G"
filtered_seurat$batch[which(str_detect(filtered_seurat$sample, "A_50_T1"))] <- "A"



filtered_seurat$sex <- NA
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "P_4_T1"))] <- "M"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "P_5_T1"))] <- "F"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "P_5_T2"))] <- "F"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "P_7_T1"))] <- "M"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "P_7_T2"))] <- "M"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "P_9_T1"))] <- "F"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "P_9_T2"))] <- "F"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "P_15_T1_B1"))] <- "F"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "P_15_T2_B1"))] <- "F"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "P_15_T3_B1"))] <- "F"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "P_15_T4_B1"))] <- "F"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "P_15_T5_B1"))] <- "F"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "P_15_T6_B1"))] <- "F"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "P_15_T1_B2"))] <- "M"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "A_20_T1"))] <- "F"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "A_20_T2"))] <- "F"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "A_24_T1"))] <- "F"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "A_24_T2"))] <- "F"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "A_26_T1"))] <- "M"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "A_31_T1"))] <- "M"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "A_31_T2"))] <- "M"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "A_41_T1"))] <- "F"
filtered_seurat$sex[which(str_detect(filtered_seurat$sample, "A_50_T1"))] <- "F"


filtered_seurat$brain_region <- "Temporal"


filtered_seurat$Biological_replicate <- NA
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "P_4_T1"))] <- "P_4"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "P_5_T1"))] <- "P_5"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "P_5_T2"))] <- "P_5"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "P_7_T1"))] <- "P_7"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "P_7_T2"))] <- "P_7"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "P_9_T1"))] <- "P_9"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "P_9_T2"))] <- "P_9"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "P_15_T1_B1"))] <- "P_15_B1"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "P_15_T2_B1"))] <- "P_15_B1"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "P_15_T3_B1"))] <- "P_15_B1"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "P_15_T4_B1"))] <- "P_15_B1"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "P_15_T5_B1"))] <- "P_15_B1"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "P_15_T6_B1"))] <- "P_15_B1"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "P_15_T1_B2"))] <- "P_15_B2"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "A_20_T1"))] <- "A_20"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "A_20_T2"))] <- "A_20"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "A_24_T1"))] <- "A_24"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "A_24_T2"))] <- "A_24"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "A_26_T1"))] <- "A_26"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "A_31_T1"))] <- "A_31"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "A_31_T2"))] <- "A_31"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "A_41_T1"))] <- "A_41"
filtered_seurat$Biological_replicate[which(str_detect(filtered_seurat$sample, "A_50_T1"))] <- "A_50"


filtered_seurat$Age_group <- NA
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "P_4_T1"))] <- "Paediatric"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "P_5_T1"))] <- "Paediatric"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "P_5_T2"))] <- "Paediatric"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "P_7_T1"))] <- "Paediatric"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "P_7_T2"))] <- "Paediatric"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "P_9_T1"))] <- "Paediatric"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "P_9_T2"))] <- "Paediatric"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "P_15_T1_B1"))] <- "Paediatric"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "P_15_T2_B1"))] <- "Paediatric"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "P_15_T3_B1"))] <- "Paediatric"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "P_15_T4_B1"))] <- "Paediatric"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "P_15_T5_B1"))] <- "Paediatric"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "P_15_T6_B1"))] <- "Paediatric"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "P_15_T1_B2"))] <- "Paediatric"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "A_20_T1"))] <- "Adult"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "A_20_T2"))] <- "Adult"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "A_24_T1"))] <- "Adult"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "A_24_T2"))] <- "Adult"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "A_26_T1"))] <- "Adult"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "A_31_T1"))] <- "Adult"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "A_31_T2"))] <- "Adult"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "A_41_T1"))] <- "Adult"
filtered_seurat$Age_group[which(str_detect(filtered_seurat$sample, "A_50_T1"))] <- "Adult"

filtered_seurat$single_cell_chemistry <- NA
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "P_4_T1"))] <- "10X_v3"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "P_5_T1"))] <- "10X_v3"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "P_5_T2"))] <- "10X_v3"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "P_7_T1"))] <- "10X_v2"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "P_7_T2"))] <- "10X_v2"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "P_9_T1"))] <- "10X_v3"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "P_9_T2"))] <- "10X_v3"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "P_15_T1_B1"))] <- "10X_v3"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "P_15_T2_B1"))] <- "10X_v3"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "P_15_T3_B1"))] <- "10X_v3"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "P_15_T4_B1"))] <- "10X_v3"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "P_15_T5_B1"))] <- "10X_v3"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "P_15_T6_B1"))] <- "10X_v3"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "P_15_T1_B2"))] <- "10X_v3"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "A_20_T1"))] <- "10X_v2"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "A_20_T2"))] <- "10X_v2"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "A_24_T1"))] <- "10X_v2"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "A_24_T2"))] <- "10X_v2"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "A_26_T1"))] <- "10X_v3"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "A_31_T1"))] <- "10X_v3"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "A_31_T2"))] <- "10X_v3"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "A_41_T1"))] <- "10X_v3"
filtered_seurat$single_cell_chemistry[which(str_detect(filtered_seurat$sample, "A_50_T1"))] <- "10X_v2"


filtered_seurat$Age_group <- as.factor(filtered_seurat$Age_group)
filtered_seurat$Biological_replicate <- as.factor(filtered_seurat$Biological_replicate)
filtered_seurat$brain_region <- as.factor(filtered_seurat$brain_region)
filtered_seurat$sex <- as.factor(filtered_seurat$sex)
filtered_seurat$batch <- as.factor(filtered_seurat$batch)
filtered_seurat$single_cell_chemistry <- as.factor(filtered_seurat$single_cell_chemistry)

filtered_seurat <- subset(filtered_seurat, subset= Age_group == Age[p])

split_seurat <- SplitObject(filtered_seurat, split.by = "sample")
split_seurat <- split_seurat[Split_seu_names[[p]]] 

for (i in 1:length(split_seurat)) {
    split_seurat[[i]] <- NormalizeData(split_seurat[[i]], verbose = TRUE)
    split_seurat[[i]] <- SCTransform(split_seurat[[i]], vars.to.regress = c("mitoRatio"), residual.features = features_unique)
    }

if (p == 1){
# Select the most variable features to use for integration
A <- rownames(split_seurat[[1]]@assays$SCT@scale.data)
B <- rownames(split_seurat[[2]]@assays$SCT@scale.data)
C <- rownames(split_seurat[[3]]@assays$SCT@scale.data)
D <- rownames(split_seurat[[4]]@assays$SCT@scale.data)
E <- rownames(split_seurat[[5]]@assays$SCT@scale.data)
F <- rownames(split_seurat[[6]]@assays$SCT@scale.data)
G <- rownames(split_seurat[[7]]@assays$SCT@scale.data)
H <- rownames(split_seurat[[8]]@assays$SCT@scale.data)
I <- rownames(split_seurat[[9]]@assays$SCT@scale.data)
J <- rownames(split_seurat[[10]]@assays$SCT@scale.data)
K <- rownames(split_seurat[[11]]@assays$SCT@scale.data)
L <- rownames(split_seurat[[12]]@assays$SCT@scale.data)
M <- rownames(split_seurat[[13]]@assays$SCT@scale.data)
N <- rownames(split_seurat[[14]]@assays$SCT@scale.data)

integ_features <- Reduce(intersect, list(A, B, C, D, E, F, G, H, I, J, K, L, M, N))

}else{
# Select the most variable features to use for integration
A <- rownames(split_seurat[[1]]@assays$SCT@scale.data)
B <- rownames(split_seurat[[2]]@assays$SCT@scale.data)
C <- rownames(split_seurat[[3]]@assays$SCT@scale.data)
D <- rownames(split_seurat[[4]]@assays$SCT@scale.data)
E <- rownames(split_seurat[[5]]@assays$SCT@scale.data)
F <- rownames(split_seurat[[6]]@assays$SCT@scale.data)
G <- rownames(split_seurat[[7]]@assays$SCT@scale.data)
H <- rownames(split_seurat[[8]]@assays$SCT@scale.data)
I <- rownames(split_seurat[[9]]@assays$SCT@scale.data)

integ_features <- Reduce(intersect, list(A, B, C, D, E, F, G, H, I))

}

# Prepare the SCT list object for integration
split_seurat <- PrepSCTIntegration(object.list = split_seurat, anchor.features = integ_features)

# Find best buddies - can take a while to run
integ_anchors <- FindIntegrationAnchors(object.list = split_seurat, 
                                        normalization.method = "SCT", 
                                        anchor.features = integ_features, reference = 1)
# Integrate across conditions
seurat_integrated <- IntegrateData(anchorset = integ_anchors, 
                                   normalization.method = "SCT")

seurat_integrated <- RunPCA(object = seurat_integrated)

# Run UMAP
seu_integ <- RunUMAP(seurat_integrated, 
                             dims = 1:40,
			     reduction = "pca")

saveRDS(seu_integ, paste0("NSForest/Downsampled/", Age[p], "/Data/seu_integ_features_unique_minimal_markers.rds"))

if (p==1){
seu_integ$sample <- NA
seu_integ$sample[which(str_detect(seu_integ$Biological_replicate, "^P_4"))] <- "4-year-old"
seu_integ$sample[which(str_detect(seu_integ$Biological_replicate, "^P_5"))] <- "5-year-old"
seu_integ$sample[which(str_detect(seu_integ$Biological_replicate, "^P_7"))] <- "7-year-old"
seu_integ$sample[which(str_detect(seu_integ$Biological_replicate, "^P_9"))] <- "9-year-old"
seu_integ$sample[which(str_detect(seu_integ$Biological_replicate, "^P_15_B1"))] <- "15-year-old B1"
seu_integ$sample[which(str_detect(seu_integ$Biological_replicate, "^P_15_B2"))] <- "15-year-old B2"

Idents(seu_integ) <- factor(seu_integ$sample, levels = c("4-year-old", "5-year-old", "7-year-old",
"9-year-old", "15-year-old B1", "15-year-old B2"))

}else{
seu_integ$sample <- NA
seu_integ$sample[which(str_detect(seu_integ$Biological_replicate, "^A_20"))] <- "20-year-old"
seu_integ$sample[which(str_detect(seu_integ$Biological_replicate, "^A_24"))] <- "24-year-old"
seu_integ$sample[which(str_detect(seu_integ$Biological_replicate, "^A_26"))] <- "26-year-old"
seu_integ$sample[which(str_detect(seu_integ$Biological_replicate, "^A_31"))] <- "31-year-old"
seu_integ$sample[which(str_detect(seu_integ$Biological_replicate, "^A_41"))] <- "41-year-old"
seu_integ$sample[which(str_detect(seu_integ$Biological_replicate, "^A_50"))] <- "50-year-old"

Idents(seu_integ) <- factor(seu_integ$sample, levels = c("20-year-old", "24-year-old", "26-year-old", "31-year-old", 
"41-year-old", "50-year-old"))
}


if (p==1){
UMAP_integrated <- DimPlot(seu_integ, pt.size=1)+
guides(color = guide_legend(override.aes = list(size=4), ncol= 1)) +                           
theme(legend.text=element_text(size=10))
}else{
UMAP_integrated <- DimPlot(seu_integ)+
guides(color = guide_legend(override.aes = list(size=4), ncol= 1)) +                           
theme(legend.text=element_text(size=10))
}
                           
ggsave(paste0("NSForest/Downsampled/", Age[p], "/figures/UMAP_NSForest_minimal_markers.pdf"), plot = UMAP_integrated)

if (p==1){
seu_integ$replicates <- NA
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^P_4_T1"))] <- "4-year-old T1"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^P_5_T1"))] <- "5-year-old T1"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^P_5_T2"))] <- "5-year-old T2"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^P_7_T1"))] <- "7-year-old T1"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^P_7_T2"))] <- "7-year-old T2"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^P_9_T1"))] <- "9-year-old T1"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^P_9_T2"))] <- "9-year-old T2"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^P_15_T1_B1"))] <- "15-year-old T1 B1"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^P_15_T2_B1"))] <- "15-year-old T2 B1"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^P_15_T3_B1"))] <- "15-year-old T3 B1"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^P_15_T4_B1"))] <- "15-year-old T4 B1"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^P_15_T5_B1"))] <- "15-year-old T5 B1"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^P_15_T6_B1"))] <- "15-year-old T6 B1"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^P_15_T1_B2"))] <- "15-year-old T1 B2"

Idents(seu_integ) <-  factor(seu_integ$replicates, levels = c("4-year-old T1", "5-year-old T1", "5-year-old T2", "7-year-old T1",
"7-year-old T2", "9-year-old T1", "9-year-old T2", "15-year-old T1 B1", "15-year-old T2 B1",
 "15-year-old T3 B1", "15-year-old T4 B1", "15-year-old T5 B1", "15-year-old T6 B1", "15-year-old T1 B2"))

seu_integ$replicates <-  factor(seu_integ$replicates, levels = c("4-year-old T1", "5-year-old T1", "5-year-old T2", "7-year-old T1",
"7-year-old T2", "9-year-old T1", "9-year-old T2", "15-year-old T1 B1", "15-year-old T2 B1",
 "15-year-old T3 B1", "15-year-old T4 B1", "15-year-old T5 B1", "15-year-old T6 B1", "15-year-old T1 B2"))


}else{
seu_integ$replicates <- NA
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^A_20_T1"))] <- "20-year-old T1"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^A_20_T2"))] <- "20-year-old T2"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^A_24_T1"))] <- "24-year-old T1"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^A_24_T2"))] <- "24-year-old T2"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^A_26_T1"))] <- "26-year-old T1"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^A_31_T1"))] <- "31-year-old T1"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^A_31_T2"))] <- "31-year-old T2"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^A_41_T1"))] <- "41-year-old T1"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^A_50_T1"))] <- "50-year-old T1"

Idents(seu_integ) <-  factor(seu_integ$replicates, levels = c("20-year-old T1", 
  "20-year-old T2", "24-year-old T1", "24-year-old T2", "26-year-old T1", "31-year-old T1", "31-year-old T2", "41-year-old T1",
  "50-year-old T1"))

seu_integ$replicates <-  factor(seu_integ$replicates, levels = c("20-year-old T1", 
  "20-year-old T2", "24-year-old T1", "24-year-old T2", "26-year-old T1", "31-year-old T1", "31-year-old T2", "41-year-old T1",
  "50-year-old T1"))
}

if (p==1){
UMAP_integrated <- DimPlot(seu_integ, group.by = 'replicates', pt.size=1)+
guides(color = guide_legend(override.aes = list(size=4), ncol= 1)) +                           
theme(legend.text=element_text(size=10)) 
}else{
UMAP_integrated <- DimPlot(seu_integ, group.by = 'replicates')+
guides(color = guide_legend(override.aes = list(size=4), ncol= 1)) +                           
theme(legend.text=element_text(size=10))
}
                           
ggsave(paste0("NSForest/Downsampled/figures/", Age[p], "/figures/UMAP_group_replicate_NSForest_minimal_markers.pdf"), plot = UMAP_integrated)

#Colour by cell type
cluster_label <- Idents(seu)

clusters_seurat_integrated <- AddMetaData(seu_integ,
                    metadata = cluster_label,
                    col.name = 'cluster_label')

Allen_metadata <- read.csv("Label_transfer/Data/Hodge_Aeverman_cell_type_colours.csv", header = TRUE)

#Change the cluster label in Allen metadata to match the equivalent column name in the seurat object (i.e cluster_label)
colnames(Allen_metadata)[which(colnames(Allen_metadata)=="Final")] <- "cluster_label"
colnames(Allen_metadata)[which(colnames(Allen_metadata)=="Colour")] <- "cluster_colour"

Idents(object = clusters_seurat_integrated) <- 'cluster_label'
levels(clusters_seurat_integrated)

#Create a new column with the same entries as the cluster_label column but call it cluster colour
clusters_seurat_integrated$cluster_colour <- clusters_seurat_integrated$cluster_label
#substitute all the elements in one column with different elements in a vector - vectors need to be ordered though
#position 1 in vector A will be subtitute with position 1 from vector B, and position 2 in vector A will be subsititute with position 2 in vector B etc
clusters_seurat_integrated$cluster_colour <- mgsub(clusters_seurat_integrated$cluster_colour, Allen_metadata$cluster_label, Allen_metadata$cluster_colour)

Test <- Allen_metadata[Allen_metadata$cluster_label %in% levels(as.factor(clusters_seurat_integrated$cluster_label)), ]

my_levels <- c("Inh L1-2 PAX6 CDH12", "Inh L1-4 LAMP5 LCP2",
"Inh L2-6 LAMP5 CA1", "Inh L1 SST NMBR", 
"Inh L1-2 GAD1 MC4R", "Inh L1-2 SST BAGE2", 
"Inh L1-2 VIP TSPAN12", "Inh L1-4 VIP CHRNA6", 
"Inh L1-3 VIP ADAMTSL1", "Inh L2-6 VIP QPCT",
"Inh L3-6 VIP HS3ST3A1", "Inh L1-2 VIP PCDH20",
"Inh L2-5 VIP SERPINF1", "Inh L2-5 VIP TYR", 
"Inh L1-3 VIP CHRM2", "Inh L2-4 VIP CBLN1", 
"Inh L1-3 VIP CCDC184", "Inh L1-3 VIP GGH", 
"Inh L1-2 VIP LBH", "Inh L2-4 VIP SPAG17",
"Inh L1-4 VIP OPRM1", "Inh L3-6 SST NPY",
"Inh L4-6 SST B3GAT2", "Inh L5-6 SST NPM1P10",
"Inh L4-6 SST GXYLT2", "Inh L4-5 SST STK32A",
"Inh L1-3 SST CALB1", "Inh L3-5 SST ADGRG6", 
"Inh L2-4 SST FRZB", "Inh L5-6 PVALB LGR5",
"Inh L2-4 PVALB WFDC2", "Inh L4-6 PVALB SULF1",
"Inh L5-6 SST MIR548F2", "Inh L2-5 PVALB SCUBE3", 
"Exc L2 LAMP5 LTK", "Exc L2-3 LINC00507 FREM3", 
"Exc L5-6 THEMIS C1QL3", "Exc L3-5 RORB ESR1",
"Exc L3-5 RORB COL22A1", "Exc L3-5 RORB FILIP1L",
"Exc L3-5 RORB TWIST2", "Exc L4-5 RORB FOLH1B",
"Exc L4-6 RORB SEMA3E", "Exc L4-5 RORB DAPK2",
"Exc L5-6 THEMIS CRABP1", "Exc L5-6 THEMIS FGF10",
"Exc L4-6 FEZF2 IL26", "Exc L5-6 FEZF2 ABO",
"OPC L1-6 PDGFRA", "Astro L1-6 FGFR3 SLC14A1",
"Astro L1-2 FGFR3 GFAP", "Oligo L1-6 OPALIN", 
"Endo L2-6 NOSTRIN", "Micro L1-3 TYROBP")

extract <- clusters_seurat_integrated@meta.data %>% select(cluster_label, cluster_colour)
extract <- unique(extract)
extract <- extract[match(my_levels, extract$cluster_label),]
clusters_seurat_integrated$cluster_label <- factor(clusters_seurat_integrated$cluster_label, levels = my_levels)

levels(as.factor(clusters_seurat_integrated$cluster_label))
extract$cluster_colour

if (p ==1){
UMAP_integrated <- DimPlot(clusters_seurat_integrated, reduction = "umap", group.by = 'cluster_label',
cols = extract$cluster_colour, pt.size=1) +
guides(color = guide_legend(override.aes = list(size=10), ncol= 2)) +
theme(legend.text=element_text(size=10))
}else{
UMAP_integrated <- DimPlot(clusters_seurat_integrated, reduction = "umap", group.by = 'cluster_label',
cols = extract$cluster_colour) +
guides(color = guide_legend(override.aes = list(size=10), ncol= 2)) +
theme(legend.text=element_text(size=10))
}                           
ggsave(paste0("NSForest/Downsampled/", Age[p], "/figures/UMAP_NSforest_minimal_markers_colour_clusters.pdf"), plot = UMAP_integrated, width = 20, height =17)

#------------------------------------------------------------------------------------------------------------------------------------------------------

#Cf random features

#random features
random_features <- sample(rownames(filtered_seurat@assays$RNA@data),length(integ_features),replace=FALSE)

write.csv(random_features, paste0("NSForest/Downsampled/", Age[p], "/Data/random_features.csv"))

split_seurat <- SplitObject(filtered_seurat, split.by = "sample")
split_seurat <- split_seurat[Split_seu_names[[p]]] 

for (i in 1:length(split_seurat)) {
    split_seurat[[i]] <- NormalizeData(split_seurat[[i]], verbose = TRUE)
    split_seurat[[i]] <- SCTransform(split_seurat[[i]], vars.to.regress = c("mitoRatio"), residual.features = random_features)
    }


if (p ==1){
# Select the most variable features to use for integration
A <- rownames(split_seurat[[1]]@assays$SCT@scale.data)
B <- rownames(split_seurat[[2]]@assays$SCT@scale.data)
C <- rownames(split_seurat[[3]]@assays$SCT@scale.data)
D <- rownames(split_seurat[[4]]@assays$SCT@scale.data)
E <- rownames(split_seurat[[5]]@assays$SCT@scale.data)
F <- rownames(split_seurat[[6]]@assays$SCT@scale.data)
G <- rownames(split_seurat[[7]]@assays$SCT@scale.data)
H <- rownames(split_seurat[[8]]@assays$SCT@scale.data)
I <- rownames(split_seurat[[9]]@assays$SCT@scale.data)
J <- rownames(split_seurat[[10]]@assays$SCT@scale.data)
K <- rownames(split_seurat[[11]]@assays$SCT@scale.data)
L <- rownames(split_seurat[[12]]@assays$SCT@scale.data)
M <- rownames(split_seurat[[13]]@assays$SCT@scale.data)
N <- rownames(split_seurat[[14]]@assays$SCT@scale.data)

integ_features <- Reduce(intersect, list(A, B, C, D, E, F, G, H, I, J, K, L, M, N))

}else{
# Select the most variable features to use for integration
A <- rownames(split_seurat[[1]]@assays$SCT@scale.data)
B <- rownames(split_seurat[[2]]@assays$SCT@scale.data)
C <- rownames(split_seurat[[3]]@assays$SCT@scale.data)
D <- rownames(split_seurat[[4]]@assays$SCT@scale.data)
E <- rownames(split_seurat[[5]]@assays$SCT@scale.data)
F <- rownames(split_seurat[[6]]@assays$SCT@scale.data)
G <- rownames(split_seurat[[7]]@assays$SCT@scale.data)
H <- rownames(split_seurat[[8]]@assays$SCT@scale.data)
I <- rownames(split_seurat[[9]]@assays$SCT@scale.data)

integ_features <- Reduce(intersect, list(A, B, C, D, E, F, G, H, I))

}

# Prepare the SCT list object for integration
split_seurat <- PrepSCTIntegration(object.list = split_seurat, anchor.features = integ_features)

# Find best buddies - can take a while to run
integ_anchors <- FindIntegrationAnchors(object.list = split_seurat, 
                                        normalization.method = "SCT", 
                                        anchor.features = integ_features, reference = 1)
# Integrate across conditions
seurat_integrated <- IntegrateData(anchorset = integ_anchors, 
                                   normalization.method = "SCT")

seurat_integrated <- RunPCA(object = seurat_integrated)

# Run UMAP
seu_integ <- RunUMAP(seurat_integrated, 
                             dims = 1:40,
			     reduction = "pca")

saveRDS(seu_integ, paste0("/SCT/data/seu_integ_random_features_", Age[p], ".rds"))

if (p==1){
seu_integ$sample <- NA
seu_integ$sample[which(str_detect(seu_integ$Biological_replicate, "^P_4"))] <- "4-year-old"
seu_integ$sample[which(str_detect(seu_integ$Biological_replicate, "^P_5"))] <- "5-year-old"
seu_integ$sample[which(str_detect(seu_integ$Biological_replicate, "^P_7"))] <- "7-year-old"
seu_integ$sample[which(str_detect(seu_integ$Biological_replicate, "^P_9"))] <- "9-year-old"
seu_integ$sample[which(str_detect(seu_integ$Biological_replicate, "^P_15_B1"))] <- "15-year-old B1"
seu_integ$sample[which(str_detect(seu_integ$Biological_replicate, "^P_15_B2"))] <- "15-year-old B2"

Idents(seu_integ) <- factor(seu_integ$sample, levels = c("4-year-old", "5-year-old", "7-year-old",
"9-year-old", "15-year-old B1", "15-year-old B2"))

}else{
seu_integ$sample <- NA
seu_integ$sample[which(str_detect(seu_integ$Biological_replicate, "^A_20"))] <- "20-year-old"
seu_integ$sample[which(str_detect(seu_integ$Biological_replicate, "^A_24"))] <- "24-year-old"
seu_integ$sample[which(str_detect(seu_integ$Biological_replicate, "^A_26"))] <- "26-year-old"
seu_integ$sample[which(str_detect(seu_integ$Biological_replicate, "^A_31"))] <- "31-year-old"
seu_integ$sample[which(str_detect(seu_integ$Biological_replicate, "^A_41"))] <- "41-year-old"
seu_integ$sample[which(str_detect(seu_integ$Biological_replicate, "^A_50"))] <- "50-year-old"

Idents(seu_integ) <- factor(seu_integ$sample, levels = c("20-year-old", "24-year-old", "26-year-old", "31-year-old", 
"41-year-old", "50-year-old"))
}


if (p==1){
UMAP_integrated <- DimPlot(seu_integ, pt.size=1)+
guides(color = guide_legend(override.aes = list(size=4), ncol= 1)) +                           
theme(legend.text=element_text(size=10)) 
}else{
UMAP_integrated <- DimPlot(seu_integ)+
guides(color = guide_legend(override.aes = list(size=4), ncol= 1)) +                           
theme(legend.text=element_text(size=10)) 
}
                           
ggsave(paste0("NSForest/Downsampled/", Age[p], "/figures/UMAP_random_markers.pdf"), plot = UMAP_integrated)

if (p==1){
seu_integ$replicates <- NA
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^P_4_T1"))] <- "4-year-old T1"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^P_5_T1"))] <- "5-year-old T1"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^P_5_T2"))] <- "5-year-old T2"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^P_7_T1"))] <- "7-year-old T1"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^P_7_T2"))] <- "7-year-old T2"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^P_9_T1"))] <- "9-year-old T1"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^P_9_T2"))] <- "9-year-old T2"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^P_15_T1_B1"))] <- "15-year-old T1 B1"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^P_15_T2_B1"))] <- "15-year-old T2 B1"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^P_15_T3_B1"))] <- "15-year-old T3 B1"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^P_15_T4_B1"))] <- "15-year-old T4 B1"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^P_15_T5_B1"))] <- "15-year-old T5 B1"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^P_15_T6_B1"))] <- "15-year-old T6 B1"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^P_15_T1_B2"))] <- "15-year-old T1 B2"

Idents(seu_integ) <-  factor(seu_integ$replicates, levels = c("4-year-old T1", "5-year-old T1", "5-year-old T2", "7-year-old T1",
"7-year-old T2", "9-year-old T1", "9-year-old T2", "15-year-old T1 B1", "15-year-old T2 B1",
 "15-year-old T3 B1", "15-year-old T4 B1", "15-year-old T5 B1", "15-year-old T6 B1", "15-year-old T1 B2"))

seu_integ$replicates <-  factor(seu_integ$replicates, levels = c("4-year-old T1", "5-year-old T1", "5-year-old T2", "7-year-old T1",
"7-year-old T2", "9-year-old T1", "9-year-old T2", "15-year-old T1 B1", "15-year-old T2 B1",
 "15-year-old T3 B1", "15-year-old T4 B1", "15-year-old T5 B1", "15-year-old T6 B1", "15-year-old T1 B2"))


}else{
seu_integ$replicates <- NA
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^A_20_T1"))] <- "20-year-old T1"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^A_20_T2"))] <- "20-year-old T2"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^A_24_T1"))] <- "24-year-old T1"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^A_24_T2"))] <- "24-year-old T2"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^A_26_T1"))] <- "26-year-old T1"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^A_31_T1"))] <- "31-year-old T1"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^A_31_T2"))] <- "31-year-old T2"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^A_41_T1"))] <- "41-year-old T1"
seu_integ$replicates[which(str_detect(seu_integ@meta.data$sample, "^A_50_T1"))] <- "50-year-old T1"

Idents(seu_integ) <-  factor(seu_integ$replicates, levels = c("20-year-old T1", 
  "20-year-old T2", "24-year-old T1", "24-year-old T2", "26-year-old T1", "31-year-old T1", "31-year-old T2", "41-year-old T1",
  "50-year-old T1"))

seu_integ$replicates <-  factor(seu_integ$replicates, levels = c("20-year-old T1", 
  "20-year-old T2", "24-year-old T1", "24-year-old T2", "26-year-old T1", "31-year-old T1", "31-year-old T2", "41-year-old T1",
  "50-year-old T1"))
}

if (p==1){
UMAP_integrated <- DimPlot(seu_integ, group.by = 'replicates', pt.size=1)+
guides(color = guide_legend(override.aes = list(size=4), ncol= 1)) +                           
theme(legend.text=element_text(size=10)) 
}else{
UMAP_integrated <- DimPlot(seu_integ, group.by = 'replicates')+
guides(color = guide_legend(override.aes = list(size=4), ncol= 1)) +                           
theme(legend.text=element_text(size=10)) 
}
                          
ggsave(paste0("NSForest/Downsampled/", Age[p], "/figures/UMAP_group_replicate_random_markers.pdf"), plot = UMAP_integrated)

#Colour by cell type
cluster_label <- Idents(seu)

clusters_seurat_integrated <- AddMetaData(seu_integ,
                    metadata = cluster_label,
                    col.name = 'cluster_label')

Allen_metadata <- read.csv("Label_transfer/Data/Hodge_Aeverman_cell_type_colours.csv", header = TRUE)

#Change the cluster label in Allen metadata to match the equivalent column name in the seurat object (i.e cluster_label)
colnames(Allen_metadata)[which(colnames(Allen_metadata)=="Final")] <- "cluster_label"
colnames(Allen_metadata)[which(colnames(Allen_metadata)=="Colour")] <- "cluster_colour"

Idents(object = clusters_seurat_integrated) <- 'cluster_label'
levels(clusters_seurat_integrated)

#Create a new column with the same entries as the cluster_label column but call it cluster colour
clusters_seurat_integrated$cluster_colour <- clusters_seurat_integrated$cluster_label
#This mgsub is a big win!!! Basically substitute all the elements in one column with different elements in a vector... vectors need to be ordered though
#So position 1 in vector A will be subtitute with position 1 from vector B, and position 2 in vector A will be subsititute with position 2 in vector B etc
clusters_seurat_integrated$cluster_colour <- mgsub(clusters_seurat_integrated$cluster_colour, Allen_metadata$cluster_label, Allen_metadata$cluster_colour)

Test <- Allen_metadata[Allen_metadata$cluster_label %in% levels(as.factor(clusters_seurat_integrated$cluster_label)), ]

my_levels <- c("Inh L1-2 PAX6 CDH12", "Inh L1-4 LAMP5 LCP2",
"Inh L2-6 LAMP5 CA1", "Inh L1 SST NMBR", 
"Inh L1-2 GAD1 MC4R", "Inh L1-2 SST BAGE2", 
"Inh L1-2 VIP TSPAN12", "Inh L1-4 VIP CHRNA6", 
"Inh L1-3 VIP ADAMTSL1", "Inh L2-6 VIP QPCT",
"Inh L3-6 VIP HS3ST3A1", "Inh L1-2 VIP PCDH20",
"Inh L2-5 VIP SERPINF1", "Inh L2-5 VIP TYR", 
"Inh L1-3 VIP CHRM2", "Inh L2-4 VIP CBLN1", 
"Inh L1-3 VIP CCDC184", "Inh L1-3 VIP GGH", 
"Inh L1-2 VIP LBH", "Inh L2-4 VIP SPAG17",
"Inh L1-4 VIP OPRM1", "Inh L3-6 SST NPY",
"Inh L4-6 SST B3GAT2", "Inh L5-6 SST NPM1P10",
"Inh L4-6 SST GXYLT2", "Inh L4-5 SST STK32A",
"Inh L1-3 SST CALB1", "Inh L3-5 SST ADGRG6", 
"Inh L2-4 SST FRZB", "Inh L5-6 PVALB LGR5",
"Inh L2-4 PVALB WFDC2", "Inh L4-6 PVALB SULF1",
"Inh L5-6 SST MIR548F2", "Inh L2-5 PVALB SCUBE3", 
"Exc L2 LAMP5 LTK", "Exc L2-3 LINC00507 FREM3", 
"Exc L5-6 THEMIS C1QL3", "Exc L3-5 RORB ESR1",
"Exc L3-5 RORB COL22A1", "Exc L3-5 RORB FILIP1L",
"Exc L3-5 RORB TWIST2", "Exc L4-5 RORB FOLH1B",
"Exc L4-6 RORB SEMA3E", "Exc L4-5 RORB DAPK2",
"Exc L5-6 THEMIS CRABP1", "Exc L5-6 THEMIS FGF10",
"Exc L4-6 FEZF2 IL26", "Exc L5-6 FEZF2 ABO",
"OPC L1-6 PDGFRA", "Astro L1-6 FGFR3 SLC14A1",
"Astro L1-2 FGFR3 GFAP", "Oligo L1-6 OPALIN", 
"Endo L2-6 NOSTRIN", "Micro L1-3 TYROBP")

extract <- clusters_seurat_integrated@meta.data %>% select(cluster_label, cluster_colour)
extract <- unique(extract)
extract <- extract[match(my_levels, extract$cluster_label),]
clusters_seurat_integrated$cluster_label <- factor(clusters_seurat_integrated$cluster_label, levels = my_levels)

levels(as.factor(clusters_seurat_integrated$cluster_label))
extract$cluster_colour

if (p==1){
UMAP_integrated <- DimPlot(clusters_seurat_integrated, reduction = "umap", group.by = 'cluster_label',
cols = extract$cluster_colour, pt.size=1) +
guides(color = guide_legend(override.aes = list(size=10), ncol= 2)) +
theme(legend.text=element_text(size=10))
}else{
UMAP_integrated <- DimPlot(clusters_seurat_integrated, reduction = "umap", group.by = 'cluster_label',
cols = extract$cluster_colours) +
guides(color = guide_legend(override.aes = list(size=10), ncol= 2)) +
theme(legend.text=element_text(size=10))
}                           
ggsave(paste0("NSForest/Downsampled/", Age[p], "/figures/UMAP_random_markers_colour_clusters.pdf"), plot = UMAP_integrated, width = 20, height =17)

}
