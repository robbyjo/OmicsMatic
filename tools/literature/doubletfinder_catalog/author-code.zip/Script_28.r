library(BayesSpace)
library(ggplot2)
library(SingleCellExperiment)


Juvenile15yr_DH1_1 <- readVisium("/scratch/mshruv003/visium_08_10_21/Hockman_Visium/X201SC21082979-Z01-F001_01/raw_data/run_spaceranger_count_DH1a/outs")
set.seed(102)
Juvenile15yr_DH1_1  <- spatialPreprocess(Juvenile15yr_DH1_1, platform="Visium", 
                              n.PCs=7, n.HVGs=2000, skip.PCA = FALSE, log.normalize=TRUE)
							  
Juvenile15yr_DH1_1  <- qTune(Juvenile15yr_DH1_1, qs=seq(2, 10), platform="Visium", d=7)
qPlot(Juvenile15yr_DH1_1)
set.seed(149)

pdf("Juvenile15yr_DH1_1_nrep10000_d7_q_8_6.pdf")
Juvenile15yr_DH1_1  <- spatialCluster(Juvenile15yr_DH1_1, q=8, platform="Visium", d=7,
                           init.method="mclust", model="t", gamma=3,
                           nrep=10000, burn.in=1000,
                           save.chain=TRUE)

clusterPlot(Juvenile15yr_DH1_1)


featurePlot(Juvenile15yr_DH1_1, "FNBP1L")
featurePlot(Juvenile15yr_DH1_1, "KCNG1")
featurePlot(Juvenile15yr_DH1_1, "SLC35F4")
featurePlot(Juvenile15yr_DH1_1, "MYO16")
featurePlot(Juvenile15yr_DH1_1, "XKR4")
featurePlot(Juvenile15yr_DH1_1, "PENK")
featurePlot(Juvenile15yr_DH1_1, "PFKFB2")
featurePlot(Juvenile15yr_DH1_1, "LAMC3")


Juvenile15yr_DH1_1.enhanced <- spatialEnhance(Juvenile15yr_DH1_1, q=8, platform="Visium", d=7,
                                    model="t", gamma=3,
                                    jitter_prior=0.3, jitter_scale=3.5,
                                    nrep=10000, burn.in=1000,
                                    save.chain=TRUE)  

clusterPlot(Juvenile15yr_DH1_1.enhanced)									
markers <- c('FNBP1L', 'KCNG1', 'SLC35F4', 'MYO16', 'XKR4', 'PENK', 'PFKFB2', 'LAMC3')
Juvenile15yr_DH1_1.enhanced <- enhanceFeatures(Juvenile15yr_DH1_1.enhanced, Juvenile15yr_DH1_1,
                                     feature_names=markers,
                                     nrounds=0)
									 
logcounts(Juvenile15yr_DH1_1.enhanced)[markers, 1:5]	
rowData(Juvenile15yr_DH1_1.enhanced)[markers, ]

featurePlot(Juvenile15yr_DH1_1.enhanced, "FNBP1L") + scale_fill_gradientn(colors = c(low = 'white', high = 'brown'), limits = c(0.0,2.5), breaks = c(0, 0.5, 1.0, 1.5, 2.0, 2.5))
featurePlot(Juvenile15yr_DH1_1.enhanced, "KCNG1") + scale_fill_gradientn(colors = c(low = 'white', high = 'brown'), limits = c(0.0,3.5), breaks = c(0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5))
featurePlot(Juvenile15yr_DH1_1.enhanced, "SLC35F4") + scale_fill_gradientn(colors = c(low = 'white', high = 'brown'), limits = c(0.0,2.5), breaks = c(0, 0.5, 1.0, 1.5, 2.0, 2.5))
featurePlot(Juvenile15yr_DH1_1.enhanced, "MYO16") + scale_fill_gradientn(colors = c(low = 'white', high = 'brown'), limits = c(0.0,2.5), breaks = c(0, 0.5, 1.0, 1.5, 2.0, 2.5))
featurePlot(Juvenile15yr_DH1_1.enhanced, "XKR4") + scale_fill_gradientn(colors = c(low = 'white', high = 'brown'), limits = c(0.0,2.0), breaks = c(0, 0.5, 1.0, 1.5, 2.0))
featurePlot(Juvenile15yr_DH1_1.enhanced, "PENK") + scale_fill_gradientn(colors = c(low = 'white', high = 'brown'), limits = c(0.0,3.0), breaks = c(0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0))
featurePlot(Juvenile15yr_DH1_1.enhanced, "PFKFB2") + scale_fill_gradientn(colors = c(low = 'white', high = 'brown'), limits = c(0.0,2.5), breaks = c(0, 0.5, 1.0, 1.5, 2.0, 2.5))
featurePlot(Juvenile15yr_DH1_1.enhanced, "LAMC3") + scale_fill_gradientn(colors = c(low = 'white', high = 'brown'), limits = c(0.0,2.0), breaks = c(0, 0.5, 1.0, 1.5, 2.0))
 				
								 
enhanced.plots <- purrr::map(markers, function(x) featurePlot(Juvenile15yr_DH1_1.enhanced, x))
patchwork::wrap_plots(enhanced.plots, ncol=2)	

spot.plots <- purrr::map(markers, function(x) featurePlot(Juvenile15yr_DH1_1, x))
patchwork::wrap_plots(c(enhanced.plots, spot.plots), ncol=2)	

dev.off()
						
Juvenile15yr_DH2_1 <- readVisium("/scratch/mshruv003/visium_08_10_21/Hockman_Visium/X201SC21082979-Z01-F001_01/raw_data/run_spaceranger_count_DH2a/outs")
set.seed(102)
Juvenile15yr_DH2_1  <- spatialPreprocess(Juvenile15yr_DH2_1, platform="Visium", 
                              n.PCs=7, n.HVGs=2000, skip.PCA = FALSE, log.normalize=TRUE)
							  
Juvenile15yr_DH2_1  <- qTune(Juvenile15yr_DH2_1, qs=seq(2, 10), platform="Visium", d=7)
qPlot(Juvenile15yr_DH2_1)
set.seed(149)

pdf("Juvenile15yr_DH2_1_nrep10000_d7_q_8_6.pdf")
Juvenile15yr_DH2_1  <- spatialCluster(Juvenile15yr_DH2_1, q=8, platform="Visium", d=7,
                           init.method="mclust", model="t", gamma=3,
                           nrep=10000, burn.in=1000,
                           save.chain=TRUE)

clusterPlot(Juvenile15yr_DH2_1)

featurePlot(Juvenile15yr_DH2_1, "FNBP1L")
featurePlot(Juvenile15yr_DH2_1, "KCNG1")
featurePlot(Juvenile15yr_DH2_1, "SLC35F4")
featurePlot(Juvenile15yr_DH2_1, "MYO16")
featurePlot(Juvenile15yr_DH2_1, "XKR4")
featurePlot(Juvenile15yr_DH2_1, "PENK")
featurePlot(Juvenile15yr_DH2_1, "PFKFB2")
featurePlot(Juvenile15yr_DH2_1, "LAMC3")



Juvenile15yr_DH2_1.enhanced <- spatialEnhance(Juvenile15yr_DH2_1, q=8, platform="Visium", d=7,
                                    model="t", gamma=3,
                                    jitter_prior=0.3, jitter_scale=3.5,
                                    nrep=10000, burn.in=1000,
                                    save.chain=TRUE)  

clusterPlot(Juvenile15yr_DH2_1.enhanced)
markers <- c('FNBP1L', 'KCNG1', 'SLC35F4', 'MYO16', 'XKR4', 'PENK', 'PFKFB2', 'LAMC3')
Juvenile15yr_DH2_1.enhanced <- enhanceFeatures(Juvenile15yr_DH2_1.enhanced, Juvenile15yr_DH2_1,
                                     feature_names=markers,
                                     nrounds=0)
									 
logcounts(Juvenile15yr_DH2_1.enhanced)[markers, 1:5]	
rowData(Juvenile15yr_DH2_1.enhanced)[markers, ]

featurePlot(Juvenile15yr_DH2_1.enhanced, "FNBP1L") + scale_fill_gradientn(colors = c(low = 'white', high = 'brown'), limits = c(0.0,2.5), breaks = c(0, 0.5, 1.0, 1.5, 2.0, 2.5))
featurePlot(Juvenile15yr_DH2_1.enhanced, "KCNG1") + scale_fill_gradientn(colors = c(low = 'white', high = 'brown'), limits = c(0.0,3.5), breaks = c(0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0,3.5))
featurePlot(Juvenile15yr_DH2_1.enhanced, "SLC35F4") + scale_fill_gradientn(colors = c(low = 'white', high = 'brown'), limits = c(0.0,2.5), breaks = c(0, 0.5, 1.0, 1.5, 2.0, 2.5))
featurePlot(Juvenile15yr_DH2_1.enhanced, "MYO16") + scale_fill_gradientn(colors = c(low = 'white', high = 'brown'), limits = c(0.0,2.5), breaks = c(0, 0.5, 1.0, 1.5, 2.0, 2.5))
featurePlot(Juvenile15yr_DH2_1.enhanced, "XKR4") + scale_fill_gradientn(colors = c(low = 'white', high = 'brown'), limits = c(0.0,2.0), breaks = c(0, 0.5, 1.0, 1.5, 2.0))
featurePlot(Juvenile15yr_DH2_1.enhanced, "PENK") + scale_fill_gradientn(colors = c(low = 'white', high = 'brown'), limits = c(0.0,3.0), breaks = c(0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0))
featurePlot(Juvenile15yr_DH2_1.enhanced, "PFKFB2") + scale_fill_gradientn(colors = c(low = 'white', high = 'brown'), limits = c(0.0,2.5), breaks = c(0, 0.5, 1.0, 1.5, 2.0, 2.5))
featurePlot(Juvenile15yr_DH2_1.enhanced, "LAMC3") + scale_fill_gradientn(colors = c(low = 'white', high = 'brown'), limits = c(0.0,2.0), breaks = c(0, 0.5, 1.0, 1.5, 2.0))
 				
								 
enhanced.plots <- purrr::map(markers, function(x) featurePlot(Juvenile15yr_DH2_1.enhanced, x))
patchwork::wrap_plots(enhanced.plots, ncol=2)	

spot.plots <- purrr::map(markers, function(x) featurePlot(Juvenile15yr_DH2_1, x))
patchwork::wrap_plots(c(enhanced.plots, spot.plots), ncol=2)	

dev.off()

Adult31yr_DH3 <- readVisium("/scratch/mshruv003/visium_08_10_21/Hockman_Visium/X201SC21082979-Z01-F001_02/raw_data/run_spaceranger_count_DH3a/outs")
set.seed(102)
Adult31yr_DH3  <- spatialPreprocess(Adult31yr_DH3, platform="Visium", 
                              n.PCs=7, n.HVGs=2000, skip.PCA = FALSE, log.normalize=TRUE)
							  
Adult31yr_DH3  <- qTune(Adult31yr_DH3, qs=seq(2, 10), platform="Visium", d=7)
qPlot(Adult31yr_DH3)
set.seed(149)

pdf("Adult31yr_DH3_nrep10000_d7_q_8_6.pdf")
Adult31yr_DH3  <- spatialCluster(Adult31yr_DH3, q=8, platform="Visium", d=7,
                           init.method="mclust", model="t", gamma=3,
                           nrep=10000, burn.in=1000,
                           save.chain=TRUE)

clusterPlot(Adult31yr_DH3)

featurePlot(Adult31yr_DH3, "FNBP1L")
featurePlot(Adult31yr_DH3, "KCNG1")
featurePlot(Adult31yr_DH3, "SLC35F4")
featurePlot(Adult31yr_DH3, "MYO16")
featurePlot(Adult31yr_DH3, "XKR4")
featurePlot(Adult31yr_DH3, "PENK")
featurePlot(Adult31yr_DH3, "PFKFB2")
featurePlot(Adult31yr_DH3, "LAMC3")



Adult31yr_DH3.enhanced <- spatialEnhance(Adult31yr_DH3, q=8, platform="Visium", d=7,
                                    model="t", gamma=3,
                                    jitter_prior=0.3, jitter_scale=3.5,
                                    nrep=10000, burn.in=1000,
                                    save.chain=TRUE)  

clusterPlot(Adult31yr_DH3.enhanced)									
markers <- c('FNBP1L', 'KCNG1', 'SLC35F4', 'MYO16', 'XKR4', 'PENK', 'PFKFB2', 'LAMC3')
Adult31yr_DH3.enhanced <- enhanceFeatures(Adult31yr_DH3.enhanced, Adult31yr_DH3,
                                     feature_names=markers,
                                     nrounds=0)
									 
logcounts(Adult31yr_DH3.enhanced)[markers, 1:5]	
rowData(Adult31yr_DH3.enhanced)[markers, ]

featurePlot(Adult31yr_DH3.enhanced, "FNBP1L") + scale_fill_gradientn(colors = c(low = 'white', high = 'brown'), limits = c(0.0,2.5), breaks = c(0, 0.5, 1.0, 1.5, 2.0, 2.5))
featurePlot(Adult31yr_DH3.enhanced, "KCNG1") + scale_fill_gradientn(colors = c(low = 'white', high = 'brown'), limits = c(0.0,3.5), breaks = c(0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5))
featurePlot(Adult31yr_DH3.enhanced, "SLC35F4") + scale_fill_gradientn(colors = c(low = 'white', high = 'brown'), limits = c(0.0,2.5), breaks = c(0, 0.5, 1.0, 1.5, 2.0, 2.5))
featurePlot(Adult31yr_DH3.enhanced, "MYO16") + scale_fill_gradientn(colors = c(low = 'white', high = 'brown'), limits = c(0.0,2.5), breaks = c(0, 0.5, 1.0, 1.5, 2.0, 2.5))
featurePlot(Adult31yr_DH3.enhanced, "XKR4") + scale_fill_gradientn(colors = c(low = 'white', high = 'brown'), limits = c(0.0,2.0), breaks = c(0, 0.5, 1.0, 1.5, 2.0))
featurePlot(Adult31yr_DH3.enhanced, "PENK") + scale_fill_gradientn(colors = c(low = 'white', high = 'brown'), limits = c(0.0,3.0), breaks = c(0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0))
featurePlot(Adult31yr_DH3.enhanced, "PFKFB2") + scale_fill_gradientn(colors = c(low = 'white', high = 'brown'), limits = c(0.0,2.5), breaks = c(0, 0.5, 1.0, 1.5, 2.0, 2.5))
featurePlot(Adult31yr_DH3.enhanced, "LAMC3") + scale_fill_gradientn(colors = c(low = 'white', high = 'brown'), limits = c(0.0,2.0), breaks = c(0, 0.5, 1.0, 1.5, 2.0))
 				
								 
enhanced.plots <- purrr::map(markers, function(x) featurePlot(Adult31yr_DH3.enhanced, x))
patchwork::wrap_plots(enhanced.plots, ncol=2)	

spot.plots <- purrr::map(markers, function(x) featurePlot(Adult31yr_DH3, x))
patchwork::wrap_plots(c(enhanced.plots, spot.plots), ncol=2)	

dev.off()

Adult31yr_DH4 <- readVisium("/scratch/mshruv003/visium_08_10_21/Hockman_Visium/X201SC21082979-Z01-F001_02/raw_data/run_spaceranger_count_DH4a/outs")
set.seed(102)
Adult31yr_DH4  <- spatialPreprocess(Adult31yr_DH4, platform="Visium", 
                              n.PCs=7, n.HVGs=2000, skip.PCA = FALSE, log.normalize=TRUE)
							  
Adult31yr_DH4  <- qTune(Adult31yr_DH4, qs=seq(2, 10), platform="Visium", d=7)
qPlot(Adult31yr_DH4)
set.seed(149)

pdf("Adult31yr_DH4_nrep10000_d7_q_8_6.pdf")
Adult31yr_DH4  <- spatialCluster(Adult31yr_DH4, q=8, platform="Visium", d=7,
                           init.method="mclust", model="t", gamma=3,
                           nrep=10000, burn.in=1000,
                           save.chain=TRUE)

clusterPlot(Adult31yr_DH4)

featurePlot(Adult31yr_DH4, "FNBP1L")
featurePlot(Adult31yr_DH4, "KCNG1")
featurePlot(Adult31yr_DH4, "SLC35F4")
featurePlot(Adult31yr_DH4, "MYO16")
featurePlot(Adult31yr_DH4, "XKR4")
featurePlot(Adult31yr_DH4, "PENK")
featurePlot(Adult31yr_DH4, "PFKFB2")
featurePlot(Adult31yr_DH4, "LAMC3")



Adult31yr_DH4.enhanced <- spatialEnhance(Adult31yr_DH4, q=8, platform="Visium", d=7,
                                    model="t", gamma=3,
                                    jitter_prior=0.3, jitter_scale=3.5,
                                    nrep=10000, burn.in=1000,
                                    save.chain=TRUE)  

clusterPlot(Adult31yr_DH4.enhanced)									
markers <- c('FNBP1L', 'KCNG1', 'SLC35F4', 'MYO16', 'XKR4', 'PENK', 'PFKFB2', 'LAMC3')
Adult31yr_DH4.enhanced <- enhanceFeatures(Adult31yr_DH4.enhanced, Adult31yr_DH4,
                                     feature_names=markers,
                                     nrounds=0)
									 
logcounts(Adult31yr_DH4.enhanced)[markers, 1:5]	
rowData(Adult31yr_DH4.enhanced)[markers, ]

featurePlot(Adult31yr_DH4.enhanced, "FNBP1L") + scale_fill_gradientn(colors = c(low = 'white', high = 'brown'), limits = c(0.0,2.5), breaks = c(0, 0.5, 1.0, 1.5, 2.0, 2.5))
featurePlot(Adult31yr_DH4.enhanced, "KCNG1") + scale_fill_gradientn(colors = c(low = 'white', high = 'brown'), limits = c(0.0,3.5), breaks = c(0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5))
featurePlot(Adult31yr_DH4.enhanced, "SLC35F4") + scale_fill_gradientn(colors = c(low = 'white', high = 'brown'), limits = c(0.0,2.5), breaks = c(0, 0.5, 1.0, 1.5, 2.0, 2.5))
featurePlot(Adult31yr_DH4.enhanced, "MYO16") + scale_fill_gradientn(colors = c(low = 'white', high = 'brown'), limits = c(0.0,2.5), breaks = c(0, 0.5, 1.0, 1.5, 2.0, 2.5))
featurePlot(Adult31yr_DH4.enhanced, "XKR4") + scale_fill_gradientn(colors = c(low = 'white', high = 'brown'), limits = c(0.0,2.0), breaks = c(0, 0.5, 1.0, 1.5, 2.0))
featurePlot(Adult31yr_DH4.enhanced, "PENK") + scale_fill_gradientn(colors = c(low = 'white', high = 'brown'), limits = c(0.0,3.0), breaks = c(0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0))
featurePlot(Adult31yr_DH4.enhanced, "PFKFB2") + scale_fill_gradientn(colors = c(low = 'white', high = 'brown'), limits = c(0.0,2.5), breaks = c(0, 0.5, 1.0, 1.5, 2.0, 2.5))
featurePlot(Adult31yr_DH4.enhanced, "LAMC3") + scale_fill_gradientn(colors = c(low = 'white', high = 'brown'), limits = c(0.0,2.0), breaks = c(0, 0.5, 1.0, 1.5, 2.0))
 				
enhanced.plots <- purrr::map(markers, function(x) featurePlot(Adult31yr_DH4.enhanced, x))
patchwork::wrap_plots(enhanced.plots, ncol=2)	

spot.plots <- purrr::map(markers, function(x) featurePlot(Adult31yr_DH4, x))
patchwork::wrap_plots(c(enhanced.plots, spot.plots), ncol=2)	

dev.off()