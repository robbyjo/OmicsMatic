library(BayesSpace)
library(ggplot2)
library(SingleCellExperiment)
library(dplyr)


Juvenile15yr_DH1_1 <- readVisium("/scratch/mshruv003/visium_08_10_21/Hockman_Visium/X201SC21082979-Z01-F001_01/raw_data/run_spaceranger_count_DH1a/outs")
set.seed(102)
Juvenile15yr_DH1_1  <- spatialPreprocess(Juvenile15yr_DH1_1, platform="Visium", 
                              n.PCs=7, n.HVGs=2000, skip.PCA = FALSE, log.normalize=TRUE)
							  
Juvenile15yr_DH1_1  <- qTune(Juvenile15yr_DH1_1, qs=seq(2, 10), platform="Visium", d=7)
qPlot(Juvenile15yr_DH1_1)
set.seed(149)

Juvenile15yr_DH1_1  <- spatialCluster(Juvenile15yr_DH1_1, q=8, platform="Visium", d=7,
                           init.method="mclust", model="t", gamma=3,
                           nrep=10000, burn.in=1000,
                           save.chain=TRUE)

Juvenile15yr_DH1_1.enhanced <- spatialEnhance(Juvenile15yr_DH1_1, q=8, platform="Visium", d=7,
                                    model="t", gamma=3,
                                    jitter_prior=0.3, jitter_scale=3.5,
                                    nrep=10000, burn.in=1000,
                                    save.chain=TRUE)  
								
markers <- c('FNBP1L', 'KCNG1', 'SLC35F4', 'MYO16', 'XKR4', 'PENK', 'RERGL', 'PFKFB2', 'LAMC3')
Juvenile15yr_DH1_1.enhanced <- enhanceFeatures(Juvenile15yr_DH1_1.enhanced, Juvenile15yr_DH1_1,
                                     feature_names=markers,
                                     nrounds=0)
									 
logcounts(Juvenile15yr_DH1_1.enhanced)[markers, 1:5]	
rowData(Juvenile15yr_DH1_1.enhanced)[markers, ]

enhanced_features_DH1 <- logcounts(Juvenile15yr_DH1_1.enhanced)[markers, ]

# Create a data frame for plotting
df_DH1 <- data.frame(
  Feature = rep(markers, each = ncol(enhanced_features_DH1)),
  Value = as.vector(enhanced_features_DH1),
  Age = rep("15_year_old_T1", each = ncol(enhanced_features_DH1)))


						
Juvenile15yr_DH2_1 <- readVisium("/scratch/mshruv003/visium_08_10_21/Hockman_Visium/X201SC21082979-Z01-F001_01/raw_data/run_spaceranger_count_DH2a/outs")
set.seed(102)
Juvenile15yr_DH2_1  <- spatialPreprocess(Juvenile15yr_DH2_1, platform="Visium", 
                              n.PCs=7, n.HVGs=2000, skip.PCA = FALSE, log.normalize=TRUE)
							  
Juvenile15yr_DH2_1  <- qTune(Juvenile15yr_DH2_1, qs=seq(2, 10), platform="Visium", d=7)
set.seed(149)


Juvenile15yr_DH2_1  <- spatialCluster(Juvenile15yr_DH2_1, q=8, platform="Visium", d=7,
                           init.method="mclust", model="t", gamma=3,
                           nrep=10000, burn.in=1000,
                           save.chain=TRUE)

Juvenile15yr_DH2_1.enhanced <- spatialEnhance(Juvenile15yr_DH2_1, q=8, platform="Visium", d=7,
                                    model="t", gamma=3,
                                    jitter_prior=0.3, jitter_scale=3.5,
                                    nrep=10000, burn.in=1000,
                                    save.chain=TRUE)  

markers <- c('FNBP1L', 'KCNG1', 'SLC35F4', 'MYO16', 'XKR4', 'PENK', 'RERGL', 'PFKFB2', 'LAMC3')
Juvenile15yr_DH2_1.enhanced <- enhanceFeatures(Juvenile15yr_DH2_1.enhanced, Juvenile15yr_DH2_1,
                                     feature_names=markers,
                                     nrounds=0)
									 
logcounts(Juvenile15yr_DH2_1.enhanced)[markers, 1:5]	
rowData(Juvenile15yr_DH2_1.enhanced)[markers, ]

enhanced_features_DH2 <- logcounts(Juvenile15yr_DH2_1.enhanced)[markers, ]

# Create a data frame for plotting
df_DH2 <- data.frame(
  Feature = rep(markers, each = ncol(enhanced_features_DH2)),
  Value = as.vector(enhanced_features_DH2),
  Age = rep("15_year_old_T2", each = ncol(enhanced_features_DH2)))
	


Adult31yr_DH3 <- readVisium("/scratch/mshruv003/visium_08_10_21/Hockman_Visium/X201SC21082979-Z01-F001_02/raw_data/run_spaceranger_count_DH3a/outs")
set.seed(102)
Adult31yr_DH3  <- spatialPreprocess(Adult31yr_DH3, platform="Visium", 
                              n.PCs=7, n.HVGs=2000, skip.PCA = FALSE, log.normalize=TRUE)
							  
Adult31yr_DH3  <- qTune(Adult31yr_DH3, qs=seq(2, 10), platform="Visium", d=7)
set.seed(149)

Adult31yr_DH3  <- spatialCluster(Adult31yr_DH3, q=8, platform="Visium", d=7,
                           init.method="mclust", model="t", gamma=3,
                           nrep=10000, burn.in=1000,
                           save.chain=TRUE)

Adult31yr_DH3.enhanced <- spatialEnhance(Adult31yr_DH3, q=8, platform="Visium", d=7,
                                    model="t", gamma=3,
                                    jitter_prior=0.3, jitter_scale=3.5,
                                    nrep=10000, burn.in=1000,
                                    save.chain=TRUE)  
									
markers <- c('FNBP1L', 'KCNG1', 'SLC35F4', 'MYO16', 'XKR4', 'PENK', 'RERGL', 'PFKFB2', 'LAMC3')
Adult31yr_DH3.enhanced <- enhanceFeatures(Adult31yr_DH3.enhanced, Adult31yr_DH3,
                                     feature_names=markers,
                                     nrounds=0)
									 
logcounts(Adult31yr_DH3.enhanced)[markers, 1:5]	
rowData(Adult31yr_DH3.enhanced)[markers, ]

enhanced_features_DH3 <- logcounts(Adult31yr_DH3.enhanced)[markers, ]

# Create a data frame for plotting
df_DH3 <- data.frame(
  Feature = rep(markers, each = ncol(enhanced_features_DH3)),
  Value = as.vector(enhanced_features_DH3),
  Age = rep("31_year_old_T1", each = ncol(enhanced_features_DH3)))



Adult31yr_DH4 <- readVisium("/scratch/mshruv003/visium_08_10_21/Hockman_Visium/X201SC21082979-Z01-F001_02/raw_data/run_spaceranger_count_DH4a/outs")
set.seed(102)
Adult31yr_DH4  <- spatialPreprocess(Adult31yr_DH4, platform="Visium", 
                              n.PCs=7, n.HVGs=2000, skip.PCA = FALSE, log.normalize=TRUE)
							  
Adult31yr_DH4  <- qTune(Adult31yr_DH4, qs=seq(2, 10), platform="Visium", d=7)
set.seed(149)

Adult31yr_DH4  <- spatialCluster(Adult31yr_DH4, q=8, platform="Visium", d=7,
                           init.method="mclust", model="t", gamma=3,
                           nrep=10000, burn.in=1000,
                           save.chain=TRUE)

Adult31yr_DH4.enhanced <- spatialEnhance(Adult31yr_DH4, q=8, platform="Visium", d=7,
                                    model="t", gamma=3,
                                    jitter_prior=0.3, jitter_scale=3.5,
                                    nrep=10000, burn.in=1000,
                                    save.chain=TRUE)  
								
markers <- c('FNBP1L', 'KCNG1', 'SLC35F4', 'MYO16', 'XKR4', 'PENK', 'RERGL', 'PFKFB2', 'LAMC3')
Adult31yr_DH4.enhanced <- enhanceFeatures(Adult31yr_DH4.enhanced, Adult31yr_DH4,
                                     feature_names=markers,
                                     nrounds=0)
									 
logcounts(Adult31yr_DH4.enhanced)[markers, 1:5]	
rowData(Adult31yr_DH4.enhanced)[markers, ]

enhanced_features_DH4 <- logcounts(Adult31yr_DH4.enhanced)[markers, ]

# Create a data frame for plotting
df_DH4 <- data.frame(
  Feature = rep(markers, each = ncol(enhanced_features_DH4)),
  Value = as.vector(enhanced_features_DH4),
  Age = rep("31_year_old_T2", each = ncol(enhanced_features_DH4)))


# Combine data frames
combined_data3 <- rbind(df_DH3, df_DH4, df_DH1, df_DH2)

filtered_data <- combined_data3 %>%
  filter(Value > 0)

filtered_data$Age <- factor(filtered_data$Age, levels = c("31_year_old_T1", "31_year_old_T2", "15_year_old_T1", "15_year_old_T2"))


features <- unique(filtered_data$Feature)

for (feature in features) {
  # Subset the data for the current feature
  feature_data <- subset(filtered_data, Feature == feature)
  
  # Create the plot for the current feature
  p <- ggplot(feature_data, aes(x = Age, y = Value, fill = Age)) +
    geom_boxplot(size = 0.5, fatten = 0.2) +
    labs(
      title = paste("Boxplot of", feature, "by Age Groups"),
      x = "Age",
      y = "Log-Counts",
      fill = "Age Group"
    ) +
    theme(axis.text.x = element_text(angle = 45, hjust = 0.5))+
    ylim(0, 2.5)
  
  # Save the plot to a file
  ggsave(paste0("Boxplot1_", feature, ".pdf"), plot = p, width = 11, height = 8.5)
}


