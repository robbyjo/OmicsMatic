#Quality control including (1) cell-level filtering, (2) gene-level filtering, (3) Doublet removal based on 
#doublets identified by the three different doublet removal pipelines (scripts 3-5)

# Load libraries
library(SingleCellExperiment)
library(Seurat)
library(tidyverse)
library(Matrix)
library(scales)
library(cowplot)
library(RCurl)

#Import the filtered feature-barcode matrices (Cell Ranger outputs)

sample <- c("4_T1", "5_T1", "5_T2", "7_T1", "7_T2", "9_T1", "9_T2", "15_T1_B1", "15_T2_B1", "15_T3_B1", "15_T4_B1", 
"15_T5_B1", "15_T6_B1", "15_T1_B2", "20_T1", "20_T2", "24_T1", "24_T2", "26_T1", "31_T1", "31_T2", "41_T1", "50_T1")

obj <- vector('list', length(sample))

for (x in 1:length(sample)){

sample.data <- Read10X(data.dir = "directory_to_cellranger_outputs/cellcount_", sample[x], "/outs/filtered_feature_bc_matrix")

obj[[x]] <- CreateSeuratObject(counts = sample.data,
                           min.features = 100, project = sample[x])

}

#P for paediatric A for adult
merged_seurat <- merge(x = obj[1], 
                       y = c(obj[2], obj[3], obj[4], obj[5], obj[6], obj[7], obj[8], obj[9], obj[10], obj[11], obj[12], obj[13], 
                       obj[14], obj[15], obj[16], obj[17], obj[18], obj[19], obj[20], obj[21], obj[22], obj[23]), 
                       add.cell.id = c("P_4_T1", c("P_5_T1", "P_5_T2", "P_7_T1", "P_7_T2", "P_9_T1", "P_9_T2", "P_15_T1_B1", "P_15_T2_B1", "P_15_T3_B1", "P_15_T4_B1", 
                      "P_15_T5_B1", "P_15_T6_B1", "P_15_T1_B2", "A_20_T1", "A_20_T2", "A_24_T1", "A_24_T2", "A_26_T1", "A_31_T1", "A_31_T2", "A_41_T1", "A_50_T1")))


merged_seurat$log10GenesPerUMI <- log10(merged_seurat$nFeature_RNA) / log10(merged_seurat$nCount_RNA)

# Compute percent mito ratio
merged_seurat$mitoRatio <- PercentageFeatureSet(object = merged_seurat, pattern = "^MT-")
merged_seurat$mitoRatio <- merged_seurat@meta.data$mitoRatio / 100

# Create metadata dataframe
metadata <- merged_seurat@meta.data

# Add cell IDs to metadata
metadata$cells <- rownames(metadata)

# Create sample column
metadata$sample <- metadata$cells 

# Rename columns
metadata <- metadata %>%
        dplyr::rename(seq_folder = orig.ident,
                      nUMI = nCount_RNA,
                      nGene = nFeature_RNA)

# Addmetadata back to Seurat object
merged_seurat@meta.data <- metadata

merged_seurat@meta.data$orig.ident <- merged_seurat@meta.data$cells

save(merged_seurat, file = "QC_directory/data/unfiltered_seurat_merged.RData")

metadata$sample <- factor(metadata$sample, levels = c("P_4_T1", "P_5_T1", "P_5_T2", "P_7_T1", "P_7_T2", "P_9_T1", "P_9_T2", "P_15_T1_B1", "P_15_T2_B1", "P_15_T3_B1", "P_15_T4_B1", 
                      "P_15_T5_B1", "P_15_T6_B1", "P_15_T1_B2", "A_20_T1", "A_20_T2", "A_24_T1", "A_24_T2", "A_26_T1", "A_31_T1", "A_31_T2", "A_41_T1", "A_50_T1"))

unfiltered_n_cells <- table(merged_seurat$sample)

write.csv(unfiltered_n_cells, file = "QC_directory/data/n_cells_unfiltered.csv")

#Visualize the number of cell counts per sample
unfiltered_cell_counts_per_sample <- metadata %>% 
  ggplot(aes(x=sample, fill=sample)) + 
  geom_bar() +
  geom_text(aes(label = ..count..), stat = "count", vjust = -0.3, colour = "black", size = 3)
  theme_classic() +
  theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust=1)) +
  theme(plot.title = element_text(hjust=0.5, face="bold")) +
  ggtitle("NCells")

ggsave("QC_directory/figures/unfiltered_cell_counts_per_sample.pdf", plot = unfiltered_cell_counts_per_sample)

# Visualize the number UMIs/transcripts per cell
Unfiltered_UMIs_per_cell <- metadata %>% 
  ggplot(aes(color=sample, x=nUMI, fill= sample)) + 
  geom_density(alpha = 0.2) + 
  scale_x_log10() + 
  theme_classic() +
  ylab("Cell density") +
  geom_vline(xintercept = 500)

ggsave("QC_directory/figures/unfiltered_UMIs_per_cell.pdf", plot = Unfiltered_UMIs_per_cell)

# Visualize the distribution of genes detected per cell via histogram
Unfiltered_genes_per_cell_histo <- metadata %>% 
  ggplot(aes(color=sample, x=nGene, fill= sample)) + 
  geom_density(alpha = 0.2) + 
  theme_classic() +
  scale_x_log10() + 
  geom_vline(xintercept = 300)

ggsave("QC_directory/figures/unfiltered_genes_per_cell_histo.pdf", plot = Unfiltered_genes_per_cell_histo)


# Visualize the distribution of genes detected per cell via boxplot
Unfiltered_genes_per_cell_box <- metadata %>% 
  ggplot(aes(x=sample, y=log10(nGene), fill=sample)) + 
  geom_boxplot() + 
  theme_classic() +
  theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust=1)) +
  theme(plot.title = element_text(hjust=0.5, face="bold")) +
  ggtitle("NCells vs NGenes")

ggsave("QC_directory/figures/unfiltered_genes_per_cell_box.pdf", plot = Unfiltered_genes_per_cell_box)

# Visualize the correlation between genes detected and number of UMIs and determine whether strong presence of cells with low numbers of genes/UMIs
Unfiltered_correlation_genes_and_UMIs <- metadata %>% 
  ggplot(aes(x=nUMI, y=nGene, color=mitoRatio)) + 
  geom_point() + 
  scale_colour_gradient(low = "gray90", high = "black") +
  stat_smooth(method=lm) +
  scale_x_log10() + 
  scale_y_log10() + 
  theme_classic() +
  geom_vline(xintercept = 500) +
  geom_hline(yintercept = 250) +
  facet_wrap(~sample)

ggsave("QC_directory/figures/unfiltered_correlation_genes_and_UMIs.pdf", plot = Unfiltered_correlation_genes_and_UMIs)

# Visualize the distribution of mitochondrial gene expression detected per cell
Unfiltered_mt_genes_per_cell <- metadata %>% 
  ggplot(aes(color=sample, x=mitoRatio, fill=sample)) + 
  geom_density(alpha = 0.2) + 
  scale_x_log10() + 
  theme_classic() +
  geom_vline(xintercept = 0.2)

ggsave("QC_directory/figures/unfiltered_mt_genes_per_cell.pdf", plot = Unfiltered_mt_genes_per_cell)


# Visualize the overall complexity of the gene expression by visualizing the genes detected per UMI
Unfiltered_genes_per_UMI <- metadata %>%
  ggplot(aes(x=log10GenesPerUMI, color = sample, fill=sample)) +
  geom_density(alpha = 0.2) +
  theme_classic() +
  geom_vline(xintercept = 0.8)

ggsave("QC_directory/figures/unfiltered_genes_per_UMI.pdf", plot = Unfiltered_genes_per_UMI)



#FILTER

sample <- c("4_T1", "5_T1", "5_T2", "7_T1", "7_T2", "9_T1", "9_T2", "15_T1_B1", "15_T2_B1", "15_T3_B1", "15_T4_B1", 
"15_T5_B1", "15_T6_B1", "15_T1_B2", "20_T1", "20_T2", "24_T1", "24_T2", "26_T1", "31_T1", "31_T2", "41_T1", "50_T1")

obj_clean <- vector('list', length(sample))

for (x in 1:length(sample)){

sample.data <- Read10X(data.dir = "directory_to_cellranger_outputs/cellcount_", sample[x], "/outs/filtered_feature_bc_matrix")

obj <- CreateSeuratObject(counts = sample.data,
                           min.features = 100, project = sample[x])

obj$barcode_ident <- paste0(sample[x], colnames(obj))

doublets <- read.csv("directory_to_doublet_analysis/", sample[x], "_intersect_Scrublet_DoubletDecon_union_DoubletFinder.csv")

predicted_doublet <- obj$barcode_ident %in% doublets$barcode

obj$predicted_doublet <- predicted_doublet

obj_clean[[x]] <- subset(obj, subset = predicted_doublet == "FALSE")

}

# Create a merged Seurat object
new_merged_seurat <-  merge(x = obj_clean[1], 
                       y = c(obj_clean[2], obj_clean[3], obj_clean[4], obj_clean[5], obj_clean[6], obj_clean[7], obj_clean[8], obj_clean[9], obj_clean[10], obj_clean[11], obj_clean[12], obj_clean[13], 
                       obj_clean[14], obj_clean[15], obj_clean[16], obj_clean[17], obj_clean[18], obj_clean[19], obj_clean[20], obj_clean[21], obj_clean[22], obj_clean[23]), 
                       add.cell.id = c("P_4_T1", c("P_5_T1", "P_5_T2", "P_7_T1", "P_7_T2", "P_9_T1", "P_9_T2", "P_15_T1_B1", "P_15_T2_B1", "P_15_T3_B1", "P_15_T4_B1", 
                      "P_15_T5_B1", "P_15_T6_B1", "P_15_T1_B2", "A_20_T1", "A_20_T2", "A_24_T1", "A_24_T2", "A_26_T1", "A_31_T1", "A_31_T2", "A_41_T1", "A_50_T1")))


new_merged_seurat$log10GenesPerUMI <- log10(new_merged_seurat$nFeature_RNA) / log10(new_merged_seurat$nCount_RNA)

# Compute percent mito ratio
new_merged_seurat$mitoRatio <- PercentageFeatureSet(object = new_merged_seurat, pattern = "^MT-")
new_merged_seurat$mitoRatio <- new_merged_seurat@meta.data$mitoRatio / 100

# Create metadata dataframe
metadata <- new_merged_seurat@meta.data

# Add cell IDs to metadata
metadata$cells <- rownames(metadata)

# Create sample column
metadata$sample <- metadata$cells

# Rename columns
metadata <- metadata %>%
        dplyr::rename(seq_folder = orig.ident,
                      nUMI = nCount_RNA,
                      nGene = nFeature_RNA)

# Addmetadata back to Seurat object
new_merged_seurat@meta.data <- metadata

new_merged_seurat@meta.data$orig.ident <- new_merged_seurat@meta.data$cells

# Filter out low quality reads using selected thresholds - these will change with experiment
filtered_seurat <- subset(x = new_merged_seurat, 
                          subset= (nUMI >= 500) & 
                            (nGene >= 250) & 
                            (log10GenesPerUMI > 0.80) & 
                            (mitoRatio < 0.20))


# Output a logical vector for every gene on whether the more than zero counts per cell

# First Extract counts
counts <- GetAssayData(object = filtered_seurat, slot = "counts")

# Then output a logical vector for every gene on whether the more than zero counts per cell
nonzero <- counts > 0

# Sums all TRUE values and returns TRUE if more than 10 TRUE values per gene
keep_genes <- Matrix::rowSums(nonzero) >= 10

# Only keeping those genes expressed in more than 10 cells
filtered_counts <- counts[keep_genes, ]

# Reassign to filtered Seurat object
filtered_seurat <- CreateSeuratObject(filtered_counts, names.field = 1:5, names.delim = "_", meta.data = filtered_seurat@meta.data, active.ident = filtered_seurat@active.ident)

Idents(filtered_seurat) <- filtered_seurat$orig.ident

levels(as.factor(Idents(filtered_seurat)))

# Save filtered subset to new metadata
metadata_clean <- filtered_seurat@meta.data

filter_n_cells <- table(filtered_seurat$sample)

write.csv(filter_n_cells, file = "QC_directory/data/n_cells_filtered.csv")


metadata_clean$sample <- factor(metadata$sample, levels = c("P_4_T1", "P_5_T1", "P_5_T2", "P_7_T1", "P_7_T2", "P_9_T1", "P_9_T2", "P_15_T1_B1", "P_15_T2_B1", "P_15_T3_B1", "P_15_T4_B1", 
                      "P_15_T5_B1", "P_15_T6_B1", "P_15_T1_B2", "A_20_T1", "A_20_T2", "A_24_T1", "A_24_T2", "A_26_T1", "A_31_T1", "A_31_T2", "A_41_T1", "A_50_T1"))

#Repeat above plots on the metadata_clean

#Visualize the number of cell counts per sample
filtered_cell_counts_per_sample <- metadata_clean %>% 
  ggplot(aes(x=sample, fill=sample)) + 
  geom_bar() +
  geom_text(aes(label = ..count..), stat = "count", vjust = -0.3, colour = "black", size = 3)
  theme_classic() +
  theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust=1)) +
  theme(plot.title = element_text(hjust=0.5, face="bold")) +
  ggtitle("NCells")

ggsave("QC_directory/figuures/filtered_cell_counts_per_sample.pdf", plot = filtered_cell_counts_per_sample)


# Visualize the number UMIs/transcripts per cell
filtered_UMIs_per_cell <- metadata_clean %>% 
  ggplot(aes(color=sample, x=nUMI, fill= sample)) + 
  geom_density(alpha = 0.2) + 
  scale_x_log10() + 
  theme_classic() +
  ylab("Cell density") +
  geom_vline(xintercept = 500)

ggsave("QC_directory/figures/filtered_UMIs_per_cell.pdf", plot = filtered_UMIs_per_cell)

# Visualize the distribution of genes detected per cell via histogram
filtered_genes_per_cell_histo <- metadata_clean %>% 
  ggplot(aes(color=sample, x=nGene, fill= sample)) + 
  geom_density(alpha = 0.2) + 
  theme_classic() +
  scale_x_log10() + 
  geom_vline(xintercept = 300)

ggsave("QC_directory/figures/filtered_genes_per_cell_histo.pdf", plot = filtered_genes_per_cell_histo)


# Visualize the distribution of genes detected per cell via boxplot
filtered_genes_per_cell_box <- metadata_clean %>% 
  ggplot(aes(x=sample, y=log10(nGene), fill=sample)) + 
  geom_boxplot() + 
  theme_classic() +
  theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust=1)) +
  theme(plot.title = element_text(hjust=0.5, face="bold")) +
  ggtitle("NCells vs NGenes")

ggsave("QC_directory/figures/filtered_genes_per_cell_box.pdf", plot = filtered_genes_per_cell_box)


# Visualize the correlation between genes detected and number of UMIs and determine whether strong presence of cells with low numbers of genes/UMIs
filtered_correlation_genes_and_UMIs <- metadata_clean %>% 
  ggplot(aes(x=nUMI, y=nGene, color=mitoRatio)) + 
  geom_point() + 
  scale_colour_gradient(low = "gray90", high = "black") +
  stat_smooth(method=lm) +
  scale_x_log10() + 
  scale_y_log10() + 
  theme_classic() +
  geom_vline(xintercept = 500) +
  geom_hline(yintercept = 250) +
  facet_wrap(~sample)

ggsave("QC_directory/figures/filtered_correlation_genes_and_UMIs.pdf", plot = filtered_correlation_genes_and_UMIs)


# Visualize the distribution of mitochondrial gene expression detected per cell
filtered_mt_genes_per_cell <- metadata_clean %>% 
  ggplot(aes(color=sample, x=mitoRatio, fill=sample)) + 
  geom_density(alpha = 0.2) + 
  scale_x_log10() + 
  theme_classic() +
  geom_vline(xintercept = 0.2)

ggsave("QC_directory/figures/filtered_mt_genes_per_cell.pdf", plot = filtered_mt_genes_per_cell)

# Visualize the overall complexity of the gene expression by visualizing the genes detected per UMI
filtered_genes_per_UMI <- metadata_clean %>%
  ggplot(aes(x=log10GenesPerUMI, color = sample, fill=sample)) +
  geom_density(alpha = 0.2) +
  theme_classic() +
  geom_vline(xintercept = 0.8)

ggsave("QC_directory/figures/filtered_genes_per_UMI.pdf", plot = filtered_genes_per_UMI)


filtered_seurat@meta.data$orig.ident <- filtered_seurat@meta.data$cells

# Create .RData object to load at any time
save(filtered_seurat, file= "QC_directory/data/filtered_seurat.RData")

#Remove mitochondrial genes from the object 
mt_genes <- grep("^MT-",rownames(filtered_seurat@assays$RNA@counts), value = TRUE)

counts <- GetAssayData(filtered_seurat, assay = "RNA")

counts <- counts[-(which(rownames(counts) %in% as.factor(mt_genes))),]

subset_counts <- subset(filtered_seurat, features = rownames(counts))

save(subset_counts, file= "QC_directory/data/filtered_seurat_mt_genes_removed.RData")


