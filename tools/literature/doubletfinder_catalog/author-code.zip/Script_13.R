#https://github.com/zhanghao-njmu/SCP
#https://github.com/zhanghao-njmu/SCP/blob/main/R/SCP-plot.R  #see p values i.e DE_threshold = "p_val_adj < 0.05"
#R-4.3.0

library(Seurat)
library(reticulate)
library(SCP) #Not with conda env activated
library(forcats)

seu <- readRDS("directory/Consensus_broad_high_res_annotated_seu.rds")

DefaultAssay(seu) <- 'RNA'

# Define an order of cluster identities
my_levels <- c("Inh L1-2 PAX6 CDH12", "Inh L1-2 PAX6 TNFAIP8L3", 
"Inh L1 SST NMBR", "Inh L1-4 LAMP5 LCP2",
 "Inh L1-2 LAMP5 DBP", "Inh L2-6 LAMP5 CA1",
"Inh L1 SST CHRNA4", "Inh L1-2 GAD1 MC4R", 
"Inh L1-2 SST BAGE2", "Inh L1-3 PAX6 SYT6", 
"Inh L1-2 VIP TSPAN12", "Inh L1-4 VIP CHRNA6", 
"Inh L1-3 VIP ADAMTSL1", "Inh L1-4 VIP PENK", 
"Inh L2-6 VIP QPCT", "Inh L3-6 VIP HS3ST3A1", 
"Inh L1-2 VIP PCDH20","Inh L2-5 VIP SERPINF1", 
"Inh L2-5 VIP TYR", "Inh L1-3 VIP CHRM2", 
"Inh L2-4 VIP CBLN1", "Inh L1-3 VIP CCDC184", 
"Inh L1-3 VIP GGH", "Inh L1-2 VIP LBH", 
"Inh L2-3 VIP CASC6", "Inh L2-4 VIP SPAG17",
"Inh L1-4 VIP OPRM1", "Inh L3-6 SST NPY",
"Inh L3-6 SST HPGD", "Inh L4-6 SST B3GAT2",
"Inh L5-6 SST KLHDC8A", "Inh L5-6 SST NPM1P10",
"Inh L4-6 SST GXYLT2", "Inh L4-5 SST STK32A",
"Inh L1-3 SST CALB1", "Inh L3-5 SST ADGRG6", 
"Inh L2-4 SST FRZB", "Inh L5-6 SST TH", 
"Inh L5-6 GAD1 GLP1R", "Inh L5-6 PVALB LGR5",
 "Inh L4-5 PVALB MEPE", "Inh L2-4 PVALB WFDC2", 
"Inh L4-6 PVALB SULF1", "Inh L5-6 SST MIR548F2", 
"Inh L2-5 PVALB SCUBE3", "Exc L2 LAMP5 LTK", 
"Exc L2-4 LINC00507 GLP2R", "Exc L2-3 LINC00507 FREM3", 
"Exc L5-6 THEMIS C1QL3", "Exc L3-4 RORB CARM1P1", 
"Exc L3-5 RORB ESR1", "Exc L3-5 RORB COL22A1", 
"Exc L3-5 RORB FILIP1L",
"Exc L3-5 RORB TWIST2", "Exc L4-5 RORB FOLH1B",
"Exc L4-6 RORB SEMA3E", "Exc L4-5 RORB DAPK2",
"Exc L5-6 RORB TTC12", "Exc L4-6 RORB C1R",
"Exc L4-5 FEZF2 SCN4B", "Exc L5-6 THEMIS DCSTAMP",
"Exc L5-6 THEMIS CRABP1", "Exc L5-6 THEMIS FGF10",
"Exc L4-6 FEZF2 IL26", "Exc L5-6 FEZF2 ABO",
"Exc L6 FEZF2 SCUBE1", "Exc L5-6 SLC17A7 IL15",
"Exc L6 FEZF2 OR2T8", "Exc L5-6 FEZF2 EFTUD1P1",
"OPC L1-6 PDGFRA", "Astro L1-6 FGFR3 SLC14A1",
"Astro L1-2 FGFR3 GFAP", "Oligo L1-6 OPALIN", 
"Endo L2-6 NOSTRIN", "Micro L1-3 TYROBP")

# Relevel object@ident
seu$MTG_annotation_log_normalised <- factor(seu$MTG_annotation_log_normalised, levels= my_levels)

#Correlation heatmap between MTG cell types with MTG cell types

ht <- CellCorHeatmap(
  srt_query = seu, srt_ref = seu,
  query_group = "MTG_annotation_log_normalised", ref_group = "MTG_annotation_log_normalised",
  nlabel = 3, label_size = 5, heatmap_palette = "RdYlBu", label_by = "row",
  show_row_names = TRUE, show_column_names = TRUE
)
pdf("directory/Similarity_MTG_cell_types.pdf", width = 20, height =17)
print(ht$plot)
dev.off()

#Correlation heatmap our datasets vs Allen MTG

Allen <- readRDS("directory/MTG_eight_donors_seurat_log_normalised.rds")

Idents(Allen) <- Allen$cluster

Allen_levels <- c("Inh L1-2 PAX6 CDH12", "Inh L1-2 PAX6 TNFAIP8L3", 
"Inh L1 SST NMBR", "Inh L1-4 LAMP5 LCP2",
 "Inh L1-2 LAMP5 DBP", "Inh L2-6 LAMP5 CA1",
"Inh L1 SST CHRNA4", "Inh L1-2 GAD1 MC4R", 
"Inh L1-2 SST BAGE2", "Inh L1-3 PAX6 SYT6", 
"Inh L1-2 VIP TSPAN12", "Inh L1-4 VIP CHRNA6", 
"Inh L1-3 VIP ADAMTSL1", "Inh L1-4 VIP PENK", 
"Inh L2-6 VIP QPCT", "Inh L3-6 VIP HS3ST3A1", 
"Inh L1-2 VIP PCDH20","Inh L2-5 VIP SERPINF1", 
"Inh L2-5 VIP TYR", "Inh L1-3 VIP CHRM2", 
"Inh L2-4 VIP CBLN1", "Inh L1-3 VIP CCDC184", 
"Inh L1-3 VIP GGH", "Inh L1-2 VIP LBH", 
"Inh L2-3 VIP CASC6", "Inh L2-4 VIP SPAG17",
"Inh L1-4 VIP OPRM1", "Inh L3-6 SST NPY",
"Inh L3-6 SST HPGD", "Inh L4-6 SST B3GAT2",
"Inh L5-6 SST KLHDC8A", "Inh L5-6 SST NPM1P10",
"Inh L4-6 SST GXYLT2", "Inh L4-5 SST STK32A",
"Inh L1-3 SST CALB1", "Inh L3-5 SST ADGRG6", 
"Inh L2-4 SST FRZB", "Inh L5-6 SST TH", 
"Inh L5-6 GAD1 GLP1R", "Inh L5-6 PVALB LGR5",
 "Inh L4-5 PVALB MEPE", "Inh L2-4 PVALB WFDC2", 
"Inh L4-6 PVALB SULF1", "Inh L5-6 SST MIR548F2", 
"Inh L2-5 PVALB SCUBE3", "Exc L2 LAMP5 LTK", 
"Exc L2-4 LINC00507 GLP2R", "Exc L2-3 LINC00507 FREM3", 
"Exc L5-6 THEMIS C1QL3", "Exc L3-4 RORB CARM1P1", 
"Exc L3-5 RORB ESR1", "Exc L3-5 RORB COL22A1", 
"Exc L3-5 RORB FILIP1L",
"Exc L3-5 RORB TWIST2", "Exc L4-5 RORB FOLH1B",
"Exc L4-6 RORB SEMA3E", "Exc L4-5 RORB DAPK2",
"Exc L5-6 RORB TTC12", "Exc L4-6 RORB C1R",
"Exc L4-5 FEZF2 SCN4B", "Exc L5-6 THEMIS DCSTAMP",
"Exc L5-6 THEMIS CRABP1", "Exc L5-6 THEMIS FGF10",
"Exc L4-6 FEZF2 IL26", "Exc L5-6 FEZF2 ABO",
"Exc L6 FEZF2 SCUBE1", "Exc L5-6 SLC17A7 IL15",
"Exc L6 FEZF2 OR2T8", "Exc L5-6 FEZF2 EFTUD1P1",
"OPC L1-6 PDGFRA", "Astro L1-6 FGFR3 SLC14A1",
"Astro L1-2 FGFR3 GFAP", "Oligo L1-6 OPALIN", 
"Endo L2-6 NOSTRIN", "Micro L1-3 TYROBP")

Allen$cluster <- factor(Allen$cluster, levels = Allen_levels)
DefaultAssay(Allen) <- 'RNA'

ht <- CellCorHeatmap(
  srt_query = seu, srt_ref = Allen,
  query_group = "MTG_annotation_log_normalised", ref_group = "cluster",
  nlabel = 3, label_size = 5, label_by = "row",
  show_row_names = TRUE, show_column_names = TRUE, heatmap_palette = "RdYlBu"
)
pdf("directory/01Similarity_query_vs_Allen_MTG_ref.pdf", width = 20, height =17)
print(ht$plot)
dev.off()

seu$MTG_annotation_log_normalised <- fct_rev(seu$MTG_annotation_log_normalised)
Allen$cluster <- fct_rev(Allen$cluster)

ht <- CellCorHeatmap(
  srt_query = seu, srt_ref = Allen,
  query_group = "MTG_annotation_log_normalised", ref_group = "cluster",
  nlabel = 3, label_size = 5, label_by = "row",
  show_row_names = TRUE, show_column_names = TRUE, heatmap_palette = "RdYlBu", column_names_side = "bottom")

pdf("directory/02Similarity_query_vs_Allen_MTG_ref.pdf", width = 18, height =17)
print(ht$plot)
dev.off()

#Repeat above subsetting paeds or adults

seu <- readRDS("directory/Consensus_broad_high_res_annotated_seu.rds")

#subset paediatric
seu_paed <- subset(seu, subset = Age_group == 'Paediatric')
DefaultAssay(seu) <- 'RNA'

#subset adult
seu_adult <- subset(seu, subset = Age_group == 'Adult')
DefaultAssay(seu) <- 'RNA'

