#Doublet Finder pipeline
library(Seurat) 
library(Matrix)
library(fields) 
library(KernSmooth) 
library(ROCR) 
library(parallel) 
library(DoubletFinder)
library(SingleCellExperiment)
library(Seurat)
library(tidyverse)
library(Matrix)
library(scales)
library(cowplot)
library(RCurl)
library(DeconRNASeq)
library(gplots)
library(dplyr)
library(MCL)
library(clusterProfiler)
library(mygene)
library(tidyr)
library(R.utils)
library(foreach)
library(doParallel)
library(stringr)

#Preclustering 

#Run QC script (script 1) prior to filtering

#load unfiltered_seurat object (no doublets or any nuclei removed)
load("QC_directory/data/unfiltered_seurat_merged.RData")

# Normalize the counts
seurat_phase <- NormalizeData(merged_seurat)

# Load cell cycle markers
load("QC_directory/data/cycle.rda")

#Perform individually for all samples
split_seurat <- SplitObject(seurat_phase, split.by = "sample")

split_seurat <- split_seurat[c("P_4_T1", "P_5_T1", "P_5_T2", "P_7_T1", "P_7_T2", "P_9_T1", "P_9_T2", "P_15_T1_B1", "P_15_T2_B1", "P_15_T3_B1", "P_15_T4_B1", 
                      "P_15_T5_B1", "P_15_T6_B1", "P_15_T1_B2", "A_20_T1", "A_20_T2", "A_24_T1", "A_24_T2", "A_26_T1", "A_31_T1", "A_31_T2", "A_41_T1", "A_50_T1")]

for (i in 1:length(split_seurat)){
  split_seurat[[i]] <- CellCycleScoring(split_seurat[[i]], 
                                 g2m.features = g2m_genes, 
                                 s.features = s_genes)
  split_seurat[[i]] <- FindVariableFeatures(split_seurat[[i]], 
                     selection.method = "vst",
                     nfeatures = 2000, 
                     verbose = FALSE)
  split_seurat[[i]] <- ScaleData(split_seurat[[i]], vars.to.regress = c("mitoRatio"))
  split_seurat[[i]] <- RunPCA(split_seurat[[i]])
  split_seurat[[i]] <- RunTSNE(split_seurat[[i]])
  saveRDS(split_seurat[[i]], paste0("Doublet_removal/Preclustering/SCT/data/", split_seurat[[i]]@meta.data$sample[1], "_unclustered_seurat.rds"))
}

#Perform on the merged sample
seurat_phase <- CellCycleScoring(seurat_phase, 
                                 g2m.features = g2m_genes, 
                                 s.features = s_genes)

seurat_phase <- FindVariableFeatures(seurat_phase, 
                     selection.method = "vst",
                     nfeatures = 2000, 
                     verbose = FALSE)

seurat_phase <- ScaleData(seurat_phase, vars.to.regress = c("mitoRatio"))


# Scale the counts
# Perform PCA
seurat_phase <- RunPCA(seurat_phase)

# Plot the PCA colored by cell cycle phase
PCA_cell_cycle_phase <- DimPlot(seurat_phase,
        reduction = "pca",
        group.by= "Phase",
        split.by = "Phase")

ggsave("Doublet_removal/Preclustering/SCT/figures/PCA_cell_cycle_phase.pdf", plot = PCA_cell_cycle_phase)

UMAP_unintegrated_for_comparison <- RunUMAP(seurat_phase, 
                             dims = 1:40,
			     reduction = "pca")
# Plot UMAP                             
UMAP_unintegrated_plot <- DimPlot(UMAP_unintegrated_for_comparison)  

ggsave("Doublet_removal/Preclustering/SCT/figures/UMAP_unintegrated_for_comparison.pdf", plot = UMAP_unintegrated_plot)


UMAP_unintegrated_split <- DimPlot(UMAP_unintegrated_for_comparison, split.by = "sample")       
ggsave("Doublet_removal/Preclustering/SCT/figures/UMAP_unintegrated_split_by_sample.pdf", plot = UMAP_unintegrated_split)


split_seurat <- SplitObject(UMAP_unintegrated_for_comparison, split.by = "sample")

split_seurat <- split_seurat[c("P_4_T1", "P_5_T1", "P_5_T2", "P_7_T1", "P_7_T2", "P_9_T1", "P_9_T2", "P_15_T1_B1", "P_15_T2_B1", "P_15_T3_B1", "P_15_T4_B1", 
                      "P_15_T5_B1", "P_15_T6_B1", "P_15_T1_B2", "A_20_T1", "A_20_T2", "A_24_T1", "A_24_T2", "A_26_T1", "A_31_T1", "A_31_T2", "A_41_T1", "A_50_T1")]


for (i in 1:length(split_seurat)){
	UMAP_unintegrated <- DimPlot(split_seurat[[i]])
	ggsave(paste0("Doublet_removal/SCT/Preclustering/figures/", "UMAP_", split_seurat[[i]]@meta.data$sample[1], "_unintegrated.pdf"), plot = UMAP_unintegrated)
}

PCA_unintegrated_for_comparison <- PCAPlot(seurat_phase,
        split.by = "sample") 
ggsave("Doublet_removal/Preclustering/SCT/figures/PCA_unintegrated_for_comparison.pdf", plot = PCA_unintegrated_for_comparison)


options(future.globals.maxSize = 4000 * 1024^2)

# Split seurat object by condition to perform cell cycle scoring and SCT on all samples
split_seurat <- SplitObject(merged_seurat, split.by = "sample")

split_seurat <- split_seurat[c("P_4_T1", "P_5_T1", "P_5_T2", "P_7_T1", "P_7_T2", "P_9_T1", "P_9_T2", "P_15_T1_B1", "P_15_T2_B1", "P_15_T3_B1", "P_15_T4_B1", 
                      "P_15_T5_B1", "P_15_T6_B1", "P_15_T1_B2", "A_20_T1", "A_20_T2", "A_24_T1", "A_24_T2", "A_26_T1", "A_31_T1", "A_31_T2", "A_41_T1", "A_50_T1")]

for (i in 1:length(split_seurat)) {
    split_seurat[[i]] <- NormalizeData(split_seurat[[i]], verbose = TRUE)
    split_seurat[[i]] <- CellCycleScoring(split_seurat[[i]], g2m.features=g2m_genes, s.features=s_genes)
    split_seurat[[i]] <- SCTransform(split_seurat[[i]], vars.to.regress = c("mitoRatio"))
    saveRDS(split_seurat[[i]], paste0("Doublet_removal/Preclustering/SCT/data/", split_seurat[[i]]@meta.data$sample[1], "_SCT.rds"))
}

# Select the most variable features to use for integration
integ_features <- SelectIntegrationFeatures(object.list = split_seurat, 
                                            nfeatures = 3000) 


# Prepare the SCT list object for integration
split_seurat <- PrepSCTIntegration(object.list = split_seurat, 
                                   anchor.features = integ_features)

# Find best buddies - can take a while to run
integ_anchors <- FindIntegrationAnchors(object.list = split_seurat, 
                                        normalization.method = "SCT", 
                                        anchor.features = integ_features, reference = 1)
# Integrate across conditions
seurat_integrated <- IntegrateData(anchorset = integ_anchors, 
                                   normalization.method = "SCT")

# Save integrated seurat object

saveRDS(seurat_integrated, "Doublet_removal/Preclustering/SCT/data/integrated_seurat.rds")

seurat_integrated <- RunPCA(object = seurat_integrated)

# Plot PCA
PCA_plot_integrated <- PCAPlot(seurat_integrated,
        split.by = "sample")  

ggsave("Doublet_removal/Preclustering/SCT/figures/PCA_plot_integrated.pdf", plot = PCA_plot_integrated)

# Run UMAP
seurat_integrated <- RunUMAP(seurat_integrated, 
                             dims = 1:40,
			     reduction = "pca")


# Plot UMAP                             
UMAP_integrated <- DimPlot(seurat_integrated)                             

ggsave("Doublet_removal/Preclustering/SCT/figures/UMAP_integrated.pdf", plot = UMAP_integrated)

#UMAP split by sample  
UMAP_integrated_split_by_sample <- DimPlot(seurat_integrated,
        split.by = "sample")  

ggsave("Doublet_removal/Preclustering/SCT/figures/UMAP_integrated_split_by_sample.pdf", plot = UMAP_integrated_split_by_sample)


#Each sample separately

split_seurat <- SplitObject(seurat_integrated, split.by = "sample")

split_seurat <- split_seurat[c("P_4_T1", "P_5_T1", "P_5_T2", "P_7_T1", "P_7_T2", "P_9_T1", "P_9_T2", "P_15_T1_B1", "P_15_T2_B1", "P_15_T3_B1", "P_15_T4_B1", 
                      "P_15_T5_B1", "P_15_T6_B1", "P_15_T1_B2", "A_20_T1", "A_20_T2", "A_24_T1", "A_24_T2", "A_26_T1", "A_31_T1", "A_31_T2", "A_41_T1", "A_50_T1")]

for (i in 1:length(split_seurat)) {
	UMAP_unintegrated <- DimPlot(split_seurat[[i]])
	ggsave(paste0("Doublet_removal/Preclustering/SCT/figures/", "UMAP_", split_seurat[[i]]@meta.data$sample[1], "_integrated.pdf"), plot = UMAP_unintegrated)
}

#Clustering analysis 
for (i in 1:length(split_seurat)) {
  seurat_SCT <- readRDS(paste0("Doublet_removal/Preclustering/SCT/data/", split_seurat[i], "_SCT.rds"))
  seurat_SCT <- RunPCA(seurat_SCT, verbose = FALSE)
  PC_heatmap <- DimHeatmap(seurat_SCT, 
           dims = 1:9, 
           cells = 500, 
           balanced = TRUE)
  ggsave(paste0("Doublet_removal/Preclustering/Clustering/figures/", split_seurat[i], "_PC_heatmap.pdf"), plot = PC_heatmap)
  elbow_plot <- ElbowPlot(object = seurat_SCT, ndims = 40)
  ggsave(paste0("Doublet_removal/Preclustering/Clustering/figures/", split_seurat[i], "_elbow_plot.pdf"), plot = elbow_plot)
  seurat_SCT <- FindNeighbors(object = seurat_SCT, dims = 1:40)                   
  clusters_seurat <- FindClusters(object = seurat_SCT, resolution = c(0.2))
  Idents(object = clusters_seurat) <- "SCT_snn_res.0.2"
  clusters_seurat <- RunUMAP(clusters_seurat, reduction = "pca", dims = 1:40)
  saveRDS(clusters_seurat, file = paste0("Doublet_removal/Preclustering/Clustering/data/", split_seurat[i], "_clusters_seurat.rds"))
  UMAP_clusters_seurat <- DimPlot(clusters_seurat, reduction = "umap", label = TRUE, label.size = 6)
  ggsave(paste0("Doublet_removal/Preclustering/Clustering/figures/", split_seurat[i], "_UMAP_clusters_seurat.pdf"), plot = UMAP_clusters_seurat)
  n_cells <- FetchData(clusters_seurat, vars = c("ident", "orig.ident"))%>% 
  dplyr::count(ident, orig.ident) %>%
  tidyr::spread(ident, n)
  write.csv(n_cells, file = paste0("Doublet_removal/Preclustering/Clustering/data/", split_seurat[i], "_number_of_cells_per_cluster.csv"))
  UMAP_cell_cycle_phase <- DimPlot(clusters_seurat,
        label = TRUE, 
        split.by = "Phase")  + NoLegend()
  ggsave(paste0("Doublet_removal/Preclustering/Clustering/figures/", split_seurat[i], "_UMAP_cell_cycle_phase.pdf"), plot = UMAP_cell_cycle_phase)
  metrics <-  c("nUMI", "nGene", "S.Score", "G2M.Score", "mitoRatio")
  feature_plot <- FeaturePlot(clusters_seurat, 
            reduction = "umap", 
            features = metrics,
            pt.size = 0.4, 
            sort.cell = TRUE,
            min.cutoff = 'q10',
            label = TRUE)
  ggsave(paste0("Doublet_removal/Preclustering/Clustering/figures/", split_seurat[i], "_Feature_plot_metrics.pdf"), plot = feature_plot)
}

#Load pre-processed Seurat object after normalisation and PCA has been run: 

split_seurat <- c("P_4_T1", "P_5_T1", "P_5_T2", "P_7_T1", "P_7_T2", "P_9_T1", "P_9_T2", "P_15_T1_B1", "P_15_T2_B1", "P_15_T3_B1", "P_15_T4_B1", 
                      "P_15_T5_B1", "P_15_T6_B1", "P_15_T1_B2", "A_20_T1", "A_20_T2", "A_24_T1", "A_24_T2", "A_26_T1", "A_31_T1", "A_31_T2", "A_41_T1", "A_50_T1")


for (i in 1:length(split_seurat)) {
 unclustered_seurat <- readRDS(paste0("Doublet_removal/Preclustering/SCT/data/", split_seurat[i], "_unclustered_seurat.rds"))
 sweep.res.list_normalised <- paramSweep_v3(unclustered_seurat, PCs = 1:10, sct = FALSE)
 sweep.stats_normalised <- summarizeSweep(sweep.res.list_normalised, GT = FALSE)
 bcmvn_normalised <- find.pK(sweep.stats_normalised)
 clustered_seurat <- readRDS(paste0("Doublet_removal/Preclustering/Clustering/data/", split_seurat[i], "_clusters_seurat.rds")) 
 annotations <- clustered_seurat@meta.data$SCT_snn_res.0.2
 homotypic.prop <- modelHomotypic(annotations)
 nExp_poi <- round(0.1*nrow(unclustered_seurat@meta.data))
 Exp_poi.adj <- round(nExp_poi*(1-homotypic.prop))
 unclustered_seurat_DoubletFinder <- doubletFinder_v3(unclustered_seurat, PCs = 1:10, pN = 0.25, pK = as.numeric(bcmvn_normalised$pK[which.max(bcmvn_normalised$BCmetric)]), nExp = nExp_poi, reuse.pANN = FALSE, sct = FALSE)
 DoubletFinder_output <- as.data.frame(rownames(unclustered_seurat_DoubletFinder@meta.data))
 DoubletFinder_output[ , 2] <- unclustered_seurat_DoubletFinder@meta.data[15]
 colnames(DoubletFinder_output) <- c("barcode", "predicted_doublet")
 write.csv(DoubletFinder_output, paste0("Doublet_removal/DoubletFinder/", split_seurat[i], "_DoubletFinder_output.csv"), row.names=FALSE)
 DoubletFinder_doublets <- subset(DoubletFinder_output, DoubletFinder_output$predicted_doublet == "Doublet")
 DoubletFinder_nondoublets <- subset(DoubletFinder_output, DoubletFinder_output$predicted_doublet == "Singlet")
 write.csv(DoubletFinder_doublets, paste0("Doublet_removal/DoubletFinder/", split_seurat[i], "_DoubletFinder_doublets.csv"), row.names=FALSE)
 write.csv(DoubletFinder_nondoublets, paste0("Doublet_removal/DoubletFinder/", split_seurat[i], "_DoubletFinder_nondoublets.csv"), row.names=FALSE)
}

for (i in 1:length(split_seurat)) {
 clustered_seurat <- readRDS(paste0("Doublet_removal/Preclustering/Clustering/data/", split_seurat[i], "_clusters_seurat.rds")) 
 DoubletFinder_doublets <- read.csv(paste0("Doublet_removal/DoubletFinder/", split_seurat[i], "_DoubletFinder_doublets.csv"))
 UMAP_visualise_doublets <- DimPlot(clustered_seurat, reduction = "umap", cells.highlight= as.list(DoubletFinder_doublets$barcode)) + NoLegend()
 ggsave(paste0("Doublet_removal/DoubletFinder/", split_seurat[i], "_doublet_finder_UMAP.pdf"), UMAP_visualise_doublets)
}

