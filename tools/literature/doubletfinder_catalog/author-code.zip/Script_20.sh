#!/bin/sh
#SBATCH --account=humbio
#SBATCH --partition=sadacc-long
#SBATCH --nodes=1 --ntasks=40
#SBATCH --time=150:00:00
#SBATCH --job-name=GSEA
#SBATCH --mail-user=stychr009@myuct.ac.za
#SBATCH --mail-type=BEGIN,END,FAIL


#Try on all cell types 
#Gene lists ranked by -log(p-value)*log2FoldChange 

module load java/jdk-11
chmod a+x GSEA_directory/gsea-cli.sh

cluster=("Inh_L1_2_PAX6_CDH12" "Inh_L1_4_LAMP5_LCP2"
 "Inh_L2_6_LAMP5_CA1" "Inh_L1_SST_NMBR"
"Inh_L1_2_GAD1_MC4R" "Inh_L1_2_SST_BAGE2"
"Inh_L1_2_VIP_TSPAN12" "Inh_L1_4_VIP_CHRNA6"
"Inh_L1_3_VIP_ADAMTSL1" "Inh_L2_6_VIP_QPCT"
"Inh_L3_6_VIP_HS3ST3A1" "Inh_L1_2_VIP_PCDH20"
"Inh_L2_5_VIP_SERPINF1" "Inh_L2_5_VIP_TYR"
"Inh_L1_3_VIP_CHRM2" "Inh_L2_4_VIP_CBLN1"
"Inh_L1_3_VIP_CCDC184" "Inh_L1_3_VIP_GGH"
"Inh_L1_2_VIP_LBH" "Inh_L1_4_VIP_OPRM1"
"Inh_L3_6_SST_NPY" "Inh_L4_6_SST_B3GAT2"
"Inh_L5_6_SST_NPM1P10" "Inh_L4_6_SST_GXYLT2"
"Inh_L4_5_SST_STK32A" "Inh_L1_3_SST_CALB1"
"Inh_L3_5_SST_ADGRG6" "Inh_L2_4_SST_FRZB"
"Inh_L5_6_PVALB_LGR5" "Inh_L2_4_PVALB_WFDC2"
"Inh_L4_6_PVALB_SULF1" "Inh_L5_6_SST_MIR548F2"
"Inh_L2_5_PVALB_SCUBE3" "Exc_L2_LAMP5_LTK"
"Exc_L2_3_LINC00507_FREM3" "Exc_L5_6_THEMIS_C1QL3"
"Exc_L3_5_RORB_ESR1" "Exc_L3_5_RORB_COL22A1"
"Exc_L3_5_RORB_FILIP1L" "Exc_L3_5_RORB_TWIST2"
"Exc_L4_5_RORB_FOLH1B" "Exc_L4_6_RORB_SEMA3E"
"Exc_L4_5_RORB_DAPK2" "Exc_L5_6_THEMIS_CRABP1"
"Exc_L5_6_THEMIS_FGF10" "Exc_L4_6_FEZF2_IL26"
"Exc_L5_6_FEZF2_ABO" "OPC_L1_6_PDGFRA"
"Astro_L1_6_FGFR3_SLC14A1" "Astro_L1_2_FGFR3_GFAP"
"Oligo_L1_6_OPALIN" "Endo_L2_6_NOSTRIN"
"Micro_L1_3_TYROBP")


for i in "${cluster[@]}"
do
/GSEA_directory/gsea-cli.sh GSEAPreranked -gmx /GSEA_directory/c5.go.bp.v2023.1.Hs.symbols.gmt -collapse No_Collapse -mode Max_probe -norm meandiv -nperm 1000 -rnk "/GSEA_directory/Preranked_geneLists/$i""_GSEA_logP_log2FC.rnk" -scoring_scheme classic -rpt_label "$i""_logP_log2FC" -create_svgs false -include_only_symbols true -make_sets true -plot_top_x 0 -rnd_seed timestamp -set_max 200 -set_min 15 -zip_report false -out /GSEA_directory/Output_nperm1000_min15_max200/
done 

