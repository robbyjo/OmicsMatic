#Differential expression analysis for Paediatric vs Adult
#Based off HBC tutorial https://github.com/hbctraining/scRNA-seq_online/blob/master/lessons/pseudobulk_DESeq2_scrnaseq.md
#See DESeq2 notes on Wald test https://bioconductor.org/packages/devel/bioc/manuals/DESeq2/man/DESeq2.pdf

library(scater)
library(Seurat)
library(tidyverse)
library(cowplot)
library(Matrix.utils)
library(edgeR)
library(dplyr)
library(magrittr)
library(Matrix)
library(purrr)
library(reshape2)
library(S4Vectors)
library(tibble)
library(SingleCellExperiment)
library(pheatmap)
library(apeglm)
library(png)
library(DESeq2)
library(RColorBrewer)
library(ashr)
library(ggrepel)


seu <- readRDS("directory_to_processed_seurat_object/seurat_object.rds")

seu$cluster_id <- Idents(seu)

# Extract raw counts and metadata to create SingleCellExperiment object

seu$sample_id <- seu$Biological_replicate

counts <- seu@assays$RNA@counts

metadata <- seu@meta.data

# Create single cell experiment object
sce <- SingleCellExperiment(assays = list(counts = counts), 
                            colData = metadata)

# Identify groups for aggregation of counts
groups <- colData(sce)[, c("cluster_id", "sample_id")]

# Named vector of cluster names
kids <- purrr::set_names(levels(sce$cluster_id))

# Total number of clusters
nk <- length(kids)

# Convert the column for sample_id from type "character" to type "factor" 
sce$sample_id <- as.factor(sce$sample_id)             


sce$batch <- as.factor(sce$batch) 
sce$sex <- as.factor(sce$sex)     
sce$brain_region <- as.factor(sce$brain_region)                                 
sce$Biological_replicate <- as.factor(sce$Biological_replicate)                            
sce$Age_group <- as.factor(sce$Age_group)
sce$single_cell_chemistry <- as.factor(sce$single_cell_chemistry)

sids <- purrr::set_names(levels(sce$sample_id))

# Total number of samples 
ns <- length(sids)

# Generate sample level metadata

## Turn named vector into a numeric vector of number of cells per sample
n_cells <- as.numeric(table(sce$sample_id))

write.csv(n_cells, "DESeq2/Wald/results/n_cells_per_sample_id.csv")

## Determine how to reorder the samples (rows) of the metadata to match the order of sample names in sids vector
m <- match(sids, sce$sample_id)


## Create the sample level metadata by combining the reordered metadata with the number of cells corresponding to each sample.

ei <- data.frame(colData(sce)[m, ], 
                 n_cells, row.names = NULL) %>% 
  select(-"cluster_id")
ei

#Count aggregation to sample level
# Aggregate the counts per sample_id and cluster_id

# Subset metadata to only include the cluster and sample IDs to aggregate across
groups <- colData(sce)[, c("cluster_id", "sample_id")]

# Aggregate across cluster-sample groups
pb <- aggregate.Matrix(t(counts(sce)), 
                       groupings = groups, fun = "sum") 

# Not every cluster is present in all samples; create a vector that represents how to split samples
splitf <- sapply(stringr::str_split(rownames(pb), 
                                    pattern = "_",  
                                    n = 2), 
                 `[`, 1)

# Turn into a list and split the list into components for each cluster and transform, so rows are genes and columns are samples and make rownames as the sample IDs
pb <- split.data.frame(pb, 
                       factor(splitf)) %>%
  lapply(function(u) 
    set_colnames(t(u), 
              	 stringr::str_extract(rownames(u), "(?<=_)[:graph:]+")))


# Print out the table of cells in each cluster-sample group (but use the biological replicates as the sample group)
options(width = 100)
table_samples_vs_cell_types <- table(sce$cluster_id, sce$sample_id)

write.csv(table_samples_vs_cell_types, "DESeq2/Wald/results/table_sample_ids_vs_cell_types.csv") 

ei


#create a vector of sample names combined for each of the cell type clusters.

#Get sample names for each of the cell type clusters

#prep. data.frame for plotting
get_sample_ids <- function(x){
  pb[[x]] %>%
   colnames()
}

de_samples <- map(1:length(kids), get_sample_ids) %>%
  unlist()

#get the cluster IDs corresponding to each of the samples in the vector.

#get cluster IDs for each of the samples

samples_list <- map(1:length(kids), get_sample_ids)

get_cluster_ids <- function(x){
  rep(names(pb)[x], 
      each = length(samples_list[[x]]))
}



de_cluster_ids <- map(1:length(kids), get_cluster_ids) %>%
  unlist()


#create a data frame with the cluster IDs and the corresponding sample IDs
#merge together the condition information.

# Create a data frame with the sample IDs, cluster IDs, condition (i.e Age_group)
#join by sample_id 

gg_df <- data.frame(cluster_id = de_cluster_ids,
                    sample_id = de_samples)

gg_df <- left_join(gg_df, ei[, c("sample_id", "Age_group")]) 

gg_df <- left_join(gg_df, ei[, c("sample_id", "batch")]) 

gg_df <- left_join(gg_df, ei[, c("sample_id", "sex")]) 

gg_df <- left_join(gg_df, ei[, c("sample_id", "brain_region")]) 

gg_df <- left_join(gg_df, ei[, c("sample_id", "Biological_replicate")]) 

gg_df <- left_join(gg_df, ei[, c("sample_id", "single_cell_chemistry")]) 


metadata <- gg_df %>%
  dplyr::select(cluster_id, sample_id, Age_group, batch, sex, brain_region, Biological_replicate, single_cell_chemistry) 

metadata

# Generate vector of cluster IDs
# need to first transform the data from type character to type factor
metadata$cluster_id <- as.factor(metadata$cluster_id)
metadata$sample_id <- as.factor(metadata$sample_id)
metadata$Age_group <- as.factor(metadata$Age_group)
metadata$batch <- as.factor(metadata$batch)
metadata$sex <- as.factor(metadata$sex)
metadata$Biological_replicate <- as.factor(metadata$Biological_replicate)
metadata$single_cell_chemistry <- as.factor(metadata$single_cell_chemistry)


clusters <- levels(metadata$cluster_id)

#Remove Inh L2-4 VIP SPAG17 (too few nuclei)
clusters <- clusters[!clusters %in% c("Inh L2-4 VIP SPAG17")]

# Function to run DESeq2 and get results for all clusters
## x is index of cluster in clusters vector on which to run function
## A is the sample group to compare
## B is the sample group to compare against (base level)

get_dds_resultsAvsB <- function(x, A, B){
       
         cluster_metadata <- metadata[which(metadata$cluster_id == clusters[x]), ]
        rownames(cluster_metadata) <- cluster_metadata$sample_id
        counts <- pb[[clusters[x]]]
    

#Remove genes expressed in less than 10% of nuclei in the cluster
zero.counts = rowSums(counts == 0)

#Then only want to keep those genes where the number of cells with zero counts is less than 90% of the total number of cells

genes2keep = which(zero.counts < 0.9*ncol(counts))
        
counts = counts[genes2keep, ]

cluster_counts <- data.frame(counts[, which(colnames(counts) %in% rownames(cluster_metadata))])

	print(paste0("Performing DE analysis for", clusters[x]))

	Test_dds <- DESeqDataSetFromMatrix(cluster_counts, 
                                     colData = cluster_metadata, 
                                     design = ~ single_cell_chemistry + Age_group)

	

	Test_dds <- collapseReplicates(Test_dds, groupby = Test_dds$Biological_replicate, run = Test_dds$sample_id, renameCols = TRUE)



        
# Transform counts for data visualization
  rld <- rlog(Test_dds, blind=TRUE)
	rld_mat <- assay(rld)
 	pca <- prcomp(t(rld_mat))
	loadings <- as.data.frame(pca$rotation)
	write.csv(loadings, paste0("Wald/results/", clusters[x], "_PCA_prcomp_not_adjusted.csv")) 


        # Plot PCA
        
        DESeq2::plotPCA(rld, intgroup = "Age_group")
        ggsave(paste0("Wald/results/", clusters[x], "_specific_groupID_PCAplot.png"))
        
        DESeq2::plotPCA(rld, intgroup = "batch")
        ggsave(paste0("Wald/results/", clusters[x], "_specific_batch_PCAplot.png"))
        
        DESeq2::plotPCA(rld, intgroup = "sex")
        ggsave(paste0("Wald/results/", clusters[x], "_specific_sex_PCAplot.png"))

        DESeq2::plotPCA(rld, intgroup = "brain_region")
        ggsave(paste0("Wald/results/", clusters[x], "_specific_brain_region_PCAplot.png"))

        DESeq2::plotPCA(rld, intgroup = "single_cell_chemistry")
        ggsave(paste0("Wald/results/", clusters[x], "_specific_single_cell_chemistry_PCAplot.png"))

        DESeq2::plotPCA(rld, intgroup = "Biological_replicate")
        ggsave(paste0("Wald/results/", clusters[x], "_specific_Biological_replicate_PCAplot.png"))

        
        # Extract the rlog matrix from the object and compute pairwise correlation values
        rld_mat <- assay(rld)
        rld_cor <- cor(rld_mat)
        
	pdf(paste0("DESeq2/Wald/results/", clusters[x], "_specific_heatmap.pdf"))
        pheatmap(rld_cor, annotation = NA)
        dev.off()


        # Run DESeq2 differential expression analysis
        Test_dds <- DESeq(Test_dds)
        
        # Plot dispersion estimates
        
	pdf(paste0("Wald/results/", clusters[x], "_dispersion_plot.pdf"))
        plotDispEsts(Test_dds)
        dev.off()

        # Output results of Wald test for contrast for A vs B
        contrast <- c("Age_group", levels(cluster_metadata$Age_group)[A], levels(cluster_metadata$Age_group)[B])
        
        # resultsNames(Test_dds)
        res <- results(Test_dds, 
                       contrast = contrast,
                       alpha = 0.05)
        
        res <- lfcShrink(Test_dds, 
                         contrast =  contrast,
                         res=res, type = "ashr")
        # Set thresholds
        padj_cutoff <- 0.05

        #Subsetting DE genes that are more than double or less than half the expression
        fold_change_cutoff <- 1.00
        
        # Turn the results object into a tibble for use with tidyverse functions
        res_tbl <- res %>%
                data.frame() %>%
                rownames_to_column(var="gene") %>%
                as_tibble()

	annotations <- read.csv("DESeq2/Wald/data/annotation.csv")
	
	gene_descriptions <- unique(annotations[, c("gene_name", "description")])


	# Merge gene descriptions with markers
	res_tbl <- left_join(x = res_tbl,
                                       y = gene_descriptions,
                                       by = c("gene" = "gene_name"))

	res_tbl$description <- gsub(",", "--", res_tbl$description)

        write.csv(res_tbl,
                  paste0("Wald/pairwise/", clusters[x], "_", levels(cluster_metadata$Age_group)[A], "_vs_", levels(cluster_metadata$Age_group)[B], "_all_genes_sc_chemistry_adjusted.csv"),
                  quote = FALSE, 
                  row.names = FALSE)
        
        # Subset the significant results
        sig_res <- dplyr::filter(res_tbl, padj < padj_cutoff) %>%
                dplyr::arrange(padj)

        #Why DESeq2 gives NA for padj https://www.biostars.org/p/458488/


	#Compute the proportion of nuclei expressing each gene in sig_res

        Cluster_subset <- subset(seu, idents = clusters[x])
        DefaultAssay(Cluster_subset) <- 'RNA'
	
	sig_res_data_frame <- as.data.frame(sig_res)

	Proportion_of_juvenile_nuclei <- vector('list', length(as.data.frame(sig_res_data_frame$gene)))
	
	Proportion_of_adult_nuclei <- vector('list', length(as.data.frame(sig_res_data_frame$gene)))
	

PrctCellExpringGene <- function(object, genes, group.by = "all"){
    if(group.by == "all"){
        prct = unlist(lapply(genes,calc_helper, object=object))
        result = data.frame(Markers = genes, Cell_proportion = prct)
        return(result)
    }

    else{        
        list = SplitObject(object, group.by)
        factors = names(list)

        results = lapply(list, PrctCellExpringGene, genes=genes)
        for(i in 1:length(factors)){
        results[[i]]$Feature = factors[i]
        }
        combined = do.call("rbind", results)
        return(combined)
    }
}

calc_helper <- function(object,genes){
    counts = object[['RNA']]@counts
    ncells = ncol(counts)
    if(genes %in% row.names(counts)){
    sum(counts[genes,]>0)/ncells
    }else{return(NA)}
}

if(nrow(sig_res_data_frame) > 0) {

features <- sig_res_data_frame$gene
subset_seu <- subset(seu, idents = clusters[x])


paed <- subset(subset_seu, subset = Age_group == 'Paediatric')
Proportion_nuclei_expressing_genes <- PrctCellExpringGene(paed, genes = features)
Proportion_of_juvenile_nuclei <- Proportion_nuclei_expressing_genes$Cell_proportion

adult <- subset(subset_seu, subset = Age_group == 'Adult')
Proportion_nuclei_expressing_genes <- PrctCellExpringGene(adult, genes = features)
Proportion_of_adult_nuclei <- Proportion_nuclei_expressing_genes$Cell_proportion

	sig_res_data_frame$Percentage_Paediatric_nuclei_expressing_gene <- Proportion_of_juvenile_nuclei

	sig_res_data_frame$Percentage_Adult_nuclei_expressing_gene <- Proportion_of_adult_nuclei

	sig_res_data_frame$Percentage_Paediatric_nuclei_expressing_gene <- as.numeric(sig_res_data_frame$Percentage_Paediatric_nuclei_expressing_gene)
	sig_res_data_frame$Percentage_Adult_nuclei_expressing_gene <- as.numeric(sig_res_data_frame$Percentage_Adult_nuclei_expressing_gene)

}



	#Compute the average expression across juvenile and adult nuclei respectively for the sig_res genes
	Cluster_subset_juvenile_average <- vector('list', length(as.data.frame(sig_res_data_frame$gene)))
	Cluster_subset_adult_average <- vector('list', length(as.data.frame(sig_res_data_frame$gene)))


	if(nrow(sig_res_data_frame) > 0) {
	Cluster_subset_juvenile_average = AverageExpression(paed, features = features, assays = 'RNA', slot = 'data', group.by = 'Age_group', return.seurat = FALSE)
	Cluster_subset_adult_average = AverageExpression(adult, features = features, assays = 'RNA', slot = 'data', group.by = 'Age_group', return.seurat = FALSE)


	sig_res_data_frame$Avg_normalised_expression_across_paediatric_nuclei <- Cluster_subset_juvenile_average$RNA[, 1]
	sig_res_data_frame$Avg_normalised_expression_across_adult_nuclei <- Cluster_subset_adult_average$RNA[, 1]

	sig_res_data_frame$Avg_normalised_expression_across_paediatric_nuclei <- as.numeric(sig_res_data_frame$Avg_normalised_expression_across_paediatric_nuclei)
	sig_res_data_frame$Avg_normalised_expression_across_adult_nuclei <- as.numeric(sig_res_data_frame$Avg_normalised_expression_across_adult_nuclei)
}

	write.csv(sig_res_data_frame,
                  paste0("Wald/pairwise/", clusters[x], "_", levels(cluster_metadata$Age_group)[A], "_vs_", levels(cluster_metadata$Age_group)[B], "_sig_genes.csv"),
                  quote = FALSE, 
                  row.names = FALSE)
        
	

	#NOTE: cannot perform DE analysis between batches or sexes because they were not specified in the design formula!
	#May be  way round this bu would have to check 
        ## ggplot of top genes
        normalized_counts <- counts(Test_dds, 
                                    normalized = TRUE)
        
        ## Order results by padj values
        top20_sig_genes <- sig_res %>%
                dplyr::arrange(padj) %>%
                dplyr::pull(gene) %>%
                head(n=20)
        
        
        top20_sig_norm <- data.frame(normalized_counts) %>%
                rownames_to_column(var = "gene") %>%
                dplyr::filter(gene %in% top20_sig_genes)
        
        gathered_top20_sig <- top20_sig_norm %>%
                gather(colnames(top20_sig_norm)[2:length(colnames(top20_sig_norm))], key = "samplename", value = "normalized_counts")
        
	#NB had to change sample_id to Biological_replicate
        gathered_top20_sig <- inner_join(ei[, c("Biological_replicate", "Age_group" )], gathered_top20_sig, by = c("Biological_replicate" = "samplename"))
        
        ## plot using ggplot2
        ggplot(gathered_top20_sig) +
                geom_point(aes(x = gene, 
                               y = normalized_counts, 
                               color = Age_group), 
                           position=position_jitter(w=0.1,h=0)) +
                scale_y_log10() +
                xlab("Genes") +
                ylab("log10 Normalized Counts") +
                ggtitle("Top 20 Significant DE Genes") +
                theme_bw() +
                theme(axis.text.x = element_text(angle = 45, hjust = 1)) + 
                theme(plot.title = element_text(hjust = 0.5))
        ggsave(paste0("Wald/pairwise/", clusters[x], "_", levels(cluster_metadata$Age_group)[A], "_vs_", levels(cluster_metadata$Age_group)[B], "_top20_DE_genes.png"))
    

#Subsetting DE genes that are more than double or less than half the expression
        fold_change_res <- dplyr::filter(res_tbl, abs(log2FoldChange) > fold_change_cutoff) %>%
                dplyr::arrange(log2FoldChange)

## Order results by log2FoldChange negative
fold_change_res_negative <- dplyr::filter(fold_change_res, log2FoldChange < 0)
 top20_genes_FoldChange <- fold_change_res_negative %>%
                dplyr::arrange(log2FoldChange) %>%
                dplyr::pull(gene) %>%
                head(n=20)

        
        top20_FoldChange_norm <- data.frame(normalized_counts) %>%
                rownames_to_column(var = "gene") %>%
                dplyr::filter(gene %in% top20_genes_FoldChange)
        
        gathered_top20_FoldChange <- top20_FoldChange_norm %>%
                gather(colnames(top20_FoldChange_norm)[2:length(colnames(top20_FoldChange_norm))], key = "samplename", value = "normalized_counts")
        
        gathered_top20_FoldChange <- inner_join(ei[, c("Biological_replicate", "Age_group" )], gathered_top20_FoldChange, by = c("Biological_replicate" = "samplename"))
        
        ## plot using ggplot2
        ggplot(gathered_top20_FoldChange) +
                geom_point(aes(x = gene, 
                               y = normalized_counts, 
                               color = Age_group), 
                           position=position_jitter(w=0.1,h=0)) +
                scale_y_log10() +
                xlab("Genes") +
                ylab("log10 Normalized Counts") +
                ggtitle("Top 20 DE Genes by log2FoldChange") +
                theme_bw() +
                theme(axis.text.x = element_text(angle = 45, hjust = 1)) + 
                theme(plot.title = element_text(hjust = 0.5))
        ggsave(paste0("Wald/pairwise/", clusters[x], "_", levels(cluster_metadata$Age_group)[A], "_vs_", levels(cluster_metadata$Age_group)[B], "log2FC_negative_top20_DE_genes_sc_chemistry_adjusted.png"))
        


    ## Order results by log2FoldChange positive 
fold_change_res_positive <- dplyr::filter(fold_change_res, log2FoldChange > 0)

         top20_genes_FoldChange <- fold_change_res_positive %>%
                dplyr::arrange(desc(log2FoldChange)) %>%
                dplyr::pull(gene) %>%
                head(n=20)

        top20_FoldChange_norm <- data.frame(normalized_counts) %>%
                rownames_to_column(var = "gene") %>%
                dplyr::filter(gene %in% top20_genes_FoldChange)
        
        gathered_top20_FoldChange <- top20_FoldChange_norm %>%
                gather(colnames(top20_FoldChange_norm)[2:length(colnames(top20_FoldChange_norm))], key = "samplename", value = "normalized_counts")
        
        gathered_top20_FoldChange <- inner_join(ei[, c("Biological_replicate", "Age_group" )], gathered_top20_FoldChange, by = c("Biological_replicate" = "samplename"))
        
        ## plot using ggplot2
        ggplot(gathered_top20_FoldChange) +
                geom_point(aes(x = gene, 
                               y = normalized_counts, 
                               color = Age_group), 
                           position=position_jitter(w=0.1,h=0)) +
                scale_y_log10() +
                xlab("Genes") +
                ylab("log10 Normalized Counts") +
                ggtitle("Top 20 DE Genes by log2FoldChange") +
                theme_bw() +
                theme(axis.text.x = element_text(angle = 45, hjust = 1)) + 
                theme(plot.title = element_text(hjust = 0.5))
        ggsave(paste0("Wald/pairwise/", clusters[x], "_", levels(cluster_metadata$Age_group)[A], "_vs_", levels(cluster_metadata$Age_group)[B], "log2FC_positive_top20_DE_genes_sc_chemistry_adjusted.png"))
   

## Obtain logical vector where TRUE values denote padj values < 0.05 and fold change > 1.5 in either direction
   	res_table_thres <- res_tbl %>% 
                  mutate(threshold = padj < 0.05 & abs(log2FoldChange) >= 0.5)
                  
 	## Volcano plot
        ggplot(res_table_thres) +
    	geom_point(aes(x = log2FoldChange, y = -log10(padj), colour = threshold)) +
   	ggtitle(paste0("Volcano plot Adults vs Juveniles ",clusters[x], " log2FC vs padj")) +
    	xlab("log2 fold change") + 
    	ylab("-log10 adjusted p-value") +
    	scale_y_continuous(limits = c(0,50)) +
    	theme(legend.position = "none",
          plot.title = element_text(size = rel(0.5), hjust = 0.5),
          axis.title = element_text(size = rel(1.25)))  +
	geom_text_repel(aes(x = log2FoldChange, y = -log10(padj)), label= ifelse(res_table_thres$threshold == TRUE, as.character(res_table_thres$gene),""))+
       scale_colour_manual(values = c("#3A66A7", "#CC1400"))
        
        ggsave(paste0("Wald/pairwise/", clusters[x], "_", levels(cluster_metadata$Age_group)[A], "_vs_", levels(cluster_metadata$Age_group)[B], "_Volcano_plot_logFC_vs_padj.png"))
          


             
}

# Run the script on all clusters comparing stim condition relative to control condition
map(1:length(clusters), get_dds_resultsAvsB, A = 2, B = 1)


