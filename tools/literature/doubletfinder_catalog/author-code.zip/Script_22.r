#Using matlab

fname='/scratch/mshruv003/visium_08_10_21/Hockman_Visium/X201SC21082979-Z01-F001_01/raw_data/Visto/15_yr_old_DH1.tif';
N=5;
VNS(fname,N)


fname='/scratch/mshruv003/visium_08_10_21/Hockman_Visium/X201SC21082979-Z01-F001_01/raw_data/Visto/15_yr_old_DH1.tif';
M=5;
refineVNS(fname,M)

mask='/scratch/mshruv003/visium_08_10_21/Hockman_Visium/X201SC21082979-Z01-F001_01/raw_data/Visto/15_yr_old_DH1_nuclei.mat';
jsonname='/scratch/mshruv003/visium_08_10_21/Hockman_Visium/X201SC21082979-Z01-F001_01/raw_data/run_spaceranger_count_DH1a/outs/spatial/scalefactors_json.json';
posname='/scratch/mshruv003/visium_08_10_21/Hockman_Visium/X201SC21082979-Z01-F001_01/raw_data/run_spaceranger_count_DH1a/outs/spatial/tissue_positions_list.csv';
countNuclei(mask,jsonname,posname)

fname='/scratch/mshruv003/visium_08_10_21/Hockman_Visium/X201SC21082979-Z01-F001_01/raw_data/Visto/15_yr_old_DH2.tif';
N=5;
VNS(fname,N)


fname='/scratch/mshruv003/visium_08_10_21/Hockman_Visium/X201SC21082979-Z01-F001_01/raw_data/Visto/15_yr_old_DH2.tif';
M=1;
refineVNS(fname,M)

mask='/scratch/mshruv003/visium_08_10_21/Hockman_Visium/X201SC21082979-Z01-F001_01/raw_data/Visto/15_yr_old_DH2_nuclei.mat';
jsonname='/scratch/mshruv003/visium_08_10_21/Hockman_Visium/X201SC21082979-Z01-F001_01/raw_data/run_spaceranger_count_DH2a/outs/spatial/scalefactors_json.json';
posname='/scratch/mshruv003/visium_08_10_21/Hockman_Visium/X201SC21082979-Z01-F001_01/raw_data/run_spaceranger_count_DH2a/outs/spatial/tissue_positions_list.csv';
countNuclei(mask,jsonname,posname)

fname='/scratch/mshruv003/visium_08_10_21/Hockman_Visium/X201SC21082979-Z01-F001_02/raw_data/Visto/31_yr_old_DH3.tif';
N=5;
VNS(fname,N)


fname='/scratch/mshruv003/visium_08_10_21/Hockman_Visium/X201SC21082979-Z01-F001_02/raw_data/Visto/31_yr_old_DH3.tif';
M=5;
refineVNS(fname,M)

mask='/scratch/mshruv003/visium_08_10_21/Hockman_Visium/X201SC21082979-Z01-F001_02/raw_data/Visto/31_yr_old_DH3_nuclei.mat';
jsonname='/scratch/mshruv003/visium_08_10_21/Hockman_Visium/X201SC21082979-Z01-F001_02/raw_data/run_spaceranger_count_DH3a/outs/spatial/scalefactors_json.json';
posname='/scratch/mshruv003/visium_08_10_21/Hockman_Visium/X201SC21082979-Z01-F001_02/raw_data/run_spaceranger_count_DH3a/outs/spatial/tissue_positions_list.csv';
countNuclei(mask,jsonname,posname)

fname='/scratch/mshruv003/visium_08_10_21/Hockman_Visium/X201SC21082979-Z01-F001_02/raw_data/Visto/31_yr_old_DH4.tif';
N=5;
VNS(fname,N)


fname='/scratch/mshruv003/visium_08_10_21/Hockman_Visium/X201SC21082979-Z01-F001_02/raw_data/Visto/31_yr_old_DH4.tif';
M=4;
refineVNS(fname,M)

mask='/scratch/mshruv003/visium_08_10_21/Hockman_Visium/X201SC21082979-Z01-F001_02/raw_data/Visto/31_yr_old_DH4_nuclei.mat';
jsonname='/scratch/mshruv003/visium_08_10_21/Hockman_Visium/X201SC21082979-Z01-F001_02/raw_data/run_spaceranger_count_DH4a/outs/spatial/scalefactors_json.json';
posname='/scratch/mshruv003/visium_08_10_21/Hockman_Visium/X201SC21082979-Z01-F001_02/raw_data/run_spaceranger_count_DH4a/outs/spatial/tissue_positions_list.csv';
countNuclei(mask,jsonname,posname)
