library(scCustomize)
library(tidyr)
library(scater)
library(Seurat)
library(tidyverse)
library(cowplot)
library(Matrix.utils)
library(edgeR)
library(dplyr)
library(magrittr)
library(Matrix)
library(purrr)
library(reshape2)
library(S4Vectors)
library(tibble)
library(SingleCellExperiment)
library(pheatmap)
library(apeglm)
library(png)
library(DESeq2)
library(RColorBrewer)
library(ashr)
library(matrixStats)
library(gplots)
library(ggplot2)
library(viridis)
library(dittoSeq)
library(plyr)
library(stringi)
library(grid)
library(ComplexHeatmap)
library(forcats)

seu <- readRDS("/scratch/stychr009/2021/Publication/Filtered_log_normalised_analysis/Consensus_broad_high_res_annotated_seu.rds")

DefaultAssay(seu) <- 'RNA'

# First Extract counts
counts <- GetAssayData(object = seu, slot = "data")

# Then output a logical vector for every gene on whether the more than zero counts per cell
nonzero <- counts > 0

# Sums all TRUE values and returns TRUE if more than 10 TRUE values per gene
keep_genes <- Matrix::rowSums(nonzero) > 15

# Only keeping those genes expressed in more than 10 cells
filtered_counts <- counts[keep_genes, ]

# Reassign to Seurat object
seu <- CreateSeuratObject(filtered_counts, names.field = 1:5, names.delim = "_", meta.data = seu@meta.data)


my_levels <- c("Inh L1-2 PAX6 CDH12", "Inh L1-2 PAX6 TNFAIP8L3", 
"Inh L1 SST NMBR", "Inh L1-4 LAMP5 LCP2",
 "Inh L1-2 LAMP5 DBP", "Inh L2-6 LAMP5 CA1",
"Inh L1 SST CHRNA4", "Inh L1-2 GAD1 MC4R", 
"Inh L1-2 SST BAGE2", "Inh L1-3 PAX6 SYT6", 
"Inh L1-2 VIP TSPAN12", "Inh L1-4 VIP CHRNA6", 
"Inh L1-3 VIP ADAMTSL1", "Inh L1-4 VIP PENK", 
"Inh L2-6 VIP QPCT", "Inh L3-6 VIP HS3ST3A1", 
"Inh L1-2 VIP PCDH20","Inh L2-5 VIP SERPINF1", 
"Inh L2-5 VIP TYR", "Inh L1-3 VIP CHRM2", 
"Inh L2-4 VIP CBLN1", "Inh L1-3 VIP CCDC184", 
"Inh L1-3 VIP GGH", "Inh L1-2 VIP LBH", 
"Inh L2-3 VIP CASC6", "Inh L2-4 VIP SPAG17",
"Inh L1-4 VIP OPRM1", "Inh L3-6 SST NPY",
"Inh L3-6 SST HPGD", "Inh L4-6 SST B3GAT2",
"Inh L5-6 SST KLHDC8A", "Inh L5-6 SST NPM1P10",
"Inh L4-6 SST GXYLT2", "Inh L4-5 SST STK32A",
"Inh L1-3 SST CALB1", "Inh L3-5 SST ADGRG6", 
"Inh L2-4 SST FRZB", "Inh L5-6 SST TH", 
"Inh L5-6 GAD1 GLP1R", "Inh L5-6 PVALB LGR5",
 "Inh L4-5 PVALB MEPE", "Inh L2-4 PVALB WFDC2", 
"Inh L4-6 PVALB SULF1", "Inh L5-6 SST MIR548F2", 
"Inh L2-5 PVALB SCUBE3", "Exc L2 LAMP5 LTK", 
"Exc L2-4 LINC00507 GLP2R", "Exc L2-3 LINC00507 FREM3", 
"Exc L5-6 THEMIS C1QL3", "Exc L3-4 RORB CARM1P1", 
"Exc L3-5 RORB ESR1", "Exc L3-5 RORB COL22A1", 
"Exc L3-5 RORB FILIP1L",
"Exc L3-5 RORB TWIST2", "Exc L4-5 RORB FOLH1B",
"Exc L4-6 RORB SEMA3E", "Exc L4-5 RORB DAPK2",
"Exc L5-6 RORB TTC12", "Exc L4-6 RORB C1R",
"Exc L4-5 FEZF2 SCN4B", "Exc L5-6 THEMIS DCSTAMP",
"Exc L5-6 THEMIS CRABP1", "Exc L5-6 THEMIS FGF10",
"Exc L4-6 FEZF2 IL26", "Exc L5-6 FEZF2 ABO",
"Exc L6 FEZF2 SCUBE1", "Exc L5-6 SLC17A7 IL15",
"Exc L6 FEZF2 OR2T8", "Exc L5-6 FEZF2 EFTUD1P1",
"OPC L1-6 PDGFRA", "Astro L1-6 FGFR3 SLC14A1",
"Astro L1-2 FGFR3 GFAP", "Oligo L1-6 OPALIN", 
"Endo L2-6 NOSTRIN", "Micro L1-3 TYROBP")


#Plot genes from Rohlwink-2019_supp_table5 | https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6704154/
TBM_markers <- read.csv("directory/Rohlwink-2019_supp_table5.csv")
Upreg <- TBM_markers[TBM_markers$log2FoldChange > 0, "Gene"]
Upreg <- Upreg[Upreg %in% rownames(seu)]

#Paediatric

subset_seu <- subset(seu, subset = Age_group == 'Juvenile') 

sample.averages <- AggregateExpression(subset_seu, assays = 'RNA', return.seurat=TRUE, group.by = "MTG_annotation_log_normalised")
scale_seurat <- ScaleData(sample.averages, assay = 'RNA', features = rownames(sample.averages))
DefaultAssay(scale_seurat) <- 'RNA'
scale_seurat$MTG_annotation_log_normalised <- rownames(scale_seurat@meta.data)
scale_seurat$MTG_annotation_log_normalised <- factor(scale_seurat$MTG_annotation_log_normalised, levels = my_levels)

pdf("directory/Filtered_Paediatric_TBM_markers_2019_supp_table5_upreg_plot_paeds.pdf", width= 10, height=10)
d <- dittoHeatmap(scale_seurat,
 genes = Upreg,
  heatmap.colors = colorRampPalette(c("blue", "white", "red"))(50), assay= 'RNA', slot = 'data', scale = "row", cluster_cols = FALSE, 
order.by = 'MTG_annotation_log_normalised', cluster_rows = TRUE, show_rownames = TRUE, show_colnames = TRUE, fontsize = 3, cellwidth = 7, cellheight = 5)
dev.off()


paed_upreg <- dittoHeatmap(scale_seurat,
 genes = Upreg,
  heatmap.colors = colorRampPalette(c("blue", "white", "red"))(50), assay= 'RNA', slot = 'data', scale = "row", cluster_cols = FALSE, 
order.by = 'MTG_annotation_log_normalised', cluster_rows = TRUE, show_rownames = TRUE, show_colnames = TRUE, fontsize = 3, cellwidth = 7, cellheight = 5)

Upreg <- Upreg[paed_upreg$tree_row$order]

Upreg <- rev(Upreg)

pdf("directory/Dotplot_Paediatric_TBM_markers_2019_supp_table5_upreg_plot_paeds.pdf", width= 15, height=15)
DotPlot(subset_seu, features = Upreg, assay = 'RNA', cols = "RdBu", 
group.by = 'MTG_annotation_log_normalised', scale = TRUE)+
coord_flip()+
theme(axis.text.x = element_text(angle = 90, hjust = 1, size=5))
dev.off()



#Adult

subset_seu <- subset(seu, subset = Age_group == 'Adult') 

sample.averages <- AggregateExpression(subset_seu, assays = 'RNA', return.seurat=TRUE, group.by = "MTG_annotation_log_normalised")
scale_seurat <- ScaleData(sample.averages, assay = 'RNA', features = rownames(sample.averages))
scale_seurat$MTG_annotation_log_normalised <- rownames(scale_seurat@meta.data)
scale_seurat$MTG_annotation_log_normalised <- factor(scale_seurat$MTG_annotation_log_normalised, levels = my_levels)


#Use the order of the paed data which has been clustered
TBM_markers <- read.csv("directory/Rohlwink-2019_supp_table5.csv")
Upreg <- TBM_markers[TBM_markers$log2FoldChange > 0, "Gene"]
Upreg <- Upreg[Upreg %in% rownames(seu)]


#First order Upreg alphabetically and then try order by the tree_rows

Upreg <- Upreg[paed_upreg$tree_row$order]

pdf("directory/Filtered_Paediatric_TBM_markers_2019_supp_table5_upreg_plot_adult.pdf", width= 10, height=10)
d <- dittoHeatmap(scale_seurat,
 genes = Upreg,
  heatmap.colors = colorRampPalette(c("blue", "white", "red"))(50), assay= 'RNA', slot = 'data', scale = "row", cluster_cols = FALSE, 
order.by = 'MTG_annotation_log_normalised', cluster_rows = FALSE, show_rownames = TRUE, show_colnames = TRUE, fontsize = 3, cellwidth = 7, cellheight = 5)
dev.off()


Upreg <- rev(Upreg)

pdf("directory/Dotplot_Paediatric_TBM_markers_2019_supp_table5_upreg_plot_adult.pdf", width= 15, height=15)
DotPlot(subset_seu, features = Upreg, assay = 'RNA', cols = "RdBu", 
group.by = 'MTG_annotation_log_normalised', scale = TRUE)+
coord_flip()+
theme(axis.text.x = element_text(angle = 90, hjust = 1, size=5))
dev.off()



