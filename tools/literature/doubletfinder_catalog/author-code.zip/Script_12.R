library(Seurat)
library(openxlsx)
library(SingleCellExperiment)
library(tidyverse)
library(Matrix)
library(scales)
library(cowplot)
library(RCurl)
library(pryr)
library(RColorBrewer)
library(dplyr)
library(textclean)

seu <- readRDS("directory/Annotated_seu_obj.rds")

MTG <- as.character(seu$MTG_annotation_log_normalised)
MTG <- substr(MTG, 1, 3)
Broad <- as.character(seu$broad_cell_type)
Broad <- substr(Broad, 1, 3)

Match <- ifelse(MTG == Broad, TRUE, FALSE)

seu$Match <- Match

subset_seu <- subset(seu, subset= Match == 'TRUE')

subset_seu$integrated_snn_res.0.2 <- NULL
subset_seu$integrated_snn_res.0.8 <- NULL
subset_seu$MTG_annotation <- NULL
subset_seu$cluster_colour <- NULL
subset_seu$MTG_annotation_filtered <- NULL
subset_seu$MTG_annotation_filtered_cluster_colour <- NULL
subset_seu$Match <- NULL

saveRDS(subset_seu, "directory/Consensus_broad_high_res_annotated_seu.rds")


df <- table(subset_seu$MTG_annotation_log_normalised, subset_seu$Biological_replicate)

write.csv(df, "directory/n_nuclei_per_cell_type_sample_consensus_broad_high_res.csv")

#plot UMAP

my_levels <- c("Inh L1-2 PAX6 CDH12", "Inh L1-2 PAX6 TNFAIP8L3", 
"Inh L1 SST NMBR", "Inh L1-4 LAMP5 LCP2",
 "Inh L1-2 LAMP5 DBP", "Inh L2-6 LAMP5 CA1",
"Inh L1 SST CHRNA4", "Inh L1-2 GAD1 MC4R", 
"Inh L1-2 SST BAGE2", "Inh L1-3 PAX6 SYT6", 
"Inh L1-2 VIP TSPAN12", "Inh L1-4 VIP CHRNA6", 
"Inh L1-3 VIP ADAMTSL1", "Inh L1-4 VIP PENK", 
"Inh L2-6 VIP QPCT", "Inh L3-6 VIP HS3ST3A1", 
"Inh L1-2 VIP PCDH20","Inh L2-5 VIP SERPINF1", 
"Inh L2-5 VIP TYR", "Inh L1-3 VIP CHRM2", 
"Inh L2-4 VIP CBLN1", "Inh L1-3 VIP CCDC184", 
"Inh L1-3 VIP GGH", "Inh L1-2 VIP LBH", 
"Inh L2-3 VIP CASC6", "Inh L2-4 VIP SPAG17",
"Inh L1-4 VIP OPRM1", "Inh L3-6 SST NPY",
"Inh L3-6 SST HPGD", "Inh L4-6 SST B3GAT2",
"Inh L5-6 SST KLHDC8A", "Inh L5-6 SST NPM1P10",
"Inh L4-6 SST GXYLT2", "Inh L4-5 SST STK32A",
"Inh L1-3 SST CALB1", "Inh L3-5 SST ADGRG6", 
"Inh L2-4 SST FRZB", "Inh L5-6 SST TH", 
"Inh L5-6 GAD1 GLP1R", "Inh L5-6 PVALB LGR5",
 "Inh L4-5 PVALB MEPE", "Inh L2-4 PVALB WFDC2", 
"Inh L4-6 PVALB SULF1", "Inh L5-6 SST MIR548F2", 
"Inh L2-5 PVALB SCUBE3", "Exc L2 LAMP5 LTK", 
"Exc L2-4 LINC00507 GLP2R", "Exc L2-3 LINC00507 FREM3", 
"Exc L5-6 THEMIS C1QL3", "Exc L3-4 RORB CARM1P1", 
"Exc L3-5 RORB ESR1", "Exc L3-5 RORB COL22A1", 
"Exc L3-5 RORB FILIP1L",
"Exc L3-5 RORB TWIST2", "Exc L4-5 RORB FOLH1B",
"Exc L4-6 RORB SEMA3E", "Exc L4-5 RORB DAPK2",
"Exc L5-6 RORB TTC12", "Exc L4-6 RORB C1R",
"Exc L4-5 FEZF2 SCN4B", "Exc L5-6 THEMIS DCSTAMP",
"Exc L5-6 THEMIS CRABP1", "Exc L5-6 THEMIS FGF10",
"Exc L4-6 FEZF2 IL26", "Exc L5-6 FEZF2 ABO",
"Exc L6 FEZF2 SCUBE1", "Exc L5-6 SLC17A7 IL15",
"Exc L6 FEZF2 OR2T8", "Exc L5-6 FEZF2 EFTUD1P1",
"OPC L1-6 PDGFRA", "Astro L1-6 FGFR3 SLC14A1",
"Astro L1-2 FGFR3 GFAP", "Oligo L1-6 OPALIN", 
"Endo L2-6 NOSTRIN", "Micro L1-3 TYROBP")


extract <- subset_seu@meta.data %>% select(MTG_annotation_log_normalised, MTG_annotation_log_normalised_cluster_colour)
extract <- unique(extract)
#extract <- extract[order(extract$MTG_annotation_log_normalised %in% my_levels), ]
extract <- extract[match(my_levels, extract$MTG_annotation_log_normalised),]
subset_seu$MTG_annotation_log_normalised <- factor(subset_seu$MTG_annotation_log_normalised, levels = my_levels)

levels(as.factor(subset_seu$MTG_annotation_log_normalised))
extract$MTG_annotation_log_normalised_cluster_colour

#adjust width and height
#also adjust number of columns in legend https://github.com/satijalab/seurat/issues/3899

pdf("directory/UMAP_label_transfer_cluster_Allen.pdf", width = 20, height =17)
DimPlot(subset_seu, reduction = "umap", group.by = "MTG_annotation_log_normalised",
        cols = extract$MTG_annotation_log_normalised_cluster_colour
, pt.size=1) +
	guides(color = guide_legend(override.aes = list(size=10), ncol= 2) ) +
	theme(legend.text=element_text(size=10))
dev.off()





