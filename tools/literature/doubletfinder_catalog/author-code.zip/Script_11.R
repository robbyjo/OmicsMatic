#Label Transfer

library(SingleCellExperiment)
library(Seurat)
library(tidyverse)
library(Matrix)
library(scales)
library(cowplot)
library(RCurl)
library(pryr)
library(RColorBrewer)
library(dplyr)
library(textclean)

clusters_seurat_integrated <- readRDS("directory/clustered_seu_obj.rds")

Allen_seurat <- readRDS("direcotry/MTG_eight_donors_seurat.rds")

#LogNormalise MTG ref
Allen_seurat <- NormalizeData(Allen_seurat)

# Load cell cycle markers
load("directory/cycle.rda")

# Score cells for cell cycle
Allen_seurat <- CellCycleScoring(Allen_seurat, 
                                 g2m.features = g2m_genes, 
                                 s.features = s_genes)

# Identify the most variable genes
Allen_seurat <- FindVariableFeatures(Allen_seurat, 
                     selection.method = "vst",
                     nfeatures = 2000, 
                     verbose = FALSE)

# Scale the counts 
Allen_seurat <- ScaleData(Allen_seurat)

# Perform linear dimensional reduction
Allen_seurat <- RunPCA(Allen_seurat)
print(Allen_seurat[["pca"]], dims = 1:5, nfeatures = 5)
VizDimLoadings(Allen_seurat, dims = 1:2, reduction = "pca")

Allen_dimplot <- DimPlot(Allen_seurat, reduction = "pca", pt.size=1)
ggsave("directory/Allen_dimplot_plot.pdf", plot = Allen_dimplot)

Allen_heatmap <- DimHeatmap(Allen_seurat, dims = 1, cells = 500, balanced = TRUE)
ggsave("directory/Allen_heatmap.pdf", plot = Allen_heatmap)

# Cluster the cells
Allen_seurat <- FindNeighbors(Allen_seurat, dims = 1:8)
Allen_seurat <- FindClusters(Allen_seurat, resolution = 0.5)

# Run non-linear dimensional reduction (UMAP/tSNE)
Allen_seurat <- RunUMAP(Allen_seurat, dims = 1:8)
Allen_UMAP <- DimPlot(Allen_seurat, reduction = "umap", pt.size=1) + NoLegend()
ggsave("directory/Allen_UMAP.pdf", plot = Allen_UMAP)

Allen_UMAP_cluster <- DimPlot(Allen_seurat, reduction = "umap", group.by = "cluster", pt.size=1)
ggsave("directory/Allen_UMAP_cluster.pdf", plot = Allen_UMAP_cluster, width =17, height =20)

saveRDS(Allen_seurat, "directory/MTG_eight_donors_seurat_log_normalised.rds")


DefaultAssay(clusters_seurat_integrated) <- 'RNA'

brain.anchors <- FindTransferAnchors(reference = Allen_seurat,
                                     query = clusters_seurat_integrated,
                                     normalization.method = "LogNormalize",
                                     dims = 1:30)

ref1 <- Allen_seurat$cluster

# Transfer labels from the 75 clusters
predictions <- TransferData(anchorset = brain.anchors,
                                     refdata = ref1)

MTG_annotation <- predictions$predicted.id


clusters_seurat_integrated <- AddMetaData(clusters_seurat_integrated,
                    metadata = MTG_annotation,
                    col.name = 'MTG_annotation')


#Colours for cell types
#Access metadata here https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6919571/#
Allen_metadata <- read.csv("directory/NIHMS1535018-supplement-1535018_Sup_Tab2.csv", header = TRUE)

#Change the cluster label in Allen metadata to match the equivalent column name in the seurat object (i.e MTG_annotation)
colnames(Allen_metadata)[which(colnames(Allen_metadata)=="cluster")] <- "MTG_annotation"
colnames(Allen_metadata)[which(colnames(Allen_metadata)=="cluster_color")] <- "cluster_colour"

#Add the subcluster colour from the Allen metadata to the seurat object metadata by joining by subMTG_annotation
#subset all the unique entries in the subcluster column of Allen metadata and subset both the subcluster column and the subclass_color column

Idents(object = clusters_seurat_integrated) <- 'MTG_annotation'
levels(clusters_seurat_integrated)

#Create a new column with the same entries as the MTG_annotation column but call it cluster colour
clusters_seurat_integrated$cluster_colour <- clusters_seurat_integrated$MTG_annotation

clusters_seurat_integrated$cluster_colour <- mgsub(clusters_seurat_integrated$cluster_colour, Allen_metadata$MTG_annotation, Allen_metadata$cluster_colour)

Test <- Allen_metadata[Allen_metadata$MTG_annotation %in% levels(as.factor(clusters_seurat_integrated$MTG_annotation)), ]

my_levels <- c("Inh L1-2 PAX6 CDH12", "Inh L1-2 PAX6 TNFAIP8L3", 
"Inh L1 SST NMBR", "Inh L1-4 LAMP5 LCP2",
 "Inh L1-2 LAMP5 DBP", "Inh L2-6 LAMP5 CA1",
"Inh L1 SST CHRNA4", "Inh L1-2 GAD1 MC4R", 
"Inh L1-2 SST BAGE2", "Inh L1-3 PAX6 SYT6", 
"Inh L1-2 VIP TSPAN12", "Inh L1-4 VIP CHRNA6", 
"Inh L1-3 VIP ADAMTSL1", "Inh L1-4 VIP PENK", 
"Inh L2-6 VIP QPCT", "Inh L3-6 VIP HS3ST3A1", 
"Inh L1-2 VIP PCDH20","Inh L2-5 VIP SERPINF1", 
"Inh L2-5 VIP TYR", "Inh L1-3 VIP CHRM2", 
"Inh L2-4 VIP CBLN1", "Inh L1-3 VIP CCDC184", 
"Inh L1-3 VIP GGH", "Inh L1-2 VIP LBH", 
"Inh L2-3 VIP CASC6", "Inh L2-4 VIP SPAG17",
"Inh L1-4 VIP OPRM1", "Inh L3-6 SST NPY",
"Inh L3-6 SST HPGD", "Inh L4-6 SST B3GAT2",
"Inh L5-6 SST KLHDC8A", "Inh L5-6 SST NPM1P10",
"Inh L4-6 SST GXYLT2", "Inh L4-5 SST STK32A",
"Inh L1-3 SST CALB1", "Inh L3-5 SST ADGRG6", 
"Inh L2-4 SST FRZB", "Inh L5-6 SST TH", 
"Inh L5-6 GAD1 GLP1R", "Inh L5-6 PVALB LGR5",
 "Inh L4-5 PVALB MEPE", "Inh L2-4 PVALB WFDC2", 
"Inh L4-6 PVALB SULF1", "Inh L5-6 SST MIR548F2", 
"Inh L2-5 PVALB SCUBE3", "Exc L2 LAMP5 LTK", 
"Exc L2-4 LINC00507 GLP2R", "Exc L2-3 LINC00507 FREM3", 
"Exc L5-6 THEMIS C1QL3", "Exc L3-4 RORB CARM1P1", 
"Exc L3-5 RORB ESR1", "Exc L3-5 RORB COL22A1", 
"Exc L3-5 RORB FILIP1L",
"Exc L3-5 RORB TWIST2", "Exc L4-5 RORB FOLH1B",
"Exc L4-6 RORB SEMA3E", "Exc L4-5 RORB DAPK2",
"Exc L5-6 RORB TTC12", "Exc L4-6 RORB C1R",
"Exc L4-5 FEZF2 SCN4B", "Exc L5-6 THEMIS DCSTAMP",
"Exc L5-6 THEMIS CRABP1", "Exc L5-6 THEMIS FGF10",
"Exc L4-6 FEZF2 IL26", "Exc L5-6 FEZF2 ABO",
"Exc L6 FEZF2 SCUBE1", "Exc L5-6 SLC17A7 IL15",
"Exc L6 FEZF2 OR2T8", "Exc L5-6 FEZF2 EFTUD1P1",
"OPC L1-6 PDGFRA", "Astro L1-6 FGFR3 SLC14A1",
"Astro L1-2 FGFR3 GFAP", "Oligo L1-6 OPALIN", 
"Endo L2-6 NOSTRIN", "Micro L1-3 TYROBP")


extract <- clusters_seurat_integrated@meta.data %>% select(MTG_annotation, cluster_colour)
extract <- unique(extract)

#extract <- extract[order(extract$MTG_annotation %in% my_levels), ]
extract <- extract[match(my_levels, extract$MTG_annotation),]
clusters_seurat_integrated$MTG_annotation <- factor(clusters_seurat_integrated$MTG_annotation, levels = my_levels)

levels(as.factor(clusters_seurat_integrated$MTG_annotation))
extract$cluster_colour

#adjust width and height
#also adjust number of columns in legend https://github.com/satijalab/seurat/issues/3899


pdf("directory/UMAP_label_transfer_cluster_Allen.pdf", width = 20, height =17)
DimPlot(clusters_seurat_integrated, reduction = "umap", group.by = "MTG_annotation",
        cols = extract$cluster_colour, pt.size=1) +
	guides(color = guide_legend(override.aes = list(size=10), ncol= 2) ) +
	theme(legend.text=element_text(size=10))
dev.off()


MTG <- readRDS("directory/Annotated_seurat.rds")

MTG$MTG_annotation_log_normalised <- clusters_seurat_integrated$MTG_annotation

MTG$MTG_annotation_log_normalised_cluster_colour <- clusters_seurat_integrated$cluster_colour

saveRDS(MTG, "directory/Annotated_seu_obj.rds")

