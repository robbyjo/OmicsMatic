#Convert seu object to anndata object

library(withr)
library(Seurat)
library(reticulate)
library(SCP) #Not with conda env activated


seu <- readRDS("directory/Consensus_broad_high_res_annotated_seu.rds")
Idents(seu) <- seu$Biological_replicate
min <- min(table(seu$Biological_replicate))

#Min = 4671

#Downsample function is to downsample per ident! 
Downsample <- subset(seu, downsample = min)
table(Downsample$Biological_replicate)

saveRDS(Downsample, "directory/Downsampled_seu.rds")

#Paediatric
subset_seu <- subset(Downsample, subset = Age_group == "Juvenile")
DefaultAssay(subset_seu) <- "RNA"
adata <- srt_to_adata(subset_seu, assay_X = "RNA", slot_X = "data")
adata$write_h5ad("directory/Paediatric_seu.h5ad")


#Adult
subset_seu <- subset(Downsample, subset = Age_group == "Adult")
DefaultAssay(subset_seu) <- "RNA"
adata <- srt_to_adata(subset_seu, assay_X = "RNA", slot_X = "data")
adata$write_h5ad("directory/Adult_seu.h5ad")


#Combined
DefaultAssay(Downsample) <- "RNA"
adata <- srt_to_adata(Downsample, assay_X = "RNA", slot_X = "data")
adata$write_h5ad("directory/Combined_seu.h5ad")
