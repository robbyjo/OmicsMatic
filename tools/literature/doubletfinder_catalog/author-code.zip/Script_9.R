#Plot violin plots instead of featureplots?
#Markers from Hodge et al Middle temporal gyrus
#Lake et al 
#Bakken et al

# Load libraries
library(SingleCellExperiment)
library(Seurat)
library(Matrix)
library(scales)
library(tidyverse)
library(RCurl)
library(cowplot)


clusters_seurat_integrated <- readRDS("directory/clustered_seu_obj.rds")

Idents(object = clusters_seurat_integrated) <- "integrated_snn_res.0.8"

Idents(clusters_seurat_integrated) <- factor(Idents(clusters_seurat_integrated), levels = c("0", "1", "2", "3", "4", "5", "6", "7", "8", "9", 
"10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", 
"32", "33", "34" , "35", "36", "37", "38", "39"))

# Select the RNA counts slot to be the default assay
DefaultAssay(clusters_seurat_integrated) <- "RNA"

Astrocyte_feature <- VlnPlot(clusters_seurat_integrated,
  features = c("FGFR3", "SLC14A1", "DIO2", "GFAP", "AQP4", "ID3", "TNC", "SLC1A2"),
  assay = 'RNA',
  slot = "data",
  stack = TRUE, flip = TRUE, fill.by = "ident"
) +
theme(axis.text.x=element_text(size=7, angle = 0), legend.position = "none")+
xlab("cluster")

ggsave("directory/Astrocyte_vln_plot.pdf", plot = Astrocyte_feature)

Microglia_feature <- VlnPlot(clusters_seurat_integrated,
  features = c("TYROBP", "C3", "CX3CR1", "CSF1R", "APBB1IP", "DOCK8", "FYB", "ADAM28"),
  assay = 'RNA',
  slot = "data",
  stack = TRUE, flip = TRUE, fill.by = "ident"
) +
theme(axis.text.x=element_text(size=7, angle = 0), legend.position = "none")+
xlab("cluster")

ggsave("directory/Microglia_vln_plot.pdf", plot = Microglia_feature)

Oligodendrocytes_feature <- VlnPlot(clusters_seurat_integrated,
  features = c("OPALIN", "PLP1", "MAG", "KLK6", "MOBP", "ST18", "MBP", "RNF220"),
  assay = 'RNA',
  slot = "data",
  stack = TRUE, flip = TRUE, fill.by = "ident"
) +
theme(axis.text.x=element_text(size=7, angle = 0), legend.position = "none")+
xlab("cluster")

ggsave("directory/Oligodendrocytes_vln_plot.pdf", plot = Oligodendrocytes_feature)

OPC_feature <- VlnPlot(clusters_seurat_integrated,
  features = c("PDGFRA", "COL20A1", "OLIG2", "PRRX1", "SEMA5A", "VCAN", "TNR", "PCDH15"),
  assay = 'RNA',
  slot = "data",
  stack = TRUE, flip = TRUE, fill.by = "ident"
) +
theme(axis.text.x=element_text(size=7, angle = 0), legend.position = "none")+
xlab("cluster")

ggsave("directory/OPC_vln_plot.pdf", plot = OPC_feature)

Inhibitory_feature <- VlnPlot(clusters_seurat_integrated,
  features = c("PAX6", "LAMP5", "VIP", "SST", "PVALB", "LHX6", "ADARB2", "GAD1"),
  assay = 'RNA',
  slot = "data",
  stack = TRUE, flip = TRUE, fill.by = "ident"
) +
theme(axis.text.x=element_text(size=7, angle = 0), legend.position = "none")+
xlab("cluster")

ggsave("directory/Inhibitory_vln_plot.pdf", plot = Inhibitory_feature)

Excitatory_feature <- VlnPlot(clusters_seurat_integrated,
  features = c("THEMIS", "RORB", "FEZF2", "LINC00507", "CUX1", "CUX2", "SLC17A7", "SATB2"),
  assay = 'RNA',
  slot = "data",
  stack = TRUE, flip = TRUE, fill.by = "ident"
) +
theme(axis.text.x=element_text(size=7, angle = 0), legend.position = "none")+
xlab("cluster")

ggsave("directory/Excitatory_vln_plot.pdf", plot = Excitatory_feature)

Endothelial_feature <- VlnPlot(clusters_seurat_integrated,
  features = c("NOSTRIN", "MECOM", "CLDN5", "HLA-E", "ABCB1", "FLT1", "IGFBP7", "HLA-B"),
  assay = 'RNA',
  slot = "data",
  stack = TRUE, flip = TRUE, fill.by = "ident"
) +
theme(axis.text.x=element_text(size=7, angle = 0), legend.position = "none")+
xlab("cluster")

ggsave("directory/Endothelial_vln_plot.pdf", plot = Endothelial_feature)



Pericytes_feature <- VlnPlot(clusters_seurat_integrated,
  features = c("ATP1A2", "DLC1", "ITIH5", "LAMA2", "DCN", "SLC6A12", "SLC19A1", "EBF1"),
  assay = 'RNA',
  slot = "data",
  stack = TRUE, flip = TRUE, fill.by = "ident"
) +
theme(axis.text.x=element_text(size=7, angle = 0), legend.position = "none")+
xlab("cluster")

ggsave("directory/Perciyte_vln_plot.pdf", plot = Pericytes_feature)
