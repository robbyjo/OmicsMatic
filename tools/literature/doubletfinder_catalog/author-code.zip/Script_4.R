library(SingleCellExperiment)
library(Seurat)
library(tidyverse)
library(Matrix)
library(scales)
library(cowplot)
library(RCurl)
library(DeconRNASeq)
library(gplots)
library(dplyr)
library(MCL)
library(clusterProfiler)
library(mygene)
library(tidyr)
library(R.utils)
library(foreach)
library(doParallel)
library(stringr)
library(DoubletDecon)
library(dplyr)


#Preclustering 

#Run QC script (script 1) prior to filtering

#load unfiltered_seurat object (no doublets or any nuclei removed)
load("QC_directory/data/unfiltered_seurat_merged.RData")

# Normalize the counts
seurat_phase <- NormalizeData(merged_seurat)

# Load cell cycle markers
load("QC_directory/data/cycle.rda")

#Perform individually for all samples
split_seurat <- SplitObject(seurat_phase, split.by = "sample")

split_seurat <- split_seurat[c("P_4_T1", "P_5_T1", "P_5_T2", "P_7_T1", "P_7_T2", "P_9_T1", "P_9_T2", "P_15_T1_B1", "P_15_T2_B1", "P_15_T3_B1", "P_15_T4_B1", 
                      "P_15_T5_B1", "P_15_T6_B1", "P_15_T1_B2", "A_20_T1", "A_20_T2", "A_24_T1", "A_24_T2", "A_26_T1", "A_31_T1", "A_31_T2", "A_41_T1", "A_50_T1")]

for (i in 1:length(split_seurat)){
  split_seurat[[i]] <- CellCycleScoring(split_seurat[[i]], 
                                 g2m.features = g2m_genes, 
                                 s.features = s_genes)
  split_seurat[[i]] <- FindVariableFeatures(split_seurat[[i]], 
                     selection.method = "vst",
                     nfeatures = 2000, 
                     verbose = FALSE)
  split_seurat[[i]] <- ScaleData(split_seurat[[i]], vars.to.regress = c("mitoRatio"))
  split_seurat[[i]] <- RunPCA(split_seurat[[i]])
  split_seurat[[i]] <- RunTSNE(split_seurat[[i]])
  saveRDS(split_seurat[[i]], paste0("Doublet_removal/Preclustering/SCT/data/", split_seurat[[i]]@meta.data$sample[1], "_unclustered_seurat.rds"))
}


#Perform on the merged sample
seurat_phase <- CellCycleScoring(seurat_phase, 
                                 g2m.features = g2m_genes, 
                                 s.features = s_genes)

seurat_phase <- FindVariableFeatures(seurat_phase, 
                     selection.method = "vst",
                     nfeatures = 2000, 
                     verbose = FALSE)

seurat_phase <- ScaleData(seurat_phase, vars.to.regress = c("mitoRatio"))


# Scale the counts
# Perform PCA
seurat_phase <- RunPCA(seurat_phase)

# Plot the PCA colored by cell cycle phase
PCA_cell_cycle_phase <- DimPlot(seurat_phase,
        reduction = "pca",
        group.by= "Phase",
        split.by = "Phase")

ggsave("Doublet_removal/Preclustering/SCT/figures/PCA_cell_cycle_phase.pdf", plot = PCA_cell_cycle_phase)

UMAP_unintegrated_for_comparison <- RunUMAP(seurat_phase, 
                             dims = 1:40,
			     reduction = "pca")
# Plot UMAP                             
UMAP_unintegrated_plot <- DimPlot(UMAP_unintegrated_for_comparison)  

ggsave("Doublet_removal/Preclustering/SCT/figures/UMAP_unintegrated_for_comparison.pdf", plot = UMAP_unintegrated_plot)


UMAP_unintegrated_split <- DimPlot(UMAP_unintegrated_for_comparison, split.by = "sample")       
ggsave("Doublet_removal/Preclustering/SCT/figures/UMAP_unintegrated_split_by_sample.pdf", plot = UMAP_unintegrated_split)


split_seurat <- SplitObject(UMAP_unintegrated_for_comparison, split.by = "sample")

split_seurat <- split_seurat[c("P_4_T1", "P_5_T1", "P_5_T2", "P_7_T1", "P_7_T2", "P_9_T1", "P_9_T2", "P_15_T1_B1", "P_15_T2_B1", "P_15_T3_B1", "P_15_T4_B1", 
                      "P_15_T5_B1", "P_15_T6_B1", "P_15_T1_B2", "A_20_T1", "A_20_T2", "A_24_T1", "A_24_T2", "A_26_T1", "A_31_T1", "A_31_T2", "A_41_T1", "A_50_T1")]


for (i in 1:length(split_seurat)){
	UMAP_unintegrated <- DimPlot(split_seurat[[i]])
	ggsave(paste0("Doublet_removal/SCT/Preclustering/figures/", "UMAP_", split_seurat[[i]]@meta.data$sample[1], "_unintegrated.pdf"), plot = UMAP_unintegrated)
}

PCA_unintegrated_for_comparison <- PCAPlot(seurat_phase,
        split.by = "sample") 
ggsave("Doublet_removal/Preclustering/SCT/figures/PCA_unintegrated_for_comparison.pdf", plot = PCA_unintegrated_for_comparison)


options(future.globals.maxSize = 4000 * 1024^2)

# Split seurat object by condition to perform cell cycle scoring and SCT on all samples
split_seurat <- SplitObject(merged_seurat, split.by = "sample")

split_seurat <- split_seurat[c("P_4_T1", "P_5_T1", "P_5_T2", "P_7_T1", "P_7_T2", "P_9_T1", "P_9_T2", "P_15_T1_B1", "P_15_T2_B1", "P_15_T3_B1", "P_15_T4_B1", 
                      "P_15_T5_B1", "P_15_T6_B1", "P_15_T1_B2", "A_20_T1", "A_20_T2", "A_24_T1", "A_24_T2", "A_26_T1", "A_31_T1", "A_31_T2", "A_41_T1", "A_50_T1")]

for (i in 1:length(split_seurat)) {
    split_seurat[[i]] <- NormalizeData(split_seurat[[i]], verbose = TRUE)
    split_seurat[[i]] <- CellCycleScoring(split_seurat[[i]], g2m.features=g2m_genes, s.features=s_genes)
    split_seurat[[i]] <- SCTransform(split_seurat[[i]], vars.to.regress = c("mitoRatio"))
    saveRDS(split_seurat[[i]], paste0("Doublet_removal/Preclustering/SCT/data/", split_seurat[[i]]@meta.data$sample[1], "_SCT.rds"))
}

# Select the most variable features to use for integration
integ_features <- SelectIntegrationFeatures(object.list = split_seurat, 
                                            nfeatures = 3000) 


# Prepare the SCT list object for integration
split_seurat <- PrepSCTIntegration(object.list = split_seurat, 
                                   anchor.features = integ_features)

# Find best buddies - can take a while to run
integ_anchors <- FindIntegrationAnchors(object.list = split_seurat, 
                                        normalization.method = "SCT", 
                                        anchor.features = integ_features, reference = 1)
# Integrate across conditions
seurat_integrated <- IntegrateData(anchorset = integ_anchors, 
                                   normalization.method = "SCT")

# Save integrated seurat object

saveRDS(seurat_integrated, "Doublet_removal/Preclustering/SCT/data/integrated_seurat.rds")

seurat_integrated <- RunPCA(object = seurat_integrated)

# Plot PCA
PCA_plot_integrated <- PCAPlot(seurat_integrated,
        split.by = "sample")  

ggsave("Doublet_removal/Preclustering/SCT/figures/PCA_plot_integrated.pdf", plot = PCA_plot_integrated)

# Run UMAP
seurat_integrated <- RunUMAP(seurat_integrated, 
                             dims = 1:40,
			     reduction = "pca")


# Plot UMAP                             
UMAP_integrated <- DimPlot(seurat_integrated)                             

ggsave("Doublet_removal/Preclustering/SCT/figures/UMAP_integrated.pdf", plot = UMAP_integrated)

#UMAP split by sample  
UMAP_integrated_split_by_sample <- DimPlot(seurat_integrated,
        split.by = "sample")  

ggsave("Doublet_removal/Preclustering/SCT/figures/UMAP_integrated_split_by_sample.pdf", plot = UMAP_integrated_split_by_sample)


#Each sample separately

split_seurat <- SplitObject(seurat_integrated, split.by = "sample")

split_seurat <- split_seurat[c("P_4_T1", "P_5_T1", "P_5_T2", "P_7_T1", "P_7_T2", "P_9_T1", "P_9_T2", "P_15_T1_B1", "P_15_T2_B1", "P_15_T3_B1", "P_15_T4_B1", 
                      "P_15_T5_B1", "P_15_T6_B1", "P_15_T1_B2", "A_20_T1", "A_20_T2", "A_24_T1", "A_24_T2", "A_26_T1", "A_31_T1", "A_31_T2", "A_41_T1", "A_50_T1")]

for (i in 1:length(split_seurat)) {
	UMAP_unintegrated <- DimPlot(split_seurat[[i]])
	ggsave(paste0("Doublet_removal/Preclustering/SCT/figures/", "UMAP_", split_seurat[[i]]@meta.data$sample[1], "_integrated.pdf"), plot = UMAP_unintegrated)
}

#Clustering analysis 
for (i in 1:length(split_seurat)) {
  seurat_SCT <- readRDS(paste0("Doublet_removal/Preclustering/SCT/data/", split_seurat[i], "_SCT.rds"))
  seurat_SCT <- RunPCA(seurat_SCT, verbose = FALSE)
  PC_heatmap <- DimHeatmap(seurat_SCT, 
           dims = 1:9, 
           cells = 500, 
           balanced = TRUE)
  ggsave(paste0("Doublet_removal/Preclustering/Clustering/figures/", split_seurat[i], "_PC_heatmap.pdf"), plot = PC_heatmap)
  elbow_plot <- ElbowPlot(object = seurat_SCT, ndims = 40)
  ggsave(paste0("Doublet_removal/Preclustering/Clustering/figures/", split_seurat[i], "_elbow_plot.pdf"), plot = elbow_plot)
  seurat_SCT <- FindNeighbors(object = seurat_SCT, dims = 1:40)                   
  clusters_seurat <- FindClusters(object = seurat_SCT, resolution = c(0.2))
  Idents(object = clusters_seurat) <- "SCT_snn_res.0.2"
  clusters_seurat <- RunUMAP(clusters_seurat, reduction = "pca", dims = 1:40)
  saveRDS(clusters_seurat, file = paste0("Doublet_removal/Preclustering/Clustering/data/", split_seurat[i], "_clusters_seurat.rds"))
  UMAP_clusters_seurat <- DimPlot(clusters_seurat, reduction = "umap", label = TRUE, label.size = 6)
  ggsave(paste0("Doublet_removal/Preclustering/Clustering/figures/", split_seurat[i], "_UMAP_clusters_seurat.pdf"), plot = UMAP_clusters_seurat)
  n_cells <- FetchData(clusters_seurat, vars = c("ident", "orig.ident"))%>% 
  dplyr::count(ident, orig.ident) %>%
  tidyr::spread(ident, n)
  write.csv(n_cells, file = paste0("Doublet_removal/Preclustering/Clustering/data/", split_seurat[i], "_number_of_cells_per_cluster.csv"))
  UMAP_cell_cycle_phase <- DimPlot(clusters_seurat,
        label = TRUE, 
        split.by = "Phase")  + NoLegend()
  ggsave(paste0("Doublet_removal/Preclustering/Clustering/figures/", split_seurat[i], "_UMAP_cell_cycle_phase.pdf"), plot = UMAP_cell_cycle_phase)
  metrics <-  c("nUMI", "nGene", "S.Score", "G2M.Score", "mitoRatio")
  feature_plot <- FeaturePlot(clusters_seurat, 
            reduction = "umap", 
            features = metrics,
            pt.size = 0.4, 
            sort.cell = TRUE,
            min.cutoff = 'q10',
            label = TRUE)
  ggsave(paste0("Doublet_removal/Preclustering/Clustering/figures/", split_seurat[i], "_Feature_plot_metrics.pdf"), plot = feature_plot)
}


#Optimise rho prime values

location="Doublet_removal/DoubletDecon/Improved_Seurat_Pre_Process/" 

location2="Doublet_removal/DoubletDecon/outputs/"

filename="Improved_Seurat_Pre_Process"
filename2="outputs" 

split_seurat <- c("P_4_T1", "P_5_T1", "P_5_T2", "P_7_T1", "P_7_T2", "P_9_T1", "P_9_T2", "P_15_T1_B1", "P_15_T2_B1", "P_15_T3_B1", "P_15_T4_B1", 
                      "P_15_T5_B1", "P_15_T6_B1", "P_15_T1_B2", "A_20_T1", "A_20_T2", "A_24_T1", "A_24_T2", "A_26_T1", "A_31_T1", "A_31_T2", "A_41_T1", "A_50_T1")

rho <- c(0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6)

for (i in 1:length(split_seurat)) {
  clustered_seurat <- readRDS(paste0("Doublet_removal/Preclustering/Clustering/data/", split_seurat[i], "_clusters_seurat.rds"))
  newFiles=Improved_Seurat_Pre_Process(clustered_seurat, num_genes=50, write_files=FALSE, data_type="data")
  str_replace(colnames(newFiles$newExpressionFile), "[.]", "-")
  str_replace(colnames(newFiles$newFullExpressionFile), "[.]", "-")
  num_doubs = round(0.1*ncol(clustered_seurat))
  for (t in 1:length(rho)){
  pdf(paste0("Doublet_removal/DoubletDecon/Optimise_rho/", split_seurat[i], "_rho_", rho[t], "_heatmap.pdf"))
  Doublet_Decon_results <- Main_Doublet_Decon(rawDataFile=newFiles$newExpressionFile, 
                           groupsFile=newFiles$newGroupsFile, 
                           filename=filename2, 
                           location=location2,
                           fullDataFile=NULL, 
                           removeCC=FALSE, 
                           species="Homo sapiens", 
                           rhop= rho[t], 
                           write=TRUE, 
                           PMF=TRUE, 
                           useFull=FALSE, 
                           heatmap=FALSE,
                           centroids=TRUE,
                           num_doubs= num_doubs, 
                           only50=FALSE,
                           min_uniq=4,
                           nCores=-1)
dev.off()
}
}

#Run DoubletDecon
s#After clustering step: Load the seurat object with the clusters: 
#Load clustered seurat object

rho_values_per_sample <- c(1.2, 1.2, 1.1, 1.0, 1.2, 1.4, 1.0)

for (i in 1:length(split_seurat)) {
  clustered_seurat <- readRDS(paste0("Doublet_removal/Preclustering/Clustering/data/", split_seurat[i], "_clusters_seurat.rds"))
  newFiles=Improved_Seurat_Pre_Process(clustered_seurat, num_genes=50, write_files=FALSE, data_type="data")
  str_replace(colnames(newFiles$newExpressionFile), "[.]", "-")
  str_replace(colnames(newFiles$newFullExpressionFile), "[.]", "-")
  write.table(newFiles$newExpressionFile, paste0(location, split_seurat[i], "_", filename, "_expression"), sep="\t")
  write.table(newFiles$newFullExpressionFile, paste0(location, split_seurat[i], "_", filename, "_fullExpression"), sep="\t")
  write.table(newFiles$newGroupsFile, paste0(location, split_seurat[i], "_", filename , "_groups"), sep="\t", col.names = F)
  num_doubs = round(0.1*ncol(clustered_seurat))
  png(paste0(location2, split_seurat[i], "_heatmap.pdf"))
  Doublet_Decon_results <- Main_Doublet_Decon(rawDataFile=newFiles$newExpressionFile, 
                           groupsFile=newFiles$newGroupsFile, 
                           filename=filename2, 
                           location=location2,
                           fullDataFile=NULL, 
                           removeCC=FALSE, 
                           species="Homo sapiens", 
                           rhop=rho_values_per_sample[i], 
                           write=TRUE, 
                           PMF=TRUE, 
                           useFull=FALSE, 
                           heatmap=FALSE,
                           centroids=TRUE,
                           num_doubs= num_doubs, 
                           only50=FALSE,
                           min_uniq=4,
                           nCores=-1)
  dev.off()
  Doublets <- Doublet_Decon_results$Final_doublets_groups
  Non_doublets <- Doublet_Decon_results$Final_nondoublets_groups
  Doublets <- str_replace(rownames(Doublets), "[.]", "-")
  Non_doublets <- str_replace(rownames(Non_doublets), "[.]", "-")
  write.csv(Doublets, file = paste0(location2, split_seurat[i], "_doublets.csv"), row.names= FALSE)
  write.csv(Non_doublets, file = paste0(location2, split_seurat[i], "_non_doublets.csv"), row.names= FALSE)
  doublets <- read.csv(paste0(location2, split_seurat[i], "_doublets.csv"))
  non_doublets <- read.csv(paste0(location2, split_seurat[i], "_non_doublets.csv"))
  colnames(doublets) <- c("barcode")
  colnames(non_doublets) <- c("barcode")
  doublets[,2] <- "True"
  non_doublets[,2] <- "False"
  Doublet_Decon_combined_outputs <- rbind(doublets, non_doublets)
  colnames(Doublet_Decon_combined_outputs) <- c("barcode", "predicted_doublet")
  write.csv(Doublet_Decon_combined_outputs, file= paste0(location2, split_seurat[i], "_Doublet_Decon_combined_outputs.csv"), row.names=FALSE)
 }

for (i in 1:length(split_seurat)) {
 clustered_seurat <- readRDS(paste0("Doublet_removal/Preclustering/Clustering/data/", split_seurat[i], "_clusters_seurat.rds")) 
 Doublets <- read.csv(paste0(location2, split_seurat[i], "_doublets.csv"))
 UMAP_visualise_doublets <- DimPlot(clustered_seurat, reduction = "umap", cells.highlight= as.list(Doublets$x)) + NoLegend()
 ggsave(paste0(location2, split_seurat[i], "_doublet_decon_UMAP.pdf"), UMAP_visualise_doublets)
}

