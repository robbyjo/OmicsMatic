#Create seurat object 
library(Matrix)
library(ff)
library(Seurat)
library(data.table)
library(readr)
library(Seurat)
library(ggplot2)
library(RColorBrewer)

#Acess reference dataset here https://portal.brain-map.org/atlases-and-data/rnaseq/human-multiple-cortical-areas-smart-seq

#Create matrix by combining the counts for each gene including exons and introns
exon <- fread("directory/human_MTG_2018-06-14_exon-matrix.csv")
intron <- fread("directory/human_MTG_2018-06-14_intron-matrix.csv")
combine <- exon + intron
combine <- as.matrix(combine)
sparse.gbm <- Matrix(combine, sparse = T)
head(sparse.gbm)
sparse.gbm <- sparse.gbm[ , -1]
#Either save it as .gz or manually add .gz to the file name
## Market Exchange Format (MEX) format
writeMM(obj = sparse.gbm, file="directory/matrix.mtx.gz")


#Save barcodes
barcodes <- read.csv("directory/human_MTG_2018-06-14_samples-columns.csv")
barcodes <- barcodes$sample_name
write(x = barcodes, file = "directory/barcodes.tsv.gz")


#Save features
features <- read.csv("directory/human_MTG_2018-06-14_genes-rows.csv")
features <- features$gene
write(x = features, file = "directory/Create_seurat/features.tsv.gz")


#Read in matrix

counts <- readMM("directory/Create_seurat/matrix.mtx.gz")

# Read in `genes.tsv`
features <- read_tsv("directory/Create_seurat/features.tsv.gz", col_names = FALSE)

gene_ids <- features$X1

# Read in `barcodes.tsv`
barcodes <- read_tsv("directory/Create_seurat/barcodes.tsv.gz", col_names = FALSE)

cell_ids <- barcodes$X1

# Make the column names as the cell IDs and the row names as the gene IDs
rownames(counts) <- gene_ids
colnames(counts) <- cell_ids

MTG <- CreateSeuratObject(counts = counts)

#Add metadata
MTG_metadata <- read.csv("directory/human_MTG_2018-06-14_samples-columns.csv", header=T)
MTG@meta.data <- MTG_metadata
rownames(MTG@meta.data) <- colnames(MTG)

#Remove nuclei with NA annotation
MTG <- subset(MTG, subset = cluster == "no class", invert = TRUE) 

#Save seurat object
saveRDS(MTG, "directory/MTG_eight_donors_seurat.rds") 

#Sanity check
levels(as.factor(MTG$donor))

#Violin plots of nGene and nUMI per cell type

#nUMI = total_reads

#nGene = genes_detected_cpm_criterion

Total_UMI <- VlnPlot(MTG, features = "total_reads", group.by = 'cluster', pt.size = 0, assay = 'RNA') +
  ylab("Total UMI")+ stat_summary(fun.data=median_hilow, conf.int=.95, 
        geom="errorbar", color="black", width = 0.3) +
  stat_summary(fun.y=median, geom="point", color="black")+
theme(legend.position="none", axis.text = element_text(size = 10))+
theme(axis.text.x = element_text(angle = 90))

ggsave("directory/Total_UMIs_per_nucleus_per_MTG_celltype.pdf", Total_UMI)

Genes_detected <- VlnPlot(MTG, features = "genes_detected_cpm_criterion", group.by = 'cluster', pt.size = 0, assay = 'RNA') +
  ylab("Genes detected") + stat_summary(fun.data=median_hilow, conf.int=.95,  
        geom="errorbar", color="black", width = 0.3) +
  stat_summary(fun.y=median, geom="point", color="black")+
theme(legend.position="none", axis.text = element_text(size = 10))+
theme(axis.text.x = element_text(angle = 90))

ggsave("directory/Genes_detected_per_nucleus_per_MTG_celltype.pdf", Genes_detected)


#Bubbleplot of Hodge markers

#Hodge marker genes ordered
Hodge_features <- c("TYROBP", "NOSTRIN", "OPALIN", "FGFR3", "PDGFRA", "SLC1A3", "FEZF2", "THEMIS", "RORB", "LINC00507", "SLC17A7", "PVALB", "SST", "LHX6", "VIP", "LAMP5", "PAX6", "ADARB2", "GAD1")

my_levels <- c("Inh L1-2 PAX6 CDH12", "Inh L1-2 PAX6 TNFAIP8L3", 
"Inh L1 SST NMBR", "Inh L1-4 LAMP5 LCP2",
 "Inh L1-2 LAMP5 DBP", "Inh L2-6 LAMP5 CA1",
"Inh L1 SST CHRNA4", "Inh L1-2 GAD1 MC4R", 
"Inh L1-2 SST BAGE2", "Inh L1-3 PAX6 SYT6", 
"Inh L1-2 VIP TSPAN12", "Inh L1-4 VIP CHRNA6", 
"Inh L1-3 VIP ADAMTSL1", "Inh L1-4 VIP PENK", 
"Inh L2-6 VIP QPCT", "Inh L3-6 VIP HS3ST3A1", 
"Inh L1-2 VIP PCDH20","Inh L2-5 VIP SERPINF1", 
"Inh L2-5 VIP TYR", "Inh L1-3 VIP CHRM2", 
"Inh L2-4 VIP CBLN1", "Inh L1-3 VIP CCDC184", 
"Inh L1-3 VIP GGH", "Inh L1-2 VIP LBH", 
"Inh L2-3 VIP CASC6", "Inh L2-4 VIP SPAG17",
"Inh L1-4 VIP OPRM1", "Inh L3-6 SST NPY",
"Inh L3-6 SST HPGD", "Inh L4-6 SST B3GAT2",
"Inh L5-6 SST KLHDC8A", "Inh L5-6 SST NPM1P10",
"Inh L4-6 SST GXYLT2", "Inh L4-5 SST STK32A",
"Inh L1-3 SST CALB1", "Inh L3-5 SST ADGRG6", 
"Inh L2-4 SST FRZB", "Inh L5-6 SST TH", 
"Inh L5-6 GAD1 GLP1R", "Inh L5-6 PVALB LGR5",
 "Inh L4-5 PVALB MEPE", "Inh L2-4 PVALB WFDC2", 
"Inh L4-6 PVALB SULF1", "Inh L5-6 SST MIR548F2", 
"Inh L2-5 PVALB SCUBE3", "Exc L2 LAMP5 LTK", 
"Exc L2-4 LINC00507 GLP2R", "Exc L2-3 LINC00507 FREM3", 
"Exc L5-6 THEMIS C1QL3", "Exc L3-4 RORB CARM1P1", 
"Exc L3-5 RORB ESR1", "Exc L3-5 RORB COL22A1", 
"Exc L3-5 RORB FILIP1L",
"Exc L3-5 RORB TWIST2", "Exc L4-5 RORB FOLH1B",
"Exc L4-6 RORB SEMA3E", "Exc L4-5 RORB DAPK2",
"Exc L5-6 RORB TTC12", "Exc L4-6 RORB C1R",
"Exc L4-5 FEZF2 SCN4B", "Exc L5-6 THEMIS DCSTAMP",
"Exc L5-6 THEMIS CRABP1", "Exc L5-6 THEMIS FGF10",
"Exc L4-6 FEZF2 IL26", "Exc L5-6 FEZF2 ABO",
"Exc L6 FEZF2 SCUBE1", "Exc L5-6 SLC17A7 IL15",
"Exc L6 FEZF2 OR2T8", "Exc L5-6 FEZF2 EFTUD1P1",
"OPC L1-6 PDGFRA", "Astro L1-6 FGFR3 SLC14A1",
"Astro L1-2 FGFR3 GFAP", "Oligo L1-6 OPALIN", 
"Endo L2-6 NOSTRIN", "Micro L1-3 TYROBP")


DefaultAssay(MTG) <- 'RNA'

MTG$cluster <- factor(MTG$cluster, levels = my_levels)

#Code for dotplot

bubbleplot <- DotPlot(MTG,
  features= Hodge_features,
  assay = 'RNA',
  cols = c("RdYlBu"),
  dot.min = 0,
  group.by = 'cluster',
  scale = TRUE, scale.max = 100, scale.min = 0, col.max = 4, col.min = -4)

ggsave("directory/Dotplot_Hodge_markers_per_MTG_celltype.pdf", bubbleplot, width= 20, height=17)